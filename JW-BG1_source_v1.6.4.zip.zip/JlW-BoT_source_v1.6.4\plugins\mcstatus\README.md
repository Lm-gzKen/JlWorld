# 我的世界查询（mcstatus）

JlWBoT 进程内 JS 插件。在群里/私聊发送 `/MC` 指令，调用**聚龙世界 MCStatus 接口**查询 Minecraft 服务器状态，随机底图生成状态图，或返回 JSON / 接口帮助。

- 类型：`js`（进程内，无需令牌、无需额外进程）
- 依赖：Node.js 18+（使用全局 `fetch`），无第三方包
- 数据来源：<https://www.jlworld.net>
- 当前版本：**1.3.3**

## 安装（导入框架）

拿到 `我的世界查询-【v1.3.3】.zip` 后：

1. 面板「插件」→「导入插件」→ 选「插件压缩包（.zip）」→ 选中 zip → 开始导入。
2. 插件出现在列表里（默认启用）。
3. 点插件卡片「编辑」→「设置」，填入聚龙世界 MCStatus 接口密钥（`mcst_...`），保存。
4. 在群里 @机器人 发 `/MC mc.hypixel.net` 验证。

> zip 是纯净版：不含任何密钥、自定义指令或运行数据；安装后按第 3 步填自己的 key 即可。

## 更新记录

### 1.3.3
- 设置页变量改为下拉选择：选中后显示说明，点「插入」在光标处插入；不再是一排不认识的标签。
- 纯净包 `plugin.json` 的 `config.commands` 带默认 4 条（type + 空 reply），导入后设置页不再是空白。
- 空模板回退逻辑不变；更新插件请用面板卡片的「更新」按钮（保留 config 与 data）。

### 1.3.2
- 去掉全部降级：只用 Markdown 发送（`msg_type=2`），失败只记日志，不回退纯文本/富媒体、不重发。
- 旧配置的 `commands` 自动补 `type`，保存时整体替换（不再保留旧条目）。
- 纯净包更新为 `插件/我的世界查询-【v1.3.2】.zip`。

### 1.3.1
- 修复发送失败时重复展示：按钮 Markdown 失败后不再重发无按钮 Markdown，直接回退一条纯文本。
- 补充说明：PC QQ 不支持 Markdown，会把一条消息的图片块和文本块各显示成「暂不支持」，手机 QQ 正常。

### 1.3.0
- 每条指令的**回复内容可编辑**：`config.commands[].reply` 存 Markdown 模板，支持 `{{变量}}`。
- 设置页每行「删除」旁新增 **【编辑】**：左侧 Markdown 源码、右侧实时预览，上方变量标签点击插入，可恢复默认。
- 支持按类型用变量（`status` / `json` / `api` / `menu`），模板不含 `{{image}}` 时跳过素材上传。
- 纯净包更新为 `插件/我的世界查询-【v1.3.0】.zip`。

### 1.2.1
- 设置页新增「接口密钥」输入框，安装后不用改 plugin.json 就能填 key。
- 提供纯净版 zip 导出（`插件/我的世界查询-【v1.2.1】.zip`），可直接在面板导入。

### 1.2.0
- 新增面板设置页 `settings.html`：在「插件 → 编辑 → 设置」里直接编辑每条**指令 + 备注**（按钮文字也可改），保存写入 `plugin.json` 的 `config.commands`。
- 菜单的指令列表与蓝色按钮都改为按 `config.commands` 生成；为空时使用内置默认值。

### 1.1.0
- 菜单改为 Markdown + 蓝色指令按钮（点击把指令填进输入框，`enter=false`）。
- 查询结果改为**一条被动回复**：`@用户 + 引用 + 状态图`，不再发文字摘要、不占主动额度。
- 状态图改用 **QQ 素材库**（`/v2/media-images`）上传后用 `qqbot-media://` 引用，修复公网图片在客户端“加载失败”。
- 接口超时/失败时挂 **【重新查询】** 按钮（`enter=true`），点击自动重发原指令。
- 只响应带 `/` 前缀的指令；不带 `/` 的普通聊天不处理。
- 菜单图标支持配置（默认聚龙世界草方块），同样走素材库上传并缓存。
- 适配接口新增的 `iconFileUrl`、`quota.custom/unlimited` 字段（`-json` 原样透传）。


## 指令

| 指令 | 说明 |
| --- | --- |
| `/MC 服务器地址` | 查询服务器状态：**一条被动回复** = @用户 + 引用原消息 + 随机底图状态图 |
| `/MC 服务器地址 -json` | 以 Markdown ` ```json ` 代码块返回原始 JSON |
| `/MC api` | 发送网站入口 + 图片接口调用帮助（Markdown） |
| `/MC` | 打开指令菜单：草方块图标 + 5 个蓝色指令按钮 |

- 命令名大小写不敏感：`/MC`、`/mc` 等价；地址支持 `host` 或 `host:port`。
- **必须带 `/` 前缀**：`/MC …` 才触发，`MC …` 这类普通聊天一律不响应（全角 `／` 也支持）。
- 端口不写默认 `25565`；基岩服请写端口（如 `/MC play.example.com:19132`）。
- 版式：优先 `msg_type=2` Markdown；发送失败或频道场景自动回退纯文本。

### 菜单按钮

`/MC` 菜单是 Markdown + `keyboard` 自定义按钮（指令按钮 `action.type=2`、`enter=false`）：

| 按钮 | 点击后填入输入框 |
| --- | --- |
| 查询服务器 | `/MC ` |
| JSON 数据 | `/MC -json ` |
| 接口帮助 | `/MC api` |
| 指令菜单 | `/MC` |
| 点我查询 | `/MC ` |

点击后只把指令插入输入框（不自动发送），用户补上服务器地址再发送；按钮为蓝色线框（`style=1`）、所有人可点（`permission.type=2`）。
自定义按钮属于平台“内邀开通”能力；未开通时插件会自动回退为无按钮 Markdown，再失败回退纯文本，不会报错刷屏。

示例：

```
/MC mc.hypixel.net
/MC play.example.com:25565 -json
/MC api
```

## 回复形态（被动回复，不占主动额度）

查询结果只发**一条被动回复**（带 `msg_id`，客户端显示为引用原消息）：

```markdown
<qqbot-at-user id="成员 member_openid" />
![服务器状态图 #760px #270px](qqbot-media://image/v1/xxxx)
```

- `@用户` 走 QQ 文本交互标签 `<qqbot-at-user />`，群聊下只支持 Markdown 消息，`id` 填 `member_openid`。
- 图片先上传到 **QQ 素材库**（`/v2/media-images/prepare → PUT → complete`），Markdown 里用 `qqbot-media://image/v1/...` 引用，不依赖外链。
  > 直接写公网图片地址（如聚龙世界 `/uploads/...png`）在部分客户端会“加载失败”，因为平台下载转存失败；素材库是平台自己的 COS，稳定显示。
- 不用主动消息：全部经由 `ctx.api.reply`（`msg_id` 被动回复），不消耗主动消息额度。
- 失败/超时（接口超时、地址不存在、图片生成失败）时，回复失败原因并挂 **【重新查询】** 按钮（`enter=true`），点击后自动重发刚才那条指令，无需重新输入。
- 素材库单机器人上限 100 张：状态图文件名 `mc-status-*`，发送后异步清理，只保留最近 60 张；菜单图标 `mc-menu-icon-*` 不参与清理，缓存 30 天后重新上传。

## 图片链路

```
query + frames（底图模板，5 分钟缓存）→ 随机 frame → image 生成 PNG
                                ↓
      素材上传 prepare → PUT 二进制 → complete → qqbot-media:// 引用
                                ↓
        Markdown 被动回复：@用户 + 引用 + ![状态图](qqbot-media://...)
                                ↓ 素材上传失败
        富媒体上传（file_data base64）→ msg_type=7（无 @）
                                ↓ 也失败
        失败提示 + 【重新查询】按钮
```

- 底图：先 `POST /api/plugin/mcstatus/frames` 取全部模板（id / 名称 / 预览图），随机挑一个传给 `image` 的 `frame`；frames 不可用时 `frame` 留空，由服务端随机。
- 发图：优先 `file_data`（PNG base64），失败再用 `url: https://www.jlworld.net<imageUrl>` 重试；都失败则只发文字摘要，并在文末注明原因。
- 每次查询会调用 query + image（frames 有缓存），受接口每分钟/每日配额限制。

## 接口字段（2026-11 版）

`/MC 地址 -json` 会把 query 接口原样返回，新增字段自动透传：

- `iconUrl`：服务器图标原始 data URI（超长会截断显示）
- `iconFileUrl`：服务器图标的可直接访问地址（相对站点根，如 `/uploads/mcstatus/icon-xxx.png`），可能为空
- `quota`：`limit` / `dailyLimit` / `remaining`，`custom=true` 表示密钥用了自定义限制

图片接口仍返回 `image`（data URI）、`imageUrl`（相对路径，可直接 GET）、`width` / `height`、`frame`、`ping`。

## 面板设置页（指令 + 回复模板）

插件自带 `settings.html`，在面板「插件 → 编辑 → 设置」里内嵌显示：

- 表格四列：**按钮文字** / **指令** / **备注** / **操作**，可增删行。
- 每行「删除」旁有 **【编辑】**：打开双栏编辑器——左侧 Markdown 源码、右侧实时预览；上方是变量下拉框，选中后显示说明，点「插入」在光标位置插入；「恢复默认」回到内置模板。
- 点弹窗底部「保存设置」→ 写入 `plugin.json` 的 `config.commands`，插件立即按新指令与新模板生效。
- 全部删除或留空时恢复内置默认 4 条指令与默认模板。
- 页面协议：接收 `jlw-settings-init`（config），收到 `jlw-settings-save-request` 时回传 `{ type: 'jlw-settings-save', config }`。

配置结构：

```json
"commands": [
  { "type": "status", "label": "查询服务器", "command": "/MC ", "note": "图片查询，随机底图生成状态图", "reply": "{{user}}\n{{image}}" },
  { "type": "json",   "label": "JSON 数据",  "command": "/MC -json ", "note": "以 JSON 代码块返回原始数据", "reply": "" },
  { "type": "api",    "label": "接口帮助",   "command": "/MC api",    "note": "网站入口与图片接口调用帮助", "reply": "" },
  { "type": "menu",   "label": "指令菜单",   "command": "/MC",        "note": "打开本菜单", "reply": "" }
]
```

- `label`：消息底部蓝色按钮的文字（两列排布，最多 8 条）。
- `command`：点击按钮后填入输入框的指令，必须以 `/` 开头。
- `note`：菜单指令列表里显示的说明。
- `type`：`status` / `json` / `api` / `menu`，决定该条用哪组变量。
- `reply`：该指令的 Markdown 回复模板，`{{变量}}` 替换；留空用内置默认。

### 可用变量

| type | 变量 |
| --- | --- |
| `status` | `user` `image` `imageUrl` `host` `port` `address` `edition` `version` `protocol` `online` `onlineBool` `players` `maxPlayers` `motd` `ping` `frame` `queried` |
| `json` | `json` `ok` `error` `host` `port` `address` `online` `players` `maxPlayers` `version` |
| `api` | `site` `apiBase` `imageEndpoint` `queryEndpoint` `framesEndpoint` `siteImage` |
| `menu` | `icon` `commands` `title` |

- `{{image}}` 是上传素材库后的 Markdown 图片；模板不含它时跳过素材上传。
- 未知变量原样保留；模板要图但素材上传失败时自动回退富媒体图片。
- 渲染后自动去掉首尾空行（`{{icon}}` 为空时不留空洞）。

## 配置（plugin.json → config）

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `apiBase` | `https://www.jlworld.net` | 接口站点 |
| `key` | `mcst_...` | 接口密钥（只放服务端，禁止暴露给网页前端） |
| `frameTtlMs` | `300000` | 底图模板缓存时长（毫秒） |
| `httpTimeoutMs` | `12000` | 单次接口请求超时 |
| `siteUrl` | `https://www.jlworld.net` | `/MC api` 展示的官网地址 |
| `siteImage` | 官网 og:image | `/MC api` 的网站配图，可换任意图片 URL |
| `iconUrl` | 空（不显示图标） | `/MC` 菜单顶部图标：填公网可访问的图片地址；留空则不显示 |
| `iconSize` | `40` | 菜单图标显示尺寸（px，16–120，按 `![我的世界 #40px #40px]` 缩放） |
| `commands` | 4 条内置指令 | 菜单指令与按钮（见上节，面板设置页可编辑） |
| `mediaKeep` | `60` | 状态图素材保留数量，超出后异步清理最旧的 |

换密钥、换站点只改 `config`，不用动 `index.js`。发布/分享前请把 `key` 换成占位值。

## 排错

| 现象 | 处理 |
| --- | --- |
| 回复「接口密钥无效或已失效」 | 检查 `config.key` |
| 回复「查询太频繁」 | 接口限流（默认 60 次/分钟、1200 次/天），稍后再试 |
| 回复「服务器地址不存在或无法解析」 | 检查地址、端口、服务器是否在线；基岩服要带 UDP 端口 |
| 只有文字没有图片 | 看框架日志 `plugin:mcstatus` 里的上传失败码；群里富媒体需要机器人有发图能力 |
| Markdown 不生效 | 频道场景或平台未开通 Markdown，插件已自动回退纯文本 |

## 自测

```bash
# 本地假服务，不消耗线上额度、不需要 QQ 凭证
node test/mcstatus-test.js
```

覆盖：菜单、图片 + 摘要、随机 frame、JSON 代码块、大小写、端口、基岩版、接口帮助、错误回退、上传失败回退、Markdown 失败回退、单聊。

## 目录

- 运行时：`~JlWBoT/plugins/mcstatus/`
- 源码/发布副本：`plugins/mcstatus/`（安装时由框架种子复制；本机已直接放在运行时目录，两处保持一致）
