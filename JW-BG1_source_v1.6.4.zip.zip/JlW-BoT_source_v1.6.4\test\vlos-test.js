'use strict';
/**
 * VloS 2.0 主流程自测（假聚龙账户 API，不联网 / 不发邮件）
 *
 * 运行：node test/vlos-test.js
 */

const assert = require('node:assert');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');
const PLUGIN_DIR = path.join(ROOT, 'plugins', 'VloS');
const TMP = path.join(__dirname, '.tmp-vlos');

const plugin = require(path.join(PLUGIN_DIR, 'index.js'));
const vlosApi = require(path.join(PLUGIN_DIR, 'api.js'));
const PLUGIN_VERSION = require(path.join(PLUGIN_DIR, 'package.json')).version;

/** 用 node:sqlite 造一个假 VSQL 插件 API，测试 SQLite 存储后端 */
function makeFakeVsql() {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(':memory:');
  const conn = {
    exec(sql) {
      db.exec(sql);
      return conn;
    },
    run(sql, ...params) {
      return db.prepare(sql).run(...params);
    },
    get(sql, ...params) {
      return db.prepare(sql).get(...params) || null;
    },
    all(sql, ...params) {
      return db.prepare(sql).all(...params);
    },
    value(sql, ...params) {
      const row = db.prepare(sql).get(...params);
      return row ? Object.values(row)[0] : null;
    },
    tx(fn) {
      db.exec('BEGIN');
      try {
        const r = fn();
        db.exec('COMMIT');
        return r;
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    },
  };
  return {
    db: db,
    vsql: {
      isReady: () => true,
      db: () => conn,
    },
  };
}
const Store = require(path.join(PLUGIN_DIR, 'lib', 'store.js'));
const T = require(path.join(PLUGIN_DIR, 'lib', 'text.js'));
const { normalizeConfig, DEFAULT_CONFIG } = require(path.join(PLUGIN_DIR, 'lib', 'defaults.js'));

let passed = 0;
let failed = 0;
const failures = [];
const checks = [];

function check(name, fn) {
  checks.push({ name, fn });
}
function ok(cond, message) {
  if (!cond) throw new Error(message || '断言失败');
}
function eq(a, b, message) {
  assert.strictEqual(a, b, message);
}

/* ---------------- 假聚龙账户服务器 ---------------- */

function startMock() {
  const state = {
    accounts: new Map(),
    tokens: new Map(),
    regCodes: new Map(),
    qqCodes: new Map(),
    callbacks: new Map(),
    calls: [],
    seq: 0,
  };

  function reset() {
    state.accounts.clear();
    state.tokens.clear();
    state.regCodes.clear();
    state.qqCodes.clear();
    state.callbacks.clear();
    state.calls.length = 0;
    state.seq = 0;
  }

  function newToken() {
    state.seq++;
    return 'tok_' + state.seq + '_' + Math.random().toString(36).slice(2, 8);
  }

  function addAccount({ email, password, name = '测试用户', qq = '', openid = '', wallet = { longjing: 300, xuanyu: 3 }, avatar = '/uploads/avatars/test.jpg' }) {
    const user = {
      id: 'usr_' + String(email).replace(/[^a-z0-9]/gi, '').slice(0, 10),
      email: String(email).toLowerCase(),
      password: String(password || 'secret123'),
      name,
      avatar,
      qq,
      qqBoundAt: qq ? Date.now() : 0,
      openid,
      openidBoundAt: openid ? Date.now() : 0,
      wallet: { longjing: Number(wallet.longjing) || 0, xuanyu: Number(wallet.xuanyu) || 0 },
      createdAt: Date.now(),
    };
    state.accounts.set(user.email, user);
    return user;
  }

  function qqOwner(qq) {
    for (const user of state.accounts.values()) if (String(user.qq) === String(qq)) return user;
    return null;
  }

  function send(res, status, obj) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(obj));
  }

  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => {
      body += c;
    });
    req.on('end', () => {
      let j = {};
      try {
        j = JSON.parse(body || '{}');
      } catch {
        return send(res, 400, { ok: false, error: 'JSON 错误' });
      }
      const action = String(req.url || '').split('?')[0].split('/').pop();
      state.calls.push({ action, body: j });
      const account = state.tokens.get(j.token) || null;

      if (action === 'send-code') {
        const email = String(j.email || '').toLowerCase();
        if (!email) return send(res, 400, { ok: false, error: '邮箱格式错误' });
        if (state.accounts.has(email)) return send(res, 400, { ok: false, error: '此邮箱已被使用' });
        state.regCodes.set(email, '123456');
        return send(res, 200, { ok: true, message: '验证码已发送', cooldown: 60, expiresIn: 10 });
      }

      if (action === 'register') {
        const email = String(j.email || '').toLowerCase();
        if (state.accounts.has(email)) return send(res, 400, { ok: false, error: '此邮箱已被使用' });
        if (state.regCodes.get(email) !== String(j.code)) return send(res, 400, { ok: false, error: '验证码不正确' });
        if (!j.password || String(j.password).length < 6) return send(res, 400, { ok: false, error: '密码过短' });
        if (!j.name || String(j.name).length < 2 || String(j.name).length > 20) return send(res, 400, { ok: false, error: '名称长度不正确' });
        const user = addAccount({ email, password: j.password, name: j.name });
        const token = newToken();
        state.tokens.set(token, user);
        return send(res, 200, { ok: true, message: '注册成功', token, user: publicUser(user) });
      }

      if (action === 'login') {
        const email = String(j.email || '').toLowerCase();
        const user = state.accounts.get(email);
        if (!user || user.password !== String(j.password || '')) return send(res, 400, { ok: false, error: '邮箱或密码不正确' });
        const token = newToken();
        state.tokens.set(token, user);
        return send(res, 200, { ok: true, message: '登录成功', token, user: publicUser(user) });
      }

      if (action === 'me') {
        if (!account) return send(res, 400, { ok: false, error: '登录已过期，请重新登录' });
        return send(res, 200, { ok: true, user: publicUser(account) });
      }

      if (action === 'balance') {
        if (!account) return send(res, 400, { ok: false, error: '登录已过期，请重新登录' });
        return send(res, 200, { ok: true, wallet: { ...account.wallet }, user: publicUser(account) });
      }

      if (action === 'qq-send-code') {
        if (!account) return send(res, 400, { ok: false, error: '登录已过期，请重新登录' });
        if (account.qq) return send(res, 400, { ok: false, error: 'QQ 已绑定，不能修改' });
        const qq = String(j.qq || '');
        if (!/^[1-9]\d{4,11}$/.test(qq)) return send(res, 400, { ok: false, error: 'QQ 号格式不正确' });
        const owner = qqOwner(qq);
        if (owner && owner !== account) return send(res, 400, { ok: false, error: '这个 QQ 已被使用（已绑定其他账号）' });
        state.qqCodes.set(qq, '654321');
        return send(res, 200, { ok: true, message: '验证码已发送', cooldown: 60, expiresIn: 10, qq });
      }

      if (action === 'qq-bind') {
        if (!account) return send(res, 400, { ok: false, error: '登录已过期，请重新登录' });
        if (account.qq) return send(res, 400, { ok: false, error: 'QQ 已绑定，不能修改' });
        const qq = String(j.qq || '');
        const owner = qqOwner(qq);
        if (owner && owner !== account) return send(res, 400, { ok: false, error: '这个 QQ 已被使用（已绑定其他账号）' });
        if (state.qqCodes.get(qq) !== String(j.code)) return send(res, 400, { ok: false, error: '验证码不正确，还可以尝试 4 次' });
        account.qq = qq;
        account.qqBoundAt = Date.now();
        state.qqCodes.delete(qq);
        return send(res, 200, { ok: true, message: 'QQ 绑定成功', user: publicUser(account) });
      }

      if (action === 'key') {
        if (j.key !== 'test-key') return send(res, 400, { ok: false, error: 'Key 无效或已被停用' });
        if (j.action === 'callback-create') {
          if (!j.html) return send(res, 400, { ok: false, error: 'html 不能为空' });
          const id = 'cb_' + Math.random().toString(36).slice(2, 10);
          state.callbacks.set(id, { id, title: j.title || '', html: j.html, status: 'open', payload: null, user: null, expiresMinutes: j.expiresMinutes });
          return send(res, 200, {
            ok: true,
            id,
            url: `https://example.test/assets/jl-callback.html?t=jlcbt_${id}`,
            expiresAt: Date.now() + (Number(j.expiresMinutes) || 60) * 60000,
            status: 'open',
          });
        }
        if (j.action === 'callback-result') {
          const cb = state.callbacks.get(j.id);
          if (!cb) return send(res, 400, { ok: false, error: '回调不存在' });
          return send(res, 200, {
            ok: true,
            callback: {
              id: cb.id,
              title: cb.title,
              status: cb.status,
              submittedAt: cb.submittedAt || 0,
              payload: cb.payload || {},
              user: cb.user || null,
              callback: cb.callback || null,
            },
          });
        }
        const email = String(j.user || '').toLowerCase();
        const user = state.accounts.get(email);
        if (!user) return send(res, 400, { ok: false, error: '账号不存在' });
        if (j.action === 'openid') {
          if (!user.qq) return send(res, 400, { ok: false, error: '该账号还没有绑定 QQ，不能填写 OpenID' });
          if (user.openid) return send(res, 400, { ok: false, error: 'OpenID 已填写，不能修改' });
          const openid = String(j.openid || '');
          if (!/^[\x21-\x7e]{8,128}$/.test(openid)) return send(res, 400, { ok: false, error: 'OpenID 格式不正确' });
          for (const u of state.accounts.values()) {
            if (u.openid && u.openid === openid && u !== user) return send(res, 400, { ok: false, error: '这个 OpenID 已被使用' });
          }
          user.openid = openid;
          user.openidBoundAt = Date.now();
          return send(res, 200, {
            ok: true,
            message: 'OpenID 已保存',
            openid: user.openid,
            openidBoundAt: user.openidBoundAt,
            user: publicUser(user),
          });
        }
        if (j.action === 'currency-add' || j.action === 'currency-sub') {
          const currency = j.currency === 'xuanyu' ? 'xuanyu' : j.currency === 'longjing' ? 'longjing' : '';
          if (!currency) return send(res, 400, { ok: false, error: '货币类型不正确（longjing / xuanyu）' });
          const amount = Number(j.amount);
          if (!Number.isInteger(amount) || amount < 1 || amount > 1000000) return send(res, 400, { ok: false, error: '数量需要是 1–1000000 的整数' });
          if (j.action === 'currency-sub') {
            if (user.wallet[currency] < amount) return send(res, 400, { ok: false, error: `余额不足：当前${currency} ${user.wallet[currency]}` });
            user.wallet[currency] -= amount;
          } else {
            user.wallet[currency] += amount;
          }
          return send(res, 200, {
            ok: true,
            message: '已调整' + currency,
            currency,
            amount,
            wallet: { ...user.wallet },
            user: publicUser(user),
          });
        }
        return send(res, 400, { ok: false, error: '这个 Key 没有权限' });
      }

      return send(res, 404, { ok: false, error: '未知接口' });
    });
  });

  function publicUser(u) {
    return {
      id: u.id,
      email: u.email,
      name: u.name,
      avatar: u.avatar,
      qq: u.qq || '',
      qqBoundAt: u.qqBoundAt || 0,
      openid: u.openid || '',
      openidBoundAt: u.openidBoundAt || 0,
      wallet: { ...u.wallet },
      createdAt: u.createdAt,
    };
  }

  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, state, reset, addAccount, port: server.address().port, baseUrl: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

/* ---------------- 测试脚手架 ---------------- */

let seq = 0;
let mock = null;

function freshDir(label) {
  const dir = path.join(TMP, `${label}-${++seq}`);
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  return dir;
}

function baseConfig(overrides = {}) {
  const cfg = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  cfg.jlAccount.baseUrl = mock.baseUrl;
  cfg.jlAccount.apiPath = '/api/plugin/jl-account';
  cfg.jlAccount.key = 'test-key';
  cfg.jlAccount.timeoutMs = 5000;
  const merge = (a, b) => {
    for (const [k, v] of Object.entries(b)) {
      if (v && typeof v === 'object' && !Array.isArray(v) && a[k] && typeof a[k] === 'object') merge(a[k], v);
      else a[k] = v;
    }
  };
  merge(cfg, overrides);
  return cfg;
}

function parseCommand(text, prefix = '') {
  let body = String(text || '').trim();
  if (prefix) {
    if (!body.startsWith(prefix)) return { name: '', args: [], text: '', matched: false };
    body = body.slice(prefix.length).trim();
  } else if (/^[/／]/.test(body)) {
    body = body.slice(1).trim();
  }
  if (!body) return { name: '', args: [], text: '', matched: true };
  const m = body.match(/^(\S+)(?:\s+([\s\S]*))?$/);
  const name = (m?.[1] || '').slice(0, 32);
  const rest = m?.[2] || '';
  return { name, args: rest ? rest.split(/\s+/).filter(Boolean) : [], text: rest, matched: true };
}

function makeCtx({
  dir,
  config,
  content,
  kind = 'c2c',
  key = 'USER_A',
  union = '',
  name = '测试用户',
  role = 'member',
  appId = '102818267',
  accountId = 'acc-test',
  eventName = '',
  source = 'test',
  raw = null,
  api = null,
  bot = null,
}) {
  const author = {
    id: key,
    member_openid: kind === 'group' ? key : '',
    user_openid: kind === 'c2c' ? key : '',
    union_openid: union,
    username: name,
    avatar: '',
    role,
    bot: false,
  };
  const clean = String(content || '').trim();
  const message = {
    id: 'MSG_' + Math.random().toString(36).slice(2, 8),
    kind,
    content,
    cleanContent: clean,
    command: parseCommand(clean, ''),
    author,
    group_openid: kind === 'group' ? 'GROUP_1' : '',
    user_openid: kind === 'c2c' ? key : '',
    channel_id: '',
    guild_id: '',
    attachments: [],
    mentions: [],
  };
  const evtName = eventName || (kind === 'group' ? 'GROUP_MESSAGE_CREATE' : 'C2C_MESSAGE_CREATE');
  const isMessageEvent = /MESSAGE_CREATE$/.test(evtName);
  const logs = { info: [], warn: [], error: [] };
  const log = {
    info: (m) => logs.info.push(String(m)),
    warn: (m) => logs.warn.push(String(m)),
    error: (m) => logs.error.push(String(m)),
    debug: () => {},
  };
  return {
    event: { source: source, name: evtName, t: evtName, id: 'EVT_' + Math.random().toString(36).slice(2, 8) },
    message: isMessageEvent ? message : null,
    raw: raw || (isMessageEvent ? undefined : {}),
    plugin: { id: 'VloS', dir, config },
    account: { id: accountId, name: '测试账户', appIdMasked: '1028****8267' },
    framework: { version: 'test', dataDir: TMP },
    api: Object.assign({ reply: async () => ({ ok: true }) }, api || {}),
    bot: Object.assign({ info: () => ({ appId, accountId, accountName: '测试账户' }) }, bot || {}),
    log,
    _logs: logs,
  };
}

function mdOf(res) {
  if (!res) return '';
  if (Array.isArray(res.replies) && res.replies[0]?.markdown?.content) return res.replies[0].markdown.content;
  if (typeof res.reply === 'string') return res.reply;
  return '';
}

async function boot({ dir, config }) {
  plugin.__test.reset();
  const ctx = makeCtx({ dir, config, content: '' });
  await plugin.onLoad(ctx);
  const rt = plugin.__test.getRuntime();
  rt.__testLogs = ctx._logs;
  return rt;
}

async function send(rt, content, opts = {}) {
  const ctx = makeCtx({
    dir: rt.dir,
    config: rt.rawConfig,
    content,
    kind: opts.kind || 'c2c',
    key: opts.key || 'USER_A',
    union: opts.union || '',
    name: opts.name || '测试用户',
    role: opts.role === undefined ? 'member' : opts.role,
    accountId: opts.accountId || 'acc-test',
    source: opts.source || 'test',
    api: opts.api || null,
    bot: opts.bot || null,
  });
  const res = await plugin.onEvent(ctx);
  if (ctx._logs.error.length) throw new Error('插件记录错误日志：' + ctx._logs.error.join(' | '));
  return mdOf(res);
}

/** 发送非消息群事件（GROUP_MEMBER_ADD 等），返回 ctx 供断言 */
async function sendEvent(rt, name, raw, opts = {}) {
  const ctx = makeCtx({
    dir: rt.dir,
    config: rt.rawConfig,
    content: '',
    eventName: name,
    raw,
    api: opts.api || null,
    bot: opts.bot || null,
  });
  const res = await plugin.onEvent(ctx);
  if (ctx._logs.error.length) throw new Error('插件记录错误日志：' + ctx._logs.error.join(' | '));
  return { res, ctx };
}

async function run() {
  fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(TMP, { recursive: true });
  mock = await startMock();
  try {
    for (const { name, fn } of checks) {
      try {
        await fn();
        passed++;
        console.log(`  ✓ ${name}`);
      } catch (e) {
        failed++;
        failures.push({ name, error: e });
        console.log(`  ✗ ${name}\n      ${e.message}`);
      }
    }
  } finally {
    await new Promise((resolve) => mock.server.close(resolve));
  }
  console.log(`\n${passed} passed, ${failed} failed, ${checks.length} total`);
  if (failed) {
    console.log('\n失败详情：');
    for (const f of failures) console.log(`- ${f.name}: ${f.error.stack || f.error.message}`);
    process.exitCode = 1;
  }
}

/* ======================= 用例 ======================= */

check('plugin.json：2.6 配置，不再包含 SMTP / 邮件模板', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(PLUGIN_DIR, 'plugin.json'), 'utf8'));
  const pkg = JSON.parse(fs.readFileSync(path.join(PLUGIN_DIR, 'package.json'), 'utf8'));
  eq(manifest.id, 'VloS');
  eq(manifest.version, pkg.version);
  eq(manifest.type, 'js');
  ok(manifest.config.jlAccount, '缺少 jlAccount 配置');
  ok(manifest.config.menu && manifest.config.guard && manifest.config.welcome, '缺少菜单 / 群管 / 进退群配置');
  ok(manifest.config.commands && manifest.config.commands.sign, '缺少指令配置');
  for (const evt of ['GROUP_MEMBER_ADD', 'GROUP_MEMBER_REMOVE', 'GROUP_JOIN_REQUEST', 'GROUP_ADD_ROBOT']) {
    ok(manifest.events.includes(evt), 'manifest.events 缺少 ' + evt);
  }
  ok(!manifest.config.smtp, '不应再有 smtp');
  ok(!manifest.config.mail, '不应再有 mail');
  eq(manifest.config.jlAccount.apiPath, '/api/plugin/jl-account');
  ok(String(manifest.description).includes('聚龙账户'));
});

check('配置纠偏：丢弃旧 SMTP / mail，范围与概率纠偏', () => {
  const cfg = normalizeConfig({
    smtp: { pass: 'old-secret' },
    mail: { html: 'old' },
    jlAccount: { baseUrl: 'www.jlworld.net', key: ' jlkey_x ' },
    sign: { longjingMin: 500, longjingMax: 10, xuanyuChance: 300, xuanyuMin: 9, xuanyuMax: 2 },
  });
  eq(cfg.smtp, undefined);
  eq(cfg.mail, undefined);
  eq(cfg.jlAccount.baseUrl, 'https://www.jlworld.net');
  eq(cfg.jlAccount.key, 'jlkey_x');
  eq(cfg.sign.longjingMin, 10);
  eq(cfg.sign.longjingMax, 500);
  eq(cfg.sign.xuanyuChance, 100);
  eq(cfg.sign.xuanyuMin, 2);
  eq(cfg.sign.xuanyuMax, 9);
});

check('/add 注册：私聊 + 邮箱验证码 + 密码 + 名称', async () => {
  mock.reset();
  const dir = freshDir('register');
  const rt = await boot({ dir, config: baseConfig() });

  let md = await send(rt, '/add user@example.com', { kind: 'group' });
  ok(md.includes('请私聊'), '群聊应要求私聊');
  eq(rt.store.get('USER_A'), null);

  md = await send(rt, '/add user@example.com');
  ok(md.includes('验证码已发送'), '应提示验证码已发送：' + md);
  ok(plugin.__test.getFlows().authFlows.has('USER_A'), '应进入验证码步骤');

  md = await send(rt, '123456');
  ok(md.includes('设置聚龙账户密码'), '应进入密码步骤：' + md);

  md = await send(rt, 'secret123');
  ok(md.includes('设置显示名称'), '应进入名称步骤：' + md);

  md = await send(rt, '小明');
  ok(md.includes('注册成功'), '应注册成功：' + md);
  const user = rt.store.get('USER_A');
  ok(user, '应保存用户');
  eq(user.email, 'user@example.com');
  eq(user.name, '小明');
  eq(user.wallet.longjing, 300);
  eq(user.wallet.xuanyu, 3);
  eq(user.token.startsWith('tok_'), true);
  eq(plugin.__test.getFlows().authFlows.has('USER_A'), false);
  ok(mock.state.accounts.has('user@example.com'), '假聚龙账户应已创建');
});

check('/list：聚龙账户资料 / 钱包 / 未绑定 QQ', async () => {
  mock.reset();
  const dir = freshDir('list');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add list@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '小红');
  const md = await send(rt, '/list');
  ok(md.includes('## 聚龙账户'), '缺聚龙账户标题：' + md);
  ok(md.includes('list@example.com'), '缺邮箱');
  ok(md.includes('**聚龙钱包**：龙晶 300 · 玄玉 3'), '缺聚龙钱包：' + md);
  ok(md.includes('未绑定'), '应提示未绑定 QQ');
  ok(md.includes('![头像 #48px #48px](http://127.0.0.1:'), '头像应转成绝对地址：' + md);
  ok(!md.includes('VloS余额'), '余额为 0 时不应显示 VloS余额 行：' + md);

  rt.store.setPendingWallet('USER_A', { longjing: 12, xuanyu: 3 });
  const withBalance = await send(rt, '/list');
  ok(withBalance.includes('**VloS余额**：龙晶 12 · 玄玉 3'), '有 VloS余额 时应显示正确数值：' + withBalance);
});

check('VloS余额：其他插件跨表写入后 /list 与 API 立刻读到新值', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({ dir: freshDir('pending-cross'), config: baseConfig() });
    await send(rt, '/add cross@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '跨表用户');
    const key = rt.store.get('USER_A').key;
    // 模拟另一个插件直接写 shared 库的 vl_lj / vl_xy（不经过 VloS 缓存）
    db.prepare('UPDATE vlos_users SET vl_lj=?, vl_xy=? WHERE key=?').run(10, 5, key);
    ok(!rt.store.get(key).pendingWallet.longjing, '缓存里应该还是旧值 0（验证确实是跨表写）');
    const md = await send(rt, '/list');
    ok(md.includes('**VloS余额**：龙晶 10 · 玄玉 5'), '跨表写入后 /list 应显示最新 VloS余额：' + md);
    eq(vlosApi.vlosBalance('USER_A').longjing, 10, 'API 应读到跨表写入的龙晶');
    eq(vlosApi.vlosBalance('USER_A').xuanyu, 5, 'API 应读到跨表写入的玄玉');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('VloS余额：addVlosBalance（星火兑换码走的接口）后 /list 立刻显示', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({ dir: freshDir('pending-api'), config: baseConfig() });
    await send(rt, '/add apiadd@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '接口用户');
    const key = rt.store.get('USER_A').key;
    const r = vlosApi.addVlosBalance('USER_A', { longjing: 100 }, { reason: '星火兑换码 261124' });
    eq(r.after.longjing, 100, 'addVlosBalance 应返回加完后的余额');
    eq(vlosApi.vlosBalance('USER_A').longjing, 100, 'vlosBalance 应读到刚加的 100');
    eq(db.prepare('SELECT vl_lj FROM vlos_users WHERE key=?').get(key).vl_lj, 100, '应落库 vl_lj=100');
    const md = await send(rt, '/list');
    ok(md.includes('**VloS余额**：龙晶 100 · 玄玉 0'), '加完余额后 /list 应立刻显示 100：' + md);
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('/list 自定义模板：VloS余额用 {pending_longjing}/{pending_xuanyu}，与签到账本分开', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({
      dir: freshDir('list-vars'),
      config: baseConfig({
        commands: {
          list: {
            reply:
              '## 自定义资料\n> 邮箱：{email}\n> VloS余额：龙晶 {pending_longjing} · 玄玉 {pending_xuanyu}\n> 签到账本：龙晶 {ledger_longjing} · 玄玉 {ledger_xuanyu}',
          },
        },
      }),
    });
    await send(rt, '/add vars@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '变量用户');
    rt.store.setPendingWallet('USER_A', { longjing: 12, xuanyu: 3 });
    rt.store.adjustBalances('USER_A', { longjing: 100, xuanyu: 2 });
    const md = await send(rt, '/list');
    ok(md.includes('VloS余额：龙晶 12 · 玄玉 3'), 'VloS余额 应取 pending 数字变量：' + md);
    ok(md.includes('签到账本：龙晶 100 · 玄玉 2'), '签到账本 应仍取 ledger 变量：' + md);
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('签到：跨表加的 VloS余额 会一并入账，不会被签到覆盖', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({
      dir: freshDir('pending-carry'),
      config: baseConfig({
        sign: { longjingMin: 5, longjingMax: 5, xuanyuChance: 0, wallet: true, arknights: false },
      }),
    });
    await send(rt, '/add carry@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '入账用户');
    const key = rt.store.get('USER_A').key;
    const walletBefore = rt.store.get(key).wallet.longjing;
    db.prepare('UPDATE vlos_users SET vl_lj=? WHERE key=?').run(10, key);
    const md = await send(rt, '/签到');
    ok(md.includes('（本次 5 + VloS余额 10）'), '签到应把跨表余额一起入账：' + md);
    eq(rt.store.get(key).wallet.longjing, walletBefore + 15, '钱包应增加 本次 5 + 余额 10');
    eq(rt.store.get(key).pendingWallet.longjing, 0, '入账后余额应清零');
    eq(db.prepare('SELECT vl_lj FROM vlos_users WHERE key=?').get(key).vl_lj, 0, 'SQLite 里的余额也应清零');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('/bindqq：一条指令直接发注册邮箱验证码并绑定', async () => {
  mock.reset();
  const dir = freshDir('bind');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add bind@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '阿龙');

  let md = await send(rt, '/bindqq 3407556894');
  ok(md.includes('验证码已发送'), '应直接发验证码：' + md);
  ok(md.includes('绑定后无法修改'), '应提示绑定后无法修改：' + md);
  ok(plugin.__test.getFlows().bindFlows.has('USER_A'), '应进入绑定验证码步骤');
  eq(rt.store.get('USER_A').qq, '');

  md = await send(rt, '654321');
  ok(md.includes('QQ 绑定成功'), '应绑定成功：' + md);
  const user = rt.store.get('USER_A');
  eq(user.qq, '3407556894');
  eq(user.qqSource, 'api');
  eq(mock.state.accounts.get('bind@example.com').qq, '3407556894');

  md = await send(rt, '/bindqq 3407556894');
  ok(md.includes('您已绑定该 QQ') || md.includes('已绑定'), '再次绑定应提示已绑定：' + md);
});

check('/bindqq 成功时自动保存 OpenID', async () => {
  mock.reset();
  const dir = freshDir('auto-openid');
  const rt = await boot({ dir, config: baseConfig() });
  const key = 'USER_OPENID_0001';
  await send(rt, '/add autoopenid@example.com', { key });
  await send(rt, '123456', { key });
  await send(rt, 'secret123', { key });
  await send(rt, '自动 OpenID 用户', { key });
  await send(rt, '/bindqq 3407556894', { key });
  let md = await send(rt, '654321', { key });
  ok(md.includes('QQ 绑定成功'), '应绑定成功：' + md);
  ok(md.includes('OpenID：已自动保存'), '应自动保存 OpenID：' + md);
  const user = rt.store.get(key);
  eq(user.openid, key);
  eq(mock.state.accounts.get('autoopenid@example.com').openid, key);
});

check('/bindopenid：已登录 + 已绑 QQ 时直接写入', async () => {
  mock.reset();
  mock.addAccount({ email: 'manual@example.com', password: 'pass1234', name: '手动用户', qq: '3407556894' });
  const dir = freshDir('bindopenid');
  const rt = await boot({ dir, config: baseConfig() });
  const key = 'USER_MANUAL_OPENID_01';
  await send(rt, '/login manual@example.com pass1234', { key });
  const md = await send(rt, '/bindopenid', { key });
  ok(md.includes('OpenID 绑定成功'), '应直接绑定：' + md);
  ok(md.includes(key), '应返回 OpenID 字符串：' + md);
  eq(rt.store.get(key).openid, key);
  eq(mock.state.accounts.get('manual@example.com').openid, key);
});

check('/bindopenid：群聊也能绑定（不再限制私聊）', async () => {
  mock.reset();
  mock.addAccount({ email: 'groupopenid@example.com', password: 'pass1234', name: '群聊用户', qq: '3407556894' });
  const dir = freshDir('bindopenid-group');
  const rt = await boot({ dir, config: baseConfig() });
  const key = 'USER_GROUP_OPENID_01';
  await send(rt, '/login groupopenid@example.com pass1234', { key });
  const md = await send(rt, '/bindopenid', { key, kind: 'group' });
  ok(md.includes('OpenID 绑定成功'), '群聊也应能绑定 OpenID：' + md);
  ok(!md.includes('请私聊'), '不应再要求私聊操作');
  eq(rt.store.get(key).openid, key);
  eq(mock.state.accounts.get('groupopenid@example.com').openid, key);
});

check('/bindopenid：Key 失效时返回字符串供手动填写', async () => {
  mock.reset();
  mock.addAccount({ email: 'fallback@example.com', password: 'pass1234', name: '回退用户', qq: '3407556894' });
  const dir = freshDir('bindopenid-fallback');
  const rt = await boot({ dir, config: baseConfig({ jlAccount: { key: 'bad-key' } }) });
  const key = 'USER_MANUAL_OPENID_02';
  await send(rt, '/login fallback@example.com pass1234', { key });
  const md = await send(rt, '/bindopenid', { key });
  ok(md.includes('你的 OpenID'), '应返回 OpenID 字符串：' + md);
  ok(md.includes(key), '应包含当前会话 OpenID：' + md);
  ok(md.includes('手动填写'), '应提示手动填写：' + md);
  eq(rt.store.get(key).openid, '');
});

check('/bindopenid：未绑定 QQ 时提示先 /bindqq', async () => {
  mock.reset();
  mock.addAccount({ email: 'noqq@example.com', password: 'pass1234', name: '无 QQ 用户' });
  const dir = freshDir('bindopenid-noqq');
  const rt = await boot({ dir, config: baseConfig() });
  const key = 'USER_MANUAL_OPENID_03';
  await send(rt, '/login noqq@example.com pass1234', { key });
  const md = await send(rt, '/bindopenid', { key });
  ok(md.includes('请先绑定 QQ'), '应提示先绑定 QQ：' + md);
});

check('/add 已注册邮箱：提示登录；/login 成功', async () => {
  mock.reset();
  mock.addAccount({ email: 'old@example.com', password: 'oldpass123', name: '老用户' });
  const dir = freshDir('login');
  const rt = await boot({ dir, config: baseConfig() });

  let md = await send(rt, '/add old@example.com');
  ok(md.includes('已注册') && md.includes('/login'), '应提示已注册并给出登录指令：' + md);
  eq(plugin.__test.getFlows().authFlows.has('USER_A'), false);

  md = await send(rt, '/login old@example.com wrongpass');
  ok(md.includes('登录失败'), '错误密码应提示失败：' + md);

  md = await send(rt, '/login old@example.com oldpass123');
  ok(md.includes('登录成功'), '正确密码应登录成功：' + md);
  const user = rt.store.get('USER_A');
  eq(user.email, 'old@example.com');
  eq(user.name, '老用户');
  eq(user.wallet.longjing, 300);
});

check('一个聚龙账户只能绑定一个机器人用户', async () => {
  mock.reset();
  mock.addAccount({ email: 'one@example.com', password: 'pass1234', name: '甲' });
  const dir = freshDir('one-account');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/login one@example.com pass1234', { key: 'USER_A' });
  const md = await send(rt, '/login one@example.com pass1234', { key: 'USER_B' });
  ok(md.includes('已绑定其他用户'), '第二个 openid 应被拒绝：' + md);
  eq(rt.store.get('USER_B'), null);
});

check('token 失效：/list 提示重新登录并清除本地 token', async () => {
  mock.reset();
  const dir = freshDir('token-expired');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add exp@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '过期测试');
  const user = rt.store.get('USER_A');
  mock.state.tokens.delete(user.token);
  const md = await send(rt, '/list');
  ok(md.includes('登录已过期') || md.includes('重新登录'), '应提示登录过期：' + md);
  eq(rt.store.get('USER_A').token, '');
});

check('/签到：配置发奖 Key 时写入聚龙钱包', async () => {
  mock.reset();
  const dir = freshDir('sign-wallet');
  const rt = await boot({
    dir,
    config: baseConfig({
      sign: { longjingMin: 10, longjingMax: 10, xuanyuChance: 100, xuanyuMin: 2, xuanyuMax: 2, wallet: true, arknights: false },
    }),
  });
  await send(rt, '/add sign@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '签到用户');
  const md = await send(rt, '/签到');
  ok(md.includes('## 每日签到'), '缺签到标题：' + md);
  ok(md.includes('**龙晶**：+10'), '应显示龙晶奖励：' + md);
  ok(md.includes('**玄玉**：+2'), '应显示玄玉奖励：' + md);
  ok(!md.includes('聚龙钱包余额'), '正常签到不应显示钱包余额：' + md);
  ok(!md.includes('VloS余额'), '正常签到不应显示VloS余额：' + md);
  const user = rt.store.get('USER_A');
  eq(user.wallet.longjing, 310);
  eq(user.wallet.xuanyu, 5);
  eq(user.balances.longjing, 0, '钱包模式不应写插件账本');
  eq(user.sign.totalDays, 1);

  const again = await send(rt, '/签到');
  ok(again.includes('今日已签到'), '第二次应提示今日已签到');
  ok(!again.includes('聚龙钱包'), '已签到卡片也不应显示钱包余额');
  eq(rt.store.get('USER_A').wallet.longjing, 310);
});

check('指令：自定义回复模板 + 变量', async () => {
  mock.reset();
  const dir = freshDir('cmd-reply');
  const rt = await boot({
    dir,
    config: baseConfig({
      sign: { longjingMin: 10, longjingMax: 10, xuanyuChance: 100, xuanyuMin: 2, xuanyuMax: 2, wallet: true, arknights: false },
      commands: {
        help: { reply: '## 自定义帮助\n{commands}\n> 版本 {version}' },
        menu: { reply: '## 自定义菜单\n{items}' },
        sign: { reply: '## 自定义签到\n{content}\n> 龙晶变量：{longjing}' },
      },
    }),
  });
  const help = await send(rt, '/vlos');
  ok(help.includes('## 自定义帮助'), '帮助应使用自定义模板：' + help);
  ok(help.includes('> 版本 ' + PLUGIN_VERSION), '帮助模板应替换 {version}：' + help);
  ok(/qqbot-cmd-(input|enter)/.test(help), '帮助模板的 {commands} 应保留指令标签：' + help);

  const menu = await send(rt, '/菜单', { kind: 'group' });
  ok(menu.includes('## 自定义菜单'), '菜单应使用自定义模板：' + menu);
  ok(menu.includes('qqbot-cmd-input'), '菜单模板的 {items} 应保留指令标签：' + menu);

  await send(rt, '/add reply@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '模板用户');
  const sign = await send(rt, '/签到');
  ok(sign.includes('## 自定义签到'), '签到应使用自定义模板：' + sign);
  ok(sign.includes('## 每日签到'), '签到模板的 {content} 应带默认回复：' + sign);
  ok(sign.includes('龙晶变量：+10'), '签到模板应替换 {longjing}：' + sign);
  eq(rt.store.get('USER_A').sign.totalDays, 1, '自定义回复不应跳过签到逻辑');
});

check('指令：签到自定义回复的全部变量（poem/龙晶/玄玉/累计/连续）', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('cmd-sign-vars'),
    config: baseConfig({
      sign: { longjingMin: 10, longjingMax: 10, xuanyuChance: 100, xuanyuMin: 2, xuanyuMax: 2, wallet: true, arknights: false },
      commands: {
        sign: {
          reply:
            '## 签到成功!\n> {poem}\n***\n> **签到时间**：{time}\n> **龙晶**：{longjing}\n> **玄玉**：{xuanyu}\n> **累计签到**：{days} 天 · 连续 {streak} 天\n{pending}\n***\n{arknights}\n{note}\n{footer}',
        },
      },
    }),
  });
  await send(rt, '/add vars@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '变量用户');
  const md = await send(rt, '/签到');
  ok(md.includes('## 签到成功!'), '应使用自定义签到模板：' + md);
  ok(/> [^<\n]+——/.test(md), '诗词变量应为非空：' + md);
  ok(md.includes('**龙晶**：+10'), '龙晶变量应为 +10：' + md);
  ok(md.includes('**玄玉**：+2'), '玄玉变量应为 +2：' + md);
  ok(md.includes('**累计签到**：1 天'), '累计签到变量应为 1 天：' + md);
  ok(md.includes('连续 1 天'), '连续签到变量应为 1 天：' + md);
});

check('指令：签到前置提示不被自定义模板替换（避免变量空白）', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('cmd-sign-notice'),
    config: baseConfig({
      sign: { longjingMin: 10, longjingMax: 10, xuanyuChance: 0, oncePerDay: true, wallet: true, arknights: false },
      commands: { sign: { reply: '## 自定义签到\n累计 {days} 天 · 连续 {streak} 天' } },
    }),
  });
  const notBound = await send(rt, '/签到');
  ok(notBound.includes('尚未绑定聚龙账户'), '未绑定时应显示系统提示：' + notBound);
  ok(!notBound.includes('自定义签到'), '未绑定时不应套用签到模板');

  await send(rt, '/add notice@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '提示用户');
  const first = await send(rt, '/签到');
  ok(first.includes('## 自定义签到'), '正常签到时才用自定义模板：' + first);
  ok(first.includes('累计 1 天'), '正常签到的变量应有值：' + first);

  const second = await send(rt, '/签到');
  ok(second.includes('今日已签到'), '重复签到应显示系统提示：' + second);
  ok(!second.includes('自定义签到'), '重复签到不应套用模板（否则变量空白）：' + second);
});

check('指令：自定义回复支持 @ / 图片 / 网址 / 蓝字片段', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('cmd-snippets'),
    config: baseConfig({
      commands: {
        help: {
          reply: '{at_user}\n{at_all}\n{cmd:/签到|签到}\n{img:https://www.jlworld.net/a.png}\n{link:https://www.jlworld.net|聚龙世界}',
        },
      },
    }),
  });
  const out = await send(rt, '/vlos', { kind: 'group' });
  ok(out.includes('<qqbot-at-user id="USER_A" />'), '@发送者应替换成 at-user 标签：' + out);
  ok(out.includes('<qqbot-at-everyone />'), '@全体成员应替换成 at-everyone：' + out);
  ok(out.includes('<qqbot-cmd-input text="%2F%E7%AD%BE%E5%88%B0"'), '蓝字指令标签应生成：' + out);
  ok(out.includes('![图片 #0px #0px](https://www.jlworld.net/a.png)'), '图片应补尺寸：' + out);
  ok(out.includes('[聚龙世界](https://www.jlworld.net)'), '网址应生成链接：' + out);
});

check('指令：自定义回复挂载按钮 + 失败回退纯文本', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('cmd-buttons'),
    config: baseConfig({
      commands: { help: { reply: '## 按钮帮助\n【1,1|签到|/签到|指令】【1,2|官网|https://www.jlworld.net|跳转】【2,1|打卡|/签到|指令|所有人|是】' } },
    }),
  });
  const calls = [];
  let failFirst = false;
  const api = {
    reply: async (m, body) => {
      calls.push(body);
      if (failFirst && calls.length === 1) return { ok: false, code: '40054', message: '按钮不支持' };
      return { ok: true };
    },
  };
  await send(rt, '/vlos', { kind: 'group', source: 'group', api });
  eq(calls.length, 1, '应只发一次');
  const kb = calls[0].keyboard;
  ok(kb && kb.content && kb.content.rows.length === 2, '应生成两行按钮：' + JSON.stringify(kb));
  eq(kb.content.rows[0].buttons.length, 2);
  eq(kb.content.rows[0].buttons[0].render_data.label, '签到');
  eq(kb.content.rows[0].buttons[0].action.type, 2);
  eq(kb.content.rows[0].buttons[0].action.data, '/签到');
  eq(kb.content.rows[0].buttons[1].action.type, 0, '跳转按钮 type=0');
  ok(!String(calls[0].markdown.content).includes('【'), '按钮行不应出现在正文：' + calls[0].markdown.content);
  eq(kb.content.rows[1].buttons[0].action.enter, true, '立即发送按钮应带 enter=true');

  calls.length = 0;
  failFirst = true;
  await send(rt, '/vlos', { kind: 'group', source: 'group', api });
  eq(calls.length, 2, '按钮发送失败应回退纯 Markdown');
  ok(!calls[1].keyboard, '回退消息不应再带按钮');
  ok(String(calls[1].markdown.content).includes('## 按钮帮助'), '回退消息应保留正文');
});

check('/签到：发奖 Key 异常时暂存，恢复后一并入账', async () => {
  mock.reset();
  const dir = freshDir('sign-pending');
  const rt = await boot({
    dir,
    config: baseConfig({
      sign: { longjingMin: 10, longjingMax: 10, xuanyuChance: 100, xuanyuMin: 2, xuanyuMax: 2, wallet: true, arknights: false },
      jlAccount: { key: 'bad-key' },
    }),
  });
  await send(rt, '/add pending@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '暂存用户');

  let md = await send(rt, '/签到');
  ok(md.includes('VloS余额'), 'Key 异常应显示VloS余额：' + md);
  ok(md.includes('**龙晶**：+10（本次，已存入 VloS余额）'), '本次龙晶应标明已暂存：' + md);
  ok(!md.includes('聚龙钱包余额'), '不应显示钱包余额：' + md);
  let user = rt.store.get('USER_A');
  eq(user.wallet.longjing, 300, 'Key 异常时钱包不应变化');
  eq(user.wallet.xuanyu, 3);
  eq(user.pendingWallet.longjing, 10, '龙晶应暂存');
  eq(user.pendingWallet.xuanyu, 2, '玄玉应暂存');

  // Key 恢复 + 跨天
  rt.cfg.jlAccount.key = 'test-key';
  user = rt.store.get('USER_A');
  user.sign.lastDate = T.yesterdayKey();
  user.sign.totalDays = 1;
  rt.store.save();

  md = await send(rt, '/签到');
  ok(md.includes('**龙晶**：+20（本次 10 + VloS余额 10）'), '恢复后应写明本次与暂存：' + md);
  ok(md.includes('**玄玉**：+4（本次 2 + VloS余额 2）'), '玄玉应写明本次与暂存：' + md);
  ok(!md.includes('**VloS余额**：'), '入账后不应再有 VloS余额提示：' + md);
  user = rt.store.get('USER_A');
  eq(user.wallet.longjing, 320);
  eq(user.wallet.xuanyu, 7);
  eq(user.pendingWallet.longjing, 0);
  eq(user.pendingWallet.xuanyu, 0);
});

check('/签到：方舟部分全部用 > 一层引用', async () => {
  mock.reset();
  const dir = freshDir('sign-ark-quote');
  const rt = await boot({
    dir,
    config: baseConfig({
      sign: { longjingMin: 1, longjingMax: 1, xuanyuChance: 0, wallet: false, arknights: true },
    }),
  });
  await send(rt, '/add arkquote@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '方舟用户');
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([
    [
      'Arknights',
      {
        isReady: () => true,
        status: () => ({ loggedIn: true }),
        sign: async () => ({
          accounts: [
            { game: 'arknights', name: '耶拉冈德在上#5653', uid: '416645203', status: 'failed', message: '请求异常', daysSigned: 0 },
            { game: 'endfield', name: '圣聆初雪', uid: '342815565', status: 'failed', message: '请求异常', daysSigned: 0 },
          ],
          errors: [],
        }),
      },
    ],
  ]);
  try {
    const md = await send(rt, '/签到');
    const idx = md.indexOf('> **方舟签到**');
    ok(idx > 0, '缺少方舟签到小节：' + md);
    const sectionText = md.slice(idx).split(/\n\s*\*\*\*\s*\n/)[0];
    const section = sectionText.split('\n').filter((x) => x.trim());
    ok(section.length >= 4, '方舟小节内容不足：' + section.join(' / '));
    for (const line of section) {
      ok(line.startsWith('>'), '方舟小节每行都应以 > 开头：' + line);
    }
    ok(!md.includes('### 方舟签到'), '不应再使用 ### 标题');
    ok(md.includes('> **明日方舟**'), '应包含明日方舟行');
    ok(md.includes('> **终末地**'), '应包含终末地行');
  } finally {
    delete globalThis.__JLWBOT_PLUGIN_APIS__;
  }
});

check('/签到：关闭钱包模式时写入插件账本', async () => {
  mock.reset();
  const dir = freshDir('sign-local');
  const rt = await boot({
    dir,
    config: baseConfig({
      sign: { longjingMin: 7, longjingMax: 7, xuanyuChance: 0, wallet: false, arknights: false },
    }),
  });
  await send(rt, '/add local@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '账本用户');
  const md = await send(rt, '/签到');
  ok(md.includes('**龙晶**：+7'), '应显示账本奖励：' + md);
  ok(!md.includes('签到账本余额'), '签到卡片不应显示账本余额：' + md);
  const user = rt.store.get('USER_A');
  eq(user.balances.longjing, 7);
  eq(user.wallet.longjing, 300, '聚龙钱包不应变化');
});

check('QQ 已被其他聚龙账户使用：提示换 QQ', async () => {
  mock.reset();
  mock.addAccount({ email: 'other@example.com', password: 'pass1234', name: '占用者', qq: '3407556894' });
  const dir = freshDir('qq-taken');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add taken@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '被占用户');
  const md = await send(rt, '/bindqq 3407556894 确认');
  ok(md.includes('这个 QQ 已被使用') || md.includes('已被使用'), '应提示 QQ 被占用：' + md);
});

check('/cancel 取消注册流程', async () => {
  mock.reset();
  const dir = freshDir('cancel');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add cancel@example.com');
  const md = await send(rt, '/cancel');
  ok(md.includes('已取消'), '应取消流程：' + md);
  eq(plugin.__test.getFlows().authFlows.has('USER_A'), false);
});

check('旧版本地用户迁移：qq → legacyQq，本地账本保留', async () => {
  const dir = freshDir('legacy');
  const legacy = {
    version: 1,
    users: {
      OLDKEY: {
        key: 'OLDKEY',
        qq: '3407556894',
        jlworld: 'legacy@example.com',
        name: '老用户',
        balances: { longjing: 82, xuanyu: 2 },
        sign: { totalDays: 1, streak: 1, lastDate: T.dateKey(), history: [] },
        aliases: ['OLDKEY'],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    },
    qqIndex: { 3407556894: 'OLDKEY' },
  };
  fs.writeFileSync(path.join(dir, 'data', 'users.json'), JSON.stringify(legacy, null, 2), 'utf8');
  const rt = await boot({ dir, config: baseConfig() });
  const user = rt.store.get('OLDKEY');
  ok(user, '旧用户应保留');
  eq(user.email, 'legacy@example.com');
  eq(user.qq, '');
  eq(user.legacyQq, '3407556894');
  eq(user.balances.longjing, 82);
  eq(rt.store.getByQQ('3407556894'), null, '旧版 QQ 不应占用聚龙 qq 索引');
  const md = await send(rt, '/list', { key: 'OLDKEY' });
  ok(md.includes('旧版本地绑定') && md.includes('3407556894'), '应提示旧版绑定：' + md);
});

check('对外 API：账户 / 钱包 / 账本 / addWallet', async () => {
  mock.reset();
  const dir = freshDir('api');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add api@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '接口用户');
  ok(vlosApi.isReady());
  const u = vlosApi.getUser('api@example.com');
  ok(u, '按邮箱应能解析');
  eq(u.email, 'api@example.com');
  eq(u.wallet.longjing, 300);
  eq(vlosApi.wallet('USER_A').longjing, 300);
  eq(vlosApi.balance('USER_A').longjing, 0);

  vlosApi.addBalance('USER_A', { longjing: 15 });
  eq(vlosApi.balance('USER_A').longjing, 15);

  // VloS 余额（原暂存余额）：读取 / 增减 / 设置
  eq(vlosApi.vlosBalance('USER_A').longjing, 0);
  const vb1 = vlosApi.addVlosBalance('USER_A', { longjing: 30, xuanyu: 5 }, { reason: 'test' });
  eq(vb1.after.longjing, 30);
  eq(vb1.after.xuanyu, 5);
  eq(vb1.vlosBalance.total, 35);
  eq(vlosApi.vlosBalance('USER_A').total, 35);
  const vb2 = vlosApi.addVlosBalance('USER_A', { longjing: -10 });
  eq(vb2.after.longjing, 20);
  const vb3 = vlosApi.addVlosBalance('USER_A', { longjing: -999 });
  eq(vb3.after.longjing, 0, '扣减不能为负');
  vlosApi.setVlosBalance('USER_A', { xuanyu: 7 });
  eq(vlosApi.vlosBalance('USER_A').xuanyu, 7);
  ok(vlosApi.getUser('USER_A').vlosBalance && vlosApi.getUser('USER_A').vlosBalance.xuanyu === 7, 'getUser 应返回 vlosBalance');

  const added = await vlosApi.addWallet('USER_A', { longjing: 20, xuanyu: 1 }, { reason: 'test' });
  eq(added.wallet.longjing, 320);
  eq(added.wallet.xuanyu, 4);
  eq(vlosApi.wallet('USER_A').longjing, 320);
  eq(mock.state.accounts.get('api@example.com').wallet.longjing, 320);
});

check('存储：VSQL 就绪时写入 SQLite（vlos_users / vlos_aliases / vlos_sign_history）', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({ dir: freshDir('store-sqlite'), config: baseConfig() });
    eq(rt.store.backend, 'sqlite', 'VSQL 就绪时应使用 SQLite 后端');
    await send(rt, '/add sql@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, 'SQL用户');
    const row = db.prepare('SELECT * FROM vlos_users WHERE email_lower=?').get('sql@example.com');
    ok(row && row.name === 'SQL用户', '用户应写入 vlos_users 表：' + JSON.stringify(row));
    ok(row.token, 'token 应写入 users 表');
    ok(
      db.prepare('SELECT COUNT(*) AS n FROM vlos_aliases WHERE user_key=?').get(row.key).n > 0,
      '别名应写入 vlos_aliases',
    );

    rt.store.setPendingWallet(row.key, { longjing: 12, xuanyu: 3 });
    eq(db.prepare('SELECT vl_lj, vl_xy FROM vlos_users WHERE key=?').get(row.key).vl_lj, 12, 'VloS余额应落库');
    eq(vlosApi.vlosBalance(row.key).longjing, 12, 'API 应能读到 SQLite 里的 VloS余额');

    rt.store.recordSign(row.key, { date: '2026-11-23', poem: '测试诗', ark: true, mode: 'wallet' });
    const hist = db.prepare('SELECT * FROM vlos_sign_history WHERE user_key=?').all(row.key);
    eq(hist.length, 1, '签到历史应写入 vlos_sign_history');
    eq(hist[0].ark, 1);
    eq(rt.store.get(row.key).sign.history.length, 1, '读回来应带签到历史');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('存储：SQLite save() 遍历缓存不死循环（签到回写 ark 的元凶）', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({ dir: freshDir('store-save-loop'), config: baseConfig() });
    rt.store.linkAccount({ key: 'SAVE_A', email: 'save-a@example.com', name: 'A' });
    rt.store.linkAccount({ key: 'SAVE_B', email: 'save-b@example.com', name: 'B' });
    rt.store.linkAccount({ key: 'SAVE_C', email: 'save-c@example.com', name: 'C' });
    rt.store.get('SAVE_A');
    rt.store.get('SAVE_B');
    rt.store.get('SAVE_C');
    const backend = rt.store._backend();
    const orderBefore = [...backend._cache.keys()].join(',');
    // 2.9.59 及之前：_saveUser 用 delete+set 重排缓存，save() 边遍历边重排 → 永远遍历不完（整进程卡死）
    const t0 = Date.now();
    rt.store.save();
    ok(Date.now() - t0 < 2000, 'save() 不应卡死');
    eq([...backend._cache.keys()].join(','), orderBefore, 'save() 不应打乱缓存顺序');
    ok(backend.saveUser('SAVE_A') === true, 'saveUser 应能只保存一个用户');
    ok(backend.saveUser('NOT_CACHED') === false, 'saveUser 对未加载用户应返回 false');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('签到：oncePerDay=false + 方舟掉落 + SQLite 时连续签到不卡死', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({
      dir: freshDir('sign-repeat-sqlite'),
      config: baseConfig({
        sign: { longjingMin: 5, longjingMax: 5, xuanyuChance: 0, oncePerDay: false, wallet: true, arknights: true },
      }),
    });
    globalThis.__JLWBOT_PLUGIN_APIS__.set('Arknights', {
      status: () => ({ loggedIn: true }),
      sign: async () => ({
        accounts: [{ game: 'arknights', uid: '416645203', name: '博士', status: 'signed', awards: [], daysSigned: 3 }],
        errors: [],
      }),
    });
    await send(rt, '/add repeat@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '重复签到用户');
    const t0 = Date.now();
    const first = await send(rt, '/签到');
    const second = await send(rt, '/签到');
    ok(Date.now() - t0 < 5000, '连续签到不应卡死（耗时 ' + (Date.now() - t0) + 'ms）');
    ok(first.includes('## 每日签到'), '第一次签到应正常出卡片：' + first);
    ok(second.includes('## 每日签到'), '第二次签到应正常出卡片：' + second);
    ok(second.includes('方舟签到'), '签到卡片应带方舟掉落段：' + second);
    eq(rt.store.get('USER_A').sign.totalDays, 2, '关闭每日一次后应累计两次');
    const hist = db.prepare('SELECT ark FROM vlos_sign_history WHERE user_key=? ORDER BY id').all('USER_A');
    eq(hist.length, 2, 'SQLite 里应有两条签到历史');
    eq(hist[1].ark, 1, '方舟掉落命中时 ark 标记应回写落库');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('签到：关闭每日一次后连续 100 次签到（压力 / SQLite）', async () => {
  mock.reset();
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt = await boot({
      dir: freshDir('sign-stress'),
      config: baseConfig({
        sign: { longjingMin: 1, longjingMax: 1, xuanyuChance: 0, oncePerDay: false, wallet: false, arknights: false },
      }),
    });
    await send(rt, '/add stress@example.com');
    await send(rt, '123456');
    await send(rt, 'secret123');
    await send(rt, '压力用户');
    const t0 = Date.now();
    for (let i = 0; i < 100; i++) {
      const md = await send(rt, '/签到');
      ok(md.includes('## 每日签到'), '第 ' + (i + 1) + ' 次签到应正常出卡片：' + md.slice(0, 80));
    }
    const ms = Date.now() - t0;
    ok(ms < 30000, '100 次签到耗时异常：' + ms + 'ms');
    const user = rt.store.get('USER_A');
    eq(user.sign.totalDays, 100, '累计签到应为 100 天');
    eq(user.sign.history.length, 100, '内存里的历史应为 100 条');
    eq(
      db.prepare('SELECT COUNT(*) AS n FROM vlos_sign_history WHERE user_key=?').get('USER_A').n,
      100,
      'SQLite 里应有 100 条签到历史',
    );
    // 缓存里有一整个用户时，全量 save() 也不能卡死
    rt.store.save();
    console.log('      100 次签到耗时 ' + ms + 'ms · RSS ' + Math.round(process.memoryUsage().rss / 1048576) + 'MB');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('存储：users.json 自动迁移到 SQLite（VSQL 后加载也可切换）', async () => {
  mock.reset();
  const dir = freshDir('store-migrate');
  // 先用 JSON 后端建一个用户
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
  const rt1 = await boot({ dir, config: baseConfig() });
  eq(rt1.store.backend, 'json', '没有 VSQL 时应回退 users.json');
  await send(rt1, '/add json@example.com');
  await send(rt1, '123456');
  await send(rt1, 'secret123');
  await send(rt1, 'JSON用户');
  ok(fs.existsSync(path.join(dir, 'data', 'users.json')), '应写入 users.json');

  // 再挂上 VSQL：同一目录重新加载应自动迁移
  const { db, vsql } = makeFakeVsql();
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt2 = await boot({ dir, config: baseConfig() });
    eq(rt2.store.backend, 'sqlite', 'VSQL 加载后应切到 SQLite');
    const row = db.prepare('SELECT * FROM vlos_users WHERE email_lower=?').get('json@example.com');
    ok(row && row.name === 'JSON用户', 'users.json 应迁移进 vlos_users：' + JSON.stringify(row));
    ok(rt2.store.get(row.key), '迁移后应能按 key 读取');
    ok(!fs.existsSync(path.join(dir, 'data', 'users.json')), '迁移完成后应删除 users.json');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('存储：VSQL 断开期间写入的 users.json 会回填到 SQL 并删除', async () => {
  mock.reset();
  const dir = freshDir('store-merge');
  const usersJson = path.join(dir, 'data', 'users.json');
  const { db, vsql } = makeFakeVsql();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', vsql]]);
  try {
    const rt1 = await boot({ dir, config: baseConfig() });
    await send(rt1, '/add a@example.com');
    await send(rt1, '123456');
    await send(rt1, 'secret123');
    await send(rt1, 'A用户');
    ok(!fs.existsSync(usersJson), '正常 SQL 模式下不应残留 users.json');

    // 模拟 VSQL 停用期间回退 JSON 写入的新用户（文件比上次迁入时间新）
    await new Promise((r) => setTimeout(r, 30));
    const legacy = {
      version: 2,
      users: {
        JSONNEW: {
          key: 'JSONNEW',
          aliases: ['JSONNEW'],
          email: 'new@example.com',
          emailLower: 'new@example.com',
          name: '新用户',
          token: '',
          wallet: { longjing: 5, xuanyu: 1 },
          pendingWallet: { longjing: 2, xuanyu: 0 },
          balances: { longjing: 1, xuanyu: 0 },
          sign: { totalDays: 1, streak: 1, lastDate: '2026-11-23', history: [] },
          createdAt: 1,
          updatedAt: 2,
        },
      },
      qqIndex: {},
      emailIndex: {},
    };
    fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
    fs.writeFileSync(usersJson, JSON.stringify(legacy, null, 2), 'utf8');

    const rt2 = await boot({ dir, config: baseConfig() });
    eq(rt2.store.backend, 'sqlite', 'VSQL 就绪时应用 SQLite 后端');
    const got = db.prepare('SELECT * FROM vlos_users WHERE key=?').get('JSONNEW');
    ok(got, '应回填 JSON 里的新用户：' + JSON.stringify(rt2.store.warnings));
    ok(db.prepare('SELECT * FROM vlos_users WHERE email_lower=?').get('a@example.com'), '原有 SQL 用户不能丢');
    ok(!fs.existsSync(usersJson), '回填完成后应删除 users.json');
  } finally {
    db.close();
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('存储：缺少 VSQL 时提示一次前置缺失', async () => {
  mock.reset();
  const prev = globalThis.__JLWBOT_PLUGIN_APIS__;
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
  try {
    const rt = await boot({ dir: freshDir('store-noprereq'), config: baseConfig() });
    const sent = [];
    const bot = {
      sendGroup: async (g, p) => { sent.push(p); return { ok: true }; },
      sendC2C: async (u, p) => { sent.push(p); return { ok: true }; },
    };
    await send(rt, '/vlos', { kind: 'group', source: 'ws', bot });
    ok(sent.some((p) => JSON.stringify(p).includes('缺少前置插件 VSQL')), '应提示缺少前置 VSQL：' + JSON.stringify(sent));
    const n = sent.length;
    await send(rt, '/vlos', { kind: 'group', source: 'ws', bot });
    eq(sent.length, n, '前置缺失提示只发一次');
  } finally {
    if (prev === undefined) delete globalThis.__JLWBOT_PLUGIN_APIS__;
    else globalThis.__JLWBOT_PLUGIN_APIS__ = prev;
  }
});

check('设置页：聚龙账户 / Key / 钱包开关 / 保存协议', () => {
  const html = fs.readFileSync(path.join(PLUGIN_DIR, 'settings.html'), 'utf8');
  for (const need of ['jlw-settings-save', 'jlw-settings-init', 'baseUrl', 'apiPath', 'key', 'walletMode', 'clearKey', 'bindopenid',
    'data-tab="menu"', 'data-tab="commands"', 'data-tab="guard"', 'data-tab="welcome"', 'data-tab="users"', 'data-tab="review"',
    'menuGroupList', 'menuC2CList', 'menuAutoSend', 'commandList', 'bannedWords', 'wJoinTpl', 'welcomePreview', 'cmd_menu', '![图片说明', '#0px #0px', 'vlos-users-data', 'vlos-callbacks-data', 'vlos-command-defaults-data', '恢复默认', 'cmdDefaultReply', 'cmd-buttons', '添加按钮', 'parseCmdButtons', 'serializeCmdButtons', '立即发送', 'reviewPendingList', 'reviewApprovedList', 'review-reason', 'gaApproveMsg', 'gaRejectMsg', 'menuSync', 'reviewRefresh', 'jlw-settings-refresh', 'cbSnap.groups']) {
    ok(html.includes(need), `设置页缺少 ${need}`);
  }
  ok(!html.includes('smtp'), '设置页不应再有 SMTP');
  ok(!html.includes('contenteditable'), '设置页不应再有邮件编辑器');
  const m = html.match(/<script>([\s\S]*?)<\/script>/);
  ok(m, '找不到内联脚本');
  new vm.Script(m[1], { filename: 'settings.html' });
});

check('插件清单：订阅消息按钮回调（INTERACTION_CREATE）', () => {
  const j = JSON.parse(fs.readFileSync(path.join(PLUGIN_DIR, 'plugin.json'), 'utf8'));
  ok(Array.isArray(j.events) && j.events.includes('INTERACTION_CREATE'), 'plugin.json events 应包含 INTERACTION_CREATE：' + JSON.stringify(j.events));
});

check('设置页：已通过群卡片可查看/修改入群验证', () => {
  const html = fs.readFileSync(path.join(PLUGIN_DIR, 'settings.html'), 'utf8');
  for (const need of [
    "selectField('vOn'",
    "selectField('vMode'",
    "areaField('vQuestion'",
    "textField('vAns' + i",
    "selectField('vCorrect'",
    "textField('vMax'",
    'validateApprovedVerify',
    '启用入群验证时请填写验证问题',
    '答案按钮：',
    "selectField('vExpire'",
    'jlw-settings-review-refresh',
    'jlw-settings-snapshots',
  ]) {
    ok(html.includes(need), `已通过卡片缺少 ${need}`);
  }
  // 保存时必须把 joinVerify 写进本群覆盖，否则审核通过后验证配置会丢
  ok(/joinVerify:\s*\{[\s\S]{0,400}?correctIndex: pickIndex/.test(html), 'collectApproved 应写入 joinVerify');
  ok(html.includes('baseVerify.passText'), 'applyGroupReview 应继承全局验证文案');
});

check('设置页：指令编辑器覆盖全部指令（含群管）', () => {
  const html = fs.readFileSync(path.join(PLUGIN_DIR, 'settings.html'), 'utf8');
  const order = (html.match(/var COMMAND_ORDER = \[([^\]]*)\]/) || [])[1] || '';
  for (const key of Object.keys(DEFAULT_CONFIG.commands)) {
    ok(order.includes(`'${key}'`), `指令编辑器缺少 ${key}（保存设置时会被丢掉）`);
  }
  ok(html.includes('{cmd:/Arknights|明日方舟}'), '设置页缺少自定义蓝色指令示例');
  ok(html.includes('{cmd:指令|显示文字}'), '设置页缺少自定义蓝色指令说明');
});

check('设置页：自定义回复预填默认 + 恢复默认', async () => {
  mock.reset();
  const dir = freshDir('cmd-defaults');
  fs.copyFileSync(path.join(PLUGIN_DIR, 'settings.html'), path.join(dir, 'settings.html'));
  const rt = await boot({ dir, config: baseConfig() });
  plugin.__test.refreshCommandDefaultsSnapshot(rt);
  const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
  const m = html.match(/<script id="vlos-command-defaults-data" type="application\/json">([\s\S]*?)<\/script>/);
  ok(m, '找不到默认回复快照 JSON');
  const parsed = JSON.parse(m[1].replace(/<!--[\s\S]*?-->/g, ''));
  ok(parsed.replies.sign.includes('## 每日签到'), '签到默认回复应含标题');
  ok(parsed.replies.sign.includes('{poem}'), '签到默认回复应保留 {poem} 变量');
  ok(parsed.replies.list.includes('{wallet_longjing}'), '资料默认回复应保留钱包变量');
  ok(parsed.replies.add.includes('## 注册聚龙账户'), '注册默认回复应是真实源码而不是 {content}');
  ok(parsed.replies.help.includes('## VloS 指令'), '帮助标题应可直接编辑，而不是 {title}');
  ok(!parsed.replies.help.includes('{title}'), '帮助默认回复不应再用 {title} 隐藏标题');
  ok(parsed.replies.menu.includes('## 菜单'), '菜单标题应可直接编辑');
  ok(html.includes('} — '), '变量下拉应把说明接在变量名后面');
  ok(parsed.replies.add.includes('{cmd_add}'), '注册默认回复应带指令标签变量');
  ok(!parsed.replies.add.includes('{content}'), '注册默认回复不应再出现 {content}');
  for (const key of Object.keys(DEFAULT_CONFIG.commands)) {
    ok(typeof parsed.replies[key] === 'string' && parsed.replies[key].length, `缺少 ${key} 的默认回复`);
    ok(!parsed.replies[key].includes('{content}'), `${key} 的默认回复不应只有 {content}`);
  }
  ok(html.includes('cmd-var-select'), '变量应改用下拉列表');
  ok(html.includes('cmdVarDoc'), '变量应有说明文案');
  ok(html.includes('当前内容 = 内置默认回复'), '预览应提示当前内容就是默认回复');
});

check('菜单：/菜单 按群聊 / 私聊返回不同配置', async () => {
  mock.reset();
  const dir = freshDir('menu-cmd');
  const rt = await boot({ dir, config: baseConfig() });
  const group = await send(rt, '/菜单', { kind: 'group' });
  ok(group.includes('群聊通用指令'), '群菜单应标明群聊：' + group);
  ok(group.includes('qqbot-cmd-input'), '群菜单应使用可点击的指令标签：' + group);
  ok(group.includes('show="%E7%AD%BE%E5%88%B0"'), '群菜单应显示「签到」标签：' + group);
  eq((group.match(/qqbot-cmd-input/g) || []).length, 4, '群菜单应有 4 个指令标签');
  const c2c = await send(rt, '/菜单', { kind: 'c2c' });
  ok(c2c.includes('私聊通用指令'), '私聊菜单应标明私聊：' + c2c);
  ok(c2c.includes('qqbot-cmd-enter'), '私聊默认点击直接发送：' + c2c);
  ok(!c2c.includes('qqbot-cmd-input'), '私聊 autoSend 时不应再用 cmd-input：' + c2c);
  rt.cfg.menu.autoSend = false;
  const c2c2 = await send(rt, '/菜单', { kind: 'c2c' });
  ok(c2c2.includes('qqbot-cmd-input'), '关闭 autoSend 后私聊应改为填入输入框：' + c2c2);
  rt.cfg.menu.group.enabled = false;
  const off = await send(rt, '/菜单', { kind: 'group' });
  ok(off.includes('还没配置'), '关闭群菜单应提示未配置：' + off);
});

check('配置纠偏：菜单上限 / 违禁词去重 / 欢迎模板兜底', () => {
  const cfg = normalizeConfig({
    menu: {
      group: { items: Array.from({ length: 25 }, (_, i) => ({ name: '指令' + i, desc: 'd'.repeat(40), command: '/c' + i })) },
      c2c: { items: Array.from({ length: 12 }, (_, i) => ({ name: '一二三四五六七八九十十一', command: '/n' + i })) },
    },
    guard: { bannedWords: '广告\n广告，加群\n', action: 'bad', muteSeconds: 5, join: { mode: 'x' } },
    welcome: { enabled: true, memberJoin: { template: '' }, memberLeave: { template: '   ' } },
  });
  eq(cfg.menu.group.items.length, 20);
  eq(cfg.menu.group.items[0].desc.length, 30);
  eq(cfg.menu.c2c.items.length, 10);
  eq(cfg.menu.c2c.items[0].name.length, 10);
  eq(cfg.guard.bannedWords.length, 2);
  eq(cfg.guard.action, 'recall');
  eq(cfg.guard.muteSeconds, 60);
  eq(cfg.guard.join.mode, 'manual');
  ok(cfg.welcome.memberJoin.template.length > 0, '空模板应回填默认');
  ok(cfg.welcome.memberLeave.template.length > 0, '空模板应回填默认');
});

check('群管：违禁词撤回并禁言，命中后不再走指令', async () => {
  mock.reset();
  const dir = freshDir('guard');
  const rt = await boot({
    dir,
    config: baseConfig({ guard: { enabled: true, bannedWords: ['广告', '加群'], action: 'recall_mute', muteSeconds: 600 } }),
  });
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      return { ok: true, data: {} };
    },
  };
  const md = await send(rt, '/签到 广告', { kind: 'group', api });
  eq(md, '', '命中违禁词不应回复');
  eq(calls.length, 2);
  eq(calls[0].key, 'recall_group_message');
  ok(String(calls[0].opts.params.message_id).startsWith('MSG_'), '应撤回原消息');
  eq(calls[1].key, 'restrict_chat_set');
  eq(calls[1].opts.body.members[0].member_openid, 'USER_A');

  calls.length = 0;
  await send(rt, '普通聊天', { kind: 'group', api });
  eq(calls.length, 0, '普通消息不应触发');
});

check('群管：撤回失败要写日志，且仍继续禁言', async () => {
  const logs = [];
  const calls = [];
  const r = {
    cfg: { guard: { enabled: true, bannedWords: ['广告'], action: 'recall_mute', muteSeconds: 180 }, groups: {} },
    log: { info: (m) => logs.push('I ' + m), warn: (m) => logs.push('W ' + m) },
  };
  const ctx = {
    api: {
      call: async (key, opts) => {
        calls.push({ key, opts });
        if (key === 'recall_group_message') return { ok: false, code: '40054005', message: '消息已过期' };
        return { ok: true, data: {} };
      },
    },
  };
  const m = { id: 'MSG_EXPIRED', group_openid: 'GROUP_X', author: { member_openid: 'MEMBER_X' } };
  const handled = await plugin.__test.guardGroupMessage(ctx, r, m, '这是广告');
  eq(handled, true, '命中违禁词应返回已处理');
  eq(calls[0].key, 'recall_group_message');
  eq(calls[1].key, 'restrict_chat_set');
  ok(logs.some((x) => x.includes('撤回失败') && x.includes('40054005')), '撤回失败必须写日志：' + logs.join(' | '));
  ok(logs.some((x) => x.includes('已禁言 180 秒')), '撤回失败也应继续禁言：' + logs.join(' | '));
});

check('进退群：退群 event_id 失败会转主动消息', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('welcome-active'),
    config: baseConfig({ welcome: { enabled: true, memberLeave: { enabled: true, template: '{member} 离开了 {group}' } } }),
  });
  const sent = [];
  const bot = {
    sendGroup: async (g, p) => {
      sent.push({ g, p, hasEvent: !!p.event_id });
      if (sent.length === 1) return { ok: false, code: '40034025', message: 'event_id 无效' };
      return { ok: true };
    },
  };
  const api = { call: async () => ({ ok: true, data: { group_name: '测试群' } }) };
  await sendEvent(rt, 'GROUP_MEMBER_REMOVE', { group_openid: 'G1', member_openid: 'M_LEAVE' }, { api, bot });
  eq(sent.length, 2, 'event_id 失败后应转主动消息');
  ok(sent[0].hasEvent, '第一条走 event_id');
  ok(!sent[1].hasEvent, '第二条为主动消息，不带 event_id');
});

check('进退群：本群有设置时用本群（全局总开关关也不影响）', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('welcome-override'),
    config: baseConfig({
      welcome: {
        enabled: false,
        memberJoin: { enabled: false, template: '全局欢迎 {member}' },
        memberLeave: { enabled: false, template: '全局退群 {member}' },
      },
      groups: {
        GROUP_1: {
          reviewStatus: 'approved',
          welcome: { memberJoin: { enabled: true, template: '本群欢迎 {member}' }, memberLeave: { enabled: false, template: '' } },
        },
      },
    }),
  });
  const sent = [];
  const bot = { sendGroup: async (g, p) => { sent.push(p); return { ok: true }; } };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M1' }, { api, bot });
  eq(sent.length, 1, '本群开启进群欢迎应发送（全局总开关关也生效）');
  ok(sent[0].markdown.content.includes('本群欢迎'), '本群有设置时应走本群模板：' + sent[0].markdown.content);
});

check('入群验证：答案按钮回调判定答对/答错/超次踢出（不依赖群全量消息）', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: {
          enabled: true,
          mode: 'custom',
          question: '1 + 1 = ?',
          answers: ['2', '二'],
          correctIndex: 0,
          maxAttempts: 3,
          passText: 'A 通过',
          failText: 'B 错误',
          kickText: 'K 踢出',
        },
      },
    }),
  });
  const sent = [];
  const replies = [];
  const seq = [];
  const bot = {
    sendGroup: async (g, p) => { sent.push(p); return { ok: true }; },
    replyEvent: async (evt, body) => { replies.push(body); seq.push('reply'); return { ok: true }; },
  };
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      seq.push(key === 'batch_remove_members' ? 'kick' : key);
      return { ok: true, data: {} };
    },
  };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_VERIFY' }, { api, bot });
  ok(plugin.__test.joinVerifyPending.size >= 1, 'ADD 后应有待验证记录：' + plugin.__test.joinVerifyPending.size);
  const pendingEntry = plugin.__test.joinVerifyPending.get('GROUP_1:M_VERIFY');
  const ttl = pendingEntry.expiresAt - Date.now();
  ok(ttl > 4 * 60000 && ttl <= 5 * 60000 + 5000, '验证默认限时应为 5 分钟：' + Math.round(ttl / 1000) + 's');
  ok(sent[0].markdown.content.includes('1 + 1 = ?'), '欢迎语后应带问题：' + sent[0].markdown.content);
  ok(sent[0].markdown.content.includes('## 入群验证'), '问题前应有「## 入群验证」标题：' + sent[0].markdown.content);
  ok(sent[0].markdown.content.includes('> 限时 5 分钟'), '标题下应标注限时：' + sent[0].markdown.content);
  ok(sent[0].markdown.content.includes('***'), '问题前应有 *** 分隔');

  // 答案按钮：回调按钮（type=1）+ 只允许这名新成员（permission.type=0 + specify_user_ids）
  const kb = sent[0].keyboard;
  ok(kb && kb.content && kb.content.rows[0].buttons.length === 2, '应挂两个答案按钮：' + JSON.stringify(kb));
  const btn = kb.content.rows[0].buttons[0];
  eq(btn.action.type, 1, '答案按钮应是回调按钮');
  eq(btn.action.permission.type, 0, '答案按钮应只允许指定用户');
  eq(JSON.stringify(btn.action.permission.specify_user_ids), JSON.stringify(['M_VERIFY']), '应限制为进群的新成员');
  eq(btn.action.data, 'jv:0', '按钮 data 应带答案序号');
  eq(btn.render_data.label, '2');

  const click = async (member, index) => {
    const ev = await sendEvent(
      rt,
      'INTERACTION_CREATE',
      {
        id: 'INT_' + index + '_' + Math.random().toString(36).slice(2, 6),
        type: 11,
        scene: 'group',
        group_openid: 'GROUP_1',
        group_member_openid: member,
        data: { type: 11, resolved: { button_data: 'jv:' + index, button_id: 'jv-' + index } },
      },
      { api, bot },
    );
    return ev;
  };

  // 点错答案（第 2 个）算错，回复里要重新挂一组按钮（旧消息按钮点过就灰了）
  await click('M_VERIFY', 1);
  ok(String(replies.at(-1).markdown.content).includes('B 错误'), '点错答案应回错误文案：' + JSON.stringify(replies.at(-1)));
  const retryKb = replies.at(-1).keyboard;
  ok(retryKb && retryKb.content.rows[0].buttons.length === 2, '答错后应重新挂答案按钮：' + JSON.stringify(retryKb));
  eq(retryKb.content.rows[0].buttons[0].action.data, 'jv:0', '重挂按钮 data 应保持答案序号');
  eq(JSON.stringify(retryKb.content.rows[0].buttons[0].action.permission.specify_user_ids), JSON.stringify(['M_VERIFY']), '重挂按钮仍只限本人');
  ok(calls.some((c) => c.key === 'interaction_ack'), '应回应互动事件（不然客户端一直 loading）');

  // 再点错一次（清掉 1.5 秒去重，模拟过一会再点），仍然能继续
  plugin.__test.joinVerifyClicks.clear();
  await click('M_VERIFY', 1);
  ok(String(replies.at(-1).markdown.content).includes('B 错误'), '第二次点错仍应回错误文案：' + JSON.stringify(replies.at(-1)));

  // 同一个人 1.5 秒内连点同一个按钮只算一次（QQ 偶发重复投递）
  const beforeDedupe = plugin.__test.joinVerifyPending.get('GROUP_1:M_VERIFY').attempts;
  await click('M_VERIFY', 1);
  const afterDedupe = plugin.__test.joinVerifyPending.get('GROUP_1:M_VERIFY').attempts;
  eq(afterDedupe, beforeDedupe, '1.5 秒内重复点同一按钮不应再加答错次数');

  // 点对答案（第 1 个）通过
  plugin.__test.joinVerifyClicks.clear();
  await click('M_VERIFY', 0);
  ok(String(replies.at(-1).markdown.content).includes('A 通过'), '点对答案应通过：' + JSON.stringify(replies.at(-1)));
  eq(plugin.__test.joinVerifyPending.size, 0, '通过后应清掉待验证记录');

  // 组外成员点同一个按钮（不是待验证的人）不应被判对/错
  await click('M_OTHER', 0);
  ok(String(replies.at(-1).markdown.content).includes('已经完成或过期'), '非本人点击应提示已完成/过期：' + JSON.stringify(replies.at(-1)));

  // 再来一次，连续点错（maxAttempts=3，第 3 次就踢）-> 踢人
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_KICK' }, { api, bot });
  for (let i = 0; i < 3; i++) {
    plugin.__test.joinVerifyClicks.clear();
    await click('M_KICK', 1);
  }
  ok(String(replies.at(-1).markdown.content).includes('K 踢出'), '第 3 次答错就应回踢出文案：' + JSON.stringify(replies.at(-1)));
  ok(calls.some((c) => c.key === 'batch_remove_members' && c.opts.body.member_openids[0] === 'M_KICK'), '应调用踢人接口');
  const kickAt = seq.indexOf('kick');
  ok(kickAt > 0 && seq.slice(0, kickAt).includes('reply'), '应先把「次数过多」提示发出去再移出（否则用户看不到）：' + JSON.stringify(seq));
});

check('入群验证：第 N 次答错就踢人，踢人失败要把原因回到群里', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-kickfail'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '3'], correctIndex: 0, maxAttempts: 1 },
      },
    }),
  });
  const replies = [];
  const seq = [];
  const bot = {
    sendGroup: async () => ({ ok: true }),
    replyEvent: async (evt, body) => { replies.push(body); seq.push('reply'); return { ok: true }; },
  };
  const calls = [];
  const api = {
    call: async (key, args) => {
      calls.push({ key, args });
      seq.push(key === 'batch_remove_members' ? 'kick' : key);
      if (key === 'batch_remove_members') return { ok: false, code: '40103012', message: '操作失败, 群主已经关闭操作权限' };
      return { ok: true, data: {} };
    },
  };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_KICKFAIL' }, { api, bot });
  // maxAttempts=1：第一次点错就踢，且踢失败要显示原因
  await sendEvent(
    rt,
    'INTERACTION_CREATE',
    { id: 'INT_KF', type: 11, scene: 'group', group_openid: 'GROUP_1', group_member_openid: 'M_KICKFAIL', data: { type: 11, resolved: { button_data: 'jv:1' } } },
    { api, bot },
  );
  ok(calls.some((c) => c.key === 'batch_remove_members'), '第 1 次答错就应调踢人接口（不再是第 N+1 次）');
  ok(String(replies[0].markdown.content).includes('验证失败次数过多'), '先发「次数过多」提示：' + JSON.stringify(replies[0]));
  const md = String(replies.at(-1).markdown.content);
  ok(md.includes('自动移出失败'), '踢人失败要再补一条原因：' + md);
  ok(md.includes('群主关闭'), '提示应指出群主关闭了操作权限：' + md);
  ok(seq.indexOf('kick') > seq.indexOf('reply'), '移出应发生在提示发出之后：' + JSON.stringify(seq));
  ok(!plugin.__test.joinVerifyPending.has('GROUP_1:M_KICKFAIL'), '踢人后应清掉待验证记录');
});

check('入群验证：限时到了先提示、等 3 秒再移出', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-timeout'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '3'], correctIndex: 0, maxAttempts: 3, expiresMinutes: 5 },
      },
    }),
  });
  const sent = [];
  const seq = [];
  const bot = {
    sendGroup: async (g, p) => { sent.push(p); seq.push('prompt'); return { ok: true }; },
  };
  const calls = [];
  const api = {
    call: async (key, args) => {
      calls.push({ key, args });
      seq.push(key === 'batch_remove_members' ? 'kick' : key);
      return { ok: true, data: {} };
    },
  };
  const ev = await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_TO' }, { api, bot });
  const entry = plugin.__test.joinVerifyPending.get('GROUP_1:M_TO');
  ok(entry, '应有待验证记录');
  entry.expiresAt = Date.now() - 1; // 模拟限时已到
  await plugin.__test.handleVerifyTimeout(ev.ctx, rt, 'GROUP_1', 'M_TO', entry);
  const promptIdx = sent.findIndex((p) => String(p.markdown && p.markdown.content).includes('验证超时'));
  ok(promptIdx >= 0, '超时应先发提示：' + JSON.stringify(sent.map((p) => p.markdown && p.markdown.content)));
  ok(calls.some((c) => c.key === 'batch_remove_members' && c.args.body.member_openids[0] === 'M_TO'), '超时应移出成员');
  ok(seq.indexOf('prompt') < seq.indexOf('kick'), '应先提示再移出：' + JSON.stringify(seq));
  ok(!plugin.__test.joinVerifyPending.has('GROUP_1:M_TO'), '超时后应清掉待验证记录');
});

check('入群验证：限时 1–10 分钟（默认 5），群管页可选、审核写入', async () => {
  mock.reset();
  // 群管页有下拉，1–10 都在
  const defaults = baseConfig();
  const html = plugin.__test.buildGroupAdminHtml({
    name: '测试群',
    group: 'G_TEST',
    welcome: defaults.welcome,
    guard: defaults.guard,
    custom: false,
    cmdVars: {},
    defaults: { join: defaults.welcome.memberJoin.template, leave: defaults.welcome.memberLeave.template },
  });
  ok(html.includes('name="vVerifyExpire"'), '群管页应有验证限时下拉');
  ok(/name="vVerifyExpire"[\s\S]{0,600}?value="5" selected/.test(html), '验证限时默认选中 5 分钟');
  for (let i = 1; i <= 10; i++) ok(html.includes(`>${i} 分钟<`), `群管页缺少 ${i} 分钟选项`);

  // 审核通过写入 expiresMinutes
  const rt = await boot({ dir: freshDir('join-verify-expire'), config: baseConfig() });
  plugin.__test.applyReviewPayload(rt, {
    group: 'G_EXPIRE',
    groupName: '限时群',
    payload: {
      wJoinEnabled: '1',
      wJoinTpl: '欢迎 {member}',
      vVerifyEnabled: '1',
      vVerifyMode: 'custom',
      vVerifyQuestion: '1+1=?',
      vVerifyAnswer1: '2',
      vVerifyAnswer2: '3',
      vVerifyCorrect: '1',
      vVerifyExpire: '8',
    },
  });
  eq(rt.cfg.groups.G_EXPIRE.welcome.joinVerify.expiresMinutes, 8, '审核通过应写入 8 分钟');
  eq(rt.cfg.groups.G_EXPIRE.welcome.joinVerify.maxAttempts, 3, '未填次数时默认 3');

  // 运行时按配置的限时创建待验证记录
  const rt2 = await boot({
    dir: freshDir('join-verify-expire-run'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '3'], correctIndex: 0, expiresMinutes: 8 },
      },
    }),
  });
  const bot = { sendGroup: async () => ({ ok: true }) };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt2, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_EXP' }, { api, bot });
  const entry = plugin.__test.joinVerifyPending.get('GROUP_1:M_EXP');
  ok(entry, '应有待验证记录');
  const ttl = entry.expiresAt - Date.now();
  ok(ttl > 7 * 60000 && ttl <= 8 * 60000 + 5000, '应按配置的 8 分钟限时：' + Math.round(ttl / 1000) + 's');
});

check('入群验证：按钮被 QQ 拒绝时自动改文字作答', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-nokb'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '二'], correctIndex: 0, maxAttempts: 3 },
      },
    }),
  });
  const sent = [];
  const bot = {
    sendGroup: async (g, p) => {
      if (p.keyboard) return { ok: false, code: '305007', message: '键盘样式参数错误' };
      sent.push(p);
      return { ok: true };
    },
  };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_TEXT' }, { api, bot });
  ok(sent.length >= 2, '按钮被拒后应重发不带按钮的欢迎语 + 蓝字答案：' + sent.length);
  ok(!sent.some((p) => p.keyboard), '重发的消息不应再带按钮');
  const fallback = String(sent[1].markdown.content);
  ok(fallback.includes('qqbot-cmd-input'), '兜底应有可点击蓝字：' + fallback);
  ok(fallback.includes('%2F%E5%85%A5%E7%BE%A4%E9%AA%8C%E8%AF%81'), '蓝字应填入 /入群验证 指令：' + fallback);
  const entry = plugin.__test.joinVerifyPending.get('GROUP_1:M_TEXT');
  ok(entry && entry.allowText === true, '按钮不可用时该成员应允许文字作答：' + JSON.stringify(entry));
  // 点蓝字 = 发送 `/入群验证 2`
  const md = await send(rt, '/入群验证 2', { kind: 'group', key: 'M_TEXT' });
  ok(md === '' || !md.includes('错误'), '蓝字指令答对应通过（回复为空表示已通过）');

  // 没有 allowText 的人发普通消息不应被拦
  const rt2 = await boot({
    dir: freshDir('join-verify-noText'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '二'], correctIndex: 0, maxAttempts: 3 },
      },
    }),
  });
  const bot2 = { sendGroup: async () => ({ ok: true }) };
  await sendEvent(rt2, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_QUIET' }, { api, bot: bot2 });
  const md2 = await send(rt2, '随便聊聊', { kind: 'group', key: 'M_QUIET' });
  eq(md2, '', '没有按钮回退时普通聊天不应触发验证');
});

check('入群验证：明日方舟校验走回调按钮 + isLoggedIn', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-ark'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'arknights', maxAttempts: 3, expiresMinutes: 5 },
      },
    }),
  });
  const sent = [];
  const replies = [];
  const bot = {
    sendGroup: async (g, p) => { sent.push(p); return { ok: true }; },
    replyEvent: async (evt, body) => { replies.push(body); return { ok: true }; },
  };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_ARK' }, { api, bot });
  ok(sent[0].markdown.content.includes('请私聊机器人授权鹰角网络账户'), '应发授权提示：' + sent[0].markdown.content);
  ok(sent[0].markdown.content.includes('> 限时 5 分钟'), '应标出限时：' + sent[0].markdown.content);
  const kb = sent[0].keyboard;
  ok(kb && kb.content.rows[0].buttons.length === 1, '应挂一个「开始校验」按钮：' + JSON.stringify(kb));
  const btn = kb.content.rows[0].buttons[0];
  eq(btn.action.type, 1, '开始校验应是回调按钮');
  eq(btn.action.data, 'jv:ark', '按钮 data 应为 jv:ark');
  eq(JSON.stringify(btn.action.permission.specify_user_ids), JSON.stringify(['M_ARK']), '按钮只限本人');

  let logged = false;
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['Arknights', { isLoggedIn: () => logged }]]);
  const click = async () => {
    plugin.__test.joinVerifyClicks.clear();
    await sendEvent(
      rt,
      'INTERACTION_CREATE',
      { id: 'INT_ARK_' + Math.random(), type: 11, scene: 'group', group_openid: 'GROUP_1', group_member_openid: 'M_ARK', data: { type: 11, resolved: { button_data: 'jv:ark' } } },
      { api, bot },
    );
  };
  await click();
  ok(String(replies.at(-1).markdown.content).includes('校验未通过'), '未登录应校验失败：' + JSON.stringify(replies.at(-1)));
  ok(replies.at(-1).keyboard && JSON.stringify(replies.at(-1).keyboard).includes('开始校验'), '失败后应重新挂「开始校验」按钮：' + JSON.stringify(replies.at(-1)));

  logged = true;
  await click();
  ok(String(replies.at(-1).markdown.content).includes('验证通过，博士！'), '登录后应校验通过：' + JSON.stringify(replies.at(-1)));
  eq(plugin.__test.joinVerifyPending.size, 0, '通过后应清掉待验证记录');
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
});

check('入群验证：入群欢迎关闭时不生效', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-off'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: false, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '1+1', answers: ['2'], maxAttempts: 3 },
      },
    }),
  });
  const bot = { sendGroup: async () => ({ ok: true }) };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_OFF' }, { api, bot });
  const md = await send(rt, '2', { kind: 'group', key: 'M_OFF' });
  eq(md, '', '进群开关关闭时不应进入验证流程');
});

check('入群验证：配置不完整（没问题/答案不足）时自动跳过，避免误踢', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('join-verify-broken'),
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '欢迎 {member}' },
        joinVerify: { enabled: true, mode: 'custom', question: '', answers: ['2'], maxAttempts: 1 },
      },
    }),
  });
  const sent = [];
  const bot = { sendGroup: async (g, p) => { sent.push(p); return { ok: true }; } };
  const api = { call: async () => ({ ok: true, data: {} }) };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'GROUP_1', member_openid: 'M_BROKEN' }, { api, bot });
  ok(!String(sent[0].markdown.content).includes('***'), '配置不完整不应追加验证题：' + sent[0].markdown.content);
  eq(plugin.__test.joinVerifyPending.size, 0, '不应创建待验证记录');
  const md = await send(rt, '2', { kind: 'group', key: 'M_BROKEN' });
  eq(md, '', '配置不完整时回答不应进入验证流程');
});

check('进退群：成员加入 / 退出 / 机器人进群发欢迎语', async () => {
  mock.reset();
  const dir = freshDir('welcome');
  const rt = await boot({
    dir,
    config: baseConfig({
      welcome: {
        enabled: true,
        memberJoin: { enabled: true, template: '{at_member} {cmd_menu} 欢迎 {member} 加入 {group}！{at_all}' },
        memberLeave: { enabled: true, template: '{member} 离开了 {group}。' },
        botJoin: { enabled: true, template: '我是 {group} 的助手，操作人 {op_member}。' },
      },
    }),
  });
  const sent = [];
  const api = { call: async (key) => ({ ok: true, data: { group_name: key === 'group_info' ? '测试群' : '' } }) };
  const bot = {
    sendGroup: async (g, p) => {
      sent.push({ g, p });
      return { ok: true, data: { id: 'M1' } };
    },
  };

  const joinEvt = await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'G1', member_openid: 'M_JOIN' }, { api, bot });
  eq(sent.length, 1);
  eq(sent[0].g, 'G1');
  eq(sent[0].p.event_id, joinEvt.ctx.event.id, '成员进群优先用事件外层 id 作 event_id（社区实测可用）');
  ok(!('msg_id' in sent[0].p), '成员进群不能用 msg_id');
  ok(!('msg_seq' in sent[0].p), 'event_id 被动回复不带 msg_seq');
  ok(sent[0].p.markdown.content.includes('测试群'), '应替换群名：' + sent[0].p.markdown.content);
  ok(sent[0].p.markdown.content.includes('M_JOIN'), '应替换成员：' + sent[0].p.markdown.content);
  ok(sent[0].p.markdown.content.includes('<qqbot-at-user id="M_JOIN" />'), '@ 成员标签应展开：' + sent[0].p.markdown.content);
  ok(sent[0].p.markdown.content.includes('<qqbot-at-everyone />'), '@ 全体标签应展开：' + sent[0].p.markdown.content);
  ok(sent[0].p.markdown.content.includes('<qqbot-cmd-input text="%2F%E8%8F%9C%E5%8D%95"'), '指令标签应展开：' + sent[0].p.markdown.content);

  sent.length = 0;
  const leaveEvt = await sendEvent(rt, 'GROUP_MEMBER_REMOVE', { group_openid: 'G1', member_openid: 'M_LEAVE' }, { api, bot });
  eq(sent.length, 1, '退群只发一条');
  ok(sent[0].p.markdown.content.includes('M_LEAVE'), '退群模板应替换成员');
  eq(sent[0].p.event_id, leaveEvt.ctx.event.id, '成员退群同样先试 event_id');
  ok(!('msg_id' in sent[0].p), '成员退群不能把事件 id 当 msg_id');

  sent.length = 0;
  const botJoinEvt = await sendEvent(rt, 'GROUP_ADD_ROBOT', { group_openid: 'G1', op_member_openid: 'OP1' }, { api, bot });
  ok(sent[0].p.markdown.content.includes('OP1'), '机器人进群模板应替换操作人');
  eq(sent[0].p.event_id, botJoinEvt.ctx.event.id, '机器人进群用 event_id');
  ok(!('msg_id' in sent[0].p), '机器人进群不应传 msg_id');

  // event_id 被拒（40034027）→ 只记日志，不降级主动消息
  const fb = [];
  const bot3 = {
    sendGroup: async (g, p) => {
      fb.push(p);
      return { ok: false, code: 40034027, message: '该事件不支持回复消息' };
    },
  };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'G1', member_openid: 'M_FAIL' }, { api, bot: bot3 });
  eq(fb.length, 2, 'event_id 被拒后应尝试主动消息');
  ok(!!fb[0].event_id, '第一条带 event_id');
  ok(!fb[1].event_id, '第二条为主动消息，不带 event_id');
  ok(!('msg_id' in fb[0]), '失败请求也不带 msg_id');

  // Markdown 无权限 → 同一 event_id 下降级纯文本
  const md = [];
  const bot4 = {
    sendGroup: async (g, p) => {
      md.push(p);
      return p.msg_type === 2 ? { ok: false, code: 304036, message: '无Markdown模板权限' } : { ok: true, data: { id: 'M2' } };
    },
  };
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'G1', member_openid: 'M_MD' }, { api, bot: bot4 });
  eq(md.length, 2, 'Markdown 失败应降级纯文本重试一次');
  eq(md[1].msg_type, 0, '降级后应为纯文本消息');
  ok(!!md[1].event_id, '降级纯文本仍保留 event_id');
  ok(md[1].content.includes('M_MD'), '降级文本保留成员信息：' + md[1].content);

  rt.cfg.welcome.enabled = false;
  sent.length = 0;
  await sendEvent(rt, 'GROUP_MEMBER_ADD', { group_openid: 'G1', member_openid: 'M2' }, { api, bot });
  eq(sent.length, 0, '关闭后不应发送');
});

check('群管：入群申请自动通过 / 拒绝 / 风险跳过', async () => {
  mock.reset();
  const dir = freshDir('join');
  const rt = await boot({
    dir,
    config: baseConfig({ guard: { enabled: true, join: { enabled: true, mode: 'approve', rejectReason: '请先看公告' } } }),
  });
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      return { ok: true, data: {} };
    },
  };
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', { group_openid: 'G1', member_openid: 'M1', join_request_id: 'JR1', username: '小明' }, { api });
  eq(calls[0].key, 'approval_join_request');
  eq(calls[0].opts.body.op, 'approve');
  eq(calls[0].opts.body.join_request_id, 'JR1');

  calls.length = 0;
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', { group_openid: 'G1', member_openid: 'M2', join_request_id: 'JR2', risk_tips: '可疑' }, { api });
  eq(calls.length, 0, '风险申请不应自动通过');

  rt.cfg.guard.join.mode = 'decline';
  calls.length = 0;
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', { group_openid: 'G1', member_openid: 'M3', join_request_id: 'JR3' }, { api });
  eq(calls[0].opts.body.op, 'decline');
  eq(calls[0].opts.body.reject_reason, '请先看公告');
});

check('群管：入群问题答案审核（qa）', async () => {
  mock.reset();
  const dir = freshDir('join-qa');
  const rt = await boot({
    dir,
    config: baseConfig({
      guard: {
        enabled: true,
        join: { enabled: true, mode: 'qa', qaKeywords: ['聚龙世界', '道友'], qaFallback: 'decline', rejectReason: '答案不对' },
      },
    }),
  });
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      return { ok: true, data: {} };
    },
  };
  const evt = (verify_info, extra = {}) => ({
    group_openid: 'G1',
    member_openid: 'M1',
    join_request_id: 'JR1',
    username: '小明',
    verify_info,
    ...extra,
  });

  await sendEvent(rt, 'GROUP_JOIN_REQUEST', evt({ method: 'verify_message', verify_message: '我想加入聚龙世界' }), { api });
  eq(calls[0].opts.body.op, 'approve');

  calls.length = 0;
  await sendEvent(
    rt,
    'GROUP_JOIN_REQUEST',
    evt({ method: 'admin_review_qa', review_qa_list: [{ question: '暗号', answer: '道友' }] }),
    { api },
  );
  eq(calls[0].opts.body.op, 'approve', '问答答案命中应通过');

  calls.length = 0;
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', evt({ method: 'verify_message', verify_message: '随便写写' }), { api });
  eq(calls[0].opts.body.op, 'decline');
  eq(calls[0].opts.body.reject_reason, '答案不对');

  calls.length = 0;
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', evt({ method: 'verify_message', verify_message: '聚龙世界' }, { risk_tips: '可疑' }), { api });
  eq(calls.length, 0, '带安全提示的申请不应自动通过');

  rt.cfg.guard.join.qaFallback = 'manual';
  calls.length = 0;
  await sendEvent(rt, 'GROUP_JOIN_REQUEST', evt({ method: 'verify_message', verify_message: '没答对' }), { api });
  eq(calls.length, 0, 'fallback=manual 时应留给管理员');

  // 违禁词总开关关闭时，入群审批仍要独立生效（本群覆盖）
  rt.cfg.groups.G2 = {
    reviewStatus: 'approved',
    guard: {
      enabled: false,
      join: { enabled: true, mode: 'qa', qaKeywords: ['2'], qaFallback: 'decline', rejectReason: '算错了' },
    },
  };
  calls.length = 0;
  await sendEvent(
    rt,
    'GROUP_JOIN_REQUEST',
    {
      group_openid: 'G2',
      member_openid: 'M2',
      join_request_id: 'JR2',
      username: '小红',
      verify_info: { method: 'verify_message', verify_message: '问题：1+1=？\n答案：2' },
    },
    { api },
  );
  eq(calls[0]?.opts.body.op, 'approve', '违禁词总开关关闭时入群问答仍应通过');
});

check('群管：事件缺 member_role 时用群成员接口补角色', async () => {
  mock.reset();
  const rt = await boot({ dir: freshDir('groupadmin-role'), config: baseConfig() });
  rt.bot = { sendC2C: async () => ({ ok: true }) };
  const calls = [];
  const api = {
    request: async (method, p) => {
      calls.push({ method, p });
      return { ok: true, data: { member_role: 'owner' } };
    },
  };
  const md = await send(rt, '/群管', { kind: 'group', role: '', api, union: 'UNION_TEST' });
  ok(md.includes('已私聊发送'), '补到 owner 后应放行：' + md);
  ok(calls.length && calls[0].p.includes('/members/'), '应调用群成员接口：' + JSON.stringify(calls));
});

check('群管：角色拿不到时放行到管理员审核', async () => {
  mock.reset();
  const rt = await boot({ dir: freshDir('groupadmin-role-unknown'), config: baseConfig() });
  rt.bot = { sendC2C: async () => ({ ok: true }) };
  const api = { request: async () => ({ ok: false, code: '11253', message: '应用无接口访问权限' }) };
  const md = await send(rt, '/群管', { kind: 'group', role: '', api, union: 'UNION_TEST' });
  ok(md.includes('已私聊发送'), '角色未知也应能提交，交给管理员审核：' + md);
});

check('群管：自定义回复能用 {heading}/{name}，拒绝提示不被模板顶掉', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('groupadmin-reply-vars'),
    config: baseConfig({ commands: { groupadmin: { reply: '{heading}\n{name} 的自定义群管卡' } } }),
  });
  rt.bot = { sendC2C: async () => ({ ok: true }) };
  const member = await send(rt, '/群管', { kind: 'group', role: 'member', union: 'UNION_TEST' });
  ok(member.includes('需要群主'), '普通成员仍应看到权限提示：' + member);
  ok(!member.includes('自定义群管卡'), '拒绝提示不应被自定义模板顶掉：' + member);
  const owner = await send(rt, '/群管', { kind: 'group', role: 'owner', union: 'UNION_TEST' });
  ok(owner.includes('测试用户 的自定义群管卡'), '群主应命中自定义模板：' + owner);
  ok(owner.includes('**测试用户**'), '自定义回复应能渲染 {heading}/{name}：' + owner);
});

check('群管审核页：按进退群开关显示模板', () => {
  const r = { cfg: { welcome: { memberJoin: { template: '欢迎' }, memberLeave: { template: '退群' } } } };
  // 群管页面：新成员进群关闭时，入群验证卡片仍然可见（只提示不生效）
  const offPage = plugin.__test.buildGroupAdminHtml({
    name: '测试群',
    group: 'G1',
    welcome: { memberJoin: { enabled: false, template: '欢迎' }, memberLeave: { enabled: true, template: '退群' } },
    guard: { enabled: false, bannedWords: [], action: 'recall', muteSeconds: 600, join: { enabled: false, mode: 'manual' } },
    custom: false,
    cmdVars: {},
    defaults: { join: '欢迎', leave: '退群' },
  });
  ok(offPage.includes('id="verifyCard"') && !/id="verifyCard"[^>]*hidden/.test(offPage), '入群验证卡片不应随进群关闭而隐藏');
  ok(offPage.includes('id="vJoinOffTip"'), '应有「入群验证不会生效」提示位');

  const off = plugin.__test.buildReviewHtml(r, {
    group: 'G1',
    groupName: '测试群',
    payload: { wJoinEnabled: '0', wLeaveEnabled: '0' },
  });
  ok(!off.includes('id="pvJoin"') && !off.includes('id="pvLeave"'), '关闭欢迎时不应渲染模板容器');
  ok(off.includes('不显示模板'), '关闭时应提示未开启');
  ok(off.includes('进群欢迎') && off.includes('进群欢迎</dt><dd>关闭'), '应显示进群欢迎状态');
  const on = plugin.__test.buildReviewHtml(r, {
    group: 'G1',
    groupName: '测试群',
    payload: { wJoinEnabled: '1', wLeaveEnabled: '0', wJoinTpl: '欢迎 {member}' },
  });
  ok(on.includes('id="pvJoin"') && !on.includes('id="pvLeave"'), '只开启进群时只渲染进群模板');
});

check('群管：/群管 权限与一次性页面', async () => {
  mock.reset();
  const dir = freshDir('groupadmin');
  const rt = await boot({ dir, config: baseConfig() });
  const sentPriv = [];
  rt.bot = {
    sendC2C: async (openid, payload) => {
      sentPriv.push({ openid, content: String(payload?.content || ''), msg_id: payload?.msg_id || '', msg_seq: payload?.msg_seq });
      return { ok: true };
    },
  };
  const member = await send(rt, '/群管', { kind: 'group', role: 'member' });
  ok(member.includes('需要群主'), '普通成员应被拒绝：' + member);
  const priv = await send(rt, '/群管', { kind: 'c2c', role: 'owner' });
  ok(priv.includes('请在群里'), '私聊应提示去群里：' + priv);
  const admin = await send(rt, '/群管', { kind: 'group', role: 'owner', union: 'UNION_TEST' });
  ok(admin.includes('已私聊发送'), '群聊应提示链接已私聊：' + admin);
  ok(!admin.includes('jl-callback.html'), '群聊不应再贴回调地址：' + admin);
  ok(admin.includes('推荐使用电脑进行编辑'), '信息卡片底部应有电脑编辑提示：' + admin);
  ok(
    sentPriv.some((x) => x.msg_id && x.content.includes('jl-callback.html') && x.content.includes('10 分钟')),
    '应优先用群消息 msg_id 私聊回复：' + JSON.stringify(sentPriv),
  );
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const items = Object.values(data.items);
  eq(items.length, 1);
  ok(items[0].url && items[0].url.includes('jl-callback.html'), '回调记录应保存地址供复用');
  const html = mock.state.callbacks.get(items[0].id).html;
  eq(mock.state.callbacks.get(items[0].id).expiresMinutes, 10, '群管页面应 10 分钟有效');
  ok(!html.includes('data-callback-save'), '页面不应再放自定义提交按钮');
  ok(html.includes('推荐使用电脑进行编辑'), '页面底部应有电脑编辑提示');
  ok(html.includes('data-reset="join"') && html.includes('恢复默认'), '模板旁应有恢复默认按钮');
  ok(html.includes('vVerifyEnabled') && html.includes('vVerifyQuestion') && html.includes('vVerifyAnswer1') && html.includes('vVerifyCorrect'), '回调页应包含入群验证字段');
  ok(html.includes('id="joinBox"') && html.includes('id="guardBox"') && html.includes('id="vCustomBox"'), '回调页应有开关联动容器');
  ok(html.includes('function syncDeps()'), '回调页应有开关联动脚本');
  ok(html.includes('qqbot-cmd-(?:input|enter)'), '回调页预览应把指令标签渲染成蓝色标签');
  ok(html.includes('欢迎加入'), '恢复默认应使用全局 welcome 模板');
  eq(items[0].group, 'GROUP_1');
  eq(items[0].status, 'awaiting');

  // 10 分钟内还没提交：再次 /群管 复用同一个地址
  const before = new Set(mock.state.callbacks.keys());
  const again = await send(rt, '/群管', { kind: 'group', role: 'owner', union: 'UNION_TEST' });
  ok(again.includes('复用'), '未提交时应复用旧链接：' + again);
  eq(mock.state.callbacks.size, before.size, '复用不应新建回调');
  const data2 = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  eq(Object.keys(data2.items).length, 1, 'callbacks.json 里仍应只有一个页面');
  eq(items[0].status, 'awaiting');
});

check('群管：私聊失败降级主动消息，再失败群提示加好友', async () => {
  mock.reset();
  const rt1 = await boot({ dir: freshDir('groupadmin-fallback1'), config: baseConfig() });
  const calls1 = [];
  rt1.bot = {
    sendC2C: async (openid, payload) => {
      calls1.push(payload || {});
      return payload?.msg_id ? { ok: false, code: 40054004, message: '无好友关系' } : { ok: true };
    },
  };
  const md1 = await send(rt1, '/群管', { kind: 'group', role: 'owner', union: 'UNION_TEST' });
  ok(md1.includes('已私聊发送'), '主动消息成功时群提示已私聊：' + md1);
  ok(calls1.some((x) => x.msg_id), '应先尝试群消息私聊回复');
  ok(calls1.some((x) => !x.msg_id), '群消息私聊回复失败后应降级主动 C2C');

  const rt2 = await boot({ dir: freshDir('groupadmin-fallback2'), config: baseConfig() });
  rt2.bot = { sendC2C: async () => ({ ok: false, code: 40034105, message: '主动消息失败，无权限' }) };
  const md2 = await send(rt2, '/群管', { kind: 'group', role: 'owner', union: 'UNION_TEST' });
  ok(md2.includes('无权限') && md2.includes('添加机器人为私聊好友'), '两种私聊都失败时群提示加好友：' + md2);
});

check('群管：提交后进入审核快照，审核后消失', async () => {
  mock.reset();
  const dir = freshDir('groupadmin-review');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const id = Object.keys(data.items)[0];
  const cb = mock.state.callbacks.get(id);
  cb.status = 'submitted';
  cb.submittedAt = Date.now();
  cb.payload = {
    wJoinEnabled: '1',
    wJoinTpl: '欢迎 {at_member} 加入 {group}',
    wLeaveEnabled: '0',
    wLeaveTpl: '拜拜',
    gEnabled: '1',
    bannedWords: '广告\n代练',
    gAction: 'warn',
    muteSeconds: '600',
    jEnabled: '1',
    joinMode: 'qa',
    joinKeywords: '聚龙',
    joinFallback: 'decline',
    rejectReason: '不行',
  };
  cb.user = { id: 'usr_x', name: '群主', email: 'owner@example.com' };
  await plugin.__test.pollCallbacks(rt);
  const snap = plugin.__test.reviewSnapshot(rt);
  eq(snap.items.length, 1);
  eq(snap.items[0].id, id);
  eq(snap.items[0].payload.gAction, 'warn');
  ok(String(snap.items[0].byAvatar || '').includes('qlogo'), '快照应带提交人头像：' + snap.items[0].byAvatar);
  const before = new Set(mock.state.callbacks.keys());
  const again = await send(rt, '/群管', { kind: 'group', role: 'owner' });
  ok(again.includes('审核中'), '待审核时再次 /群管 应提示等待：' + again);
  eq(mock.state.callbacks.size, before.size, '待审核时不应再创建新审核页面');
  rt.cfg.callbackReviews[id] = { status: 'approved', at: Date.now() };
  eq(plugin.__test.reviewSnapshot(rt).items.length, 0, '审核后不应再出现');
  const resumed = await send(rt, '/群管', { kind: 'group', role: 'owner' });
  ok(resumed.includes('私聊'), '审核结束后应允许再次提交：' + resumed);
});

check('群管：只关闭功能 / 与全局一致时自动通过，不进审核', async () => {
  mock.reset();
  const dir = freshDir('groupadmin-auto');
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  let data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const id = Object.keys(data.items)[0];
  const cb = mock.state.callbacks.get(id);
  cb.status = 'submitted';
  cb.submittedAt = Date.now();
  cb.payload = { wJoinEnabled: '0', wLeaveEnabled: '0', vVerifyEnabled: '0', gEnabled: '0', jEnabled: '0' };
  cb.user = { name: '群主' };
  await plugin.__test.pollCallbacks(rt);
  eq(plugin.__test.reviewSnapshot(rt).items.length, 0, '只关闭功能不应进审核');
  const group = rt.cfg.groups.GROUP_1;
  ok(group && group.reviewStatus === 'approved', '应直接写入本群覆盖');
  eq(rt.cfg.callbackReviews[id] && rt.cfg.callbackReviews[id].status, 'approved', '应记为已通过');
  ok(rt.cfg.callbackReviews[id].auto, '应标记自动通过');

  // 与全局一致（模板原样提交）也自动通过
  mock.reset();
  const dir2 = freshDir('groupadmin-auto2');
  const rt2 = await boot({ dir: dir2, config: baseConfig() });
  await send(rt2, '/群管', { kind: 'group', role: 'admin' });
  data = JSON.parse(fs.readFileSync(path.join(dir2, 'data', 'callbacks.json'), 'utf8'));
  const cb2 = mock.state.callbacks.get(Object.keys(data.items)[0]);
  cb2.status = 'submitted';
  cb2.submittedAt = Date.now();
  cb2.payload = {
    wJoinEnabled: '1',
    wJoinTpl: rt2.cfg.welcome.memberJoin.template,
    wLeaveEnabled: '1',
    wLeaveTpl: rt2.cfg.welcome.memberLeave.template,
    vVerifyEnabled: '0',
    gEnabled: '0',
    jEnabled: '0',
  };
  await plugin.__test.pollCallbacks(rt2);
  eq(plugin.__test.reviewSnapshot(rt2).items.length, 0, '与全局一致不应进审核');
  ok(rt2.cfg.groups.GROUP_1 && rt2.cfg.groups.GROUP_1.reviewStatus === 'approved', '应直接生效');

  // 改了模板 / 验证题仍要管理员审核
  mock.reset();
  const dir3 = freshDir('groupadmin-auto3');
  const rt3 = await boot({ dir: dir3, config: baseConfig() });
  await send(rt3, '/群管', { kind: 'group', role: 'admin' });
  data = JSON.parse(fs.readFileSync(path.join(dir3, 'data', 'callbacks.json'), 'utf8'));
  const cb3 = mock.state.callbacks.get(Object.keys(data.items)[0]);
  cb3.status = 'submitted';
  cb3.submittedAt = Date.now();
  cb3.payload = { wJoinEnabled: '1', wJoinTpl: '自定义欢迎 {member}', wLeaveEnabled: '0', vVerifyEnabled: '0', gEnabled: '0', jEnabled: '0' };
  await plugin.__test.pollCallbacks(rt3);
  eq(plugin.__test.reviewSnapshot(rt3).items.length, 1, '改了模板仍应进审核');
});

check('群管：与「已通过的本群自定义」一致时也自动通过', async () => {
  mock.reset();
  const dir = freshDir('groupadmin-auto-approved');
  const rt = await boot({ dir, config: baseConfig() });
  // 模拟之前审核通过的一份本群自定义
  rt.cfg.groups.GROUP_1 = {
    name: '测试群',
    reviewStatus: 'approved',
    updatedAt: Date.now(),
    welcome: {
      memberJoin: { enabled: true, template: '自定义欢迎 {member}' },
      memberLeave: { enabled: false, template: rt.cfg.welcome.memberLeave.template },
      joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '3'], correctIndex: 0, maxAttempts: 3, expiresMinutes: 5 },
    },
    guard: {
      enabled: true,
      bannedWords: ['广告'],
      action: 'recall_mute',
      muteSeconds: 600,
      join: { enabled: false, mode: 'manual', rejectReason: '', qaKeywords: [], qaFallback: 'decline' },
    },
  };
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const cb = mock.state.callbacks.get(Object.keys(data.items)[0]);
  cb.status = 'submitted';
  cb.submittedAt = Date.now();
  const samePayload = {
    wJoinEnabled: '1',
    wJoinTpl: '自定义欢迎 {member}',
    wLeaveEnabled: '0',
    wLeaveTpl: rt.cfg.welcome.memberLeave.template,
    vVerifyEnabled: '1',
    vVerifyMode: 'custom',
    vVerifyQuestion: '1+1=?',
    vVerifyAnswer1: '2',
    vVerifyAnswer2: '3',
    vVerifyCorrect: '1',
    vVerifyMax: '3',
    vVerifyExpire: '5',
    gEnabled: '1',
    bannedWords: '广告',
    gAction: 'recall_mute',
    muteSeconds: '600',
    jEnabled: '0',
    joinMode: 'manual',
    joinFallback: 'decline',
    rejectReason: '',
  };
  cb.payload = { ...samePayload };
  await plugin.__test.pollCallbacks(rt);
  eq(plugin.__test.reviewSnapshot(rt).items.length, 0, '和已通过的自定义一致时不应进审核');
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, wJoinTpl: '又改过的欢迎' }, 'GROUP_1') === false, '改了模板仍需审核');
  // 在已通过的基础上只关闭某项功能 → 免审（用户反馈的场景：只关了入群验证）
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, vVerifyEnabled: '0' }, 'GROUP_1') === true, '只关闭入群验证应自动通过');
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, gEnabled: '0' }, 'GROUP_1') === true, '只关闭违禁词应自动通过');
  // 群管部分（违禁词 / 入群审批）不在判断范围：改动也自动通过
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, jEnabled: '1', joinMode: 'approve' }, 'GROUP_1') === true, '入群审批改动不在判断范围，应自动通过');
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, gEnabled: '1', bannedWords: '别的词\n测试' }, 'GROUP_1') === true, '违禁词改动不在判断范围，应自动通过');
  ok(plugin.__test.autoApprovable(rt, { ...samePayload, gAction: 'warn', muteSeconds: '60' }, 'GROUP_1') === true, '改违禁词动作也应自动通过');
  // 欢迎用已通过版本、入群验证用全局内容（混合基线）：应自动通过
  rt.cfg.welcome.joinVerify = { enabled: true, mode: 'custom', question: '2+2=?', answers: ['4', '5'], correctIndex: 0, maxAttempts: 3, expiresMinutes: 5 };
  const mixed = {
    ...samePayload,
    vVerifyEnabled: '1',
    vVerifyQuestion: '2+2=?',
    vVerifyAnswer1: '4',
    vVerifyAnswer2: '5',
    vVerifyCorrect: '1',
  };
  ok(plugin.__test.autoApprovable(rt, mixed, 'GROUP_1') === true, '入群验证内容与全局一致（欢迎沿用已通过）应自动通过');
});

check('群管：没有自定义的群按全局值提交、只关某项也自动通过', async () => {
  mock.reset();
  const dir = freshDir('groupadmin-auto-global');
  const rt = await boot({ dir, config: baseConfig() });
  const w = rt.cfg.welcome;
  const g = rt.cfg.guard;
  const gp = {
    wJoinEnabled: w.memberJoin.enabled ? '1' : '0',
    // 模拟老配置里的 CRLF：页面 textarea 提交的是 LF，比较时要归一
    wJoinTpl: String(w.memberJoin.template).replace(/\n/g, '\r\n'),
    wLeaveEnabled: w.memberLeave.enabled ? '1' : '0',
    wLeaveTpl: w.memberLeave.template,
    vVerifyEnabled: '0',
    gEnabled: g.enabled ? '1' : '0',
    bannedWords: (g.bannedWords || []).join('\n'),
    gAction: g.action,
    muteSeconds: String(g.muteSeconds),
    jEnabled: g.join.enabled ? '1' : '0',
    joinMode: g.join.mode,
    joinKeywords: (g.join.qaKeywords || []).join('\n'),
    joinFallback: g.join.qaFallback,
    rejectReason: g.join.rejectReason || '',
  };
  ok(plugin.__test.autoApprovable(rt, gp, 'GROUP_NEW') === true, '按全局值只关入群验证应自动通过');
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const cb = mock.state.callbacks.get(Object.keys(data.items)[0]);
  cb.status = 'submitted';
  cb.submittedAt = Date.now();
  cb.payload = gp;
  await plugin.__test.pollCallbacks(rt);
  eq(plugin.__test.reviewSnapshot(rt).items.length, 0, '按全局值只关某项不应进审核');
});

check('群管：待审核项按新规则回溯自动通过', async () => {
  mock.reset();
  const dir = freshDir('groupadmin-auto-retro');
  const rt = await boot({ dir, config: baseConfig() });
  rt.cfg.groups.GROUP_1 = {
    name: '测试群',
    reviewStatus: 'approved',
    updatedAt: Date.now(),
    welcome: {
      memberJoin: { enabled: true, template: '自定义欢迎 {member}' },
      memberLeave: { enabled: false, template: rt.cfg.welcome.memberLeave.template },
      joinVerify: { enabled: true, mode: 'custom', question: '1+1=?', answers: ['2', '3'], correctIndex: 0, maxAttempts: 3, expiresMinutes: 5 },
    },
    guard: { enabled: false, bannedWords: [], action: 'recall', muteSeconds: 600, join: { enabled: false, mode: 'manual', rejectReason: '', qaKeywords: [], qaFallback: 'decline' } },
  };
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  const cbFile = path.join(dir, 'data', 'callbacks.json');
  let stored = JSON.parse(fs.readFileSync(cbFile, 'utf8'));
  const cb = mock.state.callbacks.get(Object.keys(stored.items)[0]);
  cb.status = 'submitted';
  cb.submittedAt = Date.now();
  cb.payload = { wJoinEnabled: '1', wJoinTpl: '改过的欢迎 {member}', wLeaveEnabled: '0', vVerifyEnabled: '0', gEnabled: '0', jEnabled: '0' };
  await plugin.__test.pollCallbacks(rt);
  eq(plugin.__test.reviewSnapshot(rt).items.length, 1, '改过模板应先进入待审核');

  // 把待审核内容改成「只关闭入群验证、其余与已通过一致」再轮询：应回溯自动通过
  stored = JSON.parse(fs.readFileSync(cbFile, 'utf8'));
  const pending = Object.values(stored.items).find((it) => it.status === 'submitted');
  pending.payload = {
    wJoinEnabled: '1',
    wJoinTpl: '自定义欢迎 {member}',
    wLeaveEnabled: '0',
    vVerifyEnabled: '0',
    gEnabled: '0',
    jEnabled: '0',
  };
  fs.writeFileSync(cbFile, JSON.stringify(stored, null, 2), 'utf8');
  await plugin.__test.pollCallbacks(rt);
  eq(plugin.__test.reviewSnapshot(rt).items.length, 0, '回溯应自动通过');
  eq(rt.cfg.groups.GROUP_1.welcome.joinVerify.enabled, false, '应已关闭本群入群验证');
  eq(rt.cfg.groups.GROUP_1.welcome.memberJoin.template, '自定义欢迎 {member}', '其余自定义保持不变');
});

check('群管：管理员审核链接通过后同步到设置页', async () => {
  mock.reset();
  const dir = freshDir('admin-review');
  fs.writeFileSync(path.join(dir, 'plugin.json'), JSON.stringify({ id: 'VloS', config: {} }), 'utf8');
  fs.copyFileSync(path.join(PLUGIN_DIR, 'settings.html'), path.join(dir, 'settings.html'));
  const rt = await boot({ dir, config: baseConfig({ groupAdmin: { adminOpenids: ['ADMIN_OPENID'] } }) });
  const sent = [];
  rt.bot = {
    sendC2C: async (openid, payload) => {
      sent.push({ openid, content: String(payload?.content || '') });
      return { ok: true };
    },
  };
  await send(rt, '/群管', { kind: 'group', role: 'admin' });
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const id = Object.keys(data.items)[0];
  const submit = mock.state.callbacks.get(id);
  submit.status = 'submitted';
  submit.submittedAt = Date.now();
  submit.payload = {
    wJoinEnabled: '1',
    wJoinTpl: '欢迎 {at_member} 加入 {group}',
    wLeaveEnabled: '0',
    wLeaveTpl: '拜拜',
    gEnabled: '1',
    bannedWords: '广告',
    gAction: 'recall',
    muteSeconds: '600',
    jEnabled: '0',
    joinMode: 'manual',
    joinKeywords: '',
    joinFallback: 'decline',
    rejectReason: '不行',
  };
  await plugin.__test.pollCallbacks(rt);
  const afterSubmit = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'callbacks.json'), 'utf8'));
  const reviewId = afterSubmit.items[id]?.reviewId;
  ok(reviewId, '提交后应给管理员创建审核链接');
  ok(sent.some((x) => x.openid === 'ADMIN_OPENID' && x.content.includes('24 小时')), '应私聊管理员 24 小时审核链接：' + JSON.stringify(sent));
  const reviewCb = mock.state.callbacks.get(reviewId);
  eq(reviewCb && reviewCb.expiresMinutes, 1440, '管理员审核链接应 24 小时有效');
  ok(reviewCb && reviewCb.html.includes('data-decision="approve"') && reviewCb.html.includes('data-decision="reject"'), '审核页应有通过 / 拒绝按钮');
  reviewCb.status = 'submitted';
  reviewCb.submittedAt = Date.now();
  reviewCb.payload = { decision: 'approve' };
  await plugin.__test.pollCallbacks(rt);
  ok(rt.cfg.groups.GROUP_1 && rt.cfg.groups.GROUP_1.reviewStatus === 'approved', '审核通过后应写入本群覆盖');
  ok(rt.rawConfig.groups && rt.rawConfig.groups.GROUP_1, '应同步面板内存里的 config.groups');
  ok(plugin.__test.reviewSnapshot(rt).groups.GROUP_1, '审核快照应带已通过群');
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8'));
  ok(manifest.config.groups.GROUP_1, '应持久化到 plugin.json');
  const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
  ok(html.includes('"groups"') && html.includes('GROUP_1'), '设置页快照应带 groups，打开「已通过」能看到');
});

check('群管：审核私聊提示文案', async () => {
  const rt = await boot({
    dir: freshDir('review-msg'),
    config: baseConfig({ groupAdmin: { approveMessage: '通过了', rejectMessage: '没通过' } }),
  });
  const fn = plugin.__test.reviewNoticeText;
  eq(fn(rt, { status: 'approved' }), '通过了');
  eq(fn(rt, { status: 'rejected', reason: '答案不对' }), '没通过\n本次拒绝原因：答案不对');
  rt.cfg.groupAdmin.rejectMessage = '自定义拒绝';
  eq(fn(rt, { status: 'rejected', reason: '' }), '自定义拒绝');
});

check('群管：本群覆盖优先于全局默认', async () => {
  mock.reset();
  const dir = freshDir('group-override');
  const rt = await boot({
    dir,
    config: baseConfig({
      groups: {
        GROUP_1: {
          name: '自定义群',
          welcome: { memberJoin: { enabled: true, template: '本群专属欢迎 {member}' } },
          guard: {
            enabled: true,
            bannedWords: ['本群禁词'],
            action: 'warn',
            muteSeconds: 120,
            join: { enabled: true, mode: 'qa', qaKeywords: ['暗号'], qaFallback: 'manual', rejectReason: '不对' },
          },
        },
      },
    }),
  });
  const g = plugin.__test.effectiveGuard(rt, 'GROUP_1');
  eq(g.action, 'warn');
  eq(rt.cfg.groups.GROUP_1.reviewStatus, 'approved', '审核覆盖默认 approved');
  eq(g.bannedWords[0], '本群禁词');
  eq(g.join.qaKeywords[0], '暗号');
  const g2 = plugin.__test.effectiveGuard(rt, 'GROUP_2');
  eq(g2.action, 'recall');
  eq(g2.bannedWords.length, 0);
  const w = plugin.__test.effectiveWelcome(rt, 'GROUP_1');
  ok(w.memberJoin.template.includes('本群专属'), '本群模板应生效：' + w.memberJoin.template);
  const w2 = plugin.__test.effectiveWelcome(rt, 'GROUP_2');
  ok(w2.memberJoin.template.includes('欢迎加入'), '没覆盖的群用全局默认：' + w2.memberJoin.template);
  rt.cfg.groups.GROUP_1.reviewStatus = 'pending';
  eq(plugin.__test.effectiveGuard(rt, 'GROUP_1').action, 'recall', '反审后应回落到全局默认');
  ok(plugin.__test.effectiveWelcome(rt, 'GROUP_1').memberJoin.template.includes('欢迎加入'), '反审后欢迎语也应回落');
});

check('群管：本群关闭违禁词时回落全局', async () => {
  const rt = await boot({
    dir: freshDir('group-guard-fallback'),
    config: baseConfig({
      guard: { enabled: true, bannedWords: ['全局违禁词'], action: 'recall_mute', muteSeconds: 60 },
      groups: {
        GROUP_1: {
          guard: {
            enabled: false,
            bannedWords: [],
            join: { enabled: true, mode: 'qa', qaKeywords: ['2'], qaFallback: 'decline' },
          },
        },
      },
    }),
  });
  const g = plugin.__test.effectiveGuard(rt, 'GROUP_1');
  eq(g.enabled, true, '本群没启用违禁词时应回落全局开关');
  eq(g.bannedWords[0], '全局违禁词', '本群词为空时应回落全局词');
  eq(g.action, 'recall_mute', '本群没设动作时应回落全局动作');
  eq(g.join.mode, 'qa', '本群入群问答配置仍应保留');
});

check('群管：已审核群关闭违禁词时仍按全局撤回并禁言（线上配置复现）', async () => {
  mock.reset();
  const rt = await boot({
    dir: freshDir('guard-approved-global'),
    config: baseConfig({
      guard: { enabled: true, bannedWords: ['蒋介石'], action: 'recall_mute', muteSeconds: 300 },
      groups: {
        GROUP_1: {
          name: 'VloS测试群',
          reviewStatus: 'approved',
          guard: {
            enabled: false,
            bannedWords: [],
            action: 'recall',
            muteSeconds: 600,
            join: { enabled: true, mode: 'qa', qaKeywords: ['2'], qaFallback: 'decline' },
          },
        },
      },
    }),
  });
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      return { ok: true, data: {} };
    },
  };
  const md = await send(rt, '蒋介石', { kind: 'group', api });
  eq(md, '', '命中全局违禁词不应回复');
  eq(calls.length, 2, '应撤回并禁言，实际调用：' + JSON.stringify(calls.map((c) => c.key)));
  eq(calls[0].key, 'recall_group_message');
  eq(calls[0].opts.params.group_openid, 'GROUP_1');
  eq(calls[1].key, 'restrict_chat_set');
  eq(calls[1].opts.body.members[0].op, 'add');
});

check('菜单：同步群指令面板 + 私聊菜单，未变化不重复', async () => {
  mock.reset();
  const dir = freshDir('menu-sync');
  const rt = await boot({ dir, config: baseConfig() });
  const calls = [];
  const api = {
    call: async (key, opts) => {
      calls.push({ key, opts });
      if (key === 'list_panels') {
        return {
          ok: true,
          data: {
            records: [
              { panel_id: 'p_old', panel: { remark: 'VloS 菜单' } },
              { panel_id: 'p_other', panel: { remark: '别的插件' } },
            ],
          },
        };
      }
      if (key === 'create_panel') return { ok: true, data: { panel_id: 'p_new' } };
      return { ok: true, data: {} };
    },
  };
  const ctx = makeCtx({ dir, config: rt.rawConfig, content: '', api });
  const out = await plugin.__test.syncMenus(ctx, rt, { force: true });
  eq(out.ok, true);
  const kinds = calls.map((c) => c.key);
  ok(kinds.includes('update_menu'), '应同步私聊菜单');
  ok(kinds.includes('list_panels') && kinds.includes('create_panel'), '应同步群面板');
  ok(kinds.includes('delete_panel'), '应删除旧 VloS 面板');
  eq(calls.find((c) => c.key === 'delete_panel').opts.params.panel_id, 'p_old');
  const create = calls.find((c) => c.key === 'create_panel');
  eq(create.opts.body.panel.remark, 'VloS 菜单');
  eq(create.opts.body.panel.items[0].type, 'command');
  ok(fs.existsSync(path.join(dir, 'data', 'menu-sync.json')), '应记录同步状态');

  calls.length = 0;
  const again = await plugin.__test.syncMenus(ctx, rt);
  ok(again.skipped, '配置没变应跳过');
  eq(calls.length, 0);
});

check('进退群：图片自动补 QQ 尺寸', () => {
  const fn = plugin.__test.withImageSize;
  eq(fn('![a](https://x.test/y.png)'), '![a #0px #0px](https://x.test/y.png)');
  eq(fn('![a #10px #20px](https://x.test/y.png)'), '![a #10px #20px](https://x.test/y.png)');
  eq(fn('文字 ![b](https://x.test/z.png) 结尾'), '文字 ![b #0px #0px](https://x.test/z.png) 结尾');
  eq(plugin.__test.normalizeQqMarkdown('A\n---\nB'), 'A\n***\nB', '腾讯分割线应是 ***');
  eq(plugin.__test.normalizeQqMarkdown('![a](https://x.test/y.png)'), '![a #0px #0px](https://x.test/y.png)');
});

check('进退群：自定义蓝色指令变量', () => {
  eq(
    plugin.__test.renderTemplate('{cmd:/Arknights|明日方舟}', {}),
    '<qqbot-cmd-input text="%2FArknights" show="%E6%98%8E%E6%97%A5%E6%96%B9%E8%88%9F" />',
  );
  eq(plugin.__test.renderTemplate('{cmd:/MC}', {}), '<qqbot-cmd-input text="%2FMC" show="%2FMC" />');
  eq(
    plugin.__test.renderTemplate('{img:https://www.jlworld.net/a.png}', {}),
    '![图片 #0px #0px](https://www.jlworld.net/a.png)',
    '图片片段应自动补 #0px #0px',
  );
  eq(plugin.__test.renderTemplate('{link:https://www.jlworld.net|聚龙世界}', {}), '[聚龙世界](https://www.jlworld.net)', '网址片段应生成 Markdown 链接');
  eq(plugin.__test.renderTemplate('{at:OPENID_A}', {}), '<qqbot-at-user id="OPENID_A" />', '@指定用户');
  eq(plugin.__test.renderTemplate('{at_all}', { at_all: '<qqbot-at-everyone />' }), '<qqbot-at-everyone />', '@全体成员');
  eq(plugin.__test.renderTemplate('{img:javascript:alert(1)}', {}), '', '非 http(s) 图片地址应被丢弃');
  eq(
    plugin.__test.normalizeQqMarkdown('<qqbot-cmd-input text="/Arknights" show="明日方舟" reference="false" />'),
    '<qqbot-cmd-input text="%2FArknights" show="%E6%98%8E%E6%97%A5%E6%96%B9%E8%88%9F" reference="false" />',
    '手写标签里的中文应自动转码',
  );
  eq(
    plugin.__test.normalizeQqMarkdown('<qqbot-cmd-input text="%2FMC" show="%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C" />'),
    '<qqbot-cmd-input text="%2FMC" show="%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C" />',
    '已转码的标签不应重复转码',
  );
});

check('指令：改名 / 停用 / 帮助备注', async () => {
  mock.reset();
  const dir = freshDir('commands');
  const cfg = baseConfig();
  cfg.commands.menu.names = ['导航'];
  cfg.commands.menu.desc = '打开功能导航';
  cfg.commands.cancel.enabled = false;
  const rt = await boot({ dir, config: cfg });
  const nav = await send(rt, '/导航', { kind: 'c2c' });
  ok(nav.includes('## 菜单'), '新指令应生效：' + nav);
  eq(await send(rt, '导航', { kind: 'c2c' }), '', '默认识别字符要求先加 /');
  eq(await send(rt, '/菜单', { kind: 'c2c' }), '', '旧指令应失效');
  eq(await send(rt, '/cancel'), '', '停用的指令不应响应');
  rt.cfg.commands.menu.prefix = '';
  ok((await send(rt, '导航', { kind: 'c2c' })).includes('## 菜单'), '识别字符留空后裸词应生效');
  rt.cfg.commands.menu.prefix = '!';
  ok((await send(rt, '!导航', { kind: 'c2c' })).includes('## 菜单'), '自定义识别字符应生效');
  const help = await send(rt, '/vlos');
  ok(help.includes('打开功能导航') && help.includes('qqbot-cmd-enter'), '帮助里的指令应是蓝色可点击标签：' + help);
  ok(help.includes('!%E5%AF%BC%E8%88%AA'), '帮助标签应带自定义识别字符：' + help);
  ok(!help.includes('/cancel'), '停用指令不应出现在帮助里');
});

check('用户：设置页只读快照含账号信息且不含 token', async () => {
  mock.reset();
  const dir = freshDir('users-snap');
  fs.copyFileSync(path.join(PLUGIN_DIR, 'settings.html'), path.join(dir, 'settings.html'));
  const rt = await boot({ dir, config: baseConfig() });
  await send(rt, '/add snap@example.com');
  await send(rt, '123456');
  await send(rt, 'secret123');
  await send(rt, '快照用户');
  const snap = plugin.__test.usersSnapshot(rt);
  eq(snap.users.length, 1);
  eq(snap.users[0].email, 'snap@example.com');
  ok(!('token' in snap.users[0]), '快照不应包含 token');
  // 没绑聚龙账户的群友不应出现在快照里
  rt.store.touch('GROUP_RANDOM_USER', { scene: 'group' });
  eq(plugin.__test.usersSnapshot(rt).users.length, 1, '未绑账户的用户应被过滤');
  plugin.__test.refreshUsersSnapshot(rt);
  const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
  ok(html.includes('snap@example.com'), '设置页应写入用户快照');
  ok(!html.includes('tok_'), '设置页快照不应包含 token');
  const m = html.match(/<script id="vlos-users-data" type="application\/json">([\s\S]*?)<\/script>/);
  ok(m, '找不到用户快照 JSON');
  const parsed = JSON.parse(m[1].replace(/<!--[\s\S]*?-->/g, ''));
  eq(parsed.users[0].email, 'snap@example.com');
});

check('框架接口键：禁言接口是 restrict_chat_set', () => {
  const eps = require(path.join(ROOT, 'src', 'core', 'endpoints.js'));
  ok(Array.isArray(eps) && eps.some((e) => e.key === 'restrict_chat_set'), '缺少 restrict_chat_set 接口');
  ok(!eps.some((e) => e.key === 'restrict_chat_setting'), '不应存在旧键 restrict_chat_setting');
});

check('api.html：指令 / 聚龙账户 / 钱包 / 绑定 QQ', () => {
  const html = fs.readFileSync(path.join(PLUGIN_DIR, 'api.html'), 'utf8');
  for (const need of ['/add 邮箱', '/login', '/bindqq', '聚龙钱包', 'currency-add', 'users.json']) {
    ok(html.includes(need), `api.html 缺少 ${need}`);
  }
  ok(!html.includes('SMTP 发信'), 'api.html 不应再有 SMTP 发信章节');
});

run();
