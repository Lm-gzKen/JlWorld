'use strict';
/**
 * 通用工具：路径、文件、JSON、ID、时间、限流、深合并
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..', '..');

/** 数据根目录：全部运行时数据都写进项目目录下的 ~JlWBoT */
function dataRoot() {
  return process.env.JLW_DATA_DIR ? path.resolve(process.env.JLW_DATA_DIR) : path.join(ROOT, '~JlWBoT');
}
function p(...parts) {
  return path.join(dataRoot(), ...parts);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function readJson(file, fallback) {
  try {
    let text = fs.readFileSync(file, 'utf8');
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

/** 原子写：先写 .tmp 再 rename，避免断电/崩溃写坏配置 */
function writeJson(file, value, pretty = true) {
  ensureDir(path.dirname(file));
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(value, null, pretty ? 2 : 0), 'utf8');
  fs.renameSync(tmp, file);
}

function writeText(file, text) {
  ensureDir(path.dirname(file));
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, file);
}

function isObj(v) {
  return v && typeof v === 'object' && !Array.isArray(v);
}

/** 深合并：仅用于配置补默认值，数组直接覆盖 */
function deepMerge(base, extra) {
  if (!isObj(base)) return extra === undefined ? base : extra;
  const out = { ...base };
  if (!isObj(extra)) return out;
  for (const k of Object.keys(extra)) {
    out[k] = isObj(base[k]) && isObj(extra[k]) ? deepMerge(base[k], extra[k]) : extra[k];
  }
  return out;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function uid(n = 12) {
  return crypto.randomBytes(Math.ceil(n / 2)).toString('hex').slice(0, n);
}

function nowIso() {
  const d = new Date();
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? '+' : '-';
  const hh = String(Math.floor(Math.abs(off) / 60)).padStart(2, '0');
  const mm = String(Math.abs(off) % 60).padStart(2, '0');
  const pad = (x, n = 2) => String(x).padStart(n, '0');
  return (
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}${sign}${hh}:${mm}`
  );
}

function ts() {
  return Date.now();
}

function dayKey(d = new Date()) {
  const pad = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

/** 时间格式化（面板用） */
function fmtDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return '-';
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  if (d) return `${d}天${h}小时`;
  if (h) return `${h}小时${m}分`;
  if (m) return `${m}分${ss}秒`;
  return `${ss}秒`;
}

/** 按日轮转的 JSONL 追加器（带大小上限） */
class JsonlWriter {
  constructor(dir, name, { maxFileMB = 16, keepDays = 7 } = {}) {
    this.dir = dir;
    this.name = name;
    this.maxBytes = maxFileMB * 1024 * 1024;
    this.keepDays = keepDays;
    this._stream = null;
    this._day = '';
    this._size = 0;
    ensureDir(dir);
  }

  _file(day) {
    return path.join(this.dir, `${this.name}-${day}.jsonl`);
  }

  _rotate() {
    const day = dayKey();
    if (day === this._day && this._stream) return;
    this._close();
    this._day = day;
    const file = this._file(day);
    try {
      this._size = fs.statSync(file).size;
    } catch {
      this._size = 0;
      fs.closeSync(fs.openSync(file, 'a'));
    }
    this._stream = fs.createWriteStream(file, { flags: 'a' });
    this._cleanup();
  }

  _cleanup() {
    try {
      const files = fs
        .readdirSync(this.dir)
        .filter((f) => f.startsWith(this.name + '-') && f.endsWith('.jsonl'))
        .sort();
      const cut = Date.now() - this.keepDays * 86400000;
      for (const f of files) {
        const fp = path.join(this.dir, f);
        if (fs.statSync(fp).mtimeMs < cut) fs.unlinkSync(fp);
      }
    } catch {
      /* ignore */
    }
  }

  write(obj) {
    this._rotate();
    const line = JSON.stringify(obj) + '\n';
    try {
      this._stream.write(line);
      this._size += Buffer.byteLength(line);
      if (this._size > this.maxBytes) {
        this._stream.end();
        const day = this._day;
        fs.renameSync(this._file(day), this._file(day + '-' + Date.now()));
        this._stream = null;
        this._day = '';
        this._rotate();
      }
    } catch {
      /* ignore */
    }
  }

  _close() {
    if (this._stream) {
      try {
        this._stream.end();
      } catch {
        /* ignore */
      }
      this._stream = null;
    }
  }

  close() {
    this._close();
  }
}

/** 读取 JSONL 尾部若干行（用于日志/消息面板） */
function tailJsonl(file, limit = 200) {
  try {
    const buf = fs.readFileSync(file);
    const text = buf.toString('utf8');
    const lines = text.split('\n').filter(Boolean);
    return lines.slice(-limit).map((l) => {
      try {
        return JSON.parse(l);
      } catch {
        return { raw: l };
      }
    });
  } catch {
    return [];
  }
}

function listJsonl(dir, prefix, limitFiles = 3) {
  try {
    return fs
      .readdirSync(dir)
      .filter((f) => f.startsWith(prefix) && f.endsWith('.jsonl'))
      .sort()
      .slice(-limitFiles)
      .map((f) => path.join(dir, f));
  } catch {
    return [];
  }
}

/** 简单令牌桶限流器 */
class RateLimiter {
  constructor(perMinute) {
    this.perMinute = perMinute;
    this.hits = [];
  }
  take() {
    const now = Date.now();
    this.hits = this.hits.filter((t) => now - t < 60000);
    if (this.hits.length >= this.perMinute) return false;
    this.hits.push(now);
    return true;
  }
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function randomToken(bytes = 24) {
  return crypto.randomBytes(bytes).toString('base64url');
}

module.exports = {
  ROOT,
  dataRoot,
  p,
  ensureDir,
  readJson,
  writeJson,
  writeText,
  deepMerge,
  sleep,
  uid,
  nowIso,
  ts,
  dayKey,
  clamp,
  fmtDuration,
  JsonlWriter,
  tailJsonl,
  listJsonl,
  RateLimiter,
  safeEqual,
  randomToken,
  isObj,
};
