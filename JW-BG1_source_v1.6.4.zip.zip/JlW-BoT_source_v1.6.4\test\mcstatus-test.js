'use strict';
/**
 * mcstatus 插件自测（不依赖真实 QQ、不消耗线上接口额度）
 *
 *   node test/mcstatus-test.js
 *
 * 启动一个本地假 MCStatus 服务，覆盖：菜单、图片状态、JSON 代码块、
 * 接口帮助、大小写、端口解析、基岩版、错误回退、Markdown 发送失败回退。
 */
const assert = require('assert');
const http = require('http');
const { parseCommand } = require('../src/core/bot.js');

const PLUGIN = require('../~JlWBoT/plugins/mcstatus/index.js');

const FIXTURE = {
  query: {
    ok: true,
    online: true,
    edition: 'java',
    host: 'mc.hypixel.net',
    serverIp: '172.65.197.160',
    port: 25565,
    address: 'mc.hypixel.net:25565',
    maxPlayers: 200000,
    onlinePlayers: 16853,
    motdText: 'Hypixel Network [1.8/26.3]\n     SB MAGIC FIND',
    motdHtml: '<span>Hypixel</span>',
    version: 'Requires MC 1.8 / 1.21',
    protocol: 767,
    iconUrl: 'data:image/png;base64,' + 'A'.repeat(5000),
    players: [{ name: 'Steve', uuid: 'u', offlineUuid: 'o', placeholder: false }],
    latencyMs: 433,
    ping: 433,
    queriedAt: 1795148626970,
    quota: { limit: 60, used: 1, remaining: 59, resetIn: 14, dailyLimit: 1200, dailyUsed: 1 },
  },
  image: {
    ok: true,
    online: true,
    host: 'mc.hypixel.net',
    address: 'mc.hypixel.net:25565',
    port: 25565,
    onlinePlayers: 16853,
    maxPlayers: 200000,
    version: 'Requires MC 1.8 / 1.21',
    protocol: 767,
    ping: 433,
    image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
    imageUrl: '/uploads/mcstatus/test.png',
    width: 760,
    height: 270,
    frame: { id: 'nether', name: '下界', builtin: true },
    queriedAt: 1795148626970,
  },
  frames: {
    ok: true,
    frames: [
      { id: 'inventory', name: '经典物品栏' },
      { id: 'nether', name: '下界' },
      { id: 'end', name: '末地' },
    ],
  },
};

let server;
let base = '';
const requests = [];
const apiCalls = [];
const ICON_PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64'
);

function startMock() {
  server = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/icon.png') {
      res.writeHead(200, { 'Content-Type': 'image/png' });
      res.end(ICON_PNG);
      return;
    }
    if (req.method === 'PUT' && req.url === '/presign') {
      res.writeHead(200, { ETag: '"d41d8cd98f00b204e9800998ecf8427e"' });
      res.end();
      return;
    }
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      let body = {};
      try {
        body = raw ? JSON.parse(raw) : {};
      } catch {
        /* ignore */
      }
      requests.push({ url: req.url, body });
      const send = (code, obj) => {
        res.writeHead(code, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(obj));
      };
      if (req.url === '/api/plugin/mcstatus/query') {
        if (body.host === 'bad_host_#####' || body.host === 'not-exist.example.com') {
          return send(400, { error: '地址不存在，无法解析' });
        }
        if (body.host === 'timeout.example.com') {
          // 比插件超时更慢，用来触发超时分支
          setTimeout(() => send(200, { ...FIXTURE.query, host: body.host }), 400);
          return;
        }
        if (body.host === 'bedrock.example.com') {
          return send(200, { ...FIXTURE.query, edition: 'bedrock', address: 'bedrock.example.com:19132', port: 19132 });
        }
        return send(200, { ...FIXTURE.query, host: body.host, port: body.port, address: `${body.host}:${body.port}` });
      }
      if (req.url === '/api/plugin/mcstatus/image') {
        return send(200, { ...FIXTURE.image, frame: { id: body.frame || 'random', name: body.frame || '随机' } });
      }
      if (req.url === '/api/plugin/mcstatus/frames') return send(200, FIXTURE.frames);
      send(404, { error: 'not found' });
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}

function makeCtx(text, opts = {}) {
  const cleanContent = String(text).trim();
  const message = {
    id: 'MSG_' + Math.random().toString(36).slice(2, 8),
    kind: opts.kind || 'group',
    content: cleanContent,
    cleanContent,
    author: { id: 'u1', username: '测试', bot: false, member_openid: 'm1' },
    group_openid: opts.kind === 'c2c' ? '' : 'GROUP_1',
    user_openid: opts.kind === 'c2c' ? 'USER_1' : '',
    channel_id: '',
    command: parseCommand(cleanContent, ''),
  };

  const replies = [];
  const uploads = [];
  const api = {
    async call(key, payload) {
      uploads.push({ key, payload });
      if (opts.uploadFails) return { ok: false, code: 500, message: 'upload failed' };
      return { ok: true, data: { file_info: 'FILE_INFO_TEST' } };
    },
    async request(method, path, payload) {
      apiCalls.push({ method, path, body: payload?.body });
      if (path === '/v2/media-images/prepare') {
        if (opts.mediaFails) return { ok: false, code: 40035006, message: 'media prepare failed' };
        return { ok: true, data: { upload_id: 'UP_TEST', presigned_url: `${base}/presign`, expires_in: 3600 } };
      }
      if (path === '/v2/media-images/complete') {
        return { ok: true, data: { url: 'qqbot-media://image/v1/TEST', image_id: 'IMG_TEST', ttl: 7776000 } };
      }
      if (path === '/v2/media-images' && method === 'GET') {
        return { ok: true, data: { images: [], next_cursor: '', total: 0 } };
      }
      return { ok: true, data: {} };
    },
    async reply(msg, content) {
      replies.push({ msg, content });
      if (opts.replyFails) return { ok: false, code: 40034024, message: 'reply failed' };
      if (content.keyboard && opts.keyboardFails) return { ok: false, code: 11253, message: 'keyboard not allowed' };
      if (content.msg_type === 2 && opts.markdownFails) return { ok: false, code: 400, message: 'markdown failed' };
      return { ok: true, data: { id: 'SENT_' + replies.length } };
    },
    async me() {
      return { ok: true, data: { username: 'bot', avatar: '' } };
    },
  };

  const logs = [];
  const log = {
    info: (m) => logs.push(['info', m]),
    warn: (m) => logs.push(['warn', m]),
    error: (m) => logs.push(['error', m]),
    debug: (m) => logs.push(['debug', m]),
  };

  return {
    message,
    event: { name: 'GROUP_MESSAGE_CREATE', message },
    raw: {},
    api,
    bot: { info: () => ({}) },
    account: { id: 'main', name: '主账号' },
    plugin: {
      id: 'mcstatus',
      dir: '',
      config: {
        apiBase: base,
        key: 'mcst_test',
        frameTtlMs: 60000,
        httpTimeoutMs: opts.httpTimeoutMs || 12000,
        siteImage: 'https://www.jlworld.net/a.jpg',
        iconUrl: `${base}/icon.png`,
      },
    },
    framework: { version: 'test', dataDir: '' },
    log,
    replies,
    uploads,
    logs,
  };
}

function resultText(out) {
  if (!out) return '';
  if (out.reply) return out.reply;
  const list = out.replies || [];
  return list
    .map((r) => (r.type === 'markdown' ? r.markdown?.content || '' : r.content || ''))
    .join('\n');
}

function jsonOf(ctx) {
  const md = ctx.replies[0].content.markdown.content;
  const inner = md.replace(/^```json\n/, '').replace(/\n```$/, '');
  return { md, inner, data: JSON.parse(inner) };
}

const cases = [];
function test(name, fn) {
  cases.push({ name, fn });
}

/* ---------------- 用例 ---------------- */

test('菜单：/MC 顶部图标 + 标题无镐子 + 指令按钮', async () => {
  const ctx = makeCtx('/MC');
  await PLUGIN.onEvent(ctx);
  const content = ctx.replies[0].content;
  const md = content.markdown.content;
  assert.strictEqual(content.msg_type, 2);
  assert.ok(
    md.startsWith('![我的世界 #40px #40px](qqbot-media://image/v1/TEST)'),
    '图标应上传到素材库并放在第一行'
  );
  assert.ok(!md.includes('⛏️'), '标题不应带镐子 emoji');
  assert.ok(md.includes('## 我的世界服务器查询'));
  assert.ok(md.includes('/MC api'), '菜单缺少指令说明');

  const rows = content.keyboard?.content?.rows;
  assert.ok(Array.isArray(rows) && rows.length === 3, '按钮应有 3 行');
  const buttons = rows.flatMap((r) => r.buttons);
  assert.strictEqual(buttons.length, 5, '应有 5 个按钮');
  const datas = buttons.map((b) => b.action.data);
  assert.ok(datas.includes('/MC '), '缺少查询按钮');
  assert.ok(datas.includes('/MC api'), '缺少接口帮助按钮');
  for (const b of buttons) {
    assert.strictEqual(b.action.type, 2, '按钮应为指令按钮');
    assert.strictEqual(b.action.enter, false, '按钮只填入输入框');
    assert.strictEqual(b.render_data.style, 1, '按钮应为蓝色');
    assert.strictEqual(b.action.permission.type, 2, '所有人可点');
    assert.ok(b.action.unsupport_tips);
  }
  assert.strictEqual(buttons[4].render_data.label, '点我查询');
  assert.strictEqual(buttons[4].action.data, '/MC ');
});

test('不带 / 的聊天不处理', async () => {
  for (const text of ['MC mc.hypixel.net', 'mc mc.hypixel.net', '你好 MC', 'MC']) {
    const ctx = makeCtx(text);
    const out = await PLUGIN.onEvent(ctx);
    assert.strictEqual(out, null, `不应处理：${text}`);
    assert.strictEqual(ctx.replies.length, 0, `不应回复：${text}`);
  }
});

test('自定义指令：菜单与按钮跟随 config.commands', async () => {
  const ctx = makeCtx('/MC');
  ctx.plugin.config.commands = [
    { label: '查状态', command: '/MC ', note: '自定义备注A' },
    { label: '帮助', command: '/MC api', note: '自定义备注B' },
  ];
  await PLUGIN.onEvent(ctx);
  const content = ctx.replies[0].content;
  const md = content.markdown.content;
  assert.ok(md.includes('`/MC`：自定义备注A'), '菜单未使用自定义备注');
  assert.ok(md.includes('`/MC api`：自定义备注B'), '菜单未使用自定义指令');
  const buttons = content.keyboard.content.rows.flatMap((r) => r.buttons);
  assert.strictEqual(buttons.length, 3, '2 个指令 + 点我查询');
  assert.strictEqual(buttons[0].render_data.label, '查状态');
  assert.strictEqual(buttons[0].action.data, '/MC');
  assert.strictEqual(buttons[2].render_data.label, '点我查询');
});

test('设置页文件存在（面板可编辑指令 + 备注）', async () => {
  const fs = require('fs');
  const path = require('path');
  const file = path.join(__dirname, '..', '~JlWBoT', 'plugins', 'mcstatus', 'settings.html');
  assert.ok(fs.existsSync(file), '缺少 settings.html');
  const html = fs.readFileSync(file, 'utf8');
  for (const key of ['jlw-settings-init', 'jlw-settings-save-request', 'jlw-settings-save', 'commands']) {
    assert.ok(html.includes(key), `settings.html 缺少 ${key}`);
  }
});

test('自定义回复模板：status 变量渲染', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net');
  ctx.plugin.config.commands = [
    {
      type: 'status',
      label: '查询服务器',
      command: '/MC ',
      note: '图片查询',
      reply: '## {{address}}\n状态：{{online}}｜人数：{{players}}/{{maxPlayers}}｜{{edition}}\n\n{{image}}',
    },
  ];
  await PLUGIN.onEvent(ctx);
  const md = ctx.replies[0].content.markdown.content;
  assert.ok(md.includes('## mc.hypixel.net:25565'), '未渲染 address');
  assert.ok(md.includes('状态：在线'), '未渲染 online');
  assert.ok(md.includes('16853/200000'), '未渲染人数');
  assert.ok(md.includes('Java 版'), '未渲染 edition');
  assert.ok(md.includes('qqbot-media://image/v1/TEST'), '未渲染 image');
});

test('模板不含 {{image}} 时不上传素材', async () => {
  apiCalls.length = 0;
  const ctx = makeCtx('/MC mc.hypixel.net');
  ctx.plugin.config.commands = [
    { type: 'status', label: '查询服务器', command: '/MC ', note: '', reply: '地址 {{address}}（{{online}}）' },
  ];
  await PLUGIN.onEvent(ctx);
  const md = ctx.replies[0].content.markdown.content;
  assert.strictEqual(md, '地址 mc.hypixel.net:25565（在线）');
  assert.ok(!apiCalls.some((c) => c.path === '/v2/media-images/prepare'), '不应上传素材');
});

test('菜单模板：{{commands}} 与 {{icon}} 渲染', async () => {
  const ctx = makeCtx('/MC');
  ctx.plugin.config.commands = [
    { type: 'menu', label: '指令菜单', command: '/MC', note: '打开本菜单', reply: '## 自定义标题\n\n{{commands}}\n\n{{icon}}' },
  ];
  await PLUGIN.onEvent(ctx);
  const md = ctx.replies[0].content.markdown.content;
  assert.ok(md.includes('## 自定义标题'), '未渲染自定义标题');
  assert.ok(md.includes('`/MC`'), '未渲染 commands 列表');
  assert.ok(md.includes('![我的世界 #40px #40px](qqbot-media://image/v1/TEST)'), '未渲染 icon');
});

test('未配置 iconUrl 时不显示菜单图标', async () => {
  const ctx = makeCtx('/MC');
  delete ctx.plugin.config.iconUrl;
  await PLUGIN.onEvent(ctx);
  assert.ok(!ctx.replies[0].content.markdown.content.includes('!['), '未配置时不应渲染图标');
});

test('按钮发送失败：不降级，只尝试一次', async () => {
  const ctx = makeCtx('/MC', { keyboardFails: true });
  const out = await PLUGIN.onEvent(ctx);
  assert.strictEqual(out, null);
  assert.strictEqual(ctx.replies.length, 1, '只发一次 Markdown');
  assert.ok(ctx.replies[0].content.keyboard, '仍为带按钮的 Markdown');
});

test('图片查询：一条被动回复 = @用户 + 引用 + 状态图', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net');
  const out = await PLUGIN.onEvent(ctx);
  assert.strictEqual(out, null, '应直接发送并返回 null');
  assert.strictEqual(ctx.replies.length, 1, '只发一条被动回复');
  const content = ctx.replies[0].content;
  assert.strictEqual(content.msg_type, 2);
  const md = content.markdown.content;
  assert.ok(md.includes('<qqbot-at-user id="m1" />'), '缺少 @用户');
  assert.ok(
    /!\[服务器状态图 #760px #270px\]\(qqbot-media:\/\/image\/v1\/TEST\)/.test(md),
    '缺少状态图（应使用 qqbot-media 引用）'
  );
  assert.strictEqual(ctx.replies[0].msg.id, ctx.message.id, '带原消息 id → 客户端显示引用');
  assert.strictEqual(ctx.uploads.length, 0, '成功路径不应走富媒体上传');
  assert.ok(apiCalls.some((c) => c.path === '/v2/media-images/prepare'), '应调用素材 prepare');
  assert.ok(apiCalls.some((c) => c.path === '/v2/media-images/complete'), '应调用素材 complete');
});

test('素材上传失败：不降级，发重试提示', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net', { mediaFails: true });
  await PLUGIN.onEvent(ctx);
  const content = ctx.replies[0].content;
  assert.strictEqual(content.msg_type, 2);
  assert.ok(content.markdown.content.includes('状态图发送失败'), '应提示失败');
  assert.ok(content.keyboard, '应带重新查询按钮');
});

test('查询超时：失败提示 + 重新查询按钮（enter=true）', async () => {
  const ctx = makeCtx('/MC timeout.example.com', { httpTimeoutMs: 60 });
  const out = await PLUGIN.onEvent(ctx);
  assert.strictEqual(out, null);
  const content = ctx.replies[0].content;
  assert.strictEqual(content.msg_type, 2);
  assert.ok(content.markdown.content.includes('查询失败'), '缺少失败提示');
  const btn = content.keyboard.content.rows[0].buttons[0];
  assert.strictEqual(btn.render_data.label, '重新查询');
  assert.strictEqual(btn.action.data, '/MC timeout.example.com', '按钮 data 应为原指令');
  assert.strictEqual(btn.action.enter, true, '点击应自动发送');
  assert.strictEqual(btn.action.type, 2);
});

test('状态卡 Markdown 失败：不降级，发重试提示', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net', { markdownFails: true });
  await PLUGIN.onEvent(ctx);
  assert.strictEqual(ctx.replies.length, 2, '模板失败后补一条重试提示');
  assert.strictEqual(ctx.replies[1].content.msg_type, 2, '仍只发 Markdown');
  assert.ok(ctx.replies[1].content.markdown.content.includes('状态图发送失败'));
});

test('素材与 Markdown 都失败：仍只发 Markdown', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net', { markdownFails: true, mediaFails: true });
  await PLUGIN.onEvent(ctx);
  assert.strictEqual(ctx.replies[0].content.msg_type, 2);
});

test('随机底图：image 请求的 frame 来自 frames 列表', async () => {
  requests.length = 0;
  const ids = new Set(['inventory', 'nether', 'end']);
  for (let i = 0; i < 10; i++) {
    const ctx = makeCtx('/MC mc.hypixel.net');
    await PLUGIN.onEvent(ctx);
  }
  const imageReqs = requests.filter((r) => r.url === '/api/plugin/mcstatus/image');
  assert.ok(imageReqs.length >= 10, '应请求图片接口');
  for (const r of imageReqs) assert.ok(ids.has(r.body.frame), `frame 不在列表：${r.body.frame}`);
});

test('JSON 模式：/MC 地址 -json 返回 ```json 代码块', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net -json');
  await PLUGIN.onEvent(ctx);
  const { inner, data } = jsonOf(ctx);
  assert.ok(ctx.replies[0].content.markdown.content.startsWith('```json'));
  assert.strictEqual(data.online, true);
  assert.strictEqual(data.edition, 'java');
  assert.ok(inner.length < 1800, `JSON 过长：${inner.length}`);
  assert.ok(!/A{5000}/.test(inner), 'iconUrl 应被截断');
  assert.strictEqual(ctx.replies.length, 1);
});

test('大小写：/mc 同样触发', async () => {
  const ctx = makeCtx('/mc mc.hypixel.net');
  await PLUGIN.onEvent(ctx);
  assert.strictEqual(ctx.replies.length, 1);
  assert.ok(ctx.replies[0].content.markdown.content.includes('<qqbot-at-user'));
});

test('端口解析：地址带端口', async () => {
  const ctx = makeCtx('/MC play.example.com:25566 -json');
  await PLUGIN.onEvent(ctx);
  assert.strictEqual(jsonOf(ctx).data.port, 25566);
});

test('基岩版：自动识别', async () => {
  const ctx = makeCtx('/MC bedrock.example.com -json');
  await PLUGIN.onEvent(ctx);
  assert.strictEqual(jsonOf(ctx).data.edition, 'bedrock');
});

test('api 帮助：含网站图片与接口文档代码块', async () => {
  const ctx = makeCtx('/MC api');
  await PLUGIN.onEvent(ctx);
  const md = ctx.replies[0].content.markdown.content;
  assert.ok(md.includes('mcstatus/image'), '缺少图片接口地址');
  assert.ok(md.includes('```json'), '缺少请求示例代码块');
  assert.ok(md.includes('![聚龙世界]'), '缺少网站图片');
  assert.ok(md.includes('frames'), '缺少模板列表接口');
});

test('错误回退：地址不存在返回 JSON 错误 + 重新查询按钮', async () => {
  const ctx = makeCtx('/MC not-exist.example.com -json');
  await PLUGIN.onEvent(ctx);
  const { data } = jsonOf(ctx);
  assert.strictEqual(data.ok, false);
  assert.ok(String(data.error).length > 0);
  const btn = ctx.replies[0].content.keyboard.content.rows[0].buttons[0];
  assert.strictEqual(btn.render_data.label, '重新查询');
  assert.strictEqual(btn.action.data, '/MC not-exist.example.com -json');
  assert.strictEqual(btn.action.enter, true);
});

test('菜单 Markdown 发送失败：不降级', async () => {
  const ctx = makeCtx('/MC', { replyFails: true });
  const out = await PLUGIN.onEvent(ctx);
  assert.strictEqual(out, null);
  assert.strictEqual(ctx.replies.length, 1, '只尝试一次 Markdown');
});

test('单聊场景：Markdown + qqbot-media 图片（无 @）', async () => {
  const ctx = makeCtx('/MC mc.hypixel.net', { kind: 'c2c' });
  await PLUGIN.onEvent(ctx);
  const content = ctx.replies[0].content;
  assert.strictEqual(content.msg_type, 2);
  const md = content.markdown.content;
  assert.ok(md.includes('qqbot-media://image/v1/TEST'), '单聊也应使用素材库图片');
  assert.ok(!md.includes('<qqbot-at-user'), '单聊不支持 @ 标签');
});

/* ---------------- 运行 ---------------- */

(async () => {
  const port = await startMock();
  base = `http://127.0.0.1:${port}`;
  let pass = 0;
  let fail = 0;
  for (const c of cases) {
    try {
      await c.fn();
      pass++;
      console.log(`  PASS  ${c.name}`);
    } catch (e) {
      fail++;
      console.log(`  FAIL  ${c.name}\n        ${e.message}`);
    }
  }
  await new Promise((resolve) => server.close(resolve));
  console.log(`\n${pass} passed, ${fail} failed, ${cases.length} total`);
  process.exitCode = fail ? 1 : 0;
})();
