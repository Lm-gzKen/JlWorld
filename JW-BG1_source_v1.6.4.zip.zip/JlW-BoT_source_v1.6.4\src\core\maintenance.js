'use strict';
/**
 * 定时重启配置：读配置、算下次时间。
 * 实际定时器在 src/index.js 里，这里只放可单测的纯函数。
 */

const MIN_MINUTES = 1;
const MAX_MINUTES = 7 * 24 * 60; // 最多 7 天

function normalizeRestart(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const n = Math.floor(Number(src.minutes));
  const minutes = Number.isFinite(n) && n >= MIN_MINUTES ? Math.min(n, MAX_MINUTES) : 0;
  return {
    enabled: !!src.enabled && minutes > 0,
    minutes,
  };
}

function readRestartConfig(config) {
  try {
    return normalizeRestart(config?.get?.('system.restart', null));
  } catch {
    return { enabled: false, minutes: 0 };
  }
}

function nextRestartAt(minutes, now = Date.now()) {
  const m = Math.floor(Number(minutes));
  if (!Number.isFinite(m) || m < MIN_MINUTES) return 0;
  return now + m * 60000;
}

/** 距离下次重启还有多久（毫秒），没有计划返回 0 */
function msUntil(nextAt, now = Date.now()) {
  const t = Number(nextAt);
  if (!Number.isFinite(t) || t <= 0) return 0;
  return Math.max(0, t - now);
}

function describeRestart(info) {
  if (!info?.enabled) return '未启用定时重启';
  return `每 ${info.minutes} 分钟重启一次`;
}

module.exports = {
  MIN_MINUTES,
  MAX_MINUTES,
  normalizeRestart,
  readRestartConfig,
  nextRestartAt,
  msUntil,
  describeRestart,
};
