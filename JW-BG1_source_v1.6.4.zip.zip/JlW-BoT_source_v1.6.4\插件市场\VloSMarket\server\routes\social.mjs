// 评论（两层：留言 + 回复）与站内消息（右上角铃铛）。
import { HttpError } from '../http.mjs';
import { maskMail } from './auth.mjs';
import { isAdmin } from '../roles.mjs';

function s(v, max) {
  return String(v == null ? '' : v).trim().slice(0, max);
}

const lastComment = new Map();

export default function register(router) {
  // ---------------- 评论列表 ----------------
  router.get('/api/plugins/:id/comments', (c) => {
    const p = c.store.get('SELECT id, email, offline FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    const isOwner = !!c.user && c.user.email === p.email;
    if (p.offline && !isOwner && !isAdmin(c.store, c.user)) throw new HttpError(403, '该插件已被管理员下架');

    const rows = c.store.all(
      'SELECT * FROM comments WHERE plugin_id=? AND deleted=0 ORDER BY created ASC, id ASC LIMIT 500',
      p.id
    );
    const byId = new Map(rows.map((r) => [r.id, r]));

    const shape = (r) => ({
      id: r.id,
      body: r.body,
      created: r.created,
      author: maskMail(r.email),
      isOwner: r.email === p.email,
      canDelete: isOwner || (!!c.user && c.user.email === r.email),
      replies: [],
    });

    const threads = new Map(rows.map((r) => [r.id, shape(r)]));
    const itemById = new Map([...threads.values()].map((item) => [item.id, item]));
    const roots = [];
    // 两遍组装：先建所有节点，再挂回复。这样即使父子时间戳相同、排序不保证，也不会把回复变成顶层
    for (const r of rows) {
      const item = threads.get(r.id);
      const parent = r.parent_id ? itemById.get(r.parent_id) : null;
      if (parent) {
        const target = byId.get(r.reply_to) || byId.get(r.parent_id);
        if (target) {
          item.replyTo = maskMail(target.email);
          item.replyToIsOwner = target.email === p.email;
        }
        parent.replies.push(item);
      } else {
        // 父评论被删了就当成顶层显示，内容不丢
        roots.push(item);
      }
    }
    roots.reverse(); // 最新的评论排最上面，回复内部保持时间正序

    return { items: roots, total: rows.length };
  });

  // ---------------- 发表评论 / 回复（同时给作者发消息）----------------
  router.post('/api/plugins/:id/comments', async (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.offline && p.email !== u.email && !isAdmin(c.store, u)) throw new HttpError(403, '该插件已被管理员下架');

    const b = await c.json();
    const body = s(b.body, 1000);
    if (!body) throw new HttpError(400, '留言内容不能为空');

    let parentId = 0;
    let replyTo = 0;
    let repliedEmail = '';
    const wantParent = Number(b.parentId) || 0;
    if (wantParent) {
      const parent = c.store.get('SELECT * FROM comments WHERE id=? AND plugin_id=? AND deleted=0', wantParent, p.id);
      if (!parent) throw new HttpError(400, '要回复的那条留言不存在或已被删除');
      parentId = parent.parent_id || parent.id;
      replyTo = parent.id;
      repliedEmail = parent.email;
    }

    const key = u.email + '|' + p.id;
    const now = Date.now();
    const last = lastComment.get(key) || 0;
    // 注意别写成 `Number(x) || 15`：配成 0（关闭冷却）会被当成 falsy 退回 15 秒
    const cd = Number(c.cfg.commentCooldownSec);
    const cooldown = Number.isFinite(cd) ? cd : 15;
    const wait = cooldown > 0 ? Math.ceil((last + cooldown * 1000 - now) / 1000) : 0;
    if (wait > 0) throw new HttpError(429, `留言太快了，请 ${wait} 秒后再发`);
    lastComment.set(key, now);

    const r = c.store.run(
      'INSERT INTO comments (plugin_id, email, body, created, parent_id, reply_to) VALUES (?,?,?,?,?,?)',
      p.id,
      u.email,
      body,
      now,
      parentId,
      replyTo
    );
    const commentId = Number(r.lastInsertRowid);

    const head = replyTo ? `回复 @${maskMail(repliedEmail)}：` : '';
    const recipients = new Set();
    if (p.email && p.email !== u.email) recipients.add(p.email);
    if (replyTo && repliedEmail && repliedEmail !== u.email) recipients.add(repliedEmail);
    for (const to of recipients) {
      c.store.run(
        'INSERT INTO messages (to_email, plugin_id, comment_id, kind, body, created) VALUES (?,?,?,?,?,?)',
        to,
        p.id,
        commentId,
        replyTo ? 'reply' : 'comment',
        head + body,
        now
      );
    }

    return {
      ok: true,
      comment: {
        id: commentId,
        body,
        created: now,
        author: maskMail(u.email),
        isOwner: u.email === p.email,
        canDelete: true,
        parentId,
        replyTo,
        replyToAuthor: replyTo ? maskMail(repliedEmail) : '',
      },
    };
  });

  // ---------------- 删除评论 ----------------
  router.delete('/api/comments/:id', (c) => {
    const u = c.mustUser();
    const cm = c.store.get('SELECT * FROM comments WHERE id = ?', Number(c.params.id));
    if (!cm) throw new HttpError(404, '留言不存在');
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', cm.plugin_id);
    if (cm.email !== u.email && (!p || p.email !== u.email) && !isAdmin(c.store, u)) {
      throw new HttpError(403, '无权删除该留言');
    }
    c.store.run('UPDATE comments SET deleted=1 WHERE id=?', cm.id);
    return { ok: true };
  });

  // ---------------- 消息列表 ----------------
  router.get('/api/messages', (c) => {
    const u = c.mustUser();
    const limit = Math.min(200, Math.max(1, Number(c.query.get('limit')) || 200));
    const rows = c.store.all(
      "SELECT * FROM messages WHERE to_email=? AND kind NOT IN ('review','report','devreply','role') ORDER BY created DESC LIMIT ?",
      u.email,
      limit
    );
    const unread = c.store.get(
      "SELECT COUNT(*) AS n FROM messages WHERE to_email=? AND is_read=0 AND kind NOT IN ('review','report','devreply','role')",
      u.email
    ).n;
    return {
      unread,
      items: rows.map((m) => {
        const p = m.plugin_id ? c.store.get('SELECT id, name, version FROM plugins WHERE id=?', m.plugin_id) : null;
        const cm = m.comment_id ? c.store.get('SELECT email FROM comments WHERE id=?', m.comment_id) : null;
        return {
          id: m.id,
          kind: m.kind,
          pluginId: m.plugin_id,
          pluginName: p ? p.name : m.plugin_id ? '(插件已删除)' : '系统通知',
          pluginVersion: p ? p.version : '',
          body: m.body,
          created: m.created,
          isRead: !!m.is_read,
          from: cm ? cm.email : '',
          fromMasked: cm ? maskMail(cm.email) : '',
        };
      }),
    };
  });

  // ---------------- 标记已读 ----------------
  router.post('/api/messages/read', async (c) => {
    const u = c.mustUser();
    const b = await c.json();
    const ids = Array.isArray(b.ids) ? b.ids.map((x) => Number(x)).filter((x) => Number.isFinite(x)) : [];
    if (!ids.length) {
      c.store.run('UPDATE messages SET is_read=1 WHERE to_email=?', u.email);
    } else {
      for (const id of ids) c.store.run('UPDATE messages SET is_read=1 WHERE id=? AND to_email=?', id, u.email);
    }
    const unread = c.store.get('SELECT COUNT(*) AS n FROM messages WHERE to_email=? AND is_read=0', u.email).n;
    return { ok: true, unread };
  });
}
