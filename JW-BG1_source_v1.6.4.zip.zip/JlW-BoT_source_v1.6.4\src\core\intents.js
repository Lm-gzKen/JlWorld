'use strict';
/**
 * QQ 机器人事件订阅（Intents）元数据
 * 单一来源：网关掩码、面板分组/中文名、无权限自动回退都从这里取
 */
const LIST = [
  { name: 'GUILDS', bit: 1 << 0, group: '频道', label: '频道基础', desc: '频道创建 / 更新 / 删除', risk: false },
  { name: 'GUILD_MEMBERS', bit: 1 << 1, group: '频道', label: '频道成员', desc: '成员加入 / 资料变更 / 移除', risk: false },
  { name: 'GUILD_MODERATION', bit: 1 << 2, group: '频道', label: '频道管理', desc: '频道审计等管理事件', risk: true },
  { name: 'GUILD_EMOJIS_AND_STICKERS', bit: 1 << 3, group: '频道', label: '频道表情与贴纸', desc: '表情、贴纸变更', risk: true },
  { name: 'GUILD_VOICE_STATES', bit: 1 << 6, group: '频道', label: '频道语音状态', desc: '语音频道进出状态', risk: true },
  { name: 'GUILD_MESSAGES', bit: 1 << 9, group: '频道', label: '频道全量消息', desc: '频道内全部消息（仅私域机器人）', risk: true },
  { name: 'GUILD_MESSAGE_REACTIONS', bit: 1 << 10, group: '频道', label: '频道表情表态', desc: '消息表情表态添加 / 移除', risk: false },
  { name: 'DIRECT_MESSAGE', bit: 1 << 12, group: '频道', label: '频道私信', desc: '用户与机器人的频道私信', risk: false },
  { name: 'PUBLIC_GUILD_MESSAGES', bit: 1 << 30, group: '频道', label: '频道 @ 消息', desc: '公域频道里 @ 机器人的消息', risk: false },
  { name: 'MESSAGE_AUDIT', bit: 1 << 27, group: '频道', label: '消息审核结果', desc: '消息审核通过 / 拒绝（需申请）', risk: true },
  { name: 'FORUMS_EVENT', bit: 1 << 28, group: '频道', label: '论坛事件', desc: '主题 / 帖子 / 评论（仅私域）', risk: true },
  { name: 'AUDIO_ACTION', bit: 1 << 29, group: '频道', label: '音频房事件', desc: '上麦 / 下麦 / 播放（需申请）', risk: true },
  { name: 'GROUP_MEMBER_EVENT', bit: 1 << 24, group: '群聊 / 单聊', label: '群成员与入群申请', desc: '成员加入 / 退出、用户申请加群（2026-08 新增）', risk: false },
  { name: 'GROUP_AND_C2C_EVENT', bit: 1 << 25, group: '群聊 / 单聊', label: '群聊与单聊消息', desc: '群 @ 消息、单聊消息、好友与进退群事件', risk: false },
  { name: 'INTERACTION', bit: 1 << 26, group: '互动', label: '互动事件', desc: '按钮回调、指令面板等互动', risk: false },
];

const BY_NAME = new Map(LIST.map((i) => [i.name, i]));
const SAFE = [
  'GUILDS',
  'GUILD_MEMBERS',
  'GUILD_MESSAGE_REACTIONS',
  'DIRECT_MESSAGE',
  'GROUP_MEMBER_EVENT',
  'GROUP_AND_C2C_EVENT',
  'PUBLIC_GUILD_MESSAGES',
  'INTERACTION',
];
const GROUPS = [...new Set(LIST.map((i) => i.group))];

function mask(names) {
  let m = 0;
  for (const n of names || []) {
    if (BY_NAME.has(n)) m |= BY_NAME.get(n).bit;
    else if (/^\d+$/.test(String(n))) m |= Number(n);
  }
  return m >>> 0;
}

module.exports = { LIST, BY_NAME, SAFE, GROUPS, mask };
