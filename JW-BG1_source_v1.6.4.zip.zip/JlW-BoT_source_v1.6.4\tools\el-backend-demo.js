'use strict';
/**
 * 易语言后端「参考实现」—— 拉取模式（format=text）
 *
 * 这个脚本演示了易语言宿主 EXE 需要做的全部事情：
 *   1. 长轮询 GET /plugin-api/v1/pull?format=text
 *   2. 解析 key=value 文本块
 *   3. 用表单 POST /plugin-api/v1/action 回动作
 *
 * 易语言侧照着这个流程写即可，JSON 都用不上。
 *
 * 用法：
 *   node tools/el-backend-demo.js --url http://127.0.0.1:8686 --token <插件令牌> --plugin el-sample
 * 或由框架自动拉起（plugin.json type=process / dll）时，读取环境变量：
 *   JLW_FRAMEWORK_URL / JLW_PLUGIN_TOKEN / JLW_PLUGIN_ID
 */
const args = process.argv.slice(2);
function arg(name, def) {
  const i = args.indexOf('--' + name);
  return i >= 0 ? args[i + 1] : def;
}

const BASE = arg('url', process.env.JLW_FRAMEWORK_URL || 'http://127.0.0.1:8686').replace(/\/+$/, '');
const TOKEN = arg('token', process.env.JLW_PLUGIN_TOKEN || '');
const PLUGIN = arg('plugin', process.env.JLW_PLUGIN_ID || 'el-sample');

if (!TOKEN) {
  console.error('缺少插件令牌：--token 或 JLW_PLUGIN_TOKEN');
  process.exit(1);
}

const headers = { Authorization: 'Bearer ' + TOKEN };

function unescapeText(s) {
  return String(s || '')
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\\\/g, '\\');
}

function parseBlocks(text) {
  const blocks = [];
  for (const chunk of String(text).split(/\r?\n---\r?\n|\r?\n---$/)) {
    const obj = {};
    for (const line of chunk.split(/\r?\n/)) {
      const i = line.indexOf('=');
      if (i <= 0) continue;
      const k = line.slice(0, i);
      if (k === '#' || k.startsWith('#')) continue;
      obj[k] = unescapeText(line.slice(i + 1));
    }
    if (obj.event && obj.event !== 'NONE') blocks.push(obj);
  }
  return blocks;
}

async function pull() {
  const url = `${BASE}/plugin-api/v1/pull?plugin=${encodeURIComponent(PLUGIN)}&timeout=25000&format=text`;
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(35000) });
  if (!res.ok) throw new Error('拉取失败 HTTP ' + res.status);
  return parseBlocks(await res.text());
}

async function action(fields) {
  const body = new URLSearchParams({ plugin: PLUGIN, ...fields }).toString();
  const res = await fetch(`${BASE}/plugin-api/v1/action`, {
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(20000),
  });
  return res.json();
}

async function handle(e) {
  console.log(`[事件] ${e.account_name || e.account_id} ${e.chat_type} ${e.user_name || e.user_id}：${e.content}`);
  const text = (e.content || '').trim();

  if (text.includes('天气')) {
    const city = e.args || text.replace(/.*天气\s*/, '') || '本地';
    await action({
      accountId: e.account_id || '',
      action: 'reply',
      chat_type: e.chat_type,
      group_openid: e.group_openid || '',
      user_openid: e.user_openid || '',
      msg_id: e.msg_id || '',
      content: `【易语言后端】${city} 今天晴，22℃，适合出门。\n（这条回复来自 tools/el-backend-demo.js）`,
    });
    console.log('  → 已回复天气');
  } else if (text.includes('签到')) {
    await action({
      accountId: e.account_id || '',
      action: 'send_group_message',
      group_openid: e.group_openid || '',
      content: '签到成功（主动消息，注意频控）',
      msg_id: e.msg_id || '',
    });
    console.log('  → 已发送签到消息');
  } else {
    console.log('  → 未命中命令，忽略');
  }
}

(async () => {
  console.log(`易语言参考后端已启动：${BASE}  plugin=${PLUGIN}`);
  for (;;) {
    try {
      const events = await pull();
      for (const e of events) {
        try {
          await handle(e);
        } catch (err) {
          console.error('处理失败：', err.message);
        }
      }
    } catch (e) {
      console.error('循环异常：', e.message);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
})();
