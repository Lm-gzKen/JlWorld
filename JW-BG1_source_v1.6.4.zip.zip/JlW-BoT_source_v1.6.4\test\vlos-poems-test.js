'use strict';
/**
 * VloS 诗词库工具自测（编码识别 / 清洗 / 导入 / 导出）
 *
 * 运行：node test/vlos-poems-test.js
 */

const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');

const poems = require(path.join(__dirname, '..', 'plugins', 'VloS', 'tools', 'poems.js'));

const TMP = path.join(__dirname, '.tmp-vlos-poems');
let pass = 0;
let fail = 0;

function eq(a, b, msg) {
  assert.strictEqual(a, b, msg);
}
function ok(v, msg) {
  assert.ok(v, msg);
}
function check(name, fn) {
  try {
    fn();
    pass++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    fail++;
    console.log(`  ✗ ${name}\n      ${e.message}`);
  }
}

fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(TMP, { recursive: true });

check('normalizePoems：去 BOM / 空行 / 注释 / 重复 / 统一空格', () => {
  const r = poems.normalizePoems('\uFEFF甲——A\r\n\r\n# 注释\r\n甲——A\r\n乙——B\r\n');
  eq(r.lines.length, 2);
  eq(r.lines[0], '甲——A');
  eq(r.lines[1], '乙——B');
  eq(r.stats.comments, 1);
  eq(r.stats.duplicates, 1);
  eq(r.stats.empty, 2);
  eq(r.stats.missingSeparator, 0);
});

check('decodePoemBuffer：UTF-8 BOM', () => {
  const r = poems.decodePoemBuffer(Buffer.from('\uFEFF甲——A\n', 'utf8'));
  eq(r.encoding, 'utf-8-bom');
  ok(!r.text.startsWith('\uFEFF'));
  ok(r.text.includes('甲——A'));
});

check('decodePoemBuffer：GBK（腾讯/旧版 VloSBoT 的编码）', () => {
  const buf = Buffer.from(
    'CCECD0D0BDA1A3ACBEFDD7D3D2D4D7D4C7BFB2BBCFA2A1A3A1AAA1AAA1B6D6DCD2D7A1B7',
    'hex',
  );
  const r = poems.decodePoemBuffer(buf);
  eq(r.encoding, 'gbk');
  ok(r.text.includes('天行健，君子以自强不息。——《周易》'), 'GBK 解码内容不对：' + r.text);
});

check('decodePoemBuffer：纯 UTF-8 中文', () => {
  const r = poems.decodePoemBuffer(Buffer.from('乙——B\n', 'utf8'));
  eq(r.encoding, 'utf-8');
});

check('importPoems：清洗后写每日诗词.txt + poems.txt（UTF-8 无 BOM）', () => {
  const src = path.join(TMP, 'input.txt');
  fs.writeFileSync(src, '\uFEFF甲——A\r\n\r\n乙——B\r\n甲——A\r\n', 'utf8');
  const outDir = path.join(TMP, 'out');
  const r = poems.importPoems({ source: src, outDir });
  eq(r.count, 2);
  eq(r.encoding, 'utf-8-bom');
  const daily = path.join(outDir, '每日诗词.txt');
  const compat = path.join(outDir, 'poems.txt');
  ok(fs.existsSync(daily) && fs.existsSync(compat));
  const buf = fs.readFileSync(daily);
  ok(!(buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf), '输出不能带 BOM');
  const text = buf.toString('utf8');
  eq(text, '甲——A\n乙——B\n');
  eq(fs.readFileSync(compat, 'utf8'), text);
});

check('exportPoems：导出 UTF-8 文件', () => {
  const source = path.join(TMP, 'out', '每日诗词.txt');
  const dest = path.join(TMP, 'export', '诗词导出.txt');
  const r = poems.exportPoems({ source, dest });
  eq(r.count, 2);
  eq(fs.readFileSync(dest, 'utf8'), '甲——A\n乙——B\n');
});

check('checkPoems：统计行数与内容', () => {
  const r = poems.checkPoems(path.join(TMP, 'out', '每日诗词.txt'));
  eq(r.count, 2);
  eq(r.lines[0], '甲——A');
  eq(r.stats.duplicates, 0);
});

console.log(`\n${pass} passed, ${fail} failed, ${pass + fail} total`);
if (fail) process.exitCode = 1;
