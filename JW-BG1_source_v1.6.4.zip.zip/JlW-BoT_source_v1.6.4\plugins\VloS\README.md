﻿# VloS · 聚龙世界（JlWBoT 插件 v2.9.62）

聚龙账户注册 / 登录 / QQ 绑定 · 个人资料 · 每日签到（随机诗词 / 龙晶 / 玄玉 / 方舟掉落）· 菜单 / 指令 / 群管 / 进退群 / 用户。

- 插件 ID：`VloS`，类型：进程内 JS（`type: js`），零 npm 依赖
- 账号体系：**聚龙账户 API**（`/api/plugin/jl-account/*`），插件不再发邮件
- 数据目录：VSQL 的 `~JlWBoT/plugins/VSQL/data/dbs/shared.db`（`vlos_users` / `vlos_aliases` / `vlos_sign_history`）；本插件 `data/` 只放诗词、回调、菜单指纹；没有 VSQL 时回退 `data/users.json`
- 后台设置页：面板「插件 → VloS → 编辑 → 设置」（聚龙账户 / 签到与掉落 / 菜单 / 指令 / 群管 / 进退群 / 用户 / 说明）

![VloS 聚龙账户设置](preview/settings-account.png)

---

## 1. 指令

| 指令 | 说明 |
| --- | --- |
| `/add 邮箱` | **私聊**注册聚龙账户：发送邮箱验证码 → 用户发 6 位码 → 密码 → 显示名称 → `register` |
| `/login 邮箱 密码` | **私聊**登录已有聚龙账户；`/add` 发现邮箱已注册时会提示用这个 |
| `/bindqq QQ号` | 绑定 QQ：**一条指令直接发注册邮箱验证码**（不再需要 `/bindqq QQ号 确认`）；绑定后无法修改，验证码发到聚龙注册邮箱 |
| `/bindopenid` | 保存 OpenID 到聚龙账户（群聊 / 私聊都可以；需已登录 + 已绑 QQ；Key 异常时返回字符串供手动填写） |
| `/list` | 聚龙账户头像 / 名称 / 邮箱 / 绑定 QQ / 聚龙钱包 / 插件签到账本 / 签到统计 |
| `/签到` | 随机诗词 + 当前时间 + 随机龙晶 + 概率玄玉 + 方舟签到掉落，整条 Markdown |
| `/菜单` | 按场景显示面板「菜单」配置；名称是 QQ Markdown 指令标签，点击填入输入框（私聊默认直接发送） |
| `/菜单同步` | **私聊**把面板「菜单」配置同步到 QQ 群指令面板 / 私聊全局菜单，每分钟 1 次 |
| `/群管` | **群里**群主 / 管理员自定义本群进退群与群管：生成一次性网页，提交后由机器人管理员在设置页「审核」 |
| `/cancel` | 取消当前注册 / QQ 绑定流程 |
| `/vlos` | 帮助与绑定人数；指令列表里的每个指令（含别名）都是蓝色可点击标签，群里填入输入框、私聊可直接发送 |

### 1.1 注册流程

```text
/add user@example.com        （私聊）
  → 聚龙 send-code 发 6 位验证码到邮箱
  → 用户直接发验证码
  → 用户发密码（至少 6 位，私聊）
  → 用户发显示名称（2–20 字）
  → 插件调 register，保存 token
  → 注册成功
```

- 如果邮箱已注册，`send-code` / `register` 会返回「邮箱已注册 / 已被使用」，插件提示：
  `/login 邮箱 密码`
- 密码只在注册流程的内存里短暂停留，**不写入数据库 / users.json**；但框架的消息记录可能仍保存你发出的消息，请尽量私聊。
- 一个 QQ 用户（openid）只能绑定一个聚龙账户。

### 1.2 登录

```text
/login user@example.com 你的密码   （私聊）
```

成功后保存 token（默认 30 天）和资料缓存。token 过期后 `/list`、`/签到`、`/bindqq` 会提示重新登录。

### 1.3 绑定 QQ

```text
/bindqq 3407556894
  → 聚龙 qq-send-code 直接发送 6 位验证码到注册邮箱（不是 QQ 邮箱）
  → 回复里提示：绑定后无法修改 / 解绑
  → 用户直接发 6 位验证码
  → 聚龙 qq-bind 绑定成功
```

- 已绑定：直接提示「您已绑定 QQ xxx（不可修改）」。
- 这个 QQ 已被其他聚龙账户使用：提示换一个。
- 没有解绑接口；确实要换只能联系管理员处理。

### 1.4 保存 OpenID

聚龙账户新增了 `key/openid` 接口（需要 Key 有 `openid` 权限，且目标账号已绑 QQ）：

```text
/bindopenid        （群聊 / 私聊都可以；需已登录聚龙账户 + 已绑 QQ）
```

- 机器人把当前会话的 OpenID（优先 `union_openid`，其次私聊 `user_openid`）通过 `key/openid` 写入聚龙账户；
- 写入成功后 `user.openid` / `user.openidBoundAt` 会随登录 / me 返回；
- 已填写时再次 `/bindopenid` 会同时显示「聚龙账户 OpenID」和「当前会话 OpenID」，方便核对是否一致；
- **填写后不可修改**，一个 OpenID 只能填到一个账号；不一致只能联系管理员清空后重填；
- 通过机器人完成 `/bindqq` 后，会自动尝试保存 OpenID（注册时如果账户已经绑了 QQ，也会尝试）；
- Key 没有 `openid` 权限 / Key 失效 / 网络异常：机器人会直接返回这串 OpenID，让用户到聚龙账户中心「个人设置 → OpenID」手动填写（文档兜底流程）。

---

## 2. 部署

```text
<框架根>/~JlWBoT/plugins/VloS/
├─ plugin.json          # 元数据 + config
├─ index.js             # 指令 / 流程 / 签到 / 方舟联动
├─ api.js               # 对外 API（绑定信息 / 钱包 / 签到账本）
├─ lib/
│  ├─ jlaccount.js      # 聚龙账户 HTTP 客户端
│  ├─ store.js          # SQLite（VSQL）用户表 / token / 钱包缓存 / 签到账本，回退 users.json
│  ├─ defaults.js       # 默认配置 / 默认诗词
│  └─ text.js           # 时间 / 随机 / 转义
├─ data/
│  ├─ 每日诗词.txt      # 诗词库主文件（UTF-8，313 首）
│  ├─ poems.txt         # 旧版兼容副本
│  └─ users.json        # 仅回退 / 迁移源（VSQL 就绪后自动导入 shared.db）
├─ settings.html        # 后台设置页
├─ api.html             # 插件 API 文档
├─ preview/             # 设置页预览图
└─ tools/
   ├─ poems.js          # 诗词导入导出
   └─ build-manifest.js # 重新生成 plugin.json
```

校验：

```bash
node test/vlos-test.js        # 主流程（假聚龙账户 API，60 项）
node test/vlos-poems-test.js  # 诗词工具
```

> **升级只复制代码文件**（`index.js` / `settings.html` / `api.js` / `api.html` / `lib/` / `README.md` / `package.json`）。运行目录的 `plugin.json` 是线上配置（聚龙 Key、`groups`、`callbackReviews`、欢迎语），用导出包模板覆盖会清空 Key 和已审核群覆盖。
>
> 本机一条命令：`node tools/deploy-vlos.js`（只复制上面这些文件并调面板热重载，只同步线上 `plugin.json` 的 `version` 字段，`--dry` 只预览）。云端更新：面板「插件 → VloS → 更新」导入 `插件\VloS-【v2.9.62】.zip`，框架保留 `config`、替换清单（`events` 会带上 `INTERACTION_CREATE`）。

---

## 3. 后台设置页

面板「插件 → VloS → 编辑 → 设置」：

### 3.1 聚龙账户

- **站点地址**：默认 `https://www.jlworld.net`
- **接口路径**：默认 `/api/plugin/jl-account`
- **超时**：默认 20000 ms
- **发奖 Key**：`jlkey_...`，用于把签到奖励写入聚龙钱包
  - 必须由聚龙后台「Key 管理」授予 `currency-add`（签到）和 `openid`（保存 OpenID）；扣除需要 `currency-sub`
  - 只保存在本机 `plugin.json`，不通过 QQ 发送
  - 输入框留空 = 保持原 Key；勾选「清除」可移除
- **跳过 TLS 证书校验**：仅自签名 / 内网测试使用

### 3.2 签到与掉落

- 龙晶 `最少 ~ 最多`，每次随机整数
- 玄玉 `概率% + 最少 ~ 最多`
- **签到奖励写入聚龙钱包**：
  - 开：用发奖 Key 调 `currency-add`，成功后写聚龙钱包
  - 关：写插件签到账本（`vlos_users.balances_lj / balances_xy`）
- 开但发奖 Key 异常 / 未配置：奖励记入 VloS余额（存储字段 `pendingWallet`），卡片显示「VloS余额」；Key 恢复后下次签到一并入账
- 每天一次、方舟签到开关、方舟超时、头像尺寸、站点链接、生效账户 ID

### 3.3 菜单

![菜单设置](preview/settings-menu.png)

- **群聊通用菜单**：保存后同步成 QQ 群「指令面板」（`scope=group`、`target_type=all`，备注固定 `VloS 菜单`）。群成员点一下就把「指令」填进输入框。最多 20 项，名称 ≤14 字符、说明 ≤30 字符。
- **私聊通用菜单**：保存后调 `PUT /v2/menu` 全量覆盖全局自定义菜单（仅单聊生效，最多 10 项，名称按 1 汉字 = 2 字符算）。
- **聊天里的菜单**：`/菜单` 不再输出纯文本，而是 QQ Markdown 指令标签——群聊用 `<qqbot-cmd-input>`（蓝字名称，点击把指令填进输入框）；私聊默认 `<qqbot-cmd-enter>`（点击直接发送），可在「点击后自动发送（仅私聊）」关掉。
- **保存后自动同步**：菜单配置的签名没变化时不会重复删建面板；也可以私聊机器人发 `/菜单同步` 手动重试（每分钟 1 次）。
- 同步失败会在插件日志里留 `VloS 菜单同步：…`，不影响签到等其它功能。

### 3.4 指令

![指令设置](preview/settings-commands.png)

![指令默认回复](preview/settings-cmd-default.png)

![帮助默认回复（标题可直接改）](preview/settings-cmd-help.png)

![Markdown 片段（@ / 图片 / 网址 / 蓝字指令）](preview/settings-cmd-snippets.png)

![消息按钮（【行,列|文字|数据|类型】）](preview/settings-cmd-buttons.png)

- 编辑插件真实响应的指令（含 `/群管`）：每个功能一行，可改「识别字符」「指令（逗号分隔）」「备注」、可停用。
- 每行「备注」右侧有 **编辑**：打开该指令的自定义回复编辑器，左边 Markdown 源码、右边实时预览。
- 点开时**默认回复已经填在源码里并渲染出来**（所有指令都是真实 Markdown 源码，例如注册是「## 注册聚龙账户 / 用法 / 例」、签到是完整签到卡、帮助是「## VloS 指令 + 指令列表」），标题这类静态文字**直接就是源码**，可以随便改；右上角 **恢复默认** 一键还原。
- `/vlos` 和 `/菜单` 的标题已经展开成 `## VloS 指令` / `## 菜单` 这种可编辑文本；`{commands}` `{items}` 仍是变量——它们的内容按「指令」表（名称/别名/备注）和「菜单」配置实时生成，改列表内容请改对应表格，或把变量删掉自己写死。
- 变量改成**下拉列表 + 说明 + 插入按钮**：下拉里每一项直接显示 `{变量} — 说明`（如 `{poem} — 今日随机诗词`、`{cmd_add} — 该指令的蓝色可点击标签`），选中后点「插入」放到 Markdown 光标位置，不用记变量名。
- 下拉最后一组是 **Markdown 片段**：`{at_user}`（@发送者）、`{at_all}`（@全体成员）、`{img:图片地址}`（自动补 `#0px #0px`）、`{link:网址|显示文字}`（蓝色链接）、`{cmd:指令|显示文字}`（蓝色指令标签）、`{at:OpenID}`（@指定用户）；插入后示例参数会被选中，直接打字替换即可。
- 参数化写法在 `renderTemplate()` 里统一处理：`{img:https://…}`、`{link:https://…|文字}`、`{cmd:/指令|文字}`、`{at:OPENID}`；非 `http(s)` 的图片/链接会被丢弃，避免 `javascript:` 之类注入。
- **消息按钮**：编辑器里单独一块「消息按钮」（和 Markdown 正文分开，因为按钮只能挂在消息最底部）：
  - 行 / 列 / 文字 / 数据 / 类型 / 可点范围 全部用下拉和输入框选，点「添加按钮」加到下面预览；**点预览里的按钮即可删除**；同一个坐标再添加会覆盖；
  - 类型（按 QQ 群键盘规范）：`指令`（`action.type=2`，点击把 data 填进输入框）/ `回调`（`action.type=1`，点击推 `INTERACTION_CREATE`，data 给后台）/ `跳转`（`action.type=0`，data 填 URL）；可点范围：`所有人` / `管理员` / `指定用户`；**立即发送**：`是` → `action.enter=true`，点击按钮直接把 data 发出去（仅指令按钮）；`否`（默认）→ 只填入输入框；
  - 存储格式仍是 `【行,列|按钮文字|数据|类型|可点范围|是否立即发送】`（为了兼容旧版本和手写），保存时自动拼在回复末尾；最多 5 行 × 每行 5 个；
  - 发送时按钮行会从正文里删掉，转成 QQ `keyboard` JSON 挂在 Markdown 消息底部；**自定义按钮需要在开放平台开通**，没开通时发送会失败，插件会自动去掉按钮、改发纯 Markdown（日志有 `VloS 按钮消息发送失败`）。
- 保存时如果源码和默认内容完全一致，会按「留空 = 跟随内置默认」保存，不会把默认文案写死（以后插件升级默认文案还能自动生效）。
- 默认回复模板只在 `index.js` 维护一份，插件加载时写进 `settings.html` 的 `vlos-command-defaults-data` JSON 块，设置页不重复写死。
- 自定义回复里 `{content}` 表示该指令原本的默认回复；`{user}`、`{group}`、`{time}` 通用；每个指令还有自己的蓝色标签变量 `{cmd_add}` `{cmd_login}` `{cmd_bindqq}` `{cmd_bindopenid}` `{cmd_list}` `{cmd_sign}` `{cmd_menu}` `{cmd_menusync}` `{cmd_groupadmin}` `{cmd_help}` `{cmd_cancel}`。`/签到` 额外有 `{heading}` `{avatar}` `{name}` `{poem}` `{longjing}` `{xuanyu}` `{days}` `{streak}` `{pending}` `{pending_longjing}` `{pending_xuanyu}` `{note}` `{arknights}` `{footer}`；`/list` 有 `{email}` `{qq}` `{openid}` `{wallet_longjing}` `{wallet_xuanyu}` `{ledger_longjing}` `{ledger_xuanyu}` `{pending}` `{pending_longjing}` `{pending_xuanyu}` `{sign_status}` 等（`{pending_*}` 是 VloS余额，`{ledger_*}` 是插件签到账本，别混用）；`/菜单` 有 `{items}` `{title}` `{scene}`；`/菜单同步` 有 `{menusync_group}` `{menusync_c2c}` `{menusync_skipped}`；`/vlos` 有 `{commands}` `{version}` `{bound}` `{with_qq}` `{signed_today}`。下拉列表里每个变量都有中文说明。
- 注册 / 登录 / 绑定等流程指令只会在**首次指令提示**套用自定义模板，后续验证码 / 密码步骤仍走内置流程；如果模板里不放 `{content}`，会完全替换默认回复（连「确认绑定 QQ 号 / 验证码已发送」这些下一步提示也没了）。2.9.25 起编辑器会红字警告，建议保留 `{content}`。
- 指令回复**只发 Markdown**：Markdown 发送失败只记日志，不再降级纯文本，也不会补发修改前的默认回复。
- **识别字符**默认 `/`：只有 `/签到` 才算指令；留空则裸词 `签到` 也识别。每个功能可以单独设（例如 `!`）。
- 指令名保存时自动去掉开头的 `/` 并转小写；识别字符支持全角 `／`。
- 备注会用在 `/vlos` 帮助里；停用的指令不再响应，也不出现在帮助里。
- `/vlos` 帮助里的指令名（含所有别名）会渲染成和菜单一样的蓝色标签：群里点击填入输入框，私聊点击直接发送。
- 改完保存即重载生效；改指令名后记得同步改「菜单」里的指令。

### 3.5 用户

![用户列表](preview/settings-users.png)

- 「用户」栏目列出通过机器人注册 / 登录的聚龙账户：邮箱、QQ、昵称、OpenID、龙晶 / 玄玉、VloS余额、签到天数、最近签到、更新时间。
- 支持关键字过滤、复制 JSON；最多显示最近更新的 300 个用户。
- 设置页是沙箱 iframe（不能读文件 / 不能联网），所以插件在启动和用户数据变化时把只读快照写进 `settings.html` 的 `vlos-users-data` JSON 块；不含 token / 密码 / 验证码。
- 需要最新数据时重载一次插件（保存设置也会重载）。

### 3.6 群管

![群管设置](preview/settings-guard.png)

- **违禁词**：群消息命中任意一个词就按动作处理：
  - `recall`：调 `recall_group_message` 撤回（QQ 限制 2 分钟内）；
  - `recall_mute`：撤回后再调 <code>restrict_chat_set</code> 禁言，时长可配（60 秒 ~ 30 天）；
  - `warn`：只在群里发一条警告。
  - 命中后这条消息不再进入指令流程；接口失败只记日志。
  - **每次 QQ 接口调用都会写日志**（成功/失败都写）：`VloS 接口 recall_group_message 撤回 message_id=… 成功（120ms）` 或 `… 失败（90ms）code=40054005 message=消息已过期`，最后再汇总一条 `VloS 违禁词命中 … · 已撤回 · 已禁言 180 秒`。撤回失败也会继续禁言，不会因为撤回失败就整条静默。
- **入群申请**：`GROUP_JOIN_REQUEST` 事件 → `approval_join_request`：
  - `manual`：只记日志；
  - `approve` / `decline`：自动通过 / 拒绝，拒绝理由可配；
  - `qa`：按入群问题答案审核——QQ 会把验证消息 / 问答答案放进 `verify_info`（`verify_message` 或 `review_qa_list[].answer`），答案命中任一关键词就通过，没命中按 `qaFallback` 自动拒绝或留给管理员；
  - 带 `risk_tips` 安全提示的申请即使命中关键词也不会通过。
  - **入群问题本身要在 QQ 群设置里由群主 / 管理员配置**，官方没有「机器人设置入群问题」的接口；机器人只负责读答案 + 审批。
  - 需要机器人是群管理员，且订阅 `GROUP_MEMBER_EVENT`。
  - 入群审批只看「处理入群申请」开关，和违禁词总开关 `guard.enabled` 互不影响；即使违禁词关闭，qa 模式也会正常审批。
- **本群覆盖里的违禁词会回落全局**：本群 `guard.enabled=false` 时，开关 / 违禁词 / 动作 / 禁言秒数全部继承全局配置（只保留本群的入群问答）；本群启用了违禁词但词库为空，也会继承全局词库。这样不会出现「全局有词、本群却完全不撤回」。

#### 本群自定义（`/群管`）

![审核页面](preview/settings-review.png)

![已通过编辑](preview/settings-approved.png)

- 群主 / 管理员在群里发 `/群管`：插件用聚龙 Key 的 `callback-create` 生成一次性网页（**10 分钟有效**），链接**只私聊发给操作人**，群里只提示「已私聊发送 / 没收到请先加机器人好友」；10 分钟内还没提交的同一群再次 `/群管` 会复用原地址，不新建回调。
- 私聊目标是发 `/群管` 的群主 / 管理员本人（已绑定的 C2C OpenID 或别名）；QQ 不提供群主 C2C OpenID，没法只定向群主。没绑定时先在私聊发 `/bindopenid`。
- 私聊优先走 2026-11-17 新增的「群消息私聊回复」（群消息 `msg_id` + 发送者 OpenID）；失败降级主动 C2C（可用 `adminNotify=false` 关闭）；两者都失败时群内被动回复「无权限，请添加机器人私聊好友」。
- 页面里的进群 / 退群 Markdown 会**实时渲染预览**（@ 标签、加粗、引用直接显示），改源码马上能看到结果。
- 群管页面是开关联动的：关闭进群/退群/违禁词/入群申请后，对应组件直接隐藏；入群验证选「明日方舟校验」时隐藏问题/答案。\n- 提交后插件用 `callback-result` 轮询（20 秒一次）取回，写入 `data/callbacks.json` 并刷新设置页「审核」快照；提交成功不再额外发主动消息。
- **自动通过（2.9.50+）**：审核判断只看**进退群的 3 项**（新成员进群 / 成员退群 / 入群验证）——按功能逐项对比「全局」和「本群上次审核通过的自定义」两个基线（可以混用），只关闭某项或开启项内容与任一基线一致，就直接写入本群覆盖并私聊「已自动通过」；**群管部分（是否启用违禁词、词库、动作、禁言、处理入群申请）完全不参与审核判断**。只有改了进退群模板 / 验证题才需要管理员审核。已经挂在「待审核」里的条目也会在下次轮询按新规则重判。
- 「审核」页分「待审核」「已通过」两个子页：待审核是回调提交和反审回来的记录；已通过直接读插件运行时的 `groups` 快照，管理员用审核链接通过后也会出现在这里，点「刷新列表」重新读取。已通过可以直接编辑模板 / 违禁词 / 入群规则并保存，也支持「反审」（回落到全局默认、重新进入待审核）和「删除」（不再生效）。
- **2.9.44 起「刷新列表」只刷新审核快照**：设置页发 `jlw-settings-review-refresh`，面板重新读一遍插件设置页里的 JSON 块再发回 `jlw-settings-snapshots`，页面只替换这几个快照并重绘审核列表，**不换 iframe、不重载插件、不丢正在编辑的内容**；旧面板不认识这个协议，会自动退回原来的整页刷新（有未保存修改时先确认）。\n- 待审核卡片会显示 **进群欢迎 / 退群欢迎 / 入群验证** 的开关状态；如果提交时进群或退群欢迎是关闭的，对应模板预览不显示（只显示「提交时进群 / 退群欢迎都是关闭的」提示），避免管理员误以为模板会生效。
- 「审核」页默认是折叠列表：头像、群名、提交人、提交时间；展开后才加载违禁词内容 / 动作 / 入群规则和 Markdown 预览。通过 → 写入 `config.groups[group_openid]` 并保存；拒绝 → 记录 `callbackReviews[id]`。
- 审核通过 / 拒绝会私聊提示提交人；提示文案在「审核」页顶部可改，拒绝时每条可填本次原因，会附在拒绝提示后面。
- 「审核」页可配置多个**管理员 OpenID**；新的群管提交进来后，插件会创建 24 小时有效的审核链接并私聊发给每个管理员。打开链接可直接看到提交的成品（进退群模板预览 + 群管规则），底部选择「通过」或「拒绝」并填写拒绝理由，提交后插件自动应用审核结果，同时同步到 `plugin.json`。
- 外部审核链接通过聚龙 `callback-create` 生成，24 小时后过期；管理员也可以在面板「审核」页继续操作。
- 同群已有一份待审核时，再次 `/群管` 会被拒绝并提示「设置正在审核中」，必须等管理员通过或拒绝后才能重新提交；回调轮询也会忽略后到的重复提交，保留先提交的那份。
- 本群覆盖只包含进退群（成员进 / 退）与群管；Bot 入群欢迎、菜单、指令等仍用全局设置。没有覆盖的群完全走全局默认。
- **本群有覆盖时以本群为准**：页面里「新成员进群 / 成员退群」开关直接决定本群是否发欢迎；全局「启用进退群」总开关关着也不影响本群单独开启（关掉再打开同样生效）。本群模板留空时自动回落全局模板。
- **只有审核通过（`reviewStatus=approved`）的本群覆盖才生效**；`pending` / `rejected` 的自定义设置一律回落到全局设置。
- 需要 Key 有 `callback` 权限、机器人是群管理员、且 QQ 下发了 `member_role`（owner / admin）。

### 3.7 进退群

![进退群设置](preview/settings-welcome.png)

![入群验证](preview/settings-join-verify.png)

- 「入群验证」「进群」「退群」「Bot 入群」四个子页；进群/退群/Bot 入群左边直接编辑 Markdown 源码，右边实时预览（变量按示例值替换）。
- **入群验证**（进退群下的独立子页，放在「进群」前面，2.9.33+）：挂在本群入群欢迎下面，受「新成员进群」开关控制（关闭时不生效）。
  - 自定义问题：填问题；欢迎语下面用 `***` 分隔，先出 `## 入群验证` 标题，紧接 `> 限时 N 分钟`，再出问题；答案是 2–4 行「单选框 + 输入框」，**单选框选中的那一行才是正确答案，其他都算错**；点「+ 添加答案」最多加到 4 行，每行可单独删除（至少保留 2 行）。
  - **验证限时**：下拉选 1–10 分钟（默认 5，`joinVerify.expiresMinutes`），欢迎语里会显示 `> 限时 N 分钟`；**时间到还没通过会自动移出**——先发「验证超时，您未在规定时间内完成验证，将被移出群聊。」，等 3 秒再调踢人接口，和答错次数用完的处理一致。
  - 全局设置页、群管一次性页面、已通过卡片都有这个下拉。
  - **答错后回复里会重新挂一组答案按钮**（不带 `group_id`，避免“同组点过一次就灰”），可以继续点；答对回「验证通过」，答错回「答案不正确（还可尝试 N 次）」；**达到「最多答错次数」的这一次就调 `batch_remove_members` 移出**（不是再多给一次）。
  - 达到答错次数时**先发「验证失败次数过多」提示，等 3 秒再调 `batch_remove_members` 移出**（否则人先被踢走，提示根本看不到）。
  - 移出失败不会只回「已移出」：提示发出后接口失败会再补一条「自动移出失败：原因」，日志也写；常见是 QQ 返回 `40103012 群主已经关闭操作权限`（群设置 → 群机器人 / 群管理里给机器人开成员管理权限），或机器人不是管理员。
  - 同一个人 1.5 秒内连点同一个按钮只算一次（QQ 偶发重复投递 `INTERACTION_CREATE` 时不会一次点击算好几次）。
  - **2.9.40 起答案挂在欢迎语下面的回调按钮上**：每个答案一个按钮（`action.type=1`，data 为 `jv:<序号>`），按钮只允许这名新成员点击（`permission.type=0` + `specify_user_ids=[新成员 openid]`），首条消息的按钮同组互斥（`group_id`，点一个其余变灰）；点按钮后 QQ 推 `INTERACTION_CREATE`，插件先 `PUT /interactions/{id}` 回应（3 秒内，否则客户端一直 loading），再按 `button_data` 判定。
  - 这样**不依赖群的全量消息权限**（不需要机器人读群里所有人的消息），普通聊天也不会被当成答案。
  - 所有群都能挂这套按钮；万一 QQ 拒绝键盘（版本 / 参数问题，返回 `305007` 等）会自动去掉按钮重发欢迎语，并补一条**蓝字答案兜底**：每个答案一个 `<qqbot-cmd-input>` 标签，点击把 `/入群验证 <答案>` 填进输入框，发送后同样判定（不需要机器人读群里的普通消息）。
  - 明日方舟校验：固定提示「请私聊机器人授权鹰角网络账户，授权后点击下方按钮校验」，底部挂 **「开始校验」回调按钮**（`action.type=1`，data=`jv:ark`，只允许这名新成员点）；点击后直接调明日方舟插件 `isLoggedIn(member_openid)`，限时内（默认 5 分钟，可调 1–10）有效。通过回「验证通过，博士！欢迎您的加入！(*´▽｀)ノノ」；未通过 / 接口取回失败会回「校验未通过！请先私聊机器人授权…」并**重新挂一个「开始校验」按钮**（旧按钮点过一次就灰）。键盘被 QQ 拒绝时兜底发蓝字 `/入群校验` 指令。
  - 全局设置页在「进退群 → 进群」下面；群管一次性页面里也有同一组配置（开关 / 方式 / 问题 / 答案 / 次数），审核通过后写进本群覆盖。
  - **已通过群可在设置页「审核 → 已通过」卡片里查看/修改验证配置**（2.9.39+）：开关、方式、问题、答案 1–4、正确答案、最多答错次数；点「保存修改」写入本群覆盖。保存前会校验（问题必填、有效答案 ≥ 2、正确答案不能指向空答案）。
  - 生效规则：本群覆盖里有 `welcome.joinVerify` 就**优先本群**，没有才继承全局；全局把入群验证关掉不影响本群单独开启。配置不完整（问题为空或有效答案 < 2）时运行时自动跳过并写日志，不会误踢。
  - 群没有本群覆盖时用全局配置；有覆盖时以本群为准。
- **新成员进群**（`GROUP_MEMBER_ADD`）、**成员退群**（`GROUP_MEMBER_REMOVE`）、**机器人被拉进群**（`GROUP_ADD_ROBOT`）分别可开关。
- **前提：机器人必须订阅「群成员事件」`GROUP_MEMBER_EVENT`（1<<24）**；只勾 `GROUP_AND_C2C_EVENT` 收不到进退群事件（日志里不会有 `VloS 收到群事件`）。退群事件 QQ 拒绝 `event_id`（40034027），只能发主动消息，需要「群主动消息」权限，否则 40034105。
- 机器人刚进群时通常还不是管理员，QQ 会拒绝主动消息。官方文档只列了 `GROUP_ADD_ROBOT` / `GROUP_MSG_RECEIVE` / `INTERACTION_CREATE` 支持 `event_id`，但**社区实测成员进群 / 退群用事件外层 id 作 `event_id` 也能发出去**：2.9.16 起优先用 `event_id`（Markdown 被拒时同一 event_id 降纯文本）；**2.9.31 起进群 / 退群在 event_id 失败（或没有事件 id）时会自动转群主动消息**（`主动消息 + Markdown` → `主动消息 + 纯文本`，日志里会写 `via=`），需要机器人有主动消息权限；机器人进群仍只走 event_id + 重试。任何情况都不要把事件 id 当成 `msg_id`。
- 待审核通知：`/群管` 提交后，插件把审核链接**主动 C2C** 发给 `groupAdmin.adminOpenids` 里的管理员（这是设计行为）；`adminNotify=false` 可关闭审核通知与群管链接的主动 C2C 回退。
- 变量：`{group}`、`{member}`、`{member_openid}`、`{username}`、`{group_openid}`、`{time}`、`{apply_source}`、`{verify_message}`、`{op_member}`；未知变量替换为空字符串。
- 腾讯 Markdown 能力也做成了变量：`{at_member}` / `{at_all}` / `{at_op}` 是 @ 标签；`{cmd_menu}`、`{cmd_sign}`、`{cmd_list}`、`{cmd_help}`、`{cmd_groupadmin}` 是蓝色指令标签（按「指令」页的名称 / 识别字符生成，点击填入输入框）。
- 别的插件的指令想做成蓝色标签，用 `{cmd:点击后填入的文字|按钮上显示的文字}`，例如 `{cmd:/Arknights|明日方舟}` → 显示「明日方舟」，点击填入 `/Arknights`；省略显示文字时按钮显示原文。这段语法在进退群模板、群管页预览里都能用。
- 模板里手写的 `<qqbot-cmd-input text="/MC" show="我的世界" />` 也会在发送前自动把中文 / 符号转成 urlencode（已转码的不会重复转），群管页和设置页预览会把它显示成蓝色标签。
- 「插入变量」下拉里还提供 Markdown 片段：图片 `![说明 #宽px #高px](url)`、链接、加粗、引用、二级标题、无序列表、分割线、行内代码；图片和链接替换成自己的地址即可。
- QQ 的 Markdown 图片必须写成 `![说明 #宽px #高px](https://…)` 才会显示；`#0px #0px` 表示按原图大小，没写尺寸时插件会自动补 `#0px #0px`。分割线用 `***`，写 `---` 会自动转成腾讯支持的 `***`。
- 腾讯 Markdown 内置能力也做成了变量：
  - `{at_member}` → `<qqbot-at-user id="成员OpenID" />`，@ 进群的新成员；
  - `{at_all}` → `<qqbot-at-everyone />`，@ 全体（机器人需为群管理员，每群每天 1 次）；
  - `{at_op}` → @ 把机器人拉进群的成员。
- 群名用 `group_info` 取并缓存 10 分钟；成员进 / 退群事件不带昵称，`{member}` 会退化成 OpenID 或「新朋友」。

### 3.8 说明

指令、流程、安全、排错都在设置页「说明」标签里。

---

## 4. 配置结构

```json
{
  "enabledAccountIds": [],
  "jlAccount": {
    "baseUrl": "https://www.jlworld.net",
    "apiPath": "/api/plugin/jl-account",
    "timeoutMs": 20000,
    "insecureTls": false,
    "key": ""
  },
  "sign": {
    "oncePerDay": true,
    "longjingMin": 10,
    "longjingMax": 100,
    "xuanyuChance": 8,
    "xuanyuMin": 1,
    "xuanyuMax": 1,
    "wallet": true,
    "arknights": true,
    "arknightsTimeoutMs": 25000
  },
  "ui": { "avatarSize": 48, "showSiteLink": true },
  "menu": {
    "enabled": true,
    "sync": true,
    "autoSend": true,
    "group": { "enabled": true, "items": [{ "name": "签到", "desc": "每日签到领龙晶", "command": "/签到" }] },
    "c2c": { "enabled": true, "items": [{ "name": "签到", "command": "/签到" }] }
  },
  "commands": {
    "sign": { "enabled": true, "prefix": "/", "names": ["签到", "每日签到", "sign"], "desc": "每日签到（诗词 + 龙晶 + 玄玉 + 方舟掉落）" },
    "menu": { "enabled": true, "prefix": "/", "names": ["菜单", "指令", "功能", "menu"], "desc": "查看当前场景的通用菜单" }
  },
  "guard": {
    "enabled": false,
    "bannedWords": [],
    "action": "recall",
    "muteSeconds": 600,
    "join": {
      "enabled": false,
      "mode": "manual",
      "rejectReason": "申请未通过，请先阅读群公告。",
      "qaKeywords": [],
      "qaFallback": "decline"
    }
  },
  "welcome": {
    "enabled": false,
    "memberJoin": { "enabled": true, "template": "{at_member} 欢迎加入 {group}！" },
    "memberLeave": { "enabled": false, "template": "有成员离开了群聊。" },
    "botJoin": { "enabled": true, "template": "大家好，我是 VloS 助手。" }
  },
  "groups": {},
  "callbackReviews": {},
  "groupAdmin": {
    "approveMessage": "您的群管设置申请已通过，本群已启用新设置。",
    "rejectMessage": "您的群管设置申请未通过。",
    "adminOpenids": ["管理员 user_openid", "第二个管理员 user_openid"]
  },
  "site": { "name": "聚龙世界", "url": "https://www.jlworld.net" }
}
```

- 源码模板里的 `jlAccount.key` 是空字符串；运行目录的 `plugin.json` 里填写真实 Key。
- `lib/defaults.js` 是默认值来源；`node tools/build-manifest.js` 可重新生成 `plugin.json` 的 config。
- 旧版 `smtp` / `mail` 字段会被 `normalizeConfig()` 丢弃，不会继续保存 SMTP 密码。

> ⚠️ **干净包只能用于「新安装 / 面板导入」，不要解压覆盖已有插件目录。**
> 干净包的 `plugin.json` 是默认配置（`groups: {}`、`callbackReviews: {}`、`jlAccount.key` 为空），
> 直接解压到 `~JlWBoT/plugins/VloS` 会把运行目录里的 Key、已审核群设置、待审核申请全部覆盖掉。
> **升级已有插件**只复制代码文件（`index.js`、`lib/`、`settings.html`、`api.html`、`README.md`、`package.json` …），
> 保留运行目录里的 `plugin.json`；面板「插件 → 导入」遇到同 ID 会拒绝，也不会覆盖。

---

## 5. 数据与旧版迁移

### SQLite（VSQL 插件，2.9.57+）

数据默认存在 VSQL 插件的 **shared** 命名空间：`~JlWBoT/plugins/VSQL/data/dbs/shared.db`，三张表（其他插件可以直接读）：

| 表 | 内容 |
| --- | --- |
| `vlos_users` | 用户主表：`key`（openid）、qq / email / name / avatar / token / wallet_lj / wallet_xy / vl_lj / vl_xy / balances_lj / balances_xy / sign_total / sign_streak / sign_last / created / updated |
| `vlos_aliases` | 别名表：`alias` → `user_key`（群 openid / 私聊 openid / QQ / 邮箱别名） |
| `vlos_sign_history` | 签到历史：`user_key` / `date` / `at` / `poem` / `ark` / `mode`，每个用户保留最近 120 条 |

- `vl_lj` / `vl_xy` 就是 **VloS余额**（原来的 `pendingWallet`）：发奖 Key 异常时签到奖励先记这里，Key 恢复后下次签到与本次奖励一并入账。
- 其他插件读取示例：`vsql.db().all('SELECT key,wallet_lj,wallet_xy,vl_lj,vl_xy FROM vlos_users')`。
- 用户对象在内存里按需加载（LRU 100 个），不再像以前那样整份 `users.json` 常驻内存。
- 写库只写需要的用户：`saveUser(key)` 只 upsert 一个用户；方舟掉落命中时 `setLastSignArk(key, true)` 直接 `UPDATE vlos_sign_history` 的最后一行（历史在独立表，`save()` 不会重写历史）。
- `save()` 会遍历缓存快照再逐个写回（2.9.60 修复：旧实现边遍历边 `delete+set` 重排缓存，导致迭代器永远结束不了 → 同步死循环，进程卡死、面板无响应）。
- **跨表写 VloS余额**：其他插件可以直接 `UPDATE vlos_users SET vl_lj=?, vl_xy=? WHERE key=?`。VloS 在 `/list`、签到结算、`vlosBalance` / `addVlosBalance` / `setVlosBalance` / `getUser` 之前都会 `refreshPending(key)` 回表读一次；普通保存（`_saveUser`）的 UPSERT 不含这两列，只有 `setPendingWallet` / `addPendingWallet` / 迁移建号才会写，避免用旧缓存覆盖别人刚加的余额（2.9.61）。

### users.json（回退 / 迁移源）

VSQL 没加载（或运行环境没有 `node:sqlite`）时自动回退旧的 `data/users.json`，并在群里 / 私聊提示一次「缺少前置插件 VSQL」；VSQL 就绪后第一次访问会把它迁移 / 回填进 `vlos_users`，成功后**删除 users.json**，之后所有数据只走 SQLite。

```json
{
  "version": 2,
  "users": {
    "<openid>": {
      "key": "<openid>",
      "aliases": ["<openid>", "<另一个会话的 openid>"],
      "email": "user@example.com",
      "name": "小明",
      "avatar": "/uploads/avatars/usr_xxx.jpg",
      "token": "***",
      "tokenExpiresAt": 1795000000000,
      "qq": "3407556894",
      "qqBoundAt": 1795000000000,
      "qqSource": "api",
      "openid": "",
      "openidBoundAt": 0,
      "legacyQq": "",
      "wallet": { "longjing": 300, "xuanyu": 3 },
      "pendingWallet": { "longjing": 0, "xuanyu": 0 },
      "balances": { "longjing": 0, "xuanyu": 0 },
      "sign": { "totalDays": 0, "streak": 0, "lastDate": "", "history": [] }
    }
  }
}
```

- `wallet`：聚龙钱包缓存（来自 `me` / `balance` / `currency-add`）
- `pendingWallet`：VloS 余额（SQLite 里对应 `vlos_users.vl_lj / vl_xy`）
- `balances`：插件签到账本（本地）
- `token`：登录凭证，**不通过 API 暴露**
- `openid` / `openidBoundAt`：机器人 OpenID；`/bindopenid` 或 `/bindqq` 成功后自动保存，填写后不可修改
- `legacyQq`：旧版插件用 QQ 邮箱验证留下的 QQ，没有同步到聚龙账户；`/list` 会提示用 `/bindqq` 重新绑定

### 旧版迁移

- 旧 `jlworld` / `mail` 字段 → `email`
- 旧 `qq`（没有走聚龙 qq-bind）→ `legacyQq`，并从本地 qqIndex 移除
- 旧 `balances` → 插件签到账本
- 旧用户需要 `/login 邮箱 密码` 重新拿 token，再 `/bindqq` 把 QQ 同步到聚龙账户

### 每日诗词.txt

UTF-8，一行一首；`data/每日诗词.txt` 优先，`poems.txt` 兼容回退，内置 8 首兜底。

```bash
node tools/poems.js import "C:\路径\每日诗词.txt"
node tools/poems.js export "D:\每日诗词导出.txt"
node tools/poems.js check
```

### menu-sync.json

记录上一次菜单同步的配置签名和时间；签名没变时插件重载不会重复删建 QQ 指令面板。删掉它会让下次加载强制同步一次。

### callbacks.json

记录 `/群管` 创建的一次性页面（id / 群 / 过期时间 / 状态）和 `callback-result` 取回的提交内容；审核通过或拒绝后，条目会被清理。不含 Key、token。

---

## 6. 签到钱包模式

开启「签到奖励写入聚龙钱包」且配置了发奖 Key 时：

1. 掷龙晶 / 玄玉；
2. 把 VloS余额（`pendingWallet`）和本次奖励相加，调 `POST /key` `action=currency-add`；
3. 成功后清空暂存，用返回的 `wallet` 更新本地缓存；
4. 签到卡片只显示 `+奖励`，并把算式写清楚：正常签到显示 `+82`；这次带上了暂存则显示 `+127（本次 82 + 暂存 45）`，即 **127 = 82 + 45**，不是 127 之外再加 45；发奖失败则显示 `+82（本次，已暂存）`。正常签到**不显示钱包余额**。

失败处理：

- Key 过期 / 权限不足 / 网络异常 / 未配置 → 本次奖励写入 VloS余额（`pendingWallet`），卡片显示「VloS余额」；
- 下次 Key 恢复后签到，会把 VloS余额和本次奖励相加后一次入账，并清空 VloS余额；
- 只有一种货币失败 → 另一种正常入钱包，失败的那种进 VloS余额；
- 关闭钱包模式 → 写插件签到账本，已有 VloS余额保留，切回钱包模式后下次一并入账。

---

## 7. 方舟签到掉落

签到会调用同进程 Arknights 插件的公开 API：

```js
const ak = globalThis.__JLWBOT_PLUGIN_APIS__?.get('Arknights');
const { accounts } = await ak.sign(userKey);
```

- 未安装 / 未加载：显示「插件未加载」，不影响本插件签到
- 未登录鹰角：显示「未绑定鹰角账户」，不影响龙晶 / 玄玉
- 没有绑定角色：显示提示
- 超时 / 报错：显示错误摘要

---

## 8. 对外 API

```js
const vlos = globalThis.__JLWBOT_PLUGIN_APIS__?.get('VloS');
if (vlos?.isReady()) {
  const u = vlos.getUser('3407556894');        // openid / QQ / 邮箱
  console.log(u.email, u.qq, u.wallet, u.balances, u.vlosBalance);
  vlos.addBalance(u.key, { longjing: 10 });    // 插件签到账本（同步）
  vlos.addVlosBalance(u.key, { longjing: 10 }, { reason: '小游戏' }); // VloS 余额（同步，可负数扣减）
  await vlos.addWallet(u.key, { longjing: 10 }, { reason: '小游戏' }); // 聚龙钱包（需 Key）
}
```

| 方法 | 说明 |
| --- | --- |
| `getUser(voucher)` / `getBinding(voucher)` | 账户资料、绑定 QQ、OpenID、钱包缓存、VloS余额、签到账本 |
| `wallet(voucher)` | 聚龙钱包缓存（同步） |
| `balance(voucher)` | 插件签到账本（同步） |
| `vlosBalance(voucher)` | **VloS 余额**（同步）：`{longjing, xuanyu, total}`，即原「暂存余额」 |
| `addVlosBalance(voucher, delta, {reason})` | 同步加减 VloS 余额；负数扣减，最低 0；返回 `before / after / delta / vlosBalance / user` |
| `setVlosBalance(voucher, {longjing, xuanyu}, {reason})` | 同步直接设置 VloS 余额（负数按 0） |
| `addWallet(voucher, delta, {reason})` | **异步**；用发奖 Key 调 `currency-add / currency-sub` |
| `addBalance` / `setBalance` | 同步；只改插件签到账本 |
| `signInfo` / `signedToday` / `stats` / `dropConfig` | 签到状态 / 统计 / 掉落配置 |
| `listUsers({limit,offset,search})` | 账户列表 |

> **VloS 余额是什么**：聚龙发奖 Key 异常时签到奖励先记到这里（SQLite 里是 `vlos_users.vl_lj / vl_xy`，回退时是 `users.json` 的 `pendingWallet`），Key 恢复后下次签到与本次奖励一并入账；其他插件可以用 `addVlosBalance` 给用户加/减这个余额，用 `vlosBalance` 读取。

约定：

- 未加载抛 `NOT_READY`；找不到用户抛 `NOT_FOUND`；没有发奖 Key 抛 `NO_KEY`
- 返回副本，外部修改不影响插件数据
- 不暴露 token、密码、发奖 Key
- VloS 重载后旧 API 对象失效，调用前重新 `get('VloS')`

---

## 9. 自测

```bash
node test/vlos-test.js        # 82 项：注册 / 登录 / 绑定 QQ / OpenID / 签到 / 菜单 / 指令 / 自定义回复 / 群管 / 本群覆盖 / 审核提示 / 进退群 / 用户快照 / 存储（SQLite / 迁移 / save 不死循环 / 跨表 VloS余额）/ API
node test/vlos-poems-test.js  # 7 项：诗词编码与导入导出
node test/vlos-live.js        # 29 项：运行中的框架只读联调（需要 8686 在跑）
```

测试使用本地假聚龙账户服务器，不联网、不发邮件、不修改真实账户。

---

## 10. 排错

| 现象 | 处理 |
| --- | --- |
| `/add` 提示「该邮箱已注册」 | 用 `/login 邮箱 密码` 登录；忘记密码去聚龙站点找回 |
| `/add` 提示「请私聊」 | 注册 / 登录只允许私聊，避免密码进群 |
| 登录已过期 | `/login 邮箱 密码` 重新登录 |
| `/bindqq` 提示「QQ 已绑定」 | 聚龙账户绑定后不可修改，只能联系管理员 |
| `/bindqq` 提示「这个 QQ 已被使用」 | 换 QQ，或先处理原聚龙账户 |
| 收不到 QQ 绑定验证码 | 验证码发到聚龙**注册邮箱**，不是 QQ 邮箱；检查垃圾箱 |
| 签到没进聚龙钱包 | 检查发奖 Key 是否有 `currency-add`；看卡片提示和日志 |
| `/bindopenid` 返回了一串字符 | Key 没有 `openid` 权限 / Key 失效 / 网络异常；按提示到账户中心手动填写，或换一个有 `openid` 权限的 Key |
| `Key 无效或已被停用` | 到聚龙后台重新生成 Key，并在「Key 管理」授予 `currency-add` + `openid` |
| 资料刷新失败 | 检查站点地址 / 接口路径 / 网络；token 过期会提示重新登录 |
| 设置保存失败 | 看面板红色结果条；确认站点地址以 http(s):// 开头 |
| 菜单没同步到 QQ | 私聊发 `/菜单同步` 看返回；确认机器人有指令面板权限、框架已连接；日志搜 `VloS 菜单同步` |
| 群里点菜单没反应 | 群指令面板的「指令」必须和机器人实际命令一致（如 `/签到`）；改完重新保存同步 |
| 违禁词没撤回 | 先搜日志 `VloS 违禁词命中`：有命中就看同行的 `已撤回 / 撤回失败(code=…)`；再搜 `VloS 接口 recall_group_message`，失败行会带 `code` / `message` 和提示（`40054005`=超过 2 分钟、`403`=机器人不是群管理员、`11298`=IP 白名单、`TOKEN_ERROR`=Secret 无效）。日志完全没有命中 → 先确认账户 `online`（面板 `/health`）；「审核 → 已通过」为空就 F5 刷新快照。 |
| 日志说已禁言但消息还在 | 2.9.19 之前不检查接口返回值，撤回失败也会打印成功；升级到 2.9.19+ 看 `VloS 接口 recall_group_message … 失败 code=…`。 |
| 手机端有「管理员撤回了一条消息」，电脑端还在 | QQ 电脑版（NT）不渲染机器人撤回事件，也不支持机器人 Markdown（显示「暂不支持该消息类型」）。服务端已撤回，以手机端为准；电脑端退出群聊重进 / 清缓存 / 换 QQ 版本。 |
| 收不到入群申请 / 进退群事件 | 连接页确认勾选 `GROUP_MEMBER_EVENT`（1<<24）；入群申请还要求机器人是群管理员 |
| 欢迎语变量没替换 | 只支持文档里的变量；`{member}` 在成员进 / 退群事件里没有昵称，会显示 OpenID 或「新朋友」 |
| 菜单点了没反应 | 群聊里 `qqbot-cmd-input` 只会把指令填进输入框，需要用户按发送；私聊才是点击直接发送 |
| 「用户」栏目是空的 / 数据旧 | 插件启动或用户数据变化时才刷新快照；保存一次设置 / 重载插件即可 |
| 指令改名后菜单失效 | 「菜单」里存的是旧指令文本，去「菜单」栏目同步改成新指令 |
| 指令没反应 | 检查「指令」栏目的识别字符：默认要有 `/`；想裸词识别就把识别字符留空 |
| 改了识别字符帮助还是 / | 保存后插件会重载；`/vlos` 会按新识别字符显示，旧消息不会变 |
| `/群管` 提示需要群主 / 管理员 | QQ 没下发 `member_role` 或发送者不是群主 / 管理员 |
| `/群管` 创建设置页面失败 | Key 要有 `callback` 权限；看返回的错误 |
| 提交了但「审核」里没有 | 插件 20 秒轮询一次；确认页面已提交、Key 有 `callback-result` 权限，打开「审核」后点「刷新列表」立即拉一次 |
| 管理员链接通过了，「已通过」里没有 | 点「刷新列表」重新读取插件快照；新版审核结果会同步到面板内存配置，重新打开设置页也能看到。若按钮无反应，按 F5 刷新面板页面加载新版面板脚本，或点提示里的「面板是旧版」在新页面刷新 |
| 审核通过后群里没变化 | 确认机器人是群管理员、`GROUP_MEMBER_EVENT` 已订阅；没有本群覆盖的群继续用全局默认 |

日志过滤：面板「日志」→ scope `plugin:VloS`。

---

## 11. 安全

- 聚龙密码只在注册 / 登录请求里使用，插件不落盘；但 QQ 消息本身可能被框架消息记录保存，建议私聊并避免公共设备。
- token 保存在本机 SQLite（`vlos_users.token`，回退时在 `users.json`），等同登录态；不要分享 `~JlWBoT` 目录。
- 发奖 Key 等同发钱权限，只保存在本机 `plugin.json`，不要放进公开仓库 / 截图。
- QQ 绑定不可修改；验证码只发注册邮箱。
- 设置页在沙箱 iframe 中运行，不能读取面板登录态，也不能发起网络请求。

---

## 12. 许可

MIT。QQ 机器人接口与文档版权归腾讯所有；聚龙账户接口版权归聚龙世界所有。
