'use strict';
/**
 * VSQL · 内置 SQLite（插件形态的数据库服务）
 *
 * 定位：别的插件不用自己挑驱动、自己管文件、自己写迁移，只要
 *   const vsql = globalThis.__JLWBOT_PLUGIN_APIS__?.get('VSQL');
 *   const db = vsql.db('我的插件ID');
 *   db.exec('CREATE TABLE IF NOT EXISTS ...');
 * 就能按插件隔离地建表、读写、事务、迁移、备份。
 *
 * 能力分层：
 *   1. 进程内 API（api.js）：JS 插件的首选，同步、零拷贝；
 *   2. 本机 HTTP 网关（lib/http-gateway.js，可选）：pull/process/dll 插件、易语言等
 *      外部程序通过 127.0.0.1 + Bearer 令牌读写同一批数据库；
 *   3. 私聊管理指令 /vsql（管理员 OpenID）：看状态、列库表、跑只读 SQL、备份、取令牌。
 *
 * 安全：
 *   - 命名空间名严格校验，一库一文件，互不串表；
 *   - 表名/列名只允许标识符，值全部走占位符；
 *   - ATTACH/DETACH 默认禁用；
 *   - 管理指令默认只允许 SELECT/PRAGMA/EXPLAIN（写 SQL 要 admin.allowWrite=true）；
 *   - HTTP 网关默认只监听 127.0.0.1 且必须带令牌。
 */

const fs = require('node:fs');
const path = require('node:path');

const API = require('./api');
const U = require('./lib/util');
const { NamespaceManager } = require('./lib/namespaces');
const { HttpGateway } = require('./lib/http-gateway');

const manifest = require('./plugin.json');
const PLUGIN_VERSION = manifest.version;

const DEFAULT_CONFIG = {
  dataDir: 'data/dbs',
  defaultNamespace: 'shared',
  maxOpen: 16,
  autoCreate: true,
  allowAttach: false,
  busyTimeoutMs: 5000,
  injectSettings: true,
  settingsPreview: { enabled: true, maxNamespaces: 8, maxTables: 15, maxRows: 10, maxBytes: 204800, redact: true },
  http: { enabled: true, host: '127.0.0.1', port: 8787, token: '', maxRows: 1000 },
  admin: { enabled: true, openids: [], allowWrite: false, maxRows: 30, groupEnabled: false },
};

let runtime = null;

/* ======================= 配置 ======================= */

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.trunc(n), min), max);
}

function normalizeConfig(raw) {
  const cfg = raw && typeof raw === 'object' ? raw : {};
  const httpRaw = cfg.http && typeof cfg.http === 'object' ? cfg.http : {};
  const adminRaw = cfg.admin && typeof cfg.admin === 'object' ? cfg.admin : {};
  const previewRaw = cfg.settingsPreview && typeof cfg.settingsPreview === 'object' ? cfg.settingsPreview : {};
  let defaultNamespace = String(cfg.defaultNamespace || DEFAULT_CONFIG.defaultNamespace).trim().toLowerCase();
  try {
    defaultNamespace = U.sanitizeNamespace(defaultNamespace);
  } catch {
    defaultNamespace = DEFAULT_CONFIG.defaultNamespace;
  }
  return {
    dataDir: typeof cfg.dataDir === 'string' && cfg.dataDir.trim() ? cfg.dataDir.trim() : DEFAULT_CONFIG.dataDir,
    defaultNamespace,
    maxOpen: clampInt(cfg.maxOpen, DEFAULT_CONFIG.maxOpen, 1, 256),
    autoCreate: typeof cfg.autoCreate === 'boolean' ? cfg.autoCreate : DEFAULT_CONFIG.autoCreate,
    allowAttach: typeof cfg.allowAttach === 'boolean' ? cfg.allowAttach : DEFAULT_CONFIG.allowAttach,
    busyTimeoutMs: clampInt(cfg.busyTimeoutMs, DEFAULT_CONFIG.busyTimeoutMs, 0, 60000),
    injectSettings: typeof cfg.injectSettings === 'boolean' ? cfg.injectSettings : DEFAULT_CONFIG.injectSettings,
    settingsPreview: {
      enabled: typeof previewRaw.enabled === 'boolean' ? previewRaw.enabled : DEFAULT_CONFIG.settingsPreview.enabled,
      maxNamespaces: clampInt(previewRaw.maxNamespaces, DEFAULT_CONFIG.settingsPreview.maxNamespaces, 1, 50),
      maxTables: clampInt(previewRaw.maxTables, DEFAULT_CONFIG.settingsPreview.maxTables, 1, 100),
      maxRows: clampInt(previewRaw.maxRows, DEFAULT_CONFIG.settingsPreview.maxRows, 1, 200),
      maxBytes: clampInt(previewRaw.maxBytes, DEFAULT_CONFIG.settingsPreview.maxBytes, 8192, 4 * 1024 * 1024),
      redact: typeof previewRaw.redact === 'boolean' ? previewRaw.redact : DEFAULT_CONFIG.settingsPreview.redact,
    },
    http: {
      enabled: typeof httpRaw.enabled === 'boolean' ? httpRaw.enabled : DEFAULT_CONFIG.http.enabled,
      host: typeof httpRaw.host === 'string' && httpRaw.host.trim() ? httpRaw.host.trim() : DEFAULT_CONFIG.http.host,
      port: clampInt(httpRaw.port, DEFAULT_CONFIG.http.port, 0, 65535),
      token: String(httpRaw.token || '').trim(),
      maxRows: clampInt(httpRaw.maxRows, DEFAULT_CONFIG.http.maxRows, 1, 100000),
    },
    admin: {
      enabled: typeof adminRaw.enabled === 'boolean' ? adminRaw.enabled : DEFAULT_CONFIG.admin.enabled,
      openids: Array.isArray(adminRaw.openids)
        ? adminRaw.openids.map((s) => String(s == null ? '' : s).trim()).filter(Boolean)
        : [],
      allowWrite: typeof adminRaw.allowWrite === 'boolean' ? adminRaw.allowWrite : DEFAULT_CONFIG.admin.allowWrite,
      groupEnabled:
        typeof adminRaw.groupEnabled === 'boolean' ? adminRaw.groupEnabled : DEFAULT_CONFIG.admin.groupEnabled,
      maxRows: clampInt(adminRaw.maxRows, DEFAULT_CONFIG.admin.maxRows, 1, 200),
    },
  };
}

function resolveDataDir(pluginDir, configured) {
  const value = String(configured || DEFAULT_CONFIG.dataDir);
  return path.isAbsolute(value) ? path.normalize(value) : path.join(pluginDir, value);
}

/**
 * 设置页快照（sandbox iframe 读不到文件系统，也发不了请求，只能由插件在 onLoad 注入）：
 *   <script type="application/json" id="vsql-runtime">  路径 / 版本 / HTTP 状态
 *   <script type="application/json" id="vsql-data">     各库的表清单 + 每表前 N 行（只读预览）
 * 内容只含路径、表结构、少量行，不含 HTTP 令牌；疑似敏感列名默认打码。
 */
const SETTINGS_RUNTIME_RE = /<script type="application\/json" id="vsql-runtime">[\s\S]*?<\/script>/;
const SETTINGS_DATA_RE = /<script type="application\/json" id="vsql-data">[\s\S]*?<\/script>/;

const PREVIEW_SENSITIVE = /(token|secret|password|passwd|sid|session|credential|api[_-]?key)/i;
const PREVIEW_CELL_MAX = 120;
const PREVIEW_SKIP_TABLE = /^__vsql_/;

function previewValue(value) {
  if (value === null || value === undefined) return null;
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) return `<blob ${value.length} B>`;
  const type = typeof value;
  if (type === 'string') {
    return value.length > PREVIEW_CELL_MAX ? value.slice(0, PREVIEW_CELL_MAX) + '…' : value;
  }
  if (type === 'number' || type === 'boolean') return value;
  return String(value);
}

/** 收集各命名空间的表清单与样例行（供设置页「数据浏览」只读展示） */
function buildPreview(rt) {
  const cfg = rt.config.settingsPreview;
  const preview = {
    enabled: !!cfg.enabled,
    generatedAt: Date.now(),
    defaultNamespace: rt.manager.defaultNamespace,
    namespaces: [],
    truncated: false,
    maxRows: cfg.maxRows,
  };
  if (!cfg.enabled) return preview;

  let list = [];
  try {
    list = rt.manager.list().filter((item) => item.file !== ':memory:');
  } catch {
    list = [];
  }
  list.sort((a, b) =>
    a.namespace === rt.manager.defaultNamespace ? -1 : b.namespace === rt.manager.defaultNamespace ? 1 : 0,
  );

  let budget = cfg.maxBytes;
  let sampledTables = 0;

  for (const item of list.slice(0, cfg.maxNamespaces)) {
    let db = null;
    try {
      db = rt.manager.db(item.namespace);
    } catch {
      continue;
    }
    let names = [];
    try {
      names = db
        .tables({ counts: false })
        .map((t) => t.name)
        .filter((n) => !PREVIEW_SKIP_TABLE.test(n));
    } catch {
      names = [];
    }
    const entry = { namespace: item.namespace, file: item.file, size: item.totalSize || 0, tables: [] };

    for (const name of names) {
      let rows = null;
      try {
        rows = db.count(name);
      } catch {
        rows = null;
      }
      const table = { name, rows, columns: [], sample: [], sampled: false };
      if (sampledTables < cfg.maxTables) {
        try {
          table.columns = db.columns(name).map((c) => ({
            name: c.name,
            type: String(c.type || ''),
            pk: Number(c.pk) || 0,
          }));
          const data = db.select(name, null, { limit: cfg.maxRows });
          const sample = data.map((row) => {
            const out = {};
            for (const col of Object.keys(row)) {
              const raw = row[col];
              const redacted = cfg.redact && raw != null && PREVIEW_SENSITIVE.test(col);
              out[col] = redacted ? '***' : previewValue(raw);
            }
            return out;
          });
          const size = JSON.stringify(sample).length;
          if (size <= budget) {
            table.sample = sample;
            table.sampled = true;
            budget -= size;
            sampledTables++;
          } else {
            table.truncated = true;
            preview.truncated = true;
          }
        } catch {
          table.error = '读取失败';
        }
      }
      entry.tables.push(table);
    }
    preview.namespaces.push(entry);
  }
  return preview;
}

/** 防止数据里的 </script> 或 <!-- 破坏 HTML：把 < 转义成 JSON 的 \u003c */
function safeJson(value) {
  return JSON.stringify(value).replace(/</g, '\\u003c');
}

function injectSettingsSnapshot(rt) {
  if (!rt.config.injectSettings) return false;
  const file = path.join(rt.pluginDir, 'settings.html');
  try {
    const html = fs.readFileSync(file, 'utf8');
    let next = html;
    let found = false;

    if (SETTINGS_RUNTIME_RE.test(next)) {
      found = true;
      const snapshot = {
        version: rt.version,
        pluginDir: rt.pluginDir,
        dataDir: rt.dataDir,
        defaultNamespace: rt.manager.defaultNamespace,
        http: rt.http ? rt.http.info() : { enabled: rt.config.http.enabled, running: false },
      };
      next = next.replace(
        SETTINGS_RUNTIME_RE,
        `<script type="application/json" id="vsql-runtime">${safeJson(snapshot)}</script>`,
      );
    }

    if (SETTINGS_DATA_RE.test(next) && rt.manager && typeof rt.manager.list === 'function') {
      found = true;
      const preview = buildPreview(rt);
      next = next.replace(
        SETTINGS_DATA_RE,
        `<script type="application/json" id="vsql-data">${safeJson(preview)}</script>`,
      );
    }

    if (found && next !== html) fs.writeFileSync(file, next, 'utf8');
    return found;
  } catch (e) {
    if (rt.log) rt.log.warn(`VSQL 设置页快照写入失败：${e.message}`);
    return false;
  }
}


/* ======================= 生命周期 ======================= */

function buildRuntime(ctx) {
  const pluginDir = ctx?.plugin?.dir || __dirname;
  const cfg = normalizeConfig(ctx?.plugin?.config);
  const dataDir = resolveDataDir(pluginDir, cfg.dataDir);
  fs.mkdirSync(dataDir, { recursive: true });

  const manager = new NamespaceManager({
    root: dataDir,
    defaultNamespace: cfg.defaultNamespace,
    maxOpen: cfg.maxOpen,
    autoCreate: cfg.autoCreate,
    allowAttach: cfg.allowAttach,
    busyTimeoutMs: cfg.busyTimeoutMs,
    log: ctx?.log || null,
  });

  return {
    pluginDir,
    dataDir,
    config: cfg,
    manager,
    log: ctx?.log || null,
    http: null,
    startedAt: Date.now(),
    version: PLUGIN_VERSION,
  };
}

async function shutdown() {
  const rt = runtime;
  runtime = null;
  if (!rt) return;
  API.unbind();
  // 先同步关库：框架删除/更新插件时不会等 onUnload 完成（只等 600ms 重试），
  // 晚关一步就会 fs.rmSync EPERM（插件目录被 SQLite 文件占用）。
  try {
    rt.manager.closeAll();
  } catch {
    /* ignore */
  }
  if (rt.http) {
    try {
      // server.close / closeAllConnections 是同步发起的；这里不再 await，
      // 避免把「释放文件」拖到 HTTP 优雅关闭之后。
      const stopping = rt.http.stop();
      if (stopping && typeof stopping.catch === 'function') stopping.catch(() => {});
    } catch {
      /* ignore */
    }
  }
}

async function startHttp(rt) {
  if (!rt.config.http.enabled) {
    if (rt.log) rt.log.info('VSQL HTTP 网关未启用（config.http.enabled=false）');
    return;
  }
  const gateway = new HttpGateway({
    manager: rt.manager,
    log: rt.log,
    config: rt.config.http,
    dataDir: rt.dataDir,
    version: rt.version,
  });
  rt.http = gateway;
  try {
    await gateway.start();
  } catch (e) {
    rt.http = null;
    if (rt.log) rt.log.warn(`VSQL ${U.describeError(e)}（数据库本身不受影响，可改 config.http.port 或关掉 HTTP）`);
  }
}

module.exports = {
  async onLoad(ctx) {
    const log = ctx?.log;
    if (runtime) await shutdown();
    try {
      runtime = buildRuntime(ctx);
    } catch (e) {
      if (log) log.error(`VSQL 初始化失败：${U.describeError(e)}`);
      throw e;
    }
    API.bind(runtime);
    if (log) {
      log.info(
        `VSQL v${PLUGIN_VERSION} 已加载：数据库目录 ${runtime.dataDir}（默认命名空间 ${runtime.manager.defaultNamespace}，` +
          `最大打开 ${runtime.manager.maxOpen}，ATTACH ${runtime.config.allowAttach ? '允许' : '禁用'}）`,
      );
      log.info('VSQL 对外 API 已注册：__JLWBOT_PLUGIN_APIS__.get("VSQL")');
    }
    await startHttp(runtime);
    injectSettingsSnapshot(runtime);
  },

  async onUnload(ctx) {
    const rt = runtime;
    const count = rt ? rt.manager.openCount() : 0;
    await shutdown();
    if (ctx?.log) ctx.log.info(`VSQL 已卸载：关闭 ${count} 个数据库句柄`);
  },

  async onEvent(ctx) {
    if (!runtime) return null;
    const message = ctx?.message;
    if (!message) return null;
    // 私聊始终可用；群聊默认关闭（结果全群可见，只在 admin.groupEnabled 打开时放行）
    const inGroup = message.kind === 'group';
    if (message.kind !== 'c2c' && !(inGroup && runtime.config.admin.groupEnabled)) return null;
    const command = message.command || {};
    if (String(command.name || '').toLowerCase() !== 'vsql') return null;
    return handleAdminCommand(runtime, ctx, message);
  },
};

/* ======================= /vsql 管理指令 ======================= */

function senderIds(message) {
  const author = message?.author || {};
  return [author.user_openid, author.member_openid, author.id, author.union_openid]
    .map((v) => String(v || '').trim())
    .filter(Boolean);
}

function adminGate(cfg, message) {
  if (cfg.admin.enabled === false) return { allowed: false, reason: 'disabled' };
  const ids = senderIds(message);
  if (!cfg.admin.openids.length) return { allowed: false, reason: 'no-admin', ids };
  const hit = ids.find((id) => cfg.admin.openids.includes(id));
  return hit ? { allowed: true, openid: hit, ids } : { allowed: false, reason: 'not-admin', ids };
}

function clip(text, max = 1400) {
  const s = String(text == null ? '' : text);
  if (s.length <= max) return s;
  return s.slice(0, Math.max(0, max - 24)) + `\n…（已截断，共 ${s.length} 字）`;
}

function jsonLine(value) {
  let text;
  try {
    text = JSON.stringify(value);
  } catch {
    text = String(value);
  }
  return text.length > 400 ? text.slice(0, 397) + '…' : text;
}

function readOnlySql(sqlText) {
  const head = String(sqlText).trim().toLowerCase();
  if (/^(select|pragma|explain)\b/.test(head)) return true;
  if (/^with\b/.test(head)) return !/\b(insert|update|delete|replace|attach|drop|alter|create)\b/.test(head);
  if (head.startsWith('values') || head.startsWith('table ')) return true;
  return false;
}

function helpText() {
  return [
    'VSQL · 内置 SQLite 管理指令（仅私聊管理员）',
    '',
    '/vsql stats            运行状态（目录 / 命名空间 / 大小 / HTTP）',
    '/vsql list             列出所有命名空间',
    '/vsql tables <ns>      列出某库的表和行数',
    '/vsql schema <ns>      看建表语句',
    `/vsql sql <ns> <SQL>   执行 SQL（默认只读，写要开 allowWrite）`,
    '/vsql backup [ns]      在线备份到 backups/ 目录',
    '/vsql token            查看本机 HTTP 网关令牌',
    '',
    '插件里直接用：__JLWBOT_PLUGIN_APIS__.get("VSQL").db("你的插件ID")',
  ].join('\n');
}

function statsText(rt) {
  const stats = API.stats();
  const http = stats.http || {};
  const lines = [
    `VSQL v${stats.version} · ${stats.ready ? '就绪' : '未就绪'} · ${stats.engine}${stats.sqliteVersion ? ' / SQLite ' + stats.sqliteVersion : ''}`,
    `数据目录：${stats.dataDir}`,
    `命名空间：${stats.namespaces} 个（已打开 ${stats.open}）· 合计 ${stats.human}`,
    `默认命名空间：${stats.defaultNamespace} · 最大打开：${rt.manager.maxOpen} · ATTACH：${stats.allowAttach ? '允许' : '禁用'}`,
    http.running
      ? `HTTP：${http.url}（开，最多 ${http.maxRows} 行/次）`
      : `HTTP：未运行（${http.enabled === false ? '配置里关闭' : '启动失败或未就绪'}）`,
    `运行时长：${Math.round(stats.uptimeMs / 1000)} 秒`,
  ];
  return lines.join('\n');
}

function listText(rt) {
  const list = rt.manager.list();
  if (!list.length) return '还没有任何命名空间（插件第一次调用 vsql.db(...) 时自动创建）';
  const lines = [`命名空间 ${list.length} 个：`];
  for (const item of list.slice(0, 40)) {
    lines.push(
      `· ${item.namespace}  ${U.humanBytes(item.totalSize)}  ` +
        `${item.tables == null ? '未打开' : item.tables + ' 表'}  ${item.open ? '已打开' : '未打开'}`,
    );
  }
  if (list.length > 40) lines.push(`…另有 ${list.length - 40} 个未显示`);
  return lines.join('\n');
}

function tablesText(rt, namespace) {
  const ns = namespace || rt.manager.defaultNamespace;
  const db = rt.manager.db(ns, { create: false });
  const tables = db.tables();
  if (!tables.length) return `命名空间「${ns}」还没有表（${db.file}）`;
  const lines = [`命名空间「${ns}」共 ${tables.length} 张表：`];
  for (const t of tables.slice(0, 40)) lines.push(`· ${t.name}  ${t.rows} 行`);
  if (tables.length > 40) lines.push(`…另有 ${tables.length - 40} 张未显示`);
  return lines.join('\n');
}

function schemaText(rt, namespace) {
  const ns = namespace || rt.manager.defaultNamespace;
  const db = rt.manager.db(ns, { create: false });
  const rows = db.schema();
  if (!rows.length) return `命名空间「${ns}」还没有任何结构`;
  const lines = [];
  for (const row of rows) {
    lines.push(`-- ${row.type} ${row.name}`);
    lines.push(String(row.sql || '').trim());
  }
  return clip(lines.join('\n'), 1600);
}

async function commandBackup(rt, namespace) {
  const ns = namespace || rt.manager.defaultNamespace;
  const db = rt.manager.db(ns, { create: false });
  if (!db) return `命名空间「${ns}」不存在`;
  const result = await db.backup();
  return `已备份「${ns}」到：\n${result.file}\n大小：${U.humanBytes(result.size)}`;
}

function commandSql(rt, namespace, sqlText) {
  const cfg = rt.config;
  const ns = namespace || rt.manager.defaultNamespace;
  if (!sqlText || !sqlText.trim()) return '用法：/vsql sql <命名空间> <SQL>';
  if (!cfg.admin.allowWrite && !readOnlySql(sqlText)) {
    return '已拒绝：管理指令默认只允许 SELECT / PRAGMA / EXPLAIN / 只读 WITH。\n' +
      '要执行写操作，请在插件设置里把「允许管理指令写 SQL」打开。';
  }
  const db = rt.manager.db(ns);
  const started = Date.now();
  const head = sqlText.trim().toLowerCase();
  try {
    if (/^(select|with|values|table|pragma|explain)\b/.test(head)) {
      const rows = db.all(sqlText);
      const ms = Date.now() - started;
      if (!rows.length) return `[${ns}] 0 行 · ${ms}ms`;
      const max = cfg.admin.maxRows;
      const lines = rows.slice(0, max).map((row, i) => `${i + 1}. ${jsonLine(row)}`);
      if (rows.length > max) lines.push(`…共 ${rows.length} 行，只显示前 ${max} 行`);
      lines.push(`[${ns}] ${rows.length} 行 · ${ms}ms`);
      return clip(lines.join('\n'), 1500);
    }
    const result = db.run(sqlText);
    return `[${ns}] 执行完成：changes=${result.changes} · lastInsertRowid=${result.lastInsertRowid} · ${Date.now() - started}ms`;
  } catch (e) {
    return `SQL 执行失败：${U.describeError(e)}`;
  }
}

async function handleAdminCommand(rt, ctx, message) {
  const cfg = rt.config;
  const gate = adminGate(cfg, message);
  if (!gate.allowed) {
    if (gate.reason === 'no-admin') {
      // 首次使用引导：把发送者自己的 OpenID 回给本人（只回私聊，不广播）
      return {
        reply:
          'VSQL 还没配置管理员。\n' +
          `你的 OpenID：${gate.ids[0] || '（取不到）'}\n` +
          '把它填进插件设置 → 管理指令 → 管理员 OpenID，保存后重新私聊 /vsql 即可。',
      };
    }
    return null; // 非管理员静默忽略
  }

  const text = String(message.command?.text || '').trim();
  const first = text.match(/^(\S+)(?:\s+([\s\S]*))?$/) || [];
  const sub = (first[1] || 'help').toLowerCase();
  const rest = first[2] || '';

  try {
    return await runAdminSub(rt, sub, rest);
  } catch (e) {
    return { reply: `执行失败：${U.describeError(e)}` };
  }
}

async function runAdminSub(rt, sub, rest) {
  switch (sub) {
    case 'stats':
    case '统计':
      return { reply: statsText(rt) };
    case 'list':
    case 'dbs':
    case '库':
      return { reply: listText(rt) };
    case 'tables':
    case '表': {
      const ns = rest.trim().split(/\s+/)[0] || '';
      return { reply: tablesText(rt, ns) };
    }
    case 'schema':
    case '结构': {
      const ns = rest.trim().split(/\s+/)[0] || '';
      return { reply: schemaText(rt, ns) };
    }
    case 'sql': {
      const m = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest.trim());
      if (!m) return { reply: '用法：/vsql sql <命名空间> <SQL>' };
      return { reply: commandSql(rt, m[1], m[2] || '') };
    }
    case 'backup':
    case '备份': {
      const ns = rest.trim().split(/\s+/)[0] || '';
      try {
        return { reply: await commandBackup(rt, ns) };
      } catch (e) {
        return { reply: `备份失败：${U.describeError(e)}` };
      }
    }
    case 'token':
    case '令牌':
      return {
        reply: rt.http && rt.http.token()
          ? `HTTP 网关：${rt.http.info().url}\n令牌：${rt.http.token()}\n（不要发到群里；换令牌请改 config.http.token）`
          : 'HTTP 网关未启用或启动失败，没有令牌。',
      };
    default:
      return { reply: helpText() };
  }
}

/* 只给 test/vsql-test.js 用 */
module.exports.__test = {
  normalizeConfig,
  readOnlySql,
  DEFAULT_CONFIG,
  injectSettingsSnapshot,
  buildPreview,
  getRuntime: () => runtime,
};
