'use strict';
/**
 * QQ 机器人网关 WebSocket 客户端
 * 协议：Hello(op10) → Identify(op2) → Ready / Heartbeat(op1) / Dispatch(op0) / Resume(op6)
 * 支持：心跳、断线重连、resume 补发、分片参数、zlib 帧解码
 */
const { EventEmitter } = require('events');
const zlib = require('zlib');

const CLOSE_REASONS = {
  4001: '无效的 opcode',
  4002: '无效的 payload',
  4006: '无效的 session id',
  4007: 'seq 错误',
  4008: '发送 payload 过快',
  4009: '连接过期',
  4010: '无效的 shard',
  4011: '需要分片',
  4012: '无效的 version',
  4013: '无效的 intent',
  4014: 'intent 无权限',
  4914: '机器人已下架，仅允许沙箱',
  4915: '机器人已封禁',
};

const MAX_RECONNECT_ATTEMPTS = 8;
const DEFAULT_COOLDOWN_SEC = 60;
const MIN_COOLDOWN_SEC = 1;
const MAX_COOLDOWN_SEC = 3600;
const GATEWAY_CACHE_MS = 30 * 60 * 1000;
const RATE_LIMIT_COOLDOWN = 60 * 1000;
const DEFAULT_GATEWAY = 'wss://api.sgroup.qq.com/websocket';
const SANDBOX_GATEWAY = 'wss://sandbox.api.sgroup.qq.com/websocket';

class Gateway extends EventEmitter {
  constructor({ config, token, logger, api }) {
    super();
    this.config = config;
    this.token = token;
    this.api = api;
    this.accountId = config.accountId || '';
    this.log = logger.child(this.accountId ? 'gateway:' + this.accountId : 'gateway');
    this.ws = null;
    this.state = 'idle'; // idle|connecting|identifying|online|resuming|reconnecting|cooldown|closed|fatal
    this.url = '';
    this.sessionId = '';
    this.seq = null;
    this.lastAckAt = 0;
    this.latency = 0;
    this.attempts = 0;
    this.reconnects = 0;
    this.round = 0;
    this.cooldownUntil = 0;
    this.cooldownTimer = null;
    this.connectedAt = 0;
    this.heartbeatTimer = null;
    this.ackTimer = null;
    this.reconnectTimer = null;
    this.manualClose = false;
    // 异常重连：false 时掉线不再自动重连（面板「异常重连」开关）
    this.autoReconnect = true;
    this.lastError = null;
    this.self = null;
    this.gatewayUrl = '';
    this.gatewayUrlAt = 0;
    this.gatewayUrlFallback = false;
    this.rateLimitUntil = 0;
    this._hbSentAt = 0;
    this._inflight = new Map();
  }

  info() {
    return {
      accountId: this.accountId,
      state: this.state,
      url: this.url,
      sessionId: this.sessionId ? this.sessionId.slice(0, 8) + '…' : '',
      seq: this.seq,
      latency: this.latency,
      connectedAt: this.connectedAt,
      reconnects: this.reconnects,
      attempts: this.attempts,
      round: this.round,
      cooldownUntil: this.cooldownUntil,
      lastError: this.lastError,
      self: this.self,
      shard: [this.config.get('bot.shardId', 0), this.config.get('bot.shardCount', 1)],
    };
  }

  _setState(s) {
    if (this.state === s) return;
    this.state = s;
    this._emitSafe('state', this.info());
  }

  /**
   * 事件分发隔离：监听方（Bot / 面板桥）抛错不能反过来打崩网关或主进程。
   * 机器人掉线重连是“业务状态”，绝不能影响框架（面板）自身。
   */
  _emitSafe(event, payload) {
    try {
      this.emit(event, payload);
    } catch (e) {
      try {
        this.log.error(`网关事件处理异常 ${event}: ${e.message}`, { stack: String(e.stack || '').split('\n').slice(0, 6).join('\n') });
      } catch {
        /* ignore */
      }
    }
  }

  intentsMask() {
    return require('./intents').mask(this.config.get('bot.intents', []));
  }

  async connect() {
    const manual =
      this.manualClose || this.state === 'fatal' || this.state === 'closed' || this.state === 'idle' || this.state === 'cooldown';
    this.manualClose = false;
    clearTimeout(this.reconnectTimer);
    this._clearCooldown();
    if (manual) {
      this.attempts = 0;
      this.rateLimitUntil = 0;
      if (this.gatewayUrlFallback) {
        this.gatewayUrl = '';
        this.gatewayUrlFallback = false;
      }
    }
    if (this.ws) this._hardClose();
    this._setState('connecting');
    try {
      await this.token.get();
    } catch (e) {
      this.log.warn('预取 access_token 失败：' + e.message);
    }
    try {
      const url = await this._resolveGatewayUrl();
      this.url = url;
      this.log.info('连接网关', { url, cached: url === this.gatewayUrl && Date.now() - this.gatewayUrlAt < GATEWAY_CACHE_MS });
      this._open(url);
    } catch (e) {
      this.lastError = e.message;
      this.log.error('网关连接失败: ' + e.message);
      if (e.fatal || e.code === 11298) {
        this._setState('fatal');
        this._emitSafe('fatal', { code: e.code || 11298, reason: e.message, hint: e.hint });
        return;
      }
      this._scheduleReconnect(e.retryAfterMs || 0);
    }
  }

  async _resolveGatewayUrl() {
    const configured = this.config.get('bot.gatewayUrl');
    if (configured) return configured;

    const now = Date.now();
    if (this.gatewayUrl && now - this.gatewayUrlAt < GATEWAY_CACHE_MS) return this.gatewayUrl;

    if (this.rateLimitUntil > now) {
      if (this.gatewayUrl) return this.gatewayUrl;
      const wait = Math.ceil((this.rateLimitUntil - now) / 1000);
      const e = new Error(`网关地址接口限频，冷却中（约 ${wait} 秒）`);
      e.code = 'RATE_LIMIT';
      e.retryAfterMs = this.rateLimitUntil - now;
      throw e;
    }

    const res = await this.api.get('/gateway');
    if (!res.ok) {
      if (isIpWhitelistResult(res)) {
        const e = new Error(res.message || '接口访问源 IP 不在白名单');
        e.code = 11298;
        e.fatal = true;
        e.hint = res.hint || '请到 QQ 开放平台为该机器人添加当前公网 IP，或关闭 IP 白名单后点「重连」。';
        throw e;
      }
      if (isRateLimitResult(res)) {
        this.rateLimitUntil = now + RATE_LIMIT_COOLDOWN;
        if (this.gatewayUrl) {
          this.log.warn('网关地址接口限频，使用缓存地址继续连接');
          return this.gatewayUrl;
        }
        // 没有缓存时使用官方固定地址兜底，避免因 /gateway 限频完全无法连接
        const fallback = this.config.get('bot.sandbox') ? SANDBOX_GATEWAY : DEFAULT_GATEWAY;
        this.gatewayUrl = fallback;
        this.gatewayUrlAt = now;
        this.gatewayUrlFallback = true;
        this.log.warn('网关地址接口限频，临时使用默认网关地址', { url: fallback });
        return fallback;
      }
      throw new Error(res.message || '获取网关地址失败');
    }
    const url = res.data?.url;
    if (!url) throw new Error('获取网关地址失败：返回中没有 url');
    this.gatewayUrl = url;
    this.gatewayUrlAt = Date.now();
    this.gatewayUrlFallback = false;
    this.rateLimitUntil = 0;
    this.log.info('网关地址已获取并缓存，后续重连不再反复请求 /gateway');
    return url;
  }

  _open(url) {
    let ws;
    try {
      ws = new WebSocket(url);
    } catch (e) {
      this.lastError = e.message;
      this._scheduleReconnect();
      return;
    }
    this.ws = ws;
    try {
      ws.binaryType = 'arraybuffer';
    } catch {
      /* ignore */
    }

    ws.addEventListener('open', () => {
      this.log.debug('WebSocket 已建立');
    });

    ws.addEventListener('message', (ev) => {
      this._onFrame(ev.data).catch((e) => this.log.error('处理帧失败: ' + e.message));
    });

    ws.addEventListener('error', () => {
      // close 事件会随后到达，这里只记录
      this.log.debug('WebSocket error');
    });

    ws.addEventListener('close', (ev) => {
      this._onClose(ev.code, ev.reason);
    });
  }

  /** 处理连接关闭：区分可重连/需要重建 session/必须人工处理 */
  _onClose(code, why) {
    this.ws = null;
    this._stopHeartbeat();
    const reason = CLOSE_REASONS[code] || why || '连接关闭';
    this.log.warn(`WebSocket 关闭 ${code} ${reason}`, { code });
    this.lastError = `${code} ${reason}`;
    this.connectedAt = 0;
    if (this.manualClose) {
      this._setState('closed');
      return;
    }
    if (!this.autoReconnect) {
      this.lastError = `${code} ${reason}（已关闭异常重连）`;
      this._setState('closed');
      this.log.warn('连接已断开，异常重连已关闭，等待手动重连', { code });
      this._emitSafe('notice', {
        level: 'warn',
        message: `${this.accountId || '账户'}：连接断开（${code} ${reason}），异常重连已关闭，需手动点「重连」`,
        accountId: this.accountId,
      });
      return;
    }
    if (code === 4914 || code === 4915 || code === 4013 || code === 4014) {
      this._setState('fatal');
      this._emitSafe('fatal', { code, reason });
      return;
    }
    // 4009（连接过期）必须丢掉旧 session 重新 Identify，否则会一直 Resume 失败
    if ([4006, 4007, 4009, 4010, 4011, 4012, 4001, 4002].includes(code)) {
      this.sessionId = '';
      this.seq = null;
    }
    this._scheduleReconnect();
  }

  async _onFrame(data) {
    let text = null;
    if (typeof data === 'string') text = data;
    else if (data instanceof ArrayBuffer) text = decodeBinary(Buffer.from(data));
    else if (ArrayBuffer.isView(data)) text = decodeBinary(Buffer.from(data.buffer, data.byteOffset, data.byteLength));
    else if (typeof data?.text === 'function') text = await data.text();
    else if (Buffer.isBuffer(data)) text = decodeBinary(data);
    if (!text) return;

    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      this.log.warn('收到无法解析的帧', { head: text.slice(0, 120) });
      return;
    }
    await this._handle(payload);
  }

  async _handle(payload) {
    const { op, d, s, t, id } = payload;
    if (typeof s === 'number') this.seq = s;

    switch (op) {
      case 10: {
        // Hello
        const interval = d?.heartbeat_interval || 45000;
        this.log.debug('Hello', { interval });
        this._startHeartbeat(interval);
        if (this.sessionId) this._setState('resuming');
        else this._setState('identifying');
        try {
          await this.token.get();
        } catch (e) {
          this.lastError = '获取 access_token 失败：' + e.message;
          this.log.error(this.lastError);
          this._hardClose(4013);
          return;
        }
        if (this.sessionId) this._sendResume();
        else this._sendIdentify();
        break;
      }
      case 11: {
        // Heartbeat ACK
        this.lastAckAt = Date.now();
        this.latency = Date.now() - this._hbSentAt;
        if (this.state !== 'online') this._setState('online');
        break;
      }
      case 0: {
        if (t === 'READY') {
          this.sessionId = d?.session_id || '';
          this.self = d?.user || null;
          this.connectedAt = Date.now();
          this.attempts = 0;
          this.round = 0;
          this._clearCooldown();
          this.rateLimitUntil = 0;
          this.gatewayUrlFallback = false;
          if (!this.config.get('bot.gatewayUrl')) this.gatewayUrlAt = Date.now();
          this.lastError = null;
          this._setState('online');
          this.log.info('网关就绪', { session: this.sessionId.slice(0, 8), user: this.self?.username });
          this._emitSafe('ready', d);
        } else if (t === 'RESUMED') {
          this._setState('online');
          this.log.info('会话恢复完成');
          this._emitSafe('resumed', d);
        } else {
          this._emitSafe('dispatch', { t, d, s, id });
        }
        break;
      }
      case 7: {
        this.log.warn('服务端要求重连');
        this._hardClose(4009);
        break;
      }
      case 9: {
        this.log.warn('无效会话（Invalid Session）');
        this.sessionId = '';
        this.seq = null;
        this._hardClose(4009);
        break;
      }
      default:
        break;
    }
  }

  _sendIdentify() {
    const token = this.token.token;
    if (!token) {
      this.log.error('identify 时缺少 access_token');
      this._hardClose(4013);
      return;
    }
    const shardId = Number(this.config.get('bot.shardId', 0)) || 0;
    const shardCount = Math.max(1, Number(this.config.get('bot.shardCount', 1)) || 1);
    this._send({
      op: 2,
      d: {
        token: 'QQBot ' + token,
        intents: this.intentsMask(),
        shard: [shardId, shardCount],
        properties: { $os: process.platform, $browser: 'JlWBoT', $device: 'JlWBoT' },
      },
    });
    this.log.info('已发送 Identify', { intents: this.intentsMask(), shard: [shardId, shardCount] });
  }

  _sendResume() {
    const token = this.token.token;
    this._send({ op: 6, d: { token: 'QQBot ' + token, session_id: this.sessionId, seq: this.seq } });
    this.log.info('已发送 Resume', { seq: this.seq });
  }

  _send(obj) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    try {
      this.ws.send(JSON.stringify(obj));
      return true;
    } catch (e) {
      this.log.warn('发送失败: ' + e.message);
      return false;
    }
  }

  _startHeartbeat(interval) {
    this._stopHeartbeat();
    const tick = () => {
      this._hbSentAt = Date.now();
      this._send({ op: 1, d: this.seq ?? null });
      clearTimeout(this.ackTimer);
      this.ackTimer = setTimeout(() => {
        if (this.manualClose) return;
        this.log.warn('心跳超时，重连');
        this._hardClose(4009);
      }, Math.max(interval * 1.5, 15000));
    };
    this.heartbeatTimer = setInterval(tick, interval);
    if (this.heartbeatTimer.unref) this.heartbeatTimer.unref();
    tick();
  }

  _stopHeartbeat() {
    clearInterval(this.heartbeatTimer);
    clearTimeout(this.ackTimer);
    this.heartbeatTimer = null;
    this.ackTimer = null;
  }

  _cooldownMs() {
    let sec = Number(this.config.get('bot.reconnectCooldownSec', DEFAULT_COOLDOWN_SEC));
    if (!Number.isFinite(sec) || sec <= 0) sec = DEFAULT_COOLDOWN_SEC;
    sec = Math.min(MAX_COOLDOWN_SEC, Math.max(MIN_COOLDOWN_SEC, sec));
    return Math.round(sec * 1000);
  }

  _scheduleReconnect(minDelay = 0) {
    if (this.manualClose) return;
    if (!this.autoReconnect) {
      this._setState('closed');
      this.log.warn('异常重连已关闭，不再自动重连');
      return;
    }
    // 冷却期间由冷却定时器统一安排，旧连接的 close 事件不能插队
    if (this.cooldownUntil > Date.now()) return;
    if (this.attempts >= MAX_RECONNECT_ATTEMPTS) {
      this._startCooldown();
      return;
    }
    this.attempts++;
    this.reconnects++;
    let delay = Math.min(60000, 1000 * Math.pow(1.8, Math.min(this.attempts, 8))) + Math.random() * 500;
    if (this.rateLimitUntil > Date.now()) delay = Math.max(delay, this.rateLimitUntil - Date.now() + 500);
    if (minDelay) delay = Math.max(delay, minDelay);
    delay = Math.min(delay, 65000);
    this._setState('reconnecting');
    this.log.info(`将在 ${Math.round(delay)}ms 后重连（本轮第 ${this.attempts} 次）`);
    clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => {
      if (this.manualClose) return;
      this.connect();
    }, delay);
    if (this.reconnectTimer.unref) this.reconnectTimer.unref();
  }

  /**
   * 一轮重连用尽（默认 8 次）后不放弃：进入冷却，到点重置次数再来一轮，一直循环。
   * 只有 4914/4915（下架/封禁）与 IP 白名单这类需要人工处理的错误才保持 fatal。
   */
  _startCooldown() {
    if (this.manualClose) return;
    clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    const wait = this._cooldownMs();
    this.round++;
    this.cooldownUntil = Date.now() + wait;
    this.attempts = 0;
    this.gatewayUrl = '';
    this.gatewayUrlFallback = false;
    this.lastError = `本轮重连 ${MAX_RECONNECT_ATTEMPTS} 次未成功，${Math.round(wait / 1000)} 秒后开始第 ${this.round + 1} 轮`;
    this._setState('cooldown');
    this.log.warn(this.lastError + '（不会放弃，持续循环）');
    this._emitSafe('notice', {
      level: 'warn',
      message: `${this.accountId || '账户'}：${this.lastError}，将一直循环重试`,
      accountId: this.accountId,
    });
    clearTimeout(this.cooldownTimer);
    this.cooldownTimer = setTimeout(() => {
      if (this.manualClose) return;
      this.cooldownUntil = 0;
      this.log.info(`冷却结束（第 ${this.round} 轮），重新开始重连`);
      this._scheduleReconnect();
    }, wait);
    if (this.cooldownTimer.unref) this.cooldownTimer.unref();
  }

  _clearCooldown() {
    if (this.cooldownTimer) clearTimeout(this.cooldownTimer);
    this.cooldownTimer = null;
    this.cooldownUntil = 0;
  }

  _hardClose(code = 1000) {
    try {
      if (this.ws) this.ws.close(code);
    } catch {
      /* ignore */
    }
    this.ws = null;
    this._stopHeartbeat();
  }

  disconnect() {
    this.manualClose = true;
    clearTimeout(this.reconnectTimer);
    this._clearCooldown();
    clearInterval(this.heartbeatTimer);
    this._hardClose(1000);
    this.sessionId = '';
    this.seq = null;
    this.connectedAt = 0;
    this._setState('closed');
    this.log.info('网关已断开（手动）');
  }
}

/** QQ 网关可能发送 zlib 压缩的二进制帧，也可能是裸 JSON 文本 */
function decodeBinary(buf) {
  try {
    if (buf.length > 2 && buf[0] === 0x78) {
      const out = zlib.inflateSync(buf);
      return out.toString('utf8');
    }
  } catch {
    /* 不是 zlib */
  }
  return buf.toString('utf8');
}

function isIpWhitelistResult(res) {
  const code = Number(res?.code);
  const errCode = Number(res?.data?.err_code);
  const message = String(res?.data?.message || res?.message || '');
  return code === 11298 || errCode === 40023002 || /IP.*白名单|访问源IP|白名单/i.test(message);
}

function isRateLimitResult(res) {
  const code = Number(res?.code);
  const errCode = Number(res?.data?.err_code);
  const message = String(res?.data?.message || res?.message || '');
  return (
    res?.status === 429 ||
    code === 100017 ||
    errCode === 40023001 ||
    /频率限制|rate limit|too many requests/i.test(message)
  );
}

module.exports = Gateway;
module.exports.CLOSE_REASONS = CLOSE_REASONS;
module.exports.isIpWhitelistResult = isIpWhitelistResult;
module.exports.isRateLimitResult = isRateLimitResult;
