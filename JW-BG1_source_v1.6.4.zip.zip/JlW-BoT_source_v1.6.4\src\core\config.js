'use strict';
/**
 * 配置管理（多账户）
 * - 默认值来自项目根 config.default.json
 * - 实际配置保存在 ~JlWBoT/config.json
 * - accounts[] 是账户池，旧版单账户配置会自动迁移
 */
const path = require('path');
const fs = require('fs');
const U = require('./util');
const store = require('./store');

const DEFAULT_FILE = path.join(U.ROOT, 'config.default.json');
const OFFICIAL_SITE = 'https://www.jlworld.net';
const LOCAL_HOSTS = new Set(['127.0.0.1', 'localhost', '::1', '[::1]', '0.0.0.0']);
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function normalizeEmail(v) {
  return String(v || '').trim().toLowerCase();
}

function isValidEmail(v) {
  return EMAIL_RE.test(normalizeEmail(v));
}

const BOT_FIELDS = [
  'appId',
  'clientSecret',
  'mode',
  'sandbox',
  'tokenUrl',
  'tokenUrlAlt',
  'apiBase',
  'apiBaseSandbox',
  'gatewayUrl',
  'intents',
  'shardId',
  'shardCount',
  'prefix',
  'name',
  'atReply',
  'autoConnect',
  'autoReconnect',
  'reconnectCooldownSec',
];

class Config {
  constructor() {
    this.defaults = U.readJson(DEFAULT_FILE, {});
    this.file = U.p('config.json');
    this.notices = [];
    this.data = this._load();
    this._migrateAuthFromSessions();
  }

  _load() {
    U.ensureDir(U.dataRoot());
    // 先按 config.json 里的 storage.engine 选定存储后端（config.json 始终存在，作为镜像/引导）
    const bootstrap = U.readJson(this.file, null);
    store.setEngine(bootstrap && bootstrap.storage && bootstrap.storage.engine);
    // 配置主存：当前引擎（SQLite kv('config') 或 JSON config.json）；config.json 始终作为可读镜像
    // 手动改过 config.json（mtime 比库里那次保存新）就导入，避免“改了没生效”。
    const stored = store.kvGetWithTime('config');
    const fileExists = fs.existsSync(this.file);
    let fileMtime = 0;
    try {
      fileMtime = fileExists ? fs.statSync(this.file).mtimeMs : 0;
    } catch {
      fileMtime = 0;
    }
    let user = stored && stored.value && typeof stored.value === 'object' ? stored.value : null;
    if (user && fileExists && fileMtime > stored.updated + 1500) {
      const fromFile = U.readJson(this.file, null);
      if (fromFile && typeof fromFile === 'object' && JSON.stringify(fromFile) !== JSON.stringify(user)) {
        user = fromFile;
        this.notices.push('检测到 config.json 被手动修改，已导入 SQLite（面板里的设置会以导入后的为准）');
      }
    }
    if (!user && fileExists) user = U.readJson(this.file, null);
    if (!user) {
      user = JSON.parse(JSON.stringify(this.defaults));
      user.server = user.server || {};
      user.accounts = [];
    }
    const merged = U.deepMerge(this.defaults, user);
    merged.accounts = this._normalizeAccounts(merged, user.accounts);
    // 旧版的访问令牌已废弃：面板改为聚龙账户登录，直接清掉
    if (merged.server && merged.server.token !== undefined) delete merged.server.token;
    // 只保留聚龙账户插件接口，清理旧的 VloS 配置
    if (merged.jlw) {
      delete merged.jlw.mode;
      delete merged.jlw.key;
    }
    this._repairJlw(merged);
    this._normalizeAuth(merged);
    if (!merged.plugins) merged.plugins = {};
    if (!merged.plugins.token) {
      merged.plugins.token = U.randomToken(24);
    }
    store.kvSet('config', merged);
    U.writeJson(this.file, merged);
    return merged;  }

  _normalizeAccounts(merged, raw) {
    let list = Array.isArray(raw) ? raw : [];
    const base = merged.bot || {};
    if (!list.length) {
      // 旧配置迁移：把 bot 段变成一个账户
      list = [
        {
          id: 'main',
          name: base.name || '主账号',
          appId: base.appId || '',
          clientSecret: base.clientSecret || '',
          enabled: true,
          autoConnect: true,
          autoReconnect: true,
          mode: base.mode || 'ws',
          sandbox: !!base.sandbox,
          prefix: base.prefix || '',
          intents: base.intents || this.defaults.bot?.intents || [],
          shardId: base.shardId || 0,
          shardCount: base.shardCount || 1,
          tokenUrl: base.tokenUrl,
          tokenUrlAlt: base.tokenUrlAlt,
          apiBase: base.apiBase,
          apiBaseSandbox: base.apiBaseSandbox,
          gatewayUrl: base.gatewayUrl || '',
          webhookPath: '/qqbot/webhook',
          atReply: base.atReply !== false,
        },
      ];
    }
    const ids = new Set();
    const paths = new Set();
    return list.map((a, i) => {
      let id = String(a.id || '').replace(/[^a-zA-Z0-9_-]/g, '');
      if (!id) id = 'acc' + (i + 1);
      while (ids.has(id)) id = id + 'x';
      ids.add(id);
      let wp = String(a.webhookPath || '').trim();
      if (!wp || !wp.startsWith('/')) wp = '/qqbot/webhook/' + id;
      while (paths.has(wp)) wp = wp + '-' + i;
      paths.add(wp);
      const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
      return {
        id,
        name: String(a.name || id),
        appId: String(a.appId || ''),
        clientSecret: String(a.clientSecret || ''),
        enabled: a.enabled !== false,
        autoConnect: a.autoConnect !== false,
        autoReconnect: a.autoReconnect !== false,
        mode: a.mode === 'webhook' ? 'webhook' : 'ws',
        sandbox: !!a.sandbox,
        prefix: String(a.prefix ?? ''),
        intents: Array.isArray(a.intents) ? a.intents : this.defaults.bot?.intents || [],
        shardId: num(a.shardId, 0),
        shardCount: Math.max(1, num(a.shardCount, 1)),
        tokenUrl: a.tokenUrl || this.defaults.bot?.tokenUrl,
        tokenUrlAlt: a.tokenUrlAlt || this.defaults.bot?.tokenUrlAlt,
        apiBase: a.apiBase || this.defaults.bot?.apiBase,
        apiBaseSandbox: a.apiBaseSandbox || this.defaults.bot?.apiBaseSandbox,
        gatewayUrl: a.gatewayUrl || '',
        webhookPath: wp,
        atReply: a.atReply !== false,
      };
    });
  }

  /**
   * 账户站点自愈：
   * - 老版本导出的 config.json 可能把 jlw.baseUrl 存成空字符串；
   * - 早期调试版可能存成 127.0.0.1 / localhost，正式包里必然连不上。
   * 这两种情况都恢复成官方站点，避免面板显示“未配置”或直接 ECONNRESET。
   * 本地联调（mock 服务）可用 JLW_ALLOW_LOCAL_SITE=1 保留本机地址。
   */
  _repairJlw(merged) {
    if (!merged.jlw || typeof merged.jlw !== 'object') merged.jlw = {};
    const defaults = this.defaults.jlw || {};
    const fallback = String(defaults.baseUrl || OFFICIAL_SITE).replace(/\/+$/, '');
    let current = String(merged.jlw.baseUrl || '').trim().replace(/\/+$/, '');
    if (current && !/^https?:\/\//i.test(current)) current = 'https://' + current;
    let reason = '';
    if (!current) reason = '空地址';
    else {
      try {
        const host = new URL(current).hostname.toLowerCase().replace(/^\[|\]$/g, '');
        if (LOCAL_HOSTS.has(host) && process.env.JLW_ALLOW_LOCAL_SITE !== '1') {
          reason = '本机地址 ' + host;
        }
      } catch {
        reason = '地址格式错误';
      }
    }
    if (reason) {
      merged.jlw.baseUrl = fallback;
      this.notices.push(`账户站点已自动恢复为 ${fallback}（原配置：${reason}）`);
    } else {
      merged.jlw.baseUrl = current || fallback;
    }
    if (!merged.jlw.apiPath) merged.jlw.apiPath = defaults.apiPath || '/api/plugin/jl-account';
  }

  /** 登录范围：只有 allowed 里的聚龙账户可以登录面板 */
  _normalizeAuth(merged) {
    if (!merged.auth || typeof merged.auth !== 'object') merged.auth = {};
    const raw = Array.isArray(merged.auth.allowed) ? merged.auth.allowed : [];
    const out = [];
    const seen = new Set();
    for (const item of raw) {
      const o = typeof item === 'string' ? { email: item } : item && typeof item === 'object' ? item : null;
      if (!o) continue;
      const email = normalizeEmail(o.email);
      const id = String(o.id || '').trim();
      if (!email && !id) continue;
      const key = email ? 'e:' + email : 'i:' + id;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        email,
        id,
        name: String(o.name || ''),
        source: String(o.source || 'config'),
        addedAt: Number(o.addedAt) || Date.now(),
      });
    }
    merged.auth.allowed = out;
    if (out.length) merged.auth.initialized = true;
    else if (typeof merged.auth.initialized !== 'boolean') merged.auth.initialized = false;
  }

  /**
   * 从旧版本已有面板会话迁移登录范围，避免升级后把自己锁在门外。
   * 只在从未初始化过、且 allowed 为空时执行。
   */
  _migrateAuthFromSessions() {
    const auth = this.data.auth || (this.data.auth = { allowed: [], initialized: false });
    if (auth.allowed.length || auth.initialized) return;
    let raw = U.readJson(U.p('data', 'sessions.json'), {});
    if (!raw || !Object.keys(raw).length) {
      // 会话已经迁进 SQLite（旧 sessions.json 被移走）时，从库里兜底
      raw = {};
      for (const s of store.sessionLoadAll()) if (s && s.sid) raw[s.sid] = s;
    }
    const now = Date.now();
    const out = [];
    const seen = new Set();
    for (const s of Object.values(raw || {})) {
      if (!s || !s.expiresAt || s.expiresAt < now || !s.user) continue;
      const user = s.user;
      const email = normalizeEmail(user.email);
      const id = String(user.id || '').trim();
      if (!email && !id) continue;
      const key = email ? 'e:' + email : 'i:' + id;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        email,
        id,
        name: String(user.name || ''),
        source: 'session-migration',
        addedAt: Date.now(),
      });
    }
    if (!out.length) return;
    auth.allowed = out;
    auth.initialized = true;
    this.save();
    this.notices.push(`已从现有面板会话迁移 ${out.length} 个登录账户到「登录范围」`);
  }

  listAllowed() {
    return (this.data.auth?.allowed || []).map((a) => ({ ...a }));
  }

  hasLoginAccounts() {
    return this.listAllowed().length > 0;
  }

  isLoginAllowed(user, email) {
    // 仅用于测试/紧急恢复；正式环境不要设置
    if (process.env.JLW_ALLOW_ALL_LOGIN === '1') return true;
    const list = this.data.auth?.allowed || [];
    if (!list.length) return false;
    const em = normalizeEmail(email || user?.email);
    const id = String(user?.id || '').trim();
    return list.some((a) => (id && a.id && a.id === id) || (em && a.email && a.email === em));
  }

  addAllowedAccount(email, meta = {}) {
    const em = normalizeEmail(email);
    if (!isValidEmail(em)) throw new Error('聚龙账户邮箱格式不正确');
    const auth = this.data.auth || (this.data.auth = { allowed: [], initialized: false });
    const exists = auth.allowed.find((a) => a.email === em);
    if (exists) {
      if (meta.name) exists.name = String(meta.name);
      if (meta.id) exists.id = String(meta.id);
      auth.initialized = true;
      this.save();
      return { ...exists };
    }
    const entry = {
      email: em,
      id: String(meta.id || ''),
      name: String(meta.name || ''),
      source: String(meta.source || 'panel'),
      addedAt: Date.now(),
    };
    auth.allowed.push(entry);
    auth.initialized = true;
    this.save();
    return { ...entry };
  }

  removeAllowedAccount(key) {
    const k = String(key || '').trim().toLowerCase();
    const auth = this.data.auth || (this.data.auth = { allowed: [], initialized: false });
    const idx = auth.allowed.findIndex((a) => a.email === k || a.id === String(key || '').trim());
    if (idx < 0) throw new Error('该账户不在登录范围');
    if (auth.allowed.length <= 1) throw new Error('至少保留一个允许登录的账户');
    const [removed] = auth.allowed.splice(idx, 1);
    this.save();
    return { ...removed };
  }

  /** 登录成功后补齐 id/name，方便以后按 id 匹配（邮箱改了也不会锁死） */
  rememberAllowedUser(user) {
    if (!user) return;
    const auth = this.data.auth;
    if (!auth || !auth.allowed.length) return;
    const id = String(user.id || '').trim();
    const em = normalizeEmail(user.email);
    const hit = auth.allowed.find((a) => (id && a.id === id) || (em && a.email === em));
    if (!hit) return;
    let changed = false;
    if (id && hit.id !== id) {
      hit.id = id;
      changed = true;
    }
    if (user.name && hit.name !== user.name) {
      hit.name = String(user.name);
      changed = true;
    }
    if (!hit.email && em) {
      hit.email = em;
      changed = true;
    }
    if (changed) this.save();
  }

  /* ---------------- 通用读写 ---------------- */

  get(pathStr, fallback) {
    return pathStr.split('.').reduce((o, k) => (o == null ? undefined : o[k]), this.data) ?? fallback;
  }

  set(pathStr, value) {
    const keys = pathStr.split('.');
    let o = this.data;
    for (let i = 0; i < keys.length - 1; i++) {
      if (typeof o[keys[i]] !== 'object' || o[keys[i]] === null) o[keys[i]] = {};
      o = o[keys[i]];
    }
    o[keys[keys.length - 1]] = value;
  }

  /** 只允许更新白名单字段，避免面板误写坏结构 */
  update(patch) {
    const allowed = ['bot', 'server', 'webhook', 'plugins', 'log', 'storage', 'jlw', 'update', 'system'];
    for (const k of Object.keys(patch || {})) {
      if (!allowed.includes(k)) continue;
      if (U.isObj(this.data[k]) && U.isObj(patch[k])) this.data[k] = { ...this.data[k], ...patch[k] };
      else this.data[k] = patch[k];
    }
    this.save();
    return this.publicConfig();
  }

  save(next) {
    if (next) this.data = next;
    store.kvSet('config', this.data);
    // 镜像一份可读的 config.json；手改这个文件后重启会被检测并导入 SQLite
    U.writeJson(this.file, this.data);
  }

  /* ---------------- 账户 ---------------- */

  listAccounts() {
    return this.data.accounts || [];
  }

  getAccount(id) {
    return this.listAccounts().find((a) => a.id === id) || null;
  }

  defaultAccount() {
    const list = this.listAccounts();
    return list[0] || null;
  }

  /** 新建账户（自动生成 id 与 webhook 路径） */
  addAccount(input = {}) {
    const base = this.data.bot || {};
    let n = this.listAccounts().length + 1;
    let id = String(input.id || '').replace(/[^a-zA-Z0-9_-]/g, '');
    if (!id) id = 'acc' + Date.now().toString(36).slice(-5);
    while (this.getAccount(id)) id = id + 'x';
    const acc = {
      id,
      name: input.name || '账户 ' + n,
      appId: input.appId || '',
      clientSecret: input.clientSecret || '',
      enabled: input.enabled !== false,
      autoConnect: input.autoConnect !== false,
      autoReconnect: input.autoReconnect !== false,
      mode: input.mode === 'webhook' ? 'webhook' : 'ws',
      sandbox: !!input.sandbox,
      prefix: input.prefix ?? base.prefix ?? '',
      intents: Array.isArray(input.intents) && input.intents.length ? input.intents : base.intents || [],
      shardId: Number(input.shardId) || 0,
      shardCount: Math.max(1, Number(input.shardCount) || 1),
      tokenUrl: input.tokenUrl || base.tokenUrl,
      tokenUrlAlt: input.tokenUrlAlt || base.tokenUrlAlt,
      apiBase: input.apiBase || base.apiBase,
      apiBaseSandbox: input.apiBaseSandbox || base.apiBaseSandbox,
      gatewayUrl: input.gatewayUrl || '',
      webhookPath:
        input.webhookPath && String(input.webhookPath).startsWith('/') && !this.listAccounts().some((a) => a.webhookPath === input.webhookPath)
          ? input.webhookPath
          : '/qqbot/webhook/' + id,
      atReply: input.atReply !== false,
    };
    this.data.accounts.push(acc);
    this.save();
    return acc;
  }

  updateAccount(id, patch = {}) {
    const acc = this.getAccount(id);
    if (!acc) return null;
    for (const k of BOT_FIELDS) {
      if (patch[k] === undefined) continue;
      if (k === 'intents') acc.intents = Array.isArray(patch.intents) ? patch.intents : acc.intents;
      else if (k === 'shardCount') acc.shardCount = Math.max(1, Number(patch.shardCount) || 1);
      else if (k === 'shardId') acc.shardId = Number(patch.shardId) || 0;
      else if (k === 'sandbox') acc.sandbox = !!patch.sandbox;
      else if (k === 'autoConnect') acc.autoConnect = patch.autoConnect !== false;
      else if (k === 'autoReconnect') acc.autoReconnect = patch.autoReconnect !== false;
      else if (k === 'enabled') acc.enabled = patch.enabled !== false;
      else if (k === 'clientSecret' && patch.clientSecret === '******') continue;
      else if (k === 'mode') acc.mode = patch.mode === 'webhook' ? 'webhook' : 'ws';
      else acc[k] = patch[k];
    }
    if (patch.enabled !== undefined) acc.enabled = patch.enabled !== false;
    if (patch.webhookPath && String(patch.webhookPath).startsWith('/')) {
      const wp = String(patch.webhookPath);
      const conflict = this.listAccounts().some((a) => a.id !== id && a.webhookPath === wp);
      if (!conflict) acc.webhookPath = wp;
    }
    this.save();
    return acc;
  }

  removeAccount(id) {
    const i = this.listAccounts().findIndex((a) => a.id === id);
    if (i < 0) return false;
    this.data.accounts.splice(i, 1);
    this.save();
    return true;
  }

  /**
   * 账户视图：让 TokenManager / QQApi / Gateway / Bot 继续用 config.get('bot.xxx')
   * 但实际读到的是某个账户的字段，storage/server 等仍走全局配置。
   */
  accountView(acc) {
    const self = this;
    const map = {
      appId: 'appId',
      clientSecret: 'clientSecret',
      mode: 'mode',
      sandbox: 'sandbox',
      tokenUrl: 'tokenUrl',
      tokenUrlAlt: 'tokenUrlAlt',
      apiBase: 'apiBase',
      apiBaseSandbox: 'apiBaseSandbox',
      gatewayUrl: 'gatewayUrl',
      intents: 'intents',
      shardId: 'shardId',
      shardCount: 'shardCount',
      prefix: 'prefix',
      name: 'name',
      atReply: 'atReply',
      autoReconnect: 'autoReconnect',
      autoConnect: 'autoConnect',
    };
    return {
      account: acc,
      accountId: acc.id,
      get(key, fallback) {
        if (key === 'bot') {
          const out = {};
          for (const [k, prop] of Object.entries(map)) out[k] = acc[prop];
          return out;
        }
        if (key.startsWith('bot.')) {
          const prop = key.slice(4);
          if (map[prop]) {
            const v = acc[map[prop]];
            return v === undefined || v === null || v === '' ? (fallback !== undefined ? fallback : v) : v;
          }
          return self.get(key, fallback);
        }
        return self.get(key, fallback);
      },
      set(key, value) {
        if (key === 'bot.name' || key === 'bot.prefix') acc[key.slice(4)] = value;
        else self.set(key, value);
      },
      update(patch) {
        if (patch && patch.bot) self.updateAccount(acc.id, patch.bot);
        const rest = { ...(patch || {}) };
        delete rest.bot;
        if (Object.keys(rest).length) self.update(rest);
        else self.save();
        return self.publicConfig();
      },
      save: () => self.save(),
      secret: () => acc.clientSecret,
      get data() {
        return self.data;
      },
      file: self.file,
      hasCredentials: () => !!(acc.appId && acc.clientSecret),
    };
  }

  /** 面板可见配置（密钥打码） */
  publicConfig() {
    const c = JSON.parse(JSON.stringify(this.data));
    c.accounts = this.listAccounts().map((a) => ({
      ...a,
      clientSecret: a.clientSecret ? '******' : '',
      hasSecret: !!a.clientSecret,
      appIdMasked: a.appId ? a.appId.slice(0, 4) + '****' + a.appId.slice(-4) : '',
    }));
    c.hasSecret = this.listAccounts().some((a) => a.clientSecret);
    if (c.server) delete c.server.token;
    if (c.jlw) {
      c.jlw.configured = !!c.jlw.baseUrl;
    }
    if (c.auth) {
      c.auth = { count: Array.isArray(c.auth.allowed) ? c.auth.allowed.length : 0, initialized: !!c.auth.initialized };
    }
    if (c.plugins) {
      c.plugins.hasToken = !!c.plugins.token;
      c.plugins.token = c.plugins.token ? '******' : '';
    }
    if (c.bot) c.bot.clientSecret = '';
    return c;
  }

  jlw() {
    const d = this.defaults.jlw || {};
    const v = this.data.jlw || {};
    return {
      baseUrl: String(v.baseUrl || d.baseUrl || OFFICIAL_SITE).replace(/\/+$/, ''),
      apiPath: String(v.apiPath || d.apiPath || '/api/plugin/jl-account').replace(/\/+$/, ''),
      insecureTls: !!v.insecureTls,
      timeoutMs: Number(v.timeoutMs) || 20000,
      sessionDays: Math.max(1, Number(v.sessionDays) || 7),
    };
  }

  secret() {
    return this.defaultAccount()?.clientSecret || '';
  }
}

module.exports = Config;
module.exports.normalizeEmail = normalizeEmail;
module.exports.isValidEmail = isValidEmail;
