'use strict';
/**
 * VSQL · 对外 API（供其他 JS 插件在同进程内调用）
 *
 * 拿法（推荐全局注册表，不依赖路径）：
 *   const vsql = globalThis.__JLWBOT_PLUGIN_APIS__?.get('VSQL');
 *   if (!vsql?.isReady()) throw new Error('VSQL 未加载');
 *   const db = vsql.db('myplugin');
 *
 * 约定：
 *   - 每次用之前重新 get('VSQL')，不要跨插件重载缓存对象；
 *   - db() 返回的句柄在 VSQL 重载后失效（操作会抛 DB_CLOSED）；
 *   - 所有方法同步（node:sqlite 是同步驱动），不要在大循环里做全表扫描。
 */

const path = require('node:path');
const manifest = require('./plugin.json');
const U = require('./lib/util');

let runtimeRef = null;

function ensure() {
  if (!runtimeRef || !runtimeRef.manager) {
    throw new U.VsqlError('NOT_READY', 'VSQL 插件尚未加载：请确认插件已启用，或先调用 vsql.isReady() 判断');
  }
  return runtimeRef;
}

const api = {
  pluginId: 'VSQL',
  version: manifest.version,
  engine: 'node:sqlite',
  VsqlError: U.VsqlError,

  /** 插件是否已加载可用（未加载时 db() 会抛 NOT_READY） */
  isReady() {
    return !!(runtimeRef && runtimeRef.manager);
  },

  /** 由 index.js 的 onLoad 调用 */
  bind(runtime) {
    runtimeRef = runtime;
    try {
      const g = globalThis;
      if (!(g.__JLWBOT_PLUGIN_APIS__ instanceof Map)) g.__JLWBOT_PLUGIN_APIS__ = new Map();
      g.__JLWBOT_PLUGIN_APIS__.set('VSQL', api);
    } catch {
      /* ignore */
    }
    return api;
  },

  /** 由 index.js 的 onUnload 调用 */
  unbind() {
    runtimeRef = null;
    try {
      if (globalThis.__JLWBOT_PLUGIN_APIS__?.get?.('VSQL') === api) globalThis.__JLWBOT_PLUGIN_APIS__.delete('VSQL');
    } catch {
      /* ignore */
    }
  },

  /* ---------------- 命名空间 ---------------- */

  /**
   * 取命名空间数据库（不存在则建文件）。
   * @param {string} [namespace] 建议直接传自己的插件 ID，例如 'xinghuo'
   * @param {{readOnly?:boolean, memory?:boolean, create?:boolean}} [options]
   * @returns {import('./lib/db').NamespaceDB}
   */
  db(namespace, options) {
    return ensure().manager.db(namespace, options);
  },

  /** db() 的别名，读起来更自然 */
  open(namespace, options) {
    return api.db(namespace, options);
  },

  /** 命名空间是否存在 */
  has(namespace) {
    return ensure().manager.has(namespace);
  },

  /** 全部命名空间（磁盘 + 内存），含大小、表数量、是否已打开 */
  list() {
    return ensure().manager.list();
  },

  /** 当前打开的句柄数 */
  openCount() {
    return ensure().manager.openCount();
  },

  /** 关闭某个命名空间的句柄（文件保留） */
  close(namespace, options) {
    return ensure().manager.close(namespace, options);
  },

  /** 关闭全部句柄 */
  closeAll() {
    return ensure().manager.closeAll();
  },

  /* ---------------- 快捷 SQL（不想写 db() 时用） ---------------- */

  query(namespace, sql, params = []) {
    return api.db(namespace).all(sql, ...params);
  },

  one(namespace, sql, params = []) {
    return api.db(namespace).get(sql, ...params);
  },

  value(namespace, sql, params = []) {
    return api.db(namespace).value(sql, ...params);
  },

  run(namespace, sql, params = []) {
    return api.db(namespace).run(sql, ...params);
  },

  exec(namespace, sql) {
    return api.db(namespace).exec(sql);
  },

  /** 键值层：get / set / del / has / all / keys / clear / incr */
  kv(namespace) {
    return api.db(namespace).kv;
  },

  /** 表封装：table(ns, 'users', { openid:'TEXT PRIMARY KEY' }, { indexes:[['openid']] }) */
  table(namespace, name, columns, options) {
    return api.db(namespace).table(name, columns, options);
  },

  /** 列出某个命名空间里的表（默认 shared），不存在返回空数组 */
  tables(namespace, options) {
    if (!api.has(namespace)) return [];
    return api.db(namespace).tables(options);
  },

  /**
   * 在所有命名空间里找一张表，返回 { namespace, file, table } 或 null。
   * 用于 B/C 插件读 A 插件建的表（A 没放在 shared 里时也能找到）。
   */
  findTable(tableName) {
    const rt = ensure();
    const wanted = String(tableName == null ? '' : tableName).trim();
    if (!wanted) return null;
    for (const item of rt.manager.list()) {
      if (item.file === ':memory:') continue;
      try {
        const db = rt.manager.db(item.namespace, { readOnly: true });
        if (db.hasTable(wanted)) return { namespace: item.namespace, file: item.file, table: wanted };
      } catch {
        /* 打不开就跳过 */
      }
    }
    return null;
  },

  /** 建表：db(namespace).createTable(...) 的快捷方式 */
  createTable(namespace, name, columns, options) {
    return api.db(namespace).createTable(name, columns, options);
  },

  /* ---------------- 状态 ---------------- */

  /** 数据目录（绝对路径） */
  dataDir() {
    return ensure().dataDir;
  },

  /** HTTP 网关状态（含掩码令牌）；未启用时 running=false */
  http() {
    if (!runtimeRef) return { enabled: false, running: false };
    if (!runtimeRef.http) return { enabled: false, running: false };
    return runtimeRef.http.info();
  },

  /** HTTP 网关完整令牌（管理指令用；不要发到群里） */
  token() {
    if (!runtimeRef || !runtimeRef.http) return '';
    return runtimeRef.http.token();
  },

  /** 数据库版本 / 聚合信息（面板、管理指令、自测都用它） */
  stats() {
    const rt = ensure();
    const list = rt.manager.list();
    const totalBytes = list.reduce((sum, item) => sum + (item.totalSize || 0), 0);
    let sqliteVersion = null;
    if (rt.manager.openCount() > 0) {
      try {
        const first = rt.manager.db(rt.manager.defaultNamespace);
        sqliteVersion = first.value('SELECT sqlite_version() AS v');
      } catch {
        sqliteVersion = null;
      }
    }
    return {
      ready: true,
      pluginId: 'VSQL',
      version: manifest.version,
      engine: 'node:sqlite',
      sqliteVersion,
      dataDir: rt.dataDir,
      defaultNamespace: rt.manager.defaultNamespace,
      namespaces: list.length,
      open: rt.manager.openCount(),
      totalBytes,
      human: U.humanBytes(totalBytes),
      allowAttach: rt.manager.allowAttach,
      http: api.http(),
      uptimeMs: Date.now() - rt.startedAt,
    };
  },

  /** stats() 的别名 */
  info() {
    return api.stats();
  },

  /** 本插件目录（api.html / README.md 的位置） */
  dir() {
    return ensure().pluginDir;
  },

  /** API 文档文件路径 */
  doc() {
    return path.join(ensure().pluginDir, 'api.html');
  },
};

module.exports = api;
