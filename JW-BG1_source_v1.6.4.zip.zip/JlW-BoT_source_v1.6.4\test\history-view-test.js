'use strict';
/**
 * 历史日志 / 历史消息：按日期读取当天的 JSONL（含大小轮转的分片）
 * 运行：node test/history-view-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };

  const jlw = await new MockJlw({ port: 0 }).start();
  const port = 22100 + Math.floor(Math.random() * 50);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hist-'));
  const logsDir = path.join(dataDir, 'logs');
  const dataSub = path.join(dataDir, 'data');
  fs.mkdirSync(logsDir, { recursive: true });
  fs.mkdirSync(dataSub, { recursive: true });

  const day = '2026-11-20';
  fs.writeFileSync(
    path.join(logsDir, `jlwbot-${day}.jsonl`),
    [
      { t: 1, time: `${day}T10:00:00+08:00`, level: 'info', msg: '第二条日志' },
      { t: 2, time: `${day}T10:01:00+08:00`, level: 'error', msg: '第三条日志' },
    ]
      .map((x) => JSON.stringify(x))
      .join('\n') + '\n',
  );
  // 大小轮转出来的分片（文件名带时间戳）
  fs.writeFileSync(
    path.join(logsDir, `jlwbot-${day}-1795000000000.jsonl`),
    JSON.stringify({ t: 0, time: `${day}T09:59:00+08:00`, level: 'debug', msg: '第一条日志' }) + '\n',
  );
  fs.writeFileSync(
    path.join(dataSub, `messages-${day}.jsonl`),
    [
      {
        t: 1,
        time: `${day}T11:00:00+08:00`,
        event: 'GROUP_MESSAGE_CREATE',
        accountId: 'a1',
        accountName: '一号',
        kind: 'group',
        id: 'm1',
        content: '群里的一条消息',
        author: 'u1',
        name: '张三',
        group_openid: 'g1',
        attachments: 0,
      },
      {
        t: 2,
        time: `${day}T11:01:00+08:00`,
        event: 'BOT_MESSAGE_CREATE',
        direction: 'out',
        accountId: 'a1',
        accountName: '一号',
        kind: 'group',
        id: 'm2',
        content: '机器人回复',
        author: 'bot',
        name: '机器人',
        group_openid: 'g1',
        attachments: 0,
      },
    ]
      .map((x) => JSON.stringify(x))
      .join('\n') + '\n',
  );

  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        plugins: { enabled: false },
        log: { level: 'warn', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  let cookie = '';
  const call = (p) => fetch(base + p, { headers: cookie ? { Cookie: cookie } : {} });

  try {
    for (let i = 0; i < 80; i++) {
      try {
        if ((await fetch(base + '/health')).ok) break;
      } catch {}
      await sleep(250);
    }
    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];

    const noAuth = await fetch(base + '/api/logs?date=' + day);
    check(noAuth.status === 401, '未登录不能读历史日志');

    const dates = await call('/api/logs/dates').then((r) => r.json());
    const hit = (dates.dates || []).find((d) => d.date === day);
    check(!!hit && hit.count >= 3, '日志日期列表按天统计条数');
    check(!!hit && typeof hit.count === 'number', '日志日期列表带 count');

    const logs = await call('/api/logs?date=' + day).then((r) => r.json());
    const msgs = (logs.logs || []).map((l) => l.msg);
    check(logs.ok === true && logs.historical === true, '历史日志返回 historical 标记');
    check(msgs.length === 3, '历史日志合并了轮转分片（3 条）');
    check(msgs[0] === '第一条日志' && msgs[2] === '第三条日志', '历史日志按时间正序');
    const errOnly = await call('/api/logs?date=' + day + '&level=error').then((r) => r.json());
    check((errOnly.logs || []).length === 1 && errOnly.logs[0].msg === '第三条日志', '历史日志按级别筛选');

    const md = await call('/api/messages/dates').then((r) => r.json());
    const mhit = (md.dates || []).find((d) => d.date === day);
    check(!!mhit && mhit.count === 2, '消息日期列表按天统计条数');

    const ev = await call('/api/events?date=' + day).then((r) => r.json());
    const list = ev.events || [];
    check(ev.ok === true && ev.historical === true && list.length === 2, '历史消息返回 2 条');
    check(list[0].message.content === '群里的一条消息', '历史消息内容正确');
    check(list[0].accountId === 'a1' && list[0].account.name === '一号', '历史消息带账户信息');
    check(list[1].direction === 'out' && list[1].name === 'BOT_MESSAGE_CREATE', '历史里能区分机器人发出的消息');
    const evAcc = await call('/api/events?date=' + day + '&account=none').then((r) => r.json());
    check((evAcc.events || []).length === 0, '历史消息按账户筛选');
  } finally {
    child.kill();
    await sleep(300);
    await jlw.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {}
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
