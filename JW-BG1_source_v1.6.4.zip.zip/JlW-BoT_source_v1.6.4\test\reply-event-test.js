'use strict';
/**
 * 回复引用对照：消息事件用 msg_id，事件（GROUP_ADD_ROBOT 等）用 event_id，
 * 进群/退群没有被动回复接口必须走主动群消息。
 *   node test/reply-event-test.js
 */
const assert = require('assert');
const Bot = require('../src/core/bot');

const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}

function makeBot() {
  const calls = [];
  const bot = Object.create(Bot.prototype);
  bot.seqMap = new Map();
  bot.log = { warn() {}, info() {}, error() {}, debug() {} };
  bot.api = {
    async post(path, body) {
      calls.push({ path, body: JSON.parse(JSON.stringify(body)) });
      return { ok: true, data: { id: 'SENT' } };
    },
  };
  return { bot, calls };
}

const msgEvent = (id = 'M1', group = 'G1') => ({ kind: 'group', id, group_openid: group });
const evtOf = (t, { id = 'EVT1', raw = {} } = {}) => ({ id, eventId: id, name: t, t, message: null, raw });

(async () => {
  /* ---------- 消息事件：msg_id ---------- */
  {
    const { bot, calls } = makeBot();
    const r = await bot.reply(msgEvent(), '你好');
    const b = calls[0].body;
    check(r.ok, '群消息回复成功');
    check(calls[0].path === '/v2/groups/G1/messages', '群消息路径正确', calls[0].path);
    check(b.msg_id === 'M1', '消息回复带 msg_id', JSON.stringify(b));
    check(b.msg_seq === 1, '消息回复自动补 msg_seq', JSON.stringify(b));
    check(!('event_id' in b), '消息回复不带 event_id');
  }

  /* ---------- 事件被动回复：event_id ---------- */
  for (const t of ['GROUP_ADD_ROBOT', 'GROUP_MSG_RECEIVE', 'INTERACTION_CREATE']) {
    const { bot, calls } = makeBot();
    const r = await bot.replyEvent(evtOf(t, { id: 'E-' + t, raw: { group_openid: 'G9' } }), '欢迎');
    const b = calls[0]?.body || {};
    check(r.ok, `${t} 被动回复成功`);
    check(calls[0]?.path === '/v2/groups/G9/messages', `${t} 走群消息接口`, calls[0]?.path);
    check(b.event_id === 'E-' + t, `${t} 用 event_id`, JSON.stringify(b));
    check(!('msg_id' in b), `${t} 不带 msg_id`, JSON.stringify(b));
    check(!('msg_seq' in b), `${t} 不带 msg_seq`, JSON.stringify(b));
  }

  /* ---------- 进群/退群：没有被动回复接口 ---------- */
  for (const t of ['GROUP_MEMBER_ADD', 'GROUP_MEMBER_REMOVE', 'GROUP_JOIN_REQUEST', 'FRIEND_ADD', 'FRIEND_DEL', 'GROUP_DEL_ROBOT']) {
    const { bot, calls } = makeBot();
    const r = await bot.replyEvent(evtOf(t, { id: 'E1', raw: { group_openid: 'G9' } }), '欢迎');
    check(!r.ok && r.code === 'NO_PASSIVE_REPLY', `${t} 拒绝被动回复`, JSON.stringify(r));
    check(calls.length === 0, `${t} 不发出任何请求`);
    check(/没有被动回复接口|不能被动回复/.test(r.error || ''), `${t} 错误提示说明了原因与替代方案`, r.error);
  }

  /* ---------- 缺少上下文 / 缺少事件 id ---------- */
  {
    const { bot, calls } = makeBot();
    const r = await bot.reply(null, 'x');
    check(!r.ok && r.code === 'NO_MESSAGE', '无消息上下文时 reply 明确报错', JSON.stringify(r));
    check(/replyEvent/.test(r.error || ''), '错误提示指向 replyEvent');
    const r2 = await bot.replyEvent({ t: 'GROUP_ADD_ROBOT', raw: { group_openid: 'G1' } }, 'x');
    check(!r2.ok && r2.code === 'NO_EVENT_ID', '事件缺少外层 id 时拒绝', JSON.stringify(r2));
    const r3 = await bot.replyEvent(evtOf('GROUP_ADD_ROBOT', { raw: {} }), 'x');
    check(!r3.ok && r3.code === 'NO_GROUP', '事件缺少 group_openid 时拒绝', JSON.stringify(r3));
    check(calls.length === 0, '以上失败都没有发请求');
  }

  /* ---------- 互斥校验 ---------- */
  {
    const { bot, calls } = makeBot();
    const a = await bot.sendGroup('G1', 'x', { msg_id: 'M1', event_id: 'E1' });
    const b = await bot.sendGroup('G1', 'x', { event_id: 'E1', msg_seq: 2 });
    const c = await bot.reply(msgEvent(), 'x', { event_id: 'E1' });
    check(!a.ok && a.code === 'BAD_REPLY_REF', 'msg_id 与 event_id 不能同时传', JSON.stringify(a));
    check(!b.ok && b.code === 'BAD_REPLY_REF', 'event_id 不能带 msg_seq', JSON.stringify(b));
    check(!c.ok && c.code === 'BAD_REPLY_REF', '消息回复不接受 event_id', JSON.stringify(c));
    check(calls.length === 0, '校验失败不发请求');
  }

  /* ---------- 面板 send ---------- */
  {
    const { bot, calls } = makeBot();
    const r = await bot.send({ type: 'group', target: 'G1', content: { msg_type: 0, content: 'hi', event_id: 'E1' } });
    check(r.ok && calls[0].body.event_id === 'E1', '面板接口可发 event_id 主动被动消息', JSON.stringify(calls[0]?.body));
  }

  /* ---------- 插件输出自动分流 ---------- */
  {
    const { bot, calls } = makeBot();
    const evt = evtOf('GROUP_ADD_ROBOT', { id: 'E7', raw: { group_openid: 'G7' } });
    const r = await bot.applyPluginOutput({ id: 'p' }, evt, { replies: [{ type: 'text', content: '欢迎入群' }], actions: [] });
    check(r.replied === true || r.results[0]?.ok === true, '插件对 GROUP_ADD_ROBOT 的直接回复可用', JSON.stringify(r));
    check(calls[0]?.body?.event_id === 'E7' && !calls[0]?.body?.msg_id, '插件回复自动走 event_id', JSON.stringify(calls[0]?.body));
  }
  {
    const { bot, calls } = makeBot();
    const evt = evtOf('GROUP_MEMBER_ADD', { id: 'E8', raw: { group_openid: 'G8', member_openid: 'U8' } });
    const r = await bot.applyPluginOutput({ id: 'p' }, evt, { replies: [{ type: 'text', content: '欢迎新人' }], actions: [] });
    check(r.replied === false, '插件对进群事件的直接回复不假装成功', JSON.stringify(r));
    check(calls.length === 0, '进群事件不会误发被动请求');
  }
  {
    const { bot, calls } = makeBot();
    const evt = evtOf('GROUP_MEMBER_ADD', { id: 'E9', raw: { group_openid: 'G9', member_openid: 'U9' } });
    const r = await bot.executeAction({ id: 'p' }, evt, { action: 'reply', content: '欢迎' });
    check(!r.ok && r.code === 'NO_PASSIVE_REPLY', '动作 reply 同样拒绝进群事件', JSON.stringify(r));
    const r2 = await bot.executeAction({ id: 'p' }, evt, { action: 'send_group_message', group_openid: 'G9', content: '欢迎' });
    check(r2.ok && calls[0].body.content === '欢迎' && !calls[0].body.msg_id, '动作 send_group_message 走主动消息', JSON.stringify(calls[0]?.body));
  }

  /* ---------- handleEvent 带上事件外层 id ---------- */
  {
    const { bot } = makeBot();
    bot.account = { id: 'test', name: '测试', appId: '123456' };
    bot.config = { get: (k, d) => d };
    bot.events = [];
    bot.counts = { group: 0, c2c: 0, channel: 0, dm: 0, other: 0, total: 0 };
    bot.dayCounts = { day: 'x', total: 0 };
    bot.seen = new Map();
    bot.plugins = { dispatch: async () => {} };
    bot.messageWriter = null;
    bot.lastEventAt = 0;
    bot.normalize = () => null;
    bot._countMessage = () => {};
    let captured = null;
    bot.on('event', (e) => (captured = e));
    bot.handleEvent({ t: 'GROUP_ADD_ROBOT', id: 'OUTER-1', d: { group_openid: 'G1' }, s: 1, source: 'ws' });
    check(captured?.eventId === 'OUTER-1', 'handleEvent 记录事件外层 id', JSON.stringify(captured?.eventId));
    check(captured?.id === 'OUTER-1', '去重 id 仍是外层 id');
  }

  /* ---------- 机器人发出的消息也要记录 ---------- */
  {
    const { bot, calls } = makeBot();
    bot.events = [];
    bot.account = { id: 'a1', name: '测试', appId: '123456' };
    bot.self = { id: 'BOT1', username: '机器人', avatar: '' };
    bot.config = { get: (k, d) => d };
    bot._countMessage = () => {};
    bot.messageWriter = null;
    bot.emit = () => {};
    await bot.sendGroup('G1', '主动消息');
    check(bot.events.length === 1, '主动发送后记录到事件列表', String(bot.events.length));
    const out = bot.events[0] || {};
    check(out.direction === 'out' && out.name === 'BOT_MESSAGE_CREATE', '记录方向为发出', JSON.stringify(out.name));
    check(out.message?.content === '主动消息' && out.message?.group_openid === 'G1', '记录内容与目标群', JSON.stringify(out.message));
    check(out.message?.author?.bot === true && out.message?.author?.username === '机器人', '发送者标记为机器人');
    await bot.reply(msgEvent('M9', 'G1'), '回复内容');
    check(bot.events.length === 2 && bot.events[0].message?.content === '回复内容', '被动回复同样记录', JSON.stringify(bot.events[0]?.message?.content));
    check(bot.events[0].source === 'reply', '记录来源为 reply', out.source);
    check(calls.length === 2, '记录不影响实际发送', String(calls.length));
  }

  /* ---------- 常量表 ---------- */
  check(Bot.EVENT_PASSIVE_REPLY.has('GROUP_ADD_ROBOT'), '支持 event_id 的事件表包含 GROUP_ADD_ROBOT');
  check(!Bot.EVENT_PASSIVE_REPLY.has('GROUP_MEMBER_ADD'), '支持 event_id 的事件表不含 GROUP_MEMBER_ADD');
  check(Bot.EVENT_NO_PASSIVE_REPLY.has('GROUP_MEMBER_REMOVE'), '无被动回复事件表包含 GROUP_MEMBER_REMOVE');

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
