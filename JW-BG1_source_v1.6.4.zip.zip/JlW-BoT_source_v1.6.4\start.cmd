@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "NODE_EXE=%~dp0runtime\node.exe"
if exist "%NODE_EXE%" goto run

where node >nul 2>nul
if errorlevel 1 goto nonode
set "NODE_EXE=node"

:run
echo.
echo   JlWBoT - QQ Bot Framework
echo   Data dir: %~dp0~JlWBoT
echo   Starting...
echo.
"%NODE_EXE%" src\index.js %*
if errorlevel 1 (
  echo.
  echo   [ERROR] process exited with code %errorlevel%
  pause
)
exit /b 0

:nonode
echo.
echo   [ERROR] Node.js not found.
echo.
echo   1. Install Node.js 18+ from https://nodejs.org/
echo   2. Or put node.exe into: %~dp0runtime\
echo.
pause
exit /b 1