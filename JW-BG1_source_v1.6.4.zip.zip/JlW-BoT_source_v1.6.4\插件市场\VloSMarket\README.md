# JlW-BoT 插件市场（v2）

> 聚龙世界账户登录 · 插件只收 `.zip` · 上传自动解析名称与版本 · 没有审核、没有独立后台页、没有接口文档页。
>
> - 当前版本：**v2.9.1**（2026-11-24，本版更新见 [更新说明-v2.9.1.md](更新说明-v2.9.1.md)）
> - 聚龙世界：<https://www.jlworld.net>
> - 站点（计划域名）：`vlos.jlworld.net`
> - 本机开发地址：`http://127.0.0.1:8300`
> - 最后更新：2026-11-24

---

## 0. 60 秒导读

1. **纯 Node、零第三方依赖**：只用 `node:http` + `node:sqlite` + `node:zlib`，没有 `node_modules`、没有构建步骤。
2. **必须 Node ≥ 22.5**（`node:sqlite` 是内置模块）。
3. 启动：双击 `启动.bat`，或 `node server/launch.mjs`。
4. 数据全部在本地：`data/market.db`、`plugins/`、`logs/`、`config.local.json`；整个文件夹拷走就是完整迁移。
5. 页面只有三个：**首页 / 插件市场 / 开发者中心**。登录后才可浏览、下载、上传。
6. 上传 = 传一个 `.zip`：服务端先解析出插件名称、版本号、包内文件清单，确认后发布；已发布的插件可以随时发新版本。

---

## 1. 快速启动

### Windows

```
双击 启动.bat
```

脚本会依次找 Node：`PATH` → `Program Files\nodejs` → `LOCALAPPDATA\Programs\nodejs` → DSH 自带 Node → 宝塔 Node。
找到后带 `--open` 启动并自动打开浏览器。

### 命令行（任何平台）

```bash
node server/launch.mjs            # 前台运行
node server/launch.mjs --open     # 顺带打开浏览器
```

默认监听 `127.0.0.1:8300`。改端口改 `config.json` 的 `port`，或用环境变量 `PORT=8300`。

### 其它脚本

| 脚本 | 用途 |
|---|---|
| `启动.bat` | 前台启动 + 打开浏览器（开发用） |
| `升级.bat` | 安全更新：把新版本的代码覆盖到旧站点目录，不动 data / plugins / config |
| `重启.bat` | 管理员运行：结束占用端口的进程后后台启动 |
| `守护.bat` | 看门狗：8300 没监听就启动，可交给宝塔计划任务每分钟跑一次 |
| `重置数据.bat` | 清空 `data/` `plugins/` `logs/` 后重建（会二次确认） |

---

## 2. 目录结构

```
VloSMarket/
├─ config.json                 ← 默认配置（可分享）
├─ config.local.json           ← 本机敏感配置（不要分享；新账户接口已不需要 VloS-key）
├─ 升级.bat                    ← 安全更新：只覆盖代码，不动 data / plugins / config
├─ 启动.bat / 重启.bat / 守护.bat / 重置数据.bat / start.sh
├─ server/
│  ├─ launch.mjs               ← 入口：检查 Node 版本后加载 index.mjs
│  ├─ index.mjs                ← HTTP 服务、路由表、静态文件、会话解析、HTTPS
│  ├─ config.mjs               ← 配置分层加载（json ← local ← 环境变量）
│  ├─ db.mjs                   ← 建表 / 旧库迁移 / store 封装
│  ├─ http.mjs                 ← 请求体、响应、静态文件、Cookie、下载
│  ├─ session.mjs              ← 会话签发与滑动续期
│  ├─ jlw.mjs                  ← 聚龙世界账户接口客户端
│  ├─ zip.mjs                  ← 极简 ZIP 读写（中央目录 / 解压单条 / 打包）
│  ├─ package.mjs              ← 上传包解析：名称、版本、包内文件清单
│  └─ routes/
│     ├─ auth.mjs              ← 注册 + 邮箱密码登录 + 重置密码 + 退出 + /api/me
│     ├─ plugins.mjs           ← 解析暂存 / 发布 / 新版本 / 列表 / 详情 / 下载 / 下架
│     ├─ admin.mjs             ← 管理员：插件管理 + 管理员账户
│     ├─ social.mjs            ← 两层评论 + 站内消息（铃铛）
│     ├─ community.mjs         ← 五心评分
│     └─ site.mjs              ← 首页公告 / 副标题 / 聚龙世界地址（只读）
├─ public/
│  ├─ home.html                ← 【外壳】常驻顶栏 + iframe + 页脚
│  ├─ home-view.html           ← 首页内容（大图标 / 公告 / 统计）
│  ├─ index.html               ← 插件市场（列表 + 详情）
│  ├─ developer.html           ← 开发者中心（我的插件 / 上传新插件 / api上传）
│  └─ assets/
│     ├─ app.css               ← 全局样式（白天 / 夜晚两套变量）
│     ├─ common.js             ← API、登录门禁、铃铛、主题
│     ├─ shell.js              ← 外壳：栏目切换 / 地址栏 / 插件详情转发
│     ├─ home.js               ← 首页动画与公告
│     ├─ market.js             ← 市场列表 / 详情 / 版本 / 评论 / 评分
│     ├─ developer.js          ← zip 上传、解析预览、发新版本、编辑资料
│     ├─ markdown.js           ← 手写 Markdown 渲染器（先转义再解析）
│     └─ bot-icon.png
├─ data/market.db              ← SQLite（唯一数据文件）
├─ plugins/<插件ID>/<版本>/xxx.zip
├─ tmp/                        ← 上传暂存（超时自动清理）
├─ logs/                       ← access.log / server.log / server.err.log
└─ _dev/                       ← 自测脚本与示例包（交付时可整目录删除）
```

---

## 3. 页面与功能

| 页面 | 地址 | 说明 |
|---|---|---|
| 首页 | `/` 或 `/home` | 外壳 + 首页内容：大图标、公告、统计 |
| 插件市场 | `/market` | 搜索 / 排序 / 标签 / 详情 / 下载 / 版本历史 / 前置插件 / 评论 / 评分 |
| 开发者中心 | `/developer` | 我的插件（每插件一张折叠卡片，点开看版本记录与操作）、上传新插件（含前置插件多选）、api上传（API 令牌与接口文档）、发新版本、编辑资料、下架 / 删除；管理员多一个「管理员」标签页 |

- 没有「审核」：上传即发布，立刻出现在市场。
- 没有独立的管理后台页：管理员工具在开发者中心的「管理员」标签页里（仅管理员可见）。
- 没有「接口文档」页：旧链接 `/docs` `/admin` 会回到首页。
- 顶栏只有 首页 / 插件市场 / 开发者中心 三个栏目（不再有「官网」栏目）；页脚保留聚龙世界链接 <https://www.jlworld.net>。

### 内嵌到其他项目

整个站点可以直接用 iframe 嵌入其他项目（例如 JlWBoT 控制台的【市场】面板），**页首、导航、页脚、整站内容都会完整保留**：

```html
<iframe src="https://你的站点/home" style="width:100%;height:800px;border:0"></iframe>
```

- 只有被「本站自己的外壳」载入的内层页面才会隐藏页首，避免双层导航；外部项目的 iframe 不会被当成外壳。
- 服务端已去掉 `X-Frame-Options`，改为 `Content-Security-Policy: frame-ancestors *`，允许跨域内嵌。
- 建议嵌在 `jlworld.net` 同站点（同一主域名）下，登录 Cookie 才会稳定带上；嵌到完全不同的域名时，浏览器可能按第三方 Cookie 策略拦截登录态。

### 管理员

| 身份 | 说明 |
|---|---|
| 超级管理员 | **固定为 `3407556894@qq.com`**，写死在代码里（`server/roles.mjs`），不能移除、不能降级 |
| 管理员 | 超级管理员在「开发者中心 → 管理员 → 管理员账户」里按聚龙账户邮箱添加；对方用该邮箱登录后自动生效 |

管理员可以：

管理员标签页分 4 个子栏目：

| 子栏目 | 内容 |
|---|---|
| 上架插件 | 全部插件（含已下架），点击行展开上传者 / 时间 / 版本 / 数据；可按插件名 / ID / 作者 / 上传者搜索；可置顶、下架、重新上架、删除 |
| 登录用户 | 所有登录过本站的聚龙账户：邮箱 / 昵称 / QQ / openid / 注册 / 最近登录 / 插件数 / 下载；支持搜索 |
| 管理员设置 | 首页公告 + 副标题编辑；管理员账户新增 / 移除 |
| Api文档 | 自动登录 API 的地址、参数、返回、curl、`App.autoLogin` 用法与安全提示 |

只有超级管理员能新增 / 移除管理员；管理员之间不能互相增删。

### 登录 / 注册

账户体系走聚龙世界新版站点插件接口：

```
POST https://www.jlworld.net/api/plugin/jl-account/{action}
```

| 功能 | action | 说明 |
|---|---|---|
| 登录 | `login` | 邮箱 + 密码；返回 `{token,user}`（本站只用它确认登录成功，不保存 token） |
| 注册发码 | `send-code`（`purpose=register`） | 6 位验证码，10 分钟有效，60 秒冷却 |
| 注册 | `register` | 邮箱 + 验证码 + 密码（≥6 位）+ 昵称（2–20 字），成功后自动登录 |
| 重置密码发码 | `send-code`（`purpose=reset`） | |
| 重置密码 | `reset-password` | 邮箱 + 验证码 + 新密码，成功后自动登录 |

旧的「邮箱验证码登录 / QQ-openid 登录 / VloS-key」在新接口里已经没有了，登录框只保留邮箱密码、注册、忘记密码三条路径。
本站只签发自己的 30 天会话 Cookie（`vlos_sid`），**不保存账户密码，也不保存聚龙 token**。

### 自动登录 API（给外部系统用）

```
POST /api/auth/auto-login
Content-Type: application/json

{ "mail": "user@qq.com", "password": "账户密码", "redirect": "/home" }
```

一次调用完成「账号 + 密码 + 登录」，成功返回 `Set-Cookie: vlos_sid=...` 与用户信息；传 `redirect`（站内路径）时直接 302。
同一 IP 5 分钟最多 10 次。完整参数、curl 与 `App.autoLogin()` 用法在「开发者中心 → 管理员 → Api文档」里。

### 上传 / 更新 API（给外部脚本用，api上传）

每个账户在「开发者中心 → api上传」里有一个 API 令牌（可复制 / 重新生成）。请求体直接是 zip 二进制，认证头：

```
Authorization: Bearer <token>
```

| 用途 | 接口 |
|---|---|
| 创建新插件 | `POST /api/v1/plugins?name=插件名&tags=工具`（body 为 zip） |
| 更新已有插件 | `POST /api/v1/plugins/{插件ID}/releases?version=1.2.0&changelog=说明`（body 为 zip） |
| 查看自己的插件 ID | `GET /api/v1/me` |

不传 `name` / `version` 时会自动从 zip 里解析；单包上限与手动上传一致（固定 32MB）；每个账户每分钟最多 20 次上传。

---

## 4. 上传流程（核心）

```
选择 zip ──POST /api/inspect──► 暂存 tmp/<token>.zip
                               解析出 name / version / 包内清单
                                      │
                          用户确认/修改名称、版本、简介…
                                      │
                     ┌────────────────┴────────────────┐
              POST /api/plugins                 POST /api/plugins/:id/releases
              （发布新插件）                      （给已有插件发新版本）
                     └────────────────┬────────────────┘
                                      ▼
                  plugins/<ID>/<版本>/<插件名>_v<版本>.zip
                  releases 表新增一行（版本、大小、sha256、包内清单）
                  plugins.version 推进到这一版
```

### 名称 / 版本解析顺序

1. **包内清单文件**（只读浅层 ≤2 层、≤512KB）：
   `plugin.json` → `manifest.json` → `info.json` → `plugin.ini` → `manifest.ini` → `插件信息.json` → `插件信息.txt` → `version.txt` → `版本.txt` → `package.json`
   - JSON 取 `name / pluginName / title / 插件名` 与 `version / ver / 版本`
   - 也支持 `key=value` 形式的 ini/txt
2. **压缩包文件名**：`扫雷_v1.2.0.zip`、`扫雷-1.2.zip`、`扫雷(1.2).zip`、`扫雷1.2.zip`
3. **包内最外层的 `.dll` 文件名**：`小游戏_扫雷.dll` → 名称 `小游戏_扫雷`；带 `_v1.2` 时会同时取出版本
4. 兜底：名称 `未命名插件`、版本 `1.0.0`

解析结果会标出来源（manifest / filename / dll），用户可以手动改；版本号最终由发布时表单里的值为准。

### 校验

- 只收 `.zip`（看后缀 + `PK` 文件头），其它后缀直接拒绝。
- 有密码的 zip、ZIP64 超大包、分卷包会给出明确中文提示。
- 包内没有 `.dll` 只给黄色警告，不拦截（源码包/资源包也允许）。
- 单包上限 **32MB**（硬上限，`maxUploadMB` 只能调小不能调大；超限在上传前就会被前端拦下，服务端返回 413）。
- 包内文件名按 UTF-8 / GBK 自动识别（Windows「发送到压缩文件夹」打出来的中文名不会乱码）。

### 包内结构建议

```
plugin.json          ← 可选，写 {"name":"扫雷助手","version":"1.2.0"} 最准确
扫雷助手.dll         ← JlW-BoT 插件本体
源码/main.e          ← 源码、模块、说明、图片都可以放
README.md
```

市场里会展示包内文件清单（最多 500 条入库、详情页展示前 200 条），下载就是下载整个 zip。

---

## 5. 数据模型

| 表 | 作用 / 关键列 |
|---|---|
| `users` | 聚龙账户：`email`（主键）`nickname`（聚龙昵称）`avatar`（头像地址，可空）`qq` `openid` `jlw_created` `first_seen` `last_login` |
| `sessions` | 会话：`token` `email` `expires` `ip` `ua` |
| `plugins` | 插件：`id` `email` `name` `author` `version`（最新）`summary` `readme` `tags` `views` `downloads` `offline`（1=已下架）`pinned`（1=置顶） |
| `releases` | 版本：`plugin_id` `version` `filename` `rel_path` `size` `sha256` `entry_count` `dll_name` `entries`(JSON) `changelog` |
| `admins` | 管理员（超级管理员不在此表，写死在代码里）：`email` `added_by` `created` |
| `api_tokens` | API 上传令牌（每个账户一个）：`email` `token` `created` `last_used` |
| `comments` | 两层评论：`parent_id` `reply_to` |
| `messages` | 站内消息（铃铛）：`to_email` `kind`(comment/reply/rating/system) `is_read` |
| `ratings` | 五心评分：`(plugin_id,email)` 主键 |
| `download_logs` | 下载明细：`release_id` `version` `email` `ip` |
| `view_logs` | 浏览去重：`(plugin_id,viewer)` |
| `settings` | 首页公告：`announcement` / `bot_name`（只读，需手改库） |
| `meta` | 结构版本：`schema=2` |

改表结构时：建表 → 补列（`migrate()`）→ 建索引，顺序不能乱。

---

## 6. API 清单

### 认证

```
GET  /api/auth/methods          站点名 / 聚龙世界地址 / 账号接口地址 / 上传上限
GET  /api/me                    当前用户 + 未读数
POST /api/auth/register/send    注册① 发邮箱验证码
POST /api/auth/register/confirm 注册② 验证码 + 昵称 + 密码，成功后自动登录
POST /api/auth/login/password   邮箱 + 密码登录
POST /api/auth/auto-login       自动登录：一次调用完成账号 + 密码 + 登录，返回会话 Cookie（文档在管理员页面）
POST /api/auth/password/send    忘记密码① 发重置验证码
POST /api/auth/password/reset   忘记密码② 验证码 + 新密码，成功后自动登录
POST /api/auth/logout           退出
```

### 插件

```
GET    /api/plugins                    列表（q / tag / sort / page / size）
GET    /api/plugins/:id                详情（浏览去重计数 + 全部版本 + 我的评分）
GET    /api/stats                      插件 / 下载 / 浏览 / 开发者 / 账户（5 项）
POST   /api/inspect?name=xxx.zip       上传 zip 到暂存并解析（原始二进制体）
POST   /api/plugins                    用 token 发布新插件
POST   /api/plugins/:id/releases       用 token 给已有插件发新版本
PATCH  /api/plugins/:id                改名称/作者/简介/介绍/标签/前置插件
POST   /api/plugins/:id/offline        下架 / 重新上架（作者或管理员；body {offline:true|false}）
DELETE /api/plugins/:id                删除插件及其所有版本（作者或管理员）
GET    /api/my/plugins                 我的插件（含版本明细、前置插件）
GET    /api/plugin-options             前置插件候选列表（登录后）
GET    /api/plugins/:id/download       最新版 → 302 到 /api/releases/:id/download
GET    /api/releases/:id/download      下载指定版本（计下载数）
```

### 上传 API（API 令牌，给外部脚本）

```
GET  /api/my/api-token                 当前账户的 API 令牌（登录会话；首次自动生成）
POST /api/my/api-token/refresh         重新生成令牌（旧令牌立即失效）
GET  /api/v1/me                        令牌认证：返回自己和插件 ID 列表
POST /api/v1/plugins                   令牌认证：上传 zip 创建新插件
POST /api/v1/plugins/:id/releases      令牌认证：上传 zip 给已有插件发新版本
```

### 管理

```
GET    /api/admin/plugins              全部插件（含已下架，带上传者 / 时间 / 版本明细）
GET    /api/admin/users                所有登录过本站的账户（含插件数 / 下载 / 身份）
GET    /api/admin/admins               管理员列表（超级管理员固定项 + 已添加）
POST   /api/admin/admins               新增管理员（仅超级管理员；body {email}）
DELETE /api/admin/admins/:email        移除管理员（仅超级管理员；超级管理员不可移除）
POST   /api/admin/settings             改首页公告 / 副标题（管理员）
POST   /api/admin/pin                  置顶 / 取消置顶（管理员；body {id, pinned}）
GET    /api/version                    前后端版本握手（服务端没重启时会提示）
```

### 社区

```
GET    /api/plugins/:id/comments       留言列表（两层）
POST   /api/plugins/:id/comments       发留言 / 回复（parentId）
DELETE /api/comments/:id               删留言
POST   /api/plugins/:id/rating         评分 1~5 颗心（需下载过、不能自评）
GET    /api/messages                   铃铛消息
POST   /api/messages/read              标记已读
GET    /api/settings                   公告 / 副标题 / 聚龙世界地址
```

所有接口都要登录（`/api/auth/*`、`/api/settings` 除外）。错误统一 `{ "error": "中文提示" }`。

---

## 7. 旧版数据迁移（自动）

旧版（v1）是「dll / 源码 / 模块分文件上传 + 审核状态机」。启动时检测到旧库会自动迁移，**全程不删数据**：

1. 备份：`data/backup/market.db.v1-<时间>.bak`（先 checkpoint，WAL 内容不会丢）。
2. **所有状态**的插件都迁移（草稿 / 待审 / 已驳回也保留文件）；没上架过的迁移后标记为「已下架」，不会突然出现在市场。
3. 每个插件的每个版本，把老的 `.dll` / 源码 / 模块打成一个 zip 放到 `plugins/<ID>/<版本>/`，写入 `releases`。
4. 旧表 `files`、`reports`、`report_msgs` **原样保留**（新代码不读，用于回退/排障）；旧下载日志改名为 `download_logs_v1` 保留。
5. 保留用户、评论、评分、浏览/下载总量、首页公告。
6. 写入 `meta.schema=2`，以后不再重复迁移。

**自动恢复**：每次启动都会检查「0 个版本」的插件；只要磁盘上还有 `plugins/<ID>/<版本>/dll|source|module`，
就自动重新打回 zip 并补 `releases`（日志：`[db] 已从磁盘恢复 N 个插件`）。升级时就算旧库被删过表，文件也能救回来。

> 迁移是单向的：旧库备份在 `data/backup/`，需要回退时停服、把备份覆盖回 `data/market.db` 即可。
>
> 迁移与恢复都**不会删**原来的 `plugins/<ID>/<版本>/dll|source|module` 文件；确认 zip 正常后可手动清理这些子目录省空间。

---

## 8. 配置

`config.json`（默认值，可分享）：

| 键 | 说明 |
|---|---|
| `siteName` | 站点名（登录框 / 标题） |
| `officialSite` | 聚龙世界地址，默认 `https://www.jlworld.net` |
| `host` / `port` | 监听地址，默认 `127.0.0.1:8300` |
| `publicUrl` | 对外的 https 地址；填了 https 后 http 会自动 301 |
| `vlosBase` | 聚龙账户接口，默认 `https://www.jlworld.net/api/plugin/jl-account/` |
| `vlosKey` | 旧接口遗留字段，新接口不需要，可留空 |
| `announcement` | 首页公告（数据库 `settings.announcement` 优先） |
| `sessionDays` | 会话天数，默认 30 |
| `maxUploadMB` | 单包上限，默认 32（硬上限 32，只能调小） |
| `zipStageMin` | 暂存包保留分钟数，默认 120 |
| `codeCooldownSec` / `commentCooldownSec` | 验证码 / 留言冷却 |
| `httpsOnly` / `httpsPort` / `certFile` / `keyFile` | 自带 TLS（SakuraFrp SNI 透传时用） |
| `trustProxy` | 反代后面取真实 IP |

环境变量（优先级最高）：`PORT` `HOST` `DATA_DIR` `VLOS_BASE` `HTTPS_PORT` `CERT_FILE` `KEY_FILE`。

---

## 9. 自测

```powershell
# 1) 语法检查（服务端 + 前端脚本）
node --check server/index.mjs
node --check public/assets/developer.js

# 2) 造一个测试库并启动（不影响正式数据）
$env:PORT=8399; $env:DATA_DIR="$env:TEMP\vlos-test"
node server/launch.mjs

# 3) 端到端：塞一个测试用户+会话，跑「解析→发布→下载→新版本→评论→删除」
node _dev\e2e.mjs http://127.0.0.1:8399 "$env:TEMP\vlos-test"

# 4) 旧库迁移演练（把 data + plugins 复制到一个临时目录后跑）
node _dev\test-mig.mjs "$env:TEMP\vlos-mig"

# 5) Markdown 渲染器断言
node _dev\md-test.mjs

# 6) ZIP 解析单测（UTF-8 / GBK 文件名 / 加密包）
node _dev\zip-test.mjs
```

`_dev/sample/` 里有两个示例 zip，可直接拖进开发者中心试上传。

---

## 10. 部署（宝塔 / 云服务器）

1. 整个 `VloSMarket` 目录拷到服务器（如 `D:\聚龙世界\web\VloSMarket`）。
2. 安装 Node ≥ 22.5（宝塔 Node 版本管理器即可）。
3. `config.json` 里 `publicUrl` 填线上 https 地址（新账户接口不需要 VloS-key）。
4. 启动：`重启.bat`（管理员）或宝塔「Node 项目」指向 `server/launch.mjs`。
5. 守护：宝塔计划任务每分钟跑 `守护.bat`。
6. 反向代理：站点根目录指到本项目，反代到 `127.0.0.1:8300`；如果走 SakuraFrp 的 HTTPS 隧道（SNI 透传），直接配 `certFile/keyFile` + `httpsOnly=true` 让本地自己说 HTTPS。
7. HTTPS 证书续签后进程会自动热加载（每 10 分钟检查证书 mtime）。

> 不要把服务挂在某个会话的后台任务里：会话被回收会连带杀掉进程。用 `Start-Process` 脱离，或交给宝塔计划任务。

---

## 11. 常见问题

**登录提示「邮箱或密码不正确」/ 连接失败？**
先直接测聚龙账户接口（不需要任何 key）：

```
curl -X POST "https://www.jlworld.net/api/plugin/jl-account/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"a@b.cn\",\"password\":\"x\",\"website\":\"\"}"
```

返回 `{"ok":false,"error":"邮箱或密码不正确"}` 说明接口通、账号或密码不对；
返回 `{"ok":true,...}` 说明账号正常。连不上则检查服务器能否访问 `www.jlworld.net`。

**页面右下角提示「服务端版本不匹配」/ 管理员标签页显示「接口不存在」？**
说明只替换了文件，Node 进程还在跑旧代码。**完全重启服务**（不是刷新浏览器）即可。

**旧插件显示 0 个版本、下载不了？**
v2.2 起启动时会自动扫描 `plugins/<ID>/<版本>/dll|source|module` 旧文件，重新打回 zip。
重启后看日志有没有 `[db] 已从磁盘恢复 N 个插件`；前提是 `plugins/` 目录还在。

**上传后名称/版本解析不对？**
在包里放一个 `plugin.json`（`{"name":"...","version":"..."}`）最稳；或者在发布表单里手动改，名称和版本都可以改。

**下载 404 / 410？**
`plugins/<ID>/<版本>/` 下的 zip 被手动删了。重新上传一个版本即可。

**换端口 / 换域名？**
只改 `config.json`（或环境变量），不用动代码。`publicUrl` 改成 https 后会话 Cookie 会自动加 `Secure`。

**想改首页公告？**
用超级管理员 / 管理员登录，首页公告右上角点「编辑公告」即可（存数据库 `settings` 表，换代码不会丢）。

---

## 12. 设计取舍

- **不引入任何包**：ZIP 解析/打包、Markdown、路由、Cookie 全自己写，保证「整个文件夹拷走就能跑」。
- **一个版本一个 zip**：下载单位清晰，包内结构由作者决定，不再拆 dll/源码/模块三类。
- **暂存 + token 两步发布**：先解析给用户看，确认后才落库，避免「传完才发现名字版本错了」。
- **两级权限**：登录即可上传，作者只能改/删自己的插件；管理员（超级管理员 3407556894@qq.com + 手动添加的账户）可以下架/上架/删除任意插件，但没有审核流程。
