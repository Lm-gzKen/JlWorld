@echo off
rem  ���վ�����ݣ������ȷ�ϣ������ȹص��������еķ��񴰿ڡ�
chcp 936 >nul
cd /d "%~dp0"

set "NODE_EXE="
for %%i in (node.exe) do set "NODE_EXE=%%~$PATH:i"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe" set "NODE_EXE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not defined NODE_EXE if exist "D:\BT\BtSoft\nodejs" for /d %%v in ("D:\BT\BtSoft\nodejs\*") do if exist "%%~v\node.exe" set "NODE_EXE=%%~v\node.exe"
if not defined NODE_EXE if exist "D:\BtSoft\nodejs" for /d %%v in ("D:\BtSoft\nodejs\*") do if exist "%%~v\node.exe" set "NODE_EXE=%%~v\node.exe"

if not defined NODE_EXE (
  echo   [ERROR] Node.js not found. Install Node.js 22.5+ first.
  pause
  exit /b 1
)

"%NODE_EXE%" "_dev\reset.mjs"
pause
