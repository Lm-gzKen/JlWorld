'use strict';
/* 插件设置独立页：内嵌 settings.html，并替它完成 config 保存 */
(() => {
  const params = new URLSearchParams(location.search);
  const pluginId = params.get('plugin') || '';
  const titleEl = document.getElementById('plugin-title');
  const subEl = document.getElementById('plugin-sub');
  const badgeEl = document.getElementById('plugin-badge');
  const statusEl = document.getElementById('plugin-status');
  const frameWrap = document.getElementById('frame-wrap');
  const frame = document.getElementById('settings-frame');
  const emptyEl = document.getElementById('empty-state');
  const saveBtn = document.getElementById('save-btn');
  const reloadBtn = document.getElementById('reload-btn');
  const themeBtn = document.getElementById('theme-btn');

  let plugin = null;
  let saveWaitTimer = null;

  const setStatus = (text, type = '') => {
    statusEl.textContent = text || '';
    statusEl.className = 'plugin-page-status' + (type ? ' ' + type : '');
  };
  const setTheme = (theme) => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('jlw-theme', theme);
  };
  setTheme(localStorage.getItem('jlw-theme') || 'dark');
  themeBtn?.addEventListener('click', () => {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  });

  async function load() {
    if (!pluginId) {
      setStatus('地址缺少 plugin 参数', 'err');
      return;
    }
    let res;
    try {
      res = await fetch('/api/plugins', { credentials: 'same-origin', cache: 'no-store' });
    } catch (e) {
      setStatus('无法连接面板：' + e.message, 'err');
      return;
    }
    if (res.status === 401) {
      setStatus('登录已失效，正在返回登录页…', 'err');
      setTimeout(() => (location.href = '/'), 900);
      return;
    }
    const data = await res.json();
    plugin = (data.plugins || []).find((p) => p.id === pluginId) || null;
    if (!plugin) {
      badgeEl.textContent = '插件不存在';
      badgeEl.className = 'badge err';
      titleEl.textContent = '插件不存在';
      subEl.textContent = pluginId;
      setStatus('没有找到该插件，可能已被删除。', 'err');
      return;
    }

    document.title = `${plugin.name} · 插件设置 · JlWBoT`;
    titleEl.textContent = plugin.name;
    subEl.textContent = `${plugin.id} · ${plugin.type || ''} · ${plugin.description || ''}`;
    badgeEl.textContent = plugin.enabled ? '已启用' : '已停用';
    badgeEl.className = 'badge ' + (plugin.enabled ? 'ok' : '');

    if (!plugin.hasSettings) {
      frameWrap.classList.add('hidden');
      emptyEl.classList.remove('hidden');
      saveBtn.disabled = true;
      reloadBtn.disabled = false;
      setStatus('该插件还没有设置页面。', '');
      return;
    }

    emptyEl.classList.add('hidden');
    frameWrap.classList.remove('hidden');
    reloadBtn.disabled = false;
    loadFrame();
  }

  function loadFrame() {
    saveBtn.disabled = true;
    const hash = location.hash === '#review' ? '#review' : '';
    frame.src = `/api/plugins/${encodeURIComponent(pluginId)}/settings?t=${Date.now()}${hash}`;
  }

  function sendInit() {
    if (!plugin || !frame.contentWindow) return;
    frame.contentWindow.postMessage({ type: 'jlw-settings-init', config: plugin.config || {} }, '*');
    saveBtn.disabled = false;
  }

  frame.addEventListener('load', () => {
    sendInit();
  });

  saveBtn?.addEventListener('click', () => {
    if (!frame.contentWindow) return;
    clearTimeout(saveWaitTimer);
    setStatus('等待设置页提交…', '');
    frame.contentWindow.postMessage({ type: 'jlw-settings-save-request' }, '*');
    saveWaitTimer = setTimeout(() => {
      if (statusEl.textContent === '等待设置页提交…') {
        setStatus('设置页没有响应保存请求；如果页面自带保存按钮，请直接点页面里的保存。', 'err');
      }
    }, 4000);
  });

  reloadBtn?.addEventListener('click', () => load());

  async function saveConfig(config) {
    if (!pluginId) return;
    if (!config || typeof config !== 'object' || Array.isArray(config)) {
      setStatus('设置页提交的 config 不是对象', 'err');
      return;
    }
    clearTimeout(saveWaitTimer);
    setStatus('正在保存…', '');
    try {
      const res = await fetch(`/api/plugins/${encodeURIComponent(pluginId)}/config`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config }),
      });
      const data = await res.json();
      if (!res.ok || data.ok === false) throw new Error(data.error || 'HTTP ' + res.status);
      if (plugin) plugin.config = config;
      setStatus('设置已保存', 'ok');
      frame.contentWindow?.postMessage({ type: 'jlw-settings-saved', ok: true }, '*');
    } catch (e) {
      setStatus('保存失败：' + e.message, 'err');
      frame.contentWindow?.postMessage({ type: 'jlw-settings-saved', ok: false, error: e.message }, '*');
    }
  }

  window.addEventListener('message', (e) => {
    if (!frame.contentWindow || e.source !== frame.contentWindow) return;
    const msg = e.data || {};
    if (msg.type === 'jlw-settings-ping') {
      try {
        frame.contentWindow.postMessage({ type: 'jlw-settings-pong' }, '*');
      } catch {
        /* ignore */
      }
      return;
    }
    if (msg.type === 'jlw-settings-save') saveConfig(msg.config);
    // 只刷新审核快照：重读设置页 JSON 块发回 iframe，不整页 load()
    if (msg.type === 'jlw-settings-review-refresh') {
      (async () => {
        try {
          const res = await fetch(`/api/plugins/${encodeURIComponent(pluginId)}/settings?t=${Date.now()}`, { credentials: 'same-origin', cache: 'no-store' });
          if (!res.ok) throw new Error('HTTP ' + res.status);
          const html = await res.text();
          const blocks = {};
          const re = /<script id="([^"]+)" type="application\/json">([\s\S]*?)<\/script>/g;
          let m;
          while ((m = re.exec(html))) blocks[m[1]] = m[2].trim();
          frame.contentWindow?.postMessage({ type: 'jlw-settings-snapshots', blocks }, '*');
          setStatus('审核数据已刷新', 'ok');
        } catch (err) {
          frame.contentWindow?.postMessage({ type: 'jlw-settings-snapshots', blocks: null, error: err.message }, '*');
          setStatus('刷新审核数据失败：' + err.message, 'err');
        }
      })();
      return;
    }
    if (msg.type === 'jlw-settings-refresh') {
      try {
        frame.contentWindow.postMessage({ type: 'jlw-settings-refreshed' }, '*');
      } catch {
        /* ignore */
      }
      load();
    }
  });

  load();
})();
