'use strict';
/**
 * 回响 zip 包导入测试：走真实的面板「导入插件（zip）」接口
 *
 *   zip → /api/plugins/import → 解压落盘 → 插件重载 → 群里 /ping 能回
 *
 * 运行：node test/huixiang-zip-import.js
 * 可用 HUIXIANG_ZIP 指定其它 zip 路径。
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const MANIFEST_FILE = path.join(ROOT, '~JlWBoT', 'plugins', 'huixiang', 'plugin.json');
const PLUGIN_VERSION = JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf8')).version;
const ZIP = path.resolve(process.env.HUIXIANG_ZIP || path.join(ROOT, '插件', `回响-【v${PLUGIN_VERSION}】.zip`));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 15000, interval = 150, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

async function main() {
  assert.ok(fs.existsSync(ZIP), '找不到 zip：' + ZIP);
  console.log('\n回响 zip 导入测试\n');
  console.log('zip:', ZIP);

  const mock = await new MockQQ({ port: 0, accounts: { app_hx: 'sec_hx' } }).start();
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const panelPort = 23100 + Math.floor(Math.random() * 400);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hxzip-'));
  fs.mkdirSync(path.join(dataDir, 'plugins'), { recursive: true });
  fs.writeFileSync(path.join(dataDir, 'plugins', '.seeded'), 'test\n', 'utf8');
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port: panelPort, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        accounts: [
          {
            id: 'a1',
            name: 'zip 测试',
            appId: 'app_hx',
            clientSecret: 'sec_hx',
            enabled: true,
            mode: 'ws',
            sandbox: false,
            prefix: '',
            tokenUrl: mock.base + '/app/getAppAccessToken',
            tokenUrlAlt: mock.base + '/app/getAppAccessToken',
            apiBase: mock.base,
            apiBaseSandbox: mock.base,
            gatewayUrl: mock.wsUrl,
            intents: ['GUILDS', 'GROUP_AND_C2C_EVENT'],
            shardId: 0,
            shardCount: 1,
          },
        ],
        plugins: { enabled: true, defaultTimeoutMs: 8000 },
        log: { level: 'info', console: false },
        storage: { messages: false, events: 100 },
      },
      null,
      2,
    ),
    'utf8',
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${panelPort}`;
  let passed = 0;
  const ok = (cond, label) => {
    assert.ok(cond, label);
    console.log('  ✓ ' + label);
    passed++;
  };

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 20000, 200, '框架启动');
    ok(true, '框架启动');

    // 聚龙账户登录（假账户服务）
    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    assert.equal(login.status, 200, '登录失败：' + login.status);
    const setCookie = (login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '';
    const cookie = setCookie.split(';')[0];
    ok(!!cookie, '面板登录拿到会话');

    // 导入 zip
    const zipB64 = fs.readFileSync(ZIP).toString('base64');
    const res = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ type: 'zip', files: [{ name: path.basename(ZIP), data: zipB64 }] }),
    });
    const body = await res.json();
    assert.equal(res.status, 200, '导入失败：' + JSON.stringify(body));
    assert.equal(body.ok, true);
    assert.equal(body.id, 'huixiang');
    ok(true, 'zip 导入成功，id = huixiang');

    const dir = path.join(dataDir, 'plugins', 'huixiang');
    const got = fs.readdirSync(dir).sort();
    assert.deepEqual(got, ['README.md', 'index.js', 'plugin.json']);
    ok(true, '落盘文件 = plugin.json / index.js / README.md');

    const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8'));
    assert.equal(manifest.name, '回响');
    assert.equal(manifest.version, PLUGIN_VERSION);
    assert.equal(manifest.type, 'js');
    assert.equal(manifest.config.downloadUrl, 'https://www.jlworld.net/');
    assert.ok((body.plugin?.status || '') === 'running', '导入后插件未运行：' + body.plugin?.status);
    ok(true, '清单字段正确，导入后状态 running');

    // 导入后的插件真的能回消息
    await waitFor(() => mock.identifies.app_hx, 15000, 150, '机器人上线');
    const msgId = 'MSG_ZIP_1';
    mock.push(
      'GROUP_MESSAGE_CREATE',
      {
        id: msgId,
        content: '/ping',
        group_openid: 'G_ZIP',
        author: { id: 'U_ZIP', member_openid: 'U_ZIP', username: 'zip 用户' },
        timestamp: new Date().toISOString(),
      },
      { appId: 'app_hx', seq: 9001 },
    );
    const reply = await waitFor(() => mock.sent.find((s) => s.body.msg_id === msgId), 8000, 120, '导入插件回复');
    assert.match(String(reply.body.content), /^砰！ · 延迟 \d+ms · \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
    ok(true, '导入的插件能正常回复 /ping');

    console.log(`\n全部通过（${passed} 项）\n`);
  } catch (e) {
    console.error('\n测试失败：', e.message);
    process.exitCode = 1;
  } finally {
    child.kill();
    await sleep(300);
    await mock.stop();
    await jlwMock.stop();
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
