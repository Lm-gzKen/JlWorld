'use strict';
/**
 * 假聚龙账户插件：用于面板登录的端到端测试
 * 只实现 /api/plugin/jl-account 的 login / me / logout
 */
const http = require('http');

class MockJlw {
  constructor({ port = 0 } = {}) {
    this.port = port;
    this.calls = [];
    this.token = 'jlw_test_token_' + Date.now();
    this.codes = new Map();
    this.users = new Map([
      ['user@test.local', { password: 'secret123', id: 'usr_test0001', name: '测试员', bio: '来自假账户服务', avatar: '/uploads/avatars/usr_test0001.jpg' }],
    ]);
    this.server = http.createServer((req, res) => this._http(req, res));
  }

  async start() {
    await new Promise((r) => this.server.listen(this.port, '127.0.0.1', r));
    this.port = this.server.address().port;
    this.base = `http://127.0.0.1:${this.port}`;
    return this;
  }

  async stop() {
    await new Promise((r) => this.server.close(r));
  }

  _read(req) {
    return new Promise((resolve) => {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    });
  }

  _user(email) {
    const u = this.users.get(String(email || '').toLowerCase());
    if (!u) return null;
    return {
      id: u.id,
      email: String(email).toLowerCase(),
      name: u.name,
      bio: u.bio,
      avatar: u.avatar,
      createdAt: 1791600000000,
      nameChangedAt: 0,
      nameNextAt: 0,
      nameCanChange: true,
      nameCooldownDays: 0,
    };
  }

  async _http(req, res) {
    const url = new URL(req.url, 'http://x');
    const raw = await this._read(req);
    let body = {};
    try {
      body = raw ? JSON.parse(raw) : {};
    } catch {
      body = {};
    }
    const json = (status, obj) => {
      const data = JSON.stringify(obj);
      res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) });
      res.end(data);
    };
    this.calls.push({ path: url.pathname, body, headers: req.headers });

    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/login') {
      const u = this.users.get(String(body.email || '').toLowerCase());
      if (!u || u.password !== body.password) return json(400, { error: '邮箱或密码不正确' });
      return json(200, { ok: true, message: '登录成功', token: this.token, user: this._user(body.email) });
    }
    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/me') {
      if (body.token !== this.token) return json(400, { error: '登录已过期，请重新登录' });
      return json(200, { ok: true, user: this._user('user@test.local') });
    }
    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/send-code') {
      if (!body.email || !String(body.email).includes('@')) return json(400, { error: '邮箱格式错误' });
      this.codes.set(String(body.email).toLowerCase(), '123456');
      return json(200, { ok: true, message: `验证码已发送到 ${body.email}，10 分钟内有效`, cooldown: 60, expiresIn: 10 });
    }
    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/register') {
      const email = String(body.email || '').toLowerCase();
      if (this.users.has(email)) return json(400, { error: '此邮箱已被使用' });
      if (body.code !== '123456') return json(400, { error: '验证码不正确' });
      if (!body.password || String(body.password).length < 6) return json(400, { error: '密码至少 6 位' });
      if (!body.name || String(body.name).length < 2) return json(400, { error: '名称 2–20 字' });
      this.users.set(email, { password: String(body.password), id: 'usr_' + email.split('@')[0], name: String(body.name), bio: '', avatar: '' });
      return json(200, { ok: true, message: '注册成功，欢迎加入', token: this.token, user: this._user(email) });
    }
    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/reset-password') {
      const email = String(body.email || '').toLowerCase();
      if (body.code !== '123456') return json(400, { error: '验证码不正确' });
      const u = this.users.get(email);
      if (!u) return json(400, { error: '账户不存在' });
      u.password = String(body.password);
      return json(200, { ok: true, message: '密码已重置', token: this.token });
    }
    if (req.method === 'POST' && url.pathname === '/api/plugin/jl-account/logout') {
      return json(200, { ok: true, message: '已退出登录' });
    }
    return json(404, { error: 'mock jlw: not found ' + url.pathname });
  }
}

module.exports = MockJlw;
