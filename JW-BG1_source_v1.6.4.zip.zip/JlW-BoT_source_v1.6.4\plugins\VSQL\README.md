# VSQL · 内置 SQLite 数据库服务（JlWBoT 插件）

> 版本 **1.0.3** · 类型 `js` · 引擎 **`node:sqlite`**（Node 22.5+，框架内置 Node 24）· 零 npm 依赖
>
> 给框架里**所有插件**用的数据库服务：别的插件不用装驱动、不用自己管文件，只要 `vsql.db()`
> 就能建表、读写、事务、迁移、备份。**默认所有插件共用一个 shared 库，A 建的表 B/C 可以直接读**；
> 要私有数据再 `vsql.db('私有命名空间')`。表叫什么、建几张、怎么改，全由业务插件自己决定，VSQL 只提供 SQLite 能力。
> 完整接口文档见插件卡片「API」→ `api.html`（也可直接看本目录 `api.html`）。

---

## 0. 为什么需要它

框架本身没有数据库层，插件各自选方案：

| 做法 | 问题 |
| --- | --- |
| 每个插件自己 `fs` 写 JSON | 并发写容易互相覆盖，数据一大就全量读写 |
| 每个插件自己 `require('node:sqlite')` | 每份实现都要处理 WAL / 事务 / 迁移 / 备份 / 关闭，容易写歪 |
| 用外部数据库 | 要额外进程、端口、账号，和「零依赖、整目录拷走」的框架原则冲突 |

VSQL 把这些收口成**一个常驻服务插件**：数据库在框架进程内，其他插件拿到的是同一套经过测试的封装；
文件全部在 `~JlWBoT/plugins/VSQL/data/dbs/` 下，跟着数据目录走，删插件即删库（建议先备份）。

---

## 1. 快速上手

```js
'use strict';

let db = null;

module.exports = {
  async onLoad(ctx) {
    const vsql = globalThis.__JLWBOT_PLUGIN_APIS__?.get('VSQL');
    if (!vsql?.isReady()) {
      ctx.log.warn('VSQL 未加载，本插件的数据功能不可用');
      return;
    }
    db = vsql.db();                           // 默认 shared 库（所有插件互通；私有数据才传命名空间）

    db.table('users', {
      openid: 'TEXT PRIMARY KEY',
      name:   'TEXT NOT NULL DEFAULT ""',
      score:  'INTEGER NOT NULL DEFAULT 0',
    }, { indexes: [['score']] });

    // 版本迁移：只在需要时跑，跑过就不再跑
    db.migrate([
      () => {},                               // 版本 1（建表已在上面做掉）
      { version: 2, sql: 'ALTER TABLE users ADD COLUMN last_sign INTEGER NOT NULL DEFAULT 0' },
    ]);

    ctx.log.info('数据库就绪：' + db.info().file);
  },

  async onEvent(ctx) {
    const cmd = ctx.message?.command?.name;
    if (cmd === '签到') {
      const openid = ctx.message.author.user_openid || ctx.message.author.member_openid;
      db.upsert('users', { openid, score: 10 });
      db.run('UPDATE users SET score = score + 1 WHERE openid = ?', openid);
      const row = db.get('SELECT score FROM users WHERE openid = ?', openid);
      return { reply: `当前积分：${row.score}` };
    }
    return null;
  },

  async onUnload() {
    db = null;                                // VSQL 会统一关闭句柄，不用自己关
  },
};
```

**三条约定**（踩过就懂）：

1. **不要缓存 VSQL 的对象**：每次用之前 `get('VSQL')`，VSQL 重载后旧对象上的 `isReady()` 为 false。
2. **不要缓存 db 句柄跨重载**：VSQL 重载会关闭全部句柄，旧句柄再操作会抛 `DB_CLOSED`，重新 `vsql.db()` 即可。
3. **方法都是同步的**：`node:sqlite` 是同步驱动，查大表会占住框架主线程；批量写用 `db.tx()`。

### 1.1 跨插件共享一张表

默认都进 `shared` 库，所以表是**通用的**——没有归属限制：

```js
// 插件 A：建表 + 写
const db = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL').db();
db.createTable('myplugin_users', { openid: 'TEXT PRIMARY KEY', score: 'INTEGER NOT NULL DEFAULT 0' });
db.upsert('myplugin_users', { openid: 'U1', score: 10 });

// 插件 B / C：同一张表直接读（不用问 A 要任何东西）
const db2 = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL').db();
db2.all('SELECT * FROM myplugin_users WHERE score > ?', 5);
```

- 表名建议加插件前缀（`myplugin_users`）避免撞名，但 VSQL 不强制、不登记归属。
- 如果 A 用了私有命名空间（`db('a-ns')`），B 可以 `vsql.findTable('表名')` 找到它再显式打开。
- 需要的话随时 `db.tables()` 看当前库里的表，`vsql.tables()` 看默认库。

---

## 2. 目录与文件

```text
plugins/VSQL/
├─ plugin.json          # 元数据、事件（私聊）、配置
├─ index.js             # 生命周期 + /vsql 管理指令
├─ api.js               # 对外 API（注册到 __JLWBOT_PLUGIN_APIS__）
├─ lib/
│  ├─ db.js             # NamespaceDB：exec/run/get/all/tx/prepare/table/migrate/backup
│  ├─ sql.js            # where / order / insert / update 的安全 SQL 构造
│  ├─ namespaces.js     # 命名空间 → 文件、句柄缓存、LRU、关闭
│  ├─ http-gateway.js   # 可选的本机 HTTP SQL 网关（127.0.0.1 + 令牌）
│  └─ util.js           # 命名空间/标识符校验、值归一化、大小/时间
├─ settings.html        # 面板设置页（存储 / HTTP / 管理指令）
├─ api.html             # 完整接口文档
└─ README.md
```

运行时数据（跟着数据目录走，不随插件包发布）：

```text
~JlWBoT/plugins/VSQL/
├─ plugin.json          # ← 面板设置会改这里的 config
└─ data/
   └─ dbs/
      ├─ myplugin.db        # 每个命名空间一个库
      ├─ myplugin.db-wal    # WAL（正常现象）
      ├─ myplugin.db-shm
      ├─ http-token.txt     # HTTP 网关令牌
      └─ backups/           # db.backup() 的默认目录
```

---

## 3. 接口一览（详细示例看 `api.html`）

```js
const vsql = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL');
const db = vsql.db();            // shared 库（跨插件互通）；私有数据用 vsql.db('myplugin')
```

| 层 | 方法 | 说明 |
| --- | --- | --- |
| 命名空间 | `vsql.db(ns, opts)` / `has` / `list` / `tables(ns?)` / `findTable(name)` / `close` / `closeAll` / `openCount` | 不传 ns = shared；`readOnly` / `memory` 可选 |
| 原生 SQL | `exec` / `run` / `get` / `all` / `value` / `column` / `prepare` / `tx` | 参数走 `?` 或 `:name`，事务可嵌套 |
| 行封装 | `table` / `insert` / `insertMany` / `upsert` / `update` / `del` / `select` / `count` / `exists` | 表名/列名白名单，where 支持操作符与 `$and/$or` |
| 结构 | `table/createTable` / `renameTable` / `addColumn` / `renameColumn` / `dropColumn` / `tables` / `columns` / `indexes` / `schema` / `hasTable` / `dropTable` / `primaryKeys` | 建表/改表全开放，表名支持中文 |
| 迁移 | `migrate` / `userVersion` / `setUserVersion` | 基于 `PRAGMA user_version`，每步一个事务 |
| 键值 | `db.kv.get/set/del/has/all/keys/clear/incr` | 值自动 JSON 序列化 |
| 维护 | `backup` / `vacuum` / `checkpoint` / `info` / `pragma` / `close` | 备份默认落到 `data/dbs/backups/` |
| 状态 | `vsql.stats()` / `isReady()` / `version` / `http()` / `token()` | 面板/日志/管理指令用 |

完整签名、`where` 语法、错误码见 `api.html`。

---

## 4. 配置项（面板「编辑 → 设置」）

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `dataDir` | `data/dbs` | 数据库目录；相对插件目录或绝对路径 |
| `defaultNamespace` | `shared` | `vsql.db()` 不传参时用哪个库 |
| `maxOpen` | `16` | 最多同时打开几个库，超出按 LRU 关闭（事务中的不关） |
| `autoCreate` | `true` | 关闭后 `db()` 只接受已存在的库 |
| `allowAttach` | `false` | 是否允许 `ATTACH / DETACH` |
| `busyTimeoutMs` | `5000` | 别的进程占用时的等待时间 |
| `injectSettings` | `true` | 把完整数据目录 + 表数据快照写进设置页（sandbox 读不到文件系统，只能插件注入） |
| `settingsPreview.enabled` | `true` | 是否在设置页显示「数据浏览」 |
| `settingsPreview.maxRows` / `maxTables` / `maxNamespaces` | `10` / `15` / `8` | 预览行数、预览表数、扫描库数上限 |
| `settingsPreview.maxBytes` | `204800` | 数据快照 JSON 的字节预算（超出只列结构） |
| `settingsPreview.redact` | `true` | 敏感列名打码 |
| `http.enabled` | `true` | 是否开本机 HTTP 网关（JS 插件不需要） |
| `http.host` / `http.port` | `127.0.0.1` / `8787` | 监听地址/端口；端口被占用自动 +1…+5 |
| `http.token` | 空 | 留空则自动生成并写入 `data/dbs/http-token.txt` |
| `http.maxRows` | `1000` | HTTP 单次最多返回行数 |
| `admin.enabled` | `true` | 是否启用私聊 `/vsql` |
| `admin.openids` | `[]` | 允许使用 `/vsql` 的 OpenID（**不填 = 谁都不能用**） |
| `admin.allowWrite` | `false` | 管理指令是否允许写 SQL（默认只读） |
| `admin.groupEnabled` | `false` | 是否允许在群里用 `/vsql`（默认关闭；仍只认管理员） |
| `admin.maxRows` | `30` | 管理指令最多显示行数 |

设置页是沙箱 iframe：只能读写 `plugin.json` 的 `config`，读不到文件系统、也发不了网络请求。所以路径与数据浏览都由插件在 `onLoad` 时**注入只读快照**到 `settings.html`（`#vsql-runtime` / `#vsql-data`）。

「存储 → 数据目录」下面会显示**从盘符开始的完整路径**（例如 `C:\Users\...\~JlWBoT\plugins\VSQL\data\dbs`），随输入实时更新，带「复制」按钮。这个路径由插件 `onLoad` 注入到 `settings.html` 的 `#vsql-runtime` 快照（iframe 读不到文件系统），所以刚改完配置、还没保存/重载时显示的是当前生效路径；不想让它写这个快照可把 `injectSettings` 设为 `false`。

![设置页数据目录](screenshot-settings.png)

### 4.1 设置页数据浏览（只读）

设置页最下面的「数据浏览」列出**所有命名空间里的所有表**，选中表就能看前 N 行：

![设置页数据浏览](screenshot-data.png)

- 快照在插件 `onLoad` 时生成：每个库的表名、行数、列结构，以及每张表最多 `settingsPreview.maxRows` 行（默认 10）。
- **敏感列自动打码**：列名匹配 `token / secret / password / sid / session / credential / api_key` 时值显示 `***`（`settingsPreview.redact`，默认开）。
- 体积有上限：默认最多 8 个库 × 15 张表、快照 JSON 不超过 200 KB；超出时只列结构、不预览样例行，页面会标注「未纳入预览」。
- 单元格超过 120 字符会截断显示，鼠标悬停看全文；`NULL` 灰显，`***` 橙色。
- 「过滤当前表的行…」在浏览器本地筛（不查库）；「刷新数据」会保存当前已生效配置让插件重载一次，然后自动刷新页面（未保存的表单修改不会被写入）。
- 内部表（`__vsql_kv` 等以 `__vsql_` 开头）不显示。
- 想要全量/复杂查询还是用私聊 `/vsql sql <ns> <SQL>` 或 HTTP 网关。


---

## 5. 管理指令 `/vsql`（私聊；群聊可选）

`plugin.json` 订阅 `C2C_MESSAGE_CREATE`、`GROUP_AT_MESSAGE_CREATE`、`GROUP_MESSAGE_CREATE`，命令白名单 `vsql`。

- **私聊**：直接发 `/vsql …`，只认 `admin.openids` 里的 OpenID。
- **群聊**：默认关闭，群里发什么都不响应；到设置页「管理指令 → 允许在群里使用」打开后才会响应（建议 @机器人），仍然只认管理员，非管理员完全静默。查询结果全群可见，注意数据暴露。

| 指令 | 作用 |
| --- | --- |
| `/vsql stats` | 版本、数据目录、库数量/大小、打开数、HTTP 状态 |
| `/vsql list` | 所有命名空间（大小、表数、是否打开） |
| `/vsql tables <ns>` | 某库的表和行数 |
| `/vsql schema <ns>` | 某库的建表语句 |
| `/vsql sql <ns> <SQL>` | 执行 SQL（默认只读；写要开 `admin.allowWrite`） |
| `/vsql backup [ns]` | 在线备份，返回文件路径 |
| `/vsql token` | 查看 HTTP 网关令牌 |

首次使用：把 `admin.openids` 留空保存 → 私聊发 `/vsql`，机器人会把你自己的 OpenID 回给你，
填进设置页再保存即可。**不要把这个 OpenID 列表分享出去**，它等价于数据库管理权限。

---

## 6. HTTP 网关（易语言 / pull 插件 / 外部程序）

JS 插件直接用进程内 API，不需要 HTTP。外部程序才需要打开它。

```bash
# 健康检查（免令牌）
curl -s http://127.0.0.1:8787/health
# {"ok":true,"name":"VSQL","version":"1.0.0","uptimeMs":1234}

# 查询
curl -s http://127.0.0.1:8787/query \
  -H "Authorization: Bearer <令牌>" \
  -H "Content-Type: application/json" \
  -d '{"ns":"myplugin","sql":"SELECT * FROM users WHERE score > ?","params":[10],"mode":"all"}'

# 建表 / 多语句
curl -s http://127.0.0.1:8787/exec \
  -H "Authorization: Bearer <令牌>" \
  -H "Content-Type: application/json" \
  -d '{"ns":"myplugin","sql":"CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, msg TEXT);"}'

# 备份
curl -s http://127.0.0.1:8787/backup \
  -H "Authorization: Bearer <令牌>" -H "Content-Type: application/json" \
  -d '{"ns":"myplugin"}'
```

`mode`：`all`（默认，行数组）/ `get`（单行）/ `value`（标量）/ `column`（首列）/ `run`（写入）/ `exec`（多语句）。
认证头：`Authorization: Bearer <令牌>` 或 `X-VSQL-Token: <令牌>`。

**安全**：默认只绑 `127.0.0.1`；改成 `0.0.0.0` 等于把数据库暴露到局域网，请同时换强令牌 + 防火墙。
HTTP 层没有表级权限，拿到令牌就是所有命名空间的读写权限。

---

## 7. 设计要点 / 坑

1. **一命名空间一文件**：插件之间不共享表，不会互相覆盖；确实要共享就约定同一个命名空间名。
2. **WAL + busy_timeout**：读写不互相阻塞；备份用 `db.backup()`，不要直接复制正在写的文件。
3. **值归一化**：`true/false → 1/0`、`Date → ISO 字符串`、对象/数组 → JSON 字符串（读出来是字符串，自己 `JSON.parse`）、`undefined → NULL`。
4. **标识符白名单**：表名/列名只允许 `[A-Za-z_][A-Za-z0-9_]*`；要诡异名字请写原生 SQL（值仍然走占位符）。
5. **ATTACH 默认禁用**：打开后可以跨库查询，但也意味着一个库能读到别的库文件，按需开启。
6. **同步驱动**：别在事件处理里跑几万行的大查询；统计类请建索引或用 `kv` 预计算。
7. **卸载即关**：插件停用/重载/删除时 VSQL 会 `closeAll()`，句柄失效是预期行为。
8. **Node 版本**：需要 `node:sqlite`（Node 22.5+）。框架内置 Node 24，正常都有；老环境会加载失败并在日志里说明。
9. **更新插件不会 EPERM**：`onUnload` 先同步 `closeAll()` 关闭 SQLite 文件、再停 HTTP。框架删除/更新插件时不会等异步 `onUnload` 完成（只留 600ms 重试），晚关一步就会报 `EPERM`，甚至把插件从注册表里丢掉。

---

### 7.1 多插件同时操作（并发语义）

可以。能不能并发、会怎样排队，取决于「谁在操作同一个文件」：

| 场景 | 连接 | 行为 |
| --- | --- | --- |
| 不同插件 → 不同命名空间 | 各自独立的连接与文件 | 完全互不影响；写入按调用顺序排队执行 |
| 不同插件 → 同一个命名空间 | **同一个连接**（管理器复用句柄） | 共享语句缓存与事务；同样排队，不会出现 `SQLITE_BUSY` |
| 本机 HTTP 网关 | 与进程内**同一个连接** | 与插件调用一起排队 |
| 外部进程/工具直接打开 `.db` | 独立连接 | WAL 下读与写可并行，写与写排队；`busy_timeout` 5 秒，超时才报 busy |

关键结论：

- **单线程同步**：一条查询执行期间，框架里所有插件/网关调用都在等它。大表扫描会卡住收发消息——建索引、别在事件里扫全表。
- **读-改-写别跨 `await`**：两个插件各读一次再各写一次会丢更新；用 `UPDATE t SET n = n + 1`（原子）或放进同步的 `db.tx()`。事务内没有 `await`，别的插件插不进来。
- **事务要短**：`tx(fn)` 是同步的，别把网络请求放进去；长事务会占住写锁，外部连接只能等到 `busy_timeout`。
- **共享命名空间要约定表名**：能用「一个插件一个命名空间」就别共用；确实共用时表名加前缀。
- **句柄别长期缓存**：`maxOpen` 会把最久未使用的句柄 LRU 回收（活跃的不会），用时现取 `vsql.db(ns)` 最稳。

```js
// 两个插件同时给同一个计数器 +1，不会丢
db.run('UPDATE counter SET n = n + 1 WHERE id = 1');

// 需要多步一致性时放进事务（同步回调）
db.tx(() => {
  const row = db.get('SELECT n FROM counter WHERE id = 1');
  db.run('UPDATE counter SET n = ? WHERE id = 1', row.n + 1);
  db.run('INSERT INTO counter_log(n) VALUES(?)', row.n + 1);
});
```

实测（`node test/vsql-test.js` 里的并发用例）：两个「插件」共用命名空间各 300 次原子自增 → 结果精确 600；两个独立连接同时写同一个文件各 100 条 → 200 条全落盘、0 次 busy。

## 8. 自测

```powershell
node test/vsql-test.js
```

覆盖 48 项：命名空间隔离与跨插件 shared 共享 / 建表增删改查 / where 操作符 / 分页排序 / 事务与回滚 / 嵌套保存点 /
async 事务拒绝 / 预编译 / 命名参数 / 值归一化 / kv / 迁移幂等 / 结构查询 / 中文表名列名 /
建表改表删表 API / findTable / ATTACH 开关 / 只读 / 关闭语义 / 备份可读 / LRU / 内存库 / 管理指令 /
HTTP 网关全套 / 同端口重载竞态 / 卸载清理 / 跨插件懒取 / 多插件并发与原子自增 /
设置页路径快照 / 数据浏览快照（表清单、样例行、敏感列打码、行数上限、只写副本）。

测试用 `test/.tmp-vsql/` 临时目录，跑完自动删除，不碰运行中的 `~JlWBoT/plugins/VSQL/data`。

---

## 9. 版本记录

| 版本 | 说明 |
| --- | --- |
| 1.0.0 | 首发：命名空间隔离、原生 SQL、表/行封装、事务、迁移、kv、备份、本机 HTTP 网关、`/vsql` 管理指令、设置页与 API 文档 |
| 1.0.1 | 设置页显示从盘符开始的完整数据目录（插件注入运行时快照，带复制按钮）；默认 shared 库跨插件共享表，新增 `vsql.tables()` / `findTable()`；独立出 `createTable/renameTable/addColumn/renameColumn/dropColumn`；表名/列名支持中文 |
| 1.0.3 | 新增群聊可选模式：`admin.groupEnabled` 打开后群里（建议 @机器人）也能用 `/vsql`，仍只认管理员；默认关闭，群聊完全静默；自测 48 项 |
| 1.0.2 | 设置页新增「数据浏览」：列出各库所有表 + 前 N 行，支持切换库/表、本地过滤、敏感列打码、一键刷新（重载插件）；快照注入带体积/表数/行数上限，内部表不展示；`onUnload` 改为同步关库，修复面板「更新插件」报 EPERM / 插件不存在；自测 46 项 |
