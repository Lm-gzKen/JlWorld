'use strict';
/**
 * 结束进程.cmd：连启动器一起结束，并阻止启动器自动重启
 *   node test/stop-all-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function alive(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM';
  }
}

(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-stopall-'));
  const port = 24700 + Math.floor(Math.random() * 200);
  for (const d of ['src', 'tools', '~JlWBoT']) fs.mkdirSync(path.join(tmp, d), { recursive: true });
  fs.copyFileSync(path.join(ROOT, 'tools', 'stop-all.ps1'), path.join(tmp, 'tools', 'stop-all.ps1'));

  fs.writeFileSync(
    path.join(tmp, 'src', 'index.js'),
    `const http=require('http');const srv=http.createServer((q,s)=>s.end('ok'));srv.listen(${port},'127.0.0.1',()=>console.log('child-ready'));setInterval(()=>{},1000);`,
  );
  fs.writeFileSync(
    path.join(tmp, 'tools', 'start-panel.ps1'),
    [
      '$root = Split-Path -Parent $PSScriptRoot',
      '$flag = Join-Path $root "~JlWBoT\\stop.flag"',
      '$node = $env:JLW_NODE',
      'if (-not $node) { $node = "node" }',
      'while (-not (Test-Path -LiteralPath $flag)) {',
      '  $p = Start-Process -FilePath $node -ArgumentList @((Join-Path $root "src\\index.js")) -WorkingDirectory $root -WindowStyle Hidden -PassThru',
      '  Set-Content -LiteralPath (Join-Path $root "~JlWBoT\\child.pid") -Value $p.Id',
      '  $p.WaitForExit()',
      '  Start-Sleep -Milliseconds 300',
      '}',
    ].join('\r\n'),
  );
  fs.writeFileSync(
    path.join(tmp, '~JlWBoT', 'config.json'),
    JSON.stringify({ server: { host: '127.0.0.1', port, openBrowser: false }, plugins: { enabled: false } }, null, 2),
  );

  const env = { ...process.env, JLW_NODE: process.execPath };
  const launcher = spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(tmp, 'tools', 'start-panel.ps1')], {
    cwd: tmp,
    env,
    stdio: 'ignore',
    windowsHide: true,
  });

  let childPid = 0;
  let healthy = false;
  for (let i = 0; i < 60; i++) {
    await sleep(200);
    try {
      childPid = Number(fs.readFileSync(path.join(tmp, '~JlWBoT', 'child.pid'), 'utf8').trim()) || 0;
    } catch {
      /* not yet */
    }
    try {
      const r = await fetch(`http://127.0.0.1:${port}/`, { signal: AbortSignal.timeout(800) });
      healthy = r.ok;
    } catch {
      healthy = false;
    }
    if (childPid && healthy) break;
  }
  check(!!childPid && alive(childPid), '启动器拉起了子进程', String(childPid));
  check(healthy, '子进程在监听端口', String(port));

  // 运行结束进程（只清当前项目）
  execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(tmp, 'tools', 'stop-all.ps1'), '-ProjectOnly', '-Quiet'], {
    cwd: tmp,
    stdio: 'ignore',
  });

  await sleep(1200);
  check(!alive(childPid), '子进程已被结束', String(childPid));
  check(!alive(launcher.pid), '启动器（含自动重启循环）也被结束', String(launcher.pid));
  check(fs.existsSync(path.join(tmp, '~JlWBoT', 'stop.flag')), '写入 stop.flag 停止标记');
  check(!fs.existsSync(path.join(tmp, '~JlWBoT', 'run.pid')), '清理运行锁');

  // 再等几秒，确认没有“复活”
  await sleep(2500);
  check(!alive(childPid), '不会自动重启（没有复活的子进程）', String(childPid));

  try {
    if (alive(launcher.pid)) launcher.kill();
  } catch {
    /* ignore */
  }
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
  } catch {
    /* ignore */
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
