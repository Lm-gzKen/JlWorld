'use strict';
/**
 * 测试插件夹具：源码仓库有 plugins/ 示例时直接复制；
 * 发布包（不带插件）里则生成最小 echo/status/el-sample，保证测试可独立运行。
 */
const fs = require('fs');
const path = require('path');

const ECHO_INDEX = `'use strict';
module.exports = {
  async onEvent(ctx) {
    const m = ctx.message;
    if (!m) return null;
    if (m.command?.name === 'ping') return { reply: 'pong' };
    if (m.command?.name === 'echo') return { reply: (m.command.args || []).join(' ') || 'pong' };
    return null;
  },
};
`;

const FIXTURES = {
  echo: {
    manifest: {
      id: 'echo',
      name: '回声示例（测试）',
      version: '1.0.0',
      author: 'test',
      description: '测试用最小 JS 插件',
      enabled: true,
      type: 'js',
      priority: 100,
      events: ['GROUP_AT_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE'],
      commands: [],
      config: {},
    },
    index: ECHO_INDEX,
  },
  status: {
    manifest: {
      id: 'status',
      name: '运行状态（测试）',
      version: '1.0.0',
      author: 'test',
      description: '测试用占位插件',
      enabled: true,
      type: 'pull',
      priority: 200,
      events: ['__test_none__'],
      commands: [],
      config: {},
    },
  },
  'el-sample': {
    manifest: {
      id: 'el-sample',
      name: '易语言示例（测试）',
      version: '1.0.0',
      author: 'test',
      description: '测试用 pull 插件',
      enabled: true,
      type: 'pull',
      priority: 100,
      events: ['GROUP_AT_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE'],
      commands: ['天气', '签到'],
      config: {},
    },
  },
};

function seedTestPlugins(dataDir, root) {
  const target = path.join(dataDir, 'plugins');
  fs.mkdirSync(target, { recursive: true });
  for (const [id, fixture] of Object.entries(FIXTURES)) {
    const dst = path.join(target, id);
    if (fs.existsSync(dst)) continue;
    const src = path.join(root, 'plugins', id);
    if (fs.existsSync(path.join(src, 'plugin.json'))) {
      fs.cpSync(src, dst, { recursive: true });
      continue;
    }
    fs.mkdirSync(dst, { recursive: true });
    fs.writeFileSync(path.join(dst, 'plugin.json'), JSON.stringify(fixture.manifest, null, 2));
    if (fixture.index) fs.writeFileSync(path.join(dst, 'index.js'), fixture.index);
  }
}

module.exports = seedTestPlugins;
