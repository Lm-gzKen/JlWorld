// 评分（5 颗心）：下载过的用户可以给别人的插件评分，再点一次是改分。
import { HttpError } from '../http.mjs';

const round1 = (x) => (x ? Math.round(Number(x) * 10) / 10 : 0);

/** 某个插件的评分汇总 */
export function ratingStats(store, pluginId) {
  const g = store.get('SELECT AVG(stars) AS avg, COUNT(*) AS n FROM ratings WHERE plugin_id=?', pluginId);
  return { avg: round1(g && g.avg), count: (g && g.n) || 0 };
}

/** 列表页批量取评分，避免 N+1 */
export function ratingsFor(store, ids) {
  const map = new Map();
  if (!ids.length) return map;
  const ph = ids.map(() => '?').join(',');
  for (const r of store.all(
    `SELECT plugin_id, AVG(stars) AS avg, COUNT(*) AS n FROM ratings WHERE plugin_id IN (${ph}) GROUP BY plugin_id`,
    ...ids
  )) {
    map.set(r.plugin_id, { avg: round1(r.avg), count: r.n });
  }
  return map;
}

/** 该用户是否下载过这个插件（评分的前提条件） */
export function hasDownloaded(store, pluginId, email) {
  return !!store.get('SELECT 1 AS x FROM download_logs WHERE plugin_id=? AND email=? LIMIT 1', pluginId, email);
}

export default function register(router) {
  router.post('/api/plugins/:id/rating', async (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id=?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.offline) throw new HttpError(403, '该插件已被管理员下架');
    if (p.email === u.email) throw new HttpError(400, '不能给自己的插件评分');
    if (!hasDownloaded(c.store, p.id, u.email)) {
      throw new HttpError(403, '下载过这个插件之后才能评分');
    }

    const b = await c.json();
    const stars = Math.round(Number(b.stars));
    if (!(stars >= 1 && stars <= 5)) throw new HttpError(400, '评分只能是 1~5 颗心');

    const now = Date.now();
    const old = c.store.get('SELECT * FROM ratings WHERE plugin_id=? AND email=?', p.id, u.email);
    if (old) {
      c.store.run('UPDATE ratings SET stars=?, updated=? WHERE plugin_id=? AND email=?', stars, now, p.id, u.email);
    } else {
      c.store.run(
        'INSERT INTO ratings (plugin_id, email, stars, created, updated) VALUES (?,?,?,?,?)',
        p.id,
        u.email,
        stars,
        now,
        now
      );
    }
    // 作者会收到一条消息（自己给自己评不了，所以这里不会自通知）
    c.store.run(
      'INSERT INTO messages (to_email, plugin_id, comment_id, kind, body, created) VALUES (?,?,0,?,?,?)',
      p.email,
      p.id,
      'rating',
      `你的插件《${p.name}》收到了 ${stars} 颗心评价。`,
      now
    );
    return { ok: true, stars, myRating: stars, ...ratingStats(c.store, p.id) };
  });
}
