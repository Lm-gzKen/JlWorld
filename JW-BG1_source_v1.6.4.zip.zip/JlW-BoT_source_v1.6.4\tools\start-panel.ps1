﻿#requires -Version 5.1
# JlWBoT 启动器：结束旧实例 -> 启动 -> 等待就绪 -> 打印后台地址 -> 打开浏览器
# 由 启动机器人.cmd 调用
#   -NoOpen  只启动，不自动打开浏览器（适合任务计划程序）

param([switch]$NoOpen, [switch]$NoRestart, [switch]$Background)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# 上次「结束进程」留下的停止标记：本次是用户主动启动，清掉它
$stopFlag = Join-Path $root '~JlWBoT\stop.flag'
if (Test-Path -LiteralPath $stopFlag) { Remove-Item -LiteralPath $stopFlag -Force -ErrorAction SilentlyContinue }

function Write-Line($text, $color = 'Gray') {
  Write-Host $text -ForegroundColor $color
}

# 关闭控制台“快速编辑”：窗口里误点/拖选文字会让控制台停止处理输出，
# Node 写 stdout 是同步的，整个进程会被冻住（表现：不回复、没日志、面板打不开）。
function Disable-QuickEdit {
  try {
    if (-not ('JlwConsoleMode' -as [type])) {
      Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class JlwConsoleMode {
  [DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr GetStdHandle(int nStdHandle);
  [DllImport("kernel32.dll", SetLastError = true)] public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
  [DllImport("kernel32.dll", SetLastError = true)] public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
}
"@ -ErrorAction Stop
    }
    $h = [JlwConsoleMode]::GetStdHandle(-10)   # STD_INPUT_HANDLE
    $mode = [uint32]0
    if (-not [JlwConsoleMode]::GetConsoleMode($h, [ref]$mode)) { return $false }
    # ENABLE_EXTENDED_FLAGS = 0x80，去掉 ENABLE_QUICK_EDIT_MODE = 0x40
    $new = [uint32](([int64]$mode -bor 0x80) -band 0xFFFFFFBF)
    return [bool][JlwConsoleMode]::SetConsoleMode($h, $new)
  } catch {
    return $false
  }
}

# ---------- 1. 找 Node ----------
function Resolve-NodePath {
  $candidates = New-Object System.Collections.Generic.List[string]
  if ($env:JLW_NODE) { $candidates.Add([string]$env:JLW_NODE) }
  $candidates.Add((Join-Path $root 'runtime\node.exe'))
  $candidates.Add((Join-Path $root 'node.exe'))
  if ($env:ProgramFiles) { $candidates.Add((Join-Path $env:ProgramFiles 'nodejs\node.exe')) }
  if (${env:ProgramFiles(x86)}) { $candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe')) }
  if ($env:LOCALAPPDATA) { $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')) }
  if ($env:USERPROFILE) { $candidates.Add((Join-Path $env:USERPROFILE 'scoop\apps\nodejs\current\node.exe')) }
  $candidates.Add('C:\nodejs\node.exe')
  $candidates.Add('D:\nodejs\node.exe')

  foreach ($p in $candidates) {
    if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) {
      return (Resolve-Path -LiteralPath $p).Path
    }
  }

  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source -and (Test-Path -LiteralPath $cmd.Source -PathType Leaf)) {
    return $cmd.Source
  }

  # 便携版常见解压目录：D:\node-v26.13.1-win-x64\node.exe
  $drives = @()
  try { $drives = @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue) } catch { }
  foreach ($d in $drives) {
    $driveRoot = $d.Root
    foreach ($p in @((Join-Path $driveRoot 'node.exe'), (Join-Path $driveRoot 'nodejs\node.exe'))) {
      if (Test-Path -LiteralPath $p -PathType Leaf) { return (Resolve-Path -LiteralPath $p).Path }
    }
    $dirs = @()
    try { $dirs = @(Get-ChildItem -LiteralPath $driveRoot -Directory -Filter 'node-*' -ErrorAction SilentlyContinue) } catch { }
    foreach ($dir in $dirs) {
      $p = Join-Path $dir.FullName 'node.exe'
      if (Test-Path -LiteralPath $p -PathType Leaf) { return (Resolve-Path -LiteralPath $p).Path }
    }
  }
  return $null
}

$node = Resolve-NodePath
if (-not $node) {
  Write-Line ''
  Write-Line '  [ERROR] Node.js not found.' 'Red'
  Write-Line '  1. Install Node.js 18+  https://nodejs.org/' 'Yellow'
  Write-Line ('  2. Or put node.exe into: ' + (Join-Path $root 'runtime\')) 'Yellow'
  Write-Line '  3. Portable node: set JLW_NODE to node.exe, or unpack to D:\node-vX.Y.Z-win-x64\' 'Yellow'
  Write-Line ''
  exit 1
}

# ---------- 2. 读配置（端口 / 聚龙账户站点） ----------
$port = 8686
$serverHost = '127.0.0.1'
$jlwBase = ''
$cfgPath = Join-Path $root '~JlWBoT\config.json'
if (Test-Path $cfgPath) {
  try {
    $text = [System.IO.File]::ReadAllText($cfgPath, [System.Text.Encoding]::UTF8)
    $cfg = $text | ConvertFrom-Json
    if ($cfg.server -and $cfg.server.port) { $port = [int]$cfg.server.port }
    if ($cfg.server.host) { $serverHost = [string]$cfg.server.host }
    if ($cfg.jlw -and $cfg.jlw.baseUrl) { $jlwBase = [string]$cfg.jlw.baseUrl }
  } catch {
    Write-Line ('  [WARN] 读取配置失败，使用默认端口 8686：' + $_.Exception.Message) 'Yellow'
  }
}
$base = "http://127.0.0.1:$port"

# ---------- 3. 结束旧实例 ----------
Write-Line ''
Write-Line '  [1/3] 检查并结束旧实例…' 'Cyan'
$killed = @()

try {
  Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
    $cl = [string]$_.CommandLine
    if ($cl -match 'src[\\/]index\.js') {
      try {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop
        $killed += $_.ProcessId
      } catch { }
    }
  }
} catch { }

# 端口仍被 node 占用（可能是用别的命令启动的），一并结束
$deadline = (Get-Date).AddSeconds(6)
while ((Get-Date) -lt $deadline) {
  $listeners = @()
  try { $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue) } catch { }
  if ($listeners.Count -eq 0) { break }
  foreach ($l in $listeners) {
    $p = Get-Process -Id $l.OwningProcess -ErrorAction SilentlyContinue
    if ($p -and $p.ProcessName -eq 'node') {
      try {
        Stop-Process -Id $p.Id -Force -ErrorAction Stop
        $killed += $p.Id
      } catch { }
    }
  }
  Start-Sleep -Milliseconds 300
}

$killed = $killed | Sort-Object -Unique
if ($killed.Count -gt 0) {
  Write-Line ('      已结束旧进程：PID ' + ($killed -join ', ')) 'Green'
} else {
  Write-Line '      没有发现运行中的旧实例' 'DarkGray'
}

# 端口是否被非 node 程序占用
$still = @()
try { $still = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue) } catch { }
if ($still.Count -gt 0) {
  $owner = Get-Process -Id $still[0].OwningProcess -ErrorAction SilentlyContinue
  Write-Line ''
  Write-Line ('  [ERROR] 端口 ' + $port + ' 被其他程序占用：' + $owner.ProcessName + ' (PID ' + $still[0].OwningProcess + ')') 'Red'
  Write-Line '  请关闭该程序，或在 ~JlWBoT\config.json 里改 server.port。' 'Yellow'
  Write-Line ''
  exit 1
}

# ---------- 4. 启动（异常退出自动拉起） ----------
Write-Line '  [2/3] 正在启动服务…' 'Cyan'
$quickEditOff = if ($Background) { $false } else { Disable-QuickEdit }
$maxRestarts = if ($NoRestart) { 0 } else { 3 }
$restarts = 0
$quickFails = 0
$firstStart = $true
$crashLog = Join-Path $root '~JlWBoT\logs\crash.log'

while ($true) {
  if ($Background) {
    $proc = Start-Process -FilePath $node -ArgumentList @('src\index.js', '--no-open') -WorkingDirectory $root -WindowStyle Hidden -PassThru
  } else {
    $proc = Start-Process -FilePath $node -ArgumentList @('src\index.js', '--no-open') -WorkingDirectory $root -NoNewWindow -PassThru
  }
  $sw = [System.Diagnostics.Stopwatch]::StartNew()

  # ---------- 5. 等服务就绪 ----------
  $ready = $false
  $lastError = ''
  for ($i = 0; $i -lt 80; $i++) {
    if ($proc.HasExited) { break }
    try {
      $r = Invoke-WebRequest -UseBasicParsing -Uri ($base + '/health') -TimeoutSec 2
      if ($r.StatusCode -eq 200) { $ready = $true; break }
    } catch {
      $lastError = $_.Exception.Message
    }
    Start-Sleep -Milliseconds 400
  }

  if (-not $ready) {
    Write-Line ''
    if ($proc.HasExited) {
      Write-Line ('  [ERROR] 服务启动失败，退出码 ' + $proc.ExitCode) 'Red'
    } else {
      Write-Line '  [ERROR] 等待服务就绪超时。' 'Red'
    }
    Write-Line ('  最后错误：' + $lastError) 'DarkGray'
    if (Test-Path -LiteralPath $crashLog) { Write-Line ('  崩溃/异常记录：' + $crashLog) 'Yellow' }
    Write-Line '  请查看上方日志。' 'Yellow'
    Write-Line ''
    exit 1
  }

  if ($firstStart) {
    $firstStart = $false
    if (-not $Background) {
      if ($quickEditOff) {
        Write-Line '      已关闭控制台“快速编辑”（避免误点选中把进程冻住）' 'DarkGray'
      } else {
        Write-Line '      [提示] 没能关闭控制台“快速编辑”：请不要在窗口里拖选文字，否则进程会卡住。' 'Yellow'
      }
    }

    # ---------- 6. 输出后台地址并打开 ----------
    $dataDir = Join-Path $root '~JlWBoT'
    $bar = '  ' + ('=' * 62)
    Write-Line ''
    Write-Line $bar 'DarkCyan'
    Write-Line '   JlWBoT 已启动' 'Green'
    Write-Line ''
    Write-Line ('   后台地址   ' + $base) 'White'
    Write-Line ('   监听地址   ' + $serverHost) 'DarkGray'
    if ($serverHost -eq '127.0.0.1') {
      Write-Line '   云服务器提示 仅本机可访问；请把 server.host 改为 0.0.0.0 并在安全组放行端口，或用 SSH 隧道。' 'Yellow'
    } else {
      Write-Line '   云服务器提示 请用公网 IP / 域名访问，并确认安全组已放行该端口。' 'DarkGray'
    }
    Write-Line '   登录方式   聚龙世界账户（邮箱 + 密码）' 'White'
    if ($jlwBase) {
      Write-Line ('   账户站点   ' + $jlwBase) 'DarkGray'
    } else {
      Write-Line '   账户站点   未配置 —— 在登录页展开「站点设置」填写' 'Yellow'
    }
    Write-Line ('   数据目录   ' + $dataDir) 'DarkGray'
    Write-Line ('   崩溃记录   ' + (Join-Path $dataDir 'logs\crash.log')) 'DarkGray'
    Write-Line $bar 'DarkCyan'
    Write-Line ''
    Write-Line '  关闭本窗口会结束机器人；要后台常驻请用任务计划程序。' 'DarkGray'
    Write-Line ''
    if ($NoOpen) {
      Write-Line '  已跳过自动打开浏览器（-NoOpen）' 'DarkGray'
    } else {
      Write-Line '  正在打开后台页面…' 'Cyan'
      try { Start-Process $base } catch { Write-Line ('  打开浏览器失败：' + $_.Exception.Message) 'Yellow' }
    }
  }

  if ($Background) {
    Write-Line ('  已在后台运行（隐藏窗口），PID ' + $proc.Id) 'Green'
    Write-Line ('  停止方式：再运行一次 启动机器人.cmd（会结束旧实例），或 taskkill /PID ' + $proc.Id + ' /F') 'DarkGray'
    Write-Line ('  日志目录：' + (Join-Path $root '~JlWBoT\logs')) 'DarkGray'
    Write-Line '  注意：后台模式由系统托管，崩溃后不会自动重启；需要常驻请用任务计划程序。' 'Yellow'
    Write-Line ''
    exit 0
  }

  # ---------- 7. 保持前台，继续显示日志 ----------
  $proc.WaitForExit()
  $code = $proc.ExitCode
  # 被强杀（taskkill / 崩溃 / 断电）时 ExitCode 可能是 null，不能当成“正常退出 0”
  if ($null -eq $code) { $code = 1 }
  $sw.Stop()
  $ranSec = [math]::Round($sw.Elapsed.TotalSeconds, 1)
  # 「结束进程.cmd」会写 stop.flag：看到它就不要再自动重启
  if (Test-Path -LiteralPath $stopFlag) {
    Write-Line ''
    Write-Line '  检测到停止标记（结束进程.cmd），不再自动重启。' 'Yellow'
    exit 0
  }
  Write-Line ''
  Write-Line ('  服务已退出（退出码 ' + $code + '，已运行 ' + $ranSec + ' 秒）') 'Yellow'

  if ($code -eq 0) { exit 0 }
  if ($maxRestarts -le 0) {
    if (Test-Path -LiteralPath $crashLog) { Write-Line ('  崩溃/异常记录：' + $crashLog) 'DarkGray' }
    exit 1
  }
  if ($ranSec -lt 10) {
    $quickFails++
    if ($quickFails -ge 2) {
      Write-Line '  连续两次启动后很快就退出，可能是配置/端口问题，不再自动重启。' 'Red'
      if (Test-Path -LiteralPath $crashLog) { Write-Line ('  崩溃/异常记录：' + $crashLog) 'DarkGray' }
      exit 1
    }
  }
  if ($restarts -ge $maxRestarts) {
    Write-Line ('  已自动重启 ' + $restarts + ' 次仍异常退出，停止自动重启。') 'Red'
    if (Test-Path -LiteralPath $crashLog) { Write-Line ('  崩溃/异常记录：' + $crashLog) 'DarkGray' }
    exit 1
  }
  $restarts++
  Write-Line ('  异常退出，3 秒后自动重启（' + $restarts + '/' + $maxRestarts + '）…') 'Cyan'
  Start-Sleep -Seconds 3
}
