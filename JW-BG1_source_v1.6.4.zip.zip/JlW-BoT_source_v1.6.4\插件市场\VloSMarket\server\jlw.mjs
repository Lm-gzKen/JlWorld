// 聚龙世界账户接口（新版站点插件接口）
//   基地址：https://www.jlworld.net/api/plugin/jl-account/
//   调用方式：POST {base}{action}，JSON 请求体；返回 {ok:true,...} 或 {ok:false,error}
//   登录态：新接口用返回的 token（放请求体），本站只把它当作登录成功的凭证，不保存
//
// 用到的 action：login / register / send-code / reset-password
import https from 'node:https';

const DEFAULT_BASE = 'https://www.jlworld.net/api/plugin/jl-account/';

// 站点证书正常，保持默认校验即可
const agent = new https.Agent({ keepAlive: true });

function normalize(httpStatus, rawText) {
  const text = String(rawText || '').trim();
  let j = null;
  try {
    j = text ? JSON.parse(text) : null;
  } catch {
    return { ok: false, code: httpStatus || 500, msg: `聚龙账户接口返回了非 JSON 数据（HTTP ${httpStatus}）` };
  }
  if (j && j.ok !== false) {
    return { ok: true, code: 200, msg: j.message || j.msg || '成功', data: j };
  }
  const msg = (j && (j.error || j.message || j.msg)) || `请求失败（HTTP ${httpStatus}）`;
  return { ok: false, code: httpStatus || 400, msg, data: j };
}

export function createJlw(cfg) {
  const base = (String(cfg.vlosBase || DEFAULT_BASE).replace(/\/+$/, '') || DEFAULT_BASE.replace(/\/+$/, '')) + '/';

  function request(action, body, timeoutMs = 25000) {
    return new Promise((resolve) => {
      let target;
      try {
        target = new URL(base + action);
      } catch {
        resolve({ ok: false, code: 0, msg: '聚龙账户接口地址配置不正确：' + base });
        return;
      }
      const payload = JSON.stringify(body || {});
      const req = https.request(
        {
          hostname: target.hostname,
          port: target.port || 443,
          path: target.pathname + target.search,
          method: 'POST',
          agent,
          timeout: timeoutMs,
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Content-Length': Buffer.byteLength(payload),
            'User-Agent': 'JlW-BoT-Market/2.2',
          },
        },
        (res) => {
          let buf = '';
          res.setEncoding('utf8');
          res.on('data', (c) => (buf += c));
          res.on('end', () => resolve(normalize(res.statusCode, buf)));
        }
      );

      req.on('timeout', () => {
        req.destroy();
        resolve({ ok: false, code: 0, msg: '连接聚龙账户接口超时，请稍后重试' });
      });
      req.on('error', (err) => {
        const code = (err && err.code) || '';
        const raw = (err && err.message) || String(err);
        let msg;
        if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') msg = '无法解析聚龙世界域名，请检查服务器网络';
        else if (code === 'ECONNREFUSED') msg = '聚龙世界网站拒绝连接';
        else if (code === 'ETIMEDOUT') msg = '连接聚龙账户接口超时，请稍后重试';
        else msg = `无法连接聚龙账户接口：${raw}`;
        resolve({ ok: false, code: 0, msg });
      });

      req.write(payload);
      req.end();
    });
  }

  return {
    // 邮箱 + 密码登录
    login: (email, password) => request('login', { email, password, website: '' }),
    // 发邮箱验证码：purpose = register | reset
    sendCode: (email, purpose) => request('send-code', { email, purpose: purpose || 'register', website: '' }),
    // 注册（需要邮箱验证码 + 昵称）
    register: (email, code, password, name) => request('register', { email, code, password, name, website: '' }),
    // 忘记密码 / 重置密码
    resetPassword: (email, code, password) => request('reset-password', { email, code, password, website: '' }),
    // 用 token 查当前账户（备用）
    me: (token) => request('me', { token }),
    raw: request,
  };
}
