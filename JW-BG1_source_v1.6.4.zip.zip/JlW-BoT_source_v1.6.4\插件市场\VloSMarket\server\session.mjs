// 会话：登录成功后由本站自己签发 token（HttpOnly Cookie），不依赖聚龙侧会话。
import { newToken, parseCookies, setCookie, clearCookie } from './http.mjs';

export const COOKIE = 'vlos_sid';

export function createSession(store, email, req, cfg, ip) {
  const now = Date.now();
  const token = newToken();
  const days = Number(cfg.sessionDays) || 30;
  const expires = now + days * 86400000;
  store.run(
    'INSERT INTO sessions (token, email, created, expires, ip, ua) VALUES (?,?,?,?,?,?)',
    token,
    email,
    now,
    expires,
    ip || '',
    String(req.headers['user-agent'] || '').slice(0, 300)
  );
  return { token, expires };
}

export function readSession(store, req, cfg) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return null;
  const row = store.get('SELECT * FROM sessions WHERE token = ?', token);
  if (!row) return null;
  const now = Date.now();
  if (row.expires < now) {
    store.run('DELETE FROM sessions WHERE token = ?', token);
    return null;
  }
  // 滑动续期：剩余不足一半就把到期时间往后推，常来的用户不会被踢下线。
  // 必须同时在同一个响应里续 Cookie（renewCookie），否则浏览器那边的
  // Max-Age 到了照样会把 Cookie 丢掉。
  const days = Number(cfg && cfg.sessionDays) || 30;
  const full = days * 86400000;
  if (row.expires - now < full / 2) {
    row.expires = now + full;
    row.renewed = true;
    store.run('UPDATE sessions SET expires = ? WHERE token = ?', row.expires, token);
  }
  return row;
}

/** 会话被滑动续期后，把浏览器里的 Cookie 到期时间一起延长 */
export function renewCookie(res, session, cfg) {
  if (!session || !session.renewed) return false;
  attachCookie(res, session.token, session.expires, !!(cfg && cfg.cookieSecure));
  return true;
}

export function attachCookie(res, token, expires, secure) {
  setCookie(res, COOKIE, token, {
    maxAge: Math.max(0, Math.floor((expires - Date.now()) / 1000)),
    httpOnly: true,
    sameSite: 'Lax',
    secure: !!secure,
  });
}

export function dropCookie(res) {
  clearCookie(res, COOKIE);
}

export function purgeExpired(store) {
  return store.run('DELETE FROM sessions WHERE expires < ?', Date.now()).changes;
}
