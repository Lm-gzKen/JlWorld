// 配置加载：config.json（默认值，可分享） ← config.local.json（本机敏感值，勿分享） ← 环境变量
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** 站点根目录（server/ 的上一级）。整个目录可原样拷走，路径全部相对它解析。 */
export const ROOT = path.resolve(fileURLToPath(new URL('..', import.meta.url)));

/** 单个 zip 包的硬上限（MB）。配置只能调小，调不大——防止有人上传几 G 的包。 */
export const MAX_UPLOAD_MB = 32;

const DEFAULTS = {
  siteName: 'JlW-BoT 插件市场',
  officialSite: 'https://www.jlworld.net',
  host: '127.0.0.1',
  port: 8300,
  publicUrl: '',

  // HTTPS 直连（可选）：填了证书就能让隧道直连本地 TLS 端口，不用 Nginx 反代。
  // SakuraFrp 的 HTTPS 隧道是 SNI 透传，本地必须自己会说 TLS。
  // httpsOnly=true：主端口(port) 直接说 HTTPS，不跑 HTTP（单端口，最省事）
  // httpsOnly=false：主端口继续 HTTP，另开 httpsPort（双端口，保留 http 入口）
  httpsOnly: false,
  httpsPort: 8443,
  certFile: '',
  keyFile: '',

  // 聚龙世界账户接口（2026-11 新版站点插件接口）
  vlosBase: 'https://www.jlworld.net/api/plugin/jl-account/',
  vlosKey: '',

  // 首页公告（Markdown）。也可以在数据库 settings 表里放 announcement 覆盖它。
  announcement: '',

  sessionDays: 30,
  maxUploadMB: 32,       // 单个 zip 包上限（硬上限，见 MAX_UPLOAD_MB）
  zipStageMin: 120,      // 上传包暂存时间（分钟），超时自动清理
  codeCooldownSec: 60,   // 同邮箱验证码冷却
  commentCooldownSec: 15,
  viewDedupeSec: 3600,
  trustProxy: false,
};

function readJson(file) {
  try {
    // 去掉 BOM：Windows 记事本 / PowerShell 写出来的 JSON 可能带 BOM，JSON.parse 会直接报错
    const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
    return JSON.parse(text);
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw new Error(`配置文件解析失败 ${file}：${err.message}`);
  }
}

export function loadConfig() {
  const base = readJson(path.join(ROOT, 'config.json')) || {};
  const local = readJson(path.join(ROOT, 'config.local.json')) || {};
  const cfg = { ...DEFAULTS, ...base, ...local };

  // 兼容老配置：升级包不覆盖 config.json，老版本默认站名 / 老账户接口地址在这里自动换成新的
  if (/VloSBoT/i.test(String(cfg.siteName || ''))) cfg.siteName = String(cfg.siteName).replace(/VloSBoT/gi, 'JlW-BoT');
  if (!cfg.vlosBase || /frp-ice\.com:14780/i.test(String(cfg.vlosBase))) cfg.vlosBase = DEFAULTS.vlosBase;

  // 环境变量优先级最高，便于云上部署时不落地明文
  if (process.env.VLOS_KEY) cfg.vlosKey = process.env.VLOS_KEY;
  if (process.env.VLOS_BASE) cfg.vlosBase = process.env.VLOS_BASE;
  if (process.env.PORT) cfg.port = Number(process.env.PORT);
  if (process.env.HOST) cfg.host = process.env.HOST;
  if (process.env.DATA_DIR) cfg.dataDir = process.env.DATA_DIR;
  if (process.env.HTTPS_PORT) cfg.httpsPort = Number(process.env.HTTPS_PORT);
  if (process.env.CERT_FILE) cfg.certFile = process.env.CERT_FILE;
  if (process.env.KEY_FILE) cfg.keyFile = process.env.KEY_FILE;
  if (process.env.OFFICIAL_SITE) cfg.officialSite = process.env.OFFICIAL_SITE;
  // 这两个一般只在自测时用（把冷却关掉才能连发多条）
  if (process.env.COMMENT_COOLDOWN_SEC !== undefined) cfg.commentCooldownSec = Number(process.env.COMMENT_COOLDOWN_SEC);
  if (process.env.CODE_COOLDOWN_SEC !== undefined) cfg.codeCooldownSec = Number(process.env.CODE_COOLDOWN_SEC);

  cfg.port = Number(cfg.port) || 8300;
  // 单个 zip 硬上限 32MB：就算老 config.json 里写着 200，也按 32 算，避免有人传几 G 的包
  cfg.maxUploadMB = Math.min(MAX_UPLOAD_MB, Math.max(1, Number(cfg.maxUploadMB) || MAX_UPLOAD_MB));
  cfg.dataDir = path.resolve(ROOT, cfg.dataDir || '.');
  cfg.publicDir = path.join(ROOT, 'public');
  cfg.officialSite = String(cfg.officialSite || DEFAULTS.officialSite).trim();

  return cfg;
}

/** 数据根下的标准子目录，启动时确保存在。 */
export function ensureDirs(cfg) {
  const dirs = {
    data: path.join(cfg.dataDir, 'data'),
    plugins: path.join(cfg.dataDir, 'plugins'),
    tmp: path.join(cfg.dataDir, 'tmp'),
    logs: path.join(cfg.dataDir, 'logs'),
  };
  for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });
  return dirs;
}
