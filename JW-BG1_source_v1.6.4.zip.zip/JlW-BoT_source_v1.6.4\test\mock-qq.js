'use strict';
/**
 * 假 QQ 服务器：模拟 access_token、网关 WebSocket、发消息接口（支持多账户）
 * 仅用于本地端到端测试，不连接腾讯
 */
const http = require('http');
const WsHub = require('../src/core/ws-server');

const fakeLogger = { child: () => ({ info() {}, warn() {}, error() {}, debug() {}, child() { return this; } }) };

class MockQQ {
  constructor({ port = 0, accounts } = {}) {
    this.port = port;
    this.accounts = accounts || { test_app: 'test_secret' };
    this.sent = [];
    this.calls = [];
    this.failOpenids = new Set();
    this.wsClients = new Map(); // appId -> client
    this.clients = new Set();
    this.events = [];
    this.identifies = {};
    this.identifyCounts = {};
    this.server = http.createServer((req, res) => this._http(req, res));
    this.hub = new WsHub({ server: this.server, logger: fakeLogger, path: '/websocket', auth: () => true });
    this.hub.onConnect((client) => {
      this.clients.add(client);
      client.socket.on('close', () => {
        this.clients.delete(client);
        for (const [appId, c] of this.wsClients) if (c === client) this.wsClients.delete(appId);
      });
      client.send({ op: 10, d: { heartbeat_interval: 2000 } });
    });
    this.hub.onMessage(({ client, msg }) => {
      if (msg?.op === 2) {
        const appId = this._appFromToken(msg.d?.token);
        // 模拟：包含私域全量消息 Intent 的机器人无权限，网关直接 4014
        if (msg.d && (msg.d.intents & (1 << 9)) !== 0) {
          client.close(4014);
          return;
        }
        this.identifies[appId] = msg.d;
        this.identifyCounts[appId] = (this.identifyCounts[appId] || 0) + 1;
        client.appId = appId;
        if (appId) this.wsClients.set(appId, client);
        client.send({
          op: 0,
          s: 1,
          t: 'READY',
          d: {
            version: 1,
            session_id: 'mock-session-' + appId + '-' + Date.now(),
            user: { id: '10000', username: 'MockBot-' + appId, bot: true },
            shard: [0, 1],
          },
        });
      } else if (msg?.op === 1) {
        client.send({ op: 11 });
      } else if (msg?.op === 6) {
        const appId = this._appFromToken(msg.d?.token);
        if (appId) {
          client.appId = appId;
          this.wsClients.set(appId, client);
        }
        this.resumed = true;
        client.send({ op: 0, s: 2, t: 'RESUMED', d: '' });
      }
    });
  }

  _appFromToken(token) {
    const m = /^QQBot\s+mock_token_(.+)$/.exec(String(token || ''));
    return m ? m[1] : null;
  }

  _appFromAuth(auth) {
    const m = /^QQBot\s+mock_token_(.+)$/.exec(String(auth || ''));
    return m ? m[1] : null;
  }

  async start() {
    await new Promise((r) => this.server.listen(this.port, '127.0.0.1', r));
    this.port = this.server.address().port;
    this.base = `http://127.0.0.1:${this.port}`;
    this.wsUrl = `ws://127.0.0.1:${this.port}/websocket`;
    return this;
  }

  async stop() {
    this.hub.close();
    await new Promise((r) => this.server.close(r));
  }

  _read(req) {
    return new Promise((resolve) => {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    });
  }

  async _http(req, res) {
    const url = new URL(req.url, 'http://x');
    const bodyText = await this._read(req);
    let body = {};
    try {
      body = bodyText ? JSON.parse(bodyText) : {};
    } catch {
      body = { raw: bodyText };
    }
    const json = (status, obj) => {
      const data = JSON.stringify(obj);
      res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) });
      res.end(data);
    };
    this.calls.push({ method: req.method, path: url.pathname, auth: req.headers.authorization, body });

    if (url.pathname === '/app/getAppAccessToken') {
      const expect = this.accounts[body.appId];
      if (!expect || expect !== body.clientSecret) return json(200, { code: 100016, message: 'invalid appid or secret' });
      return json(200, { access_token: 'mock_token_' + body.appId, expires_in: '7200' });
    }
    if (url.pathname === '/gateway') return json(200, { url: this.wsUrl });
    if (url.pathname === '/gateway/bot') {
      return json(200, { url: this.wsUrl, shards: 1, session_start_limit: { total: 1000, remaining: 1000, reset_after: 86400000, max_concurrency: 1 } });
    }
    if (url.pathname === '/users/@me') {
      const appId = this._appFromAuth(req.headers.authorization) || 'unknown';
      return json(200, { id: '10000', username: 'MockBot-' + appId, bot: true, avatar: 'http://thirdqq.qlogo.cn/mock-avatar.png' });
    }
    if (req.method === 'GET' && /^\/v2\/groups\/[^/]+\/info$/.test(url.pathname)) {
      const gid = url.pathname.split('/')[3];
      return json(200, {
        group_openid: gid,
        group_name: '测试群',
        group_avatar: 'http://thirdqq.qlogo.cn/g?b=qq&s=100&nk=' + encodeURIComponent(gid),
        group_member_num: 8,
      });
    }
    if (req.method === 'GET' && /^\/v2\/groups\/[^/]+\/bot_state$/.test(url.pathname)) {
      return json(200, {
        member_openid: 'BOT_MOCK',
        member_role: 'admin',
        recv_msg_setting: 'all',
        allow_proactive_msg: false,
        joined_at: '2026-01-01T00:00:00+08:00',
      });
    }
    if (req.method === 'GET' && /^\/v2\/users\/[^/]+\/info$/.test(url.pathname)) {
      const uid = url.pathname.split('/')[3];
      return json(200, {
        user_openid: uid,
        username: '模拟用户-' + uid.slice(-4),
        avatar: 'http://thirdqq.qlogo.cn/g?b=qq&s=100&nk=' + encodeURIComponent(uid),
        union_openid: 'UNION_' + uid,
      });
    }
    if (req.method === 'POST' && /\/messages$/.test(url.pathname)) {
      const appId = this._appFromAuth(req.headers.authorization);
      if (!appId || !this.accounts[appId]) return json(401, { code: 11244, message: 'token invalid' });
      const target = url.pathname.split('/')[3] || '';
      if (this.failOpenids && this.failOpenids.has(target)) {
        return json(400, { code: 40054, message: 'openid 无效或已失效（mock）' });
      }
      const id = 'MSG_' + (this.sent.length + 1);
      this.sent.push({ appId, path: url.pathname, body, at: Date.now() });
      return json(200, { id, timestamp: new Date().toISOString(), ext_info: { ref_idx: 'REFIDX_' + id } });
    }
    if (req.method === 'DELETE' && /\/messages\//.test(url.pathname)) return json(200, {});
    return json(404, { code: 404, message: 'mock not found: ' + url.pathname });
  }

  /** 向指定账户的网关推送事件；不传 appId 则广播 */
  push(t, d, { appId, seq = Date.now() } = {}) {
    const evt = { op: 0, s: seq, t, id: 'EVT_' + appId + '_' + seq, d };
    if (appId) {
      const client = this.wsClients.get(appId);
      if (client) client.send(evt);
    } else {
      for (const c of this.clients) c.send(evt);
    }
    this.events.push({ appId: appId || '*', evt });
    return evt;
  }

  pushGroupMessage({ appId, group = 'G_MOCK', content = '/ping', user = 'U_MOCK' } = {}) {
    return this.push(
      'GROUP_AT_MESSAGE_CREATE',
      {
        id: 'MSG_IN_' + Date.now(),
        content,
        group_openid: group,
        author: { id: user, member_openid: user, username: '模拟用户', member_role: 'member' },
        timestamp: new Date().toISOString(),
        message_type: 0,
      },
      { appId },
    );
  }
}

module.exports = MockQQ;

if (require.main === module) {
  (async () => {
    const port = Number(process.argv[2]) || 19100;
    const mock = await new MockQQ({ port }).start();
    console.log('MockQQ listening', mock.base, 'ws', mock.wsUrl);
    console.log('appId=test_app clientSecret=test_secret');
    setInterval(() => {}, 1 << 30);
  })();
}
