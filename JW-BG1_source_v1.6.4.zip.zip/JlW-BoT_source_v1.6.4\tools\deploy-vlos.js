#!/usr/bin/env node
'use strict';
/**
 * 把 plugins/VloS 的代码文件部署到 ~JlWBoT/plugins/VloS 并让面板热重载。
 *
 * 只复制代码 / 页面 / 说明文件，绝不动运行目录的 plugin.json
 * （那是线上配置：聚龙 Key、groups 群覆盖、callbackReviews、欢迎语）。
 *
 * 用法：
 *   node tools/deploy-vlos.js            # 复制 + 重载
 *   node tools/deploy-vlos.js --dry      # 只打印将复制的文件
 *   node tools/deploy-vlos.js --no-reload
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const http = require('node:http');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'plugins', 'VloS');
const RUNTIME_ROOT = path.join(ROOT, '~JlWBoT');
const DST = path.join(RUNTIME_ROOT, 'plugins', 'VloS');
const PANEL_PORT = Number(process.env.JLW_PANEL_PORT || 8686);

// 注意：不含 plugin.json（线上配置）
const FILES = ['index.js', 'settings.html', 'api.js', 'api.html', 'package.json', 'README.md', 'lib/defaults.js', 'lib/jlaccount.js', 'lib/store.js', 'lib/text.js', 'data/每日诗词.txt'];

const dry = process.argv.includes('--dry');
const noReload = process.argv.includes('--no-reload');

if (!fs.existsSync(DST)) {
  console.error(`找不到运行目录：${DST}`);
  process.exit(1);
}

for (const rel of FILES) {
  const s = path.join(SRC, rel);
  if (!fs.existsSync(s)) {
    console.warn('跳过（源码缺失）', rel);
    continue;
  }
  const d = path.join(DST, rel);
  if (dry) {
    console.log('would copy', rel, fs.statSync(s).size);
    continue;
  }
  fs.mkdirSync(path.dirname(d), { recursive: true });
  fs.copyFileSync(s, d);
  console.log('copied', rel, fs.statSync(d).size);
}

// 只把版本号写进线上 plugin.json，配置（Key / 群覆盖 / 审核记录）原样保留
const liveManifest = path.join(DST, 'plugin.json');
const version = JSON.parse(fs.readFileSync(path.join(SRC, 'package.json'), 'utf8')).version;
try {
  const manifest = JSON.parse(fs.readFileSync(liveManifest, 'utf8'));
  if (manifest.version !== version) {
    manifest.version = version;
    fs.writeFileSync(liveManifest, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
    console.log('patched plugin.json version ->', version);
  }
} catch (e) {
  console.warn('plugin.json 版本同步跳过：' + e.message);
}

if (dry || noReload) process.exit(0);

/**
 * 面板登录态：旧版框架在 data/sessions.json，1.5+ 改成 data/jlwbot.db 的 sessions 表。
 * 返回 { sid }，找不到返回空。
 */
function panelSession() {
  const sessionsFile = path.join(RUNTIME_ROOT, 'data', 'sessions.json');
  if (fs.existsSync(sessionsFile)) {
    try {
      const obj = JSON.parse(fs.readFileSync(sessionsFile, 'utf8'));
      const sid = Object.keys(obj).find((k) => obj[k] && (!obj[k].expiresAt || obj[k].expiresAt > Date.now()));
      if (sid) return { sid };
    } catch {
      /* 试数据库 */
    }
  }
  const dbFile = path.join(RUNTIME_ROOT, 'jlwbot.db');
  if (fs.existsSync(dbFile)) {
    try {
      const { DatabaseSync } = require('node:sqlite');
      const db = new DatabaseSync(dbFile, { readOnly: true });
      try {
        const row = db
          .prepare('SELECT sid FROM sessions WHERE expires > ? ORDER BY created DESC LIMIT 1')
          .get(Date.now());
        if (row && row.sid) return { sid: String(row.sid) };
      } finally {
        db.close();
      }
    } catch {
      /* ignore */
    }
  }
  return null;
}

const session = panelSession();
if (!session) {
  console.error('没有面板登录态（data/sessions.json 或 jlwbot.db sessions 表），请到面板手动点「重载」');
  process.exit(0);
}

const req = http.request(
  {
    host: '127.0.0.1',
    port: PANEL_PORT,
    path: '/api/plugins/VloS/reload',
    method: 'POST',
    headers: {
      Cookie: 'jlw_sid=' + session.sid,
      'x-jlw-session': session.sid,
      'Content-Length': 0,
    },
  },
  (res) => {
    let body = '';
    res.on('data', (c) => (body += c));
    res.on('end', () => {
      let v = null;
      try {
        v = (JSON.parse(body).plugins || []).find((p) => p.id === 'VloS');
      } catch {
        /* ignore */
      }
      console.log('reload', res.statusCode, v ? `VloS ${v.version} ${v.status}` : body.slice(0, 300));
    });
  },
);
req.on('error', (e) => console.error('reload 失败（面板没开？）：' + e.message));
req.end();
