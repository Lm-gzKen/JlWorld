# BBSP - build the DLL call host (x86 + x64)
#
# Uses the .NET Framework csc.exe that ships with Windows (no Visual Studio, no native npm deps).
# The 32-bit host loads 32-bit DLLs (EasyLanguage / EPL DLLs are usually 32-bit),
# the 64-bit host loads 64-bit DLLs.
#
# Usage: pwsh -NoProfile -File tools\dllhost\build-dllhost.ps1
#        powershell -NoProfile -ExecutionPolicy Bypass -File tools\dllhost\build-dllhost.ps1
#
# NOTE: keep this file ASCII-only: Windows PowerShell 5.1 reads .ps1 as ANSI.

param(
  [string]$OutDir = ''
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here '..\..') | Select-Object -ExpandProperty Path
if (-not $OutDir) { $OutDir = Join-Path $root 'bin' }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$src = Join-Path $here 'Program.cs'
if (-not (Test-Path $src)) { throw "Source not found: $src" }

$csc86 = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
$csc64 = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'

$jobs = @(
  @{ Name = 'bbsp-dllhost-x86.exe'; Csc = $csc86; Platform = 'x86' },
  @{ Name = 'bbsp-dllhost-x64.exe'; Csc = $csc64; Platform = 'x64' }
)

foreach ($j in $jobs) {
  if (-not (Test-Path $j.Csc)) { throw "csc.exe not found: $($j.Csc) (.NET Framework 4.x required)" }
  $out = Join-Path $OutDir $j.Name
  Write-Host "Building $($j.Name) ..." -ForegroundColor Cyan
  & $j.Csc /nologo /target:exe /platform:$($j.Platform) /optimize+ /r:System.Web.Extensions.dll /out:$out $src
  if ($LASTEXITCODE -ne 0) { throw "Build failed: $($j.Name) (exit $LASTEXITCODE)" }
  $size = (Get-Item $out).Length
  Write-Host ("  -> {0}  ({1:N0} bytes)" -f $out, $size) -ForegroundColor Green
}

Write-Host 'Done: bin\bbsp-dllhost-x86.exe / bin\bbsp-dllhost-x64.exe' -ForegroundColor Green
