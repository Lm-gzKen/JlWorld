# JlWBoT

> **QQ 官方机器人框架** —— 多账户 · WebSocket / WebHook 双接入 · QQ API v2 · Web 控制台 · 易语言 DLL 插件
>
> 当前版本：**v1.6.4** · 运行环境：**Node.js 18.17+**（导出包内置 Windows x64 `runtime\node.exe` v24.16.0）
> 设计原则：**零 npm 依赖**（只用 Node 内置模块）、**数据自包含**（全部在 `~JlWBoT`）、**可整目录拷走/脱机运行**
>
> 本 README 同时作为**跨会话交接文档**：下一个会话先读第 0 节，再按需跳到对应章节。

---

## 0. 跨会话交接卡（先读这里）

### 0.1 项目身份

| 项 | 值 |
| --- | --- |
| 项目名 | JlWBoT（聚龙世界 QQ 官方机器人框架） |
| 版本 | `1.6.4`（`package.json`） |
| 语言/运行时 | Node.js CommonJS；**无第三方依赖，不需要 `npm install`** |
| 主入口 | `src/index.js` |
| 默认面板 | `http://127.0.0.1:8686` |
| 默认数据目录 | `<项目根>\~JlWBoT`（`~` 是文件夹名的一部分） |
| 控制台登录 | 聚龙世界账户（邮箱 + 密码），**没有面板访问令牌** |
| 在线更新源 | <https://www.jlworld.net/QQBOT> |
| 当前导出目录 | `框架导出\` |
| 导出脚本 | `tools/export-framework.ps1` |
| 插件开发文档 | [docs/插件开发.md](docs/插件开发.md) |
| 部署文档 | [docs/部署与脱机运行.md](docs/部署与脱机运行.md) |

### 0.2 60 秒常用命令

```powershell
# 启动（Windows，自动结束旧实例、打开浏览器）
.\启动机器人.cmd

# 只启动、不打开浏览器
.\启动机器人.cmd -NoOpen

# 结束进程：启动器 + 主进程 + 插件子进程一起结束，写停止标记并清锁
.\结束进程.cmd

# 直接运行（可指定端口/监听地址/数据目录）
node src/index.js
node src/index.js --port 9000 --host 0.0.0.0 --data-dir D:\JlWBoT-data
node src/index.js --allow-email you@example.com
node src/index.js -v

# 全量回归（核心 + 网关 + 站点自愈 + 在线更新；不需要 npm）
node test/run-all.js

# 只跑核心自测 / 网关端到端
node test/selftest.js
node test/gateway-e2e.js

# 构建可发布的框架 zip（成品包；顶层目录固定 JlW-BoT；加 -Full 带测试与截图）
powershell -NoProfile -ExecutionPolicy Bypass -File tools\export-framework.ps1

# 只把本机 node.exe 复制进 runtime\（离线运行）
powershell -ExecutionPolicy Bypass -File tools\打包离线版.ps1

# 查看导出包哈希
Get-FileHash "框架导出\JlW-BoT [v1.6.4].zip" -Algorithm SHA256
```

### 0.3 当前工作区快照（整理时间：2026-11-23）

> 这一节是**本机当前状态**，不是发布包的固定内容；换机器/换数据目录后以实际为准。

| 项 | 当前值 |
| --- | --- |
| 工作区根 | `C:\Users\gzken\Desktop\聚龙世界\QQ机器人\DSH机器人` |
| 源码版本 | **v1.6.4** |
| 正在运行的面板 | **运行中**：`http://127.0.0.1:8686`（2026-11-22 18:22 启动，PID 见 `/health`）；`Texas`（1905380567）已 `online`（IP 白名单加入本机 `120.230.80.80` 后恢复）；`VloS`（102818267）仍 `invalid appid or secret`（100016，等重置 AppSecret）；**群里实际在跑的是云端 `D:\QQbot\JlW-BoT`** |
| 常驻方式 | agent 从 DSH 会话启动的 node 进程会随任务/会话结束被清理；长期运行请手动双击 `启动机器人.cmd` 或配置任务计划程序 |
| 本机数据目录 | `<工作区>\~JlWBoT` |
| 数据目录账户 | `Texas`（停用）· `VloS`（启用） |
| 数据目录插件 | `Arknights` · `huixiang` · `mcstatus` · `VloS` · `xinghuo`（星火 v1.5.0；目录已覆盖，面板重载后生效；源码在 `plugins/xinghuo`） · `VSQL`（内置 SQLite 服务 v1.0.0） · `weather`（天气查询 v1.0.0，源码 `plugins/weather`，面板重载后生效） |
| VSQL 插件 | **1.0.3**（源码 `plugins/VSQL`，运行副本 `~JlWBoT/plugins/VSQL`）：内置 SQLite 数据库服务，默认 shared 库跨插件共享表，`db('私有ns')` 可隔离；建表/改名/加列/删列全开放（表名支持中文）；设置页可浏览所有表与表内数据（敏感列打码、可过滤、可刷新），并显示从盘符开始的完整数据目录；自测 **46 项**（`node test/vsql-test.js`） |
| VloS 版本 | **2.9.62**（新增模板数字变量 `{pending_longjing}` / `{pending_xuanyu}`，自定义 /list 卡片可正确显示 VloS余额；82 单测 / 7 诗词 / 29 联调） |
| VloS 导出包 | `插件\VloS-【v2.9.62】.zip`（根目录 `plugin.json`，可直接导入；空 Key / 无用户数据；**只用于新装，不要解压覆盖已有插件**） |
| 星火插件 | **v1.7.3**（源码 `plugins/xinghuo`，交付 `插件\星火-【v1.7.3】.zip`）：好友/群 OpenID 收集 + zip 导入 + qlogo 头像/名称补全、【好友】【群聊】列表与全选、公告编辑/记录、腾讯 Markdown 蓝字与 5×5 消息按钮、用户库唯一发送入口（两次确认 + 实时进度）、失败好友自动标无效且私聊恢复、【全部/有效/无效/删除】筛选、机器人昵称账户列、群名首字群头像兜底、固定兑换码（总数 0=无限、每人限一次开关、同用户默认一次、VloS 到账前后校验）、只写 VloS 余额；存储交给 **VSQL shared 库**（`xinghuo_` 表，跨插件可读，旧 JSON/SQLite 自动迁移；**前置插件 VSQL，缺失会报错并临时回退 JSON**），自测 **162 单测 + 21 端到端** |
| 天气查询插件 | **v1.3.2**（源码 `plugins/weather`，运行副本 `~JlWBoT/plugins/weather`，交付 `插件\天气查询-【v1.3.2】.zip`，ID `weather`）：**回复统一是图片**（PowerShell + GDI+ → 富媒体上传 → `msg_type=7`，失败退纯文本）；群聊只开 `/天气 城市`，群聊 `/天气` 弹**可编辑菜单**；私聊 `/天气 订阅 城市`、`/天气 时间 0800`、`/天气 取消订阅`、`/天气` 看状态；推送走**主动消息**（不带 msg_id，需主动消息权限）；**每分钟整点调度**，只看「推送时间 == 当前分钟」的订阅，有就推、没有就跳过，**人数无上限**（并发 4 路）、**不补推、发送失败不重试**；城市到区县（离线 34 省/375 市/2846 区县 + Photon 兜底）；**存储 VSQL shared 库**（`weather_subs` / `weather_tasks`，旧 JSON 自动迁移）；设置页三栏「设置 / 订阅列表 / 回复信息」，文案与菜单全可改；自测 **180 单测 + 56 端到端 + 33 项交付包校验** |
| QQBOT 页面最新包 | `JlW-BoT [v1.3.4].zip`（整理时；本地已是 v1.6.4，页面版本更低所以不弹更新） |
| 导出包 | `框架导出\JlW-BoT [v1.6.4].zip`（约 33.3MB；SHA256 见 `Get-FileHash`） |
| 发布包顶层目录 | `JlW-BoT`（无版本号） |
| 登录范围 | 数据目录下次启动时从现有面板会话（SQLite `sessions` 表；旧版读 `sessions.json`）迁移；当前开发快照未手动添加 |
| 主回归结果 | 核心 **29/29** · 回复引用 **66/66** · 稳定性 **26/26** · 重启/日志 **33/33** · 重启端到端 **16/16** · 重连循环 **31/31** · 隔离 **16/16** · 单实例 **13/13** · 结束进程 **7/7** · 回复闸门 **18/18** · 历史日志/消息 **13/13** · 消息预览 **18/18** · 数据库迁移 **9/9** · 存储切换 **10/10** · 网关 **19/19** · 账户开关 **20/20** · 站点自愈 **8/8** · 登录范围 **10/10** · 插件更新 **12/12** · 市场代理 **49/49** · 更新 **14/14** · 更新接口 **5/5** |

### 0.4 当前限制 / 必知坑

1. **第一次升级必须手动**：v1.3.1 及更早版本没有在线更新器，必须手动换成 v1.6.4；v1.3.2 及以后已有更新器，页面出现更高版本后可一键升级（会从现有会话迁移登录范围）。
2. **页面版本要高于本机版本才会提示**：QQBOT 页面当前是 v1.3.4，低于本机 v1.6.4，所以不会弹更新按钮；页面上的 zip 内部版本还是 1.3.3，在线更新会因「版本不一致」拒绝安装，需要重新上传正确的包。
3. **`~JlWBoT` 是字面文件夹名**，不是用户主目录；脚本/命令里要加引号或反斜杠转义。
4. **不要提交/打包 `~JlWBoT`**：里面有 AppSecret、聚龙会话 token、插件 token、消息与日志。
5. **面板端口改动要重启**；其余配置保存后即时生效。
6. **WebHook 端口只能是 80 / 443 / 8080 / 8443**，且必须是 HTTPS；WebSocket 模式不需要公网入站。
7. **QQ 机器人 IP 白名单**：云服务器/家庭宽带公网 IP 变化会触发 `11298`，需要到每个 AppID 后台更新；框架会停止自动重连避免继续触发限频。
8. **32 位易语言 DLL 不能直接进 64 位 Node**，必须走 `pull` 拉取模式或 `dll` 宿主进程。
9. **PowerShell 脚本含中文时必须保存为 UTF-8 with BOM**（`tools/start-panel.ps1` 已带 BOM）；`.cmd` 保持 ASCII + CRLF。
10. **前端无构建**：直接改 `src/web/*`，刷新浏览器生效；不要引入 CDN/外部资源，保持离线可用。
11. **登录范围空/被锁死**：用 `node src/index.js --allow-email you@example.com` 补一个；或临时 `JLW_ALLOW_ALL_LOGIN=1` 登录后在左下角添加。
12. **登录范围按邮箱/ID 匹配**：后台添加只校验格式，不验证聚龙账户是否真实存在；输错邮箱会导致该账户无法登录，需再加正确邮箱。
13. **别在控制台窗口里拖选文字**：Windows 控制台的「快速编辑」会让进程在写 stdout 时卡住——表现就是「不回复、没日志、面板端口也打不开」，但进程其实没死（按 Esc 取消选中即可恢复）。`启动机器人.cmd` 现在会自动关掉快速编辑；日志文件 `~JlWBoT/logs/jlwbot-*.jsonl` 不受影响。
14. **崩溃不再无声**：未捕获异常/未处理的 Promise 拒绝会写进 `~JlWBoT/logs/crash.log` 并继续运行；每次启动还会检查 `~JlWBoT/logs/heartbeat.json`，上次没正常收尾会在日志里提示。
15. **面板端口会自愈**：HTTP 服务意外停止监听时看门狗会自动重新 listen（指数退避）；启动器在进程异常退出时自动重启（最多 3 次，`-NoRestart` 可关）。
16. **同一个数据目录只允许一个实例**（v1.4.1+）：启动时会检查 `~JlWBoT/run.pid`，已有进程在跑就拒绝启动并提示 PID；确认旧进程已死可加 `--force`。这条是为了避免两个网关同时收事件、重复回消息。
17. **关 CMD 窗口 = 结束前台进程**：默认模式下 node 挂在控制台上，关窗口会一起结束；只有 `-Background` 隐藏模式会脱离控制台继续跑。如果关了窗口还有消息，运行 `结束进程.cmd`（会连启动器和自动重启一起停掉）。
18. **插件报错只进框架日志**：未捕获异常/接口错误不会发到群聊或私聊（VloS、Arknights 均已按此处理），排查看面板「日志」或 `~JlWBoT/logs/`。
19. **干净插件包不要解压覆盖已有插件**：`插件\*-【v*.zip` 里的 `plugin.json` 是默认空配置（Key 空、`groups: {}`、`callbackReviews: {}`），解压到 `~JlWBoT/plugins/<插件>` 会覆盖运行配置，表现为「更新后群设置/待审核记录全没了」。升级只复制代码文件（`index.js`、`lib/`、`settings.html` 等），保留运行目录的 `plugin.json`；面板「导入」遇到同 ID 会直接拒绝。
20. **QQ 网关两类连不上**（面板/插件都正常，但一直 `reconnecting`/`fatal`，任何指令都不回）：
    - `invalid appid or secret`（code 100016）：AppID/AppSecret 被 QQ 拒绝，通常后台重置过 Secret。2026-11-22 实测 `VloS`（102818267）报这个 → 到 QQ 开放平台该机器人「开发设置」重置 AppSecret，再在面板左下角账户里改 Secret（即时生效，不用重启）。
    - `接口访问源IP不在白名单`（code 11298 / err_code 40023002）：该机器人开了 IP 白名单且当前公网 IP 不在里面。2026-11-22 实测本机公网 IP **120.230.80.80**、云端 **222.187.254.123**；`Texas`（1905380567）用新 Secret 能拿到 token（`expires_in=60` 正常），但调 `/users/@me`、`/gateway` 都是 `401 11298`；**19:38 把本机 IP 加进白名单后 `Texas` 恢复 `online`**。云端 bot 与本机不是同一出口 IP，两边要分别加。
21. **不要用 `Get-Content` / `Set-Content` 批量改中文文件**：本机默认 `powershell.exe` 是 5.1，`Get-Content -Raw` 会按 ANSI（936）解码 UTF-8 中文，再 `Set-Content -Encoding UTF8` 会写成「双重编码」乱码，并且换行可能被吞（2026-11-22 本 README 就是这样被写坏过一次，靠 `框架导出\JlW-BoT [v1.4.4].zip` 里的 `README.md` 恢复）。改中文文件优先用编辑工具的精确替换；非要用脚本就 `node` + `fs.readFileSync(p,'utf8')` / `writeFileSync(p, s, 'utf8')`，或 PowerShell 里显式 `[System.IO.File]::ReadAllText($p,[Text.Encoding]::UTF8)`。
22. **同一个群里有多个机器人时只让一个跑 VloS**：群成员里有 `VloS` 和 `Texas` 两个机器人，云端跑 VloS、本机跑 Texas，两个实例都会收事件、都回消息（重复回复 / 重复撤回）。要么停一个账户，要么在插件设置里用 `enabledAccountIds` 限定只让一个账户处理（值填账户 ID，如 `acciot33`）。撤回/禁言会由先到的实例执行，另一个会报「消息不存在」。
23. **QQ 电脑版（NT）不显示机器人撤回 / 不支持机器人 Markdown**：手机端能看到「管理员VloS撤回了一条成员消息」，电脑端原消息还在、也看不到撤回提示；机器人发的 Markdown 卡片在电脑端显示「[暂不支持该消息类型，请用手机QQ查看]」。这是 QQ 客户端限制，服务端撤回已经成功（否则手机端不会有系统提示），不要据此改插件。排查以手机端 + 插件日志 `VloS 接口 recall_group_message … 成功` 为准；电脑端可退出群聊重进 / 清缓存 / 换旧版或更新 QQ 再看。
24. **进退群事件收不到 / 退群发不出去**：① `GROUP_AND_C2C_EVENT` **不包含**成员进退群，必须在「连接」页额外勾选 **`GROUP_MEMBER_EVENT`（群成员事件，1<<24）**，否则插件连事件都收不到（日志不会出现 `VloS 收到群事件`）；② 退群事件 QQ 拒绝 `event_id` 被动回复（`40034027`），只能发群主动消息，需要开放平台开通「群主动消息」权限，否则 `40034105`；③ 进群欢迎可以走 `event_id`，一般不需要主动消息权限。
25. **QQ 没有「拉取全部好友 / 群列表」接口**：星火（以及任何插件）只能靠 `C2C_MESSAGE_CREATE` / `FRIEND_ADD` / `GROUP_ADD_ROBOT` 等事件收集，历史数据用导出包（CSV）导入；OpenID 按 AppID 隔离，多账户时记录里要带 `accountId` 才能用对账户发。
26. **插件设置页是 sandbox iframe**：`connect-src 'none'`，不能 `fetch` 面板接口，也不能读本地文件（文件选择 + File API 可以）。星火的做法是「插件把只读快照写进 `settings.html` 的 `xh-data` + 设置页把动作写进 `config.tasks`」；不要给设置页加 `fetch('/api/...')`，会直接被 CSP 拦掉，表现为按钮点了没反应。
27. **插件更新/删除前必须同步释放文件**：框架 `PluginManager.remove()` 只等子进程退出、不等 JS 的异步 `onUnload`，随后 `fs.rmSync` 最多重试 600ms；插件若还开着 SQLite/日志文件就会 `EPERM`，而回滚里 `rmSync` 抛错会跳过 `reloadAll()`，插件直接从注册表消失（面板「更新」连续报「插件不存在」）。VSQL 1.0.2 起 `onUnload` 先同步 `closeAll()` 再停 HTTP；以后写持有文件的插件请照此处理，必要时在 `onUnload` 里同步关流。

### 0.5 维护约定（给后续会话）

> 对话上下文会被压缩、截断或换会话，落盘的文件才是可靠记忆；**每次任务完成后先把结果同步到本 README，再回复用户**，不要只留在对话里。

1. 改完代码 / 跑完测试 / 导出完插件，立即更新对应章节（状态、版本、命令、踩坑）；这是每次任务的必做项。
2. 框架版本同步 `package.json`、`src/web/index.html` 与本 README；插件版本同步该插件的 `plugin.json` 与该插件 README。
3. 新接口、新协议、易错点写进对应章节。
4. 回复用户时注明「已更新 README」；没有更新就不算完成任务。
5. 不确定写哪里：至少更新「0.3 当前工作区快照」和「17 变更记录」各一条。

### 0.6 VloS 当前状态（v2.9.62）

- 源码：`plugins/VloS/`；运行副本：`~JlWBoT/plugins/VloS/`（**2.9.62 已部署并重载**，2026-11-24 14:45；云端 `D:\\QQbot\\JlW-BoT` 需同步 2.9.62）；完整功能见 [plugins/VloS/README.md](plugins/VloS/README.md)。
- 测试：`node test/vlos-test.js` 82 项、`node test/vlos-poems-test.js` 7 项、`node test/vlos-live.js` 29 项（联调需 8686 在跑）。
- 运行配置摘要：聚龙 Key 已配置（值不记录）；`sign.oncePerDay=false`、`wallet=true`、龙晶 10–100、玄玉 8% 1–3、方舟掉落开启；全局 `guard.enabled=true`、`action=recall_mute`；全局入群审批 `manual`；`welcome` 三类全开；1 个群覆盖（**已审核**；`guard.enabled=false` → 开关/词库/动作继承全局，`join.enabled=true`、`qa`）、管理员 OpenID 1 个、用户 2 个、`callbackReviews` 5 条。
- 群管覆盖生效规则：`groups[group_openid]` 只在 `reviewStatus === 'approved'` 时生效；`pending` / `rejected` 的本群设置**完全回落全局**，不会“半套生效”。审核通过时才写入 `reviewStatus='approved'`。
- 违禁词动作会**逐次记录 QQ 接口调用**：`VloS 接口 recall_group_message … 成功/失败（code/message）` + 汇总行 `违禁词命中 … · 已撤回 · 已禁言 N 秒`；撤回失败仍继续禁言（2.9.19+）。排查看第 0.7 节。
- 导出包只用于新装/导入：包内 `plugin.json` 是默认空配置，**解压覆盖运行目录会清掉 Key、已审核群、待审核申请**；升级只复制代码文件，保留运行目录 `plugin.json`（本次部署脚本就踩过：拷贝 `plugin.json` 把线上 Key/群覆盖覆盖成模板，已用 `~JlWBoT/backup/VloS-2.9.4-20261121-224427` 恢复）。
- 本机部署用 `node tools/deploy-vlos.js`（只复制代码 / 页面 / 说明并热重载，不碰运行目录 `plugin.json`，只同步其中的 `version` 字段，可加 `--dry` 预览）；云端更新走面板「插件 → VloS → 更新」导入 `插件\VloS-【v2.9.62】.zip`，框架会保留 `config`、替换清单（所以 `events` 里的 `INTERACTION_CREATE` 会一起更新）。
- 入群验证（2.9.33+）：答案以**回调按钮**挂在欢迎语下方，只允许进群的那名新成员点（`permission.type=0` + `specify_user_ids`），点后走 `INTERACTION_CREATE` 判定，不依赖群的全量消息权限；2.9.39 补齐「已通过」卡片编辑，2.9.40 修正按钮类型映射（0=跳转 / 1=回调 / 2=指令）；2.9.41 按钮被拒时改用蓝字「/入群验证 <答案>」兜底，2.9.42 问题前加「## 入群验证」标题、答错后重挂按钮；2.9.43 验证限时下拉（1–10 分钟，默认 5）；2.9.45 答错次数达到即踢、踢失败把原因回到群里；2.9.46 先发提示、等 3 秒再移出；2.9.47 限时到点也先提示再移出，欢迎语标注「> 限时 N 分钟」；2.9.48 超时文案改成「您未在规定时间内完成验证，将被移出群聊」；2.9.49 方舟校验改回调按钮、失败重挂按钮；2.9.50 群管只关闭功能 / 与全局一致时自动通过；2.9.51 与上次已通过的自定义一致也自动通过；2.9.52 在已通过版本上只关闭功能也自动通过（含待审核回溯）；2.9.53 全局基线比较忽略换行差异；2.9.54 自动通过按功能逐项比对两个基线；2.9.55 审核范围只看进退群 3 项；2.9.56 暂存余额改名 VloS余额并开放读取/增减 API；2.9.57 存储换成 VSQL SQLite；2.9.58 缺失前置会提示，迁移后删除 users.json；2.9.59 修复签到变量空白（前置提示不套模板）；2.9.60 修复开启每日重复签到后 `/签到` 把框架卡死（SQLite 缓存重排死循环，单核 100% / 面板无响应）；2.9.61 修复 VloS余额 被跨表写入后仍显示 0 / 被旧缓存覆盖；2.9.62 新增 {pending_longjing}/{pending_xuanyu} 模板变量。
- 入群验证踢人前提：机器人要有群成员管理权限。本机实测该测试群 `batch_remove_members` 返回 **`40103012 操作失败, 群主已经关闭操作权限`**，此时插件会在群里回「自动移出失败：群主关闭了机器人的成员管理权限…」，需要群主在群设置 → 群机器人 / 群管理里给机器人开权限。
- 入群验证（2.9.33+，2.9.39 补齐已通过卡片编辑）：本群覆盖里有 `welcome.joinVerify` 就优先用本群，没有才继承全局；**全局把入群验证关着不影响本群单独开启**（全局 `welcome.enabled=true` 时，本群覆盖的进群开关打开即生效）。配置不完整（问题为空或有效答案少于 2 个）时自动跳过验证并写日志，不会误判踢人。
- `/群管`：群里只提示「链接已私聊发送 / 没收到请加好友」；私聊按「群消息 `msg_id` 回复 → 主动 C2C → 群内提示加好友」降级；页面 10 分钟有效，未提交时复用原地址，已提交未审核时禁止重复提交。
- 管理员审核：提交后私聊 **24 小时**审核链接（群主提交页仍是 10 分钟）；通过写 `groups[group_openid]`、同步面板内存配置和 `plugin.json`；设置页「已通过」读取运行时 `groups` 快照，旧面板需 F5 才能用「刷新列表」。
- 入群问答：只看 `guard.join.enabled`，与 `guard.enabled` 无关；读 `verify_info.verify_message` / `review_qa_list[].answer`，命中关键词自动通过，带 `risk_tips` 不自动通过。
- 指令自定义回复：`commands.<key>.reply`（设置页「指令 → 备注右侧编辑」），点开即预填该指令默认回复并渲染，右上是「恢复默认」；左 Markdown 源码、右实时预览；`{content}` 引用默认回复，`/签到` `/list` `/菜单` `/vlos` 提供拆解变量，流程指令只套首次提示。与默认完全一致的保存会写回空值（继续跟随默认）。
- 进退群：`GROUP_MEMBER_ADD` / `GROUP_ADD_ROBOT` 用事件外层 id 作 `event_id` 走群消息被动回复（不带 `msg_id` / `msg_seq`）；`GROUP_MEMBER_REMOVE` 先试 `event_id`，退群专用接口未开放 / 失败时才降级主动消息。
- 敏感文件：`plugin.json`（Key）、`data/users.json`（token / 邮箱 / QQ）、`data/callbacks.json`、`~JlWBoT/config.json`（AppSecret）、`~JlWBoT/data/sessions.json`（sid）**不能外传**。

### 0.6.1 星火当前状态（v1.7.3）

- 源码：`plugins/xinghuo/`；交付包：`插件\星火-【v1.7.3】.zip`（根目录 `plugin.json`，无 `data/`，可直接导入/更新）；运行副本：`~JlWBoT/plugins/xinghuo/`。完整说明见 [plugins/xinghuo/README.md](plugins/xinghuo/README.md)。
- 功能：好友 / 群 OpenID 自动收集（C2C、FRIEND_ADD/DEL、GROUP_ADD/DEL_ROBOT、群消息）+ zip / CSV 导入；用户库分【好友】【群聊】，支持全选/单选、刷新选中；好友筛选【全部】【有效】【无效】【删除】，群聊筛选【有效】【无效】；好友 / 群补全进度和按钮分开，刷新选中按 `scope + ids` 限定不串类；好友头像 qlogo，名称 `get_user_info`，群名 `group_info`，群头像缺失时用群名首字生成图标；账户列显示 `/users/@me` 机器人昵称；公告页只编辑/保存/删除，**用户库顶部是唯一发送入口**（下拉选公告 → 两次确认 → 实时进度/用时/预计剩余/取消），公告支持腾讯 Markdown 蓝字与 5×5 消息按钮，失败好友自动标无效、再次私聊机器人恢复有效；兑换码后台一次生成一个固定码（可自定义，0 次=无限、同用户一次、用完失效），只写 VloS 余额。
- 存储：**前置插件 VSQL**；数据交给 VSQL 的默认 `shared` 库，表统一 `xinghuo_` 前缀（`xinghuo_friends` 等），其他插件可直接读；首次自动迁移旧 `data/xinghuo.json` 或旧版自带 `data/xinghuo.db`（取最新一份），旧文件保留；VSQL 未加载 / 打开失败会**报错并临时回退 JSON**，设置页「存储 · VSQL」显示原因；星火不再自己开 SQLite 文件。
- 设置页协议：`settings.html` 的 `xh-data` 只读快照 + `config.tasks` 任务队列 + `processedTasks` 幂等；用 `jlw-settings-review-refresh` 取新快照，不需要整页刷新。公告发送走框架自己的 `/plugin-api/v1/action`（`endpoint=send_c2c_message`），重载后 onLoad 没有事件上下文也能发。
- 自测：`node test/xinghuo-test.js` **162 项**；`node test/xinghuo-e2e.js` **21 项**（真 VSQL 插件 + shared 库跨插件读表 + 按钮 keyboard）。
- VloS 依赖：到账只需要 VloS 的 `addVlosBalance`，星火侧不需要任何发奖 Key；星火每次调用都重新 `get('VloS')`，VloS 单独重载不需要重启星火。
- 安装后如果面板没显示：点「重新加载」或重启一次框架（插件目录在启动时扫描）。

### 0.6.2 VSQL 当前状态（v1.0.3）

- 源码：`plugins/VSQL/`；运行副本：`~JlWBoT/plugins/VSQL/`；交付包：`插件\VSQL-【v1.0.3】.zip`（根目录 `plugin.json`，不含 `data/`）；完整说明见 [plugins/VSQL/README.md](plugins/VSQL/README.md)，接口文档见插件卡片「API」→ `api.html`。
- 定位：**只提供 SQLite 能力的数据库服务**，不预设任何业务表、不处理聊天消息（只订阅 `C2C_MESSAGE_CREATE` 跑 `/vsql` 管理指令）。底层 `node:sqlite`（零 npm 依赖），WAL + busy_timeout。
- **跨插件共享（默认）**：`vsql.db()` = 默认 `shared` 库，所有插件同一文件、表通用（A 建的表 B/C 直接 `SELECT`）；表名建议加插件前缀。私有数据用 `vsql.db('私有ns')`，其他插件可 `vsql.findTable('表名')` 找到后打开。
- **表结构全开放**：`createTable / renameTable / addColumn / renameColumn / dropColumn / tables / columns / indexes / schema / hasTable / dropTable / primaryKeys`；表名/列名支持中文、字母、数字、下划线、短横线。另含 `exec/run/get/all/value/column/prepare/tx/insert/insertMany/upsert/update/del/select/count/exists`、`migrate`、`kv`、`backup`、`vacuum/checkpoint/info`。
- **设置页数据浏览（1.0.2）**：页面最下方列出所有库的表，切换即可看前 N 行；支持本地过滤、敏感列（token/secret/password/sid/session…）打码、一键「刷新数据」（重载插件后自动刷新页面）。快照默认 8 库 × 15 表 × 10 行 / 200 KB，超出只列结构；内部表 `__vsql_*` 不展示。
- **群聊指令（1.0.3，默认关闭）**：`/vsql` 默认只在私聊响应；设置页打开「允许在群里使用」后，群里（建议 @机器人）也能用，仍只认 `admin.openids`，非管理员静默。群里发 `/vsql` 没反应是默认行为，不是坏了。

![VSQL 设置页数据浏览](plugins/VSQL/screenshot-data.png)

- **设置页完整路径（1.0.1）**：数据目录下方显示从盘符开始的绝对路径，随输入实时更新，带「复制」按钮。
- 约定：**不要缓存 VSQL 对象与 db 句柄**（重载会关闭全部句柄，旧句柄抛 `DB_CLOSED`）；方法全是同步的，批量写用 `db.tx()`，别在事件里扫大表。
- HTTP 网关（可选，默认开）：`127.0.0.1:8787`，`POST /query|/exec|/backup`、`GET /namespaces|/info|/health`；令牌在 `data/dbs/http-token.txt`，私聊 `/vsql token` 可看。
- 管理指令：私聊 `/vsql stats|list|tables <ns>|schema <ns>|sql <ns> <SQL>|backup [ns]|token`；`admin.openids` 为空时谁都不能用（首次发 `/vsql` 会把自己的 OpenID 回给本人），写 SQL 默认关闭。
- 自测：`node test/vsql-test.js` **48 项**（命名空间隔离与跨插件共享 / CRUD / where / 事务与嵌套保存点 / async 事务拒绝 / 预编译 / 命名参数 / 值归一化 / kv / 迁移幂等 / 结构查询 / ATTACH / 只读 / 关闭语义 / 备份 / LRU / 内存库 / 管理指令 / HTTP 网关 / 中文表名列名 / 建改删表 / findTable / 设置页路径与数据快照 / 卸载清理）；用 `test/.tmp-vsql/` 临时目录，不碰运行中数据。

### 0.7 事故复盘：违禁词不撤回 / 日志说成功但没动作（2026-11-22）

**现象**：群里发违禁词，机器人只禁言、消息没撤回；旧版本日志里甚至看不到任何 API 调用结果。

**三个叠加原因**：

1. **群覆盖把全局违禁词关掉了**（11-21 18:04 保存 /群管 设置后开始）：该群覆盖里 `guard.enabled=false`，2.9.12 及更早的 `effectiveGuard()` 用 `deepMerge(全局, 本群)`，本群的 `false` 直接把整个群的违禁词关掉，全局词库（含「蒋介石」）全部失效。修复：2.9.13 起「本群关闭违禁词 → 开关/词库/动作/禁言秒数继承全局」，2.9.16 起「只有 `reviewStatus=approved` 的群覆盖生效，pending/rejected 回落全局」。
2. **接口失败被当成成功**（最坑）：框架 `ctx.api.call()` 失败时**不抛异常**，而是返回 `{ ok:false, code, message }`。旧插件代码 `await ctx.api.call(...)` 之后没看返回值，所以 `recall_group_message` 返回 401/403 时既不报错也不写日志，最后还打印「已禁言」——看起来像执行了，实际只成功了一半。修复（2.9.19）：每次 QQ 接口调用都写日志（成功/失败 + code/message + 常见原因提示），撤回失败仍继续禁言，并在汇总行标出 `撤回失败(code=…)`。
3. **环境层：网关根本没连上**：`VloS`（102818267）的 AppSecret 失效（`invalid appid or secret` 100016）、`Texas`（1905380567）的本机公网 IP 不在白名单（`11298`）。这时候插件收不到任何群事件，日志里只有 token/重连。修复：QQ 开放平台重置 AppSecret；IP 白名单加入当前公网 IP（本机 `120.230.80.80`、云端 `222.187.254.123`，两边不是同一出口）。

**下次怎么快速定位（按顺序看）**：

1. 面板 `/health` + 账户状态：必须是 `online`；`reconnecting`/`fatal` 先修网关（看 `lastError`：100016=Secret、11298=IP 白名单）。
2. 面板日志搜 `VloS 违禁词命中`：有命中说明事件和词库都正常，继续看同一行的 `已撤回 / 撤回失败(code=…)`。
3. 搜 `VloS 接口 recall_group_message`：失败会写 `code=… message=…` 和排查提示（`40054005`=超过 2 分钟、`403/管理员`=机器人不是群管理员、`11298`=IP 白名单、`TOKEN_ERROR`=Secret 无效）。
4. 确认部署版本：日志里 `VloS 插件已加载 v2.9.19` 才算新代码；云端和本机要分别确认。
5. 群覆盖：设置页「审核 → 已通过」里该群存在且是 approved；覆盖里 `启用违禁词` 关掉也没关系（2.9.13+ 会继承全局）。

**约定**：以后插件里任何 `ctx.api.call()` 都必须走 `callQqApi()`（或至少判断 `res.ok !== false`），不允许「调用完就写成功日志」。

---

## 1. 项目概览

JlWBoT 是一个面向 QQ 官方机器人 API v2 的轻量框架，目标是把「多机器人账户 + 双接入方式 + 可视化管理 + 易语言插件」放在一个可拷贝的目录里。

### 1.1 功能一览

| 模块 | 说明 |
| --- | --- |
| 面板登录 | 聚龙世界账户（邮箱 + 密码）登录；支持注册、找回密码；会话 Cookie 持久化，密码不落盘 |
| 登录范围 | 只有「登录范围」列表里的聚龙账户能登录；首次运行在 CMD 添加第一个，后台左下角可继续增删；移出后旧会话失效 |
| 多账户 | 账户池：每个账户独立 AppID / AppSecret / access_token / 网关连接 / WebHook 路径 / 消息计数，可同时在线、独立启停与切换 |
| 接入方式 | WebSocket（identify / 心跳 / 断线重连 / Resume 补发 / 分片）与 WebHook（Ed25519 验签 / 回调地址验证 / op12 ACK）双模式，按账户独立配置 |
| 事件订阅 | Intents 中英双名、按「群聊 / 单聊」「频道」「互动」分组；无权限被网关 4014 时自动回退并提示 |
| QQ API | 67 个 API v2 接口（消息、富媒体、群管理、入群审批、菜单/面板、频道、互动），面板可视化调试，插件可编程调用 |
| 面板 | 概览 / 账户 / 消息 / 连接 / 接口 / 插件 / 日志 / 设置；实时日志与事件推送（自研 RFC6455 WebSocket 服务端） |
| 公网 IP | 右上角常驻显示本机公网 IP（服务端多源探测），点击复制；离线时降级显示“获取失败” |
| 插件 | JS（进程内）、HTTP（框架推送）、拉取（长轮询，易语言推荐）、进程（自动拉起 EXE）、DLL（自动拉起易语言 DLL 宿主）；支持创建 / 导入 / 更新 / 删除 / API 文档 / 设置页 |
| 易语言 | 纯文本 `key=value` 拉取格式 + 表单动作接口，不需要 JSON 解析；事件带 `account_id`，动作回 `accountId` 指定用哪个账户回复 |
| 数据 | 配置、日志、消息 JSONL、插件、登录会话全部在 `~JlWBoT/`；日志/消息按日轮转 |
| 插件市场 | 左侧【市场】内嵌 <https://vlos.jlworld.net/>，浏览/下载插件；面板同源反向代理去掉 X-Frame-Options，不暴露面板 Cookie，登录面板即自动登录市场 |
| 在线更新 | 面板左下角从 QQBOT 页面检查新版本，一键下载官方 zip、校验、解压覆盖并自动重启，保留 `~JlWBoT` |
| 运维 | 端口/监听地址可改、插件令牌可重置、账户增删、插件热重载、事件模拟、错误归一化、自测脚本、导出脚本 |

### 1.2 界面

(截图略)

| 登录 | 账户 |
| --- | --- |
| (截图略) | (截图略) |
| **消息** | **接口** |
| (截图略) | (截图略) |
| **插件** | **连接** |
| (截图略) | (截图略) |

---

## 2. 架构与请求链路

### 2.1 总体结构

```text
QQ 开放平台
  ├─ WebSocket 网关 ──┐
  └─ WebHook POST ────┤
                      ▼
              AccountHost（账户池）
                      │
               Bot（事件归一化/去重/
               命令解析/被动回复）
                      │
                      ▼
              PluginManager（五种插件）
                      │
        ┌─────────────┼──────────────┐
        ▼             ▼              ▼
   JS 进程内      HTTP / pull      process / dll
        │             │              │
        └─────────────┴──────┬───────┘
                             ▼
                    QQ API v2（按账户凭证）

浏览器面板 ◀── HTTP /api/* + /ws ──▶ PanelServer
聚龙账户   ◀── HTTPS /api/plugin/jl-account ──▶ JlwClient
QQBOT 页面 ◀── HTTPS 更新页 ──▶ Updater ──▶ update-apply.js
```

### 2.2 模块职责

| 文件 | 职责 |
| --- | --- |
| `src/index.js` | 参数解析、依赖装配、启动/优雅退出、启动横幅 |
| `src/core/config.js` | 默认配置合并、迁移、原子写、`publicConfig()` 打码、站点自愈 |
| `src/core/logger.js` | 控制台 + JSONL 日志、环形缓冲、面板订阅、敏感字段打码 |
| `src/core/util.js` | 路径/数据目录、JSON 读写（去 BOM）、原子写、JSONL、ID/时间工具 |
| `src/core/token.js` | 每账户 access_token 获取/缓存/到期前刷新 |
| `src/core/api.js` | QQ API HTTP 客户端：鉴权、重试、限流、错误分类（含 11298 致命判定） |
| `src/core/endpoints.js` | 67 个 QQ API v2 接口注册表（面板与插件共用） |
| `src/core/gateway.js` | WebSocket 网关：identify、心跳、resume、重连、限频退避、IP 白名单致命停止 |
| `src/core/webhook.js` | WebHook Ed25519 验签、回调地址验证、op12 ACK |
| `src/core/accounts.js` | 账户池生命周期、状态聚合、事件合并、按账户路由 |
| `src/core/bot.js` | 事件归一化、去重、命令解析、被动回复、`msg_seq`、插件动作执行 |
| `src/core/plugins.js` | 插件加载/分发/长轮询/进程守护/DLL 宿主/热重载/导入导出 |
| `src/core/session.js` | 面板登录会话（文件持久化、TTL） |
| `src/core/jlw.js` | 聚龙账户客户端：登录/me/logout/注册/找回密码/站点校验 |
| `src/core/netinfo.js` | 公网 IP 多源探测、缓存、离线降级 |
| `src/core/server.js` | HTTP 路由、鉴权、面板 API、插件桥、WebHook、静态文件、WebSocket 推送 |
| `src/core/ws-server.js` | 自研 RFC6455 WebSocket 服务端（面板实时推送） |
| `src/core/updater.js` | 更新页解析、版本比较、下载、启动独立更新器 |
| `src/core/update-apply.js` | 独立更新器：等旧进程退出、解压、校验、备份、覆盖、重启 |
| `src/web/*` | 原生 HTML/CSS/JS 面板（无构建、无 CDN） |

### 2.3 事件链路

1. 网关收到 `op=0` 事件，或 WebHook 收到平台 POST；
2. `Bot.handleEvent()` 归一化成 `{ id, name, time, message, account, raw }` 并去重；
3. `PluginManager.dispatch()` 按插件 `events` / `commands` 匹配、按 `priority` 排序；
4. 插件返回 `reply` / `replies` / `actions` / `stop`；
5. 框架用事件所属账户的凭证调用 QQ API 回复；外部插件在动作里回 `accountId`。

### 2.4 登录链路

1. 登录页 POST `/api/login`（邮箱、密码，可选 `baseUrl` / `insecureTls`）；
2. 服务端按 IP（10 次/分钟）和邮箱（5 次/10 分钟）限流；
3. `JlwClient.login()` 调 `{baseUrl}{apiPath}/login`；
4. 成功后创建 `SessionStore` 会话，下发 HttpOnly `jlw_sid` Cookie；
5. 浏览器带 Cookie 调 `/api/*`；服务端 `_sessionOf()` 校验。

### 2.5 在线更新链路

1. 面板登录后调 `/api/update/check`；
2. `Updater.check()` 抓取 QQBOT 页面，解析 `yz-dl-name` / `yz-dl-btn`（或 `jlwbot-*` meta），比较版本；
3. 用户点「下载并重启」→ `/api/update/start`；
4. 服务端下载到 `~JlWBoT/updates/`，校验 zip 魔数/大小/SHA（如果页面提供）；
5. 启动独立更新器，解码到临时目录并校验 `package.json` 与 `src/index.js`；
6. 更新器写 `apply-ready.json`；面板收到 `ok:true` 后才退出；
7. 更新器等旧 PID 退出，备份旧 `src` 等，覆盖框架文件，保留 `~JlWBoT`；
8. 用新 `runtime\node.exe` 以 `--no-open` 重启；浏览器轮询 `/health` 后自动刷新。

---

## 3. 快速开始

### 3.1 运行环境

- Windows 10 / 11 / Server 2016 及以上（64 位；内置 Node 24 不再支持 Windows 7；Node 18+ 官方也已停止支持 Win7）
- Node.js **18.17+**；当前导出包内置 `runtime\node.exe` **v24.16.0**
- 空载内存约 60MB；主要开销来自消息日志与插件
- WebSocket 模式只需**出站**访问 `api.bot.qq.com` / `api.sgroup.qq.com`
- WebHook 模式需要**公网 HTTPS 入站**

### 3.2 启动

Windows 双击 **`启动机器人.cmd`**：

1. 自动结束旧的 JlWBoT 实例（按 `src/index.js` 命令行与端口双重检测）；
2. 启动服务并等待 `/health` 就绪；
3. 控制台打印面板地址、登录方式、数据目录、账户/插件数量；
4. 自动打开浏览器，用聚龙世界账户登录。

```powershell
# 不打开浏览器
.\启动机器人.cmd -NoOpen

# 精简启动（不杀旧实例）
.\start.cmd

# 直接跑
node src/index.js
node src/index.js --port 9000
```

### 3.3 命令行参数

| 参数 | 说明 |
| --- | --- |
| `-p, --port <端口>` | 面板端口；会写回 `config.json` |
| `--host <地址>` | 监听地址；会写回 `config.json` |
| `--data-dir <目录>` | 数据目录；只设置 `JLW_DATA_DIR`，不写入配置 |
| `--no-open` | 不自动打开浏览器 |
| `-v, --version` | 打印版本号 |
| `-h, --help` | 帮助 |

### 3.4 登录面板

- 地址：`http://127.0.0.1:8686`（端口可在「设置」改）
- 账号：**聚龙世界账户**（邮箱 + 密码），不再需要面板访问令牌
- 登录页三个页签：
  - **登录**：邮箱 + 密码
  - **注册**：邮箱 → 获取验证码 → 设置密码 + 显示名称，注册成功直接进面板
  - **找回密码**：邮箱 → 获取验证码 → 设置新密码，重置成功直接进面板
- 聚龙账户站点默认 `https://www.jlworld.net`，接口 `/api/plugin/jl-account`；可在「设置 → 聚龙账户登录」改站点/跳过自签名证书。
- 登录会话保存在 SQLite（`~JlWBoT/jlwbot.db` 的 `sessions` 表）；Cookie `jlw_sid`，HttpOnly，有效期 `jlw.sessionDays`（默认 7 天）。

### 3.5 登录范围（首次运行）

登录范围是允许进入后台的聚龙账户白名单：

- 首次运行、`auth.allowed` 为空且没有旧会话可迁移时，`启动机器人.cmd` 会先运行 `tools/setup-login.js`，在 CMD 里要求输入第一个聚龙账户邮箱（输入两次确认）。
- 直接 `node src/index.js` 也会在控制台提示；没有交互式控制台时用：
  ```powershell
  node src/index.js --allow-email you@example.com
  ```
- 第一个账户添加后服务才启动；登录后台后，**左下角「登录范围」**可以继续添加/移除账户。
- 未加入列表的账户：即使密码正确也会返回 403「该聚龙账户不在登录范围」；注册/找回密码同样要求邮箱已在列表中。
- 至少保留一个账户；移除最后一个会被拒绝。被移除账户的旧会话在下一次请求时失效（HTTP API 返回 401）。
- 目前没有角色概念：**所有在登录范围内的账户都可以管理登录范围**（添加/移除其他人）。
- 升级时如果 `auth.allowed` 为空，会自动把现有面板会话（SQLite `sessions` 表，旧版则读 `data/sessions.json`）里的用户迁移进登录范围，避免升级后把自己锁在门外。
- 测试/应急可设 `JLW_ALLOW_ALL_LOGIN=1` 临时关闭限制（启动会打印警告，正式环境不要用）。

### 3.6 添加机器人账户

打开「账户」→「新建账户」：

1. 填账户名称、`AppID`、`AppSecret`；
2. 选择接入方式：
   - **WebSocket**：本地/内网可用，框架主动连网关，无需公网；
   - **WebHook**：需要公网 HTTPS，端口只能是 **80 / 443 / 8080 / 8443**；
3. 三个开关（v1.4.6+）：
   - **启用**（提示：启用机器人到池中）：账户总开关，也是唯一的总闸。关掉后整个账户处于禁用状态，卡片标「已停用」并变灰；此时「自动连接」「异常重连」也一起停用（灰色不可改）。
   - **自动连接**（默认开）：项目启动、重启（含定时重启）后自动连这个 bot；关掉后启动时不连，需要手动点「启动」。
   - **异常重连**（默认开）：掉线后自动重连并一直保持在线（重连用尽后进入冷却循环，不放弃）；关掉后掉线就停在「已断开」，手动点「重连」才恢复。改这个开关立即生效，不用重启账户。
   - **新建账户默认三项全开**，保存后立即进入账户池并连接。
4. 卡片上的「停用/启用」按钮：点「启用」= 一次把三项都打开（启用到池中）；点「停用」= 整账户禁用并断开。

需要几个机器人就加几个账户；它们会同时在线，右上角下拉可切换当前账户。

> 定时重启/手动重启后账户没连上时，看启动日志的「账户池加载完成」一行：会写明自动连接了几个、跳过了哪些账户以及原因（已停用 / 未开启自动连接）。

### 3.7 验证

- 面板「概览」显示账户「已连接」即成功；
- 群里 @ 机器人或私聊发送 `/ping`，内置 `echo` 插件回复 `pong`；
- 不接真 QQ 时，可点「概览」→「模拟一条群消息」走完整事件 → 插件 → 回复链路（回复会因未配置凭证失败，属正常）。

---

## 4. 目录结构

```text
JlW-BoT/
├─ 启动机器人.cmd                 一键启动：结束旧实例 → 启动 → 打印地址 → 打开面板
├─ start.cmd                      精简启动（不杀旧实例）
├─ config.default.json            默认配置（首次运行写入 SQLite，并生成 ~JlWBoT/config.json 镜像）
├─ package.json                   版本、npm scripts
├─ README.md                      本文件（项目总入口 / 跨会话交接）
├─ .gitignore                     排除 ~JlWBoT、runtime、临时文件
├─ src/
│  ├─ index.js                    入口：参数、装配、优雅退出
│  ├─ core/
│  │  ├─ config.js               配置合并/迁移/原子写/打码/站点自愈
│  │  ├─ db.js                   SQLite 存储（配置/会话/日志/消息 + 旧 JSON 迁移）
│  │  ├─ util.js                 路径、JSON、JSONL、ID/时间工具
│  │  ├─ logger.js               日志缓冲/写 SQLite/订阅/脱敏
│  │  ├─ token.js                access_token 获取/缓存/刷新
│  │  ├─ api.js                  QQ API HTTP 客户端
│  │  ├─ endpoints.js            67 个 QQ API v2 接口注册表
│  │  ├─ gateway.js              WebSocket 网关
│  │  ├─ webhook.js              WebHook Ed25519/ACK
│  │  ├─ accounts.js             账户池
│  │  ├─ bot.js                  事件归一化/命令/回复/动作
│  │  ├─ plugins.js              插件系统
│  │  ├─ session.js              面板会话（SQLite）
│  │  ├─ jlw.js                  聚龙账户客户端
│  │  ├─ login-scope.js           首次运行登录范围引导
│  │  ├─ netinfo.js              公网 IP 探测
│  │  ├─ server.js               HTTP 路由/API/静态/WebHook
│  │  ├─ ws-server.js            面板 WebSocket 服务端
│  │  ├─ updater.js              更新页解析/下载/启动更新器
│  │  ├─ update-apply.js         独立更新器（解压/备份/覆盖/重启）
│  │  └─ market-proxy.js         插件市场同源反向代理
│  └─ web/                       面板前端（原生 HTML/CSS/JS，无构建）
│     ├─ index.html
│     ├─ app.js
│     ├─ style.css
│     ├─ logo.png
│     ├─ favicon.svg
│     ├─ docs.html / docs.js / docs.css
│     └─ plugin-settings.html / .js / .css
├─ plugins/                       内置示例插件（首次启动复制到 ~JlWBoT/plugins）
│  ├─ echo/                       JS：/ping /echo /help
│  ├─ status/                     JS：/状态
│  ├─ el-sample/                  易语言拉取示例
│  ├─ dll-sample/                 易语言 DLL 宿主示例（默认关闭）
│  ├─ mcstatus/                   Minecraft 查询（v1.3.3）
│  ├─ Arknights/                  明日方舟工具（v1.5.0）
│  ├─ VloS/                       聚龙世界插件（v2.9.62）
│  ├─ VSQL/                       内置 SQLite 数据库服务（v1.0.0，给其他插件建表/读写）
│  └─ README.txt                  导出包中的占位说明
├─ docs/
│  ├─ API接口.md                  67 个 QQ API v2 接口清单 + 插件市场上传 API
│  ├─ 插件开发.md                 插件完整开发文档（含多语言示例）
│  ├─ 易语言对接.md               易语言拉取/DLL 宿主/排错
│  ├─ 部署与脱机运行.md           部署、端口、WebHook、自启、故障
│  └─ images/                     面板截图
├─ test/                          单元 + 端到端测试（假 QQ / 假聚龙账户）
│  ├─ run-all.js                  主回归跑批（不依赖 npm）
│  ├─ seed-plugins.js             测试插件夹具（导出包无示例插件时自动生成 echo/status/el-sample）
│  ├─ selftest.js / gateway-e2e.js
│  ├─ config-site-repair.js
│  ├─ auth-scope-test.js
│  ├─ plugin-update-test.js
│  ├─ market-proxy-test.js
│  ├─ update-test.js / update-api-test.js
│  ├─ mock-qq.js / mock-jlw.js
│  └─ vlos-*.js / huixiang-*.js / mcstatus-test.js
├─ tools/
│  ├─ start-panel.ps1             启动器（找 Node、杀旧实例、等就绪、开浏览器）
│  ├─ setup-login.js              首次运行登录范围设置（CMD 引导）
│  ├─ export-framework.ps1        构建发布 zip（顶层 JlW-BoT）
│  ├─ 打包离线版.ps1              只把 node.exe 复制到 runtime\
│  ├─ gen-api-doc.js              生成 docs/API接口.md
│  └─ el-backend-demo.js          易语言参考后端
├─ runtime/
│  └─ node.exe                    内置 Windows x64 Node（约 88MiB）
├─ ~JlWBoT/                       ★ 运行时数据（不随导出包发布）
└─ 框架导出/                      构建产物（不随导出包发布）
```

### 4.1 本机额外目录（不属于发布包）

| 目录 | 内容 |
| --- | --- |
| `~JlWBoT/` | 当前配置、日志、消息、会话、插件、备份 |
| `框架导出/` | `JlW-BoT [v1.3.0].zip`、`[v1.3.1]`、`[v1.3.2]`、`[v1.3.3]`、`[v1.3.4]`、`[v1.3.5]`、`[v1.3.6]`、`[v1.3.7]`、`[v1.3.8]`、`[v1.3.9]`、`[v1.4.0]`、`[v1.4.1]`、`[v1.4.2]`、`[v1.4.3]`、`[v1.4.4]`、`[v1.4.5]`、`[v1.4.6]`、`[v1.4.7]`、`[v1.4.8]`、`[v1.4.9]`、`[v1.4.10]`、`[v1.4.11]`、`[v1.4.12]`、`[v1.4.13]`、`[v1.4.14]`、`[v1.4.15]`、`[v1.4.16]`、`[v1.5.0]`、`[v1.5.1]`、`[v1.6.0]`、`[v1.6.1]`、`[v1.6.2]`、`[v1.6.3]`、`[v1.6.4]` 历史导出 |
| `插件/` | 已打包的插件 zip（Arknights、VloS、回响、我的世界查询） |
| `node-v26.13.1-win-x64.zip` | 本机 Node 便携包（构建时可删） |

---

## 5. 配置系统

### 5.1 配置位置与优先级

| 优先级 | 来源 | 说明 |
| --- | --- | --- |
| 1 | `--data-dir <目录>` | 设置 `process.env.JLW_DATA_DIR`，只影响本次进程 |
| 2 | 环境变量 `JLW_DATA_DIR` | 指定数据目录 |
| 3 | `<项目根>\~JlWBoT` | 默认数据目录 |

配置主存是 `<数据目录>\jlwbot.db` 的 `kv(config)`；`<数据目录>\config.json` 是随保存更新的可读镜像（手改后重启会导入数据库）。首次启动从项目根 `config.default.json` 补默认值。

### 5.2 加载/保存规则

- `config.default.json` 是默认值来源；`config.json` 只存差异/实际值，启动时深合并。
- 读取 JSON 时会**去掉 UTF-8 BOM**（记事本保存也不怕）。
- 写入采用「临时文件 + rename」原子写，避免断电写坏。
- 旧版单账户配置（只有 `bot` 段）会自动迁移成 `accounts: [{ id: "main", ... }]`。
- 旧版 `server.token` 会被删除（面板不再用访问令牌）。
- 旧版 `jlw.mode` / `jlw.key` 会被删除。
- `accounts[]` 为空时，会把 `bot` 段变成第一个账户。
- `plugins.token` 为空时自动生成 24 位随机令牌。
- `publicConfig()` 返回面板可见配置：AppSecret 打码、`plugins.token` 打码、`hasSecret` / `hasToken` 标记。
- `--port` / `--host` 会写回 `config.json`；`--data-dir` 不写回。

### 5.3 默认配置（`config.default.json`）

```json
{
  "$comment": "首次启动会复制到 ~JlWBoT/config.json。accounts[] 是账户池；bot 段仅作为新建账户的默认模板。",
  "server": {
    "host": "127.0.0.1",
    "port": 8686,
    "openBrowser": true,
    "trustProxy": false
  },
  "jlw": {
    "baseUrl": "https://www.jlworld.net",
    "apiPath": "/api/plugin/jl-account",
    "insecureTls": false,
    "timeoutMs": 20000,
    "sessionDays": 7
  },
  "auth": {
    "allowed": [],
    "initialized": false
  },
  "update": {
    "enabled": true,
    "pageUrl": "https://www.jlworld.net/QQBOT"
  },
  "accounts": [],
  "bot": {
    "appId": "",
    "clientSecret": "",
    "sandbox": false,
    "mode": "ws",
    "tokenUrl": "https://bots.qq.com/app/getAppAccessToken",
    "tokenUrlAlt": "https://api.bot.qq.com/app/getAppAccessToken",
    "apiBase": "https://api.sgroup.qq.com",
    "apiBaseSandbox": "https://sandbox.api.sgroup.qq.com",
    "gatewayUrl": "",
    "intents": [
      "GUILDS",
      "GUILD_MEMBERS",
      "GUILD_MESSAGE_REACTIONS",
      "DIRECT_MESSAGE",
      "GROUP_MEMBER_EVENT",
      "GROUP_AND_C2C_EVENT",
      "PUBLIC_GUILD_MESSAGES",
      "INTERACTION"
    ],
    "shardId": 0,
    "shardCount": 1,
    "prefix": "",
    "name": "",
    "atReply": true
  },
  "webhook": {
    "path": "/qqbot/webhook",
    "verifySignature": true,
    "ackOp12": true
  },
  "plugins": {
    "enabled": true,
    "defaultTimeoutMs": 8000,
    "maxQueue": 200,
    "autoReload": true,
    "token": ""
  },
  "log": {
    "level": "info",
    "console": true,
    "maxFileMB": 16,
    "keepDays": 7
  },
  "storage": {
    "messages": true,
    "maxMessages": 20000,
    "events": 500
  }
}
```

### 5.4 顶层字段说明

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `server.host` | `127.0.0.1` | 监听地址；`0.0.0.0` 可公网/局域网访问 |
| `server.port` | `8686` | 面板端口；改动需重启 |
| `server.openBrowser` | `true` | 启动后自动开浏览器 |
| `server.trustProxy` | `false` | 信任 `X-Forwarded-For`（反向代理时开） |
| `jlw.baseUrl` | `https://www.jlworld.net` | 聚龙账户站点；空/本机地址会自动修复 |
| `jlw.apiPath` | `/api/plugin/jl-account` | 账户接口路径 |
| `jlw.insecureTls` | `false` | 跳过 TLS 证书校验（仅自签名/测试） |
| `jlw.timeoutMs` | `20000` | 账户接口超时 |
| `jlw.sessionDays` | `7` | 面板会话有效天数 |
| `auth.allowed` | `[]` | 允许登录的聚龙账户列表；空则首次运行走 CMD 引导 |
| `auth.initialized` | `false` | 是否已完成首次登录范围初始化（用于升级时从旧会话迁移） |
| `update.enabled` | `true` | 是否检查在线更新 |
| `update.pageUrl` | `https://www.jlworld.net/QQBOT` | 更新页地址 |
| `webhook.path` | `/qqbot/webhook` | 默认 WebHook 路径；多账户自动加 `/<id>` |
| `webhook.verifySignature` | `true` | 是否验签 |
| `webhook.ackOp12` | `true` | 是否回 op12 ACK |
| `plugins.enabled` | `true` | 插件总开关 |
| `plugins.defaultTimeoutMs` | `8000` | 插件默认超时 |
| `plugins.maxQueue` | `200` | 每插件事件队列上限 |
| `plugins.autoReload` | `true` | 文件变化自动重载 |
| `plugins.token` | 自动生成 | 外部插件 API 令牌；面板打码 |
| `log.level` | `info` | `debug/info/warn/error` |
| `log.console` | `true` | 是否打印到控制台 |
| `log.maxFileMB` | `16` | 单日志文件大小上限 |
| `log.keepDays` | `7` | 日志保留天数 |
| `storage.engine` | `sqlite` | 存储方式：`sqlite`（`jlwbot.db`）或 `json`（JSON/JSONL 文件）；面板「设置 → 日志与存储」可切换，切换时自动迁移并重启 |
| `storage.messages` | `true` | 是否落盘消息 |
| `storage.maxMessages` | `20000` | 消息保留条数（内存事件环/查询上限参考） |
| `storage.events` | `500` | 内存事件环大小 |

### 5.5 账户对象字段（`accounts[]`）

| 字段 | 说明 |
| --- | --- |
| `id` | 账户 ID（自动清理非法字符；唯一） |
| `name` | 显示名称 |
| `appId` | QQ 机器人 AppID |
| `clientSecret` | AppSecret（面板打码） |
| `enabled` | 账户总开关：停用后框架启动/重启都不会连接它（面板「停用/启用」） |
| `autoConnect` | 自动连接（默认 `true`）：项目启动、重启（含定时重启）后是否自动连这个 bot |
| `autoReconnect` | 异常重连（默认 `true`）：掉线后是否自动重连并保持在线；关掉后掉线停在「已断开」，需手动点「重连」 |
| `mode` | `ws` 或 `webhook` |
| `sandbox` | 是否沙箱环境 |
| `prefix` | 命令前缀（默认空；`/签到` 与 `签到` 都识别） |
| `intents` | 订阅的 Intents 名称数组 |
| `shardId` / `shardCount` | 分片参数 |
| `tokenUrl` / `tokenUrlAlt` | access_token 获取地址 |
| `apiBase` / `apiBaseSandbox` | API 基地址 |
| `gatewayUrl` | 网关地址（空则每次获取） |
| `webhookPath` | 该账户 WebHook 路径 |
| `atReply` | 群聊是否必须 @ 才回复 |

### 5.6 登录范围

`auth.allowed` 是对象数组，元素：

```json
{
  "email": "user@example.com",
  "id": "usr_xxx",
  "name": "显示名",
  "source": "first-run-cli / panel / session-migration",
  "addedAt": 1795250000000
}
```

- 登录时按 `user.id` 或 `user.email` 匹配；邮箱大小写不敏感。
- 首次登录成功后会把 `id`/`name` 补进条目，以后邮箱改了仍可按 id 匹配。
- 通过面板添加只要求邮箱格式正确；不会去聚龙站点验证账户是否存在。
- 至少保留一个账户；`removeAllowedAccount()` 会拒绝删除最后一个。
- 手工编辑 `config.json` 也可；`allowed` 为空时启动会走 CMD 首次引导。
- 测试/应急：环境变量 `JLW_ALLOW_ALL_LOGIN=1` 临时允许所有账户（启动日志会警告）。

### 5.7 站点自愈

v1.3.1 起，启动时若发现 `jlw.baseUrl`：

- 为空；
- 或指向 `127.0.0.1` / `localhost` / `::1` / `0.0.0.0`；
- 或格式不合法；

会自动恢复为 `config.default.json` 的站点（默认 `https://www.jlworld.net`），并写回 `config.json`，启动日志会提示。

本地 mock 联调（需要保留 `http://127.0.0.1:xxxx`）时设置：

```powershell
$env:JLW_ALLOW_LOCAL_SITE = "1"
node src/index.js
```

运行中手动把站点改成回环地址再登录，服务端会返回 400 和明确提示，而不是 `ECONNRESET`。

---

## 6. 面板

### 6.1 页面

| 页面 | 内容 |
| --- | --- |
| 概览 | 账户在线数、今日消息、群/私聊、插件错误、账户池、当前账户卡片、IP/版本 |
| 账户 | 新建/编辑/删除/启用/停用/启动/重连/切换；AppID/Secret/模式/Intents/WebHook 路径；自动连接（启动/重启后是否自动连）与异常重连（掉线是否自动保持在线）开关 |
| 消息 | 实时消息 + 进群/退群/加群申请 + 机器人自己发出的消息；按账户/群/类型过滤、群名称列、附件详情；**点消息看预览**（文字气泡、Markdown 成品、图片、卡片、`ark_data` 群公告）；支持**选日期看历史消息**（SQLite `messages` 表） |
| 连接 | 当前账户的 WS/WebHook 状态、Intents 开关、错误信息、重连/重启 |
| 接口 | 67 个 API 的分组浏览与在线调试（选账户、路径参数、请求体、响应） |
| 插件 | 列表、启用/停用、重载、新建、导入、更新、删除、API 文档、设置页、测试事件 |
| 市场 | 内嵌 VloSBoT 插件市场（`vlos.jlworld.net`），浏览/下载插件；登录面板时已自动登录市场，顶部可外部打开/刷新 |
| 日志 | 实时日志、级别过滤、搜索、暂停、下载；支持**选日期看历史日志**（SQLite `logs` 表，旧版 JSONL 会自动导入） |
| 设置 | 面板端口/监听、聚龙账户站点、插件令牌、公网 IP、存储（SQLite / JSON 可切换）、日志、主题 |

### 6.2 登录/注册/找回密码

- 登录：`POST /api/login`，成功后 Cookie `jlw_sid`。
- 注册：`POST /api/jlw/send-code` → 邮箱验证码 → `POST /api/jlw/register`。
- 找回：`POST /api/jlw/send-code`（`purpose=reset`）→ `POST /api/jlw/reset-password`。
- 登录失败限流：同 IP 10 次/分钟；同邮箱 5 次/10 分钟；验证码有冷却。

### 6.3 左下角「登录范围」

- 始终显示在左下角，副标题是当前允许账户数（如 `1 个账户`）。
- 点开弹窗：账户列表（头像首字、名称、邮箱/ID）、当前账户标记、移除按钮、邮箱输入框。
- 添加：输入聚龙账户邮箱 → `POST /api/auth/scope`；成功后立即生效，该邮箱可登录/注册/重置密码。
- 移除：至少保留一个；移除后旧会话在下一次 HTTP 请求时失效，所有面板 WebSocket 会主动断开并重连鉴权。
- 首次运行只有一个账户时，登录后会 toast 一次「可在左下角【登录范围】添加更多聚龙账户」。

### 6.4 左下角在线更新

- 登录面板后自动检查一次；
- 每 15 分钟检查一次；
- 页面重新可见时检查一次；
- 有新版本：左下角显示「发现新版本 vX.Y.Z · 当前 vA.B.C」；
- 点开弹窗：当前/最新版本、包大小、来源、更新警告；
- 点「下载并重启」→ 下载进度遮罩 → 校验 → 重启 → 自动刷新；
- 更新失败会显示错误和日志路径；旧版本继续运行（校验失败时）。

### 6.5 其他交互

- 右上角公网 IP 胶囊：点击复制；离线显示获取失败。
- 头像：QQ 头像按 AppID/openid 拼接；机器人头像从 `/users/@me` 取并与 READY 合并。
- 群名称：按 `group_openid` 查询并缓存；点群名过滤，点「全部」退出。
- 插件文档页：`/docs.html`，支持搜索/TOC/代码复制/「复制全文」。
- 插件设置页：`/plugin-settings.html`，独立可编辑，向父页面 `postMessage` 保存。
- **白天/夜晚主题**：右上角胶囊按钮（登录页在右上角固定一颗），`localStorage` 记忆；切换时 0.5 秒颜色渐变，不闪屏。
- **页面背景**（v1.3.9+，移植自 VloSMarket）：底部双层海浪（夜/昼各两层交叉淡化）、细点阵纹理、缓慢上浮的光点；全部 `pointer-events:none`，不影响点击，`prefers-reduced-motion` 下自动静止。

### 6.5.1 消息页记录范围（v1.4.0+）

| 类型 | 方向 | 说明 |
| --- | --- | --- |
| 群聊 / 单聊 / 频道 | 收到 | 网关下发的事件，带发送者、内容、附件 |
| 进群 / 退群 / 加群申请 / 机器人进出群 / 加删好友 | 收到 | 顶部筛选「群事件」；群名、成员 OpenID、验证信息都能看 |
| 机器人发出的消息 | 发出 | 主动发送、被动回复、`event_id` 回复、插件动作回复都会记一条（筛选「机器人」） |

- 「全部」里按时间混排收发；搜索框同时匹配内容、昵称、OpenID、事件说明。
- 机器人发出的消息成功后由 `Bot._recordOutgoing()` 记录：进内存事件环（`storage.events`）、写 SQLite `messages` 表（`direction:"out"`，原始请求体存 `payload`，用于详情页还原 markdown/卡片/富媒体）、并通过面板 WebSocket 实时推送。
- 发送失败不记录（只在日志里留 WARN），保证消息页里出现的都是真实发出的。

| 群事件 | 机器人发出 |
| --- | --- |
| (截图略) | (截图略) |

### 6.6 前端约定

- 原生 HTML/CSS/JS，无打包、无 CDN、无框架依赖。
- 修改 `src/web/*` 后刷新浏览器即可；服务端静态资源 `no-store`。
- 主页面 CSP：`default-src 'self'`，`connect-src 'self' ws: wss:`。
- 插件 `api.html` / `settings.html` 在沙箱 iframe 中运行，CSP 禁止联网。

#### 主题与背景图

| 白天（light） | 夜晚（dark） |
| --- | --- |
| (截图略) | (截图略) |
| (截图略) | (截图略) |

---

### 6.7 插件市场

左侧导航「插件」下面新增 **市场**，页面内嵌 <https://vlos.jlworld.net/>：

- 市场站点本身带 `X-Frame-Options: SAMEORIGIN`，不能直接 iframe；面板用同源反向代理 `/market-proxy/*` 转发。
- 代理只固定代理 `https://vlos.jlworld.net`，不是开放代理；访问需要面板登录。
- 转发前会去掉 `X-Frame-Options` / CSP，并把 HTML/CSS/JS 里的 `/assets`、`/api`、`/home`、`/market` 等根路径改写到 `/market-proxy/*`，保证市场页面、接口和下载都在面板同源下工作。
- **根路径映射到市场根 `/`（首页）**，不是 `/index.html`：市场的 `/index.html` 是「插件列表」页（白底、无首页 hero），之前内嵌显示和直接打开 `https://vlos.jlworld.net/` 不一样就是这个原因。
- **内嵌时保留栏目（顶栏）**：市场检测到被 iframe 内嵌会加 `.embedded` 隐藏顶栏/页脚（给它自家外壳用）；面板代理把判定改成「父窗口是否为市场外壳」，所以在面板里能看到完整的顶部栏目、铃铛与用户区。
- **不会转发面板的 `jlw_sid` Cookie**；市场自己的登录 Cookie 作用域改为 `/market-proxy/`。
- **面板登录时自动登录市场**：面板用聚龙账户密码登录成功后，服务端顺带调用市场 `POST /api/auth/auto-login`（`{ mail, password }`），拿到市场自己的 `vlos_sid` 只存在内存里，按面板会话索引，之后转发 `/market-proxy/*` 时自动带上；密码只用于这一次请求，不写配置、不写日志、不落盘。见 `MarketProxy#autoLogin()` 与 `PanelServer#_marketLogin()`。
- 因此打开【市场】标签时通常已经是登录状态，不用再输一遍账号密码；如果市场仍显示登录页（例如面板是从旧版本启动、或市场那边会话过期），点【刷新】或退出面板重新登录一次即可。
- 市场自动登录接口有 **10 次 / 5 分钟的 IP 限流**：框架按邮箱缓存市场会话（`marketByMail`），同一账户再次登录面板时先用 `GET /api/me` 验证缓存，有效就直接复用，不再调自动登录；被限流（429）时只写一条 warn 日志，市场退回它自己的登录页，不影响面板。
- 在市场里点「退出登录」会上游下发清空 `vlos_sid` 的 Cookie，代理检测到后调用 `_marketLogout()` 一并清掉服务端缓存，避免下次又把旧会话注入回去。
- **框架重启后**面板会话还在（SQLite `sessions` 表），但市场登录态只在内存，会失效；市场页顶部有【市场登录】按钮，用密码补一次即可（`POST /api/market/login`，同样不落盘）。
- **可以选账户登录市场**：后台允许多人编辑时，登录范围里可能有多个聚龙账户；【市场登录】弹窗会列出左下角【登录范围】里的全部账户，默认选当前面板账户，选谁就用谁的密码登录市场（`POST /api/market/login` 带 `mail`，会校验在登录范围内）。市场会话按邮箱分别缓存，切回某个账户时若缓存还有效直接复用。
- **正常内嵌，不做缩放**：iframe 按面板内容区大小直接铺满（不再用 `transform: scale` 放大/缩小），市场页面按自己的响应式布局显示；每次进入【市场】固定从首页开始。
- **上传插件走流式转发**：`/market-proxy/*` 在读取 body 之前分流，zip 二进制原样 pipe 给市场（保留 `Content-Length`，超时 5 分钟，支持 200 MB）；不能再先把请求体 `toString('utf8')`，否则 zip 会损坏、市场报「zip 目录越界」。
- **内层链接也在外壳里切页**：外壳页注入的点击补丁同时接管 `#viewFrame` 里的站内链接（例如首页的「上传插件」`href="/market-proxy/developer"`），映射成对应视图在外壳里切换，不会让内层 iframe 自己跳成独立页面；内层页面的顶栏按 `embedded` 规则隐藏，避免双顶栏。
- iframe 地址带面板版本号（`/market-proxy/?v=<版本>`），面板升级后一定拿新页面，不吃 bfcache/旧缓存。
- **固定从首页开始**：每次进入【市场】都会重置到 `/market-proxy/`（市场首页），不会停在上次浏览的子页面。
- 面板退出登录会同时丢弃对应的市场登录态（`/api/logout` → `_dropMarketSid`）；市场登录态默认保留 12 小时、最多 200 条（`MARKET_SID_TTL_MS`）。
- 市场登录成功后原本会把**顶层窗口**跳到 `/home`（`common.js` 的 `done()`），内嵌时会顶掉整个控制台；代理层把 `window.top.location.href='/home'` 改写成 `location.reload()`，保持在内嵌面板里。
- 市场页面有自己的聚龙世界登录门禁；登录后即可浏览、评分、评论、下载插件本体/源码。
- 页面顶部有「外部打开」和「刷新」；市场接口/下载异常时可直接外部打开。
- 测试可用 `JLW_MARKET_URL=http://127.0.0.1:xxxx` 指向本地假市场。
- 相关文件：`src/core/market-proxy.js`、`src/core/server.js` 的 `/market-proxy/*` 拦截、`src/web/app.js` 的 `pageMarket()`。
- 测试：`node test/market-proxy-test.js`（49 项，含自动登录、会话复用、市场退出、补登录/切换账户、根路径落到市场首页、栏目路由、改写内容禁缓存、上传 zip 二进制透传、栏目点击兜底、内嵌导航与顶栏还原）。
- 排查接口：`GET /api/market/status` 返回 `{ signedIn, mail, proxy }`，可确认当前面板会话有没有拿到市场登录态。

## 7. 面板 HTTP API 与 WebSocket

### 7.1 鉴权模型

| 类型 | 鉴权 |
| --- | --- |
| `/api/*` | 除登录相关外，都需要面板会话 Cookie `jlw_sid`（或 `x-jlw-session` / `?session=`） |
| `/plugin-api/v1/*` | 插件令牌：`Authorization: Bearer <token>` / `x-jlw-plugin-token` / `?token=` |
| `/qqbot/webhook*` | 各账户 AppSecret Ed25519 验签 |
| `/health`、静态页面 | 公开 |

未登录访问 `/api/*` 返回 `401 { ok:false, error:"请先登录", login:true }`。

### 7.2 路由分组

> 完整注册表以 `src/core/server.js` 的 `_registerRoutes()` 为准；下面是按功能分组的路由。

#### 登录 / 会话

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `POST` | `/api/login` | 邮箱+密码登录；可选 `baseUrl` / `insecureTls` |
| `GET` | `/api/session` | 当前登录状态、站点、版本、`needsSetup` |
| `POST` | `/api/logout` | 退出并清 Cookie/会话 |
| `GET` | `/api/me` | 当前聚龙用户资料 |
| `POST` | `/api/me/refresh` | 用上游 token 刷新资料 |
| `POST` | `/api/jlw/send-code` | 发送注册/重置验证码 |
| `POST` | `/api/jlw/register` | 注册并登录 |
| `POST` | `/api/jlw/reset-password` | 重置密码并登录 |
| `POST` | `/api/jlw/test` | 测试站点/接口连通性 |
| `GET` | `/api/auth/scope` | 登录范围列表 + 当前账户 |
| `POST` | `/api/auth/scope` | 添加 `{email}` 到登录范围 |
| `DELETE` | `/api/auth/scope/:key` | 从登录范围移除（`:key` 为 email 或 id；拒绝删最后一个） |

#### 状态 / 账户

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/health` | 公开健康检查：名称/版本/账户数/uptime |
| `GET` | `/api/status` | 完整状态：账户、插件、服务器、配置、IP、路径 |
| `GET` | `/api/accounts` | 账户列表 |
| `POST` | `/api/accounts` | 新建账户 |
| `GET` | `/api/accounts/:id` | 单账户详情 |
| `PATCH` | `/api/accounts/:id` | 修改账户 |
| `DELETE` | `/api/accounts/:id` | 删除账户 |
| `POST` | `/api/accounts/:id/start` | 启动 |
| `POST` | `/api/accounts/:id/stop` | 停止 |
| `POST` | `/api/accounts/:id/restart` | 重连 |
| `POST` | `/api/accounts/:id/mode` | 切换 WS/WebHook |
| `POST` | `/api/accounts/:id/token/refresh` | 刷新该账户 token |
| `POST` | `/api/bot/start` / `stop` / `restart` / `mode` | 兼容旧接口（默认账户） |
| `POST` | `/api/token/refresh` | 兼容旧接口 |

#### 配置 / 更新

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/api/config` | 打码后的配置 |
| `POST` | `/api/config` | 保存配置 patch；端口变更返回 `restartRequired`；`system.restart` 变化会立即重排定时重启 |
| `POST` | `/api/system/restart` | 进程内重启（不退出 node）；返回 `{ ok, restarting: true }` |
| `GET` | `/api/update/check` | 检查更新；`?force=1` 跳过缓存 |
| `POST` | `/api/update/start` | 下载并启动更新；body `{version}` 可选 |
| `GET` | `/api/update/progress` | 更新阶段/进度/错误 |

#### 事件 / 消息 / API 调试

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/api/events` | 事件列表；`limit`/`account` |
| `POST` | `/api/events/inject` | 注入模拟事件 |
| `POST` | `/api/send` | 主动发送消息（按账户） |
| `GET` | `/api/groups/info` | 群名称查询（缓存） |
| `GET` | `/api/endpoints` | 67 个接口注册表 + 分组 |
| `POST` | `/api/call` | 通用 API 调试透传 |
| `GET` | `/api/netinfo` | 公网 IP（缓存） |
| `POST` | `/api/netinfo/refresh` | 强制重新探测 |

#### 插件

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/api/plugins` | 插件列表/状态/统计 |
| `POST` | `/api/plugins/reload` | 全部重载 |
| `POST` | `/api/plugins/create` | 新建插件（只填元数据） |
| `POST` | `/api/plugins/import` | 导入 js/json/zip/文件夹 |
| `POST` | `/api/plugins/:id/update` | 用同 ID 的新版本 zip 更新（保留 config/enabled/data，失败回滚） |
| `GET` | `/api/plugins/:id` | 单插件详情 |
| `GET` | `/api/plugins/:id/api-doc` | 读取 `api.html` |
| `GET` | `/api/plugins/:id/settings` | 读取 `settings.html` |
| `POST` | `/api/plugins/:id/config` | 保存插件 config |
| `DELETE` | `/api/plugins/:id` | 删除插件目录 |
| `POST` | `/api/plugins/:id/enable` | 启用/停用 |
| `POST` | `/api/plugins/:id/reload` | 单插件重载 |
| `POST` | `/api/plugins/:id/test` | 注入测试事件 |
| `POST` | `/api/plugins/:id/manifest` | 修改 manifest |
| `POST` | `/api/plugins/:id/file` | 读写插件文件（受沙箱限制） |
| `POST` | `/api/plugins/install-sample` | 重新安装示例插件 |
| `POST` | `/api/plugins/token/rotate` | 重置插件令牌 |

#### 日志 / 文档 / 静态

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/api/logs` | 日志查询（limit/level/q） |
| `GET` | `/api/logs/download` | 导出某天日志为 NDJSON（`?date=YYYY-MM-DD`，缺省最近一天） |
| `POST` | `/api/storage/engine` | 切换存储方式（`{ engine: "sqlite" \| "json" }`），自动迁移数据并重启 |
| `GET` | `/docs/:file` | 返回 Markdown 文档（`README.md`、`plugin.md`、docs/*.md） |
| `GET/POST` | `/market-proxy/*` | VloSBoT 插件市场同源代理（需面板登录；转发固定上游，自动带市场会话） |
| `GET` | `/api/market/status` | 当前面板会话的市场登录态（`signedIn` / `mail`） |
| `POST` | `/api/market/login` | 用聚龙账户密码补一次市场登录（`{ password, mail? }`；`mail` 可指定登录范围内的其他账户；密码不落盘，5 次 / 5 分钟） |
| `GET` | `/` `/app.js` `/style.css` `/favicon.svg` `/logo.png` | 面板静态资源 |
| `GET` | `/docs.html` `/plugin-settings.html` | 文档/插件设置页 |

#### 插件桥（外部程序）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/plugin-api/v1/info` | 框架版本、账户、插件 manifest、支持的动作 |
| `GET` | `/plugin-api/v1/pull` | 长轮询拉事件；`plugin`、`timeout`、`format=text` |
| `POST` | `/plugin-api/v1/action` | 回传动作（reply/send_group_message/...） |

#### WebHook

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/qqbot/webhook` | 健康提示（POST only） |
| `POST` | `/qqbot/webhook` | 默认账户回调 |
| `POST` | `/qqbot/webhook/<id>` | 其他账户回调 |

### 7.3 响应约定

- 成功：`{ "ok": true, ... }`
- 失败：`{ "ok": false, "error": "人类可读信息", "code": "可选错误码" }`
- 登录失效：HTTP 401 + `{ login: true }`
- 大部分错误不会抛 HTML；客户端 `api()` 统一读 JSON。
- `GET /api/status` 包含 `version/now/accounts/aggregate/plugins/pluginList/server/config/jlw/webhook/paths`，以及 `system.restart`（`{ enabled, minutes, nextAt }`）。

### 7.4 面板 WebSocket

- 路径：`/ws`
- 鉴权：面板会话（Cookie/头/query）
- 服务端 → 客户端：
  - `hello`：版本、完整状态、插件、最近日志、最近事件
  - `status`：状态变化
  - `log`：实时日志
  - `event`：实时事件
  - `notice`：框架提示
- 客户端 → 服务端：`ping`，服务端回 `pong`。

---

## 8. QQ API v2 / 网关 / WebHook / Intents

### 8.1 API

- 注册表：`src/core/endpoints.js`，共 **67** 个接口；完整清单见 [docs/API接口.md](docs/API接口.md)（文末另有插件市场上传 API）。
- 默认 API Base：`https://api.sgroup.qq.com`；沙箱：`https://sandbox.api.sgroup.qq.com`。
- access_token：`https://bots.qq.com/app/getAppAccessToken`（备用 `https://api.bot.qq.com/...`）；按账户缓存，到期前 60 秒刷新。
- 回复消息自动补 `msg_seq`（同一 `msg_id` 多条回复时递增）。
- 错误归一化：`code/message/status`；`11298`（IP 白名单）标记为致命，不再刷新 token/重试。
- 限流/重试：API 客户端对可重试错误退避；`40023001` 时提示等待。

### 8.2 WebSocket 网关

- `GET /gateway` 获取地址（会缓存；限频时暂停）。
- `op=2` identify：token + intents + shard。
- 心跳：按 `heartbeat_interval` 发送 `op=1`；`op=11` 心跳 ACK。
- 断线：指数退避重连，最多 8 次；支持 `resume`（`op=6`）。
- `op=9` 无效 session：清 session 重连。
- `op=7` reconnect：主动重连。
- 4004 / 4014 等鉴权/权限错误：停止或回退 Intents。
- IP 白名单错误：停止自动重连，面板提示去开放平台加 IP。

### 8.3 WebHook

- 路径按账户：默认 `/qqbot/webhook`，其他 `/qqbot/webhook/<id>`。
- 平台校验：Ed25519 签名（`X-Signature-Ed25519` / `X-Signature-Timestamp`），用各账户 AppSecret。
- 回调地址验证：自动回 `plain_token` + `signature`。
- op12 ACK：按 `webhook.ackOp12` 返回。
- 平台限制：HTTPS；端口 80/443/8080/8443；代理不能改写原始 body。
- 反向代理要保留 `/ws` 的 `Upgrade`/`Connection` 头。

### 8.4 Intents

默认开启 8 个：

`GUILDS` · `GUILD_MEMBERS` · `GUILD_MESSAGE_REACTIONS` · `DIRECT_MESSAGE` · `GROUP_MEMBER_EVENT` · `GROUP_AND_C2C_EVENT` · `PUBLIC_GUILD_MESSAGES` · `INTERACTION`

- `GROUP_MEMBER_EVENT`（1<<24）是 2026-08 新增：群成员加入/退出、用户申请加群。
- 无权限的 Intent 不要勾选；4014 会自动回退到上次可用集合，面板提示。
- 插件订阅群消息时：
  - 只写 `GROUP_AT_MESSAGE_CREATE`：只收到 @ 机器人的群消息；
  - 要收全量群消息，必须显式加 `GROUP_MESSAGE_CREATE`。
- 命令解析不强制前缀：`/签到` 与 `签到` 都会得到 `command=签到`。

---

## 9. 插件系统

### 9.1 五种类型

| type | 运行位置 | 适合 |
| --- | --- | --- |
| `js` | 框架进程内 | 性能最好，原生 JS，直接调用框架 API |
| `http` | 你的 HTTP 服务 | 已有服务，框架把事件 POST 过去 |
| `pull` | 你的程序主动拉取 | **易语言首选**，只需 HTTP 客户端，无需开服务端口 |
| `process` | 框架拉起并守护 EXE | 易语言后端、Python/Go 独立进程 |
| `dll` | 框架拉起 DLL 宿主 | 32 位易语言 DLL（宿主加载后走拉取协议） |

### 9.2 插件目录与文件

```text
~JlWBoT/plugins/<id>/
├─ plugin.json       元数据 + config（必需）
├─ index.js          JS 插件入口（type=js）
├─ api.html          可选：插件 API 文档（面板沙箱打开）
├─ settings.html     可选：插件设置页（沙箱 iframe + postMessage）
├─ data/             可选：插件自己的数据
└─ launch.*          可选：process/dll 的启动配置
```

`plugin.json` 最小示例：

```json
{
  "id": "my-plugin",
  "name": "我的插件",
  "version": "1.0.0",
  "author": "你的名字",
  "description": "这个插件做什么",
  "enabled": true,
  "type": "js",
  "priority": 100,
  "events": ["GROUP_AT_MESSAGE_CREATE", "GROUP_MESSAGE_CREATE", "C2C_MESSAGE_CREATE"],
  "commands": ["天气"],
  "config": {}
}
```

字段：

| 字段 | 说明 |
| --- | --- |
| `id` | 唯一 ID（非法字符会清理） |
| `name` / `version` / `author` / `description` | 元数据 |
| `enabled` | 是否启用 |
| `type` | `js/http/pull/process/dll` |
| `priority` | 越小越先执行（默认 100） |
| `events` | 订阅事件；空则 `["*"]` |
| `commands` | 命令白名单（用于匹配/展示） |
| `config` | 插件配置，面板设置页读写 |
| `launch` | 进程/DLL 启动参数（`command`/`args`/`cwd` 等） |

### 9.3 JS 插件返回

```js
module.exports = {
  async onEvent(ctx) {
    const { message } = ctx;
    if (!message) return null;
    if (message.command?.name !== '天气') return null;
    return { reply: '收到：' + message.cleanContent };
    // 或 { replies: [...] } / { actions: [...] } / { stop: true }
  },
};
```

- `{ reply }`：单条回复。
- `{ replies: [...] }`：多条回复。
- `{ actions: [...] }`：主动动作（发群/单聊/频道、调 API、互动 ACK、日志等）。
- `{ stop: true }`：阻止后续插件。
- 插件内可通过 `globalThis.__JLWBOT_PLUGIN_APIS__` 调用其他插件的公开 API（例如 VloS/Arknights）。

### 9.4 生命周期与状态

- 启动时 `PluginManager.init()` 复制 `plugins/` 示例到 `~JlWBoT/plugins`（有 `.seeded` 标记，不重复覆盖）。
- 扫描每个子目录的 `plugin.json`，加载插件。
- `js`：进程内 `require`。
- `http`：事件 POST 到配置的 URL。
- `pull/process/dll`：使用队列/长轮询/子进程。
- 状态：`idle`、`disabled`、`starting`、`running`、`error`、`stopped`。
- 面板支持启用/停用、重载、删除、导入、更新、创建、测试事件、API 文档、设置页。
- 插件进程退出会自动重启；`autoReload` 监听文件变化。

### 9.5 外部插件协议（pull）

拉取：

```http
GET {框架}/plugin-api/v1/pull?plugin=el-sample&timeout=25000&format=text
Authorization: Bearer <插件令牌>
```

返回纯文本（`format=text` 或 `Accept: text/plain`）：

```text
# JlWBoT pull
plugin=el-sample
count=1
server_time=1795250000000
---
seq=1
event=GROUP_AT_MESSAGE_CREATE
event_id=...
time=...
account_id=main
account_name=主账号
chat_type=group
group_openid=G_XXX
user_openid=
channel_id=
guild_id=
msg_id=MSG_XXX
user_id=...
user_name=小明
member_role=member
content=天气 北京
command=天气
args=北京
```

`format` 不传或 `json` 时返回 JSON：`{ ok, events:[...] }`。

动作：

```http
POST {框架}/plugin-api/v1/action
Authorization: Bearer <插件令牌>
Content-Type: application/x-www-form-urlencoded

plugin=el-sample&accountId=main&action=reply&chat_type=group&group_openid=G_XXX&msg_id=MSG_XXX&content=北京今天晴
```

支持的动作：`reply`、`send_group_message`、`send_c2c_message`、`send_channel_message`、`api`、`endpoint`、`interaction_ack`、`log`、`noop`。`accountId` 决定用哪个账户回复；不传用默认账户。

### 9.6 内置示例插件

| 插件 | 类型/版本 | 功能 |
| --- | --- | --- |
| `echo` | js 1.0.0 | `/ping`、`/echo`、`/help`，演示单条/多条回复 |
| `status` | js 1.0.0 | `/状态` 查看框架运行信息 |
| `el-sample` | pull 1.0.0 | 易语言长轮询示例（默认启用但不回复） |
| `dll-sample` | dll 1.0.0 | 32 位易语言 DLL 宿主示例（默认关闭） |
| `mcstatus` | js 1.3.3 | `/MC 地址` 查询 Minecraft 服务器，支持 JSON/菜单/自定义回复模板 |
| `Arknights` | js 1.5.0 | 森空岛签到、数据卡片、肉鸽/基建/剿灭/干员、设置页与对外 API |
| `VloS` | js 2.9.43 | 聚龙账户注册/登录/QQ 绑定、资料、签到（诗词/龙晶/玄玉/方舟掉落）、菜单/群管/进退群/用户、审核页；群管覆盖只认已审核群（未审核/驳回回落全局）；进退群默认 `event_id`，被拒自动降级主动消息（需主动消息权限） |
| `xinghuo`（星火） | js 1.7.3 | 好友/群 OpenID 收集与 zip 导入，好友/群分列表、qlogo 头像 + 名称补全/一键刷新/重试失败项、全选；公告页只编辑保存，用户库顶部是唯一发送入口（下拉选公告、两次确认、实时进度/用时/预计剩余/取消），公告支持腾讯 Markdown 蓝字与 5×5 消息按钮（按钮被拒自动改纯 Markdown），失败好友自动标无效、私聊恢复有效，好友筛选【全部/有效/无效/删除】、群聊【有效/无效】，刷新选中按 scope+ids 不串类；账户列显示机器人昵称，群头像缺失用群名首字兜底；兑换码后台一次生成一个固定码（可自定义，0 次=无限、同用户一次、用完失效），只写 VloS 余额；存储交给 VSQL shared 库（`xinghuo_` 表，跨插件可读，旧 JSON/SQLite 自动迁移，前置 VSQL 缺失会报错并回退 JSON）；源码 `plugins/xinghuo`，zip 在 `插件/星火-【v1.7.3】.zip` |
| `huixiang`（本机插件 zip） | js 1.0.0 | 回响：`/ping` 延迟测试、`/状态` Markdown 状态卡、`/data` 群聊/私聊统计、`/openid`、`/gopenid`；源码不在框架导出，zip 在 `插件/回响-【v1.0.0】.zip` |
| `VSQL` | js 1.0.3 | 内置 SQLite 数据库服务：默认 shared 库跨插件共享表，`db('私有ns')` 可隔离；建表/改名/加列/删列全开放（表名支持中文）；设置页可浏览所有表与表内数据（敏感列打码、过滤、刷新），显示完整数据目录；可选 HTTP 网关与 `/vsql` 管理指令；源码 `plugins/VSQL` |

> `VloS` 是功能最完整的示例插件，包含自定义设置页、插件 API、群管审核回调等；细节见 `plugins/VloS/README.md`。
> `星火` 是第二个完整业务插件：设置页用「只读快照 + config.tasks 任务队列」在 sandbox iframe 里完成 zip 导入 / 发码 / 发公告；细节见 `plugins/xinghuo/README.md`。
> `Arknights` 与 `VloS` 会通过 `globalThis.__JLWBOT_PLUGIN_APIS__` 互相调用公开 API。

### 9.7 插件设置页 / API 文档

- 面板「插件 → 编辑」里的设置页读取 `settings.html`，在沙箱 iframe 中运行。
- 保存流程：iframe `postMessage({type:'jlw-settings-save', config})` → 父页面 `POST /api/plugins/:id/config` → 回传 `jlw-settings-saved`。
- `settings.html` 是独立页面时也能读取 `config`（父页面注入/URL 参数），但不是所有浏览器都允许；推荐通过面板打开。
- `api.html` 同样是沙箱页面；`GET /api/plugins/:id/api-doc` 返回 HTML。
- 导入 zip 限制：单文件 18MB、解压总量 60MB；不支持 ZIP64/加密 zip；zip 根目录或单层子目录要有 `plugin.json`。

### 9.8 插件在线更新

插件卡片上的「更新」按钮用于把已有插件升级到新的 zip（同 ID）：

- 只接受 `.zip`；包里的 `plugin.json.id` 必须与当前插件 ID 一致，否则拒绝。
- 更新前完整备份旧插件目录到 `~JlWBoT/backup/plugins/`。
- 保留旧 `plugin.json` 的 `config`（新默认值 + 旧值合并，旧值优先）、`enabled` 状态和 `data/` 用户数据。
- 新包的 `data/` 文件会先写入，再用旧 `data/` 覆盖同名文件，保证用户数据不丢。
- 加载失败/文件写入失败会删除半成品、恢复备份并重载旧版本；错误提示「更新失败，已回滚」。
- 保留最近 5 个更新备份；成功返回 `previousVersion` / `version`。
- 卡片上的「API」按钮已移除；API 文档入口保留在「编辑」弹窗底部的「API 文档」。
- 对应接口：`POST /api/plugins/:id/update`，body `{files:[{name,data(base64)}]}`。

### 9.8 易语言（最省事接法）

1. 面板「插件」→ 新建，只填名称/版本/作者/介绍；类型默认「拉取」；创建后在「外部程序接入」复制插件令牌；
2. 易语言程序循环 `GET /plugin-api/v1/pull?...&format=text`；
3. 处理完 `POST /plugin-api/v1/action`（表单）回动作；
4. 参考后端：`node tools/el-backend-demo.js --token <插件令牌>`；
5. 32 位 DLL 用 `dll` 宿主，见 [docs/易语言对接.md](docs/易语言对接.md)。

---

## 10. 在线更新（v1.3.2+）

### 10.1 更新页约定

默认页面：<https://www.jlworld.net/QQBOT>

页面里的下载卡片：

```html
<div class="yz-dl-name">JlW-BoT [v1.3.4].zip</div>
<div class="yz-dl-meta">35 MB · 已下载 0 次</div>
<a class="yz-btn yz-btn-sm yz-dl-btn" href="/download/xxxx">下载</a>
```

解析规则：

- 找 `yz-dl-name`，取文件名；
- 从文件名取 `vX.Y.Z`；
- 找同一区块的 `yz-dl-btn` 的 `href`；
- 解析大小（`35 MB`）；
- 也兼容未来的 meta：
  ```html
  <meta name="jlwbot-version" content="1.3.3">
  <meta name="jlwbot-download" content="/download/xxxx">
  <meta name="jlwbot-sha256" content="...">
  <meta name="jlwbot-notes" content="更新说明">
  <meta name="jlwbot-size" content="35 MB">
  ```
- 多个 JlW-BoT 卡片时取版本号最高的。
- 版本比较支持 `1.3.2` / `v1.3.2` / `1.3.2-beta`（预发布低于正式版）。

### 10.2 检查与缓存

- 服务端 `Updater.check()` 缓存 **10 分钟**；`?force=1` 强制刷新。
- 面板登录后检查一次；之后每 **15 分钟**、页面重新可见时检查。
- 检查失败静默，不打扰用户；日志记录 `update` scope。
- 只有 `latest > current` 才显示按钮。

### 10.3 下载与安装

- 下载地址必须与页面同域，或是 `*.jlworld.net`；HTTP 页面只允许 HTTP 下载，HTTPS 页面拒绝 HTTP。
- 下载到 `~JlWBoT/updates/JlW-BoT [vX.Y.Z].zip`；最大 320MB；校验 zip 魔数、可选 SHA256。
- 独立更新器 `src/core/update-apply.js` 复制到 `~JlWBoT/updates/apply-update.js` 运行。
- 解压用 PowerShell `Expand-Archive`（Windows）或 `unzip`（其他平台）。
- 校验包内 `package.json` 版本必须与页面版本一致；缺失 `src/index.js` 拒绝。
- 校验通过后写 `apply-ready.json`；面板收到 `ok:true` 才退出。
- 更新器等待旧 PID（最多 90 秒），备份 `src`/`package.json`/`config.default.json`/启动脚本到 `backup-*`。
- 覆盖时保留 `~JlWBoT`，合并 `plugins`（不删除用户插件）。
- 用 `runtime\node.exe`（没有则更新器自己的 Node）以 `--no-open` 启动；参数沿用原来的 `--data-dir` / `--port` 等。
- 更新日志：`~JlWBoT/updates/update.log`；最近结果：`last-update.json`。
- 失败回滚：复制失败会恢复备份并尝试重启旧版本；校验失败在旧进程退出前拒绝，旧服务继续运行。

### 10.4 面板接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/api/update/check` | 返回 `current/latest/hasUpdate/url/fileName/sizeText/notes/pageUrl` |
| `POST` | `/api/update/start` | 开始下载安装；body `{version}` 可选 |
| `GET` | `/api/update/progress` | `phase`：`idle/downloading/preparing/restarting/ready/error`，含 `percent/received/total/error` |

### 10.5 重要限制

- **第一次从 v1.3.1 及更早版本升级必须手动**：旧版本没有更新器。
- **页面版本必须高于本机版本**；页面当前是 v1.3.4，所以 v1.3.4 不会提示。
- 更新包顶层目录必须是 `JlW-BoT`（或任意单层目录，更新器会找根），内部要有 `package.json` + `src/index.js`。
- 更新会覆盖 `src/`、`docs/`、`tools/`、`test/`、启动脚本、`config.default.json`；不会动 `~JlWBoT`。
- 如果安装目录只读、磁盘满、杀毒软件锁文件，更新失败；旧版本尽量保留/回滚。
- 自动更新后新进程是后台进程（无控制台）；面板会自己刷新。需要前台日志就手动重启 `启动机器人.cmd`。

---

## 11. 导出与发布

### 11.1 构建发布包

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools\export-framework.ps1
```

> 有 npm 的环境也可以 `npm run export`；当前机器可能没有 npm，直接用上面的命令即可。

输出：

```text
框架导出\JlW-BoT [v<package.version>].zip
```

- 顶层目录固定 **`JlW-BoT`**（不带版本号），方便直接替换。
- 文件名带版本号：`JlW-BoT [v1.3.4].zip`。
- 版本号从 `package.json` 读取；发版前先改版本（见 11.3）。

### 11.2 包含 / 排除

包含：

- `src/`、`docs/`、`tools/`、`test/`
- `config.default.json`、`package.json`、`README.md`
- `start.cmd`、`启动机器人.cmd`、`.gitignore`
- `plugins/README.txt`（空占位，不含示例插件）
- `runtime/node.exe`（Windows x64 Node，离线运行）

排除：

- `~JlWBoT/`（配置、日志、消息、会话、插件数据）
- `框架导出/`、根目录 zip
- `test/.tmp-*`（测试临时目录）
- 根目录 `node-*.zip` 等下载包

> 导出脚本会检查 staging 里没有 `~JlWBoT`；不会打包密钥/日志/消息。

### 11.3 发版检查清单

1. 改 `package.json` 的 `version`；
2. 改 `src/web/index.html` 的 `<small id="brand-version">`（app.js 会覆盖，但静态兜底）；
3. 更新 README 的版本/变更记录；
4. `node test/run-all.js` 全绿；
5. `powershell -NoProfile -ExecutionPolicy Bypass -File tools\export-framework.ps1`；
6. 解压新 zip 到临时目录，运行 `runtime\node.exe test\config-site-repair.js` 和 `runtime\node.exe test\update-test.js`；
7. 启动临时实例，`/health` 版本正确、`/api/session` 站点正确；
8. 把 zip 上传到 QQBOT 页面下载位；
9. 保留旧 zip 至少一个版本，方便回滚。

### 11.4 离线运行时

```powershell
powershell -ExecutionPolicy Bypass -File tools\打包离线版.ps1
```

只把当前 `node.exe` 复制到 `runtime\node.exe`；之后 `启动机器人.cmd` 优先用它。`runtime\` 约 88MiB，可删除回退系统 Node。

---

## 12. 测试与质量

### 12.1 测试矩阵

| 脚本 | 项数 | 覆盖 |
| --- | --- | --- |
| `test/selftest.js` | 29 | 工具函数、Ed25519 官方样例、事件归一化、插件结果、错误分类、接口注册表、日志、面板集成、登录/注册/会话、插件 CRUD/导入/文档/设置、配置、多账户、IP、退出 |
| `test/reply-event-test.js` | 66 | 回复引用：消息事件用 `msg_id`(+`msg_seq`)、`GROUP_ADD_ROBOT`/`GROUP_MSG_RECEIVE`/`INTERACTION_CREATE` 用 `event_id`、进群/退群没有被动回复必须走主动消息、`msg_id` 与 `event_id` 互斥、插件输出自动分流 |
| `test/gateway-e2e.js` | 19 | 假 QQ 网关：双账户登录、token/网关、事件按账户回复、头像、群名、`event_id` 发送与引用互斥、易语言拉取、断线重连、Intent 回退、账户增删、IP |
| `test/account-modes-test.js` | 20 | 启用 / 自动连接 / 异常重连：配置默认值与持久化、新建默认全开、启动只连该连的账户、关掉异常重连后掉线不重连、重新打开立即补连、进程内重启后自动连接账户重新上线 |
| `test/resilience-test.js` | 26 | 崩溃取证（`crash.log`）、心跳与「上次异常退出」识别、stdout 写失败不崩、HTTP 端口看门狗自愈、畸形 WS 帧不影响服务 |
| `test/restart-log-test.js` | 33 | 定时重启配置（归一化/上限/下次时间）、接口调用日志（成功 DEBUG、失败 WARN、traceId、打码、开关）、面板重启接口与配置回调 |
| `test/restart-e2e.js` | 16 | 真进程内重启：PID 不变、uptime 归零、定时计划保留、重启日志 |
| `test/reconnect-loop-test.js` | 31 | 重连用尽后进入冷却、冷却结束自动续轮、多轮循环、冷却时长配置、手动断开/重连清理定时器 |
| `test/isolation-test.js` | 16 | 机器人侧异常不影响框架：网关事件隔离、Bot 回调兜底、账户转发隔离、状态聚合降级、`/health` 仍可用、异常风暴不退出 |
| `test/single-instance-test.js` | 13 | 单实例锁（第二个实例被拦、残留锁接管、`--force`）、旧版 Arknights 共享对象缺 `live` 不再抛 `.keys` |
| `test/stop-all-test.js` | 7 | `结束进程.cmd`：杀启动器与子进程、写 `stop.flag` 不复活、清锁 |
| `test/reply-guard-test.js` | 18 | 回复闸门：只拦 `【[404 error]` 前缀、正常回复/重复内容/连续多条放行、Bot / 插件 API / 动作三条出口 |
| `test/history-view-test.js` | 13 | 历史日志/消息：日期统计、按日期读、按级别/账户筛选、机器人发出的消息区分、未登录 401 |
| `test/message-preview-test.js` | 18 | 消息详情预览：纯文本/链接、XSS 转义、Markdown 成品（图片/链接不被二次包链接）、图片附件、`raw.ark_data` 群公告（含控制字符）、ark 卡片、未知卡片占位、`javascript:` 拦截、机器人发出的 markdown/卡片/富媒体请求体、腾讯 `qqbot-*` 自定义标签解码/隐藏与 `***` 分隔线 |
| `test/db-migrate-test.js` | 9 | SQLite 迁移：旧 config/sessions/logs/messages（含 payload）导入一次、合并分片并按时间排序、旧文件移到 backup、二次启动不重复、按保留天数清理 |
| `test/storage-engine-test.js` | 10 | 存储引擎切换：SQLite ↔ JSON 双向迁移、config.json 记录引擎、JSON 引擎写 JSONL、两边都能按日期查日志、消息 payload 原样读回、重启后引擎正确 |
| `test/config-site-repair.js` | 8 | 空站点/本机站点自愈、`JLW_ALLOW_LOCAL_SITE`、运行中本机地址 400 |
| `test/auth-scope-test.js` | 10 | 登录范围鉴权、允许/拒绝登录、添加/移除、末位保护、旧会话失效 |
| `test/plugin-update-test.js` | 12 | 同 ID zip 更新、保留 config/data、新文件合并、坏包回滚 |
| `test/market-proxy-test.js` | 49 | 市场代理鉴权、去 XFO/CSP、根路径落到市场首页、API/下载透传、上传 zip 二进制透传、不泄露面板 Cookie、自动登录/复用/退出/补登录/切换账户、栏目路由、改写内容禁缓存、栏目点击兜底、内嵌导航与顶栏还原 |
| `test/update-test.js` | 14 | 更新页解析、版本比较、域名白名单、本地下载、独立更新器解压/覆盖/保留 `~JlWBoT`/重启 |
| `test/update-api-test.js` | 5 | 更新接口鉴权、页面解析、`hasUpdate`、大小、进度 idle |
| `test/huixiang-e2e.js` | — | 回响插件的端到端（需要单独跑） |
| `test/huixiang-zip-import.js` | — | 回响 zip 导入 |
| `test/mcstatus-test.js` | — | Minecraft 查询插件 |
| `test/vlos-test.js` | 41 | VloS 主流程（假聚龙账户） |
| `test/vlos-poems-test.js` | 7 | 诗词导入导出 |
| `test/vlos-live.js` | 29 | 运行中的框架只读联调（需要 8686 在跑） |
| `test/vsql-test.js` | 48 | VSQL 内置 SQLite：命名空间隔离与跨插件共享、CRUD、where、事务/嵌套保存点、async 事务拒绝、预编译、命名参数、值归一化、kv、迁移幂等、结构查询、ATTACH、只读、关闭语义、备份、LRU、内存库、`/vsql` 管理指令、HTTP 网关、中文表名列名、建改删表、findTable、设置页路径/数据快照、卸载清理 |

主回归合计：**29 + 66 + 26 + 33 + 16 + 31 + 16 + 13 + 7 + 18 + 13 + 18 + 9 + 10 + 19 + 20 + 8 + 10 + 12 + 49 + 14 + 5 = 442 项（22 个测试文件）**。

### 12.2 命令

```powershell
node test/run-all.js          # 442 项主回归（不需要 npm）
node test/selftest.js         # 29 项
node test/reply-event-test.js # 66 项（回复引用）
node test/resilience-test.js  # 26 项（崩溃取证/心跳/端口自愈）
node test/restart-log-test.js  # 33 项（定时重启配置/接口日志）
node test/restart-e2e.js      # 16 项（进程内重启端到端）
node test/single-instance-test.js # 13 项（单实例锁）
node test/stop-all-test.js     # 7 项（结束进程，不复活）
node test/reply-guard-test.js  # 18 项（回复闸门/报错前缀）
node test/history-view-test.js # 13 项（历史日志/消息按日期读）
node test/message-preview-test.js # 18 项（消息详情预览渲染）
node test/db-migrate-test.js  # 9 项（旧 JSON 迁进 SQLite + 保留期清理）
node test/storage-engine-test.js # 10 项（SQLite ↔ JSON 切换）
node test/gateway-e2e.js      # 18 项
node test/account-modes-test.js # 20 项（启用/自动连接/异常重连）
node test/config-site-repair.js  # 8 项
node test/auth-scope-test.js  # 10 项
node test/plugin-update-test.js # 12 项
node test/market-proxy-test.js # 49 项
node test/update-test.js      # 14 项
node test/update-api-test.js  # 5 项
node test/vlos-test.js        # 42 项（VloS）
node test/vsql-test.js        # 48 项（VSQL 内置 SQLite）
```

> 当前机器 PATH 里可能没有 `npm`；本项目**不需要 `npm install`**，所有测试/导出都能直接用 `node` / `powershell` 运行。`package.json` 里的 `scripts` 只是给有 npm 的环境用的快捷入口：
> `npm run test:all` = `node test/run-all.js`，`npm test` = 核心 + 网关，`npm run export` = 导出脚本。

### 12.3 假服务器

```powershell
# 假 QQ 服务器
node test/mock-qq.js 19100
# 面板设置：AppID=test_app，AppSecret=test_secret
# 高级配置里把 apiBase/tokenUrl/gatewayUrl 指向 http://127.0.0.1:19100

# 假聚龙账户由 test/mock-jlw.js 在测试进程内启动，不需要单独运行
```

测试会创建临时数据目录；`test/seed-plugins.js` 会给测试数据目录准备最小 `echo/status/el-sample` 夹具，所以**导出包不带示例插件也能跑完整回归**。导出脚本会排除 `test/.tmp-*`。

---

## 13. 部署与运维

### 13.1 本机 / 便携

- 整个目录拷走即可（含 `runtime` 和 `~JlWBoT`）。
- 只迁移数据：停服，拷 `~JlWBoT`。
- 无 Node 的 Windows x64：用内置 `runtime\node.exe`。

### 13.2 云服务器（Windows 推荐）

1. 整个目录复制到服务器；
2. 双击 `启动机器人.cmd -NoOpen`，或 `powershell -ExecutionPolicy Bypass -File tools\start-panel.ps1 -NoOpen`；
3. 推荐 SSH 隧道访问面板，不要直接暴露公网：
   ```bash
   ssh -L 8686:127.0.0.1:8686 用户@服务器IP
   ```
4. 要公网访问：`server.host=0.0.0.0` + 安全组/防火墙放行 8686；面板仍有聚龙账户登录，建议再加 IP 白名单；
5. **QQ IP 白名单**：到每个 AppID 后台添加服务器公网 IP，否则 `11298` 一直重连。

### 13.3 Linux

`.cmd` / `runtime\node.exe` 只适用于 Windows。Linux 安装 Node 18+：

```bash
node src/index.js --no-open
```

面板访问同样靠 `server.host` + 安全组或 SSH 隧道。

### 13.4 反向代理要点

- `/ws` 必须支持 `Upgrade`/`Connection`；
- `/qqbot/webhook` 不能改写请求体（验签签原始 body）；
- 面板可加 HTTPS 域名，但 WebHook 端口仍受 QQ 限制（80/443/8080/8443）；
- 开启 `server.trustProxy` 并正确传 `X-Forwarded-For`。

### 13.5 开机自启

- 任务计划程序：启动 `启动机器人.cmd -NoOpen`，起始目录为项目根；
- 隐藏窗口：用 VBS 调 `powershell -File tools\start-panel.ps1 -NoOpen`；
- 崩溃自愈：计划任务失败每分钟重启；框架内部有插件进程守护和网关重连。

### 13.6 端口

| 用途 | 默认 |
| --- | --- |
| 面板 / WebHook | `8686` |
| 面板 WebSocket | 同端口 `/ws` |
| WebHook 平台允许端口 | 80 / 443 / 8080 / 8443 |
| 假 QQ 服务器 | `19100` |
| 测试随机端口 | 18741+ / 18891+ / 19091+ 等 |

### 13.7 定时重启（v1.3.7+）

面板「设置 → 定时重启」：

(截图略)

- 开关 + 间隔分钟数（1–10080，默认 360 = 6 小时），保存后立即生效，不用重启进程。
- 到点执行**进程内重启**：拆掉账户/插件/面板再重新 boot，PID 不变、启动器窗口不会关，几秒内恢复。
- 重启会短暂断开网关（自动重连）、面板 WebSocket 会重连；`~JlWBoT` 数据不受影响。
- 配置项：`system.restart.enabled` / `system.restart.minutes`；`0` 或不启用表示关闭。
- 「立即重启」按钮等价于 `POST /api/system/restart`。
- 重启过程日志：`正在停用运行时（定时重启）…` → `重启完成：http://…`。

### 13.8 接口调用日志（v1.3.7+）

面板「设置 → 日志与存储」：

- **接口调用日志**（`log.api`，默认开）：每次 QQ API 调用一条 `方法 路径 → 状态 耗时`。
  - 成功 → **DEBUG** 级别（把日志级别调到 DEBUG 才显示，避免刷屏）；
  - 失败 → **WARN** 级别（默认 INFO 就能看到，带 `code=` 与接口返回的 message）；
  - 带 `traceId`（响应头 `x-tps-trace-id`）与第几次重试。
- **记录请求/响应内容**（`log.apiBody`，默认关）：额外记录请求体与响应体，`token/secret/authorization/password/cookie/key` 自动打码，单条截断 500 字符。
- 事件与插件分发也会留 DEBUG 日志：`收到事件 GROUP_AT_MESSAGE_CREATE（group）`、`事件 X 分发给 N 个插件`、`插件 echo 处理 X 完成 12ms`。
- 排查模板：日志级别临时调 `DEBUG` → 复现 → 面板「日志」页按 `api:` scope 过滤 → 看完调回 `INFO`。

### 13.9 机器人掉线 ≠ 面板掉线（v1.3.8+）
框架和机器人共用一个 Node 进程，但两者是**独立的两层**：

- **机器人连接层**：网关/Token/重连。掉线时只会变成 `reconnecting` / `cooldown`，面板照常工作。
- **框架层**：HTTP 面板、插件、数据、日志。`/health` 永远可答（账户模块抛错会降级返回 `accounts: 0`）。

保证这一点的机制：

- 网关所有事件经 `_emitSafe` 分发，Bot 回调经 `_guard` 包裹，账户事件转发也有隔离——机器人侧异常只进日志，不向框架冒泡。
- 重连用尽后进入冷却（默认 60 秒）继续下一轮，**不会退出进程**；只有 11298（IP 白名单）、4914/4915（下架/封禁）保持 fatal，等人工处理。
- 崩溃守卫只记录 `crash.log`，不再因为异常次数多而主动退出。

排查“面板打不开”时先分清三层：

| 检查 | 结果含义 |
| --- | --- |
| `curl http://127.0.0.1:8686/health` | 有 JSON：框架活着，问题在网络/隧道/防火墙；连不上：进程或端口问题 |
| `/health` 里的 `pid` 与 `tasklist` 对得上 | 对得上说明是同一个进程；对不上说明跑的是另一个实例 |
| `netstat -ano \| findstr 8686` | 有 LISTENING 才是真在监听；没有就是进程没起或被改端口 |
| 隧道（frp/ngrok/cloudflared） | 隧道客户端要指向 `127.0.0.1:8686`；只暴露面板时 `server.host` 保持 `127.0.0.1` 即可；要让同网段直连才改 `0.0.0.0` |

### 13.10 单实例与停止（v1.4.1+）

**为什么会“关了还在发消息”**

| 场景 | 是否还在跑 |
| --- | --- |
| 默认 `启动机器人.cmd`，关闭 CMD 窗口 | 否：node 挂在控制台上，窗口关闭会一起结束 |
| `启动机器人.cmd -Background` 隐藏启动后关窗口 | **是**：后台实例故意脱离控制台，需要 `结束进程.cmd` |
| 开了两个 CMD / 两个安装目录 | 是：两个进程各连一个网关，会重复回消息 |
| 用面板「定时重启」/「立即重启」 | 同一个 PID 重启，不会多出进程 |

**单实例锁**

- 启动时检查 `~JlWBoT/run.pid`；锁里的 PID 还活着且不是自己 → 直接退出，提示“已有另一个 JlWBoT 实例在运行（PID xxx）”。
- 进程崩溃/强杀留下的锁：PID 不存在时自动接管，不用手动删。
- 确认旧进程已死仍被拦：`node src/index.js --force`，或直接运行 `结束进程.cmd`。
- 锁只在数据目录维度生效；两个不同 `--data-dir` 的实例互不影响（但同一个机器人 AppID 仍会双连，别这么跑）。

**结束进程（唯一入口）**

```powershell
.\结束进程.cmd
# 或
powershell -NoProfile -ExecutionPolicy Bypass -File tools\stop-all.ps1
```

它会按顺序做：

1. 先写 `~JlWBoT/stop.flag`：启动器看到这个标记就不再自动重启；
2. 结束**启动器**（`powershell tools\start-panel.ps1`，即自动重启的源头）；
3. 结束所有 `node src\index.js`（前台 / `-Background` 隐藏都算），`taskkill /T /F` 连同插件子进程（DLL 宿主、EXE 插件）一起结束；
4. 按 `~JlWBoT/config.json` 的面板端口兜底，清掉路径不同的副本；
5. 删除 `~JlWBoT/run.pid`，确认端口已释放，并打印每个被结束进程的命令行摘要。
6. 多轮扫描（最多 4 轮），防止“杀掉又被拉起来”。

只想清当前项目、不碰别的 JlWBoT 副本：`powershell -File tools\stop-all.ps1 -ProjectOnly`。下次运行 `启动机器人.cmd` 会自动清掉 `stop.flag`。

**为什么会“关了还在发消息”**

- 默认 `启动机器人.cmd` 是前台模式，关 CMD 窗口会一起结束；但如果之前用过 `-Background`（隐藏窗口），那个实例不受当前窗口影响，必须用 `结束进程.cmd`。
- 只杀 node 不够：启动器 `start-panel.ps1` 还在，会自动重启 node。所以 `结束进程.cmd` 先杀启动器、再写 `stop.flag`，确保不会复活。
- 同一台机器跑了两份（旧目录 + 新目录）也会各连一个网关，表现为重复回复；单实例锁只对**同一个数据目录**生效，跨目录副本由按端口兜底清理。

**插件报错不往聊天发**

- VloS / Arknights / mcstatus 的未捕获异常、接口错误只写框架日志（SQLite `logs` 表与面板「日志」），不会在群聊/私聊回复错误信息。
- `UserError` / `ServiceError` 这类“用法提示”（例如缺少参数）仍会正常回复，方便用户操作。

### 13.11 插件回复闸门（v1.4.4+）

框架只拦截**带统一前缀的报错文案**，其余回复（含欢迎语、卡片、连续多条）全部原样放行：

| 配置 `plugins.replyGuard` | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | `true` | 总开关 |
| `blockErrors` | `true` | 是否拦截带前缀的报错 |
| `errorPrefix` | `【[404 error]` | 报错前缀（插件按此开头拼报错） |

- 约定：插件报错文案统一写成 `【[404 error] 具体报错内容】`；框架看到这个前缀就丢弃并写日志，不再往群聊/私聊发。
- **不再限频、不再去重**（v1.4.3 的 800ms / 20 条每分钟 / 60s 去重已删除）：它们会误伤进群欢迎、连续指令回复等正常消息。
- 覆盖所有插件出口：`reply` / `replies`、`actions.reply`、`send_group_message` / `send_c2c_message` / `send_channel_message`、`ctx.api.send*`、`ctx.bot.send*`。
- 被拦时日志关键词：`插件的报错文案已拦截（只写日志）`，meta 里有 `target` 与 `sample`。
- 插件里可用 `ReplyGuard.errorText(msg)`（或自行拼同样前缀）生成报错文案；正常提示不要加前缀。
- 详见 [docs/插件开发.md](docs/插件开发.md)。

---

## 14. 数据、备份与安全

### 14.1 数据目录

```text
~JlWBoT/
├─ jlwbot.db                   SQLite 主库（配置/会话/日志/消息；WAL 模式）
├─ config.json                 配置镜像（方便查看/手改；改完重启会导入数据库）
├─ data/
│  └─ ...                      插件/其他运行时数据
├─ logs/
│  ├─ crash.log                崩溃记录（纯文本）
│  ├─ heartbeat.json           心跳
│  └─ stderr.log / stdout.log  启动器重定向输出
├─ plugins/
│  ├─ <id>/plugin.json
│  ├─ <id>/data/...
│  └─ ...
├─ backup/
│  ├─ legacy-json-<时间>/      从旧版升级时移过来的 JSON/JSONL（保留回滚）
│  └─ config-*.json            配置备份
└─ updates/                    在线更新 zip/日志/备份（懒创建）
```

### 14.2 存储与保留策略

- 主存储：`jlwbot.db`（Node 内置 `node:sqlite`，零 npm 依赖）。表：`kv`（配置）、`sessions`（面板会话）、`logs`（运行日志）、`messages`（收发消息）。
- 首次用 v1.5.0 启动会把旧的 `config.json`、`data/sessions.json`、`logs/jlwbot-*.jsonl`、`data/messages-*.jsonl` 导入 SQLite，旧文件移到 `backup/legacy-json-<时间>/` 保留（不会重复导入）。
- `config.json` 仍会随保存更新，作为可读镜像；手动改它之后重启，会检测 mtime 并把新内容导入数据库。
- 日志：保留 `log.keepDays`（默认 7 天）——统计/清理按天，SQLite 内按 `day` 字段查询。
- 消息：`storage.messages` 控制是否入库；面板历史消息按日期查询，单次最多 2000 条。
- 存储方式：`storage.engine = sqlite | json`，默认 SQLite；面板「设置 → 日志与存储」可切换，切换时把配置/会话/日志/消息迁移到目标格式并自动重启。
- 事件内存环：`storage.events` 默认 500（不落盘）。
- 更新备份：最近 2 个 `backup-*`。

### 14.3 安全

- 默认只监听 `127.0.0.1`。
- 面板登录走聚龙账户；密码只在登录瞬间提交，不写入本机。
- 登录范围白名单：只有 `auth.allowed` 中的账户能登录；新增/移除即时生效，移出账户的旧 HTTP 会话失效。
- `config.json` 含 AppSecret / 插件 token；`jlwbot.db` 里也有同样的配置和会话（含上游 token）；不要提交/分享，注意数据目录权限。
- 面板 API 返回的 secret/token 会打码（`******` / `hasSecret`）。
- Cookie `jlw_sid` HttpOnly、SameSite=Lax。
- CSP、`X-Content-Type-Options: nosniff`、Referrer-Policy。
- 登录限流：IP 10 次/分钟、邮箱 5 次/10 分钟。
- 插件可调用所有 API，只安装可信插件。
- 在线更新只允许聚龙域名/同域下载；校验 zip/版本；更新器不执行包内脚本。

### 14.4 备份/迁移

1. 停服（退出时 SQLite 会 checkpoint，目录里只留 `jlwbot.db`，不再有 `-wal`）；
2. 备份整个 `~JlWBoT`（`jlwbot.db` + 插件 + 备份目录一起带走）；
3. 拷贝项目目录（不含 `~JlWBoT` 也可）到新机器；
4. 把 `~JlWBoT` 放回项目根；
5. 启动，检查 `/api/session` 的站点与版本。

> 运行中直接拷贝的话，要连 `jlwbot.db-wal` 一起拷（`-shm` 可重建），或者先停服；Windows 上数据库文件被占用时复制会失败，属正常。

---

## 15. 故障排查

| 现象 | 处理 |
| --- | --- |
| 启动即退出 | 看控制台错误；`node --check src/index.js`；确认 Node 18+ |
| 端口被占用 `EADDRINUSE` | 换端口或结束占用：`netstat -ano | findstr 8686` |
| 面板打不开 | 服务是否就绪；防火墙；`host` 是否 `127.0.0.1` 而你在另一台机器 |
| 登录页「账户站点 未配置」 | v1.3.2 会自动修复；确认 `~JlWBoT/config.json` 的 `jlw.baseUrl`；或删掉让默认值重建 |
| 登录 `ECONNRESET` / 连 127.0.0.1 | 旧配置把站点指到本机；v1.3.2 启动会自愈；本地 mock 才设 `JLW_ALLOW_LOCAL_SITE=1` |
| 登录提示「无法连接聚龙账户服务」 | 站点地址/协议错误、站点不可用、自签名证书未勾「跳过证书校验」 |
| 登录提示「接口不存在」 | 站点没有启用聚龙账户插件，或 `apiPath` 不对 |
| 登录一直密码错误 | 用聚龙世界账户，不是机器人 AppSecret |
| 一直「未配置」 | 没填 AppID/AppSecret，或保存后没重启 |
| 「鉴权中」卡住 | 出站被拦、AppID 不匹配、IP 白名单；看日志 token 错误码 |
| `11298` / IP 不在白名单 | 公网 IP 变了；到 QQ 开放平台给每个机器人加当前 IP，或关白名单后重连；框架会停止自动重连避免限频 |
| `40023001` / 调用超频 | 反复获取 `/gateway` 或重连触发；等几分钟，不要连续重启；框架有缓存/退避 |
| 网关 4013/4014 | 订阅了无权限 Intent；到「连接」取消勾选后重连 |
| 日志出现 `4009 连接过期` | v1.4.0 起自动清 session 重新 Identify；升级前会一直 Resume 失败到冷却。频繁 4009 说明 token/网络频繁抖动，看 `gateway:` 日志 |
| 被动回复 40034024 | `msg_id` 失效（超过 5 分钟）或不属于本消息 |
| WebHook 验证不过 | 端口必须 80/443/8080/8443；HTTPS；AppSecret 正确；代理不能改 body |
| 多账户 WebHook 收不到 | 每个账户分别填 `/qqbot/webhook/<id>` |
| 定时重启 / 手动重启后账户没连上 | 看启动日志「账户池加载完成」：写了跳过原因（已停用 / 未开启自动连接）；到「账户 → 编辑」把「启用」「自动连接」打开再重启 |
| 掉线后不自动重连 | 「账户 → 编辑 → 异常重连」被关了；打开后立即补连，或点「重连」 |
| 公网 IP 获取失败 | 本机离线/探测源不可达；不影响机器人 |
| 改端口不生效 | 端口需重启；其余配置即时 |
| 易语言拉取为空 | 插件 `events`/`commands` 没匹配；面板「测试」发模拟事件 |
| 中文乱码 | 全链路 UTF-8；易语言用 `编码_URL编码(..., 真)` |
| 更新按钮不出现 | 页面最新版本 <= 本机版本；当前页面是 v1.3.4，本机 v1.4.15；等页面发布更高版本 |
| 更新提示「更新包版本 1.3.3 与页面版本 1.3.4 不一致」 | 页面上的 zip 内部 `package.json` 还是 1.3.3（包名写错）；重新上传正确版本的 zip |
| 突然不回复、没日志、面板也打不开 | 先看控制台标题是否带「选择」：带就是快速编辑把进程冻住了，按 Esc 或点一下窗口即可恢复；`启动机器人.cmd` 已自动关闭快速编辑 |
| 进程真的没了 | 看 `~JlWBoT/logs/crash.log`（未捕获异常/退出码）、`~JlWBoT/logs/heartbeat.json`（最后心跳）、`~JlWBoT/logs/jlwbot-*.jsonl`；启动器会自动重启，`/health` 有 `pid`/`lastCrash` |
| 面板端口中途失效 | v1.3.6 起看门狗会自动重新 listen；日志里搜「HTTP 服务已自动恢复」；反复 EADDRINUSE 说明端口被别的程序占用 |
| 更新下载失败 | 页面/网络/域名白名单；看日志 `update`；手动下载 zip 替换 |
| 更新后没重启 | 看 `~JlWBoT/updates/update.log`；手动运行 `启动机器人.cmd`；确认端口没被旧进程占用 |
| 更新后旧版本还在 | 可能只是页面缓存/没刷新；看 `/health` 版本；检查安装目录 |
| PowerShell 中文乱码/解析错误 | `.ps1` 保存为 UTF-8 with BOM；`.cmd` 用 ASCII+CRLF |
| 配置改了不生效 | 端口需重启；`config.json` 是否被 BOM/JSON 语法破坏；看启动日志 |
| 插件设置页打不开 | 插件目录有 `settings.html`；面板插件详情「设置」；看 CSP/控制台 |
| 插件导入失败 | 单文件 ≤18MB、总量 ≤60MB、非 ZIP64/加密；根目录或单层子目录有 `plugin.json` |

更多部署/排错：[docs/部署与脱机运行.md](docs/部署与脱机运行.md)。

---

## 16. 开发约定与代码地图

### 16.1 硬约束

- **零第三方依赖**：只用 Node 内置模块；不要引入 npm 包/CDN。
- **CommonJS**：`require` / `module.exports`；不用 ESM。
- **数据目录**：所有运行期写入走 `U.dataRoot()` / `U.p()`；不要把数据写进 `src/`。
- **路径**：用 `path.join`；Windows 路径含空格/中文要加引号。
- **日志脱敏**：不要打印 AppSecret/token/密码；Logger 会打码常见字段。
- **前端无构建**：直接编辑 `src/web`；不要加打包步骤。
- **PowerShell 编码**：含中文的 `.ps1` 必须 UTF-8 BOM；`.cmd` 用 ASCII + CRLF。
- **导出**：不要把 `~JlWBoT`、测试临时目录、根目录 zip 打进包。
- **文档**：改动后更新本 README 对应章节；上下文会被压缩，不要只依赖对话记忆。

### 16.2 常用扩展点

**加一个面板 API：**

1. 在 `src/core/server.js` 的 `_registerRoutes()` 里加 `R('GET', '/api/xxx', async (req,res,{url,body,params}) => {...})`；
2. `/api/*` 自动走登录鉴权（除登录白名单）；
3. 返回 `{ok:true,...}` 或 `{ok:false,error}`；
4. 前端 `src/web/app.js` 用 `api('/api/xxx')` 调用；
5. 加测试，重建导出。

**加一个配置字段：**

1. 改 `config.default.json`；
2. 如需面板保存，把顶层键加入 `Config.update()` 的 `allowed`；
3. 读取用 `config.get('xxx', default)`；
4. 敏感字段在 `publicConfig()` 打码；
5. 旧配置通过深合并自动补默认值。

**加一个插件类型/能力：**

1. `src/core/plugins.js` 的 `VALID_TYPES` / 启动逻辑；
2. `src/core/bot.js` 的动作执行；
3. 插件协议文档 `docs/插件开发.md`；
4. 测试 `test/`；
5. 注意 32 位 DLL 必须独立宿主。

**改在线更新：**

1. 更新页解析 `src/core/updater.js`；
2. 安装逻辑 `src/core/update-apply.js`；
3. 面板路由 `src/core/server.js`；
4. 前端 `src/web/app.js` + `style.css` + `index.html`；
5. 跑 `node test/update-test.js && node test/update-api-test.js`；
6. 发版必须高于当前版本，页面文件名带版本号。

### 16.3 关键约定

- `U.ROOT` 是项目根（`src/core/util.js` 向上两级）。
- `U.dataRoot()` 读取 `JLW_DATA_DIR`，否则 `<ROOT>/~JlWBoT`。
- `U.p(...)` 拼接数据目录。
- `U.readJson` 去 BOM；`U.writeJson` 原子写。
- `Config.publicConfig()` 是面板唯一可见配置；不要直接返回 `config.data`。
- 所有账户操作走 `AccountHost`，不要直接操作 `Bot`。
- 所有 QQ API 调用走 `Bot`/`api.js`，自动带账户 token。
- 平台事件先 `normalizeEvent()`，再进插件。
- 插件返回统一由 `Bot.executePluginResult()` 处理。

### 16.4 发版约定（每次改动都要改版本）

只要改动会进导出包，**发版前必须改版本号**，不要用同一个版本号反复覆盖导出包：

1. `node tools/bump-version.js <新版本>`：自动同步 `package.json`、侧边栏品牌版本、文档页适用版本、`docs/插件开发.md`、部署文档的升级说明、README 的当前版本/导出包名；跑完会打印还需要手工补的项。
2. 手工补：README「17. 变更记录」加一条（写清改了什么）、测试数字（0.3 快照 / 12.1 合计 / 12.2 命令）、`框架导出/` 历史列表。
3. `node test/run-all.js` 全量回归。
4. `powershell -NoProfile -ExecutionPolicy Bypass -File tools\export-framework.ps1` 导出成品包 `框架导出\JlW-BoT [vX.Y.Z].zip`（默认不含 `test/`、`docs/images/`、开发工具；要完整源码包加 `-Full`）。
5. 云端/其他机器用新包覆盖程序文件（**保留 `~JlWBoT`**），重启后确认侧边栏版本号。

> 面板侧边栏与 `/health` 的版本都取自 `package.json`，在线更新也按它比较，所以版本号只能递增。

---

## 17. 变更记录

### 插件 VSQL 1.0.3（2026-11-24）

- **群聊里发 `/vsql` 没反应**：这是默认行为——VSQL 原来只订阅 `C2C_MESSAGE_CREATE`，群里的事件根本不会分发给它。新增可选开关 `admin.groupEnabled`（设置页「管理指令 → 允许在群里使用」，默认关）：打开后订阅 `GROUP_AT_MESSAGE_CREATE` / `GROUP_MESSAGE_CREATE`，群里（建议 @机器人）也能用 `/vsql`，且仍然只认 `admin.openids`，非管理员完全静默。
- 群里查询结果全群可见，默认关闭以避免数据暴露；私聊行为不变。
- 自测扩到 **48 项**（新增：群聊默认静默、开启后管理员可用、非管理员静默）。交付包 `插件\VSQL-【v1.0.3】.zip`。
### 插件 VSQL 1.0.2（2026-11-23）

- **设置页新增「数据浏览」**：列出所有命名空间里的所有表（名称 + 行数 + 列结构），选中表即可查看前 N 行；支持切换库/表、输入框本地过滤行、表头显示列类型与主键。
- **只读快照**：sandbox iframe 读不到文件系统、也发不出请求，所以插件在 `onLoad` 时把表清单与样例行注入 `settings.html` 的 `#vsql-data`（与 `#vsql-runtime` 并列，`<` 已转义，不含 HTTP 令牌）。
- **敏感列打码**：列名匹配 `token / secret / password / passwd / sid / session / credential / api_key` 时值显示 `***`（`settingsPreview.redact`，默认开）。
- **有上限**：默认 8 个库 × 15 张表 × 每表 10 行，快照 JSON 200 KB 预算；超出只列结构并在页面标注；单元格 120 字符截断。内部表 `__vsql_*` 不展示。
- **刷新数据**：按钮会用当前已生效配置触发一次插件重载（未保存的表单修改不会写入），重载后自动刷新页面；全量查询仍走 `/vsql sql` 或 HTTP 网关。
- **修复「更新插件」失败（EPERM / 插件不存在）**：根因是 `onUnload` 里先 `await http.stop()` 再关库，框架删除插件目录时 SQLite 文件仍被占用，`fs.rmSync` 报 `EPERM`；回滚又因 rm 抛错跳过 `reloadAll()`，插件会从注册表消失。现在 `onUnload` 先同步 `closeAll()` 关库，再发起 HTTP 关闭（不 await），实测 `POST /api/plugins/VSQL/update` 返回 200、数据保留、网关回到 8787。
- 自测扩到 **48 项**（预览构建：表清单/行数/10 行上限/敏感列打码/中文列名/内部表过滤；快照注入只写副本且运行时快照共存）。交付包 `插件\VSQL-【v1.0.3】.zip`。
### 插件 VSQL 1.0.1（2026-11-23）

- **设置页显示完整数据目录**：「存储 → 数据目录」输入框下方新增「完整路径」一行，显示从盘符开始的绝对路径（如 `C:\Users\...\~JlWBoT\plugins\VSQL\data\dbs`），随输入实时重算，带「复制」按钮。实现方式：插件 `onLoad` 把 `{ version, pluginDir, dataDir, defaultNamespace, http }` 写入 `settings.html` 的 `#vsql-runtime` 快照（sandbox iframe 读不到文件系统，只能由插件注入）；新增 `config.injectSettings`（默认 `true`）可关闭；自测只在临时副本上验证，不写源码模板。
- **表结构完全开放**：新增 `createTable / renameTable / addColumn / renameColumn / dropColumn`（表封装上也有同名方法）；表名/列名从 `[A-Za-z_]` 放宽到中文/字母/数字/下划线/短横线（仍统一双引号包裹、值全部占位符），`where`/`order` 的键解析同步支持中文。VSQL 只提供 SQLite 能力，不预设任何业务表。
- **跨插件共享表（默认）**：`vsql.db()` 不传参数 = 默认 `shared` 库，所有插件同一文件，A 建的表 B/C 直接 `SELECT`（无归属限制）；新增 `vsql.tables(ns?)`、`vsql.findTable(name)`（跨命名空间找表）。要私有数据仍可 `vsql.db('私有ns')`，文档改为「共享为默认、隔离为可选」。
- 自测扩到 **43 项**（新增：中文表名/列名、建/改/删表 API、跨插件 shared 读写、findTable、设置页快照只写副本/幂等）。
- 交付包更新为 `插件\VSQL-【v1.0.1】.zip`；运行副本 `~JlWBoT/plugins/VSQL` 已同步，**当前 8686 实例仍需「插件 → 重新加载」**才能看到 v1.0.1。

### 插件 VSQL 1.0.0（2026-11-23）

- **新增内置插件 `VSQL`：框架级的 SQLite 数据库服务**，其他插件不再各自写 JSON / 各自 `require('node:sqlite')`。源码 `plugins/VSQL/`，运行副本 `~JlWBoT/plugins/VSQL/`；完整说明 [plugins/VSQL/README.md](plugins/VSQL/README.md)，接口文档 `api.html`。
- 调用方式：`globalThis.__JLWBOT_PLUGIN_APIS__?.get('VSQL')` → `db(ns)`；**一个命名空间一个 `.db` 文件**（默认 `<插件目录>/data/dbs/<ns>.db`），插件之间互不串表；`readOnly` / `memory` 可选。
- 能力：原生 `exec/run/get/all/value/column/prepare/tx`（事务可嵌套 SAVEPOINT，async 函数会被拒绝并回滚）；行封装 `table/insert/insertMany/upsert/update/del/select/count/exists`（表名列名白名单 + `?` 占位符 + `where` 操作符 / `$and` / `$or`）；结构 `tables/columns/indexes/schema/hasTable/dropTable`；迁移 `migrate`（`PRAGMA user_version`，只跑新版本）；`kv`；`backup`（在线备份到 `data/dbs/backups/`）、`vacuum/checkpoint/info`。
- 安全默认值：命名空间/标识符严格校验；`ATTACH/DETACH` 默认禁用（`allowAttach=false`）；管理指令默认只读；HTTP 网关只监听 `127.0.0.1` 且必须 Bearer 令牌。
- **可选本机 HTTP 网关**（默认开，`127.0.0.1:8787`，端口占用自动 +1…+5）：`POST /query`（`mode=all|get|value|column|run|exec`）、`POST /exec`、`POST /backup`、`GET /namespaces|/info|/health`；令牌自动生成到 `data/dbs/http-token.txt`。给易语言 / pull / process 插件与外部程序用，JS 插件用进程内 API 即可。
- **私聊管理指令 `/vsql`**（只订阅 `C2C_MESSAGE_CREATE`，命令白名单 `vsql`）：`stats / list / tables <ns> / schema <ns> / sql <ns> <SQL> / backup [ns] / token`；`admin.openids` 为空时谁都不能用，首次私聊发 `/vsql` 会把本人 OpenID 回给自己，方便填进设置页；非管理员静默忽略。
- 设置页（`settings.html`）可改数据目录、默认命名空间、最大打开数、busy_timeout、自动建库、ATTACH 开关、HTTP 网关与管理员 OpenID；保存后插件自动重载。
- 自测 `node test/vsql-test.js` **38 项全过**（含 HTTP 网关全链路、卸载后端口关闭与注册表移除）。运行中的 8686 实例**尚未重载**：面板「插件 → 重新加载」或重启后才会出现 VSQL 卡片。

### v1.6.4（2026-11-24）

- 许可证由 MIT 改为 **BSD 3-Clause**：仍然允许商用、修改、再分发，但新增“不得用作者/贡献者名义为衍生品背书”的限制。
- 成品包开始附带 `LICENSE`（BSD 3-Clause 全文）；`package.json` 的 `license` 字段同步为 `BSD-3-Clause`。功能与 v1.6.3 相同，主回归 22 个文件 442 项不变。

### v1.6.3（2026-11-24）

- **消息预览清理腾讯自定义 markdown**：`<qqbot-cmd-input ... />` / `<qqbot-cmd-enter ... />` 不再原样显示；标签里 `show` / `text` 的百分号编码会解码成中文（`%E8%8F%9C%E5%8D%95` → `菜单`）。菜单列表里保留为普通文字（如「群管：进退群提示」），单独成行的命令快捷入口（欢迎语里常见）直接隐藏，不再出现一排“蓝字”标签。
- `<qqbot-at-user id="..." />` 显示为 `@用户`，不暴露 OpenID；其它 `qqbot-*` 自定义标签不显示。`***` 现在按 Markdown 分隔线渲染，不再是字面量。
- 新增 2 项预览测试（中文解码/标签隐藏/分隔线、行内命令标签），`test/message-preview-test.js` 共 **18 项**；主回归 22 个文件 **442 项**。

### v1.6.2（2026-11-24）

- **消息详情新增「消息预览」**：消息页点开任意一条消息（包括机器人自己发出的），抽屉顶部先显示「消息预览」再显示原始字段。文字按聊天气泡排版；Markdown 消息渲染成成品（标题、列表、加粗、行内代码、链接）；图片附件直接显示缩略图，点击可看原图；卡片消息还原标题、描述与按钮样式。原始报文仍保留在下方，方便排查。
- **特殊消息结构解析**：`raw.ark_data`（群公告等 ark 消息）会解析出标题与正文；带 `[群公告]` 前缀的文本自动拆成公告卡；控制字符会清理，未知卡片显示占位说明，不再是空白。
- **安全**：先转义 HTML 再套渲染，链接只放行 `http(s)` 与 `data:image`，`javascript:` 等危险地址不渲染；避免消息内容在面板里执行脚本。
- **Markdown 里的图片/链接不会被二次包链接**：旧消息常见 `![图片说明](https://…)`，先生成 `<img>` 再自动识别 URL 会把标签属性包进 `<a>` 导致破版；现在先占位再还原，图片、链接、加粗可以同时正常显示。
- **机器人发出的消息可回放**：发送时把原始请求体存进 SQLite `messages.payload`（JSON 引擎同样写入 JSONL），历史消息也能按当时的 markdown / 卡片 / 富媒体还原；旧库启动时自动补 `payload` 列，老消息退回按文本预览。SQLite → JSON 切换也会带上 payload，不会因为换存储引擎丢预览。
- 新增 `test/message-preview-test.js` 16 项并加入主回归；顺带修正网关端到端对同一 `msg_id` 多次回复的 `msg_seq` 断言（内置指令先回复过时序号应递增，而不是固定 1）。`db-migrate-test` 增加 payload 导入断言（9 项）、`storage-engine-test` 增加 JSON 引擎 payload 读回（10 项），主回归 22 个文件 440 项。

### v1.6.1（2026-11-24）

- 日志/消息页的日期选择框统一成面板主题样式（`input[type=date]` 深色/浅色自适应、边框与搜索框一致、去掉原生白底突兀感），高度和字号也对齐。
- 日期框移到搜索框后面，和「今天」按钮放进同一个不换行的小组：顺序固定为「搜索 → 日期 → 今天」；窄屏时整组一起换行，不会把日期单独挤到下一行最左边。
- 纯前端调整，主回归仍为 21 个文件 422 项。

### v1.6.0（2026-11-24）

- **存储方式可选**：设置 →「日志与存储」新增「存储方式」下拉——`SQLite`（`~JlWBoT/jlwbot.db`，默认）/ `JSON · JSONL 文件`。保存后自动把配置、面板会话、日志、消息迁移到目标格式并重启（`POST /api/storage/engine`）。
- 新增 `src/core/json-store.js` + `src/core/store.js`：按 `storage.engine` 分发后端；JSON 后端写 `config.json`、`data/sessions.json`、`logs/jlwbot-*.jsonl`、`data/messages-*.jsonl`，SQLite 后端沿用 v1.5 的四张表。
- 双向迁移：SQLite → JSON 按天导出 JSONL 并写 `sessions.json`；JSON → SQLite 先清空业务表再重新导入（旧文件移到 `backup/legacy-json-*`）。`config.json` 里保存 `storage.engine`，重启时按它选后端，不需要手改代码。
- 两种引擎下，面板「日志 / 消息」的按日期查询、下载、保留期清理都可用。
- 新增 `test/storage-engine-test.js`（9 项：SQLite↔JSON 双向切换、config.json 记录引擎、JSON 引擎写 JSONL、两边都能按日期查日志、重启后引擎正确），主回归 21 个文件 422 项。

### v1.5.1（2026-11-24）

- SQLite 历史数据按保留策略清理：启动时、以及每 6 小时按 `log.keepDays`（默认 7 天）删日志、按 30 天删消息，并顺带 `wal_checkpoint`，避免数据库无限增长；迁移前已有的旧 JSONL 也已经导入，清理同样生效。
- `test/db-migrate-test.js` 加到 8 项（新增「按保留天数清理过期日志」），主回归 20 个文件 413 项。
- 已把本机 `~JlWBoT` 真实迁移到 SQLite：`jlwbot.db` 4.3MB（日志 2.1 万条、消息 2691 条、面板会话 1 个），旧文件在 `~JlWBoT/backup/legacy-json-2026-11-24T05-27-39/`。

### v1.5.0（2026-11-24）

- **存储改为 SQLite**：新增 `src/core/db.js`（Node 内置 `node:sqlite`，仍然零 npm 依赖），`~JlWBoT/jlwbot.db` 里存 `kv`（配置）、`sessions`（面板会话）、`logs`（运行日志）、`messages`（收发消息）。
- 首次启动自动迁移旧数据：`config.json`、`data/sessions.json`、`logs/jlwbot-*.jsonl`（含大小轮转分片）、`data/messages-*.jsonl` → SQLite；旧文件移到 `~JlWBoT/backup/legacy-json-<时间>/` 保留，`legacy_imported` 标记保证不会重复导入。
- `config.json` 仍随保存更新，作为可读镜像；手动改它之后重启会按 mtime 检测并导入数据库，不会出现「改了没生效」。
- 日志/消息不再写 JSONL：面板「日志 / 消息」按日期查询改为查库（更快，不用扫文件）；日志下载导出所选日期的 NDJSON。
- 退出时自动 `wal_checkpoint(TRUNCATE)`，目录里只留一个 `jlwbot.db`，整目录拷走即可迁移；运行中拷贝要连 `jlwbot.db-wal` 一起拷（或先停服）。
- 新增 `test/db-migrate-test.js`（8 项：导入一次、合并分片排序、旧文件搬 backup、二次启动不重复、按保留天数清理），`test/history-view-test.js` 改为验证 SQLite 查询；主回归 20 个文件 413 项。

### v1.4.16（2026-11-23）

- **日志页新增日期选择**：除了实时日志，还能选任意一天看历史日志（读 `~JlWBoT/logs/jlwbot-YYYY-MM-DD.jsonl`）；当天文件因大小轮转会拆成 `jlwbot-YYYY-MM-DD-<时间戳>.jsonl`，接口会按日期合并分片再按时间正序返回。「今天」按钮回实时；历史模式下实时推送自动暂停，下载按钮下载所选日期。
- **消息页新增日期选择**：同上，读 `~JlWBoT/data/messages-YYYY-MM-DD.jsonl`，能看历史收发消息、区分机器人发出的消息，支持按账户筛选；每次最多读 2000 条。
- 新增接口：`GET /api/logs/dates`、`GET /api/messages/dates`（可用日期+大小）、`GET /api/logs?date=`、`GET /api/logs/download?date=`、`GET /api/events?date=`。
- 消息写入 JSONL 时补上 `accountId` / `accountName`，历史消息能显示归属账户（老文件没有这两个字段，显示为空）。
- **左侧栏顺序调整**：概览 → 账户 → 连接 → 插件 → 市场 → 消息 → 日志 → 接口 → 设置。
- 新增 `test/history-view-test.js`（13 项：日期列表合并轮转分片、按日期读、级别筛选、账户筛选、机器人消息识别、未登录 401），主回归 405 项。

### v1.4.15（2026-11-23）

- **修复「上传插件失败：zip 目录越界」**：市场代理之前把请求体按 UTF-8 转成字符串再转发，zip 是二进制，转码后文件就坏了；现在在读取 body 之前分流 `/market-proxy/*`，**直接流式转发**（保留 `Content-Length`，超时 5 分钟，支持市场 200 MB 上限），测试用 4 KB 全字节 + SHA256 断言内容一字不差。
- **市场 iframe 地址带面板版本号**（`/market-proxy/?v=1.4.15`）：面板升级后 iframe 一定重新加载，不再命中 bfcache/旧页面——之前「栏目 UI 没到、页面还是旧的」多半是这种缓存。
- 实测（真实市场 + 模拟面板）：首页点「上传插件」后 `#viewFrame` 切到 `/market-proxy/developer.html`，标题「开发者中心 · JlW-BoT 插件市场」，二级栏目「我的插件 / 上传新插件 / api上传 / 管理员」都在，外层顶栏高亮同步为「开发者中心」；内层页面自己的顶栏按 `embedded` 规则隐藏，不会出现双顶栏。
- `test/market-proxy-test.js` 扩到 49 项（新增上传二进制长度一致、SHA256 一致），主回归 392 项。

### v1.4.14（2026-11-23）

- **「开发者中心」点击彻底兜底**：不再依赖市场 `shell.js` 的路由。代理在外壳页注入一小段脚本，在捕获阶段接管 `a[data-view]` 点击，直接切 `#viewFrame`（`data-view` 已是代理路径），并同步顶栏高亮、标题、地址栏；Ctrl/⌘/Shift/中键点击仍按默认新标签打开（用户已验证这条路能开）。
- 之前就算路径改写正确，浏览器缓存旧 `shell.js` 时 `load()` 仍会把 `developer.html` 退回首页；现在市场脚本新/旧都能点开。内层视图不会重复注入。
- 实测：模拟面板 iframe 加载真实市场，把 `a.onclick` 清空（模拟旧脚本）后点「开发者中心」，`#viewFrame` 仍切到 `/market-proxy/developer.html`，标题「开发者中心 · JlW-BoT 插件市场」，顶栏高亮同步。
- `test/market-proxy-test.js` 扩到 47 项（新增栏目点击补丁注入、内层视图不重复注入），主回归 390 项。

### v1.4.13（2026-11-23）

- **点左上角图标检查更新**：点侧边栏品牌区（logo + 版本号）会强制查一次更新（`/api/update/check?force=1`，绕过服务端缓存）；发现新版本直接弹更新框，已是最新则 toast 提示。品牌区加了 hover 效果和「点击检查更新」提示。
- **设置页新增「版本与更新」卡片**：显示当前版本 / 更新页最新 / 上次检查时间，提供【检查更新】【下载并重启】【打开更新页】。检查完只就地刷新卡片，不重渲染整页（不会丢还没保存的设置输入）。
- 手动检查会显示具体失败原因（网络、证书、页面解析等），不再静默；更新页版本不高于本机时会提示「更新页最新 vX，不高于本机」，避免误以为检查坏了。
- 更新源仍是 `https://www.jlworld.net/QQBOT`；实测该页当前最新是 v1.4.12（能解析到 `JlW-BoT [v1.4.12].zip`），只有页面版本**高于**本机才会提示更新。

### v1.4.12（2026-11-23）

- **修复「开发者中心点了回首页」升级后仍复现**：根因是浏览器缓存。市场脚本带 `ETag + Cache-Control: no-cache`，代理虽然重写了 `shell.js`（补上 `/market-proxy/developer.html` 路由），但浏览器带 `If-None-Match` 请求时上游回 304，浏览器继续用**改写前的旧 shell.js**，里面没有 developer 路由，`load()` 查不到就退回首页。
- 代理层：不再转发 `If-None-Match` / `If-Modified-Since`；所有改写过的文本响应（HTML/CSS/JS/JSON）强制 `Cache-Control: no-store` 并删掉 `ETag` / `Last-Modified` / `Expires`，升级后不会再跑到旧脚本。
- 实测：带旧 ETag 请求 `/market-proxy/assets/shell.js` 返回 200 + `no-store`，内容含 `/market-proxy/developer.html` 路由；模拟点击「开发者中心」后 viewFrame 切到 `developer.html`，标题「开发者中心 · JlW-BoT 插件市场」。
- `test/market-proxy-test.js` 扩到 46 项（新增：带 `If-None-Match` 仍返回完整 JS、`no-store` 且无 ETag、条件请求头不转发），主回归 388 项。

### v1.4.11（2026-11-23）

- **API 文档补上插件市场上传接口**：`docs/API接口.md` 文末新增「插件市场上传 API（VloSBoT 插件市场）」——令牌生成/重置与安全提醒、请求体必须是 zip 二进制（`Content-Type: application/zip`，不要 `multipart/form-data`）、三个接口（创建 `POST /api/v1/plugins`、更新 `POST /api/v1/plugins/{插件ID}/releases`、查自己 `GET /api/v1/me`）、可选查询参数（`name`/`author`/`summary`/`tags`/`version`/`changelog`/`filename`）、三段 curl 示例、成功/失败返回格式、200 MB 上限与同版本不可重复发布。
- 该章节写在 `tools/gen-api-doc.js` 里随文档一起生成，重新跑 `node tools/gen-api-doc.js` 不会丢。
- `docs/插件开发.md` 第 19 节补「19.1 上传到插件市场」，指向 API 文档；README 文档索引同步。
- 文档里只用 `<令牌>` 占位，**没有写入任何真实令牌**；令牌只在市场「开发者中心 → API 令牌」查看/重置。

### v1.4.10（2026-11-23）

- **导出包改为「成品包」**：不再打包 `test/` 回归源码、`docs/images/` 文档截图、开发工具（导出/发版/演示/生成文档脚本），只保留运行需要的内容——`src/`、`runtime/node.exe`、`tools/start-panel.ps1`、`tools/stop-all.ps1`、`tools/setup-login.js`、`docs/*.md`、`plugins/README.txt`、启动/结束 `.cmd`、`config.default.json`、`package.json`、`README.md`。包从 102 个文件 / 35.85 MB 降到 52 个 / 33.2 MB。
- 根目录文件改成**白名单复制**（以前是「除 zip 外全部复制」）：`node-v*.zip`、临时文件、`插件/`（插件源码）、`插件市场/`（市场源码）、`~JlWBoT/`（数据与日志）都不会进包；导出脚本最后会校验包里没有 `~JlWBoT`、`logs/`、`.tmp-*`、`*.log`。
- 成品包里 README 的截图链接替换成「(截图略)」，避免坏图；需要完整源码包（含 `test/`、`docs/images/`、全部 `tools/`）时用 `-Full`：`tools\export-framework.ps1 -Full`。
- 文档 16.4 发版约定补充成品包内容与 `-Full` 用法。

### v1.4.9（2026-11-23）

- 市场内嵌改为**正常显示网页**：去掉 `transform: scale` 等比缩放，iframe 直接铺满面板内容区（`.market-wrap` + iframe 100%），按市场自己的响应式布局显示，不再放大/缩小。
- **修复「开发者中心」点不了**：代理的 JS 路径改写漏了 `/developer.html`（只改了 `/home-view.html`、`/index.html`），而顶栏 `data-view` 被改成 `/market-proxy/developer.html`；`shell.js` 用它查 `PATHS` 查不到就退回首页，看起来就是点了没反应。现在 `/developer.html`、`/home.html` 也统一改写，顶栏三个栏目与路由一一对应。
- `test/market-proxy-test.js` 扩到 42 项（新增栏目路由 `developer.html` 改写、`data-view` 与路由一致），主回归 385 项。

### v1.4.8（2026-11-23）

- **修复内嵌市场看不到栏目（顶栏）**：市场 `common.js` 一检测到自己被 iframe 内嵌，就给 body 加 `.embedded`，用 CSS `display:none !important` 把顶栏和页脚隐藏（本来是给它自家外壳用的）；面板内嵌的是整个市场，结果只剩内容区。代理层把这句判定改成「父窗口是不是市场自己的外壳（`parent.App.shellView/shellLoad`）」：在面板里照常显示完整页面（顶栏、首页/插件市场/开发者中心、铃铛、用户区、页脚），市场自家外壳的行为不变。
- 只替换 `return window.self !== window.top;` 这一句，其余 `window.top` 判断（插件详情、栏目跳转、登录后刷新）保持原样，避免副作用。
- `test/market-proxy-test.js` 扩到 40 项（新增内嵌判定改写、辅助函数注入、其它 `window.top` 判断不受影响），主回归 383 项。

### v1.4.7（2026-11-23）

- **内嵌市场改为直接转发市场首页**：代理根路径 `/market-proxy/` 之前映射到上游 `/index.html`，而市场的 `/index.html` 是「插件列表」页（白底、没有首页 hero），所以内嵌看到的和直接打开 `https://vlos.jlworld.net/` 不一样；现在映射到市场根 `/`，页面标题与首页 hero 都一致。`_rewriteUrl` 里 `href="/"` 也改成 `/market-proxy/`，点市场里的「首页」不会跳出内嵌。
- 市场登录弹窗可以选择用【登录范围】里的哪个聚龙账户登录市场（多人编辑场景），`POST /api/market/login` 支持 `mail`（校验在登录范围内）；市场会话按邮箱分别缓存，切回已登录账户时优先复用。
- 市场页按面板宽度等比缩放（0.5–1.4 倍，`transform: scale` + 反算 iframe 尺寸），宽屏填满、窄屏不横向滚动；每次进入【市场】固定从首页开始，窗口 resize 重新适配。
- `test/market-proxy-test.js` 扩到 38 项（自动登录、服务端会话覆盖浏览器旧值、不泄露 `jlw_sid`、内嵌导航改写、重复登录复用缓存、市场内退出即清缓存、补登录成功/失败、指定另一个账户登录并切换、根路径落到首页），主回归 380 项。
- 新增 `tools/bump-version.js`：发版前统一改版本号（`node tools/bump-version.js 1.4.8`），把本次改动一起带上。

### v1.4.6（2026-11-23）

- **排查「定时重启后没有重连机器人」**：进程内重启本身会重新连接账户（已用假 QQ 网关回归覆盖）；之前账户被跳过时**不打任何日志**，最容易踩的是「启用」被关掉——账户在启动/重启时被静默跳过。现在启动日志固定输出「账户池加载完成：N 个账户（自动连接 X 个，跳过：… 原因）」，并加了 5 秒兜底：该自动连接却没进过 `start()` 的账户会被补连一次并写 warn。
- 账户新增两个开关（面板「账户 → 编辑」，`accounts[].autoConnect` / `accounts[].autoReconnect`，默认都开）：
  - **自动连接**：项目启动、重启（含定时重启/在线更新）后是否自动连这个 bot；关掉后需手动点「启动」。
  - **异常重连**：掉线后是否自动重连并保持在线；关掉后掉线停在「已断开」并提示，需手动点「重连」；重新打开会立刻补连。开关实时生效，不用重启账户。
  - 三个开关的分工：启用＝账户总开关（关掉即整账户禁用，另两项跟着变灰不可改）；自动连接＝启动/重启时连不连；异常重连＝掉线后自不自觉重连。
- 面板细节：编辑弹窗在「启用」旁加了提示「启用机器人到池中」；新建账户默认三项全开；账户卡片上的「启用」按钮会把三项一起打开（启用到池中），「停用」则整账户禁用并断开。
- 账户卡片副标题标记「已停用 / 未自动连接 / 手动重连」，`idle` 状态文案从「空闲」改为「未连接」。
- 新增 `test/account-modes-test.js`（20 项：配置默认值与持久化、新建账户默认三项全开、启动只连该连的账户、关掉异常重连后掉线不重连且无重连尝试、重新打开立即补连、进程内重启后自动连接账户重新上线），主回归 373 项。

### v1.4.5（2026-11-22）

- **插件市场随面板自动登录**：面板用聚龙账户密码登录/注册/重置密码成功后，服务端顺带调用市场 `POST /api/auth/auto-login`，把拿到的 `vlos_sid` 按面板会话存在内存里（`PanelServer#marketSids`），转发 `/market-proxy/*` 时自动带上，打开【市场】不用再登录一次。
- 密码只用于那一次请求：不写配置、不写日志、不落盘；市场登录态默认保留 12 小时、最多 200 条，退出面板登录会同步丢弃（`/api/logout`）。
- 修复**登录市场后内嵌页面变成独立网页**：市场 `common.js` 登录成功后会把顶层窗口 `window.top.location.href='/home'`，代理层改写成 `location.reload()`，保持在内嵌面板里。
- 代理侧顺手把上游 `Secure` Cookie 去掉（面板是 `http://127.0.0.1`，带 Secure 的 Cookie 浏览器会直接丢弃）。
- 新增排查接口 `GET /api/market/status`（`signedIn` / `mail` / `proxy`）与补登录接口 `POST /api/market/login`（`{ password }`，5 次 / 5 分钟）；市场页顶部加【市场登录】按钮，框架重启后面板会话还在时可一键补市场登录。
- 同一邮箱复用市场会话：再次登录面板先 `GET /api/me` 验证缓存，有效就不再调自动登录接口（那里有 10 次 / 5 分钟的 IP 限流）；市场内退出登录会清掉服务端缓存。
- `test/market-proxy-test.js` 扩到 30 项（自动登录、服务端会话覆盖浏览器旧值、不泄露 `jlw_sid`、内嵌导航改写、重复登录复用缓存、市场内退出即清缓存、补登录成功/失败），主回归 353 项。

### v1.4.4（2026-11-22）

- 按使用反馈调整回复闸门：**删除 800ms 限频、20 条/分钟、60s 去重**（会误伤进群/退群欢迎与连续指令回复）。
- 改为**只拦截统一前缀的报错文案**：`【[404 error] 具体报错内容】`；其他回复全部原样放行。
- 配置简化为 `plugins.replyGuard = { enabled, blockErrors, errorPrefix }`，前缀可自定义。
- Arknights / VloS 的报错文案统一使用该前缀（框架拦截后只写日志）；欢迎语、卡片、正常指令回复不受影响。
- 修复 v1.4.3 闸门导致“进群欢迎 / 退群欢迎发不出去”的问题。
- 单测改为 18 项，主回归 338 项。

### v1.4.3（2026-11-22）

**事故复盘**：Arknights 旧版插件在 `sharedState()` 里读 `live.keys()`，旧共享对象缺 `live` 时抛 `Cannot read properties of undefined (reading 'keys')`；插件的 catch 分支把它拼成 `出错了：...` 当普通回复返回。群里有指令就回一条，多个群同时触发，短时间内大量重复错误消息 → 被判定骚扰 → 多个群移除机器人。

**修复**：

- Arknights 1.5.3：`sharedState()` 自动补齐 `live/sends/seen`；接口错误与未捕获异常只写日志，不再回复到群聊/私聊。
- 框架新增**插件回复闸门** `src/core/reply-guard.js`（配置 `plugins.replyGuard`）：
  - 同一插件 + 同一目标最小间隔 `minIntervalMs`（默认 800ms）；
  - 同一目标每分钟最多 `perMinute` 条（默认 20）；
  - 相同内容 `dedupeMs` 内只发一次（默认 60s）；
  - **崩溃/堆栈类文案**（`出错了`、`Cannot read`、`TypeError`、`异常` 等）无论主动被动一律拦截，只写日志；
  - 命中拦截会写 warn 日志（插件、目标、原因、内容摘要），不会静默。
- 闸门覆盖所有插件出口：`reply` 返回值、`actions.reply`、`send_group_message`/`send_c2c_message`/`send_channel_message`、`ctx.api.send*`、`ctx.bot.send*`/`reply*`。
- mcstatus 的异常回复改为只写日志（其他用法提示保持被动回复）。
- 新增 `test/reply-guard-test.js`（26 项：限频/去重/额度/堆栈拦截/主动错误拦截），主回归扩到 346 项。

### v1.4.2（2026-11-22）

- **合并为一个 `结束进程.cmd`**（删除 `停止机器人.cmd` / `强制关闭.cmd`）：先杀启动器（`start-panel.ps1`，自动重启的源头），再杀所有 `node src\index.js`，`taskkill /T /F` 连插件子进程一起结束，最后按端口兜底并清 `run.pid`。
- 新增 `~JlWBoT/stop.flag`：结束进程时写入，启动器看到后不再自动重启；下次 `启动机器人.cmd` 会自动清除。
- 多轮扫描（最多 4 轮）+ 每轮间隔，避免“杀掉又被拉起来”；输出每个 PID 的命令行摘要与端口释放结果。
- 新增 `test/stop-all-test.js`（7 项：结束启动器与子进程、不复活、写标记、清锁），主回归扩到 320 项。

### v1.4.1（2026-11-22）

- **单实例锁**（禁止重复运行）：同一数据目录只允许一个进程；第二个实例启动时直接退出并提示已有 PID。锁文件 `~JlWBoT/run.pid`，PID 不存在时自动接管，`--force` 可强开。
- 新增 `停止机器人.cmd` / `tools/stop-panel.ps1`：结束所有 `src\index.js` 进程（含 `-Background` 隐藏实例）、可选按端口结束占用者，并清理运行锁。
- 新增 **`强制关闭.cmd`** / `tools/force-stop.ps1`：按项目路径 + 面板端口匹配所有相关 node，`taskkill /T /F` 连同插件子进程一起结束，释放端口、清锁并打印被结束进程的命令行摘要；`-ProjectOnly` 只清当前项目。
- 修复 Arknights `Cannot read properties of undefined (reading 'keys')`：`sharedState()` 兼容旧版本遗留的共享对象（缺 `live`/`sends`/`seen` 时自动补齐）。
- **插件报错不再发到 QQ**：Arknights 的接口错误与未捕获异常改为只写框架日志；VloS 原本就只记日志。群聊/私聊里只会看到正常回复。
- 新增 `test/single-instance-test.js`（13 项），主回归扩到 313 项。

### Arknights v1.5.3（2026-11-22）

- 修复旧共享对象缺 `live` 时 `newestLiveSeq()` 抛 `.keys` 的问题。
- 接口错误（`SklandError`）与未捕获异常不再回复到群聊/私聊，只写 `明日方舟接口错误` / `明日方舟插件异常` 日志。
- 用法/业务提示（`UserError` / `ServiceError`）保持正常回复。

### VloS v2.9.62（2026-11-24）

- 新增模板变量 **`{pending_longjing}` / `{pending_xuanyu}`**：VloS余额 的龙晶 / 玄玉纯数字（0 也显示），`/list` 与 `/签到` 的自定义回复模板都能直接用。
- 自定义卡片里常把「签到账本」的 `{ledger_longjing}` / `{ledger_xuanyu}` 当成 VloS余额 写（预览里看着像有值，实际线上账本为 0 就永远显示 0）；现在 VloS余额 用新变量，签到账本继续用 `{ledger_*}`，两者不再混淆。
- 设置页的变量说明、示例预览同步补上这两个变量。
- 单测 82 项（自定义 `/list` 模板同时输出 pending 12/3 与 ledger 100/2）。

### VloS v2.9.61（2026-11-24）

- **修复 `/list` 的 VloS余额 显示 0**：其他插件会直接 `UPDATE vlos_users.vl_lj / vl_xy`（跨表写），VloS 内存 LRU 缓存里还是旧值；`/list` 直接读缓存、普通保存还会把旧值写回，所以别人加多少都显示 0，甚至被下一次保存覆盖掉。
- 读取回表：新增 `store.refreshPending(key)`，`/list`、签到结算、`vlosBalance` / `addVlosBalance` / `setVlosBalance` / `getUser` 取值前都先读一次数据库并同步缓存。
- 写库不碰余额列：普通 `_saveUser()` 改用不含 `vl_lj / vl_xy` 的 UPSERT，只有 `setPendingWallet` / `addPendingWallet` / 迁移建号才写这两列，跨表写入不会被旧缓存覆盖。
- 签到结算更稳：入账时只扣掉本次真正消费掉的旧 VloS余额（carry），异步期间其他插件加进来的部分保留，不再整值覆盖。
- 单测 81 项（跨表写入后 `/list` 显示 10/5、API 读取一致；`addVlosBalance` 加 100 后 `/list` 立刻显示；签到把跨表 10 一并入账且不清掉）。
- 云端 `D:\QQbot\JlW-BoT` 需导入 `插件\VloS-【v2.9.61】.zip`；旧版（卡片还是「聚龙家产 / VloS余额」格式）不会回表，永远显示 0。

### VloS v2.9.60（2026-11-23）

- **修复「开启每日重复签到后发 `/签到` 直接把框架干死」**：SQLite 存储的 `save()` 一边遍历用户缓存，一边让 `_saveUser()` 用 `delete + set` 把当前 key 挪到 Map 末尾，迭代器永远到不了结尾 → **同步死循环**。表现就是进程还在但**单核 100% CPU、面板 `/health` 无响应、网关/日志/心跳全停**，只能杀进程重启。
- 修复方式：`save()` 先 `[...cache.values()]` 快照再遍历；`_saveUser()` 对已在缓存里的 key 只 `set` 更新（不再重排），缓存顺序保持稳定。
- 签到回写更轻：只保存当前用户（`saveUser`），不再把所有缓存用户重写一遍；方舟掉落标记改用 `setLastSignArk` 直接 `UPDATE vlos_sign_history` 最后一行 —— 之前 `save()`/`saveUser()` 只写用户主表，`ark` 标记其实没落库。
- 单测 78 项（新增 `save()` 不死循环 + 缓存顺序不变；`oncePerDay=false` + 方舟掉落 + SQLite 连续签到两次正常出卡、历史两条、ark 落库；连续 100 次签到压力：约 115ms、RSS 72MB、历史 100 条）。
- 部署脚本 `tools/deploy-vlos.js` 现在只把 `version` 写进线上 `plugin.json`（其余配置不动），面板显示的版本号不再滞后。

### VloS v2.9.59（2026-11-23）

- 修复「签到变量空白」：未绑定 / 未登录 / 今日已签到 / 登录过期 / 正在签到这些**前置提示不再套用自定义签到模板**（之前模板里的 `{poem}` `{longjing}` `{days}` 等没有值，卡片只剩“签到成功!”和空字段）；只有真正签到成功才渲染模板变量。
- 顺带把 `/bindqq` 未登录 / 登录过期、`/list` 未绑定也改成系统提示，不套自定义模板（符合“系统提示固定文案”的约定）。
- 单测 75 项（签到全部变量、前置提示不套模板）。

### VloS v2.9.58（2026-11-23）

- **VSQL 改为显式前置**：检测不到 VSQL 时日志写 `error`，并在群里 / 私聊提示一次「VloS 缺少前置插件 VSQL」；当前仍可暂存 `users.json` 继续用。
- **回填后删除 users.json**：VSQL 连上后立刻把 JSON 数据迁移 / 回填（VSQL 停用期间写的新数据以 JSON 为准，钱包为 0 时保留 SQL 值，签到历史按日期取并集），落库成功后删除 `users.json`，之后所有数据只走 SQLite，不留额外文件。
- 迁移完成会 `checkpoint` 一次，WAL 落盘并截断。
- 单测 73 项（前置缺失提示一次、JSON 回填并删除、迁移删除）。

### VloS v2.9.57（2026-11-23）

- **存储换成 SQLite**：通过 VSQL 插件（`node:sqlite`，WAL）把用户数据存在 shared 命名空间的 `vlos_users` / `vlos_aliases` / `vlos_sign_history` 三张表；首次连上会自动把 `users.json` 迁移过去（原文件保留作备份），其他插件可以直接 SQL 读取。内存改为按需加载（LRU 100），不再整份 `users.json` 常驻。
- VSQL 未加载 / 运行环境没有 `node:sqlite` 时自动回退 `users.json`；之后 VSQL 就绪会自动切换并迁移。
- 框架：插件启动按 `priority` 排序（`src/core/plugins.js`），VSQL（10）先于 VloS（60）。
- 签到 `ark` 标记显式保存；VloS余额对应 `vlos_users.vl_lj / vl_xy`，对外 API（`vlosBalance` / `addVlosBalance` / `setVlosBalance`）不变。
- 单测 71 项（SQL 后端写入 / 读取回填 / users.json 迁移 / 无 VSQL 回退）。

### VloS v2.9.56（2026-11-23）

- 「暂存余额」正式改名 **VloS余额**（签到卡片、用户表头、变量说明、API 文档统一）；存储字段仍是 `users.json` 的 `pendingWallet`，聚龙 Key 恢复后下次签到一并入账的行为不变。
- 新增对外 API：`vlosBalance(voucher)` 读取 `{longjing, xuanyu, total}`；`addVlosBalance(voucher, delta, {reason})` 加 / 减（负数扣减、最低 0）；`setVlosBalance(voucher, {longjing, xuanyu})` 直接设置；`getUser()` 返回里的 `pendingWallet` 改为 `vlosBalance`。其他插件可以直接给用户加/减 VloS余额。
- 单测 69 项（VloS余额读取 / 增减 / 扣到 0 / 设置）。

### VloS v2.9.55（2026-11-23）

- 审核判断范围收紧为**进退群的 3 项**：新成员进群 / 成员退群 / 入群验证；群管部分（是否启用违禁词、词库、动作、禁言、处理入群申请）**完全不参与**自动审核判断，改了也直接生效。
- 群管页面：入群验证卡片不再随「新成员进群」关闭而隐藏，始终可见；关闭时卡片内提示「入群验证不会生效」。
- 单测 69 项（群管改动自动通过、入群验证始终可配置）。

### VloS v2.9.54（2026-11-23）

- 自动通过改成**按功能逐项对比两个基线**（全局 + 本群已通过的自定义），允许混用：例如欢迎模板沿用已通过版本、入群验证内容用全局的，也会自动通过（之前整体比对一个基线，混用会被误判要审核）。
- **违禁词（词库 / 动作 / 禁言秒数）不在审核检查范围内**：改了也直接自动通过；入群审批规则仍比对内容。
- 群管页面提示同步；单测 69 项（混用基线、改违禁词自动通过、改模板仍审核）。

### VloS v2.9.53（2026-11-23）

- 修复「没有自定义、按全局值提交、只关某一项功能」仍进审核的问题：自动通过比较文本时统一换行符（CRLF/LF）和首尾空白，避免老配置里的 `\r\n` 与 textarea 提交的 `\n` 被当成“改过模板”。
- 明确全局基线规则：没有本群自定义时，开启的项只要与全局一致（关闭的项不比对内容）就自动通过。
- 单测 69 项（全局基线只关入群验证自动通过，含 CRLF 模板）。

### VloS v2.9.52（2026-11-23）

- 在「已通过的本群自定义」基础上**只关闭某些功能**（例如只关入群验证、只关违禁词）也自动通过、不进审核；只有重新开启或改动开启功能的内容才需要审核。
- 已经挂在「待审核」里的条目会在下次轮询（20 秒）按新规则重判，符合条件的自动通过并私聊提交人。
- 群管页面提示同步；单测 68 项（只关验证自动通过、回溯自动通过、重新开启仍需审核）。

### VloS v2.9.51（2026-11-23）

- 自动通过再扩一条：提交内容与**本群上次审核通过的自定义**完全一致时也直接自动通过、不进审核（包括自定义欢迎模板 / 验证题 / 词库等）；只有和全局、已通过版本都不同才需要管理员审核。
- 群管页面提示同步说明；单测 67 项（与已通过自定义一致自动通过、改模板仍审核）。

### VloS v2.9.50（2026-11-23）

- **群管提交自动通过**：提交内容只是**关闭功能**（入群欢迎 / 退群提示 / 入群验证 / 违禁词 / 入群审批任一关闭），或**与全局完全一致**（模板、验证题/答案/限时、词库/动作/禁言、入群审批规则都没改）时，不再创建审核链接、不进「待审核」，直接写入本群 `groups` 覆盖，并私聊提交人「已自动通过」；只有开启且内容与全局不同才需要管理员审核。
- 群管页面提示文案同步说明；新增 `groupAdmin.autoApproveMessage`（自动通过私聊文案）。
- 单测 66 项（关闭功能自动通过 / 与全局一致自动通过 / 改模板仍进审核）。

### VloS v2.9.49（2026-11-23）

- 明日方舟入群校验也改成**回调按钮**（`jv:ark`，只允许这名新成员点）：点击后直接调 `Arknights.isLoggedIn(member_openid)`，不再靠指令按钮让用户发 `/入群校验`。
- **校验未通过 / 接口取回失败**会回「校验未通过！请先私聊机器人授权…」并**重新挂一个「开始校验」按钮**（按钮点一次就灰，和自定义问题一样）；通过文案改成「验证通过，博士！欢迎您的加入！(*´▽｀)ノノ」，文字 `/入群校验` 这条兜底路径也一致。
- 单测 65 项（方舟回调按钮、失败重挂、通过文案）。

### VloS v2.9.48（2026-11-23）

- 验证超时默认文案改成「验证超时，您未在规定时间内完成验证，将被移出群聊。」（先发提示，3 秒后再移出）。

### VloS v2.9.47（2026-11-23）

- **验证限时到了会真的移出成员**：定时器到点先发「验证超时，您未在规定时间内完成验证，将被移出群聊。」，等 3 秒再调 `batch_remove_members`；踢失败再补一条「自动移出失败：原因」。之前只是把待验证记录删掉、按钮失效，人不会被踢。
- 欢迎语在「## 入群验证」标题下面加 **`> 限时 N 分钟`**（自定义问题 / 明日方舟校验都加），设置页与群管页的预览同步。
- 新增 `joinVerify.timeoutText`（超时文案，默认「验证超时，您未在规定时间内完成验证，将被移出群聊。」）。
- 单测 65 项（超时先提示再踢、限时标注）。

### VloS v2.9.46（2026-11-23）

- 验证失败达到次数时改成 **先发「验证失败次数过多，已被移出群聊」提示 → 等 3 秒 → 再调 `batch_remove_members` 移出**；之前是先踢再回，被踢的人根本看不到提示。
- 踢人失败时提示已经发出，之后再补一条「自动移出失败：原因」（`40103012` 群主关闭操作权限等）。
- 单测 64 项（提示在移出之前、失败原因补发）。

### VloS v2.9.45（2026-11-23）

- **「最多答错次数」改成达到即踢**：旧逻辑是 `attempts > max`，`maxAttempts=3` 实际给 4 次机会；现改为 `attempts >= max`，第 3 次答错就调 `batch_remove_members` 移出。
- **同一次点击不重复计数**：新增 1.5 秒去重（`group + member + button_data`），QQ 偶发重复投递 `INTERACTION_CREATE` 时只算一次，避免「点一下算好几次」。
- **踢人失败不再假装成功**：接口失败时回复里带「自动移出失败：原因」，日志写 `入群验证踢人失败`。本机用真实群实测 `batch_remove_members` 返回 `40103012 操作失败, 群主已经关闭操作权限` —— 这是群主在群设置里关了机器人的成员管理权限，代码绕不过去，需要在群设置 → 群机器人 / 群管理里给机器人开启操作权限（或加管理员）。
- 设置页 / 群管页标签改成「最多答错次数（达到即踢出）」。
- 单测 64 项（第 N 次即踢、踢失败把原因回到群里）。

### VloS v2.9.44（2026-11-23）

- 审核页「刷新列表」改成**只刷新审核快照**：`settings.html` 发 `jlw-settings-review-refresh`，面板重新 `GET /api/plugins/:id/settings`，解析里面 `<script id="vlos-…-data" type="application/json">` 的 JSON 块，再用 `jlw-settings-snapshots` 发回；页面只替换这几个数据块并 `renderReviewPage()`，**不换 iframe、不重载插件、不丢正在编辑的内容**。
- 面板端改了 `src/web/app.js` 与 `src/web/plugin-settings.js`（独立设置页同样支持）；静态文件按请求读盘，**不用重启面板，按 F5 刷新面板页面**即可加载新逻辑。
- 旧面板不认识新消息：1.1 秒没有回执就退回原来的 `jlw-settings-refresh` 整页刷新（有未保存修改时先弹确认），不会点了没反应。
- 单测 63 项（设置页包含新协议与快照处理）。

### VloS v2.9.43（2026-11-23）

- 入群验证加**限时下拉**（1–10 分钟，默认 5，配置项 `welcome.joinVerify.expiresMinutes`）：
  - 群管一次性页面（回调页）新增「验证限时（超过后本次验证失效，需重新进群）」下拉，提交时随 payload 带 `vVerifyExpire`；
  - 全局设置页「进退群 → 入群验证」、设置页「审核 → 已通过」卡片同样有下拉；审核链接页面显示「限时 N 分钟」；
  - 运行时按本群/全局的 `expiresMinutes` 创建待验证记录（自定义问题与明日方舟校验都用它，之前写死 30 分钟 / 5 分钟）。
- 单测 63 项（群管页 1–10 分钟选项、审核写入 8 分钟、运行时限时生效）。

### VloS v2.9.42（2026-11-23）

- 入群验证问题前面加 **`## 入群验证` 标题**（自定义问题 / 明日方舟校验都加），设置页和群管页的欢迎语预览同步。
- **答错后重新挂按钮**：点过一次的那条消息里，同组按钮会全部变灰；现在答错回复会再发一组答案按钮（`groupButtons:false`，不带 `group_id`），成员可以继续点，答对为止 / 超次踢出。
- 单测 62 项（问题标题、答错重挂按钮、重挂按钮仍只限本人）。

### VloS v2.9.41（2026-11-22）

- 入群验证兜底改成 **Markdown 蓝字**：按钮发不出去时补一条 `> 点下面的蓝色答案也可以完成验证：<qqbot-cmd-input …>`，每个答案一个标签，点击把 `/入群验证 <答案>` 填进输入框，发送后同样判定（`handleJoinVerifyMessage` 会剥掉 `/入群验证` 前缀）。
- 明确「所有群都能挂自定义按钮」，不再把“未开通内邀”当成限制；只有 QQ 真拒绝键盘时才走蓝字兜底。
- 单测 62 项（蓝字兜底 + `/入群验证 2` 通过）。

### VloS v2.9.40（2026-11-22）

- 入群验证答案改成**消息按钮**：每个答案一个回调按钮（`action.type=1`，`data=jv:<序号>`），按钮**只允许这次进群的新成员点击**（`permission.type=0` + `specify_user_ids=[member_openid]`），同一组按钮点一个其余变灰（`group_id`）。
- 判定改走 **`INTERACTION_CREATE`**：先 `PUT /interactions/{interaction_id}` 回应（3 秒内，否则客户端一直 loading），再按 `button_data` 判对错/计数/踢人；**不再依赖群的全量消息权限**，也不再拦截新人的普通群聊消息。插件清单 `events` 增加 `INTERACTION_CREATE`（账号需勾 `INTERACTION` intent，Texas / VloS 都已勾）。
- 修正按钮类型映射：QQ 群键盘是 **0=跳转 / 1=回调 / 2=指令**，之前把「回调」映射成 0、「跳转」映射成 1，回调按钮实际发成了跳转按钮。指令编辑器的类型说明同步更新。
- 群没开通自定义按钮（QQ 返回 `305007` 等键盘类错误）时自动去掉键盘重发欢迎语，并补「请 @机器人 后直接回复你的答案」；只有这种情况下该成员才允许文字作答，普通聊天不会被当成答案。
- 设置页 / 群管页的欢迎语预览会显示「答案按钮：2 / 3（仅新成员可点）」。
- 环境：群里的出题实例是**云端 VloS**（本机 VloS 账户 `invalid appid or secret` 掉线，本机 Texas 只是第二个成员机器人）。要让群里的欢迎语带上答案按钮，需把 `插件\VloS-【v2.9.61】.zip` 更新到云端面板（保留 config，清单会带上 `INTERACTION_CREATE`）；本机已部署 2.9.42 但没给测试群配 `joinVerify`，避免两个机器人同时出题。
- 单测 62 项（新增：答案按钮结构/限制本人、`INTERACTION_CREATE` 判定、非本人点击提示、按钮被拒回退文字、清单事件）。

### VloS v2.9.39（2026-11-22）

- 修复「已通过」群卡片没有入群验证字段：面板里对已审核群点「保存修改」时只写进群/退群/群管，`welcome.joinVerify` 被丢掉，所以群里欢迎语只有模板、没有验证题和「开始校验」按钮。现在卡片显示并保存验证开关、方式、问题、答案 1–4、正确答案、最多答错次数。
- 保存前校验：开启验证时问题必填、有效答案至少 2 个、正确答案不能指向空答案（不满足会弹提示并阻止保存）。
- 审核通过（`applyGroupReview`）写入 `joinVerify` 时继承全局自定义的通过/失败/踢出文案，不再回退到插件内置默认。
- 运行时兜底：入群验证配置不完整（问题为空或有效答案 < 2）时自动跳过验证并写 `入群验证配置不完整` 日志，避免新人无论答什么都判错被踢。
- 明确生效规则：本群覆盖有 `welcome.joinVerify` 就优先本群，没有才继承全局；全局关闭入群验证不影响本群单独开启。
- 部署脚本修正：升级只复制代码文件，**不再覆盖运行目录 `plugin.json`**（线上 Key / 群覆盖 / 欢迎语）。本次误覆盖已用 `~JlWBoT/backup/VloS-2.9.4-20261121-224427/plugin.json` 恢复并重载。
- 单测 60 项（新增「已通过卡片验证字段」「配置不完整自动跳过」）。

### VloS v2.9.38（2026-11-23）

- 修复群管页面答案行「默认 4 行全显示 / + 和删除没反应」：`.v-answer-row` 的 `display:flex` 覆盖了 `hidden`，补 `.v-answer-row[hidden]{display:none}`；现在默认 2 行，+ 加到 3/4 行，删除回到 2 行。
- 待审核卡片显示用户配置的**验证问题**和**验证答案**（正确项前面标 `✓`，兼容旧的多行答案 payload）；管理员审核链接页面同样显示。
- 面板验证页保存/回填已实测：payload 带 `answers` + `correctIndex`，重载后能恢复问题、答案行和单选项。
- 单测 58 项。

### VloS v2.9.37（2026-11-23）

- 入群验证答案改为**单选框 + 输入框**：默认 2 行，点「+ 添加答案」最多加到 4 行，每行可单独删除（至少保留 2 行）；**只有单选框选中的那条算正确答案，其他都算错**（`correctIndex`）。
- 全局设置页和群管页面同步这套 UI；群管页面 payload 改成 `vVerifyAnswer1..4` + `vVerifyCorrect`，审核通过时按文本回填 `correctIndex`。
- 欢迎语预览现在会把验证内容接在模板下面（`***` 分隔）：自定义问题显示问题；明日方舟校验显示授权提示 +「开始校验」按钮。
- 单测 58 项（更新为「只有选中答案通过、其他选项算错」）。

### VloS v2.9.36（2026-11-22）

- 群管一次性页面加**开关联动**：关闭「新成员进群」时隐藏进群模板、预览和整张「入群验证」卡片；关闭「成员退群」隐藏退群模板/预览；关闭「启用违禁词」隐藏违禁词与命中动作；关闭「处理入群申请」隐藏审批方式/关键词/拒绝理由。
- 入群验证选「明日方舟校验」时隐藏问题/答案/次数，显示授权校验说明；切回自定义问题恢复。
- 新增回调页断言（联动容器 + `syncDeps`）：单测 58 项。

### VloS v2.9.35（2026-11-22）

- 进退群下新增**独立子页「入群验证」**，排在「进群」前面（顺序：入群验证 / 进群 / 退群 / Bot 入群），不再挤在进群页里。
- 群管一次性页面也把「入群验证」独立成一张卡片，放在「进退群」卡片前面。
- 单测 58 项。

### VloS v2.9.34（2026-11-22）

- 群管待审核卡片显示 **进群欢迎 / 退群欢迎 / 入群验证** 的开关状态；提交时对应的欢迎是关闭的，就不再显示模板预览，只留一句「提交时进群 / 退群欢迎都是关闭的，不显示模板」。
- 管理员审核链接页面（`buildReviewHtml`）同步：状态行 + 只渲染已开启的模板；两个都关闭时不渲染任何模板容器。
- 单测 58 项（新增审核页开关与模板显示）。

### VloS v2.9.33（2026-11-22）

- 新增**入群验证**（挂在本群入群欢迎下面，受「新成员进群」开关控制，关闭时不生效）：
  - 自定义问题：问题接在欢迎语后用 `***` 分隔；答案 2–4 个（每行一个），答对回自定义「答对回复」，答错回「答错回复（还可尝试 N 次）」，超过次数调用 `batch_remove_members` 踢出并回「踢出回复」；
  - 明日方舟校验：固定提示「请私聊机器人授权鹰角网络账户，授权后点击下方按钮校验」，消息底部挂「开始校验」**回调按钮**（`jv:ark`，只限新成员）；点击后限时内调明日方舟插件 `isLoggedIn(openid)`，通过回「验证通过，博士！欢迎您的加入！(*´▽｀)ノノ」，失败回「校验未通过！」并重挂按钮；
  - 全局设置页在「进退群 → 进群」下面；群管页面同一组字段（开关 / 方式 / 问题 / 答案 / 次数），审核通过写入本群覆盖；本群有覆盖用本群，没有用全局。
- 新增 3 条单测（自定义问题答对/答错/超次踢人、明日方舟校验、关闭进群欢迎时不生效）：单测 57 项。

### VloS v2.9.32（2026-11-22）

- 进退群排查增强：收到 `GROUP_MEMBER_ADD/REMOVE/GROUP_ADD_ROBOT` 时先记 `VloS 收到群事件 …`，跳过时写明原因（总开关关闭 / 场景开关关闭 / 模板渲染为空）。
- 实际根因：本机 Texas 账户没订阅 **`GROUP_MEMBER_EVENT`（群成员事件）** intent，所以进群 / 退群事件根本没到插件；已在面板给 Texas 补上并重启（`GROUP_AND_C2C_EVENT` 不含成员事件）。云端 Bot 同样要在「连接」页勾选「群成员事件」。
- 退群限制说明：QQ 对 `GROUP_MEMBER_REMOVE` 的 `event_id` 返回 `40034027`（该事件不能被动回复），只能转主动消息；主动消息需要开放平台「群主动消息」权限，没权限会报 `40034105`，这不是插件能绕过的。
- 单测 54 项。

### VloS v2.9.31（2026-11-22）

- 修复「本群群管设置里关闭入群欢迎后再打开没反应」：
  - `effectiveWelcome()` 在本群覆盖没写 `enabled` 时，按本群「新成员进群 / 成员退群」开关推导总开关——全局总开关关着，本群单独打开也能发；关掉再打开同样生效；
  - 本群模板为空时回落全局模板，避免关一次再开模板被清空导致发不出内容；
  - `applyReviewPayload()` 存本群欢迎时，空模板回填全局模板。
- 修复退群看不到消息：`sendWelcome()` 增加主动消息兜底——先试 `event_id`（Markdown → 纯文本），失败或没有事件 id 时自动转「主动消息 + Markdown / 纯文本」，日志 `via=` 会标明走的是哪条；进群同样适用，机器人进群仍只走 event_id + 重试。
- 单测 54 项（新增退群 event_id 失败转主动消息、本群设置优先于全局总开关）。

### VloS v2.9.30（2026-11-22）

- `/群管` 等指令的自定义回复现在支持 `{heading}` `{name}` `{avatar}`：通用变量由 `applyCommandReply` 统一提供（头像是发消息人的 QQ 头像），不用再依赖各 handler 自己塞 `__commandVars`。
- 「权限不足 / 格式错误 / 设置正在审核中 / 创建页面失败」这类**系统提示不再套用自定义回复模板**（`replyNotice` → `replyMd(..., {raw:true})`），避免用户把 `/群管` 模板改成设置卡后，拒绝提示也被顶成设置卡、造成“群主识别没了”的假象。
- 设置页变量下拉对所有指令都加上 `{heading}` `{name}` `{avatar}`，并注明「系统提示固定显示默认内容」。
- 新增单测「自定义回复能用 heading/name，拒绝提示不被模板顶掉」：单测 52 项。

### VloS v2.9.29（2026-11-22）

- 群管被拒绝时，卡片里直接显示 **QQ 下发识别到的角色**（如「当前识别角色：**member**」），不用再翻日志猜。
- 附本次实测：`role=owner`（member=DAB3D110…）能进设置页；`role=member`（member=DE1F9D86…）被拒绝 → 说明 QQ 认为该账号是普通成员，不是插件识别丢失。
- 单测 51 项。

### VloS v2.9.28（2026-11-22）

- 群管权限识别加诊断与兜底：
  - 每次 `/群管` 都写日志 `VloS /群管 权限检查 group=… role=… event=… kind=…`，能直接看出 QQ 下发的角色是 `owner` / `admin` / `member` / 空；
  - 事件没带 `member_role` 时，尝试调「获取群成员信息」接口补角色（`/v2/groups/{group_openid}/members/{member_openid}`，内邀能力，失败只写日志）；
  - 角色为空（接口也拿不到）时不再直接拒绝，而是放行到「提交后管理员审核」；显式 `member` 仍然拒绝。
- 新增两条单测（补角色、角色未知放行）：单测 51 项。

### VloS v2.9.27（2026-11-22）

- 去掉指令编辑器里的「流程类指令缺少 {content}」红字提示（按反馈不再需要）。
- `/bindopenid` 不再限制私聊：群聊里发也能保存 OpenID（优先 `union_openid`，没有则退回当前会话的 member/user openid）；Key 失效时仍在群里返回字符串供手动填写。
- 插件 README / api.html 的 `/bindopenid` 说明改成「群聊 / 私聊都可以」；单测 49 项。

### VloS v2.9.26（2026-11-22）

- `/bindqq` 改成**一条指令完成**：`/bindqq QQ号` 直接调 `qq-send-code` 发验证码到聚龙注册邮箱，回复里提示「绑定后无法修改」，用户直接发 6 位验证码即可；不再要求先发 `/bindqq QQ号 确认`（旧写法仍兼容，行为一样）。
- 默认回复模板、插件 README、api.html 的错误提示同步改成单步流程；绑定流程过期/验证码错误提示也去掉「确认」。
- 单测 48 项。

### VloS v2.9.25（2026-11-22）

- 修复「/bindqq 没反应」的坑：流程类指令（注册/登录/绑定/取消/群管/菜单同步）的自定义回复如果没写 `{content}`，会把默认提示整段替换掉，连「确认绑定 QQ 号 / 验证码已发送」都没了，看起来像没反应。
- 设置页编辑器新增红字警告：流程类指令模板里没有 `{content}` 时提示「会整段替换默认提示」；文档也补了这条。
- 单测 48 项。

### VloS v2.9.24（2026-11-22）

- 按钮编辑器新增 **「立即发送」** 下拉：选「是」时 `action.enter=true`，点击按钮直接把数据发出去（仅指令按钮）；默认「否」= 只把 data 填进输入框。
- 存储格式扩成 `【行,列|按钮文字|数据|类型|可点范围|是否立即发送】`，旧格式（没有最后两段）仍能解析；预览按钮上会标「· 立即」。
- 单测增加 `enter=true` 断言；单测 48 项。

### VloS v2.9.23（2026-11-22）

- 指令编辑器把「消息按钮」拆成独立编辑区（和 Markdown 正文分开，因为按钮只能挂在消息最底部）：
  - 行 / 列 / 文字 / 数据 / 类型 / 可点范围 用下拉和输入框配置，「添加按钮」加入预览；
  - **点预览里的按钮即可删除**；同一坐标重复添加会覆盖；最多 5 行 × 5 个；
  - 保存时自动序列化成 `【行,列|文字|数据|类型|可点范围】` 拼在回复末尾，兼容旧的手写格式；
  - 只有按钮没有正文时会自动把默认文案固定下来，避免运行时正文变空。
- 根 README、插件 README 更新截图与说明；单测 48 项。

### VloS v2.9.22（2026-11-22）

- 自定义回复支持 **消息按钮**：`【行,列|按钮文字|数据|类型|可点范围】`，最多 5 行 × 5 个；类型 `指令`（点击填入 data）/`跳转`（data 是 URL）/`回调`，可点范围 `所有人`/`管理员`/`指定用户`。
- 按钮行从 Markdown 正文里剥离，转成 QQ `keyboard` JSON 挂在消息底部；发送失败（如开放平台未开通自定义按钮）自动去掉按钮重发纯 Markdown，并记 `VloS 按钮消息发送失败`。
- 设置页变量下拉新增「消息按钮」片段，预览里把按钮画成蓝色按钮条（正文不显示）。
- 新增单测「自定义回复挂载按钮 + 失败回退纯文本」：单测 48 项。

### VloS v2.9.21（2026-11-22）

- 指令回复变量新增 **Markdown 片段**（下拉最后一组，带说明）：
  - `{at_user}` @发送者、`{at_all}` @全体成员（`<qqbot-at-everyone />`）、`{at:OpenID}` @指定用户；
  - `{img:https://…}` 图片（自动补 QQ 需要的 `#0px #0px`）；
  - `{link:https://…|显示文字}` 蓝色可点击链接；
  - `{cmd:/指令|显示文字}` 蓝色指令标签。
- `renderTemplate()` 统一支持 `{img:}` / `{link:}` / `{at:}`；只接受 `http(s)` 地址，非 http 的图片/链接直接丢弃（防 `javascript:` 注入）。
- 设置页下拉用 `optgroup` 分组「Markdown 片段」，插入后示例参数自动选中，直接打字替换。
- 新增单测「自定义回复支持 @ / 图片 / 网址 / 蓝字片段」：单测 47 项。

### VloS v2.9.20（2026-11-22）

- 指令回复编辑器：`/vlos` 和 `/菜单` 的标题不再用 `{title}` 变量隐藏，默认源码直接是 `## VloS 指令` / `## 菜单`，可自由改标题文字。
- 变量下拉每一项直接显示 `{变量} — 中文说明`（如 `{poem} — 今日随机诗词`），选中后仍可点「插入」放到光标处。
- 说明：`{commands}` / `{items}` 仍由「指令」表和「菜单」配置实时生成；改列表内容请改对应表格，或删掉变量自己写死。
- 单测 46 项。

### VloS v2.9.19（2026-11-22）

- 修复「日志说已禁言、实际没撤回」：框架的 `ctx.api.call` 失败时返回 `{ ok:false, code, message }` 而不抛异常，之前直接忽略返回值，所以撤回失败也当成成功。
- 违禁词撤回 / 禁言每次接口调用都写日志：`VloS 接口 recall_group_message 撤回 message_id=… 成功（120ms）` / `失败（90ms）code=… message=…`，最后汇总 `VloS 违禁词命中 … · 已撤回 · 已禁言 180 秒`（失败会写清 code/原因）。
- 常见失败自动附排查提示：`11298`→IP 白名单、`40054005`→只允许撤回 2 分钟内、`403/管理员`→机器人不是群管理员、`TOKEN_ERROR`→AppSecret 无效。
- 撤回失败仍继续禁言；`warn` 动作也会记录提醒发送结果。
- 新增单测「撤回失败要写日志且仍继续禁言」：单测 46 项。

### VloS v2.9.18（2026-11-22）

- 指令自定义回复：**所有指令的默认回复都改成真实 Markdown 源码**（注册/登录/绑定/群管等不再显示 `{content}`），点开「编辑」直接看到默认文案并渲染，可直接改。
- 变量从「标签按钮」改成 **下拉列表 + 中文说明 + 插入按钮**：选中变量在旁边显示含义（如 `{poem}`=今日随机诗词、`{cmd_add}`=注册指令蓝色标签），点「插入」放到光标位置。
- `applyCommandReply` 支持 `{cmd_*}` 蓝色指令标签变量；`/菜单同步` 新增 `{menusync_group}` `{menusync_c2c}` `{menusync_skipped}`。
- 与默认完全一致的保存仍写回空值（跟随默认）；「恢复默认」保留。
- 新增「已审核群关闭违禁词时仍按全局撤回并禁言（线上配置复现）」单测：用线上同款配置（群覆盖 `guard.enabled=false` + 全局 `蒋介石`/300 秒）断言先 `recall_group_message` 再 `restrict_chat_set`；单测 46 项。

### VloS v2.9.17（2026-11-22）

- 设置页「指令 → 编辑」打开时，**默认回复直接填进 Markdown 源码并渲染预览**：`/签到` `/list` `/菜单` `/vlos` 是完整默认排版，注册 / 登录等流程指令默认是 `{content}`，可以在默认基础上直接改。
- 新增 **恢复默认** 按钮，一键把源码还原成该指令的内置默认回复。
- 保存时若源码与默认完全一致，按「留空 = 跟随内置默认」保存，不把默认文案写死（以后默认文案升级仍能自动生效）。
- 默认回复模板只在 `index.js` 维护一份，插件加载时写入 `settings.html` 的 `vlos-command-defaults-data`；单测 44 项。

### VloS v2.9.16（2026-11-22）

- **群管设置只认「已审核」群**：`groups[group_openid]` 仅在 `reviewStatus === 'approved'` 时生效；`pending` / `rejected` 的本群设置整体回落全局（以前 pending 也会部分生效，容易出现“改了没生效”或“半套生效”）。
- 本群覆盖里 `guard.enabled=false` 时，开关 / 违禁词 / 动作 / 禁言秒数全部继承全局，只保留本群入群问答；修复「全局有违禁词但本群不撤回」。
- 干净导出包 `plugin.json` 是空配置，README 增加警告：只用于新装/导入，**不要解压覆盖已有插件**（会清掉 Key、已审核群、`callbackReviews`）。
- 单测 43 项。

### VloS v2.9.15（2026-11-22）

- 管理员审核链接恢复 **24 小时**有效（群主 / 管理员提交的设置页仍是 10 分钟）。
- 审核链接文字、审核页副标题、设置页提示同步改为 24 小时。

### VloS v2.9.14（2026-11-22）

- 明确两条私聊主动消息路径，并统一由 `adminNotify=false` 控制：
  - **群管设置链接**：先走「群消息 `msg_id` → 单聊」发给发起 `/群管` 的用户；失败才降级主动 C2C；仍失败则群内被动回复让用户先加机器人好友。
  - **待审核通知**：提交后主动 C2C 发给 `groupAdmin.adminOpenids` 的管理员（设计行为）。
- `adminNotify=false` 会同时关闭「群管链接的主动 C2C 回退」和「待审核通知」，只写入待审核列表。
- VloS README / api.html 修正流程描述（之前误写成“不再发主动 C2C”）。

### VloS v2.9.13（2026-11-22）

- 进退群欢迎改为**只用事件外层 id 作 `event_id`**；event_id 被拒（40034025/26/27）时只写日志，不再降级主动消息，避免触发主动消息权限/风控。
- Markdown 被拒时同一 event_id 下降级纯文本，仍不产生主动消息。
- 报错文案统一 `【[404 error] …】` 前缀，由框架拦截并写日志；管理员私聊通知是唯一主动 C2C，可用 `adminNotify=false` 关闭。
- 违禁词提醒改为被动回复当前消息，不再发群主动消息。
- 框架 README、插件 README、api.html 同步更新。

### VloS v2.9.12（2026-11-22）

- 指令回复改为**只发 Markdown**：Markdown 发送失败只记日志，不再降级纯文本、也不再补发修改前的默认回复。
- 去掉 2.9.11 的事件去重 guard：配置以最新版为准，不再用「先到先得」压掉新回复。
- 自定义回复只采用当前配置模板；旧配置不会参与拼接。

### VloS v2.9.11（2026-11-22）

- 修复自定义回复重复：Markdown 发送失败时降级文本改用**自定义回复的纯文本**，不再回退到修改前的默认回复。
- 同一事件只允许发一条 Markdown 指令回复（全局 event id 去重 60 秒），防止热重载残留旧实例导致「修改前 + 修改后」两条。
- 日志会标记「降级纯文本（自定义回复）」和「跳过重复回复 event=...」。

### VloS v2.9.10（2026-11-22）

- 修复自定义回复失败时的降级文本：优先用自定义回复的纯文本，不再回退到修改前的默认回复，避免「修改后 + 修改前」两条。
- 日志会标记「降级纯文本（自定义回复）」，便于确认是否走了兜底。

### VloS v2.9.9（2026-11-22）

- 按社区实测纠正：成员进群 / 退群**优先用事件外层 id 作 `event_id`**（官方文档只列了 `INTERACTION_CREATE` / `GROUP_ADD_ROBOT` / `GROUP_MSG_RECEIVE`，但实测这两个事件也能发出去），不再强制走主动消息。
- 发送链路四级兜底：`event_id + Markdown` → `event_id + 纯文本` → `主动消息 + Markdown` → `主动消息 + 纯文本`；只有 Markdown / 引用类错误才继续降级，网络/频控直接停，避免重复轰炸。
- 日志会写明最终走哪条路（如「欢迎语已发送（event_id + Markdown）」）与错误码提示。
- 单测覆盖：event_id 优先、`40034027` 后降级主动消息、`304036` 时同 event_id 降纯文本，42 项全过。

### VloS v2.9.8（2026-11-22）

- **纠正 2.9.6 的回退**：官方文档明确 `event_id` 只支持 `INTERACTION_CREATE`、`GROUP_ADD_ROBOT`、`GROUP_MSG_RECEIVE`；`GROUP_MEMBER_ADD` / `GROUP_MEMBER_REMOVE` 没有被动回复接口，2.9.7 用 `event_id` 发进群欢迎会被服务端拒绝（`40034027 该事件不支持回复消息`）。
- 成员进群 / 退群改为只发**群主动消息**（不带 `msg_id` / `event_id` / `msg_seq`）；Bot 入群仍用 `event_id`。
- 失败日志按官方错误码给出提示：`40034105` 无主动消息权限、`40034100` 主动消息频控、`40034101/40054003` 机器人不在群、`40034027` 仍在用 event_id。
- Markdown 被拒（`304036` 无 Markdown 模板权限等）时自动降级**纯文本主动消息**重试一次，保留成员/群名信息；日志会注明“已降级纯文本”。
- 单测同步改为断言“成员进群/退群不带任何回复引用”，并覆盖 Markdown 降级，42 项全过。

### v1.4.0（2026-11-22）

- **修复 4009「连接过期」不自动连接**：4009（以及 4006/4007/4010/4011/4012）现在会清空 `session_id`/`seq`，重连时重新 Identify，而不是一直拿过期 session 去 Resume、失败到冷却循环。连接页仍显示轮次/冷却。
- **群成员事件进「消息」页**：进群、退群、加群申请、机器人入群/退群、加好友/删好友按行展示，新增「群事件」筛选；群名、成员 OpenID、验证信息、操作人都能看到，详情抽屉可直接看原始事件。搜索也覆盖这些事件。
- **机器人自己发出的消息也记录**：主动发送、被动回复、`event_id` 回复、插件动作回复成功后统一走 `Bot._recordOutgoing()`，进内存事件环 + `messages-*.jsonl`（`direction:"out"`）+ 面板实时推送；消息页新增「机器人」筛选，显示发送账号、目标群/用户与内容。发送失败不记录。
- 网关 e2e 补 4009 重连用例（19 项），重连测试补 4009/4006/4915 用例（31 项），回复测试补发送记录用例（66 项），主回归 **300 项**。

### v1.3.9（2026-11-22）

- 面板 UI 移植 VloSMarket 的**白天/夜晚主题 + 页面背景**：
  - 主题按钮改成「☀️/🌙 + 白天/夜晚」胶囊；登录页右上角固定一颗，登录后自动隐藏；切换有 0.5 秒颜色渐变，`localStorage` 记忆。
  - 新背景层：底部双层海浪（夜/昼各两层交叉淡化，34s/52s 漂移）、细点阵纹理、18 颗缓慢上浮的光点；全部 `pointer-events:none`，`prefers-reduced-motion` 下静止。
  - 白天配色按 VloSMarket 的浅色调（`#eef2f9` 底、白色卡片、蓝紫点缀），夜晚保持原深色。
- 前端仍零依赖：只改 `src/web/index.html`、`style.css`、`app.js`，不引入图片/字体/CDN。
- 新增 4 张主题截图：`docs/images/theme-{light,dark}-{login,dashboard}.png`。

### v1.3.8（2026-11-22）

- **重连不再放弃**：一轮 8 次用尽后进入冷却（默认 60 秒，`bot.reconnectCooldownSec` 可配），冷却结束重置次数继续下一轮，无限循环；连接页新增 `cooldown` 状态、轮次与冷却剩余秒数。
- IP 白名单（11298）与 4914/4915（下架/封禁）仍保持 fatal：这两类必须人工处理，继续重试只会触发限频。
- **机器人/面板隔离**：网关所有事件走 `_emitSafe`，Bot 的 ready/dispatch/fatal/state 回调走 `_guard`，账户事件转发、面板状态聚合与 `/health` 全部兜底；机器人掉线、重连、账户异常不再能把框架带崩。
- `CrashGuard` 不再因“短时间内异常过多”主动退出，只记录 `exceptionBurst`；面板不会跟着没。
- 新增 `test/reconnect-loop-test.js`（26 项）、`test/isolation-test.js`（16 项），主回归扩到 287 项。

### v1.3.7（2026-11-21）

- 面板「设置」新增**定时重启**：开关 + 间隔分钟数（1–10080，默认 360），保存即生效；到点执行**进程内重启**（PID 不变、启动器窗口不关），另加「立即重启」按钮。
- 新增 `src/core/maintenance.js`（配置归一化/下次时间）、`POST /api/system/restart`、`/api/status` 的 `system.restart`（`{ enabled, minutes, nextAt }`）。
- `src/index.js` 重构为 boot/dispose：在线更新、手动重启、定时重启共用同一套进程内重启流程，重启失败才退出交给启动器。
- **接口调用日志**：`log.api`（默认开）记录每次 QQ API 调用的 `方法 路径 → 状态 耗时`，带 `traceId` 与重试次数；成功记 DEBUG、失败记 WARN（含 `code` 与接口 message）。
- `log.apiBody`（默认关）额外记录请求/响应体，`token/secret/authorization/password/cookie/key` 自动打码并截断。
- 事件与插件分发补 DEBUG 日志：`收到事件 X`、`事件 X 分发给 N 个插件`、`插件 Y 处理 X 完成 Zms`。
- 新增 `test/restart-log-test.js`（33 项）、`test/restart-e2e.js`（16 项），主回归扩到 246 项。

### v1.3.6（2026-11-21）

- **稳定性**：新增 `src/core/health.js`，未捕获异常 / 未处理的 Promise 拒绝先写 `~JlWBoT/logs/crash.log` 再继续运行；同分钟异常过多才主动退出交给启动器重启。
- 新增心跳 `~JlWBoT/logs/heartbeat.json`（15 秒一次）；启动时若发现上次没正常收尾，会在日志里告警并给出最后心跳时间。
- `/health` 增加 `pid`、`node`、`listening`、`lastCrash`、`lastServerError`，面板打不开时也能用命令行确认进程状态。
- HTTP 服务增加常驻 `error` / `clientError` 处理和看门狗：监听意外停止会自动重新 listen（指数退避），畸形请求行返回 400 而不是抛异常。
- WebSocket 握手阶段补 `error` 监听，帧解析整体 try/catch，畸形帧只断开该客户端。
- `src/core/logger.js`：stdout 写失败（EPIPE / 控制台冻结 / 被关闭）不再带崩进程，连续失败自动关闭控制台输出，文件日志继续写。
- `tools/start-panel.ps1`：自动关闭控制台「快速编辑」，避免误点选中把整个进程冻住（症状正是“不回复、没日志、端口打不开”）；异常退出自动重启（最多 3 次，`-NoRestart` 关闭）；新增 `-Background` 隐藏窗口运行；被强杀时 `ExitCode` 为 null 也按异常处理。
- 新增 `test/resilience-test.js`（26 项），主回归扩到 196 项。

### v1.3.5（2026-11-21）

- 修正**回复引用**：新增 `Bot.replyEvent(evt, content)`，`GROUP_ADD_ROBOT` / `GROUP_MSG_RECEIVE` / `INTERACTION_CREATE` 只用 `event_id` 做被动回复，不带 `msg_id`、不带 `msg_seq`。
- `GROUP_MEMBER_ADD` / `GROUP_MEMBER_REMOVE` / `GROUP_JOIN_REQUEST` / `FRIEND_ADD` / `FRIEND_DEL` / `GROUP_DEL_ROBOT` **没有被动回复接口**，`replyEvent` 直接返回 `code: NO_PASSIVE_REPLY` 并提示改用主动群消息；不再把事件 id 塞进 `msg_id` 发出去。
- `reply()` / `sendGroup()` / `sendC2C()` / `sendChannel()` 增加引用校验：`msg_id` 与 `event_id` 互斥、`event_id` 不能带 `msg_seq`（`code: BAD_REPLY_REF`）；消息事件传 `event_id` 也拒绝。
- 插件输出和动作 `reply` 自动分流：有 `message` 走 `msg_id`，事件走 `event_id`，没有接口的事件只记警告、不假装回复成功。
- 事件对象新增 `eventId`（事件外层 id）；`ctx.bot.replyEvent()` / `ctx.api.replyEvent()` 可直接调用。
- 面板「发送消息」新增事件 id 输入框，`/api/send` 支持 `event_id`。
- 新增 `test/reply-event-test.js`（59 项），网关端到端补 2 项，主回归扩到 170 项。
- 接口页「发送群聊消息」备注补上三种引用方式的区别。

### v1.3.4（2026-11-21）

- 左侧导航「插件」下新增 **市场**，内嵌 `https://vlos.jlworld.net/`，可浏览/下载插件。
- 新增 `src/core/market-proxy.js`：同源反向代理，去掉上游 X-Frame-Options/CSP，改写 HTML/CSS/JS 根路径，不转发面板 `jlw_sid`。
- 新增 `test/market-proxy-test.js`（15 项），主回归扩到 109 项。
- 市场页面需要联网；市场自身仍有聚龙世界登录门禁。

### VloS v2.9.7（2026-11-22）

- 「指令」页每行「备注」右侧新增 **编辑**：Markdown 源码左、实时预览右，变量标签可点击插入。
- 新增 `commands.<key>.reply` 自定义回复模板；留空用内置默认，`{content}` 引用默认内容。
- `/签到`、`/list`、`/菜单`、`/vlos` 提供拆解变量（poem/longjing/xuanyu/days/streak、email/qq/wallet、items、commands/version 等），方便重排版；流程指令只套用首次提示。
- 单测 42 项。

### VloS v2.9.6（2026-11-22）

- 恢复**成员进群**用事件外层 id 作 `event_id` 的被动回复：历史日志 21:42 / 22:09 已证明 `GROUP_MEMBER_ADD` 可发出去，2.9.5 改成主动消息是回退。
- `GROUP_ADD_ROBOT` 继续用 `event_id`；`GROUP_MEMBER_REMOVE` 先试 `event_id`，失败再降级主动消息。
- 不使用 `msg_id` 传事件 id（22:16 / 22:33 实测返回 40034024）。

### VloS v2.9.5（2026-11-21）

- 修正进退群欢迎消息接口：`GROUP_MEMBER_ADD` / `GROUP_MEMBER_REMOVE` 没有被动回复接口，改为群主动消息（需主动权限）；只有 `GROUP_ADD_ROBOT` 使用 `event_id` 被动回复。
- 删除把事件 id 塞进 `msg_id` 的错误写法；`scheduleBotJoinRetry` 改用 `event_id`。
- 同步更新 `plugins/VloS/README.md`、`api.html` 与单测断言。
- 重新导出 `插件\VloS-【v2.9.5】.zip`（空 Key，可直接导入）。

### VloS v2.9.4（2026-11-21）

- 进群 / Bot 入群欢迎语改为**被动消息**：把事件外层 id 作为群消息接口的 `msg_id` 传入，不传 `event_id`，也不额外传 `msg_seq`。
- 退群先试同样的被动消息（`msg_id=event_id`）；退群专用回复接口未开放 / 失败时才降级主动消息。
- Bot 入群补发只重试被动消息，不再走主动消息、不再等管理员权限。
- 按用户实测：用户进群用事件 id 作 `msg_id` 可正常发出，不需要主动消息权限。

### v1.3.3（2026-11-21）

- 新增**登录范围**：只有 `auth.allowed` 中的聚龙账户可以登录；未加入的账户密码正确也返回 403。
- 首次运行没有允许账户时，`启动机器人.cmd` / `node src/index.js` 在 CMD 引导添加第一个邮箱；支持 `--allow-email` 无交互。
- 面板左下角新增【登录范围】按钮：查看、添加、移除允许登录的聚龙账户；至少保留一个。
- 登录、注册、找回密码都校验登录范围；被移除账户的旧 HTTP 会话在下一次请求失效。
- 升级时自动从 `~JlWBoT/data/sessions.json` 的有效会话迁移登录范围，避免升级锁死。
- 新增 `src/core/login-scope.js`、`tools/setup-login.js`、`test/auth-scope-test.js`（10 项）。
- 插件卡片新增【更新】按钮：上传同 ID 的新版本 zip，保留 `config` / `enabled` / `data`，失败自动回滚；卡片上的【API】按钮移除，API 文档入口保留在编辑弹窗。
- 新增 `test/plugin-update-test.js`（12 项）。
- 测试/应急环境变量 `JLW_ALLOW_ALL_LOGIN=1` 可临时关闭限制（会警告）。

### v1.3.2（2026-11-21）

- 新增**在线更新**：QQBOT 页面检查、左下角提示、下载/校验/覆盖/自动重启。
- 新增 `src/core/updater.js`、`src/core/update-apply.js`。
- 导出包顶层目录固定为 **`JlW-BoT`**，方便直接替换；新增 `tools/export-framework.ps1`。
- 新增更新测试 `test/update-test.js`、`test/update-api-test.js`。
- 新增 `test/run-all.js`：不依赖 npm 的主回归跑批。
- README 扩展为项目总入口/跨会话交接文档（含 API、配置、插件、更新、部署、排错、当前快照）。

### v1.3.1

- 修复旧导出包 `jlw.baseUrl` 为空/本机地址导致的「账户站点 未配置」/登录 `ECONNRESET`。
- 启动自动恢复官方站点；运行中本机地址登录返回 400 明确提示。
- `JLW_ALLOW_LOCAL_SITE=1` 保留本地 mock 调试。
- 配置读取去 UTF-8 BOM。

### v1.3.0

- 补上 QQ 2026-08 新增的 `GROUP_MEMBER_EVENT`（1<<24）：群成员加入/退出、用户申请加群。
- 插件可订阅 `GROUP_MEMBER_ADD` / `GROUP_MEMBER_REMOVE` / `GROUP_JOIN_REQUEST`。
- 群消息事件补 `author.member_nickname`。

### 更早

- 多账户、WebSocket/WebHook、67 个 API、面板、插件系统、易语言 pull/DLL、VloS/Arknights 等功能见 `docs/` 与插件 README。

---

## 18. 文档地图

| 想了解 | 看 |
| --- | --- |
| 插件开发（多语言/易语言/动作/字段） | [docs/插件开发.md](docs/插件开发.md) |
| 易语言拉取/DLL 宿主/排错 | [docs/易语言对接.md](docs/易语言对接.md) |
| 67 个 QQ API v2 接口 + 插件市场上传 API | [docs/API接口.md](docs/API接口.md) |
| 部署/端口/WebHook/自启/升级 | [docs/部署与脱机运行.md](docs/部署与脱机运行.md) |
| VloS 插件（注册/签到/群管/审核/API） | [plugins/VloS/README.md](plugins/VloS/README.md) |
| Arknights 插件 | [plugins/Arknights/README.md](plugins/Arknights/README.md) |
| 面板内置文档 | <http://127.0.0.1:8686/docs.html> |

---

## 附录 A：mcstatus 插件详解（v1.3.3）

> 运行目录 `~JlWBoT/plugins/mcstatus/`（index.js / plugin.json / settings.html / README.md）；源码副本 `plugins/mcstatus/`；纯净导入包 `插件/我的世界查询-【v1.3.3】.zip`。数据来源：聚龙世界 MCStatus 接口（`/api/plugin/mcstatus/query|image|frames`），密钥在 `config.key`。

### A.1 行为

| 指令 | 行为 |
| --- | --- |
| `/MC 地址` | 一条被动回复：`@用户` + 引用原消息 + 随机底图状态图 |
| `/MC 地址 -json` | JSON 代码块返回 query 原始数据 |
| `/MC api` | 官网配图 + 图片接口帮助 |
| `/MC` | 菜单：可选图标 + 指令列表 + 蓝色按钮 |

- 必须带 `/` 或 `／` 前缀（入口判 `^[/／]`），不带 `/` 的聊天忽略。
- 地址支持 `host` / `host:port`，默认 25565。
- 失败（超时/地址不存在/图片失败）→ 提示 + 【重新查询】按钮（`enter=true` 自动重发原指令）。
- **只用 Markdown（v1.3.2 起）**：所有回复都是 `msg_type=2`，发送失败只记日志，不回退纯文本、不回退富媒体，也不重发，避免同一条消息出现两次。

### A.2 图片必须走 QQ 素材库

公网图片 URL 写进 Markdown 会「加载失败」（平台转存失败，消息里的 URL 会变成 `https:`）。正确做法：

1. `POST /v2/media-images/prepare` `{file_name, file_size, content_type, md5, sha1}` → `upload_id` + `presigned_url`
2. `PUT <presigned_url>`（二进制，`Content-Type` 必须与 prepare 一致）
3. `POST /v2/media-images/complete` `{upload_id, md5}` → `qqbot-media://image/v1/<token>`

Markdown：`![服务器状态图 #760px #270px](qqbot-media://image/v1/...)`。素材 90 天滑动有效、上限 100 张；插件只清理 `mc-status-*`（保留 `mediaKeep=60`），菜单图标 `mc-menu-icon-*` 缓存 30 天重传。

### A.3 @ / 引用 / 按钮

- 群聊 @ 用户：`<qqbot-at-user id="member_openid" />`，**只支持 Markdown 消息**。
- 引用：被动回复带原消息 `msg_id`（`ctx.api.reply` 自动带）。
- 按钮：`keyboard.content.rows[].buttons[]`，`action.type=2` 指令按钮，`enter=false` 填输入框 / `true` 直接发送，`style=1` 蓝框，`permission.type=2` 所有人。
- 自定义按钮需平台“内邀开通”；未开通时发送失败，插件只记日志、不降级。

v1.3.2 起不再有降级链：唯一发送路径是 `Markdown`（可带按钮），失败不打第二条。

### A.4 设置页（settings.html）

面板「插件 → 编辑 → 设置」内嵌；`GET /api/plugins/:id/settings` 返回文件，iframe `sandbox="allow-scripts allow-popups"`。协议：

- init：`{type:'jlw-settings-init', config}`
- 面板点保存 → iframe：`{type:'jlw-settings-save-request'}`
- iframe → 面板：`{type:'jlw-settings-save', config}`（保留 config 其他字段）
- 面板落盘 `POST /api/plugins/:id/config` → 重载插件

页面提供接口密钥 + 指令表格（按钮文字 / 指令 / 备注 / 操作）。每行「删除」旁有 **【编辑】**：点开后左侧是 Markdown 源码、右侧实时预览，上方是可点击插入的变量标签（`{{host}}` 等），底部「恢复默认 / 取消 / 完成」。

### A.4.1 可编辑回复模板（v1.3.0）

每条指令的回复内容存在 `config.commands[].reply`（Markdown），`type` 决定它对应哪个处理器：

| type | 指令 | 可用变量 |
| --- | --- | --- |
| `status` | `/MC 地址` | `user` `image` `imageUrl` `host` `port` `address` `edition` `version` `protocol` `online` `onlineBool` `players` `maxPlayers` `motd` `ping` `frame` `queried` |
| `json` | `/MC 地址 -json` | `json` `ok` `error` `host` `port` `address` `online` `players` `maxPlayers` `version` |
| `api` | `/MC api` | `site` `apiBase` `imageEndpoint` `queryEndpoint` `framesEndpoint` `siteImage` |
| `menu` | `/MC` | `icon` `commands` `title` |

渲染规则：

- `{{变量}}` 直接替换；未知变量原样保留（方便发现拼写错误）。
- `{{image}}` 是上传素材库后的 Markdown 图片；模板不含 `{{image}}` 时不调用素材上传，发送更快。
- 模板为空 → 用内置默认模板（与 1.2.x 行为一致）。
- 模板要图但素材上传失败 → 直接回退富媒体图片，避免发出只有 @ 的空消息。
- 渲染后去掉首尾空行（`{{icon}}` 为空时不留空洞）。

### A.5 开发 / 部署

1. 改 `~JlWBoT/plugins/mcstatus/index.js`
2. `node --check` + `node test/mcstatus-test.js`（23 项，本地假服务，不耗线上额度）
3. 同步源码副本 `plugins/mcstatus/`
4. 热重载：读 `~JlWBoT/data/sessions.json` 取有效 sid → `POST http://127.0.0.1:8686/api/plugins/mcstatus/reload`，header `x-jlw-session: <sid>`
5. 校验 `GET /api/plugins`：`status=running`、`errors=0`

### A.6 踩坑

| 现象 | 结论 |
| --- | --- |
| 群里图片“加载失败”，URL 变 `https:` | 外链转存失败；改用素材库 |
| 只有 @ 没图 | 素材 prepare/PUT/complete 失败，看 `plugin:mcstatus` 日志 |
| 按钮不出现 | 自定义按钮未开通；已自动降级 |
| 点按钮直接发送 | `action.enter=true`；要填输入框用 `false` |
| 群里 @ 不出来 | `<qqbot-at-user>` 只支持 Markdown，且填 `member_openid` |
| 模拟事件发不出真实消息 | 测试接口用 `TEST_GROUP`，QQ 返回 11255 |
| 单测素材上传被跳过 | fixture 必须是合法 PNG/JPEG 魔数 |
| PC QQ 里一条 Markdown 显示成两个「暂不支持该消息类型」 | PC 客户端不支持 Markdown，把图片块和文本块各渲染成一个占位；消息记录里只有一条 `BOT_MESSAGE_CREATE`，手机 QQ 正常显示，不是重复发送 |
| 回复报 `40054005 消息被去重` | 短时间内发了内容完全相同的消息（如连续 `/MC api`）；插件回退纯文本一条，不重发 Markdown |

### A.7 版本历史

| 版本 | 内容 |
| --- | --- |
| 1.0.0 | 查询 + 随机底图 + `-json` + `api` 帮助 |
| 1.1.0 | 菜单按钮、@+引用+图一条回复、素材库、重新查询、`/` 前缀 |
| 1.2.0 | 面板设置页（指令 + 备注） |
| 1.2.1 | 设置页接口密钥输入、纯净 zip 导出 |
| 1.3.0 | 每条指令可编辑 Markdown 回复模板（变量替换）、设置页双栏编辑器（源码 + 实时预览） |
| 1.3.1 | 发送失败不再重发无按钮 Markdown（避免平台判重/重复展示），直接回退纯文本 |
| 1.3.2 | 去掉全部降级：只用 Markdown 发送（失败只记日志，不回退纯文本/富媒体）；旧配置自动补 type 并整体替换 |
| 1.3.3 | 设置页变量改为下拉选择 + 说明 + 插入按钮；纯净包 plugin.json 带默认 4 条指令（不再空白） |

---

## 19. 许可

BSD 3-Clause（允许商用、修改、再分发；不得用作者/贡献者名义为衍生品背书）。QQ 机器人相关接口与文档版权归腾讯所有；聚龙世界账户接口与文档版权归聚龙世界所有。
