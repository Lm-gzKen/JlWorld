'use strict';
/**
 * access_token 管理：获取 / 缓存 / 到期前刷新 / 失效重取
 * 官方接口：POST https://bots.qq.com/app/getAppAccessToken  {appId, clientSecret}
 */
class TokenManager {
  constructor({ config, logger, accountId }) {
    this.config = config;
    this.accountId = accountId || config.accountId || '';
    this.log = logger.child(this.accountId ? 'token:' + this.accountId : 'token');
    this.token = '';
    this.expiresAt = 0;
    this.refreshing = null;
    this.lastError = null;
    this.timer = null;
    this.fetchImpl = globalThis.fetch;
  }

  get valid() {
    return !!this.token && Date.now() < this.expiresAt - 5000;
  }

  header() {
    return 'QQBot ' + this.token;
  }

  async get(force = false) {
    if (!force && this.valid) return this.token;
    if (this.refreshing) return this.refreshing;
    this.refreshing = this._refresh().finally(() => {
      this.refreshing = null;
    });
    return this.refreshing;
  }

  invalidate() {
    this.token = '';
    this.expiresAt = 0;
  }

  async _refresh() {
    const appId = this.config.get('bot.appId', '');
    const secret = this.config.secret() || this.config.get('bot.clientSecret', '');
    if (!appId || !secret) {
      const err = new Error('未配置 AppID / AppSecret');
      err.code = 'NO_CREDENTIALS';
      this.lastError = err.message;
      throw err;
    }
    const urls = [this.config.get('bot.tokenUrl'), this.config.get('bot.tokenUrlAlt')].filter(Boolean);
    let lastErr;
    for (const url of urls) {
      try {
        const t0 = Date.now();
        const res = await this.fetchImpl(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ appId, clientSecret: secret }),
          signal: AbortSignal.timeout(15000),
        });
        const text = await res.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch {
          throw new Error(`返回非 JSON（HTTP ${res.status}）`);
        }
        if (!data.access_token) {
          const e = new Error(data.message || `获取 access_token 失败(code=${data.code ?? res.status})`);
          e.code = data.code;
          throw e;
        }
        this.token = data.access_token;
        const ttl = Number(data.expires_in) || 7200;
        this.expiresAt = Date.now() + ttl * 1000;
        this.lastError = null;
        this.log.info(`access_token 获取成功`, { ttl, ms: Date.now() - t0 });
        this._schedule();
        return this.token;
      } catch (e) {
        lastErr = e;
        this.log.warn(`token 接口失败：${url}`, { error: e.message });
      }
    }
    this.lastError = lastErr?.message || 'unknown';
    throw lastErr || new Error('获取 access_token 失败');
  }

  _schedule() {
    clearTimeout(this.timer);
    const ms = Math.max(30000, this.expiresAt - Date.now() - 60000);
    this.timer = setTimeout(() => {
      this.get(true).catch((e) => this.log.error('自动刷新 token 失败: ' + e.message));
    }, ms);
    if (this.timer.unref) this.timer.unref();
  }

  info() {
    return {
      hasToken: !!this.token,
      expiresAt: this.expiresAt,
      ttlLeft: this.expiresAt ? Math.max(0, this.expiresAt - Date.now()) : 0,
      lastError: this.lastError,
    };
  }

  stop() {
    clearTimeout(this.timer);
    this.timer = null;
  }
}

module.exports = TokenManager;
