'use strict';
/**
 * 框架统一存储（SQLite，Node 内置 node:sqlite，零 npm 依赖）
 *
 * 表：
 *   kv        配置等小对象（config / legacy_imported 等）
 *   sessions  面板登录会话
 *   logs      运行日志（替代 logs/jlwbot-*.jsonl）
 *   messages  收发消息（替代 data/messages-*.jsonl）
 *
 * 首次启动会把旧的 JSON/JSONL 迁进来（config.json、data/sessions.json、
 * logs/jlwbot-*.jsonl、data/messages-*.jsonl），迁移完把旧文件移到
 * ~JlWBoT/backup/legacy-json-<时间>/ 保留，方便回滚。
 */
const fs = require('fs');
const path = require('path');
const U = require('./util');

let handle = null;
let stmts = null;

const LEVELS = { trace: 10, debug: 20, info: 30, warn: 40, error: 50 };
const LEVEL_SETS = {
  debug: ['debug', 'info', 'warn', 'error'],
  info: ['info', 'warn', 'error'],
  warn: ['warn', 'error'],
  error: ['error'],
};

function dbFile() {
  return path.join(U.dataRoot(), 'jlwbot.db');
}

function open() {
  if (handle) return handle;
  const { DatabaseSync } = require('node:sqlite');
  U.ensureDir(U.dataRoot());
  handle = new DatabaseSync(dbFile());
  handle.exec('PRAGMA journal_mode = WAL');
  handle.exec('PRAGMA synchronous = NORMAL');
  handle.exec('PRAGMA busy_timeout = 5000');
  handle.exec(`
    CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL, updated INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (sid TEXT PRIMARY KEY, json TEXT NOT NULL, created INTEGER, expires INTEGER);
    CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, day TEXT NOT NULL,
      level TEXT NOT NULL, scope TEXT, msg TEXT, meta TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_logs_day ON logs(day);
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, day TEXT NOT NULL,
      direction TEXT, event TEXT, kind TEXT, msg_id TEXT, content TEXT,
      author TEXT, aname TEXT, account_id TEXT, account_name TEXT,
      group_openid TEXT, user_openid TEXT, channel_id TEXT, guild_id TEXT,
      attachments INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_messages_day ON messages(day);
  `);
  // v1.6.2 起给消息补一列 payload（机器人发出时的原始 body，用于面板渲染卡片/markdown）
  try {
    const cols = handle.prepare('PRAGMA table_info(messages)').all();
    if (!cols.some((c) => c.name === 'payload')) handle.exec('ALTER TABLE messages ADD COLUMN payload TEXT');
  } catch {
    /* ignore */
  }
  stmts = {
    kvGet: handle.prepare('SELECT v, updated FROM kv WHERE k = ?'),
    kvSet: handle.prepare('INSERT INTO kv(k, v, updated) VALUES (?, ?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v, updated = excluded.updated'),
    kvDel: handle.prepare('DELETE FROM kv WHERE k = ?'),
    sessAll: handle.prepare('SELECT sid, json, created, expires FROM sessions ORDER BY created ASC'),
    sessClear: handle.prepare('DELETE FROM sessions'),
    sessPut: handle.prepare('INSERT OR REPLACE INTO sessions(sid, json, created, expires) VALUES (?, ?, ?, ?)'),
    logIns: handle.prepare('INSERT INTO logs(ts, day, level, scope, msg, meta) VALUES (?, ?, ?, ?, ?, ?)'),
    logDay: handle.prepare('SELECT * FROM logs WHERE day = ? ORDER BY ts DESC, id DESC LIMIT ?'),
    logDayLevel: handle.prepare('SELECT * FROM logs WHERE day = ? AND level IN (SELECT value FROM json_each(?)) ORDER BY ts DESC, id DESC LIMIT ?'),
    logDayQ: handle.prepare("SELECT * FROM logs WHERE day = ? AND (msg LIKE ? OR meta LIKE ?) ORDER BY ts DESC, id DESC LIMIT ?"),
    logDayLevelQ: handle.prepare("SELECT * FROM logs WHERE day = ? AND level IN (SELECT value FROM json_each(?)) AND (msg LIKE ? OR meta LIKE ?) ORDER BY ts DESC, id DESC LIMIT ?"),
    logDates: handle.prepare('SELECT day, COUNT(*) AS count FROM logs GROUP BY day ORDER BY day DESC'),
    logCount: handle.prepare('SELECT COUNT(*) AS n FROM logs WHERE day = ?'),
    msgIns: handle.prepare(`INSERT INTO messages(ts, day, direction, event, kind, msg_id, content, author, aname, account_id, account_name, group_openid, user_openid, channel_id, guild_id, attachments, payload)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),
    msgDay: handle.prepare('SELECT * FROM messages WHERE day = ? ORDER BY ts DESC, id DESC LIMIT ?'),
    msgDayAcc: handle.prepare('SELECT * FROM messages WHERE day = ? AND account_id = ? ORDER BY ts DESC, id DESC LIMIT ?'),
    msgDates: handle.prepare('SELECT day, COUNT(*) AS count FROM messages GROUP BY day ORDER BY day DESC'),
  };
  // 第一次打开时自动把旧的 JSON/JSONL 迁进来（migrate 内部有 migrated 闸，
  // 它调用 insertLog/insertMessage 时会再次进 open()，不会递归迁移）
  if (!migrated) migrate();
  return handle;
}

function getDb() {
  const db = open();
  migrate();
  return db;
}

function dayOf(ts) {
  return U.dayKey(new Date(Number(ts) || Date.now()));
}

/** 带本地时区的 ISO 时间（和日志里原来的 time 格式一致） */
function isoTs(ts) {
  const d = new Date(Number(ts) || Date.now());
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? '+' : '-';
  const pad = (x, n = 2) => String(x).padStart(n, '0');
  return (
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}` +
    `${sign}${pad(Math.floor(Math.abs(off) / 60))}:${pad(Math.abs(off) % 60)}`
  );
}

/* ---------------- kv ---------------- */

function kvGet(key, fallback = null) {
  try {
    open();
    const row = stmts.kvGet.get(key);
    if (!row) return fallback;
    return JSON.parse(row.v);
  } catch {
    return fallback;
  }
}

function kvGetWithTime(key) {
  try {
    open();
    const row = stmts.kvGet.get(key);
    if (!row) return null;
    return { value: JSON.parse(row.v), updated: Number(row.updated) || 0 };
  } catch {
    return null;
  }
}

function kvSet(key, value) {
  open();
  stmts.kvSet.run(key, JSON.stringify(value), Date.now());
}

/* ---------------- 日志 ---------------- */

function normalizeTs(rec) {
  let ts = Number(rec && rec.t) || 0;
  // 旧数据/测试里可能有 t=1 这种占位值：小于 1e11（1973 年）就当无效，改用 time 字段
  if (!(ts > 1e11)) ts = Date.parse((rec && rec.time) || '') || ts || Date.now();
  return ts;
}

function insertLog(rec) {
  open();
  const ts = normalizeTs(rec);
  stmts.logIns.run(
    ts,
    dayOf(ts),
    String(rec.level || 'info'),
    rec.scope || '',
    String(rec.msg == null ? '' : rec.msg),
    rec.meta === undefined ? null : JSON.stringify(rec.meta),
  );
}

function rowToLog(row) {
  let meta;
  try {
    meta = row.meta ? JSON.parse(row.meta) : undefined;
  } catch {
    meta = undefined;
  }
  return { t: row.ts, time: isoTs(row.ts), level: row.level, scope: row.scope || undefined, msg: row.msg || '', meta };
}

function logsByDay(day, { level = '', q = '', limit = 2000 } = {}) {
  open();
  const lim = Math.max(1, Math.min(Number(limit) || 2000, 20000));
  let rows;
  if (level && LEVEL_SETS[level] && q) rows = stmts.logDayLevelQ.all(day, JSON.stringify(LEVEL_SETS[level]), `%${q}%`, `%${q}%`, lim);
  else if (level && LEVEL_SETS[level]) rows = stmts.logDayLevel.all(day, JSON.stringify(LEVEL_SETS[level]), lim);
  else if (q) rows = stmts.logDayQ.all(day, `%${q}%`, `%${q}%`, lim);
  else rows = stmts.logDay.all(day, lim);
  return rows.reverse().map(rowToLog);
}

function logDates() {
  open();
  return stmts.logDates.all().map((r) => ({ date: r.day, count: Number(r.count) || 0 }));
}

function logCount(day) {
  try {
    open();
    const r = stmts.logCount.get(day);
    return Number(r?.n) || 0;
  } catch {
    return 0;
  }
}

/** 某天全部日志（迁移到 JSON 引擎时用） */
function logsAll(day) {
  open();
  return handle
    .prepare('SELECT * FROM logs WHERE day = ? ORDER BY ts ASC, id ASC')
    .all(day)
    .map(rowToLog);
}

/** 清空业务表（切换存储引擎/重新导入前用） */
function resetAll() {
  open();
  handle.exec('DELETE FROM logs; DELETE FROM messages; DELETE FROM sessions;');
}

/** 强制从 JSON/JSONL 重新导入（切换回 SQLite 时用） */
function importFromJson(force = true) {
  open();
  if (force) handle.prepare('DELETE FROM kv WHERE k = ?').run('legacy_imported');
  migrated = false;
  migrate();
}

/* ---------------- 消息 ---------------- */

function insertMessage(rec) {
  open();
  const ts = normalizeTs(rec);
  stmts.msgIns.run(
    ts,
    dayOf(ts),
    rec.direction || 'in',
    rec.event || '',
    rec.kind || '',
    rec.id || '',
    String(rec.content == null ? '' : rec.content),
    rec.author || '',
    rec.name || '',
    rec.accountId || '',
    rec.accountName || '',
    rec.group_openid || '',
    rec.user_openid || '',
    rec.channel_id || '',
    rec.guild_id || '',
    Number(rec.attachments) || 0,
    rec.payload ? JSON.stringify(rec.payload) : null,
  );
}

function rowToMessageRecord(row) {
  return {
    t: row.ts,
    time: isoTs(row.ts),
    event: row.event,
    direction: row.direction,
    kind: row.kind,
    id: row.msg_id,
    content: row.content,
    author: row.author,
    name: row.aname,
    accountId: row.account_id,
    accountName: row.account_name,
    group_openid: row.group_openid,
    user_openid: row.user_openid,
    channel_id: row.channel_id,
    guild_id: row.guild_id,
    attachments: row.attachments,
    payload: (() => {
      try {
        return row.payload ? JSON.parse(row.payload) : undefined;
      } catch {
        return undefined;
      }
    })(),
  };
}

function messagesByDay(day, { account = '', limit = 2000 } = {}) {
  open();
  const lim = Math.max(1, Math.min(Number(limit) || 2000, 20000));
  const rows = account ? stmts.msgDayAcc.all(day, account, lim) : stmts.msgDay.all(day, lim);
  return rows.reverse().map(rowToMessageRecord);
}

function messageDates() {
  open();
  return stmts.msgDates.all().map((r) => ({ date: r.day, count: Number(r.count) || 0 }));
}

/** 某天全部消息（迁移到 JSON 引擎时用） */
function messagesAll(day) {
  open();
  return handle
    .prepare('SELECT * FROM messages WHERE day = ? ORDER BY ts ASC, id ASC')
    .all(day)
    .map(rowToMessageRecord);
}

/* ---------------- 会话 ---------------- */

function sessionLoadAll() {
  open();
  return stmts.sessAll.all().map((r) => {
    try {
      return JSON.parse(r.json);
    } catch {
      return null;
    }
  }).filter(Boolean);
}

function sessionSaveAll(list) {
  open();
  const db = handle;
  db.exec('BEGIN');
  try {
    stmts.sessClear.run();
    for (const s of list) {
      if (!s || !s.sid) continue;
      stmts.sessPut.run(s.sid, JSON.stringify(s), Number(s.createdAt) || 0, Number(s.expiresAt) || 0);
    }
    db.exec('COMMIT');
  } catch (e) {
    try {
      db.exec('ROLLBACK');
    } catch {
      /* ignore */
    }
    throw e;
  }
}

/* ---------------- 迁移旧 JSON/JSONL ---------------- */

function readJsonlFile(file) {
  const out = [];
  let text = '';
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch {
    return out;
  }
  for (const line of text.split('\n')) {
    const s = line.trim();
    if (!s) continue;
    try {
      out.push(JSON.parse(s));
    } catch {
      /* 跳过坏行 */
    }
  }
  return out;
}

function findJsonl(dir, prefix) {
  try {
    return fs
      .readdirSync(dir)
      .filter((f) => f.startsWith(prefix + '-') && f.endsWith('.jsonl'))
      .map((f) => {
        const fp = path.join(dir, f);
        let mtime = 0;
        try {
          mtime = fs.statSync(fp).mtimeMs;
        } catch {
          /* ignore */
        }
        return { fp, mtime };
      })
      .sort((a, b) => a.mtime - b.mtime)
      .map((x) => x.fp);
  } catch {
    return [];
  }
}

function moveLegacy(src, root, sub, stamp) {
  try {
    const dstDir = path.join(root, 'backup', 'legacy-json-' + stamp, sub);
    U.ensureDir(dstDir);
    const dst = path.join(dstDir, path.basename(src));
    fs.renameSync(src, dst);
    return true;
  } catch {
    return false;
  }
}

let migrated = false;
function migrate() {
  if (migrated) return;
  migrated = true;
  try {
    const done = stmts.kvGet.get('legacy_imported');
    if (done) return;
    const root = U.dataRoot();
    const sessFile = path.join(root, 'data', 'sessions.json');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const db = handle;
    let counts = { config: 0, sessions: 0, logs: 0, messages: 0 };

    db.exec('BEGIN');
    try {
      // config.json
      const cfgFile = path.join(root, 'config.json');
      if (fs.existsSync(cfgFile) && !stmts.kvGet.get('config')) {
        const data = U.readJson(cfgFile, null);
        if (data && typeof data === 'object') {
          stmts.kvSet.run('config', JSON.stringify(data), Date.now());
          counts.config = 1;
        }
      }
      // sessions.json
      if (fs.existsSync(sessFile)) {
        const obj = U.readJson(sessFile, {});
        for (const [sid, s] of Object.entries(obj || {})) {
          if (!s || !s.expiresAt) continue;
          stmts.sessPut.run(sid, JSON.stringify({ ...s, sid }), Number(s.createdAt) || 0, Number(s.expiresAt) || 0);
          counts.sessions++;
        }
      }
      // logs
      for (const fp of findJsonl(path.join(root, 'logs'), 'jlwbot')) {
        for (const rec of readJsonlFile(fp)) {
          if (!rec || !rec.level) continue;
          insertLog(rec);
          counts.logs++;
        }
      }
      // messages
      for (const fp of findJsonl(path.join(root, 'data'), 'messages')) {
        for (const rec of readJsonlFile(fp)) {
          if (!rec) continue;
          insertMessage(rec);
          counts.messages++;
        }
      }
      stmts.kvSet.run('legacy_imported', JSON.stringify({ at: Date.now(), counts }), Date.now());
      db.exec('COMMIT');
    } catch (e) {
      try {
        db.exec('ROLLBACK');
      } catch {
        /* ignore */
      }
      throw e;
    }

    // 旧文件挪到 backup，避免重复导入；config.json 保留（会作为可编辑镜像继续写）
    for (const fp of findJsonl(path.join(root, 'logs'), 'jlwbot')) moveLegacy(fp, root, 'logs', stamp);
    for (const fp of findJsonl(path.join(root, 'data'), 'messages')) moveLegacy(fp, root, 'data', stamp);
    if (fs.existsSync(sessFile)) moveLegacy(sessFile, root, 'data', stamp);

    if (counts.config + counts.sessions + counts.logs + counts.messages > 0) {
      console.log(
        `[db] 已把旧 JSON 数据迁入 SQLite：config ${counts.config}、sessions ${counts.sessions}、logs ${counts.logs}、messages ${counts.messages}（旧文件在 ~JlWBoT/backup/legacy-json-${stamp}/）`,
      );
    }
  } catch (e) {
    console.error('[db] 迁移旧 JSON 数据失败：' + (e && e.message));
  }
}

function pruneLogs(keepDays = 7) {
  const days = Math.max(1, Number(keepDays) || 7);
  const cut = U.dayKey(new Date(Date.now() - days * 86400000));
  try {
    open();
    handle.prepare('DELETE FROM logs WHERE day < ?').run(cut);
    return true;
  } catch {
    return false;
  }
}

function pruneMessages(keepDays = 30) {
  const days = Math.max(1, Number(keepDays) || 30);
  const cut = U.dayKey(new Date(Date.now() - days * 86400000));
  try {
    open();
    handle.prepare('DELETE FROM messages WHERE day < ?').run(cut);
    return true;
  } catch {
    return false;
  }
}

function checkpoint() {
  try {
    if (handle) handle.exec('PRAGMA wal_checkpoint(TRUNCATE)');
  } catch {
    /* ignore */
  }
}

function close() {
  try {
    if (handle) {
      checkpoint();
      handle.close();
    }
  } catch {
    /* ignore */
  }
  handle = null;
  stmts = null;
}

module.exports = {
  getDb,
  dbFile,
  kvGet,
  kvGetWithTime,
  kvSet,
  insertLog,
  logsByDay,
  logsAll,
  logDates,
  logCount,
  resetAll,
  importFromJson,
  insertMessage,
  messagesByDay,
  messagesAll,
  messageDates,
  sessionLoadAll,
  sessionSaveAll,
  pruneLogs,
  pruneMessages,
  checkpoint,
  close,
  dayOf,
  LEVEL_SETS,
};
