'use strict';
/**
 * VloS · 诗词库处理 / 导入 / 导出
 *
 * 用法（在插件目录下）：
 *   node tools/poems.js check
 *   node tools/poems.js import "C:\...\每日诗词.txt"
 *   node tools/poems.js import "C:\...\每日诗词.txt" --out-dir data
 *   node tools/poems.js export "D:\每日诗词导出.txt"
 *   node tools/poems.js export "D:\每日诗词导出.txt" --source data/每日诗词.txt
 *
 * 处理规则：
 *   - 自动识别 UTF-8（含 BOM）/ GBK(CP936)
 *   - 统一换行、去 BOM、去控制字符、trim、压缩连续空格
 *   - 去空行、去 # 注释行、去完全重复的行
 *   - 输出 UTF-8（无 BOM），一行一首
 *   - 默认同时写 data/每日诗词.txt（主文件）和 data/poems.txt（旧版兼容副本）
 */

const fs = require('node:fs');
const path = require('node:path');

const PLUGIN_ROOT = path.resolve(__dirname, '..');
const DEFAULT_OUT_DIR = path.join(PLUGIN_ROOT, 'data');

function decodePoemBuffer(buf) {
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf);
  if (b.length >= 3 && b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) {
    return { text: b.subarray(3).toString('utf8'), encoding: 'utf-8-bom' };
  }
  try {
    const text = new TextDecoder('utf-8', { fatal: true }).decode(b);
    return { text, encoding: 'utf-8' };
  } catch {
    try {
      return { text: new TextDecoder('gbk').decode(b), encoding: 'gbk' };
    } catch {
      return { text: b.toString('utf8'), encoding: 'utf-8-fallback' };
    }
  }
}

function normalizePoems(text) {
  const stats = {
    rawLines: 0,
    empty: 0,
    comments: 0,
    duplicates: 0,
    missingSeparator: 0,
    tooLong: 0,
  };
  const lines = [];
  const seen = new Set();
  const raw = String(text || '')
    .replace(/^\uFEFF/, '')
    .replace(/\r\n?/g, '\n')
    .split('\n');
  stats.rawLines = raw.length;
  for (let line of raw) {
    line = String(line)
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
      .replace(/\t/g, ' ')
      .replace(/[ \u3000]+/g, ' ')
      .trim();
    if (!line) {
      stats.empty++;
      continue;
    }
    if (line.startsWith('#')) {
      stats.comments++;
      continue;
    }
    if (seen.has(line)) {
      stats.duplicates++;
      continue;
    }
    seen.add(line);
    lines.push(line);
    if (!line.includes('——')) stats.missingSeparator++;
    if (line.length > 120) stats.tooLong++;
  }
  return { lines, stats };
}

function readPoemFile(file) {
  const buf = fs.readFileSync(file);
  const { text, encoding } = decodePoemBuffer(buf);
  const { lines, stats } = normalizePoems(text);
  return { file, encoding, lines, stats };
}

function writeText(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, file);
}

function importPoems({ source, outDir = DEFAULT_OUT_DIR, compat = true } = {}) {
  if (!source) throw new Error('缺少源文件');
  const r = readPoemFile(source);
  if (!r.lines.length) throw new Error(`源文件没有可用诗词：${source}`);
  const body = r.lines.join('\n') + '\n';
  const daily = path.join(outDir, '每日诗词.txt');
  writeText(daily, body);
  let compatFile = '';
  if (compat) {
    compatFile = path.join(outDir, 'poems.txt');
    writeText(compatFile, body);
  }
  return { ...r, daily, compat: compatFile, count: r.lines.length };
}

function exportPoems({ source, dest } = {}) {
  if (!dest) throw new Error('缺少导出目标文件');
  const r = readPoemFile(source);
  if (!r.lines.length) throw new Error(`源文件没有可用诗词：${source}`);
  writeText(dest, r.lines.join('\n') + '\n');
  return { ...r, dest, count: r.lines.length };
}

function checkPoems(file) {
  const r = readPoemFile(file);
  return { ...r, count: r.lines.length };
}

function defaultSource(root = PLUGIN_ROOT) {
  const candidates = [
    path.join(root, '每日诗词.txt'),
    path.join(root, 'data', '每日诗词.txt'),
    path.join(root, 'data', 'poems.txt'),
  ];
  return candidates.find((f) => fs.existsSync(f)) || candidates[0];
}

/* ---------------- CLI ---------------- */

function parseArgs(argv) {
  const flags = { outDir: '', source: '', compat: true, json: false };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--out-dir') flags.outDir = argv[++i] || '';
    else if (a.startsWith('--out-dir=')) flags.outDir = a.slice('--out-dir='.length);
    else if (a === '--source') flags.source = argv[++i] || '';
    else if (a.startsWith('--source=')) flags.source = a.slice('--source='.length);
    else if (a === '--no-compat') flags.compat = false;
    else if (a === '--json') flags.json = true;
    else rest.push(a);
  }
  return { flags, rest };
}

function printStats(r, count) {
  console.log(`  源文件    ${r.file}`);
  console.log(`  编码      ${r.encoding}`);
  console.log(`  原始行    ${r.stats.rawLines}`);
  console.log(`  保留      ${count}`);
  console.log(`  空行      ${r.stats.empty}`);
  console.log(`  注释行    ${r.stats.comments}`);
  console.log(`  重复      ${r.stats.duplicates}`);
  console.log(`  缺少出处  ${r.stats.missingSeparator}`);
  console.log(`  超长行    ${r.stats.tooLong}`);
}

function main() {
  const { flags, rest } = parseArgs(process.argv.slice(2));
  const cmd = rest[0] || 'check';
  try {
    if (cmd === 'import') {
      const source = rest[1] || flags.source || defaultSource();
      const outDir = flags.outDir ? path.resolve(flags.outDir) : DEFAULT_OUT_DIR;
      const r = importPoems({ source, outDir, compat: flags.compat });
      if (flags.json) {
        console.log(JSON.stringify({ ok: true, ...r, lines: undefined }, null, 2));
        return;
      }
      console.log('=== 诗词导入 ===');
      printStats(r, r.count);
      console.log(`  主文件    ${r.daily}`);
      console.log(`  兼容副本  ${r.compat || '（未生成）'}`);
      console.log(`\n完成：${r.count} 首，UTF-8（无 BOM）`);
      return;
    }
    if (cmd === 'export') {
      const dest = rest[1] || '';
      if (!dest) throw new Error('用法：node tools/poems.js export <目标文件> [--source <文件>]');
      const source = flags.source || defaultSource();
      const r = exportPoems({ source: path.resolve(source), dest: path.resolve(dest) });
      if (flags.json) {
        console.log(JSON.stringify({ ok: true, ...r, lines: undefined }, null, 2));
        return;
      }
      console.log('=== 诗词导出 ===');
      printStats(r, r.count);
      console.log(`  导出到    ${r.dest}`);
      console.log(`\n完成：${r.count} 首，UTF-8（无 BOM）`);
      return;
    }
    if (cmd === 'check') {
      const file = rest[1] || flags.source || defaultSource();
      const r = checkPoems(path.resolve(file));
      if (flags.json) {
        console.log(JSON.stringify({ ok: r.count > 0, ...r, lines: undefined }, null, 2));
        return;
      }
      console.log('=== 诗词检查 ===');
      printStats(r, r.count);
      console.log(`  第一首    ${r.lines[0] || '（空）'}`);
      console.log(`  最后一首  ${r.lines[r.lines.length - 1] || '（空）'}`);
      if (!r.count) process.exitCode = 1;
      return;
    }
    throw new Error(`未知子命令：${cmd}\n可用：import / export / check`);
  } catch (e) {
    console.error(`\n失败：${e.message}`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();

module.exports = {
  PLUGIN_ROOT,
  DEFAULT_OUT_DIR,
  decodePoemBuffer,
  normalizePoems,
  readPoemFile,
  importPoems,
  exportPoems,
  checkPoems,
  defaultSource,
};
