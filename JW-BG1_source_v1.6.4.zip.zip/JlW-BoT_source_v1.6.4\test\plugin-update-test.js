'use strict';
/** 插件在线更新：同 ID zip 覆盖、保留 config/enabled/data、失败回滚 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* 最小 store ZIP 写入 */
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let j = 0; j < 8; j++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  return (c ^ 0xffffffff) >>> 0;
}
function makeZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const { name, data } of entries) {
    const n = Buffer.from(name, 'utf8');
    const b = Buffer.from(data);
    const crc = crc32(b);
    const l = Buffer.alloc(30);
    l.writeUInt32LE(0x04034b50, 0); l.writeUInt16LE(20, 4); l.writeUInt16LE(0x800, 6);
    l.writeUInt16LE(0, 8); l.writeUInt16LE(0, 10); l.writeUInt16LE(0, 12);
    l.writeUInt32LE(crc, 14); l.writeUInt32LE(b.length, 18); l.writeUInt32LE(b.length, 22);
    l.writeUInt16LE(n.length, 26); l.writeUInt16LE(0, 28);
    locals.push(l, n, b);
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6);
    c.writeUInt16LE(0x800, 8); c.writeUInt16LE(0, 10); c.writeUInt16LE(0, 12);
    c.writeUInt16LE(0, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(b.length, 20);
    c.writeUInt32LE(b.length, 24); c.writeUInt16LE(n.length, 28); c.writeUInt16LE(0, 30);
    c.writeUInt16LE(0, 32); c.writeUInt16LE(0, 34); c.writeUInt16LE(0, 36);
    c.writeUInt32LE(0, 38); c.writeUInt32LE(offset, 42);
    centrals.push(c, n);
    offset += 30 + n.length + b.length;
  }
  const cd = Buffer.concat(centrals);
  const e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(entries.length, 8); e.writeUInt16LE(entries.length, 10);
  e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, e]);
}

function packageZip(version, index, extra = {}) {
  const files = {
    'plugin.json': JSON.stringify(
      {
        id: 'up-test',
        name: '更新测试',
        version,
        type: 'js',
        enabled: true,
        events: ['GROUP_AT_MESSAGE_CREATE'],
        config: { newKey: 'default', keep: 'overwritten' },
      },
      null,
      2,
    ),
    'index.js': index,
    ...extra,
  };
  return makeZip(Object.entries(files).map(([name, data]) => ({ name: 'up-test/' + name, data })));
}

(async () => {
  const jlw = await new MockJlw({ port: 0 }).start();
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-plugin-update-'));
  const pluginDir = path.join(dataDir, 'plugins', 'up-test');
  fs.mkdirSync(path.join(pluginDir, 'data'), { recursive: true });
  fs.writeFileSync(
    path.join(pluginDir, 'plugin.json'),
    JSON.stringify(
      {
        id: 'up-test',
        name: '更新测试',
        version: '1.0.0',
        type: 'js',
        enabled: true,
        events: ['GROUP_AT_MESSAGE_CREATE'],
        config: { keep: 'yes', nested: { x: 1 } },
      },
      null,
      2,
    ),
  );
  fs.writeFileSync(path.join(pluginDir, 'index.js'), "module.exports = { async onEvent() { return null; } };\n");
  fs.writeFileSync(path.join(pluginDir, 'data', 'user.txt'), 'keep-data');

  const port = 18981 + Math.floor(Math.random() * 30);
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        log: { level: 'warn', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: {
      ...process.env,
      JLW_DATA_DIR: dataDir,
      JLW_ALLOW_LOCAL_SITE: '1',
      JLW_ALLOW_ALL_LOGIN: '1',
    },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };
  try {
    const deadline = Date.now() + 20000;
    let cookie = '';
    while (Date.now() < deadline) {
      try {
        if ((await fetch(base + '/health')).ok) break;
      } catch {
        await sleep(200);
        continue;
      }
      await sleep(200);
    }
    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];
    const headers = { 'Content-Type': 'application/json', Cookie: cookie };
    const update = async (version, index, extra) => {
      const zip = packageZip(version, index, extra);
      return fetch(base + '/api/plugins/up-test/update', {
        method: 'POST',
        headers,
        body: JSON.stringify({ files: [{ name: 'up-test.zip', data: zip.toString('base64') }] }),
      });
    };

    const res = await update(
      '1.1.0',
      "module.exports = { async onEvent() { return { reply: 'new' }; } };\n",
      { 'data/new-default.txt': 'new-default', 'new-file.txt': 'new-file' },
    );
    const body = await res.json();
    check(res.status === 200 && body.ok === true, '更新接口成功');
    check(body.version === '1.1.0' && body.previousVersion === '1.0.0', '版本从 1.0.0 升到 1.1.0');
    const manifest = JSON.parse(fs.readFileSync(path.join(pluginDir, 'plugin.json'), 'utf8'));
    check(manifest.config.keep === 'yes' && manifest.config.newKey === 'default', '保留旧 config 并合并新默认值');
    check(manifest.config.nested.x === 1, '保留嵌套 config');
    check(fs.readFileSync(path.join(pluginDir, 'index.js'), 'utf8').includes("'new'"), '代码已替换');
    check(fs.readFileSync(path.join(pluginDir, 'data', 'user.txt'), 'utf8') === 'keep-data', 'data 用户文件保留');
    check(fs.existsSync(path.join(pluginDir, 'data', 'new-default.txt')), '新包 data 文件已加入');
    check(fs.readFileSync(path.join(pluginDir, 'new-file.txt'), 'utf8') === 'new-file', '新包普通文件已加入');
    const list = await fetch(base + '/api/plugins', { headers }).then((r) => r.json());
    check(list.plugins.find((p) => p.id === 'up-test')?.status === 'running', '更新后插件运行中');

    // 坏包：加载失败必须回滚到 1.1.0
    const bad = await update('2.0.0', 'module.exports = {');
    const badBody = await bad.json();
    check(bad.status === 400 && /回滚/.test(badBody.error || ''), '坏包更新失败并提示回滚');
    const after = JSON.parse(fs.readFileSync(path.join(pluginDir, 'plugin.json'), 'utf8'));
    check(after.version === '1.1.0', '回滚后仍是 1.1.0');
    check(fs.readFileSync(path.join(pluginDir, 'data', 'user.txt'), 'utf8') === 'keep-data', '回滚后 data 未丢');
  } finally {
    child.kill();
    await sleep(200);
    await jlw.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
