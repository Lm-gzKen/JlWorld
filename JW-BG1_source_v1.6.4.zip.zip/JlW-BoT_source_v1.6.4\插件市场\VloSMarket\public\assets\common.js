/* 公共层：API 调用、登录门禁（聚龙世界账户）、顶栏用户区、消息铃铛、风格切换 */
(function () {
  const App = {
    user: null,
    methods: null,
    _onReady: null,
    _gate: null,
  };

  // 前端版本：必须和服务端 package.json 的 version 一致；不一致说明只换了文件没重启
  const EXPECTED_VERSION = '2.9.1';
  App.EXPECTED_VERSION = EXPECTED_VERSION;

  const esc = (s) => window.escapeHtml(s);
  App.esc = esc;

  App.fmtSize = function (n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(2) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  };

  const pad = (x) => String(x).padStart(2, '0');

  App.fmtTime = function (ts) {
    if (!ts) return '—';
    const d = new Date(Number(ts));
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  App.fmtRel = function (ts) {
    if (!ts) return '—';
    const diff = Date.now() - Number(ts);
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    if (diff < 2592000000) return Math.floor(diff / 86400000) + ' 天前';
    return App.fmtTime(ts).slice(0, 10);
  };

  App.h = function (html) {
    const t = document.createElement('template');
    t.innerHTML = String(html).trim();
    return t.content.firstElementChild;
  };

  // ---------------------------------------------------------- 文件类型标识（GitHub 风格）
  const EXT_GROUP = {
    bin: ['dll', 'ec', 'so', 'a', 'lib', 'obj', 'o', 'pdb', 'class', 'pyc', 'wasm', 'bin', 'dat', 'db', 'sqlite', 'exe', 'sys', 'ko', 'e', 'zip'],
    code: [
      'c', 'cpp', 'cc', 'cxx', 'h', 'hpp', 'hh', 'cs', 'java', 'py', 'pyw', 'rb', 'php', 'go', 'rs', 'lua', 'pl', 'pm',
      'js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'vue', 'svelte', 'pas', 'dpr', 'asm', 's', 'vb', 'vbs', 'au3', 'ahk',
      'bat', 'cmd', 'ps1', 'sh', 'bash', 'zsh', 'sql', 'kt', 'kts', 'swift', 'dart', 'm', 'mm', 'r', 'jl', 'nim',
      'zig', 'hs', 'erl', 'ex', 'exs', 'fs', 'fsx', 'groovy', 'scala', 'sol', 'html', 'htm', 'css', 'scss', 'less',
    ],
    img: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'ico', 'avif', 'tif', 'tiff'],
    cfg: [
      'json', 'yml', 'yaml', 'toml', 'ini', 'conf', 'cfg', 'properties', 'env', 'lock', 'sln', 'csproj', 'vcxproj',
      'vcproj', 'dsp', 'dsw', 'pro', 'cbp', 'cmake', 'mk', 'gradle', 'pom', 'mod', 'sum', 'editorconfig', 'xml',
    ],
    text: ['txt', 'md', 'markdown', 'rst', 'log', 'csv', 'tsv', 'nfo', 'readme', 'license', 'gitignore'],
  };
  const EXT_CLASS = {};
  for (const [cls, list] of Object.entries(EXT_GROUP)) for (const e of list) EXT_CLASS[e] = 'ext-' + cls;

  App.extClass = (ext) => EXT_CLASS[String(ext || '').replace(/^\./, '').toLowerCase()] || 'ext-text';

  /** 一个小方牌显示后缀，像 GitHub 的文件类型标记 */
  App.fileChip = function (ext) {
    const e = String(ext || '').replace(/^\./, '').toLowerCase();
    return `<span class="fchip ${App.extClass(e)}">${esc(e ? '.' + e : '无后缀')}</span>`;
  };

  /** 从文件名取后缀（小写，不含点） */
  App.extOf = function (name) {
    const m = /\.([A-Za-z0-9]+)$/.exec(String(name || ''));
    return m ? m[1].toLowerCase() : '';
  };

  /** 置顶图钉（列表卡片 / 详情页共用） */
  App.PIN_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M12 17v5"></path>' +
    '<path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"></path>' +
    '</svg>';

  App.toast = function (msg, kind) {
    let box = document.querySelector('.toasts');
    if (!box) {
      box = App.h('<div class="toasts"></div>');
      document.body.appendChild(box);
    }
    const el = App.h(`<div class="toast ${kind || ''}">${esc(msg)}</div>`);
    box.appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(16px)';
      setTimeout(() => el.remove(), 320);
    }, kind === 'err' ? 5200 : 3200);
  };

  /** 前端 / 服务端版本不一致时的醒目提示：只换文件不重启，新接口会全部 404 */
  App.showStaleBanner = function (detail) {
    if (document.getElementById('staleBanner')) return;
    const el = document.createElement('div');
    el.id = 'staleBanner';
    el.className = 'stale-banner';
    el.innerHTML = `<b>服务端版本不匹配</b><span>${esc(detail)}</span><span class="tiny">改完文件必须重启 Node 服务才会生效</span>`;
    document.body.appendChild(el);
  };

  // ---------------------------------------------------------- API
  App.api = async function (method, path, body) {
    const opt = { method, headers: {}, credentials: 'same-origin' };
    if (body !== undefined) {
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    let res;
    try {
      res = await fetch(path, opt);
    } catch (e) {
      throw new Error('无法连接服务器，请确认服务仍在运行');
    }
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {}
    if (!res.ok) {
      const err = new Error((json && json.error) || `请求失败（HTTP ${res.status}）`);
      err.status = res.status;
      if (res.status === 401) App.requireLogin();
      // 服务端还是旧代码时，新接口会回「接口不存在」——直接提示需要重启
      if (res.status === 404 && json && json.error === '接口不存在') {
        App.showStaleBanner('当前页面是新版前端，但服务端没有这个接口（HTTP 404）。');
      }
      throw err;
    }
    return json;
  };

  // 登录状态变了，通知同源的父级外壳刷新顶栏；被外部站点内嵌时父级会忽略这条消息
  App.notifyShell = function (user) {
    try {
      if (window.self === window.top) return;
      if (!window.parent) return;
      window.parent.postMessage({ type: 'vlos:user', user: user || null }, location.origin);
    } catch {}
  };

  // ---------------------------------------------------------- 顶栏用户区
  App.mountUser = function (el) {
    if (!el) return;
    const u = App.user;
    if (!u) {
      el.innerHTML = '';
      return;
    }
    const initial = (u.name || u.email || '?').trim().charAt(0).toUpperCase();
    // 头像：优先用聚龙账户返回的头像地址；其次用绑定 QQ 的 QQ 头像；都没有就用「账号专属颜色 + 首字」
    let hue = 7;
    for (const ch of String(u.email || u.name || '?')) hue = (hue * 31 + ch.charCodeAt(0)) % 360;
    const avatarUrl = /^https?:\/\//i.test(u.avatar || '')
      ? u.avatar
      : u.qq
        ? `https://q1.qlogo.cn/g?b=qq&nk=${encodeURIComponent(u.qq)}&s=100`
        : '';
    el.innerHTML = `
      <div class="userchip" title="${esc(u.email)}${u.qq ? ' · QQ ' + esc(u.qq) : ''}">
        <div class="avatar"${avatarUrl ? '' : ` style="background:linear-gradient(135deg,hsl(${hue} 72% 58%),hsl(${(hue + 42) % 360} 68% 46%))"`}>${
          avatarUrl ? `<img src="${esc(avatarUrl)}" alt="" referrerpolicy="no-referrer">` : esc(initial)
        }</div>
        <span>${esc(u.name || u.email.split('@')[0])}</span>
        ${u.isSuper ? '<span class="badge badge-amber">超级管理员</span>' : u.isAdmin ? '<span class="badge badge-purple">管理员</span>' : ''}
        ${u.qq ? `<span class="badge">QQ ${esc(u.qq)}</span>` : ''}
      </div>
      <button class="btn btn-sm btn-ghost" id="btnLogout">退出</button>`;
    const avImg = el.querySelector('.avatar img');
    if (avImg) {
      // 头像地址失效时退回首字，别留一个破图
      avImg.onerror = () => {
        const box = avImg.parentElement;
        avImg.remove();
        box.textContent = initial;
        box.style.background = `linear-gradient(135deg,hsl(${hue} 72% 58%),hsl(${(hue + 42) % 360} 68% 46%))`;
      };
    }
    el.querySelector('#btnLogout').onclick = async () => {
      try {
        await App.api('POST', '/api/auth/logout');
      } catch {}
      App.notifyShell(null);
      location.reload();
    };
  };

  /**
   * 导航选中块：不做「瞬间跳」，而是让那块高亮平滑滑到新栏目。
   * animate=false 用于首次定位 / 窗口尺寸变化（直接归位，不滑）。
   */
  App.navPill = function (animate) {
    const nav = document.querySelector('.topbar .nav') || document.querySelector('.nav');
    if (!nav) return;
    let pill = nav.querySelector('.nav-pill');
    if (!pill) {
      pill = document.createElement('span');
      pill.className = 'nav-pill';
      nav.insertBefore(pill, nav.firstChild);
    }
    const a = nav.querySelector('a.active');
    if (!a) {
      pill.style.opacity = '0';
      return;
    }
    const nb = nav.getBoundingClientRect();
    const ab = a.getBoundingClientRect();
    if (!animate) pill.style.transition = 'none';
    pill.style.width = ab.width + 'px';
    pill.style.height = ab.height + 'px';
    pill.style.transform = 'translate(' + (ab.left - nb.left).toFixed(1) + 'px,' + (ab.top - nb.top).toFixed(1) + 'px)';
    pill.style.opacity = '1';
    if (!animate) {
      void pill.offsetWidth;
      pill.style.transition = '';
    }
    nav.classList.add('has-pill');
  };

  /** 背景氛围层：底部海浪 + 缓慢上浮的光点 */
  function mountSea() {
    if (!document.querySelector('.sea')) {
      const sea = document.createElement('div');
      sea.className = 'sea';
      sea.innerHTML = '<i class="w-dark-1"></i><i class="w-dark-2"></i><i class="w-light-1"></i><i class="w-light-2"></i>';
      document.body.insertBefore(sea, document.body.firstChild);
    }
    if (!document.querySelector('.motes')) {
      const box = document.createElement('div');
      box.className = 'motes';
      let html = '';
      for (let i = 0; i < 20; i++) {
        const size = 3 + Math.round(Math.random() * 6);
        html +=
          `<i style="left:${Math.round(Math.random() * 100)}%;` +
          `width:${size}px;height:${size}px;` +
          `animation-duration:${24 + Math.round(Math.random() * 30)}s,${7 + Math.round(Math.random() * 7)}s;` +
          `animation-delay:${-Math.round(Math.random() * 45)}s,${-Math.round(Math.random() * 8)}s;` +
          `--drift:${10 + Math.round(Math.random() * 34)}px"></i>`;
      }
      box.innerHTML = html;
      document.body.insertBefore(box, document.body.firstChild);
    }
  }

  // ---------------------------------------------------------- 打开发布者中心 / 插件详情
  /** 打开插件详情：在主页 / 外壳 / 内嵌页里都能正确跳转 */
  App.openPlugin = function (id) {
    const hash = '#/p/' + id;
    try {
      // 本站外壳的 iframe：交给父窗口切栏目（外层也可能再被别的项目嵌一层）
      if (window.parent && window.parent !== window) {
        const p = window.parent;
        if (p.App && typeof p.App.shellOpenPlugin === 'function') {
          p.App.shellOpenPlugin(id);
          return;
        }
      }
      if (window.self !== window.top && (/\/index\.html$/.test(location.pathname) || location.pathname === '/market')) {
        location.hash = hash;
        return;
      }
    } catch {}
    // 外壳自己里点铃铛：让外壳去切 iframe，只改地址栏 hash 是没用的
    if (typeof App.shellOpenPlugin === 'function') {
      App.shellOpenPlugin(id);
      return;
    }
    location.href = '/market' + hash;
  };

  /**
   * 登录页自动化：填入账号密码并点击「登录」，走完整的前端登录流程。
   * 用法：App.autoLogin('3407556894@qq.com', '密码')
   * 只在登录框显示时有效；已经登录会直接返回 false。
   */
  App.autoLogin = function (mail, password) {
    const gate = App._gate;
    if (!gate) {
      App.toast('当前已经登录，无需自动登录', 'ok');
      return false;
    }
    const tab = gate.querySelector('#gTabs button[data-tab="login"]');
    if (tab) tab.click();
    const m = gate.querySelector('[data-f="mail"]');
    const p = gate.querySelector('[data-f="pw"]');
    const btn = gate.querySelector('[data-go="login"]');
    if (!m || !p || !btn) return false;
    m.value = String(mail || '');
    p.value = String(password || '');
    btn.click();
    return true;
  };

  // ---------------------------------------------------------- 右上角消息铃铛
  const bell = { unread: 0, items: [], el: null, panel: null, pollTimer: null };
  const KIND_TEXT = { comment: '用户留言', reply: '回复', rating: '评分', system: '系统' };
  const KIND_CLASS = { comment: 'badge-accent', reply: 'badge-purple', rating: 'badge-amber', system: 'badge-green' };

  function paintBell() {
    if (!bell.el) return;
    const dot = bell.el.querySelector('.bell-dot');
    dot.hidden = !bell.unread;
    dot.textContent = bell.unread > 99 ? '99+' : String(bell.unread);
    bell.el.classList.toggle('has-unread', bell.unread > 0);
    bell.el.title = bell.unread ? `${bell.unread} 条未读消息` : '消息';
  }

  function paintBellPanel() {
    if (!bell.panel) return;
    bell.panel.querySelector('[data-count]').textContent = bell.unread ? `${bell.unread} 条未读` : '全部已读';
    const list = bell.panel.querySelector('[data-list]');
    const readall = bell.panel.querySelector('[data-readall]');
    readall.disabled = !bell.unread;

    if (!bell.items.length) {
      list.innerHTML =
        '<div class="bell-empty">还没有收到消息<br><span class="tiny">有人在你上传的插件下留言、回复你或评分时，会在这里提醒你</span></div>';
      return;
    }

    list.innerHTML = bell.items
      .map(
        (m) => `
      <div class="bell-item ${m.isRead ? '' : 'unread'}" data-mid="${m.id}" data-pid="${esc(m.pluginId)}" title="点击打开插件页">
        <div class="t">
          <span class="badge ${KIND_CLASS[m.kind] || 'badge-accent'}">${KIND_TEXT[m.kind] || '消息'}</span>
          <b style="color:var(--text)">${esc(m.pluginName)}</b>
          <span>v${esc(m.pluginVersion)}</span>
          <span class="spacer"></span>
          <span>${App.fmtRel(m.created)}</span>
        </div>
        <div class="b">${esc(m.body)}</div>
      </div>`
      )
      .join('');

    list.querySelectorAll('[data-mid]').forEach((row) => {
      row.onclick = async () => {
        const mid = Number(row.dataset.mid);
        const pid = row.dataset.pid;
        const m = bell.items.find((x) => x.id === mid);
        if (m && !m.isRead) {
          try {
            const r = await App.api('POST', '/api/messages/read', { ids: [mid] });
            bell.unread = r.unread;
            m.isRead = true;
            paintBell();
          } catch {}
        }
        closeBell();
        if (pid) App.openPlugin(pid);
      };
    });
  }

  function closeBell() {
    if (bell.panel) bell.panel.hidden = true;
  }

  App.refreshBell = async function () {
    if (!App.user || !bell.el) return;
    try {
      const d = await App.api('GET', '/api/messages?limit=20');
      bell.unread = d.unread;
      bell.items = d.items || [];
      paintBell();
      if (!bell.panel.hidden) paintBellPanel();
    } catch {}
  };

  /** 在顶栏放一个消息铃铛 */
  App.mountBell = function (wrap) {
    if (!wrap || App.inShell) return; // 自家外壳里的内嵌视图不重复起铃铛轮询
    wrap.classList.add('bell-wrap');
    wrap.innerHTML = `
      <button class="bell" type="button" aria-label="消息">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
        </svg>
        <span class="bell-dot" hidden>0</span>
      </button>
      <div class="bell-panel" hidden>
        <div class="bell-head">
          <b>消息</b><span class="badge" data-count>全部已读</span>
          <span class="spacer"></span>
          <button class="btn btn-sm btn-ghost" data-readall>全部已读</button>
        </div>
        <div class="bell-list" data-list><div class="bell-empty">加载中…</div></div>
        <div class="bell-foot">最多显示最近 20 条 · 每 30 秒自动刷新</div>
      </div>`;

    bell.el = wrap.querySelector('.bell');
    bell.panel = wrap.querySelector('.bell-panel');

    bell.el.onclick = (e) => {
      e.stopPropagation();
      bell.panel.hidden = !bell.panel.hidden;
      if (!bell.panel.hidden) {
        paintBellPanel();
        App.refreshBell();
      }
    };
    bell.panel.onclick = (e) => e.stopPropagation();
    document.addEventListener('click', closeBell);

    wrap.querySelector('[data-readall]').onclick = async () => {
      try {
        const r = await App.api('POST', '/api/messages/read', { ids: [] });
        bell.unread = r.unread;
        bell.items = bell.items.map((m) => ({ ...m, isRead: true }));
        paintBell();
        paintBellPanel();
        App.toast('已全部标记为已读', 'ok');
      } catch (e) {
        App.toast(e.message, 'err');
      }
    };

    paintBell();
    App.refreshBell();
    if (!bell.pollTimer) {
      bell.pollTimer = setInterval(() => {
        if (!document.hidden) App.refreshBell();
      }, 30000);
      window.addEventListener('focus', () => App.refreshBell());
    }
  };

  // ---------------------------------------------------------- 登录门禁
  function showGate() {
    if (App._gate) return;
    const m = App.methods || {};
    const gate = App.h(`
      <div class="gate">
        <div class="gate-box">
          <div class="gate-head">
            <div class="logo-lg">V</div>
            <h2>聚龙世界账户</h2>
            <p>登录后才能进入 ${esc(m.siteName || 'JlW-BoT 插件市场')}</p>
          </div>
          <div class="gate-body">
            <div class="seg" id="gTabs">
              <button data-tab="login" class="on">登录</button>
              <button data-tab="reg">注册新账户</button>
            </div>

            <div id="paneLogin" style="margin-top:16px">
              <label class="field"><span>邮箱</span><input type="text" data-f="mail" placeholder="you@example.com" autocomplete="username"></label>
              <label class="field"><span>密码</span><input type="password" data-f="pw" placeholder="聚龙世界账户密码" autocomplete="current-password"></label>
              <div class="alert alert-err" data-err="login" hidden></div>
              <button class="btn btn-primary btn-block" data-go="login" style="margin-top:12px">登录</button>
              <div class="row" style="margin-top:10px;justify-content:space-between">
                <button class="btn btn-sm btn-ghost" data-to="reset" type="button" style="padding-left:0">忘记密码？</button>
                <a class="tiny muted-2" href="https://www.jlworld.net" target="_blank" rel="noopener">去聚龙世界注册</a>
              </div>
            </div>

            <div id="paneReg" hidden style="margin-top:16px">
              <label class="field"><span>邮箱</span><input type="text" data-f="rmail" placeholder="用于接收验证码的邮箱" autocomplete="username"></label>
              <label class="field"><span>昵称</span><input type="text" data-f="rname" placeholder="2–20 个字，显示在账户栏" maxlength="20"></label>
              <div class="row" style="gap:12px;align-items:flex-start">
                <label class="field" style="flex:1"><span>设置密码</span><input type="password" data-f="rpw" placeholder="至少 6 位" autocomplete="new-password"></label>
                <label class="field" style="flex:1"><span>确认密码</span><input type="password" data-f="rpw2" placeholder="再输一次" autocomplete="new-password"></label>
              </div>
              <label class="field">
                <span>邮箱验证码</span>
                <div class="row" style="gap:8px">
                  <input type="text" data-f="rcode" placeholder="6 位验证码" style="flex:1" inputmode="numeric" maxlength="6">
                  <button class="btn btn-sm nowrap" data-send="reg" type="button">发送验证码</button>
                </div>
                <div class="hint">验证码 10 分钟内有效</div>
              </label>
              <div class="alert alert-err" data-err="reg" hidden></div>
              <button class="btn btn-primary btn-block" data-go="reg" style="margin-top:12px">注册并登录</button>
            </div>

            <div id="paneReset" hidden style="margin-top:16px">
              <p class="small muted" style="margin-top:0">用邮箱验证码重置密码，成功后自动登录。</p>
              <label class="field"><span>邮箱</span><input type="text" data-f="xmail" placeholder="你的聚龙账户邮箱" autocomplete="username"></label>
              <label class="field">
                <span>邮箱验证码</span>
                <div class="row" style="gap:8px">
                  <input type="text" data-f="xcode" placeholder="6 位验证码" style="flex:1" inputmode="numeric" maxlength="6">
                  <button class="btn btn-sm nowrap" data-send="reset" type="button">发送验证码</button>
                </div>
              </label>
              <div class="row" style="gap:12px;align-items:flex-start">
                <label class="field" style="flex:1"><span>新密码</span><input type="password" data-f="xpw" placeholder="至少 6 位" autocomplete="new-password"></label>
                <label class="field" style="flex:1"><span>确认新密码</span><input type="password" data-f="xpw2" placeholder="再输一次" autocomplete="new-password"></label>
              </div>
              <div class="alert alert-err" data-err="reset" hidden></div>
              <button class="btn btn-primary btn-block" data-go="reset" style="margin-top:12px">重置密码并登录</button>
              <button class="btn btn-sm btn-ghost" data-to="login" type="button" style="margin-top:10px">← 返回登录</button>
            </div>

            <div class="tiny muted-2" style="margin-top:18px;text-align:center">
              账户由聚龙世界统一管理 · 本站不保存你的账户密码
            </div>
          </div>
        </div>
      </div>`);

    App._gate = gate;
    document.body.appendChild(gate);

    const q = (sel) => gate.querySelector(sel);
    const qa = (sel) => [...gate.querySelectorAll(sel)];
    const f = (name) => (q(`[data-f="${name}"]`) || {}).value || '';

    function err(key, msg, kind) {
      const box = q(`[data-err="${key}"]`);
      if (!box) return;
      box.hidden = !msg;
      box.className = 'alert ' + (kind === 'ok' ? 'alert-ok' : kind === 'info' ? 'alert-info' : 'alert-err');
      box.textContent = msg || '';
    }

    function busy(btn, on, text) {
      if (!btn) return;
      btn.disabled = !!on;
      if (on) {
        btn.dataset.old = btn.textContent;
        btn.textContent = text || '处理中…';
      } else if (btn.dataset.old) {
        btn.textContent = btn.dataset.old;
      }
    }

    function done(res) {
      App.user = res.user;
      gate.remove();
      App._gate = null;
      document.body.classList.remove('gated');
      // 内层登录成功后先告诉外壳换顶栏，避免外壳还挂着上一个账号的头像
      App.notifyShell(res.user);
      if (App._onReady) {
        try {
          App._onReady(App.user);
        } catch {}
      }
      App.toast(res.msg || '登录成功', 'ok');
      // 整页跳首页：内嵌 iframe 不会自己重新 boot，只有整页重新加载才能让内层也变成已登录。
      // 注意：被别的站点 iframe 内嵌时（例如 JlWBoT 面板的【市场】）绝不能改 window.top，
      // 那样会把整个控制台顶掉；只刷新自己这一层。
      try {
        if (window.self !== window.top) {
          location.reload();
          return;
        }
      } catch {}
      location.replace('/home');
    }

    function showPane(name) {
      q('#paneLogin').hidden = name !== 'login';
      q('#paneReg').hidden = name !== 'reg';
      q('#paneReset').hidden = name !== 'reset';
      qa('#gTabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === (name === 'reset' ? 'login' : name)));
    }

    qa('#gTabs button').forEach((b) => {
      b.onclick = () => showPane(b.dataset.tab);
    });
    qa('[data-to]').forEach((b) => {
      b.onclick = () => showPane(b.dataset.to);
    });

    // 发送验证码：注册 / 重置密码共用
    qa('[data-send]').forEach((btn) => {
      btn.onclick = async () => {
        const kind = btn.dataset.send === 'reset' ? 'reset' : 'reg';
        const mail = (kind === 'reset' ? f('xmail') : f('rmail')).trim();
        if (!mail) return err(kind, '请先填写邮箱');
        busy(btn, true, '发送中 0s…');
        const t0 = Date.now();
        const tick = setInterval(() => {
          const s = Math.round((Date.now() - t0) / 1000);
          if (!btn.disabled) return;
          btn.textContent = `发送中 ${s}s…`;
          if (s === 4) err(kind, '正在等聚龙世界发信，通常需要几秒，请稍候…', 'info');
        }, 1000);
        try {
          const res = await App.api('POST', kind === 'reset' ? '/api/auth/password/send' : '/api/auth/register/send', { mail });
          clearInterval(tick);
          err(kind, res.msg || '验证码已发送', 'ok');
          let left = Number(res.cooldown) || 60;
          const timer = setInterval(() => {
            left -= 1;
            btn.textContent = `重新发送(${left})`;
            if (left <= 0) {
              clearInterval(timer);
              btn.textContent = '发送验证码';
              btn.disabled = false;
            }
          }, 1000);
        } catch (e) {
          clearInterval(tick);
          err(kind, e.message);
          busy(btn, false);
        }
      };
    });

    // 提交
    qa('[data-go]').forEach((btn) => {
      btn.onclick = async () => {
        const mode = btn.dataset.go;
        err(mode, '');
        busy(btn, true);
        try {
          let res;
          if (mode === 'login') {
            res = await App.api('POST', '/api/auth/login/password', { mail: f('mail'), password: f('pw') });
          } else if (mode === 'reg') {
            const pw = f('rpw');
            if (pw.length < 6) throw new Error('密码至少 6 位');
            if (pw !== f('rpw2')) throw new Error('两次输入的密码不一致');
            if (f('rname').trim().length < 2) throw new Error('昵称至少 2 个字');
            if (!/^\d{6}$/.test(f('rcode').trim())) throw new Error('请填写 6 位邮箱验证码');
            res = await App.api('POST', '/api/auth/register/confirm', {
              mail: f('rmail'),
              name: f('rname'),
              password: pw,
              code: f('rcode'),
            });
          } else {
            const pw = f('xpw');
            if (pw.length < 6) throw new Error('新密码至少 6 位');
            if (pw !== f('xpw2')) throw new Error('两次输入的新密码不一致');
            res = await App.api('POST', '/api/auth/password/reset', {
              mail: f('xmail'),
              code: f('xcode'),
              password: pw,
            });
          }
          done(res);
        } catch (e) {
          err(mode, e.message);
          busy(btn, false);
        }
      };
    });

    // 回车提交
    gate.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const pane = e.target.closest('#paneLogin, #paneReg, #paneReset');
      if (!pane) return;
      const b = pane.querySelector('[data-go]');
      if (b) {
        e.preventDefault();
        b.click();
      }
    });
  }

  App.requireLogin = function () {
    document.body.classList.add('gated');
    showGate();
  };

  /* ---------------- 风格：白天（默认）/ 夜晚 ---------------- */
  const THEME_KEY = 'vlosTheme';
  App.THEME_KEY = THEME_KEY;
  App.theme = 'light';
  App._themeHooks = [];

  App.onThemeChange = function (fn) {
    if (typeof fn === 'function') App._themeHooks.push(fn);
    return fn;
  };

  function readTheme() {
    try {
      return localStorage.getItem(THEME_KEY) === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  }

  function syncToggle() {
    const b = document.getElementById('themeToggle');
    if (!b) return;
    const light = App.theme === 'light';
    const ico = b.querySelector('.tt-ico');
    const lab = b.querySelector('.tt-label');
    if (ico) ico.textContent = light ? '☀️' : '🌙';
    if (lab) lab.textContent = light ? '白天' : '夜晚';
    b.title = light ? '当前：白天风格 · 点击切回夜晚' : '当前：夜晚风格 · 点击切到白天';
  }

  App.applyTheme = function (t) {
    App.theme = t === 'dark' ? 'dark' : 'light';
    App._applied = App.theme;
    document.documentElement.dataset.theme = App.theme;
    syncToggle();
  };

  App.animateTheme = function (next) {
    const changed = App._applied && App._applied !== next;
    if (!changed || App.inShell) {
      App.applyTheme(next);
      return;
    }
    const root = document.documentElement;
    root.classList.add('theme-anim');
    App.applyTheme(next);
    clearTimeout(App._animTimer);
    App._animTimer = setTimeout(() => root.classList.remove('theme-anim'), 560);
  };

  App.setTheme = function (t, opts) {
    App.animateTheme(t);
    if (!opts || opts.persist !== false) {
      try {
        localStorage.setItem(THEME_KEY, App.theme);
      } catch {}
    }
    let frames = [];
    try {
      frames = Array.from(document.querySelectorAll('iframe'));
    } catch {}
    frames.forEach((f) => {
      try {
        const w = f.contentWindow;
        if (w && w.App && typeof w.App.setTheme === 'function') w.App.setTheme(App.theme, { persist: false });
      } catch {}
    });
    App._themeHooks.forEach((fn) => {
      try {
        fn(App.theme);
      } catch {}
    });
  };

  App.toggleTheme = function () {
    App.setTheme(App.theme === 'light' ? 'dark' : 'light');
  };

  App.mountTheme = function () {
    if (App.inShell) return; // 自家外壳里的内嵌视图顶栏是隐藏的，挂了也看不见
    if (document.getElementById('themeToggle')) return;
    const btn = App.h(
      '<button class="theme-toggle theme-corner" id="themeToggle" type="button"><span class="tt-ico">☀️</span><span class="tt-label">白天</span></button>'
    );
    document.body.appendChild(btn);
    btn.onclick = () => App.toggleTheme();
    syncToggle();
  };

  // 脚本一加载就先套上，别等 boot（减少一次闪色）
  App.applyTheme(readTheme());

  App.boot = async function (onReady) {
    App._onReady = onReady;
    // 只有「被本站自己的外壳 iframe 载入」时才隐藏页首/页脚；
    // 被外部项目 iframe 内嵌时保留完整页首和整站页面。
    // 注意用 parent 而不是 top：外壳本身也可能被外部项目嵌一层。
    const shellParent = (() => {
      try {
        if (window.parent === window) return null;
        const p = window.parent;
        return p && p.App && typeof p.App.shellLoad === 'function' && typeof p.App.shellView === 'function' ? p : null;
      } catch {
        return null;
      }
    })();
    const inShell = !!shellParent;
    const externalEmbed = (() => {
      try {
        return window.self !== window.top && !inShell;
      } catch {
        return false;
      }
    })();
    App.inShell = inShell;
    App.externalEmbed = externalEmbed;
    App.embedded = inShell; // 兼容旧代码里的 App.embedded 判断

    if (inShell) {
      document.body.classList.add('embedded');
      document.documentElement.style.background = 'transparent';
      document.body.style.background = 'transparent';
      // 站内栏目链接交给外壳切栏目，别只在内层换页面
      document.addEventListener('click', (e) => {
        const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
        if (!a || a.target === '_blank') return;
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        const shell = shellParent;
        if (!shell || !shell.App) return;
        const view = shell.App.shellView(a.getAttribute('href'));
        if (!view) return;
        e.preventDefault();
        shell.App.shellLoad(view);
      });
    } else {
      // 普通页面，或被子项目 iframe 内嵌：都保留完整顶栏、页脚、主题和铃铛
      mountSea();
      App.mountTheme();
    }
    try {
      const [methods, me, ver] = await Promise.all([
        App.api('GET', '/api/auth/methods'),
        App.api('GET', '/api/me'),
        App.api('GET', '/api/version').catch(() => null),
      ]);
      App.methods = methods;
      App.serverVersion = ver && ver.version ? ver.version : '';
      if (!ver) {
        App.showStaleBanner(`服务端没有版本接口，说明还在运行旧代码（前端 v${EXPECTED_VERSION}）。`);
      } else if (ver.version !== EXPECTED_VERSION) {
        App.showStaleBanner(`前端 v${EXPECTED_VERSION} / 服务端 v${ver.version}，请重启服务端后再操作。`);
      }
      if (me.user) {
        App.user = me.user;
        document.body.classList.remove('gated');
        if (inShell) App.notifyShell(me.user);
        onReady(me.user);
      } else {
        App.requireLogin();
      }
    } catch (e) {
      App.requireLogin();
    }
    if (!App.inShell) {
      App.navPill(false);
      setTimeout(() => App.navPill(false), 400);
      window.addEventListener('resize', () => App.navPill(false));
    }
    return App;
  };

  window.App = App;
})();
