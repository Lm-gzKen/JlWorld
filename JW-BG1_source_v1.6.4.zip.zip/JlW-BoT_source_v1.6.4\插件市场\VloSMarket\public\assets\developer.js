/* 开发者中心：上传 zip 新插件 / 给已有插件发新版本 / 编辑资料 / 删除 */
(function () {
  const esc = window.escapeHtml;
  const $ = (id) => document.getElementById(id);
  const state = {
    tab: 'mine',
    openUpload: null,
    parsed: null,
    verOpen: new Map(),
    cardOpen: new Set(), // 我的插件：哪些卡片是展开状态（默认全部收起）
    plugQ: '', // 管理员插件搜索词
    adminTab: 'plugins',
  };
  const liveCards = new Map();

  // ------------------------------------------------------------ Markdown 编辑辅助
  const MD_HINT = `
    <b>常用写法</b>：<code># 标题</code> <code>**粗体**</code> <code>- 列表</code>
    <code>1. 编号</code> <code>&gt; 引用</code> <code>\`行内代码\`</code>
    <code>\`\`\`代码块\`\`\`</code> <code>[文字](链接)</code><br>
    📷 <b>插图最简单的方式：直接把图片直链粘贴进来就会自动显示</b>，例如
    <code>https://xxx.com/a.png</code>，一个符号都不用写；也支持
    <code>&lt;https://xxx.com/a.png&gt;</code> 和 <code>![说明](https://xxx.com/a.png)</code>。<br>
    支持 png / jpg / gif / webp / svg。正文里直接写 HTML 会被转义成文字显示（防 XSS）。`;

  function mdPut(ta, text, selStart, selEnd) {
    const s = ta.selectionStart;
    const e = ta.selectionEnd;
    ta.setRangeText(text, s, e, 'end');
    if (selStart !== undefined) ta.setSelectionRange(s + selStart, s + (selEnd === undefined ? selStart : selEnd));
    ta.focus();
  }

  function mdWrap(ta, before, after, ph) {
    const s = ta.selectionStart;
    const e = ta.selectionEnd;
    const sel = ta.value.slice(s, e) || ph;
    ta.setRangeText(before + sel + after, s, e, 'end');
    ta.setSelectionRange(s + before.length, s + before.length + sel.length);
    ta.focus();
  }

  function mdPrefix(ta, prefix, ph) {
    const s = ta.selectionStart;
    const ls = ta.value.lastIndexOf('\n', s - 1) + 1;
    let le = ta.value.indexOf('\n', s);
    if (le === -1) le = ta.value.length;
    const block = ta.value.slice(ls, le) || ph;
    const out = block
      .split('\n')
      .map((l, i) => (prefix.includes('{n}') ? prefix.replace('{n}', i + 1) : prefix) + l)
      .join('\n');
    ta.setRangeText(out, ls, le, 'end');
    ta.focus();
  }

  function mdToolbar(ta) {
    const bar = App.h(`
      <div class="md-tools">
        <button type="button" class="btn btn-sm" data-md="bold">粗体</button>
        <button type="button" class="btn btn-sm" data-md="italic">斜体</button>
        <button type="button" class="btn btn-sm" data-md="h2">标题</button>
        <button type="button" class="btn btn-sm" data-md="ul">列表</button>
        <button type="button" class="btn btn-sm" data-md="ol">1. 编号</button>
        <button type="button" class="btn btn-sm" data-md="quote">引用</button>
        <button type="button" class="btn btn-sm" data-md="code">代码</button>
        <button type="button" class="btn btn-sm" data-md="table">表格</button>
        <button type="button" class="btn btn-sm" data-md="link">🔗 链接</button>
        <button type="button" class="btn btn-sm" data-md="image" style="border-color:var(--accent);color:var(--accent)">🖼 插入图片</button>
      </div>`);

    bar.querySelectorAll('[data-md]').forEach((b) => {
      b.onmousedown = (ev) => ev.preventDefault();
      b.onclick = () => {
        const s = ta.selectionStart;
        const e = ta.selectionEnd;
        const sel = ta.value.slice(s, e).trim();
        const isUrl = /^https?:\/\//i.test(sel);
        switch (b.dataset.md) {
          case 'bold':
            return mdWrap(ta, '**', '**', '粗体文字');
          case 'italic':
            return mdWrap(ta, '*', '*', '斜体文字');
          case 'h2':
            return mdPrefix(ta, '## ', '小标题');
          case 'ul':
            return mdPrefix(ta, '- ', '列表项');
          case 'ol':
            return mdPrefix(ta, '{n}. ', '列表项');
          case 'quote':
            return mdPrefix(ta, '> ', '引用内容');
          case 'code':
            return sel.includes('\n') ? mdWrap(ta, '```\n', '\n```', '代码内容') : mdWrap(ta, '`', '`', '代码');
          case 'table':
            return mdPut(ta, '\n| 列1 | 列2 |\n| --- | --- |\n| 内容 | 内容 |\n');
          case 'link':
            if (isUrl) return mdPut(ta, `[点这里](${sel})`);
            return mdPut(ta, '[链接文字](https://)', 7, 15);
          case 'image':
            if (isUrl) return mdPut(ta, `![图片](${sel})`);
            return mdPut(ta, '![图片说明](https://图片直链.png)', 7, 26);
        }
      };
    });
    return bar;
  }

  function enhanceMd(root) {
    const ta = root.querySelector('textarea[data-f="readme"]');
    if (!ta) return;
    const prev = ta.previousElementSibling;
    if (!prev || !prev.classList || !prev.classList.contains('md-tools')) {
      ta.parentNode.insertBefore(mdToolbar(ta), ta);
    }
    const hint = ta.parentNode.querySelector('.hint');
    if (hint) {
      hint.className = 'md-tip';
      hint.innerHTML = MD_HINT;
    }
  }

  // ------------------------------------------------------------ 上传 zip
  function inspectZip(file, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/inspect?name=' + encodeURIComponent(file.name));
      xhr.withCredentials = true;
      xhr.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
      xhr.onload = () => {
        let json = null;
        try {
          json = JSON.parse(xhr.responseText);
        } catch {}
        if (xhr.status === 200) resolve(json);
        else reject(new Error((json && json.error) || `上传失败（HTTP ${xhr.status}）`));
      };
      xhr.onerror = () => reject(new Error('网络错误，上传中断'));
      xhr.send(file);
    });
  }

  /** 拖拽 / 点击选择 zip，选好就上传解析 */
  function zipZone(onParsed, opts = {}) {
    const el = App.h(`
      <div>
        <div class="drop" data-drop>
          <b>点击选择 .zip 压缩包</b>
          <span>或把压缩包拖到这里 · 上传后自动解析插件名称和版本号 · 单个包最大 ${App.methods && App.methods.maxUploadMB ? App.methods.maxUploadMB : 32} MB</span>
          <input type="file" accept=".zip" hidden>
        </div>
        <div data-progress hidden style="margin-top:10px">
          <div class="fileline"><span class="nm" style="flex:1">正在上传并解析…</span><span class="badge" data-st>0%</span></div>
          <div class="progress"><i></i></div>
        </div>
        <div class="alert alert-err" data-err hidden style="margin-top:10px"></div>
      </div>`);
    const input = el.querySelector('input');
    const drop = el.querySelector('[data-drop]');
    const box = el.querySelector('[data-progress]');
    const bar = box.querySelector('.progress i');
    const st = box.querySelector('[data-st]');
    const errBox = el.querySelector('[data-err]');

    const handle = async (file) => {
      errBox.hidden = true;
      if (!file) return;
      if (!/\.zip$/i.test(file.name)) {
        errBox.hidden = false;
        errBox.textContent = '插件只支持 .zip 压缩包';
        return;
      }
      const maxMB = (App.methods && Number(App.methods.maxUploadMB)) || 32;
      if (file.size > maxMB * 1048576) {
        errBox.hidden = false;
        errBox.textContent = `压缩包不能超过 ${maxMB} MB（当前 ${App.fmtSize(file.size)}）`;
        return;
      }
      box.hidden = false;
      bar.style.width = '0%';
      st.textContent = '0%';
      try {
        const res = await inspectZip(file, (pct) => {
          bar.style.width = Math.round(pct * 100) + '%';
          st.textContent = '上传 ' + Math.round(pct * 100) + '%';
        });
        bar.style.width = '100%';
        st.textContent = '解析完成';
        setTimeout(() => (box.hidden = true), 700);
        onParsed(res, file);
      } catch (e) {
        box.hidden = true;
        errBox.hidden = false;
        errBox.textContent = e.message;
      }
    };

    drop.onclick = () => input.click();
    input.onchange = () => {
      if (input.files.length) handle(input.files[0]);
      input.value = '';
    };
    drop.ondragover = (e) => {
      e.preventDefault();
      drop.classList.add('over');
    };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = (e) => {
      e.preventDefault();
      drop.classList.remove('over');
      const file = (e.dataTransfer.files || [])[0];
      if (file) handle(file);
    };
    return el;
  }

  function parsedSummary(parsed) {
    const warn = (parsed.warnings || [])
      .map((w) => `<div class="alert alert-warn" style="margin-top:8px">${esc(w)}</div>`)
      .join('');
    return `
      <div class="repo" style="margin-top:12px">
        <div class="repo-head">
          <b>包内容</b>
          <span class="badge">${parsed.entryCount} 个文件</span>
          <span class="tiny muted-2">${App.fmtSize(parsed.totalSize)}</span>
          <span class="spacer"></span>
          <span class="tiny muted-2">${parsed.hasDll ? '本体 ' + esc(parsed.dllName) : '没有 .dll'}</span>
        </div>
        <table class="filelist"><tbody>${(parsed.entries || [])
          .slice(0, 40)
          .map(
            (e) =>
              `<tr><td class="fi">${App.fileChip(App.extOf(e.name))}</td><td class="fn"><span class="fname">${esc(e.name)}</span></td><td class="fs">${App.fmtSize(e.size)}</td></tr>`
          )
          .join('')}</tbody></table>
        ${parsed.truncated || parsed.entryCount > 40 ? `<div class="repo-empty tiny">只显示前 40 个文件，完整内容以包内为准</div>` : ''}
      </div>${warn}`;
  }

  // ------------------------------------------------------------ 我的插件
  function publicStatusBadge(p) {
    return p.offline
      ? '<span class="badge badge-red">已下架</span>'
      : '<span class="badge badge-green">已发布</span>';
  }

  async function renderMine() {
    const pane = $('paneMine');
    liveCards.clear();
    pane.innerHTML = '<div class="loading">加载中…</div>';
    let data;
    try {
      data = await App.api('GET', '/api/my/plugins');
    } catch (e) {
      pane.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }
    App.refreshBell();

    if (!data.items.length) {
      pane.innerHTML = `
        <div class="empty">
          <div class="big">📦</div>
          <div>你还没有上传过插件</div>
          <div class="small" style="margin-top:6px">把插件打成 .zip，上传后会自动解析名称和版本</div>
          <div style="margin-top:14px"><button class="btn btn-primary" data-goto-new>上传第一个插件</button></div>
        </div>`;
      pane.querySelector('[data-goto-new]').onclick = () => go('new');
      return;
    }

    pane.innerHTML = '';
    const hint = App.h(
      '<div class="tiny muted-2" style="margin-bottom:10px">每张卡片是一个插件，点击卡片展开查看版本记录和上架 / 删除等操作</div>'
    );
    pane.appendChild(hint);
    for (const p of data.items) pane.appendChild(buildCard(p));
  }

  function setOpenUpload(pid) {
    state.openUpload = pid;
    for (const c of liveCards.values()) c.syncUpload();
  }

  function entryRows(entries, limit) {
    return (entries || [])
      .slice(0, limit)
      .map(
        (e) =>
          `<tr><td class="fi">${App.fileChip(App.extOf(e.name))}</td><td class="fn"><span class="fname">${esc(e.name)}</span></td><td class="fs">${App.fmtSize(e.size)}</td></tr>`
      )
      .join('');
  }

  function releaseTable(p) {
    if (!p.releases.length) {
      return '<div class="repo"><div class="repo-empty">还没有发布任何版本</div></div>';
    }
    const groups = p.releases
      .map((r) => {
        const key = p.id + '|' + r.version;
        const open = state.verOpen.has(key) ? state.verOpen.get(key) : r.version === p.version;
        const isCurrent = r.version === p.version;
        return `
          <div class="vgroup" data-ver="${esc(r.version)}">
            <div class="vhead" data-vtoggle="${esc(r.version)}">
              <span class="vcaret">${open ? '▾' : '▸'}</span>
              <span class="badge badge-accent">v${esc(r.version)}</span>
              ${isCurrent ? '<span class="badge badge-green">当前版本</span>' : '<span class="badge">历史版本</span>'}
              <span class="tiny muted-2">${r.entryCount} 个文件 · ${App.fmtSize(r.size)}</span>
              <span class="spacer"></span>
              <span class="tiny muted-2">${App.fmtRel(r.created)}</span>
            </div>
            <div class="vbody" ${open ? '' : 'hidden'}>
              <div style="padding:9px 12px 10px">
                <div class="row-wrap" style="gap:8px">
                  <a class="btn btn-sm nowrap" href="/api/releases/${r.id}/download">下载这个版本</a>
                  <span class="tiny muted-2">${esc(r.filename)}</span>
                  <span class="spacer"></span>
                  <span class="tiny muted-2">sha256 ${esc(r.sha256.slice(0, 12))}…</span>
                </div>
                ${r.changelog ? `<div class="tiny muted" style="margin-top:7px;white-space:pre-wrap">${esc(r.changelog)}</div>` : ''}
                <table class="filelist" style="margin-top:8px"><tbody>${entryRows(r.entries, 60)}</tbody></table>
                ${(r.entries || []).length < r.entryCount ? `<div class="tiny muted-2" style="margin-top:6px">还有 ${r.entryCount - r.entries.length} 个文件没有显示</div>` : ''}
              </div>
            </div>
          </div>`;
      })
      .join('');
    const total = p.releases.reduce((a, r) => a + r.size, 0);
    return `
      <div class="repo">
        <div class="repo-head">
          <b>版本</b>
          <span class="badge">${p.releases.length}</span>
          <span class="tiny muted-2">总计 ${App.fmtSize(total)}</span>
          <span class="spacer"></span>
          <span class="tiny muted-2">每个版本一个 zip · 点版本行展开</span>
        </div>
        ${groups}
      </div>`;
  }

  /** 新版本上传面板：拖入 zip → 显示解析结果 → 填版本号/更新说明 → 发布 */
  function releasePanel(p, onChanged) {
    const box = App.h(`
      <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--line-soft)">
        <div class="row-wrap" style="margin-bottom:8px">
          <b class="small">上传新版本</b>
          <span class="tiny muted-2">选一个 .zip，系统会解析出版本号，确认后直接发布</span>
        </div>
        <div data-zone></div>
        <div data-form hidden style="margin-top:12px">
          <div data-summary></div>
          <div class="row-wrap" style="gap:12px;align-items:flex-start">
            <label class="field" style="width:170px;margin-bottom:0"><span>版本号 *</span><input type="text" data-upver></label>
            <label class="field" style="flex:1;margin-bottom:0"><span>更新说明（可选）</span><input type="text" data-changelog placeholder="这一版改了什么"></label>
          </div>
          <div class="alert alert-err" data-err hidden style="margin-top:10px"></div>
          <div class="row" style="margin-top:12px">
            <button class="btn btn-primary" data-publish>发布新版本</button>
            <button class="btn btn-ghost" data-reset>重新选择</button>
            <span class="tiny muted-2">发布后立刻出现在市场，历史版本保留</span>
          </div>
        </div>
      </div>`);

    const zoneHost = box.querySelector('[data-zone]');
    const form = box.querySelector('[data-form]');
    const summaryBox = box.querySelector('[data-summary]');
    const verInput = box.querySelector('[data-upver]');
    const changeInput = box.querySelector('[data-changelog]');
    const errBox = box.querySelector('[data-err]');
    let token = '';

    const mountZone = () => {
      zoneHost.innerHTML = '';
      const z = zipZone((res) => {
        token = res.token;
        verInput.value = res.parsed.version || p.version;
        form.hidden = false;
        summaryBox.innerHTML = parsedSummary(res.parsed);
        verInput.focus();
      });
      zoneHost.appendChild(z);
    };
    mountZone();

    box.querySelector('[data-reset]').onclick = () => {
      form.hidden = true;
      token = '';
      summaryBox.innerHTML = '';
      mountZone();
    };

    box.querySelector('[data-publish]').onclick = async () => {
      const btn = box.querySelector('[data-publish]');
      errBox.hidden = true;
      if (!token) {
        errBox.hidden = false;
        errBox.textContent = '请先选择一个 .zip';
        return;
      }
      btn.disabled = true;
      try {
        const r = await App.api('POST', `/api/plugins/${p.id}/releases`, {
          token,
          version: verInput.value.trim(),
          changelog: changeInput.value.trim(),
        });
        App.toast(`v${r.release.version} 已发布`, 'ok');
        setOpenUpload(null);
        onChanged();
      } catch (e) {
        errBox.hidden = false;
        errBox.textContent = e.message;
        btn.disabled = false;
      }
    };
    return box;
  }

  function buildCard(p) {
    const card = App.h(`
      <div class="card my-card" style="margin-bottom:14px" data-pid="${esc(p.id)}">
        <div class="row-wrap my-head" data-head></div>
        <div class="my-body" data-body hidden>
          <div class="my-acts" data-acts></div>
          <div data-upload></div>
          <div class="small muted" style="margin-top:10px" data-sum></div>
          <div class="row-wrap tiny muted-2" style="margin-top:8px" data-stats></div>
          <div style="margin-top:12px" data-files></div>
        </div>
      </div>`);

    const headEl = card.querySelector('[data-head]');
    const bodyEl = card.querySelector('[data-body]');
    const actsEl = card.querySelector('[data-acts]');
    const sumEl = card.querySelector('[data-sum]');
    const statsEl = card.querySelector('[data-stats]');
    const filesEl = card.querySelector('[data-files]');
    const upEl = card.querySelector('[data-upload]');
    let cur = p;

    const isOpen = () => state.cardOpen.has(cur.id);

    /** 按 cardOpen 同步展开 / 收起（刷新、切标签后保持状态） */
    function applyOpen() {
      const open = isOpen();
      bodyEl.hidden = !open;
      card.classList.toggle('open', open);
      const t = headEl.querySelector('[data-expand]');
      if (t) {
        t.textContent = open ? '▾' : '▸';
        t.title = open ? '收起插件信息' : '展开查看插件信息';
        t.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
    }

    function toggleOpen(force) {
      const open = force === undefined ? !isOpen() : !!force;
      if (open) state.cardOpen.add(cur.id);
      else state.cardOpen.delete(cur.id);
      applyOpen();
    }

    function paintHead() {
      headEl.innerHTML = `
        <button type="button" class="my-toggle" data-expand aria-label="展开或收起插件信息">${isOpen() ? '▾' : '▸'}</button>
        <h3 style="margin:0;font-size:17px">${esc(cur.name)}</h3>
        <span class="badge badge-accent">v${esc(cur.version)}</span>
        ${publicStatusBadge(cur)}
        ${cur.pinned ? '<span class="badge badge-amber">置顶中</span>' : ''}
        ${cur.unread ? `<span class="badge badge-red">${cur.unread} 条新消息</span>` : ''}
        ${cur.deps && cur.deps.length ? `<span class="badge" title="安装前需要先装的前置插件">前置 ${cur.deps.length}</span>` : ''}
        <span class="spacer"></span>
        <span class="tiny muted-2" data-meta>⬇ ${cur.downloads} · 👁 ${cur.views} · 📦 ${cur.releases.length} 个版本 · 更新于 ${App.fmtRel(cur.updated)}</span>`;
      headEl.querySelector('[data-expand]').onclick = (ev) => {
        ev.stopPropagation();
        toggleOpen();
      };
      headEl.onclick = (ev) => {
        if (ev.target.closest('button, a, input')) return;
        toggleOpen();
      };
    }

    function paintBody() {
      actsEl.innerHTML = `
        <a class="btn btn-sm btn-ghost" href="/market#/p/${esc(cur.id)}" target="_blank" title="在插件市场打开">在市场查看</a>
        <button class="btn btn-sm" data-act="edit">编辑资料</button>
        <button class="btn btn-sm" data-act="upload">上传新版本</button>
        <button class="btn btn-sm" data-act="toggle">${cur.offline ? '重新上架' : '下架'}</button>
        <button class="btn btn-sm btn-danger" data-act="del">删除</button>`;
      actsEl.querySelectorAll('[data-act]').forEach((b) => (b.onclick = () => onAct(b.dataset.act)));
      sumEl.textContent = cur.summary || '（没有简短介绍）';
      statsEl.innerHTML = `
        <span>💬 ${cur.commentCount} 条留言</span>
        <span>📦 ${cur.releases.length} 个版本</span>
        <span>更新于 ${App.fmtRel(cur.updated)}</span>`;
      filesEl.innerHTML = releaseTable(cur);
      filesEl.querySelectorAll('[data-vtoggle]').forEach((h) => {
        h.onclick = () => {
          const ver = h.dataset.vtoggle;
          const b = h.parentElement.querySelector('.vbody');
          const willOpen = b.hidden;
          b.hidden = !willOpen;
          h.querySelector('.vcaret').textContent = willOpen ? '▾' : '▸';
          state.verOpen.set(cur.id + '|' + ver, willOpen);
        };
      });
    }

    function paintUpload() {
      upEl.innerHTML = '';
      if (state.openUpload !== cur.id) return;
      upEl.appendChild(releasePanel(cur, refresh));
      toggleOpen(true);
      // 面板就在按钮下面，再滚一下确保整块可见
      upEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    async function refresh() {
      try {
        const d = await App.api('GET', '/api/my/plugins');
        App.refreshBell();
        const np = d.items.find((x) => x.id === cur.id);
        if (!np) return;
        cur = np;
        paintHead();
        paintBody();
        paintUpload();
      } catch {}
    }

    async function onAct(act) {
      if (act === 'upload') {
        setOpenUpload(state.openUpload === cur.id ? null : cur.id);
        return;
      }
      if (act === 'edit') return openEdit(cur);
      if (act === 'toggle') {
        try {
          const r = await App.api('POST', `/api/plugins/${cur.id}/offline`, { offline: !cur.offline });
          App.toast(r.offline ? '插件已下架，市场里不再显示' : '插件已重新上架', 'ok');
          refresh();
        } catch (e) {
          App.toast(e.message, 'err');
        }
        return;
      }
      if (act === 'del') {
        if (!confirm(`确定删除插件《${cur.name}》吗？所有版本、留言都会一并删除。`)) return;
        try {
          await App.api('DELETE', '/api/plugins/' + cur.id);
          App.toast('插件已删除', 'ok');
          renderMine();
        } catch (e) {
          App.toast(e.message, 'err');
        }
      }
    }

    paintHead();
    paintBody();
    paintUpload();
    applyOpen();
    liveCards.set(p.id, { syncUpload: paintUpload });
    return card;
  }

  // ------------------------------------------------------------ 前置插件选择器
  const depOptions = { at: 0, items: null };

  async function loadDepOptions() {
    if (depOptions.items && Date.now() - depOptions.at < 60000) return depOptions.items;
    const d = await App.api('GET', '/api/plugin-options');
    depOptions.items = d.items || [];
    depOptions.at = Date.now();
    return depOptions.items;
  }

  /** 多选 + 搜索的前置插件选择器；host.getSelected() 取当前选中的 id 列表 */
  function depsPicker(selected, excludeId) {
    const host = App.h(`
      <div class="deps-picker">
        <input type="search" data-depq placeholder="搜索插件名 / 作者" autocomplete="off">
        <div class="deps-list" data-deplist><div class="loading">加载插件列表…</div></div>
        <div class="tiny muted-2" data-dephint style="margin-top:6px"></div>
      </div>`);
    const picked = new Set(selected || []);
    const list = host.querySelector('[data-deplist]');
    const q = host.querySelector('[data-depq]');
    const hint = host.querySelector('[data-dephint]');
    let items = [];

    const syncHint = () => {
      hint.textContent = picked.size
        ? `已选 ${picked.size} 个前置插件，会按顺序提示用户先安装`
        : '可多选；前置插件会显示在插件详情页，提醒用户先安装';
    };

    const paint = () => {
      const kw = q.value.trim().toLowerCase();
      if (!items.length) {
        list.innerHTML = '<div class="empty" style="padding:18px">还没有其它插件可以选</div>';
        return;
      }
      const rows = items.filter(
        (it) => it.id !== excludeId && (!kw || `${it.name} ${it.author}`.toLowerCase().includes(kw))
      );
      if (!rows.length) {
        list.innerHTML = '<div class="empty" style="padding:18px">没有匹配的插件</div>';
        return;
      }
      list.innerHTML = rows
        .map(
          (it) => `
          <label class="dep-row">
            <input type="checkbox" value="${esc(it.id)}" ${picked.has(it.id) ? 'checked' : ''}>
            <span class="dep-nm">${esc(it.name)}</span>
            <span class="badge badge-accent">v${esc(it.version)}</span>
            ${it.offline ? '<span class="badge badge-red">已下架</span>' : ''}
            <span class="spacer"></span>
            <span class="tiny muted-2">${esc(it.author)}</span>
          </label>`
        )
        .join('');
      list.querySelectorAll('input[type=checkbox]').forEach((cb) => {
        cb.onchange = () => {
          if (cb.checked) picked.add(cb.value);
          else picked.delete(cb.value);
          syncHint();
        };
      });
      syncHint();
    };

    q.oninput = paint;
    loadDepOptions()
      .then((all) => {
        items = all;
        paint();
      })
      .catch((e) => {
        list.innerHTML = `<div class="alert alert-err" style="margin:8px">${esc(e.message)}</div>`;
      });

    host.getSelected = () => [...picked];
    return host;
  }

  function openEdit(p) {
    const box = App.h(`
      <div class="gate">
        <div class="gate-box" style="max-width:620px">
          <div class="gate-head" style="text-align:left">
            <h2 style="font-size:17px">编辑插件资料</h2>
            <p>只改资料，不会影响已发布的版本；版本号由上传的包决定</p>
          </div>
          <div class="gate-body">
            <label class="field"><span>插件名称</span><input type="text" data-f="name" value="${esc(p.name)}"></label>
            <label class="field"><span>作者</span><input type="text" data-f="author" value="${esc(p.author)}"></label>
            <label class="field"><span>简短介绍</span><input type="text" data-f="summary" value="${esc(p.summary || '')}" placeholder="一句话说明这个插件做什么"></label>
            <label class="field"><span>标签</span><input type="text" data-f="tags" value="${esc((p.tags || []).join(','))}" placeholder="用逗号分隔，最多 8 个"></label>
            <div class="field"><span>前置插件（可多选）</span><div data-deps></div></div>
            <label class="field"><span>详细介绍（支持 Markdown）</span>
              <textarea data-f="readme" style="min-height:180px" placeholder="# 标题&#10;&#10;支持 **粗体**、列表、代码块、表格…&#10;&#10;插图片：直接把图片直链粘贴进来"></textarea>
              <div class="hint"></div>
            </label>
            <div class="alert alert-err" data-err hidden></div>
            <div class="row" style="margin-top:14px">
              <button class="btn btn-primary" data-save>保存</button>
              <button class="btn" data-cancel>取消</button>
            </div>
          </div>
        </div>
      </div>`);
    box.querySelector('[data-f="readme"]').value = p.readme || '';
    box.querySelector('[data-deps]').appendChild(depsPicker((p.deps || []).map((d) => d.id), p.id));
    box.querySelector('[data-deps]').getSelected = box.querySelector('[data-deps] .deps-picker').getSelected;
    document.body.appendChild(box);
    enhanceMd(box);

    const f = (n) => box.querySelector(`[data-f="${n}"]`).value;
    box.querySelector('[data-cancel]').onclick = () => box.remove();
    box.querySelector('[data-save]').onclick = async () => {
      const errBox = box.querySelector('[data-err]');
      const btn = box.querySelector('[data-save]');
      btn.disabled = true;
      try {
        await App.api('PATCH', `/api/plugins/${p.id}`, {
          name: f('name'),
          author: f('author'),
          summary: f('summary'),
          readme: f('readme'),
          tags: f('tags'),
          deps: box.querySelector('[data-deps]').getSelected(),
        });
        box.remove();
        App.toast('已保存', 'ok');
        renderMine();
      } catch (e) {
        errBox.hidden = false;
        errBox.textContent = e.message;
        btn.disabled = false;
      }
    };
  }

  // ------------------------------------------------------------ 上传新插件
  function renderNew() {
    const pane = $('paneNew');
    pane.innerHTML = '';
    const card = App.h(`
      <div class="card" style="max-width:820px">
        <h3 style="font-size:17px;margin-bottom:4px">上传新插件</h3>
        <p class="small muted" style="margin-top:0">插件只支持 <b>.zip</b> 压缩包。包内可以放 <span class="mono">.dll</span>、源码、说明等任意文件；也可以放一个 <span class="mono">plugin.json</span>（{"name":"插件名","version":"1.0.0"}）让名称和版本更准确。</p>
        <div data-zone style="margin-top:14px"></div>
        <div data-form hidden></div>
      </div>`);
    pane.appendChild(card);

    const zoneHost = card.querySelector('[data-zone]');
    const form = card.querySelector('[data-form]');
    let token = '';
    let parsed = null;

    const mountZone = () => {
      zoneHost.innerHTML = '';
      zoneHost.appendChild(
        zipZone((res) => {
          token = res.token;
          parsed = res.parsed;
          renderForm();
        })
      );
    };

    function renderForm() {
      zoneHost.hidden = true;
      form.hidden = false;
      form.innerHTML = `
        <div class="row-wrap" style="margin-bottom:10px">
          <span class="badge badge-green">已解析</span>
          <span class="tiny muted-2">名称和版本是自动识别的，可以修改；确认无误后发布</span>
        </div>
        ${parsedSummary(parsed)}
        <div class="row" style="gap:12px;align-items:flex-start;margin-top:14px">
          <label class="field" style="flex:2"><span>插件名称 *</span><input type="text" data-f="name" value="${esc(parsed.name)}"></label>
          <label class="field" style="flex:1"><span>版本号 *</span><input type="text" data-f="version" value="${esc(parsed.version)}"></label>
        </div>
        <div class="row" style="gap:12px;align-items:flex-start">
          <label class="field" style="flex:1"><span>作者 *</span><input type="text" data-f="author" value="${esc(defaultAuthor())}"></label>
          <label class="field" style="flex:2"><span>标签</span><input type="text" data-f="tags" placeholder="用逗号分隔，最多 8 个，例如：签到,工具"></label>
        </div>
        <label class="field"><span>简短介绍</span><input type="text" data-f="summary" placeholder="一句话说明这个插件做什么（显示在卡片上）"></label>
        <div class="field"><span>前置插件（可多选）</span><div data-deps></div></div>
        <label class="field"><span>详细介绍（支持 Markdown）</span>
          <textarea data-f="readme" style="min-height:200px" placeholder="# 功能&#10;&#10;- 支持 xxx&#10;- 支持 yyy&#10;&#10;## 使用方法&#10;&#10;解压后把 .dll 放进插件目录即可"></textarea>
          <div class="hint"></div>
        </label>
        <div class="alert alert-err" data-err hidden></div>
        <div class="row" style="margin-top:14px">
          <button class="btn btn-primary" data-publish>发布到市场</button>
          <button class="btn" data-reset>重新选择压缩包</button>
          <span class="tiny muted-2">发布后立刻出现在插件市场</span>
        </div>`;
      enhanceMd(form);
      form.querySelector('[data-deps]').appendChild(depsPicker([], null));
      form.querySelector('[data-deps]').getSelected = form.querySelector('[data-deps] .deps-picker').getSelected;

      const f = (n) => form.querySelector(`[data-f="${n}"]`).value;
      form.querySelector('[data-reset]').onclick = () => {
        form.hidden = true;
        form.innerHTML = '';
        zoneHost.hidden = false;
        token = '';
        parsed = null;
        mountZone();
      };
      form.querySelector('[data-publish]').onclick = async () => {
        const btn = form.querySelector('[data-publish]');
        const errBox = form.querySelector('[data-err]');
        errBox.hidden = true;
        btn.disabled = true;
        try {
          const r = await App.api('POST', '/api/plugins', {
            token,
            name: f('name'),
            author: f('author'),
            version: f('version'),
            summary: f('summary'),
            tags: f('tags'),
            readme: f('readme'),
            deps: form.querySelector('[data-deps]').getSelected(),
          });
          App.toast(`《${r.plugin.name}》v${r.plugin.version} 已发布`, 'ok');
          state.tab = 'mine';
          renderTabs();
          renderMine();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (e) {
          errBox.hidden = false;
          errBox.textContent = e.message;
          btn.disabled = false;
        }
      };
    }

    mountZone();
  }

  function defaultAuthor() {
    const u = App.user || {};
    if (u.qq) return 'QQ ' + u.qq;
    return (u.email || '').split('@')[0] || '匿名';
  }

  // ------------------------------------------------------------ api 上传
  function copyText(text, btn) {
    const done = () => {
      if (!btn) return;
      const old = btn.textContent;
      btn.textContent = '已复制';
      setTimeout(() => (btn.textContent = old), 1200);
    };
    const fallback = () => {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        done();
      } catch {}
      ta.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(fallback);
    } else {
      fallback();
    }
  }

  async function renderApi() {
    const pane = $('paneApi');
    pane.innerHTML = '<div class="loading">加载中…</div>';
    let tok;
    let mine;
    try {
      [tok, mine] = await Promise.all([App.api('GET', '/api/my/api-token'), App.api('GET', '/api/my/plugins')]);
    } catch (e) {
      pane.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }

    const base = location.origin;
    const token = tok.token;
    const pluginRows = mine.items.length
      ? mine.items
          .map(
            (p) => `<tr>
              <td><b>${esc(p.name)}</b> ${p.offline ? '<span class="badge badge-red">已下架</span>' : ''}</td>
              <td>v${esc(p.version)}</td>
              <td class="mono" style="font-size:12px">${esc(p.id)}</td>
              <td style="text-align:right"><button class="btn btn-sm" data-copy="${esc(p.id)}">复制 ID</button></td>
            </tr>`
          )
          .join('')
      : '<tr><td colspan="4" class="muted">还没有插件，先上传一个吧</td></tr>';

    pane.innerHTML = `
      <div class="card" style="margin-bottom:14px">
        <div class="row-wrap">
          <h3 style="margin:0;font-size:17px">API 令牌</h3>
          <span class="badge badge-amber">保密</span>
          <span class="spacer"></span>
          <button class="btn btn-sm btn-primary" data-copy="${esc(token)}">复制令牌</button>
          <button class="btn btn-sm" data-refresh-token>重新生成</button>
        </div>
        <p class="small muted" style="margin-top:6px">所有上传接口都用这个令牌认证；令牌泄露请立即点「重新生成」，旧令牌会立刻失效。</p>
        <pre class="codeblock">${esc(token)}</pre>
        <div class="tiny muted-2" style="margin-top:6px">创建：${App.fmtTime(tok.created)} · 最近使用：${
          tok.lastUsed ? App.fmtRel(tok.lastUsed) : '还没用过'
        }</div>
      </div>

      <div class="card" style="margin-bottom:14px">
        <h3 style="font-size:17px">上传 / 更新接口</h3>
        <p class="small muted" style="margin-top:0">请求体直接是 zip 文件（binary），<b>不要用 multipart/form-data</b>；认证头是 <span class="mono">Authorization: Bearer 令牌</span>。</p>
        <table class="tbl">
          <thead><tr><th>用途</th><th>方法与地址</th></tr></thead>
          <tbody>
            <tr><td>创建新插件</td><td class="mono">POST /api/v1/plugins</td></tr>
            <tr><td>更新已有插件</td><td class="mono">POST /api/v1/plugins/{插件ID}/releases</td></tr>
            <tr><td>查看自己 + 插件 ID</td><td class="mono">GET /api/v1/me</td></tr>
          </tbody>
        </table>
        <div class="tiny muted-2" style="margin-top:8px">可选查询参数：<span class="mono">name / author / summary / tags / version / changelog / filename</span>；不传 name、version 时自动从 zip 里解析。单包上限 ${App.methods && App.methods.maxUploadMB ? App.methods.maxUploadMB : 32} MB。</div>

        <div class="k" style="margin-top:14px">1. 创建新插件</div>
        <pre class="codeblock">curl -X POST "${base}/api/v1/plugins?name=插件名&tags=工具" \\
  -H "Authorization: Bearer ${esc(token)}" \\
  -H "Content-Type: application/zip" \\
  --data-binary "@插件.zip"</pre>

        <div class="k" style="margin-top:12px">2. 更新已有插件（换个版本号就是发新版本）</div>
        <pre class="codeblock">curl -X POST "${base}/api/v1/plugins/插件ID/releases?version=1.2.0&changelog=修复问题" \\
  -H "Authorization: Bearer ${esc(token)}" \\
  -H "Content-Type: application/zip" \\
  --data-binary "@插件.zip"</pre>

        <div class="k" style="margin-top:12px">3. 查看自己的插件 ID</div>
        <pre class="codeblock">curl "${base}/api/v1/me" -H "Authorization: Bearer ${esc(token)}"</pre>

        <div class="alert alert-info" style="margin-top:12px">返回 JSON：成功 <span class="mono">{"ok":true,"plugin":{"id":"...","version":"..."},"msg":"..."}</span>；失败 <span class="mono">{"error":"原因"}</span>。同一插件同一个版本号不能重复发布。</div>
      </div>

      <div class="card">
        <h3 style="font-size:17px">我的插件 ID</h3>
        <p class="small muted" style="margin-top:0">更新时把下面的 ID 填到 <span class="mono">/api/v1/plugins/{ID}/releases</span>。</p>
        <div style="overflow:auto">
          <table class="tbl">
            <thead><tr><th>插件</th><th>当前版本</th><th>插件 ID</th><th></th></tr></thead>
            <tbody>${pluginRows}</tbody>
          </table>
        </div>
      </div>`;

    pane.querySelectorAll('[data-copy]').forEach((b) => {
      b.onclick = () => copyText(b.dataset.copy, b);
    });

    const refresh = pane.querySelector('[data-refresh-token]');
    if (refresh) {
      refresh.onclick = async () => {
        if (!confirm('重新生成后旧令牌会立即失效，正在用旧令牌的脚本会断开。确定继续？')) return;
        refresh.disabled = true;
        try {
          const r = await App.api('POST', '/api/my/api-token/refresh');
          App.toast(r.msg || '令牌已重新生成', 'ok');
          renderApi();
        } catch (e) {
          App.toast(e.message, 'err');
          refresh.disabled = false;
        }
      };
    }
  }

  // ------------------------------------------------------------ 管理员工具
  async function renderAdmin() {
    const pane = $('paneAdmin');
    pane.innerHTML = '<div class="loading">加载中…</div>';
    let data;
    let admins;
    let users;
    let settings;
    try {
      [data, admins, users, settings] = await Promise.all([
        App.api('GET', '/api/admin/plugins'),
        App.api('GET', '/api/admin/admins'),
        App.api('GET', '/api/admin/users'),
        App.api('GET', '/api/settings'),
      ]);
    } catch (e) {
      const stale = /接口不存在|HTTP 404/.test(e.message);
      pane.innerHTML = stale
        ? `<div class="alert alert-err">
             <b>服务端还在运行旧版本</b><br>
             新前端请求 /api/admin/* 时服务端返回了「接口不存在」，所以管理员列表、删除、添加管理员都用不了。<br>
             请把 Node 服务完全重启一次（不是刷新浏览器），重启后再打开这个页面。
             <div style="margin-top:10px"><button class="btn btn-sm" onclick="location.reload()">重启后点这里刷新</button></div>
           </div>`
        : `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }

    const at = state.adminTab || 'plugins';

    const versionRows = (p) => {
      if (!p.releases || !p.releases.length) {
        return '<div class="tiny muted-2">没有版本记录（旧版插件如果还有原文件，重启后会自动恢复）</div>';
      }
      return `<table class="tbl">
        <thead><tr><th>版本</th><th>包文件</th><th>大小</th><th>上传时间</th></tr></thead>
        <tbody>${p.releases
          .map(
            (r) => `<tr>
              <td><span class="badge badge-accent">v${esc(r.version)}</span></td>
              <td class="mono tiny">${esc(r.filename)}</td>
              <td>${App.fmtSize(r.size)}</td>
              <td class="tiny muted-2">${App.fmtTime(r.created)}</td>
            </tr>`
          )
          .join('')}</tbody>
      </table>`;
    };

    const pluginList = data.items
      .map(
        (p) => `
      <div class="adm-item" data-item="${esc(p.id)}" data-search="${esc(
        `${p.name} ${p.id} ${p.author || ''} ${p.owner?.email || ''} ${p.ownerMasked || ''}`.toLowerCase()
      )}">
        <div class="adm-head" data-toggle="${esc(p.id)}">
          <span class="vcaret">▸</span>
          <span class="nm">${esc(p.name)}</span>
          <span class="badge badge-accent">v${esc(p.version)}</span>
          ${p.offline ? '<span class="badge badge-red">已下架</span>' : '<span class="badge badge-green">上架中</span>'}
          ${p.pinned ? '<span class="badge badge-amber">置顶</span>' : ''}
          <span class="tiny muted-2">上传者 ${esc(p.ownerMasked)}</span>
          <span class="spacer"></span>
          <span class="tiny muted-2">${p.releaseCount} 个版本 · ⬇ ${p.downloads}</span>
          <span class="tiny muted-2">${App.fmtRel(p.updated)}</span>
        </div>
        <div class="adm-body" hidden>
          <div class="adm-grid">
            <div><div class="k">上传者邮箱</div><div class="v">${esc(p.owner.email)}</div></div>
            <div><div class="k">QQ</div><div class="v">${esc(p.owner.qq || '未绑定')}</div></div>
            <div><div class="k">openid</div><div class="v tiny mono">${esc(p.owner.openid || '—')}</div></div>
            <div><div class="k">账户注册时间</div><div class="v">${p.owner.joined ? App.fmtTime(p.owner.joined) : '—'}</div></div>
            <div><div class="k">最近登录</div><div class="v">${p.owner.lastLogin ? App.fmtRel(p.owner.lastLogin) : '—'}</div></div>
            <div><div class="k">上传时间</div><div class="v">${App.fmtTime(p.created)}</div></div>
            <div><div class="k">最近更新</div><div class="v">${App.fmtTime(p.updated)}</div></div>
            <div><div class="k">版本 / 总大小</div><div class="v">${p.releaseCount} 个 / ${App.fmtSize(p.totalSize)}</div></div>
            <div><div class="k">前置插件</div><div class="v">${
              p.deps && p.deps.length ? p.deps.map((d) => esc(d.name)).join('、') : '无'
            }</div></div>
            <div><div class="k">下载 / 浏览</div><div class="v">${p.downloads} / ${p.views}</div></div>
            <div><div class="k">留言 / 评分</div><div class="v">${p.commentCount} / ${
              p.rating.count ? `${p.rating.avg}（${p.rating.count} 人）` : '暂无'
            }</div></div>
          </div>
          <div class="adm-sub">
            <h5>版本明细</h5>
            ${versionRows(p)}
          </div>
          <div class="row-wrap" style="margin-top:12px">
            <a class="btn btn-sm btn-ghost" href="/market#/p/${esc(p.id)}" target="_blank">在市场查看</a>
            <button class="btn btn-sm" data-pin="${p.pinned ? '0' : '1'}" data-id="${esc(p.id)}">${p.pinned ? '取消置顶' : '置顶'}</button>
            <button class="btn btn-sm" data-off="${p.offline ? '0' : '1'}" data-id="${esc(p.id)}">${p.offline ? '重新上架' : '下架'}</button>
            <button class="btn btn-sm btn-danger" data-del="${esc(p.id)}" data-name="${esc(p.name)}">删除插件</button>
          </div>
        </div>
      </div>`
      )
      .join('');

    const userRows = users.items
      .map(
        (u) => `
      <tr data-user-row data-search="${esc((u.email + ' ' + u.name + ' ' + u.qq + ' ' + u.openid).toLowerCase())}">
        <td><b>${esc(u.email)}</b> ${
          u.isSuper ? '<span class="badge badge-amber">超级管理员</span>' : u.isAdmin ? '<span class="badge badge-purple">管理员</span>' : ''
        }</td>
        <td>${esc(u.name)}</td>
        <td class="tiny muted-2">${u.qq ? 'QQ ' + esc(u.qq) : '—'}${
          u.openid ? `<br><span class="mono" style="font-size:11.5px">${esc(u.openid)}</span>` : ''
        }</td>
        <td>${u.plugins} / ${u.online}</td>
        <td>${u.downloads}</td>
        <td class="tiny muted-2">${u.joined ? App.fmtTime(u.joined) : '—'}</td>
        <td class="tiny muted-2">${u.lastLogin ? App.fmtRel(u.lastLogin) : '—'}</td>
      </tr>`
      )
      .join('');

    const adminRows = admins.items
      .map(
        (a) => `
      <tr>
        <td><b>${esc(a.email)}</b> ${a.isSuper ? '<span class="badge badge-amber">超级管理员</span>' : '<span class="badge badge-purple">管理员</span>'}</td>
        <td class="tiny muted-2">${a.created ? App.fmtTime(a.created) : '固定账户'}</td>
        <td class="tiny muted-2">${a.addedBy ? esc(a.addedBy) : '—'}</td>
        <td style="text-align:right">${admins.canManage && !a.isSuper ? `<button class="btn btn-sm btn-danger" data-rm="${esc(a.email)}">移除</button>` : ''}</td>
      </tr>`
      )
      .join('');

    const ann = settings.announcement || { value: '' };
    const botName = (settings.botName && settings.botName.value) || '';

    pane.innerHTML = `
      <div class="seg" id="adminTabs" style="max-width:680px;margin-bottom:14px">
        <button data-atab="plugins" class="${at === 'plugins' ? 'on' : ''}">上架插件</button>
        <button data-atab="users" class="${at === 'users' ? 'on' : ''}">登录用户</button>
        <button data-atab="settings" class="${at === 'settings' ? 'on' : ''}">管理员设置</button>
        <button data-atab="api" class="${at === 'api' ? 'on' : ''}">Api文档</button>
      </div>

      <div data-apane="plugins" ${at === 'plugins' ? '' : 'hidden'}>
        <div class="card">
          <div class="row-wrap" style="margin-bottom:6px">
            <h3 style="margin:0;font-size:17px">插件管理</h3>
            <span class="badge">${data.total}</span>
            ${data.offlineCount ? `<span class="badge badge-red">${data.offlineCount} 个已下架</span>` : ''}
            <span class="spacer"></span>
            <input type="search" data-plugq placeholder="搜索插件名 / ID / 作者 / 上传者" style="max-width:300px" value="${esc(state.plugQ)}">
          </div>
          <p class="small muted" style="margin-top:0">点击插件行展开详情（上传者、时间、版本、数据），可以置顶 / 下架 / 重新上架 / 删除任意插件。</p>
          <div class="adm-list" data-pluglist>${pluginList || '<div class="empty">还没有插件</div>'}</div>
          <div class="empty" data-plugempty hidden>没有匹配的插件，换个关键词试试</div>
        </div>
      </div>

      <div data-apane="users" ${at === 'users' ? '' : 'hidden'}>
        <div class="card">
          <div class="row-wrap" style="margin-bottom:6px">
            <h3 style="margin:0;font-size:17px">登录用户</h3>
            <span class="badge">${users.total} 个账户</span>
            <span class="badge badge-purple">${users.admins} 个管理员</span>
            <span class="spacer"></span>
            <input type="search" data-userq placeholder="搜索邮箱 / 昵称 / QQ / openid" style="max-width:280px">
          </div>
          <p class="small muted" style="margin-top:0">所有用聚龙账户登录过本站的账户，按最近登录排序。插件列是「总数 / 上架中」。</p>
          <div style="overflow:auto">
            <table class="tbl">
              <thead><tr><th>账户</th><th>昵称</th><th>QQ / openid</th><th>插件 总/上架</th><th>下载</th><th>注册时间</th><th>最近登录</th></tr></thead>
              <tbody>${userRows || '<tr><td colspan="7" class="muted">还没有用户</td></tr>'}</tbody>
            </table>
          </div>
        </div>
      </div>

      <div data-apane="settings" ${at === 'settings' ? '' : 'hidden'}>
        <div class="card" style="margin-bottom:14px">
          <h3 style="font-size:17px">站点设置</h3>
          <p class="small muted" style="margin-top:0">首页公告支持 Markdown，保存后立即生效，存在数据库里，换代码不会丢。</p>
          <label class="field"><span>首页公告</span><textarea data-announcement style="min-height:180px">${esc(ann.value)}</textarea></label>
          <label class="field"><span>首页副标题</span><input type="text" data-botname value="${esc(botName)}" placeholder="例如：聚龙世界 · QQ 机器人框架"></label>
          <div class="alert alert-err" data-seterr hidden></div>
          <div class="row" style="margin-top:12px">
            <button class="btn btn-primary" data-savesettings>保存设置</button>
            <span class="tiny muted-2">管理员可随时修改</span>
          </div>
        </div>

        <div class="card" style="max-width:860px">
          <h3 style="font-size:17px">管理员账户</h3>
          <p class="small muted" style="margin-top:0">超级管理员固定为 <b>${esc(admins.superEmail)}</b>，不可移除。管理员可以管理插件，但只有超级管理员能增减管理员。</p>
          <table class="tbl">
            <thead><tr><th>账户</th><th>添加时间</th><th>添加人</th><th></th></tr></thead>
            <tbody>${adminRows}</tbody>
          </table>
          ${
            admins.canManage
              ? `<div class="row-wrap" style="margin-top:14px">
                   <input type="text" data-newadmin placeholder="填聚龙账户邮箱，例如 someone@qq.com" style="flex:1;min-width:240px">
                   <button class="btn btn-primary" data-addadmin>添加管理员</button>
                 </div>
                 <div class="tiny muted-2" style="margin-top:6px">对方不需要先登录；用这个邮箱登录后就会获得管理员权限。</div>`
              : '<div class="tiny muted-2" style="margin-top:10px">只有超级管理员可以增减管理员。</div>'
          }
          <div class="alert alert-err" data-aderr hidden style="margin-top:10px"></div>
        </div>
      </div>

      <div data-apane="api" ${at === 'api' ? '' : 'hidden'}>
        <div class="card" style="max-width:880px">
          <h3 style="font-size:17px">Api文档</h3>
          <p class="small muted" style="margin-top:0">登录接口：一次调用完成「账号 + 密码 + 登录」，成功后返回会话 Cookie（<span class="mono">vlos_sid</span>）。此文档仅管理员可见。</p>
          <table class="tbl">
            <tbody>
              <tr><th style="width:110px">地址</th><td class="mono">POST /api/auth/auto-login</td></tr>
              <tr><th>请求体</th><td class="mono">application/json</td></tr>
              <tr><th>参数</th><td><span class="mono">mail</span> 聚龙账户邮箱 · <span class="mono">password</span> 密码 · <span class="mono">redirect</span> 可选，站内路径（如 <span class="mono">/home</span>），传了会 302 跳转</td></tr>
              <tr><th>限流</th><td>同一 IP 5 分钟最多 10 次</td></tr>
            </tbody>
          </table>

          <div class="k" style="margin-top:14px">请求示例</div>
          <pre class="codeblock">POST /api/auth/auto-login
Content-Type: application/json

{"mail":"user@qq.com","password":"你的密码","redirect":"/home"}</pre>

          <div class="k" style="margin-top:12px">返回示例</div>
          <pre class="codeblock">HTTP/1.1 200 OK
Set-Cookie: vlos_sid=...; Path=/; HttpOnly; SameSite=Lax
{"ok":true,"user":{"email":"user@qq.com","name":"昵称"},"msg":"登录成功"}</pre>

          <div class="k" style="margin-top:12px">curl 调用</div>
          <pre class="codeblock">curl -i -X POST "https://你的站点/api/auth/auto-login" \\
  -H "Content-Type: application/json" \\
  -d "{\\"mail\\":\\"user@qq.com\\",\\"password\\":\\"你的密码\\"}"</pre>

          <div class="k" style="margin-top:12px">浏览器登录页自动化</div>
          <pre class="codeblock">// 登录框已经显示时：自动填入并提交，走完整前端登录流程
App.autoLogin('user@qq.com', '你的密码');</pre>

          <div class="alert alert-warn" style="margin-top:12px">密码只放在请求体里，不要拼到 URL；公网请务必用 HTTPS。接口只是把账号密码转发给聚龙世界验证，本站不保存密码。</div>
        </div>
      </div>`;

    // 子栏目切换
    pane.querySelectorAll('[data-atab]').forEach((b) => {
      b.onclick = () => {
        state.adminTab = b.dataset.atab;
        renderAdmin();
      };
    });

    // 上架插件搜索：插件名 / ID / 作者 / 上传者
    const plugQuery = pane.querySelector('[data-plugq]');
    if (plugQuery) {
      const rows = Array.from(pane.querySelectorAll('[data-item]'));
      const emptyEl = pane.querySelector('[data-plugempty]');
      const applyPlugFilter = () => {
        const q = plugQuery.value.trim().toLowerCase();
        let shown = 0;
        for (const el of rows) {
          const hit = !q || String(el.dataset.search || '').includes(q);
          el.hidden = !hit;
          if (hit) shown++;
        }
        if (emptyEl) emptyEl.hidden = !rows.length || shown > 0;
      };
      plugQuery.oninput = () => {
        state.plugQ = plugQuery.value;
        applyPlugFilter();
      };
      applyPlugFilter();
    }

    // 登录用户搜索
    const qInput = pane.querySelector('[data-userq]');
    if (qInput) {
      qInput.oninput = () => {
        const q = qInput.value.trim().toLowerCase();
        pane.querySelectorAll('[data-user-row]').forEach((tr) => {
          tr.hidden = !!q && !String(tr.dataset.search || '').includes(q);
        });
      };
    }

    // 点击插件行展开 / 收起详情
    pane.querySelectorAll('[data-toggle]').forEach((h) => {
      h.onclick = (ev) => {
        if (ev.target.closest('button, a')) return;
        const bodyEl = h.parentElement.querySelector('.adm-body');
        const willOpen = bodyEl.hidden;
        bodyEl.hidden = !willOpen;
        h.querySelector('.vcaret').textContent = willOpen ? '▾' : '▸';
      };
    });

    pane.querySelectorAll('[data-pin]').forEach((b) => {
      b.onclick = async () => {
        const want = b.dataset.pin === '1';
        b.disabled = true;
        try {
          await App.api('POST', '/api/admin/pin', { id: b.dataset.id, pinned: want });
          App.toast(want ? '已置顶到市场首页' : '已取消置顶', 'ok');
          renderAdmin();
        } catch (e) {
          App.toast(e.message, 'err');
          b.disabled = false;
        }
      };
    });

    pane.querySelectorAll('[data-off]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true;
        try {
          await App.api('POST', `/api/plugins/${b.dataset.id}/offline`, { offline: b.dataset.off === '1' });
          App.toast(b.dataset.off === '1' ? '插件已下架' : '插件已重新上架', 'ok');
          renderAdmin();
        } catch (e) {
          App.toast(e.message, 'err');
          b.disabled = false;
        }
      };
    });

    pane.querySelectorAll('[data-del]').forEach((b) => {
      b.onclick = async () => {
        if (!confirm(`确定删除插件《${b.dataset.name}》吗？所有版本、留言都会一并删除。`)) return;
        b.disabled = true;
        try {
          await App.api('DELETE', '/api/plugins/' + b.dataset.del);
          App.toast('插件已删除', 'ok');
          renderAdmin();
        } catch (e) {
          App.toast(e.message, 'err');
          b.disabled = false;
        }
      };
    });

    pane.querySelectorAll('[data-rm]').forEach((b) => {
      b.onclick = async () => {
        if (!confirm(`确定移除管理员 ${b.dataset.rm} 吗？`)) return;
        b.disabled = true;
        try {
          await App.api('DELETE', '/api/admin/admins/' + encodeURIComponent(b.dataset.rm));
          App.toast('已移除管理员', 'ok');
          renderAdmin();
        } catch (e) {
          App.toast(e.message, 'err');
          b.disabled = false;
        }
      };
    });

    const addBtn = pane.querySelector('[data-addadmin]');
    if (addBtn) {
      addBtn.onclick = async () => {
        const input = pane.querySelector('[data-newadmin]');
        const errBox = pane.querySelector('[data-aderr]');
        const email = input.value.trim();
        errBox.hidden = true;
        if (!email) {
          errBox.hidden = false;
          errBox.textContent = '请先填写聚龙账户邮箱';
          return;
        }
        addBtn.disabled = true;
        try {
          const r = await App.api('POST', '/api/admin/admins', { email });
          App.toast(r.msg || '已添加管理员', 'ok');
          renderAdmin();
        } catch (e) {
          errBox.hidden = false;
          errBox.textContent = e.message;
          addBtn.disabled = false;
        }
      };
    }

    const saveBtn = pane.querySelector('[data-savesettings]');
    if (saveBtn) {
      saveBtn.onclick = async () => {
        const errBox = pane.querySelector('[data-seterr]');
        errBox.hidden = true;
        saveBtn.disabled = true;
        try {
          await App.api('POST', '/api/admin/settings', {
            announcement: pane.querySelector('[data-announcement]').value,
            botName: pane.querySelector('[data-botname]').value,
          });
          App.toast('站点设置已保存', 'ok');
          saveBtn.disabled = false;
        } catch (e) {
          errBox.hidden = false;
          errBox.textContent = e.message;
          saveBtn.disabled = false;
        }
      };
    }
  }

  // ------------------------------------------------------------ tabs
  function renderTabs() {
    document.querySelectorAll('#tabs button[data-tab]').forEach((b) => {
      b.classList.toggle('on', b.dataset.tab === state.tab);
    });
    $('paneMine').hidden = state.tab !== 'mine';
    $('paneNew').hidden = state.tab !== 'new';
    $('paneApi').hidden = state.tab !== 'api';
    $('paneAdmin').hidden = state.tab !== 'admin';
  }

  function go(tab) {
    if (tab === 'admin' && !(App.user && App.user.isAdmin)) tab = 'mine';
    state.tab = tab;
    state.openUpload = null;
    renderTabs();
    if (tab === 'mine') renderMine();
    if (tab === 'new') renderNew();
    if (tab === 'api') renderApi();
    if (tab === 'admin') renderAdmin();
  }

  App.boot(async (user) => {
    App.mountUser($('userArea'));
    App.mountBell($('bellArea'));

    const admin = !!(user && user.isAdmin);
    const adminTab = $('tabAdmin');
    if (adminTab) adminTab.hidden = !admin;

    document.querySelectorAll('#tabs button[data-tab]').forEach((b) => {
      b.onclick = () => go(b.dataset.tab);
    });

    go('mine');
  });
})();
