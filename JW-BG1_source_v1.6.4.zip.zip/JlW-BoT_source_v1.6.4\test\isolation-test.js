'use strict';
/**
 * 隔离性：机器人连接/账户异常不能影响框架与面板
 *   node test/isolation-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');

const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}
const tempDir = (p) => fs.mkdtempSync(path.join(os.tmpdir(), p));

(async () => {
  /* ---------------- Gateway：监听方抛错不影响网关 ---------------- */
  {
    const Gateway = require('../src/core/gateway');
    const logs = [];
    const logger = {
      child: () => ({ info() {}, warn() {}, error: (m) => logs.push(m), debug() {} }),
    };
    const config = { accountId: 'a1', get: (k, d) => d };
    const gw = new Gateway({ config, token: { get: async () => 't' }, logger, api: { get: async () => ({ ok: false }) } });
    gw.on('state', () => {
      throw new Error('监听方炸了');
    });
    let threw = false;
    try {
      gw._setState('online');
    } catch {
      threw = true;
    }
    check(!threw, '网关 state 事件监听抛错不会外泄');
    check(gw.state === 'online', '网关状态仍然更新');
    check(logs.some((m) => /监听方炸了/.test(m)), '异常被记录到日志');
    check(typeof gw._emitSafe === 'function', '网关统一走 _emitSafe');
    gw.disconnect();
  }

  /* ---------------- Bot：网关回调异常被 _guard 拦住 ---------------- */
  {
    const Bot = require('../src/core/bot');
    const bot = Object.create(Bot.prototype);
    bot.log = { error() {}, warn() {}, info() {}, debug() {} };
    const fn = bot._guard('state', () => {
      throw new Error('bot 回调炸了');
    });
    let threw = false;
    try {
      fn();
    } catch {
      threw = true;
    }
    check(!threw, 'Bot._guard 吞掉回调异常');

    // ready 回调里 status() 抛错，也不能炸
    const bot2 = Object.create(Bot.prototype);
    bot2.log = { error() {}, warn() {}, info() {}, debug() {} };
    bot2.gateway = new EventEmitter();
    bot2.config = { get: (k, d) => d };
    bot2.self = {};
    bot2._fetchSelf = () => Promise.resolve();
    bot2.status = () => {
      throw new Error('status 炸了');
    };
    bot2.state = 'off';
    bot2.emit = () => {};
    bot2._bindGateway();
    let threw2 = false;
    try {
      bot2.gateway.emit('ready', { user: { username: 'x' } });
    } catch {
      threw2 = true;
    }
    check(!threw2, '网关 ready 回调里 status 抛错不影响进程');

    // handleEvent 外层兜底
    const bot3 = Object.create(Bot.prototype);
    bot3.log = { error() {}, warn() {}, info() {}, debug() {} };
    bot3._handleEvent = () => {
      throw new Error('事件处理炸了');
    };
    let threw3 = false;
    try {
      bot3.handleEvent({ t: 'X', d: {} });
    } catch {
      threw3 = true;
    }
    check(!threw3, 'handleEvent 有最外层兜底');
  }

  /* ---------------- AccountsHost：转发事件抛错不影响 ---------------- */
  {
    const AccountHost = require('../src/core/accounts');
    const logs = [];
    const host = Object.create(AccountHost.prototype);
    host.logger = { error: (m) => logs.push(m) };
    host.on('event', () => {
      throw new Error('面板侧监听炸了');
    });
    let threw = false;
    try {
      host._safeEmit('event', { id: 1 });
    } catch {
      threw = true;
    }
    check(!threw, '账户事件转发有隔离');
    check(logs.some((m) => /面板侧监听炸了/.test(m)), '账户转发异常被记录');
  }

  /* ---------------- 面板：状态聚合失败仍能开 ---------------- */
  const PanelServer = require('../src/core/server');
  const port = 23200 + Math.floor(Math.random() * 300);
  const logger = {
    child: () => ({ info() {}, warn() {}, error() {}, debug() {} }),
    subscribe: () => () => {},
    recent: () => [],
  };
  const host = new EventEmitter();
  host.info = () => {
    throw new Error('账户模块坏了');
  };
  host.status = () => {
    throw new Error('账户模块坏了');
  };
  host.list = () => [];
  host.events = () => [];
  host.webhookAccount = () => null;
  const config = {
    data: {},
    get: (k, d) => (k === 'server.port' ? port : k === 'server.host' ? '127.0.0.1' : d),
    set() {},
    save() {},
    jlw: () => ({ baseUrl: '' }),
    isLoginAllowed: () => true,
    publicConfig: () => ({}),
    update: () => ({}),
  };
  const panel = new PanelServer({
    config,
    logger,
    host,
    plugins: { list: () => [], registry: new Map(), info: () => ({}) },
    endpoints: [],
    webhook: {},
    netinfo: {},
    session: { get: () => null, destroy() {} },
    jlw: {},
    updater: {},
    watchdogMs: 5000,
  });
  const base = `http://127.0.0.1:${port}`;
  await panel.start();

  const h = await fetch(base + '/health').then((r) => r.json());
  check(h.ok === true && h.pid === process.pid, 'host.info 抛错时 /health 仍正常', JSON.stringify(h));
  check(h.accounts === 0, '/health 账户数降级为 0');

  const st = panel._statusPayload();
  check(st.ok === true && st.degraded === true, '状态聚合失败时返回降级状态', JSON.stringify(st).slice(0, 120));

  const healthBad = await fetch(base + '/health').then((r) => r.status);
  check(healthBad === 200, '降级时 /health 仍 200');

  await panel.stop();
  try {
    panel.server.closeAllConnections?.();
  } catch {
    /* ignore */
  }
  await new Promise((r) => setTimeout(r, 100));

  /* ---------------- 崩溃守卫：大量异常不再主动退出 ---------------- */
  {
    const health = require('../src/core/health');
    const dir = tempDir('jlw-isolation-');
    const logs = [];
    const guard = new health.CrashGuard({
      dataDir: dir,
      version: 'test',
      maxExceptions: 5,
      windowMs: 60000,
      logger: { info() {}, warn() {}, error: (m) => logs.push(m), debug() {} },
    }).install();
    for (let i = 0; i < 12; i++) process.emit('uncaughtException', new Error('burst ' + i));
    check(process.listenerCount('uncaughtException') >= 1, '大量异常后进程仍在运行');
    const crashes = health.readCrashes(dir, 50);
    check(crashes.some((c) => c.kind === 'exceptionBurst'), '异常风暴被记录为 exceptionBurst');
    check(logs.some((m) => /进程继续运行/.test(m)), '日志说明进程继续运行');
    guard.uninstall();
    try {
      fs.rmSync(dir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
