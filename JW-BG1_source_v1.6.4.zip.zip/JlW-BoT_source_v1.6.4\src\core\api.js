'use strict';
/**
 * QQ 开放平台 HTTP API 客户端
 * - 自动带 Authorization: QQBot <access_token>
 * - token 失效自动刷新重试；429/5xx/网络错误退避重试
 * - 统一返回 { ok, status, data, code, message, duration, traceId }
 */
const { sleep } = require('./util');

const TOKEN_ERR_CODES = new Set([11241, 11242, 11243, 11244, 11245, 40001, 40014]);
const IP_WHITELIST_CODE = 11298;
const IP_WHITELIST_ERR = 40023002;

const SECRET_KEY = /token|secret|authorization|password|passwd|cookie|key/i;
const MAX_LOG_BODY = 500;

/** 请求/响应体打码 + 截断，只用于调试日志 */
function redact(value) {
  if (value === undefined || value === null) return undefined;
  let walk;
  walk = (v, depth) => {
    if (depth > 4) return '…';
    if (typeof v === 'string') return v.length > 300 ? v.slice(0, 300) + '…' : v;
    if (Array.isArray(v)) return v.slice(0, 20).map((x) => walk(x, depth + 1));
    if (v && typeof v === 'object') {
      const o = {};
      for (const [k, val] of Object.entries(v)) {
        o[k] = SECRET_KEY.test(k) ? (typeof val === 'string' && val.length > 8 ? val.slice(0, 4) + '******' : '******') : walk(val, depth + 1);
      }
      return o;
    }
    return v;
  };
  let text;
  try {
    text = JSON.stringify(walk(value, 0));
  } catch {
    text = String(value);
  }
  return text && text.length > MAX_LOG_BODY ? text.slice(0, MAX_LOG_BODY) + '…' : text;
}

function isIpWhitelistError(status, data) {
  const code = Number(data?.code);
  const errCode = Number(data?.err_code);
  const message = String(data?.message || '');
  return (
    code === IP_WHITELIST_CODE ||
    errCode === IP_WHITELIST_ERR ||
    /IP.*白名单|访问源IP|白名单/i.test(message) ||
    (status === 401 && /白名单/.test(message))
  );
}

class QQApi {
  constructor({ config, token, logger, accountId }) {
    this.config = config;
    this.token = token;
    this.accountId = accountId || config.accountId || '';
    this.log = logger.child(this.accountId ? 'api:' + this.accountId : 'api');
    this.stats = { total: 0, ok: 0, fail: 0, lastError: null };
  }

  get baseUrl() {
    return this.config.get('bot.sandbox')
      ? this.config.get('bot.apiBaseSandbox')
      : this.config.get('bot.apiBase');
  }

  /* ---------------- 接口调用日志 ---------------- */

  _logEnabled() {
    try {
      return this.config.get('log.api', true) !== false;
    } catch {
      return true;
    }
  }

  _logBody() {
    try {
      return this.config.get('log.apiBody', false) === true;
    } catch {
      return false;
    }
  }

  /**
   * 每次 QQ 接口调用都留一条：
   *   成功 → DEBUG（把日志级别调到 DEBUG 才看得到，避免刷屏）
   *   失败 → WARN（默认 info 级别就能看到）
   */
  _logCall({ method, pathStr, status, duration, attempt, traceId, ok, code, message, reqBody, resData }) {
    if (!this._logEnabled()) return;
    const ms = Number.isFinite(duration) ? duration + 'ms' : '';
    let line = `${method} ${pathStr} → ${status || 'ERR'} ${ms}`.trim();
    if (ok) {
      if (attempt > 1) line += `（第 ${attempt} 次尝试）`;
      const meta = { status, ms: duration, attempt };
      if (traceId) meta.traceId = traceId;
      if (this._logBody()) {
        if (reqBody !== undefined) meta.req = redact(reqBody);
        if (resData !== undefined) meta.res = redact(resData);
      }
      try {
        this.log.debug(line, meta);
      } catch {
        /* ignore */
      }
      return;
    }
    if (code) line += ` code=${code}`;
    if (message) line += ` ${String(message).slice(0, 160)}`;
    const meta = { status: status || 0, ms: duration, attempt };
    if (code) meta.code = code;
    if (traceId) meta.traceId = traceId;
    if (this._logBody()) {
      if (reqBody !== undefined) meta.req = redact(reqBody);
      if (resData !== undefined) meta.res = redact(resData);
    }
    try {
      this.log.warn(line, meta);
    } catch {
      /* ignore */
    }
  }

  buildUrl(pathStr, query) {
    const base = this.baseUrl.replace(/\/+$/, '');
    let url = base + (pathStr.startsWith('/') ? pathStr : '/' + pathStr);
    if (query && Object.keys(query).length) {
      const qs = new URLSearchParams();
      for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== '') qs.append(k, v);
      const s = qs.toString();
      if (s) url += (url.includes('?') ? '&' : '?') + s;
    }
    return url;
  }

  /**
   * @param {string} method
   * @param {string} pathStr 形如 /v2/groups/{group_openid}/messages
   * @param {object} opts { query, body, timeout, retry, raw, auth }
   */
  async request(method, pathStr, opts = {}) {
    const { query, body, timeout = 20000, retry = 2, raw = false } = opts;
    const url = this.buildUrl(pathStr, query);
    let attempt = 0;
    let lastResult = null;

    while (attempt <= retry) {
      attempt++;
      const t0 = Date.now();
      let token;
      try {
        token = await this.token.get(attempt > 1);
      } catch (e) {
        return this._fail(url, method, 0, 'TOKEN_ERROR', e.message, Date.now() - t0);
      }

      const headers = {
        Authorization: this.token.header(),
        'User-Agent': 'JlWBoT/1.0 (Node.js)',
        Accept: 'application/json',
      };
      let payload;
      if (body !== undefined && body !== null && method !== 'GET' && method !== 'DELETE') {
        headers['Content-Type'] = 'application/json';
        payload = typeof body === 'string' ? body : JSON.stringify(body);
      }

      try {
        const res = await fetch(url, {
          method,
          headers,
          body: payload,
          signal: AbortSignal.timeout(timeout),
        });
        const text = await res.text();
        const duration = Date.now() - t0;
        let data = null;
        if (text) {
          try {
            data = JSON.parse(text);
          } catch {
            data = { raw: text };
          }
        }
        const traceId = res.headers.get('x-tps-trace-id') || undefined;
        this.stats.total++;

        if (res.ok && !(data && data.code && data.code !== 0 && !data.id && !data.url)) {
          this.stats.ok++;
          this._logCall({
            method,
            pathStr,
            status: res.status,
            duration,
            attempt,
            traceId,
            ok: true,
            reqBody: body,
            resData: data,
          });
          return { ok: true, status: res.status, data: data ?? {}, duration, traceId };
        }

        // IP 白名单：刷新 token 没有意义，必须由用户到开放平台加白名单
        const code = data?.code;
        if (isIpWhitelistError(res.status, data)) {
          this.stats.fail++;
          const result = this._fail(
            url,
            method,
            res.status,
            code || IP_WHITELIST_CODE,
            data?.message || '接口访问源 IP 不在白名单',
            duration,
            traceId,
            data,
          );
          result.fatal = true;
          result.hint = '当前公网 IP 不在 QQ 机器人 IP 白名单。请到 QQ 开放平台为该机器人添加当前公网 IP，或关闭 IP 白名单后点「重连」。';
          this.stats.lastError = { at: Date.now(), message: result.message, code: result.code };
          this.log.error('接口 IP 白名单拦截：' + result.message);
          this._logCall({
            method,
            pathStr,
            status: res.status,
            duration,
            attempt,
            traceId,
            ok: false,
            code: result.code,
            message: result.message,
            reqBody: body,
            resData: data,
          });
          return result;
        }

        // token 失效 → 刷新后重试一次
        if ((res.status === 401 || TOKEN_ERR_CODES.has(code)) && attempt <= retry) {
          this.log.warn(`token 失效，刷新后重试 (${code || res.status})`);
          this.token.invalidate();
          continue;
        }
        // 限流
        if (res.status === 429 || code === 100001) {
          const wait = Number(data?.retry_after ?? res.headers.get('retry-after') ?? 1) * 1000 || 1000;
          if (attempt <= retry) {
            this.log.warn(`触发限流，${wait}ms 后重试`);
            await sleep(Math.min(wait, 10000));
            continue;
          }
        }
        // 5xx / 网络
        if (res.status >= 500 && attempt <= retry) {
          await sleep(300 * attempt * attempt);
          continue;
        }

        this.stats.fail++;
        const result = this._fail(
          url,
          method,
          res.status,
          code || ('HTTP_' + res.status),
          data?.message || res.statusText,
          duration,
          traceId,
          data,
        );
        this.stats.lastError = { at: Date.now(), message: result.message, code: result.code };
        this._logCall({
          method,
          pathStr,
          status: res.status,
          duration,
          attempt,
          traceId,
          ok: false,
          code: result.code,
          message: result.message,
          reqBody: body,
          resData: data,
        });
        return result;
      } catch (e) {
        const duration = Date.now() - t0;
        const isTimeout = e.name === 'TimeoutError' || e.name === 'AbortError';
        if (attempt <= retry) {
          await sleep(300 * attempt);
          continue;
        }
        this.stats.fail++;
        lastResult = this._fail(url, method, 0, isTimeout ? 'TIMEOUT' : 'NETWORK_ERROR', e.message, duration);
        this.stats.lastError = { at: Date.now(), message: lastResult.message, code: lastResult.code };
        this._logCall({
          method,
          pathStr,
          status: 0,
          duration,
          attempt,
          ok: false,
          code: isTimeout ? 'TIMEOUT' : 'NETWORK_ERROR',
          message: e.message,
          reqBody: body,
        });
        return lastResult;
      }
    }
    return lastResult || this._fail(url, method, 0, 'UNKNOWN', '请求失败');
  }

  _fail(url, method, status, code, message, duration, traceId, data) {
    return { ok: false, status, code, message, duration, traceId, data: data ?? null, error: true };
  }

  get(pathStr, opts) {
    return this.request('GET', pathStr, opts);
  }
  post(pathStr, body, opts = {}) {
    return this.request('POST', pathStr, { ...opts, body });
  }
  put(pathStr, body, opts = {}) {
    return this.request('PUT', pathStr, { ...opts, body });
  }
  patch(pathStr, body, opts = {}) {
    return this.request('PATCH', pathStr, { ...opts, body });
  }
  del(pathStr, opts = {}) {
    return this.request('DELETE', pathStr, opts);
  }

  /** 上传二进制到预签名 URL（分片上传用） */
  async putBinary(url, buffer, { timeout = 60000 } = {}) {
    const t0 = Date.now();
    try {
      const res = await fetch(url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: buffer,
        signal: AbortSignal.timeout(timeout),
      });
      const text = await res.text().catch(() => '');
      const duration = Date.now() - t0;
      if (this._logEnabled()) {
        const line = `PUT <presigned> → ${res.status} ${duration}ms ${buffer.length}B`;
        if (res.ok) this.log.debug(line);
        else this.log.warn(line);
      }
      return { ok: res.ok, status: res.status, data: text, duration };
    } catch (e) {
      const duration = Date.now() - t0;
      if (this._logEnabled()) this.log.warn(`PUT <presigned> → ERR ${duration}ms ${e.message}`);
      return { ok: false, status: 0, message: e.message, duration };
    }
  }
}

module.exports = QQApi;
module.exports.isIpWhitelistError = isIpWhitelistError;
