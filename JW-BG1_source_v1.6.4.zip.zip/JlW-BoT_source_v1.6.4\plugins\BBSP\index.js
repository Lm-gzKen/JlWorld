'use strict';
/**
 * BBSP · 积木编程（JlWBoT 插件，内置设置页模式）
 *
 * 全部 UI 在插件的 settings.html 里（面板 → 插件 → BBSP → 编辑 → 设置 / 设置页右上角「新页面」）。
 *   - 设置页跑在面板沙箱 iframe 里，不能联网、不能写文件；
 *   - 所以项目/DLL 组件库存在 plugin.json 的 config 里（设置页 postMessage 保存）；
 *   - DLL 二进制以 base64 传一次，插件 onLoad 时落盘到 data/dlls/ 后立刻从 config 删掉；
 *   - 导出/安装也走 config 的 pending 动作，由 onLoad 同步写文件（面板可能映射到外网，不能依赖 127.0.0.1）。
 *
 * 对外 API（生成的 JS 插件就是用它调 DLL）：
 *   const bbsp = globalThis.__JLWBOT_PLUGIN_APIS__?.get('BBSP');
 *   await bbsp.invokeDll('dll_xxx', 'Add', [{ type: 'int', value: 1 }], { ret: 'int' });
 *   bbsp.info()
 */

const path = require('node:path');

const { Store } = require('./lib/store');
const { DllBridge } = require('./lib/dll-bridge');
const CFG = require('./lib/config');
const manifest = require('./plugin.json');

const PKG_VERSION = manifest.version;
const API_KEY = 'BBSP';

let runtime = null;

/* ======================= 生命周期 ======================= */

async function onLoad(ctx) {
  if (runtime) unloadSync();
  const dir = ctx.plugin.dir;
  const log = ctx.log;
  const dataDir = (ctx.framework && ctx.framework.dataDir) || '';
  const pluginsDir = dataDir ? path.join(dataDir, 'plugins') : '';

  const { config: initialConfig, warnings: initialWarnings } = CFG.normalizeConfig(ctx.plugin.config);
  let config = initialConfig;
  let warnings = initialWarnings;
  const store = new Store({ dir, log });
  const bridge = new DllBridge({ dir, log, timeoutMs: config.settings.dllTimeoutMs });

  // plugin.json 被覆盖成默认值时，从 data/state.json 恢复（保护升级/手工覆盖）
  let restored = false;
  const fresh = !(config.projects || []).length && !(config.dlls || []).length && !config.pending && !config.lastExport;
  if (fresh) {
    const side = store.readState();
    if (side && ((side.projects || []).length || (side.dlls || []).length)) {
      const merged = CFG.normalizeConfig({
        version: config.version,
        settings: side.settings || config.settings,
        projects: side.projects || [],
        activeProjectId: side.activeProjectId || '',
        dlls: side.dlls || [],
        pending: null,
        lastExport: side.lastExport || null,
      });
      config = merged.config;
      warnings = warnings.concat(['已从 data/state.json 恢复项目/DLL 配置']).concat(merged.warnings);
      restored = true;
    }
  }

  // 1.1.x 旧数据（data/projects、data/dlls/index.json）并进 config
  const legacy = store.migrateLegacy(config);
  if (legacy.changed) {
    const again = CFG.normalizeConfig(config);
    config = again.config;
    warnings = warnings.concat(again.warnings);
  }

  // 同步完成落盘与 pending，避免和面板写 plugin.json 抢时序
  const dllResult = store.applyDlls(config);
  const pendingResult = store.applyPending(config, { pluginsDir });
  store.writeState(config);
  if (dllResult.changed || pendingResult.changed || legacy.changed || restored || warnings.length) {
    try {
      store.writeManifestConfig(config, warnings);
    } catch (e) {
      log.warn('BBSP 回写 plugin.json 失败（下次保存设置会覆盖）：' + e.message);
    }
  }

  runtime = { ctx, dir, config, store, bridge, log, startedAt: Date.now() };
  bindApi(createApi());

  if (config.settings.dllTimeoutMs && config.dlls.length) {
    bridge.ensureBinaries().catch((e) => log.warn('BBSP DLL 宿主不可用：' + e.message));
  }

  if (warnings.length) log.warn('BBSP 配置提示：' + warnings.join('；'));
  const last = config.lastExport;
  log.info(
    `BBSP 已加载（内置设置页模式）：项目 ${config.projects.length} 个，DLL ${config.dlls.length} 个` +
      (dllResult.materialized.length ? `，新落盘 DLL ${dllResult.materialized.length} 个` : '') +
      (last ? `；上次${last.action === 'install' ? '安装' : '导出'}：${last.id}${last.error ? '（失败：' + last.error + '）' : ''}` : ''),
  );
}

function unloadSync() {
  unbindApi();
  try {
    if (runtime && runtime.bridge) runtime.bridge.dispose();
  } catch {
    /* ignore */
  }
  runtime = null;
}

async function onUnload() {
  unloadSync();
}

/* ======================= 对外 API ======================= */

function createApi() {
  const api = {
    pluginId: API_KEY,
    version: PKG_VERSION,

    isReady() {
      return !!runtime;
    },

    /** 状态：项目/DLL 数量、上次导出、数据目录 */
    info() {
      if (!runtime) return { ready: false };
      return {
        ready: true,
        version: PKG_VERSION,
        projects: runtime.config.projects.length,
        dlls: runtime.config.dlls.map((d) => ({ id: d.id, alias: d.alias || d.name, arch: d.arch, exports: (d.exports || []).length })),
        lastExport: runtime.config.lastExport || null,
        dirs: { data: runtime.store.dataDir, dlls: runtime.store.dllsDir, exports: runtime.store.exportsDir },
        dllHosts: runtime.bridge.status(),
      };
    },

    dllLibrary() {
      return runtime ? CFG.dllLibrary(runtime.config) : { items: [] };
    },

    /**
     * 调 DLL 的公开入口（生成的 JS 插件就用它）。
     * @param {string} dllRef DLL id（也接受别名 / 文件名）
     * @param {string} fn 导出函数名
     * @param {Array} args [{type:'int'|'text_ansi'|..., value}]；也接受裸值（按 DLL 里登记的参数类型补）
     * @param {{ret?:string, conv?:'stdcall'|'cdecl'}} [opts]
     */
    async invokeDll(dllRef, fn, args, opts = {}) {
      if (!runtime) throw new Error('【[404 error] BBSP 插件未加载】');
      const { bridge, store, config } = runtime;
      const dll = resolveDll(config, dllRef);
      if (!dll) throw new Error('【[404 error] BBSP 组件库里没有这个 DLL：' + String(dllRef || '') + '】');
      const file = store.dllPath(dll.id);
      const ex = (dll.exports || []).find((e) => (e.clean || e.name) === fn || e.name === fn);
      const types = ex && Array.isArray(ex.params) ? ex.params : [];
      const normArgs = (Array.isArray(args) ? args : []).map((a, i) => {
        if (a && typeof a === 'object' && a.type) return { type: a.type, value: a.value };
        return { type: types[i] || 'int', value: a };
      });
      const r = await bridge.call({
        dll: file,
        fn,
        conv: opts.conv || (ex && ex.conv) || (dll.arch === 'x86' ? 'stdcall' : 'cdecl'),
        ret: opts.ret || (ex && ex.ret) || 'int',
        args: normArgs,
        arch: dll.arch === 'x64' ? 'x64' : 'x86',
      });
      if (!r.ok) {
        throw new Error('【[404 error] DLL「' + (dll.alias || dll.name) + '」调用 ' + fn + ' 失败：' + r.error + '】');
      }
      return r.value;
    },

    async pingHost(arch = 'x86') {
      if (!runtime) throw new Error('BBSP 未加载');
      return runtime.bridge.ping(arch);
    },
  };
  return api;
}

function resolveDll(config, ref) {
  const key = String(ref || '');
  if (!key) return null;
  const list = (config && config.dlls) || [];
  return (
    list.find((d) => d.id === key) ||
    list.find((d) => d.alias === key) ||
    list.find((d) => d.name === key) ||
    list.find((d) => d.id + '.dll' === key) ||
    null
  );
}

function bindApi(api) {
  try {
    const g = globalThis;
    if (!(g.__JLWBOT_PLUGIN_APIS__ instanceof Map)) g.__JLWBOT_PLUGIN_APIS__ = new Map();
    g.__JLWBOT_PLUGIN_APIS__.set(API_KEY, api);
  } catch {
    /* ignore */
  }
}

function unbindApi() {
  try {
    if (globalThis.__JLWBOT_PLUGIN_APIS__ && globalThis.__JLWBOT_PLUGIN_APIS__.get(API_KEY)) {
      globalThis.__JLWBOT_PLUGIN_APIS__.delete(API_KEY);
    }
  } catch {
    /* ignore */
  }
}

/* ======================= 消息指令 ======================= */

async function onEvent(ctx) {
  const message = ctx.message;
  if (!message) return null;
  const cmd = String((message.command && message.command.name) || '').replace(/^\//, '');
  if (cmd !== 'bbsp') return null;

  const counts = runtime
    ? `项目 ${runtime.config.projects.length} 个 · DLL ${runtime.config.dlls.length} 个`
    : '插件未就绪，看面板日志';
  return {
    reply: [
      '【BBSP】积木编程工作台（面板内置页）',
      '打开：面板 → 插件 → BBSP →「编辑 → 设置」，或插件卡片上的设置页「新页面」。',
      '工作台就在面板网页里，不需要本机端口；面板映射到外网时也能用。',
      counts,
    ].join('\n'),
  };
}

module.exports = { onLoad, onUnload, onEvent };
