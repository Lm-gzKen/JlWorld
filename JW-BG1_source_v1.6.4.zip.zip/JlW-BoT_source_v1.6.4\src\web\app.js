'use strict';
/* JlWBoT 控制台前端（多账户）—— 无构建、无外部依赖 */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const esc = (s) =>
    String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const TITLES = {
    dashboard: ['概览', '多账户运行状态与实时动态'],
    accounts: ['账户', 'QQ 机器人账户池：接入、切换与凭证'],
    connection: ['连接', '当前账户的 WebSocket / WebHook 接入'],
    plugins: ['插件', 'JS / HTTP / 拉取 / 进程 / 易语言 DLL'],
    market: ['市场', '浏览与下载 VloSBoT 插件'],
    messages: ['消息', '实时收发事件与消息明细'],
    logs: ['日志', '框架运行日志实时查看'],
    api: ['接口', 'QQ 机器人 API v2 全量调试'],
    settings: ['设置', '面板、插件与存储的全局配置'],
  };

  const state = {
    loggedIn: false,
    page: 'dashboard',
    status: null,
    accounts: [],
    accountId: localStorage.getItem('jlw-account') || '',
    plugins: [],
    events: [],
    logs: [],
    endpoints: [],
    groups: [],
    intents: [],
    intentTab: '',
    pluginToken: '',
    pluginApiBase: '/plugin-api/v1',
    pluginNotice: null,
    modalPersistent: false,
    settingsPluginId: null,
    ws: null,
    wsOk: false,
    paused: false,
    logLevel: '',
    logQuery: '',
    logDate: '',
    msgFilter: 'all',
    msgQuery: '',
    msgAccount: '',
    msgDate: '',
    msgGroup: '',
    msgGroupAccount: '',
    msgGroupName: '',
    groupNames: {},
    apiGroup: '全部',
    apiQuery: '',
    ip: null,
    ipLoading: false,
    user: null,
    update: null,
    updateAt: 0,
    updating: false,
    authScope: null,
    authScopeLoading: false,
  };

  /* ================= 基础工具 ================= */

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      credentials: 'same-origin',
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* ignore */
    }
    if (res.status === 401) {
      showLogin();
      throw new Error(data?.error || '登录已失效');
    }
    if (!res.ok || data?.ok === false) throw new Error(data?.error || data?.message || 'HTTP ' + res.status);
    return data;
  }

  function toast(msg, type = '') {
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.textContent = msg;
    $('#toast').appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(6px)';
      el.style.transition = '0.2s';
      setTimeout(() => el.remove(), 220);
    }, 3200);
  }

  async function copyText(text, label = '已复制') {
    try {
      await navigator.clipboard.writeText(text);
      toast(label, 'ok');
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        toast(label, 'ok');
      } catch {
        toast('复制失败，请手动选择', 'err');
      }
      ta.remove();
    }
  }

  const fmtTime = (ts) => {
    if (!ts) return '—';
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, '0');
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  };
  const fmtDateTime = (ts) => {
    if (!ts) return '—';
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  };
  const fmtDur = (ms) => {
    if (!ms || ms < 0) return '—';
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    if (d) return `${d} 天 ${h} 小时`;
    if (h) return `${h} 小时 ${m} 分`;
    if (m) return `${m} 分 ${ss} 秒`;
    return `${ss} 秒`;
  };
  const fmtNum = (n) => Number(n || 0).toLocaleString('zh-CN');
  const fmtBytes = (n) => {
    const v = Number(n || 0);
    if (v >= 1024 * 1024) return (v / 1024 / 1024).toFixed(1) + ' MB';
    if (v >= 1024) return (v / 1024).toFixed(1) + ' KB';
    return v + ' B';
  };
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

  function connMeta(s) {
    const map = {
      online: ['已连接', 'ok'],
      webhook: ['WebHook 监听中', 'ok'],
      connecting: ['连接中', 'warn'],
      identifying: ['鉴权中', 'warn'],
      resuming: ['恢复会话', 'warn'],
      reconnecting: ['重连中', 'warn'],
      cooldown: ['冷却中', 'warn'],
      starting: ['启动中', 'warn'],
      unconfigured: ['未配置', 'warn'],
      fatal: ['致命错误', 'err'],
      error: ['异常', 'err'],
      off: ['已停止', ''],
      closed: ['已停止', ''],
      idle: ['未连接', ''],
    };
    return map[s] || [s || '未知', ''];
  }

  function kindMeta(kind) {
    const map = {
      group: ['群聊', 'info'],
      c2c: ['单聊', 'violet'],
      channel: ['频道', 'ok'],
      dm: ['私信', 'warn'],
      other: ['事件', ''],
    };
    return map[kind] || ['事件', ''];
  }

  const METHOD_ORDER = { GET: 0, POST: 1, PUT: 2, PATCH: 3, DELETE: 4 };

  function activeAccount() {
    return state.accounts.find((a) => a.id === state.accountId) || state.accounts[0] || null;
  }

  function accountName(id) {
    const a = state.accounts.find((x) => x.id === id);
    return a ? a.name : id ? id.slice(0, 8) : '—';
  }

  /** 群/私聊用户头像：https://q.qlogo.cn/qqapp/{appid}/{openid}/0 */
  function profileAvatarUrl(evt) {
    const msg = evt?.message;
    if (!msg) return '';
    const acc = state.accounts.find((a) => a.id === evt.accountId);
    const appId = acc?.appId;
    const author = msg.author || {};
    const openid = author.member_openid || author.user_openid || author.id;
    if (!appId || !openid) return '';
    return `https://q.qlogo.cn/qqapp/${encodeURIComponent(appId)}/${encodeURIComponent(openid)}/0`;
  }

  function avatarHtml(evt, size = 34) {
    const url = profileAvatarUrl(evt);
    const initial = esc((evt?.message?.author?.username || '?').slice(0, 1));
    const style = `width:${size}px;height:${size}px;font-size:${Math.max(10, Math.round(size * 0.42))}px`;
    if (!url) return `<div class="avatar" style="${style}">${initial}</div>`;
    return `<div class="avatar" style="${style}"><img src="${esc(url)}" alt="" data-initial="${initial}" referrerpolicy="no-referrer" loading="lazy" /></div>`;
  }

  function accountAvatarHtml(acc, size = 24) {
    const initial = esc((acc?.self?.username || acc?.name || '?').slice(0, 1));
    const url = acc?.self?.avatar;
    const style = `width:${size}px;height:${size}px;font-size:${Math.max(10, Math.round(size * 0.42))}px`;
    return `<div class="avatar" style="${style}">${url ? `<img src="${esc(url)}" alt="" data-initial="${initial}" referrerpolicy="no-referrer" loading="lazy" />` : initial}</div>`;
  }

  const PAGES = {
    dashboard: pageDashboard,
    accounts: pageAccounts,
    connection: pageConnection,
    plugins: pagePlugins,
    market: pageMarket,
    messages: pageMessages,
    logs: pageLogs,
    api: pageApi,
    settings: pageSettings,
  };

  /* ================= 登录 ================= */

  function showLogin() {
    state.loggedIn = false;
    state.authScope = null;
    state.update = null;
    document.body.classList.remove('logged-in');
    $('#login').classList.remove('hidden');
    $('#app').classList.add('hidden');
    const el = $('#login-email');
    if (el) setTimeout(() => el.focus(), 60);
  }

  async function checkSession() {
    try {
      const r = await fetch('/api/session', { credentials: 'same-origin' });
      const data = await r.json();
      if (data.loggedIn) {
        state.user = data.user || null;
        await showApp();
      } else {
        showLogin();
      }
    } catch {
      showLogin();
    }
  }

  async function showApp() {
    state.loggedIn = true;
    document.body.classList.add('logged-in');
    $('#login').classList.add('hidden');
    $('#app').classList.remove('hidden');
    renderChrome();
    connectWS();
    await refreshAll();
    await loadAuthScope(true);
    render();
    refreshIp();
    checkUpdate(false);
  }

  /* ================= 数据刷新 ================= */

  function applyStatus(payload) {
    if (!payload) return;
    state.status = payload;
    state.accounts = payload.accounts || [];
    if (!state.accounts.some((a) => a.id === state.accountId)) {
      state.accountId = payload.activeId || state.accounts[0]?.id || '';
      if (state.accountId) localStorage.setItem('jlw-account', state.accountId);
    }
    renderAccountSelect();
  }

  async function refreshAll() {
    try {
      const [status, plugins, endpoints, logs] = await Promise.all([
        api('/api/status'),
        api('/api/plugins'),
        api('/api/endpoints'),
        api('/api/logs?limit=400'),
      ]);
      applyStatus(status);
      state.plugins = plugins.plugins || [];
      state.endpoints = endpoints.endpoints || [];
      state.groups = endpoints.groups || [];
      state.intents = endpoints.intents || [];
      state.pluginToken = endpoints.pluginToken || '';
      state.pluginApiBase = endpoints.pluginApiBase || '/plugin-api/v1';
      state.logs = logs.logs || [];
      await refreshEvents();
      renderChrome();
      render();
    } catch (e) {
      toast(e.message, 'err');
    }
  }

  async function refreshStatus() {
    try {
      applyStatus(await api('/api/status'));
      renderChrome();
      if (['dashboard', 'connection', 'accounts'].includes(state.page)) render();
    } catch {
      /* ignore */
    }
  }

  async function refreshPlugins() {
    const r = await api('/api/plugins');
    state.plugins = r.plugins || [];
    renderChrome();
    if (state.page === 'plugins' || state.page === 'dashboard') render();
  }

  async function refreshEvents() {
    const parts = ['limit=' + (state.msgDate ? '2000' : '300')];
    if (state.msgDate) parts.push('date=' + encodeURIComponent(state.msgDate));
    if (state.msgAccount) parts.push('account=' + encodeURIComponent(state.msgAccount));
    const r = await api('/api/events?' + parts.join('&'));
    state.events = r.events || [];
  }

  /** 切到某一天的消息（空 = 今天/实时） */
  async function loadEventsDate(day) {
    state.msgDate = String(day || '');
    try {
      await refreshEvents();
    } catch (e) {
      toast('读取消息失败：' + e.message, 'err');
      state.events = [];
    }
    if (state.page === 'messages') render();
  }

  async function refreshIp(force = false) {
    if (state.ipLoading) return;
    state.ipLoading = true;
    renderIpPill();
    try {
      const r = force ? await api('/api/netinfo/refresh', { method: 'POST', body: {} }) : await api('/api/netinfo');
      state.ip = r;
    } catch (e) {
      state.ip = { ip: '', error: e.message };
    } finally {
      state.ipLoading = false;
      renderIpPill();
    }
  }

  /* ================= 在线更新 ================= */

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  function renderUpdatePill() {
    const btn = $('#update-pill');
    if (!btn) return;
    const info = state.update;
    if (!info || !info.hasUpdate || state.updating) {
      btn.classList.add('hidden');
      return;
    }
    btn.classList.remove('hidden');
    const ver = $('#update-pill-version');
    if (ver) ver.textContent = `v${info.latest} · 当前 v${info.current}`;
    btn.title = `发现新版本 v${info.latest}，点击下载并自动更新`;
  }

  async function checkUpdate(force = false, manual = false) {
    if (!state.loggedIn || state.updating) return null;
    try {
      const info = await api('/api/update/check' + (force ? '?force=1' : ''));
      if (info && info.ok) {
        state.update = info;
        state.updateAt = Date.now();
        renderUpdatePill();
        renderUpdateCard();
        if (manual) {
          if (info.enabled === false) {
            toast('在线更新已在配置中关闭', 'warn');
          } else if (info.hasUpdate) {
            toast(`发现新版本 v${info.latest}（当前 v${info.current}）`, 'ok');
            openUpdateModal();
          } else {
            const tail = info.latest && info.latest !== info.current ? `（更新页最新 v${info.latest}，不高于本机）` : '';
            toast(`已是最新版本 v${info.current || ''}${tail}`, 'ok');
          }
        }
      } else if (manual) {
        toast('检查更新失败：' + ((info && info.error) || '未知错误'), 'err');
      }
      return info;
    } catch (e) {
      if (manual) toast('检查更新失败：' + e.message, 'err');
      return null;
    }
  }

  /** 设置页「版本与更新」卡片：检查完就地更新，不重渲染整页（避免丢未保存的输入） */
  function renderUpdateCard() {
    const info = state.update;
    const badge = $('#upd-badge');
    if (badge) {
      if (!info) {
        badge.textContent = '未检查';
        badge.className = 'badge';
      } else if (info.hasUpdate) {
        badge.textContent = '可更新 v' + info.latest;
        badge.className = 'badge warn';
      } else {
        badge.textContent = '已是最新';
        badge.className = 'badge ok';
      }
    }
    const cur = $('#upd-current');
    if (cur) cur.textContent = 'v' + ((state.status && state.status.version) || '—');
    const latest = $('#upd-latest');
    if (latest) latest.textContent = info && info.latest ? 'v' + info.latest : '—';
    const at = $('#upd-checked');
    if (at) at.textContent = state.updateAt ? fmtDateTime(state.updateAt) : '—';
    const run = $('[data-act="update-run"]');
    if (run) run.disabled = !(info && info.hasUpdate);
  }

  function openUpdateModal() {
    const info = state.update;
    if (!info || !info.hasUpdate) return toast('当前已是最新版本', 'ok');
    const size = info.sizeText ? `更新包约 ${esc(info.sizeText)}` : '更新包大小以页面为准';
    const notes = info.notes ? `<p class="update-notes">${esc(info.notes)}</p>` : '';
    openModal(
      `发现新版本 v${info.latest}`,
      `<div class="update-modal">
        <div class="update-version-row">
          <span>当前版本 <b>v${esc(info.current)}</b></span>
          <span class="update-version-arrow">→</span>
          <span>最新版本 <b class="update-ok">v${esc(info.latest)}</b></span>
        </div>
        <p class="item-sub">${size} · 来源 <a href="${esc(info.pageUrl)}" target="_blank" rel="noopener">聚龙世界 QQBOT</a></p>
        ${notes}
        <p class="update-warning">下载完成后机器人会自动重启，期间会短暂离线；账户、插件和 <code>~JlWBoT</code> 数据会保留。</p>
      </div>`,
      `<button class="btn" data-close="modal">稍后</button><button class="btn btn-primary" data-act="update-run">下载并重启</button>`,
    );
  }

  function setUpdateOverlay(opts = {}) {
    const box = $('#update-overlay');
    if (!box) return;
    box.classList.remove('hidden');
    const title = $('#update-overlay-title');
    const text = $('#update-overlay-text');
    const hint = $('#update-overlay-hint');
    const bar = $('#update-bar-fill');
    const spinner = $('#update-spinner');
    const close = $('#update-overlay-close');
    if (title) title.textContent = opts.title || '正在更新';
    if (text) text.textContent = opts.text || '';
    if (hint) hint.textContent = opts.hint || '';
    if (bar) bar.style.width = `${clamp(Number(opts.percent) || 0, 0, 100)}%`;
    if (spinner) spinner.style.display = opts.spinner === false ? 'none' : 'block';
    if (close) close.classList.toggle('hidden', !opts.closable);
  }

  function hideUpdateOverlay() {
    state.updating = false;
    const box = $('#update-overlay');
    if (box) box.classList.add('hidden');
    renderUpdatePill();
  }

  async function waitForRestart(info) {
    const deadline = Date.now() + 120000;
    while (Date.now() < deadline) {
      try {
        const r = await fetch('/health?t=' + Date.now(), { cache: 'no-store', credentials: 'same-origin' });
        const j = await r.json();
        if (j && j.ok && String(j.version) === String(info.latest)) {
          setUpdateOverlay({
            title: '更新完成',
            text: `已升级到 v${info.latest}，正在重新加载面板…`,
            hint: '',
            percent: 100,
            spinner: false,
          });
          setTimeout(() => location.reload(), 900);
          return;
        }
      } catch {
        /* 重启期间服务会短暂不可用 */
      }
      await wait(1000);
    }
    state.updating = false;
    renderUpdatePill();
    setUpdateOverlay({
      title: '重启超时',
      text: '没有检测到新版本面板',
      hint: '请手动运行 启动机器人.cmd，或查看 ~JlWBoT/updates/update.log',
      percent: 100,
      spinner: false,
      closable: true,
    });
  }

  async function pollUpdateProgress(info) {
    const deadline = Date.now() + 10 * 60 * 1000;
    while (Date.now() < deadline) {
      let p;
      try {
        p = await fetch('/api/update/progress', { cache: 'no-store', credentials: 'same-origin' }).then((r) => r.json());
      } catch {
        await waitForRestart(info);
        return;
      }
      if (p?.phase === 'error') {
        state.updating = false;
        renderUpdatePill();
        setUpdateOverlay({
          title: '更新失败',
          text: p.error || '下载或安装更新包失败',
          hint: '可以稍后重试，或查看 ~JlWBoT/updates/update.log',
          spinner: false,
          closable: true,
        });
        return;
      }
      if (p?.phase === 'restarting') {
        setUpdateOverlay({
          title: '正在重启',
          text: '更新包已下载，正在关闭旧进程并安装…',
          hint: '页面会自动恢复，不需要手动刷新',
          percent: 100,
        });
        await waitForRestart(info);
        return;
      }
      if (p?.phase === 'preparing') {
        setUpdateOverlay({
          title: '正在校验更新包',
          text: '正在解压并检查新版本文件…',
          hint: '校验通过后会自动重启',
          percent: 100,
        });
        await wait(500);
        continue;
      }
      if (p?.phase === 'ready') {
        state.updating = false;
        renderUpdatePill();
        setUpdateOverlay({
          title: '更新已就绪',
          text: p.message || '请手动重启机器人完成更新',
          hint: '重启后会自动使用新版本',
          percent: 100,
          spinner: false,
          closable: true,
        });
        return;
      }
      const pct = Number(p?.percent) || 0;
      const done = Number(p?.received) || 0;
      const total = Number(p?.total) || 0;
      const size = done ? ` ${(done / 1048576).toFixed(1)}${total ? ' / ' + (total / 1048576).toFixed(1) : ''} MB` : '';
      setUpdateOverlay({
        title: `正在下载 v${info.latest}`,
        text: `正在下载更新包${size}`,
        hint: '下载完成后会自动重启，请保持页面打开',
        percent: pct,
      });
      await wait(600);
    }
    state.updating = false;
    renderUpdatePill();
    setUpdateOverlay({
      title: '更新超时',
      text: '下载时间超过 10 分钟',
      hint: '请检查网络后重试，或到更新页手动下载',
      spinner: false,
      closable: true,
    });
  }

  async function startUpdate() {
    const info = state.update;
    if (!info || !info.hasUpdate || state.updating) return;
    closeAll();
    state.updating = true;
    renderUpdatePill();
    setUpdateOverlay({
      title: '正在更新',
      text: `正在连接更新服务器，准备下载 v${info.latest}…`,
      hint: '下载完成后机器人会自动重启',
      percent: 0,
    });
    try {
      await api('/api/update/start', { method: 'POST', body: { version: info.latest } });
      await pollUpdateProgress(info);
    } catch (e) {
      state.updating = false;
      renderUpdatePill();
      setUpdateOverlay({
        title: '更新失败',
        text: e.message,
        hint: '可以稍后重试，或到更新页手动下载',
        spinner: false,
        closable: true,
      });
    }
  }

  /* ================= 登录范围 ================= */

  function renderLoginScopePill() {
    const btn = $('#login-scope-pill');
    const label = $('#login-scope-count');
    if (!label) return;
    const count = state.authScope?.count;
    label.textContent = count === undefined || count === null ? '—' : count === 0 ? '未设置' : `${count} 个账户`;
    if (btn) btn.title = count ? `允许登录的聚龙账户：${count} 个；点击管理` : '还没有允许登录的聚龙账户';
  }

  async function loadAuthScope(force = false) {
    if (state.authScopeLoading) return state.authScope;
    if (state.authScope && !force) {
      renderLoginScopePill();
      return state.authScope;
    }
    state.authScopeLoading = true;
    try {
      const r = await api('/api/auth/scope');
      state.authScope = r;
      renderLoginScopePill();
      if (r.count <= 1 && !localStorage.getItem('jlw-scope-hinted')) {
        localStorage.setItem('jlw-scope-hinted', '1');
        toast('可在左下角【登录范围】添加更多聚龙账户', 'ok');
      }
      return r;
    } catch {
      /* 登录范围读取失败不阻塞面板 */
      return null;
    } finally {
      state.authScopeLoading = false;
    }
  }

  function scopeMatchesCurrent(a) {
    const u = state.user;
    if (!a || !u) return false;
    const email = String(a.email || '').toLowerCase();
    const id = String(a.id || '');
    return (email && email === String(u.email || '').toLowerCase()) || (id && id === String(u.id || ''));
  }

  async function openLoginScopeModal() {
    const info = (await loadAuthScope(true)) || state.authScope;
    if (!info) return toast('读取登录范围失败', 'err');
    const rows = (info.allowed || [])
      .map((a) => {
        const title = a.name || a.email || a.id || '未命名账户';
        const sub = [a.email, a.id].filter(Boolean).join(' · ') || '无邮箱';
        const self = scopeMatchesCurrent(a) ? '<span class="scope-self">当前账户</span>' : '';
        const key = encodeURIComponent(a.email || a.id || '');
        return `<div class="scope-row">
          <span class="scope-avatar">${esc(title.slice(0, 1))}</span>
          <span class="scope-main"><b>${esc(title)}</b><small>${esc(sub)}</small></span>
          ${self}
          <button class="btn btn-sm btn-danger" data-act="scope-remove" data-key="${key}" ${info.count <= 1 ? 'disabled title="至少保留一个账户"' : ''}>移除</button>
        </div>`;
      })
      .join('');
    openModal(
      '登录范围',
      `<p class="item-sub" style="margin-top:0">只有列表中的聚龙账户可以登录控制台；未添加的账户即使密码正确也会被拒绝。</p>
      <div class="scope-list">${rows || '<div class="scope-empty">还没有允许登录的账户</div>'}</div>
      <div class="scope-add">
        <input id="scope-email" type="email" placeholder="聚龙账户邮箱，例如 user@example.com" autocomplete="off" />
        <button class="btn btn-primary btn-sm" data-act="scope-add">添加账户</button>
      </div>
      <p class="scope-warning">至少保留一个账户；移除后该账户立即无法登录，已登录的会话会在下一次请求时失效。新增账户需要先有聚龙世界账户。</p>`,
      '<button class="btn" data-close="modal">关闭</button>',
    );
  }

  /* ================= WebSocket ================= */

  function connectWS() {
    if (state.ws) {
      try {
        state.ws.close();
      } catch {
        /* ignore */
      }
    }
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    let ws;
    try {
      ws = new WebSocket(`${proto}://${location.host}/ws`);
    } catch {
      return;
    }
    state.ws = ws;
    ws.onopen = () => {
      state.wsOk = true;
      renderWsPill();
    };
    ws.onclose = () => {
      state.wsOk = false;
      renderWsPill();
      if (state.loggedIn) setTimeout(connectWS, 3000);
    };
    ws.onerror = () => {
      state.wsOk = false;
      renderWsPill();
    };
    ws.onmessage = (e) => {
      let m;
      try {
        m = JSON.parse(e.data);
      } catch {
        return;
      }
      handleWs(m);
    };
  }

  function handleWs(m) {
    if (m.type === 'hello') {
      const d = m.data || {};
      if (d.status) applyStatus(d.status);
      if (d.plugins) state.plugins = d.plugins;
      if (d.logs) state.logs = d.logs;
      if (d.events) state.events = d.events;
      renderChrome();
      if (state.page === 'dashboard' || state.page === 'accounts') render();
      return;
    }
    if (m.type === 'log') {
      if (!isHistoryDate(state.logDate)) {
        state.logs.push(m.data);
        if (state.logs.length > 1200) state.logs.splice(0, state.logs.length - 1200);
        if (state.page === 'logs' && !state.paused) appendLogLine(m.data);
      }
      return;
    }
    if (m.type === 'event') {
      bumpCounters(m.data);
      renderNavCounts();
      if (!isHistoryDate(state.msgDate)) {
        state.events.unshift(m.data);
        if (state.events.length > 300) state.events.length = 300;
        if (state.page === 'messages') renderMessagesList();
      }
      if (state.page === 'dashboard') scheduleDashboard();
      return;
    }
    if (m.type === 'notice') {
      const n = m.data || {};
      toast(n.message || '收到系统提示', n.level === 'error' ? 'err' : n.level === 'warn' ? 'warn' : 'ok');
      refreshStatus();
      return;
    }
    if (m.type === 'status') {
      applyStatus(m.data);
      renderChrome();
      if (state.page === 'connection' || state.page === 'accounts') render();
      else if (state.page === 'dashboard') scheduleDashboard();
    }
  }

  function bumpCounters(evt) {
    const st = state.status;
    if (!st) return;
    const acc = st.accounts?.find((a) => a.id === evt.accountId);
    const kind = evt.message?.kind;
    const bump = (obj) => {
      if (!obj) return;
      obj.today = (obj.today || 0) + 1;
      if (obj.counts) {
        obj.counts.total = (obj.counts.total || 0) + 1;
        if (kind && obj.counts[kind] !== undefined) obj.counts[kind]++;
      }
    };
    bump(acc);
    if (st.aggregate) {
      st.aggregate.today = (st.aggregate.today || 0) + 1;
      st.aggregate.total = (st.aggregate.total || 0) + 1;
      if (kind && st.aggregate[kind] !== undefined) st.aggregate[kind]++;
    }
  }

  let dashTimer = null;
  function scheduleDashboard() {
    clearTimeout(dashTimer);
    dashTimer = setTimeout(() => {
      if (state.page === 'dashboard') render();
    }, 400);
  }

  /* ================= 骨架渲染 ================= */

  function render() {
    const [title, sub] = TITLES[state.page] || ['', ''];
    $('#page-title').textContent = title;
    $('#page-sub').textContent = sub;
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.page === state.page));
    const content = $('#content');
    const fn = PAGES[state.page];
    try {
      content.innerHTML = fn ? fn() : '<div class="card empty">页面不存在</div>';
    } catch (e) {
      content.innerHTML = `<div class="card empty"><b>页面渲染失败</b>${esc(e.message)}</div>`;
      console.error(e);
    }
    mountPage(state.page);
    renderNavCounts();
    renderChrome();
  }

  function renderUserChip() {
    const u = state.user;
    const av = $('#user-avatar');
    if (av) av.innerHTML = u?.avatar ? `<img src="${esc(u.avatar)}" alt="">` : esc((u?.name || '聚').slice(0, 1));
    const n = $('#user-name');
    if (n) n.textContent = u?.name || '聚龙用户';
    const e = $('#user-email');
    if (e) e.textContent = u?.email || '';
    const chip = $('#user-chip');
    if (chip) chip.title = u ? `${u.name || ''} <${u.email || ''}>` : '聚龙账户';
  }

  function renderChrome() {
    const st = state.status;
    const acc = activeAccount();
    renderUserChip();
    const [label, cls] = connMeta(acc?.state);
    const pill = $('#sidebar-status');
    if (pill) pill.innerHTML = `<i class="dot ${cls}"></i><span>${esc(acc ? acc.name + ' · ' + label : label)}</span>`;
    const nd = $('#nav-conn-dot');
    if (nd) nd.className = 'dot ' + cls;
    const meta = $('#sidebar-meta');
    if (meta) {
      const online = st?.aggregate?.online ?? 0;
      meta.textContent = st ? `${state.accounts.length} 个账户 · ${online} 在线 · ${st.server.host}:${st.server.port}` : '—';
    }
    const bv = $('#brand-version');
    if (bv && st?.version) bv.textContent = 'v' + st.version;
    renderWsPill();
    renderAccountSelect();
    renderIpPill();
    renderNavCounts();
    renderUpdatePill();
    renderUpdateCard();
    renderLoginScopePill();
  }

  function renderWsPill() {
    const p = $('#ws-pill');
    if (!p) return;
    p.classList.toggle('on', state.wsOk);
    p.innerHTML = `<i class="dot ${state.wsOk ? 'ok' : ''}"></i><span>${state.wsOk ? '实时' : '离线'}</span>`;
  }

  function renderAccountSelect() {
    const sel = $('#account-select');
    if (!sel) return;
    if (state.accounts.length < 2) {
      sel.classList.add('hidden');
      return;
    }
    sel.classList.remove('hidden');
    sel.innerHTML = state.accounts
      .map((a) => {
        const [lbl] = connMeta(a.state);
        return `<option value="${esc(a.id)}" ${a.id === state.accountId ? 'selected' : ''}>${esc(a.name)} · ${esc(lbl)}</option>`;
      })
      .join('');
  }

  function renderIpPill() {
    const pill = $('#ip-pill');
    const val = $('#ip-value');
    if (!pill || !val) return;
    const ip = state.ip || {};
    pill.classList.remove('ok', 'err');
    if (state.ipLoading) {
      val.textContent = '获取中…';
      pill.title = '正在查询公网 IP…';
      return;
    }
    if (ip.ip) {
      val.textContent = ip.ip;
      pill.classList.add('ok');
      pill.title = `公网 IP：${ip.ip}（来源 ${ip.source || '—'}）\n更新时间：${ip.updatedAt ? fmtDateTime(ip.updatedAt) : '—'}\n点击复制`;
    } else {
      val.textContent = '获取失败';
      pill.classList.add('err');
      pill.title = (ip.error || '无法获取公网 IP') + '\n点击重试';
    }
  }

  function renderNavCounts() {
    const p = $('#nav-plugin-count');
    if (p) p.textContent = String(state.plugins.length || 0);
    const a = $('#nav-account-count');
    if (a) a.textContent = String(state.accounts.length || 0);
  }

  function mountPage(page) {
    if (page === 'market') {
      // 每次进入市场都从首页开始（市场内部可能停在 /home、/developer 等子页）
      const frame = $('#market-frame');
      if (frame) {
        try {
          const u = new URL(frame.src, location.origin);
          if (u.pathname !== '/market-proxy/' && u.pathname !== '/market-proxy/index.html') frame.src = marketHomeUrl();
        } catch {
          frame.src = marketHomeUrl();
        }
      }
    }
    if (page === 'messages') {
      const input = $('#msg-search');
      if (input) {
        input.value = state.msgQuery;
        input.addEventListener('input', () => {
          state.msgQuery = input.value;
          renderMessagesList();
        });
      }
      const msgDate = $('#msg-date');
      if (msgDate) {
        msgDate.addEventListener('change', () => {
          void loadEventsDate(msgDate.value);
        });
      }
    }
    if (page === 'api') {
      const input = $('#api-search');
      if (input) {
        input.value = state.apiQuery;
        input.addEventListener('input', () => {
          state.apiQuery = input.value;
          renderApiList();
        });
      }
    }
    if (page === 'logs') {
      const input = $('#log-search');
      if (input) {
        input.value = state.logQuery;
        input.addEventListener('input', () => {
          state.logQuery = input.value;
          const view = $('#log-view');
          if (view) {
            view.innerHTML = renderLogLines();
            view.scrollTop = view.scrollHeight;
          }
        });
      }
      const logDate = $('#log-date');
      if (logDate) {
        logDate.addEventListener('change', () => {
          void loadLogsDate(logDate.value);
        });
      }
    }
  }

  /* ================= 概览 ================= */

  function statCard(label, value, sub) {
    return `<div class="card"><div class="stat">
      <span class="stat-label">${esc(label)}</span>
      <div class="stat-value">${value}</div>
      <span class="stat-sub">${sub || ''}</span>
    </div></div>`;
  }

  function pageDashboard() {
    const st = state.status;
    if (!st) return skeleton();
    const agg = st.aggregate || {};
    const acc = activeAccount();
    const running = state.plugins.filter((p) => p.status === 'running').length;
    const recent = state.events.slice(0, 8);
    const logs = state.logs.slice(-12);
    const token = acc?.token || {};
    const ttl = token.ttlLeft || 0;
    const pct = clamp((ttl / 7200000) * 100, 0, 100);

    return `
    ${
      agg.configured === 0
        ? `<div class="card" style="border-color:rgba(245,158,11,.4);background:linear-gradient(90deg,rgba(245,158,11,.10),rgba(245,158,11,.03))">
            <div class="row between">
              <div>
                <div style="font-weight:600;margin-bottom:3px">还没有可用的机器人账户</div>
                <div class="item-sub">去「账户」页新建一个，填入 AppID / AppSecret；也可以先用「模拟一条群消息」走通插件链路。</div>
              </div>
              <button class="btn btn-primary" data-act="goto" data-page="accounts">去添加账户</button>
            </div>
          </div>`
        : ''
    }
    <div class="grid g4">
      ${statCard('在线账户', `${agg.online || 0}<small>/ ${state.accounts.length}</small>`, `已配置 ${agg.configured || 0} 个`)}
      ${statCard('今日消息', fmtNum(agg.today || 0), `累计 ${fmtNum(agg.total || 0)} 条`)}
      ${statCard('群 / 私聊', `${fmtNum(agg.group || 0)}<small>/ ${fmtNum(agg.c2c || 0)}</small>`, '按账户汇总')}
      ${statCard('插件', `${running}<small>/ ${state.plugins.length}</small>`, `错误 ${state.plugins.reduce((a, p) => a + (p.stats?.errors || 0), 0)} 次`)}
    </div>

    <div class="card">
      <div class="card-head">
        <h3 class="card-title">账户池</h3>
        <div class="card-actions">
          <button class="btn btn-sm" data-act="account-new">新建账户</button>
          <button class="btn btn-sm btn-ghost" data-act="goto" data-page="accounts">管理</button>
        </div>
      </div>
      ${
        state.accounts.length
          ? `<table class="table"><thead><tr><th>账户</th><th>接入</th><th>状态</th><th>今日</th><th style="width:150px">操作</th></tr></thead><tbody>
              ${state.accounts
                .map((a) => {
                  const [label, cls] = connMeta(a.state);
                  return `<tr>
                    <td><div class="row" style="gap:8px;flex-wrap:nowrap">${accountAvatarHtml(a, 26)}
                      <div style="min-width:0"><div style="font-size:12.5px">${esc(a.name)}</div><div class="mono" style="font-size:10px;color:var(--dim)">${esc(a.id)}</div></div></div></td>
                    <td><span class="badge">${a.mode === 'webhook' ? 'WebHook' : 'WebSocket'}</span></td>
                    <td><span class="badge ${cls}">${esc(label)}</span></td>
                    <td class="mono">${fmtNum(a.today || 0)}</td>
                    <td><div class="row" style="gap:6px">
                      <button class="btn btn-sm btn-ghost" data-act="account-active" data-id="${esc(a.id)}">切换</button>
                      <button class="btn btn-sm btn-ghost" data-act="account-restart" data-id="${esc(a.id)}">重连</button>
                    </div></td>
                  </tr>`;
                })
                .join('')}
            </tbody></table>`
          : `<div class="empty"><b>还没有账户</b>点击右上角「新建账户」开始</div>`
      }
    </div>

    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3 class="card-title">当前账户 <small>${esc(acc?.name || '—')}</small></h3>
          <div class="card-actions">
            <button class="btn btn-sm btn-ghost" data-act="account-restart" data-id="${esc(acc?.id || '')}">重启连接</button>
          </div>
        </div>
        ${
          acc
            ? `<div class="row" style="gap:14px;margin-bottom:14px">
                <div class="avatar" style="width:46px;height:46px;font-size:17px">${acc.self?.avatar ? `<img src="${esc(acc.self.avatar)}" alt="">` : esc((acc.self?.username || acc.name || 'J').slice(0, 1))}</div>
                <div><div style="font-size:15px;font-weight:600">${esc(acc.self?.username || acc.name)}</div>
                  <div class="item-sub mono">${esc(acc.appIdMasked || 'AppID 未配置')}</div></div>
                <div class="spacer"></div>
                <span class="badge ${acc.sandbox ? 'warn' : 'info'}">${acc.sandbox ? '沙箱' : '正式'}</span>
              </div>
              <dl class="kv">
                <dt>账户 ID</dt><dd>${esc(acc.id)}</dd>
                <dt>接入方式</dt><dd>${acc.mode === 'webhook' ? 'WebHook' : 'WebSocket'}</dd>
                <dt>命令前缀</dt><dd>${acc.prefix ? esc(acc.prefix) : '（无）'}</dd>
                <dt>Intents</dt><dd>${acc.intentsMask}（0x${Number(acc.intentsMask || 0).toString(16)}）</dd>
                <dt>WebHook</dt><dd>${esc(location.origin + acc.webhookPath)}</dd>
              </dl>`
            : `<div class="empty">没有账户</div>`
        }
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">访问凭证</h3>
          <button class="btn btn-sm" data-act="refresh-token">立即刷新</button>
        </div>
        <div class="row between" style="margin-bottom:8px">
          <span class="badge ${token.hasToken ? 'ok' : 'err'}">${token.hasToken ? '有效' : '未获取'}</span>
          <span class="mono" style="font-size:12px;color:var(--muted)">剩余 ${fmtDur(ttl)}</span>
        </div>
        <div class="progress ${pct < 15 ? 'danger' : pct < 40 ? 'warn' : ''}"><i style="width:${pct}%"></i></div>
        ${token.lastError ? `<p class="item-sub" style="color:var(--danger);margin-top:10px">${esc(token.lastError)}</p>` : ''}
        <dl class="kv" style="margin-top:14px">
          <dt>到期时间</dt><dd>${token.expiresAt ? fmtDateTime(token.expiresAt) : '—'}</dd>
          <dt>刷新策略</dt><dd>到期前 60 秒自动刷新</dd>
          <dt>凭证来源</dt><dd>${esc(acc?.appIdMasked || '未配置')}</dd>
        </dl>
        <div class="grid g3" style="margin-top:16px;gap:10px">
          <div class="stat"><span class="stat-label">API 调用</span><div class="stat-value" style="font-size:19px">${fmtNum(acc?.api?.total)}</div></div>
          <div class="stat"><span class="stat-label">成功</span><div class="stat-value" style="font-size:19px;color:var(--ok)">${fmtNum(acc?.api?.ok)}</div></div>
          <div class="stat"><span class="stat-label">失败</span><div class="stat-value" style="font-size:19px;color:var(--danger)">${fmtNum(acc?.api?.fail)}</div></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <h3 class="card-title">快捷操作</h3>
        <span class="item-sub">对当前账户生效</span>
      </div>
      <div class="row">
        <button class="btn" data-act="inject-event">模拟一条群消息</button>
        <button class="btn" data-act="send-test">发送消息测试</button>
        <button class="btn" data-act="plugins-reload">重载全部插件</button>
        <button class="btn" data-act="goto" data-page="api">打开接口调试</button>
        <button class="btn" data-act="goto" data-page="logs">查看实时日志</button>
        <button class="btn btn-ghost" data-act="copy" data-copy="${esc(st.server.url)}">复制面板地址</button>
      </div>
    </div>

    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3 class="card-title">最近事件</h3>
          <button class="btn btn-sm btn-ghost" data-act="goto" data-page="messages">全部</button>
        </div>
        ${
          recent.length
            ? `<div class="list">${recent
                .map((e) => {
                  const [kl, kc] = kindMeta(e.message?.kind || 'other');
                  return `<div class="list-item click" data-act="view-event" data-id="${esc(e.id)}">
                    ${avatarHtml(e, 34)}
                    <div class="item-main">
                      <div class="item-title"><span class="badge ${kc}">${kl}</span>
                        <span class="acct-badge">${esc(accountName(e.accountId))}</span>
                        <span>${esc(e.message?.author?.username || e.name)}</span>
                        <span class="spacer"></span>
                        <span class="item-time">${fmtTime(e.ts)}</span>
                      </div>
                      <div class="item-sub">${esc((e.message?.cleanContent || e.name).slice(0, 90))}</div>
                    </div>
                  </div>`;
                })
                .join('')}</div>`
            : `<div class="empty"><b>还没有收到事件</b>把机器人拉进群 @ 一下试试</div>`
        }
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">实时日志</h3>
          <button class="btn btn-sm btn-ghost" data-act="goto" data-page="logs">全部</button>
        </div>
        <div class="log-view" style="max-height:310px">${logs.map(logLineHtml).join('') || '<div class="empty">暂无日志</div>'}</div>
      </div>
    </div>`;
  }

  function skeleton() {
    return `<div class="card empty"><b>正在加载…</b>如果长时间没有响应，请检查服务是否正常</div>`;
  }

  /* ================= 账户 ================= */

  function pageAccounts() {
    return `
    <div class="card flat">
      <div class="row between">
        <div class="row">
          <span class="badge info">${state.accounts.length} 个账户</span>
          <span class="badge ok">${state.accounts.filter((a) => a.state === 'online' || a.state === 'webhook').length} 在线</span>
          <span class="item-sub">每个账户独立 access_token 与网关连接，插件事件会标明来源账户</span>
        </div>
        <div class="row">
          <button class="btn btn-sm" data-act="refresh">刷新</button>
          <button class="btn btn-sm btn-primary" data-act="account-new">新建账户</button>
        </div>
      </div>
    </div>
    <div class="acct-grid">
      ${
        state.accounts.length
          ? state.accounts
              .map((a) => {
                const [stateLabel, stateCls] = connMeta(a.state);
                const disabled = a.enabled === false;
                const [label, cls] = disabled ? ['已停用', ''] : [stateLabel, stateCls];
                return `<div class="card acct-card"${disabled ? ' style="opacity:.72"' : ''}>
          <div class="acct-top">
            <div class="acct-ico">${a.self?.avatar ? `<img src="${esc(a.self.avatar)}" alt="" referrerpolicy="no-referrer" />` : esc((a.name || '?').slice(0, 1).toUpperCase())}</div>
            <div style="flex:1;min-width:0">
              <div class="acct-name">${esc(a.name)}</div>
              <div class="acct-sub mono">${esc(a.id)} · ${a.mode === 'webhook' ? 'WebHook' : 'WebSocket'}${a.sandbox ? ' · 沙箱' : ''}${a.enabled === false ? ' · 已停用' : ''}${a.enabled !== false && a.autoConnect === false ? ' · 未自动连接' : ''}${a.enabled !== false && a.autoReconnect === false ? ' · 手动重连' : ''}</div>
            </div>
            <span class="badge ${cls}">${esc(label)}</span>
          </div>
          <dl class="kv" style="grid-template-columns:80px 1fr">
            <dt>AppID</dt><dd>${esc(a.appIdMasked || '未配置')}</dd>
            <dt>命令前缀</dt><dd>${a.prefix ? esc(a.prefix) : '（无）'}</dd>
            <dt>今日</dt><dd>${fmtNum(a.today || 0)} 条 · 累计 ${fmtNum(a.counts?.total || 0)}</dd>
            <dt>凭证</dt><dd>${a.token?.hasToken ? '有效 · ' + fmtDur(a.token.ttlLeft) : '未获取'}</dd>
            <dt>WebHook</dt><dd class="acct-webhook">${esc(a.webhookPath)}</dd>
          </dl>
          ${a.lastError ? `<div class="acct-error" title="${esc(a.lastError)}">${esc(a.lastError)}</div>` : ''}
          <div class="plugin-foot acct-foot">
            <button class="btn btn-sm ${a.enabled ? '' : 'btn-primary'}" data-act="account-toggle" data-id="${esc(a.id)}" data-enabled="${a.enabled ? '0' : '1'}">${a.enabled ? '停用' : '启用'}</button>
            <button class="btn btn-sm" data-act="account-restart" data-id="${esc(a.id)}">重连</button>
            <button class="btn btn-sm" data-act="account-edit" data-id="${esc(a.id)}">编辑</button>
            <button class="btn btn-sm btn-ghost" data-act="account-copy-webhook" data-id="${esc(a.id)}">复制回调</button>
            <button class="btn btn-sm btn-danger" data-act="account-delete" data-id="${esc(a.id)}">删除</button>
          </div>
        </div>`;
              })
              .join('')
          : `<div class="card empty"><b>还没有账户</b>点击「新建账户」添加第一个 QQ 机器人</div>`
      }
    </div>
    <div class="card">
      <div class="card-head"><h3 class="card-title">多账户说明</h3></div>
      <div class="grid g2">
        <div>
          <p class="item-sub" style="margin-top:0">每个账户对应一个 QQ 机器人 AppID，拥有独立的 access_token、网关连接、WebHook 回调路径与消息计数。插件事件里会带 <code>account.id</code> / <code>account.name</code>，回复时自动用该账户的凭证。</p>
          <p class="item-sub">WebHook 模式需要给每个账户在其开放平台后台分别填写回调地址：<code>${esc(location.origin)}/qqbot/webhook/&lt;账户ID&gt;</code>，并保证公网 HTTPS 且端口为 80/443/8080/8443。</p>
        </div>
        <div>
          <dl class="kv">
            <dt>账户总数</dt><dd>${state.accounts.length}</dd>
            <dt>在线</dt><dd>${state.accounts.filter((a) => a.state === 'online' || a.state === 'webhook').length}</dd>
            <dt>已配置凭证</dt><dd>${state.accounts.filter((a) => a.hasCredentials).length}</dd>
            <dt>插件令牌</dt><dd>${esc(state.pluginToken)}</dd>
          </dl>
        </div>
      </div>
    </div>`;
  }

  function openAccountModal(id) {
    const acc = id ? state.accounts.find((a) => a.id === id) : null;
    const isEdit = !!acc;
    // 新建账户默认三项全开：创建完成即进入账户池并保持在线
    const accEnabled = acc ? acc.enabled !== false : true;
    const autoConnect = acc ? acc.autoConnect !== false : true;
    const autoReconnect = acc ? acc.autoReconnect !== false : true;
    const intents = (acc?.intents?.length ? acc.intents : ['GUILDS', 'GUILD_MEMBERS', 'GUILD_MESSAGE_REACTIONS', 'DIRECT_MESSAGE', 'GROUP_AND_C2C_EVENT', 'PUBLIC_GUILD_MESSAGES', 'INTERACTION']).join(',');
    const body = `
      <div class="input-row">
        <label class="field"><span class="field-label">账户名称</span><input id="ac-name" type="text" value="${esc(acc?.name || '')}" placeholder="例如 主账号 / 客服号" /></label>
        <label class="field"><span class="field-label">接入方式</span>
          <select id="ac-mode">
            <option value="ws" ${acc?.mode !== 'webhook' ? 'selected' : ''}>WebSocket（无需公网）</option>
            <option value="webhook" ${acc?.mode === 'webhook' ? 'selected' : ''}>WebHook（需公网 HTTPS）</option>
          </select>
        </label>
      </div>
      <div class="input-row">
        <label class="field"><span class="field-label">AppID</span><input id="ac-appid" type="text" value="${esc(acc?.appId || '')}" placeholder="开放平台 AppID" /></label>
        <label class="field"><span class="field-label">AppSecret ${acc?.hasSecret ? '<span class="badge ok">已保存</span>' : ''}</span><input id="ac-secret" type="password" value="" placeholder="${acc?.hasSecret ? '留空表示不修改' : 'AppSecret'}" autocomplete="new-password" /></label>
      </div>
      <div class="input-row">
        <label class="field"><span class="field-label">命令前缀</span><input id="ac-prefix" type="text" value="${esc(acc?.prefix || '')}" placeholder="例如 / 或 !（可留空）" /></label>
        <label class="field"><span class="field-label">WebHook 路径</span><input id="ac-webhook" type="text" value="${esc(acc?.webhookPath || '')}" placeholder="/qqbot/webhook/账户ID" /></label>
      </div>
      <label class="field"><span class="field-label">Intents（逗号分隔）</span>
        <input id="ac-intents" type="text" value="${esc(intents)}" />
        <span class="field-hint">常用：GUILDS, GUILD_MEMBERS, GROUP_AND_C2C_EVENT, PUBLIC_GUILD_MESSAGES, INTERACTION, DIRECT_MESSAGE, GUILD_MESSAGE_REACTIONS</span>
      </label>
      <div class="input-row">
        <label class="field"><span class="field-label">分片 ID</span><input id="ac-shard" type="number" value="${acc?.shardId ?? 0}" /></label>
        <label class="field"><span class="field-label">分片总数</span><input id="ac-shardcount" type="number" value="${acc?.shardCount ?? 1}" /></label>
      </div>
      <div class="row" style="gap:24px;margin:6px 0 4px">
        <label class="row" style="gap:8px"><span class="field-label">沙箱环境</span><span class="switch"><input id="ac-sandbox" type="checkbox" ${acc?.sandbox ? 'checked' : ''} /><span></span></span></label>
        <label class="row" style="gap:8px" title="启用机器人到池中">
          <span class="field-label">启用<span class="item-sub" style="margin-left:6px;font-weight:400">启用机器人到池中</span></span>
          <span class="switch"><input id="ac-enabled" type="checkbox" ${accEnabled ? 'checked' : ''} /><span></span></span>
        </label>
      </div>
      <div class="row" id="ac-sub-switches" style="gap:24px;margin:6px 0 4px;${accEnabled ? '' : 'opacity:.45'}">
        <label class="row" style="gap:8px"><span class="field-label">自动连接</span><span class="switch"><input id="ac-autoconnect" type="checkbox" ${autoConnect ? 'checked' : ''} ${accEnabled ? '' : 'disabled'} /><span></span></span></label>
        <label class="row" style="gap:8px"><span class="field-label">异常重连</span><span class="switch"><input id="ac-autoreconnect" type="checkbox" ${autoReconnect ? 'checked' : ''} ${accEnabled ? '' : 'disabled'} /><span></span></span></label>
      </div>
      <p class="field-hint"><b>启用</b>＝把机器人启用「到池中」：关掉后整个账户就是禁用状态，启动/重启都不会连接，下面的「自动连接」「异常重连」也一起停用（灰色不可改）。新建账户默认三项全开。</p>
      <p class="field-hint"><b>自动连接</b>：项目启动、重启（含定时重启）后自动连这个 bot。<b>异常重连</b>：掉线后自动重连并一直保持在线；关掉后掉线就停在「已断开」，需手动点「重连」。</p>
      <p class="field-hint">保存后若凭证或接入方式变化，框架会自动重启该账户的连接。</p>`;
    openModal(isEdit ? '编辑账户 · ' + acc.name : '新建账户', body, `
      <button class="btn btn-ghost" data-close="modal">取消</button>
      <button class="btn btn-primary" data-act="account-save" data-id="${esc(id || '')}">保存</button>`);

    // 启用是总开关：关掉时自动连接 / 异常重连 变灰且不可操作；
    // 重新打开启用 = 启用到池中，顺手把这两项一起打开（与卡片上的「启用」按钮一致）
    const enabledInput = $('#ac-enabled');
    const subRow = $('#ac-sub-switches');
    const subInputs = ['#ac-autoconnect', '#ac-autoreconnect'];
    const syncSub = () => {
      const on = !!enabledInput?.checked;
      if (subRow) subRow.style.opacity = on ? '' : '0.45';
      for (const sel of subInputs) {
        const el = $(sel);
        if (el) el.disabled = !on;
      }
    };
    if (enabledInput) {
      enabledInput.addEventListener('change', () => {
        if (enabledInput.checked) {
          for (const sel of subInputs) {
            const el = $(sel);
            if (el) el.checked = true;
          }
        }
        syncSub();
      });
    }
    syncSub();
  }

  async function saveAccount(id) {
    const val = (sel) => $(sel)?.value?.trim() ?? '';
    const intents = val('#ac-intents')
      .split(/[,，\s]+/)
      .map((x) => x.trim())
      .filter(Boolean);
    const payload = {
      name: val('#ac-name') || '未命名账户',
      appId: val('#ac-appid'),
      mode: $('#ac-mode')?.value || 'ws',
      prefix: val('#ac-prefix'),
      webhookPath: val('#ac-webhook') || undefined,
      intents,
      shardId: Number(val('#ac-shard')) || 0,
      shardCount: Number(val('#ac-shardcount')) || 1,
      sandbox: !!$('#ac-sandbox')?.checked,
      enabled: !!$('#ac-enabled')?.checked,
      autoConnect: !!$('#ac-autoconnect')?.checked,
      autoReconnect: !!$('#ac-autoreconnect')?.checked,
    };
    const secret = val('#ac-secret');
    if (secret) payload.clientSecret = secret;
    try {
      if (id) {
        await api('/api/accounts/' + encodeURIComponent(id), { method: 'PATCH', body: payload });
        toast('账户已更新', 'ok');
      } else {
        const r = await api('/api/accounts', { method: 'POST', body: payload });
        state.accountId = r.account?.id || state.accountId;
        localStorage.setItem('jlw-account', state.accountId);
        toast('账户已创建', 'ok');
      }
      closeAll();
      await refreshAll();
    } catch (e) {
      toast(e.message, 'err');
    }
  }

  /* ================= 消息 ================= */

  function groupKey(accountId, groupOpenid) {
    return `${accountId || ''}|${groupOpenid || ''}`;
  }

  /* ---------------- 群成员事件（进群 / 退群 / 申请 / 机器人进出群） ---------------- */
  const GROUP_EVENT_META = {
    GROUP_MEMBER_ADD: { label: '进群', badge: 'ok', desc: '加入了群聊' },
    GROUP_MEMBER_REMOVE: { label: '退群', badge: 'warn', desc: '退出了群聊' },
    GROUP_JOIN_REQUEST: { label: '加群申请', badge: 'info', desc: '申请加群' },
    GROUP_ADD_ROBOT: { label: '机器人入群', badge: 'violet', desc: '机器人被添加到群聊' },
    GROUP_DEL_ROBOT: { label: '机器人退群', badge: 'err', desc: '机器人被移出群聊' },
    FRIEND_ADD: { label: '加好友', badge: 'ok', desc: '添加机器人为好友' },
    FRIEND_DEL: { label: '删好友', badge: 'warn', desc: '删除了机器人好友' },
  };

  function isGroupEvent(e) {
    return !!e && !e.message && !!GROUP_EVENT_META[e.name];
  }

  /** 机器人自己发出的消息（direction=out 由框架记录） */
  function isOutgoing(e) {
    return !!e && (e.direction === 'out' || e.name === 'BOT_MESSAGE_CREATE');
  }

  function eventGroupId(e) {
    return e?.message?.group_openid || e?.raw?.group_openid || '';
  }

  function eventActor(e) {
    const raw = e?.raw || {};
    return raw.member_openid || raw.op_member_openid || raw.user_openid || raw.openid || '';
  }

  /** 进群/退群等事件的一行说明 */
  function groupEventText(e) {
    const meta = GROUP_EVENT_META[e.name];
    const raw = e.raw || {};
    const bits = [meta ? meta.desc : e.name];
    if (e.name === 'GROUP_JOIN_REQUEST') {
      if (raw.verify_info) bits.push(`验证信息：${raw.verify_info}`);
      if (raw.apply_source) bits.push(`来源：${raw.apply_source}`);
    }
    if ((e.name === 'GROUP_MEMBER_ADD' || e.name === 'GROUP_ADD_ROBOT') && raw.op_member_openid) {
      bits.push(`操作人：${raw.op_member_openid}`);
    }
    if (e.name === 'GROUP_MEMBER_ADD' && raw.invite_source) bits.push(`邀请来源：${raw.invite_source}`);
    return bits.join(' · ');
  }

  function ensureGroupName(accountId, groupOpenid) {
    const key = groupKey(accountId, groupOpenid);
    if (!groupOpenid || state.groupNames[key]) return;
    state.groupNames[key] = { loading: true };
    api(`/api/groups/info?account=${encodeURIComponent(accountId || '')}&group=${encodeURIComponent(groupOpenid)}`)
      .then((r) => {
        state.groupNames[key] = { name: r.name || '', error: r.name ? '' : '未返回群名称' };
      })
      .catch((e) => {
        state.groupNames[key] = { name: '', error: e.message };
      })
      .finally(() => updateGroupNameCells(key));
  }

  function groupNameCellHtml(e) {
    const gid = eventGroupId(e);
    if (!gid) return '<span style="color:var(--dim)">—</span>';
    const key = groupKey(e.accountId, gid);
    const info = state.groupNames[key];
    if (!info) {
      ensureGroupName(e.accountId, gid);
      return '<span class="item-sub">加载中…</span>';
    }
    if (info.loading) return '<span class="item-sub">加载中…</span>';
    const label = info.name || `群聊 ${String(gid).slice(0, 6)}`;
    const active = state.msgGroup === gid && state.msgGroupAccount === e.accountId;
    return `<button type="button" class="group-link${active ? ' active' : ''}" data-act="msg-group-filter" data-account="${esc(e.accountId || '')}" data-group="${esc(gid)}" data-name="${esc(info.name || '')}" title="${esc(info.error || gid)}">${esc(label)}</button>`;
  }

  function updateGroupNameCells(key) {
    if (state.page !== 'messages') return;
    document.querySelectorAll('.msg-group-cell').forEach((cell) => {
      if (cell.dataset.groupKey !== key) return;
      const e = state.events.find((x) => x.id === cell.dataset.eventId);
      if (e) cell.innerHTML = groupNameCellHtml(e);
    });
  }

  function filteredEvents() {
    const q = state.msgQuery.trim().toLowerCase();
    return state.events.filter((e) => {
      const groupEvent = isGroupEvent(e);
      if (!e.message && !groupEvent) return false;
      if (state.msgAccount && e.accountId !== state.msgAccount) return false;
      const gid = eventGroupId(e);
      if (state.msgGroup && (e.accountId !== state.msgGroupAccount || gid !== state.msgGroup)) return false;
      if (state.msgFilter === 'group' && e.message?.kind !== 'group') return false;
      if (state.msgFilter === 'c2c' && e.message?.kind !== 'c2c') return false;
      if (state.msgFilter === 'channel' && !['channel', 'dm'].includes(e.message?.kind)) return false;
      if (state.msgFilter === 'member' && !groupEvent) return false;
      if (state.msgFilter === 'out' && !isOutgoing(e)) return false;
      if (q) {
        const hay = groupEvent
          ? `${GROUP_EVENT_META[e.name]?.label || ''} ${e.name} ${groupEventText(e)} ${gid} ${eventActor(e)} ${e.raw?.username || ''}`.toLowerCase()
          : `${e.message.cleanContent || e.message.content || ''} ${e.message.author?.username || ''} ${e.message.author?.id || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }

  function pageMessages() {
    const tabs = [
      ['all', '全部'],
      ['group', '群聊'],
      ['c2c', '单聊'],
      ['channel', '频道'],
      ['member', '群事件'],
      ['out', '机器人'],
    ];
    return `
    <div class="card flat">
      <div class="row between" style="gap:12px">
        <div class="row">
          <div class="segmented">
            ${tabs.map(([k, l]) => `<button class="${state.msgFilter === k ? 'on' : ''}" data-act="msg-filter" data-filter="${k}">${l}</button>`).join('')}
          </div>
          <select id="msg-account" class="account-select" style="max-width:170px">
            <option value="">全部账户</option>
            ${state.accounts.map((a) => `<option value="${esc(a.id)}" ${state.msgAccount === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}
          </select>
          <div class="row nowrap" style="gap:8px">
            <input id="msg-search" type="text" placeholder="搜索内容 / 昵称 / OpenID" style="width:190px" />
            <input id="msg-date" type="date" value="${esc(state.msgDate)}" max="${todayKey()}" title="选择日期查看历史消息" />
            <button class="btn btn-sm ${isHistoryDate(state.msgDate) ? '' : 'btn-ghost'}" data-act="msg-today">今天</button>
          </div>
          ${isHistoryDate(state.msgDate) ? `<span class="badge warn">历史 ${esc(state.msgDate)}</span>` : ''}
          ${
            state.msgGroup
              ? `<span class="group-filter">只看群：<b>${esc(state.msgGroupName || state.msgGroup)}</b><button type="button" data-act="msg-group-clear">全部</button></span>`
              : ''
          }
        </div>
        <div class="row">
          ${isHistoryDate(state.msgDate) ? '<span class="item-sub">只读历史（实时推送已暂停）</span>' : ''}
          <button class="btn btn-sm" data-act="send-test">发送消息</button>
          <button class="btn btn-sm btn-ghost" data-act="inject-event">模拟事件</button>
        </div>
      </div>
    </div>
    <div class="card" style="padding:0;overflow:hidden">
      <div id="msg-list">${messagesHtml()}</div>
    </div>`;
  }

  function groupEventRowHtml(e) {
    const meta = GROUP_EVENT_META[e.name] || { label: '事件', badge: '' };
    const actor = eventActor(e);
    return `<tr class="click" data-act="view-event" data-id="${esc(e.id)}">
      <td class="mono" style="color:var(--dim)">${fmtTime(e.ts)}</td>
      <td><span class="badge ${meta.badge}">${esc(meta.label)}</span></td>
      <td class="msg-group-cell" data-group-key="${esc(groupKey(e.accountId, eventGroupId(e)))}" data-event-id="${esc(e.id)}">${groupNameCellHtml(e)}</td>
      <td><span class="acct-badge">${esc(accountName(e.accountId))}</span></td>
      <td><div class="row" style="gap:7px;flex-wrap:nowrap"><div class="avatar" style="width:24px;height:24px;font-size:10px">${esc(meta.label.slice(0, 1))}</div><div style="min-width:0"><div style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(actor ? '成员 ' + actor.slice(0, 6) : '系统事件')}</div><div class="mono" style="font-size:10px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((actor || '').slice(0, 12))}</div></div></div></td>
      <td><div style="white-space:pre-wrap;word-break:break-word;max-height:44px;overflow:hidden">${esc(groupEventText(e))}</div></td>
      <td><span style="color:var(--dim)">—</span></td>
    </tr>`;
  }

  function outgoingRowHtml(e) {
    const m = e.message || {};
    const acc = state.accounts.find((a) => a.id === e.accountId);
    const text = m.cleanContent || m.content || '（非文本）';
    return `<tr class="click" data-act="view-event" data-id="${esc(e.id)}">
      <td class="mono" style="color:var(--dim)">${fmtTime(e.ts)}</td>
      <td><span class="badge info">发出</span></td>
      <td class="msg-group-cell" data-group-key="${esc(groupKey(e.accountId, m.group_openid))}" data-event-id="${esc(e.id)}">${groupNameCellHtml(e)}</td>
      <td><span class="acct-badge">${esc(accountName(e.accountId))}</span></td>
      <td><div class="row" style="gap:7px;flex-wrap:nowrap">${accountAvatarHtml(acc, 24)}<div style="min-width:0"><div style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.author?.username || '机器人')}</div><div class="mono" style="font-size:10px;color:var(--dim)">机器人</div></div></div></td>
      <td><div style="white-space:pre-wrap;word-break:break-word;max-height:44px;overflow:hidden">${esc(text)}</div></td>
      <td><span style="color:var(--dim)">—</span></td>
    </tr>`;
  }

  function messagesHtml() {
    const list = filteredEvents();
    if (!list.length) return `<div class="empty"><b>暂无消息</b>等待群聊 @、私聊消息或进群/退群事件，也可以点「模拟事件」</div>`;
    return `<table class="table"><thead><tr><th style="width:74px">时间</th><th style="width:66px">类型</th><th style="width:210px">群名称</th><th style="width:96px">账户</th><th style="width:150px">发送者</th><th>内容</th><th style="width:60px">附件</th></tr></thead><tbody>
      ${list
        .slice(0, 200)
        .map((e) => {
          if (isGroupEvent(e)) return groupEventRowHtml(e);
          if (isOutgoing(e)) return outgoingRowHtml(e);
          const m = e.message;
          const [kl, kc] = kindMeta(m.kind);
          const rawText = m.content || '';
          const displayText = m.cleanContent || (/^<@/.test(rawText.trim()) ? '（@了机器人）' : rawText) || '（非文本）';
          return `<tr class="click" data-act="view-event" data-id="${esc(e.id)}">
            <td class="mono" style="color:var(--dim)">${fmtTime(e.ts)}</td>
            <td><span class="badge ${kc}">${kl}</span></td>
            <td class="msg-group-cell" data-group-key="${esc(groupKey(e.accountId, m.group_openid))}" data-event-id="${esc(e.id)}">${groupNameCellHtml(e)}</td>
            <td><span class="acct-badge">${esc(accountName(e.accountId))}</span></td>
            <td><div class="row" style="gap:7px;flex-wrap:nowrap">${avatarHtml(e, 24)}<div style="min-width:0"><div style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.author?.username || '未知')}</div><div class="mono" style="font-size:10px;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((m.author?.id || '').slice(0, 12))}</div></div></div></td>
            <td><div style="white-space:pre-wrap;word-break:break-word;max-height:44px;overflow:hidden">${esc(displayText)}</div>${m.attachments?.length ? `<div class="item-sub" style="margin-top:2px">📎 ${esc(m.attachments[0].filename || m.attachments[0].content_type || '附件')}${m.attachments.length > 1 ? ` 等 ${m.attachments.length} 个` : ''}</div>` : ''}</td>
            <td>${m.attachments?.length ? `<span class="badge info" title="点击查看附件">${m.attachments.length}</span>` : '<span style="color:var(--dim)">—</span>'}</td>
          </tr>`;
        })
        .join('')}
    </tbody></table>`;
  }

  function renderMessagesList() {
    const el = $('#msg-list');
    if (el) el.innerHTML = messagesHtml();
  }

  /* ================= 消息预览（点击消息时渲染“发出去的样子”） ================= */

  function safeUrl(u) {
    const s = String(u || '').trim();
    if (!s) return '';
    if (/^https?:\/\//i.test(s)) return s;
    if (/^data:image\//i.test(s)) return s;
    return '';
  }

  /** 去掉 QQ 消息里夹带的控制字符（群公告 prompt 里常见 \u0001/\u0002） */
  function stripCtl(s) {
    return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
  }

  /** 解码 QQ 自定义标签属性里的百分号编码（%2F%E8%8F%9C... → /菜单） */
  function decodeQQPercent(s) {
    const v = String(s == null ? '' : s);
    try {
      return decodeURIComponent(v);
    } catch {
      return v;
    }
  }

  /**
   * 清理腾讯自定义 markdown：
   * - <qqbot-cmd-input text="/菜单" show="菜单" /> 这类“蓝字指令”显示为解码后的文字，不显示原始标签；
   *   单独占一行的指令按钮（欢迎语里的命令快捷入口）直接不显示；
   * - <qqbot-at-user id="..." /> → @用户；
   * - 其它 qqbot-* 自定义标签不显示。
   */
  function normalizeQQMarkdown(s) {
    let out = String(s == null ? '' : s);
    const attr = (attrs, name) => {
      const m = attrs.match(new RegExp(name + '\\s*=\\s*["\']([^"\']*)["\']', 'i'));
      return m ? m[1] : '';
    };
    // 整行只有一个命令按钮：这是 QQ 客户端给的快捷入口，预览里不展示
    out = out.replace(/^[ \t]*<qqbot-cmd-(?:input|enter)\b[^\n]*?\/>[ \t]*\r?$/gim, '');
    out = out.replace(/<qqbot-cmd-(?:input|enter)\b([^>]*?)\/>/gi, (m, attrs) => {
      const label = decodeQQPercent(attr(attrs, 'show') || attr(attrs, 'text')).replace(/^\//, '');
      return label;
    });
    out = out.replace(/<qqbot-at-user\b[^>]*\/>/gi, '@用户');
    out = out.replace(/<qqbot-[^>\n]*\/>/gi, '');
    return out;
  }

  function linkifyHtml(escaped) {
    return String(escaped || '').replace(/(https?:\/\/[^\s<]+)/g, (m) => {
      const t = m.replace(/[),.。；;!?！？]+$/, '');
      const tail = m.slice(t.length);
      return `<a href="${t}" target="_blank" rel="noreferrer noopener">${t}</a>${tail}`;
    });
  }

  function inlineMd(s) {
    // 先把 markdown 的代码/图片/链接换成占位符，避免自动识别 URL 时把生成标签的属性也包进 <a>
    const stash = [];
    const hold = (html) => `\u0000${stash.push(html) - 1}\u0000`;
    let out = String(s || '');
    out = out.replace(/`([^`]+)`/g, (m, code) => hold(`<code>${code}</code>`));
    out = out.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (m, alt, url) => {
      const u = safeUrl(url);
      return u ? hold(`<img class="bubble-img" src="${u}" alt="${alt}" referrerpolicy="no-referrer" loading="lazy" />`) : alt;
    });
    out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, text, url) => {
      const u = safeUrl(url);
      return u ? hold(`<a href="${u}" target="_blank" rel="noreferrer noopener">${text}</a>`) : text;
    });
    out = out.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    out = out.replace(/__([^_]+)__/g, '<b>$1</b>');
    out = out.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>');
    out = out.replace(/~~([^~]+)~~/g, '<s>$1</s>');
    out = linkifyHtml(out);
    return out.replace(/\u0000(\d+)\u0000/g, (m, i) => stash[Number(i)]);
  }

  function renderMarkdown(md) {
    md = normalizeQQMarkdown(md);
    const lines = String(md || '').replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    let list = null;
    let code = null;
    let para = [];
    const flushList = () => {
      if (!list) return;
      out.push(`<${list.tag}>${list.items.map((i) => `<li>${inlineMd(esc(i))}</li>`).join('')}</${list.tag}>`);
      list = null;
    };
    const flushPara = () => {
      if (!para.length) return;
      out.push(`<p>${inlineMd(esc(para.join('\n'))).replace(/\n/g, '<br/>')}</p>`);
      para = [];
    };
    for (const line of lines) {
      if (/^```/.test(line)) {
        if (code === null) {
          flushPara();
          flushList();
          code = [];
        } else {
          out.push(`<pre class="bubble-code"><code>${esc(code.join('\n'))}</code></pre>`);
          code = null;
        }
        continue;
      }
      if (code !== null) {
        code.push(line);
        continue;
      }
      if (!line.trim()) {
        flushPara();
        flushList();
        continue;
      }
      if (/^\s*(?:\*\s*){3,}$/.test(line) || /^\s*(?:-\s*){3,}$/.test(line) || /^\s*(?:_\s*){3,}$/.test(line)) {
        flushPara();
        flushList();
        out.push('<hr class="bubble-hr" />');
        continue;
      }
      const h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) {
        flushPara();
        flushList();
        const n = Math.min(6, h[1].length) + 2;
        out.push(`<h${n} class="bubble-h">${inlineMd(esc(h[2]))}</h${n}>`);
        continue;
      }
      if (/^>\s?/.test(line)) {
        flushPara();
        flushList();
        out.push(`<blockquote>${inlineMd(esc(line.replace(/^>\s?/, '')))}</blockquote>`);
        continue;
      }
      const li = line.match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
      if (li) {
        flushPara();
        const tag = /^\d/.test(li[1]) ? 'ol' : 'ul';
        if (!list || list.tag !== tag) {
          flushList();
          list = { tag, items: [] };
        }
        list.items.push(li[2]);
        continue;
      }
      flushList();
      para.push(line);
    }
    if (code !== null) out.push(`<pre class="bubble-code"><code>${esc(code.join('\n'))}</code></pre>`);
    flushPara();
    flushList();
    return out.join('\n');
  }

  function cardFromPayload(payload) {
    const p = payload || {};
    const node = p.ark || p.embed || p.card || p.ark_data || p;
    let title = '';
    let desc = '';
    let prompt = '';
    let img = '';
    let link = '';
    const fields = [];
    if (Array.isArray(node.kv)) {
      for (const kv of node.kv) {
        const key = String((kv && kv.key) || '').toUpperCase();
        const val = kv && kv.value;
        if (!val) continue;
        if (key.includes('TITLE') && !title) title = val;
        else if ((key.includes('DESC') || key.includes('CONTENT')) && !desc) desc = val;
        else if (key.includes('PROMPT') && !prompt) prompt = val;
        else if (key.includes('IMG') && !img) img = val;
        else if ((key.includes('URL') || key.includes('JUMP')) && !link) link = val;
        else fields.push({ k: kv.key, v: val });
      }
    }
    if (!title && node.title) title = node.title;
    if (!desc && (node.desc || node.description)) desc = node.desc || node.description;
    if (!prompt && node.prompt) prompt = node.prompt;
    if (!img && node.thumbnail && node.thumbnail.url) img = node.thumbnail.url;
    if (!img && node.image && node.image.url) img = node.image.url;
    if (!link && (node.url || node.jump_url)) link = node.url || node.jump_url;
    if (Array.isArray(node.fields)) {
      for (const f of node.fields) if (f && (f.name || f.value)) fields.push({ k: f.name || '', v: f.value || '' });
    }
    // ark_data（群公告等特殊消息）：没有 kv，正文常在 prompt 里，前缀 [群公告] 当作标题
    title = stripCtl(title).trim();
    desc = stripCtl(desc).trim();
    prompt = stripCtl(prompt).trim();
    if (node.prompt) {
      const txt = stripCtl(node.prompt).trim();
      const m = txt.match(/^\[([^\]]{1,12})\]\s*([\s\S]*)$/);
      if (m && !desc) {
        if (!title) title = m[1];
        desc = m[2];
        prompt = '';
      } else if (!desc && !prompt) {
        desc = txt;
      }
    }
    if (!title && node.ark_name) title = stripCtl(String(node.ark_name)).trim();
    if (!img) img = node.pic_url || node.image_url || node.thumbnail_url || '';
    if (!link) link = node.jump_url || node.url || '';
    const rawBtns = Array.isArray(node.buttons) ? node.buttons : Array.isArray(node.button) ? node.button : [];
    return { title, desc, prompt, img, link, fields, buttons: rawBtns };
  }

  function renderCardPreview(payload) {
    const c = cardFromPayload(payload);
    const img = safeUrl(c.img);
    const rows = (c.fields || [])
      .filter((f) => f.v !== undefined && f.v !== null && String(f.v) !== '')
      .slice(0, 8)
      .map((f) => `<div class="card-row"><span>${esc(f.k)}</span><b>${esc(String(f.v))}</b></div>`)
      .join('');
    const btns = (c.buttons || [])
      .slice(0, 6)
      .map((b) => {
        const label = (b && (b.text || (b.render_data && b.render_data.label) || b.label)) || '按钮';
        return `<button class="btn btn-sm" disabled>${esc(label)}</button>`;
      })
      .join('');
    if (!c.title && !c.desc && !img && !rows && !c.prompt) return '';
    const link = safeUrl(c.link);
    return `<div class="msg-card">
      ${img ? `<img class="msg-card-img" src="${img}" referrerpolicy="no-referrer" loading="lazy" alt="" />` : ''}
      <div class="msg-card-body">
        ${c.title ? `<div class="msg-card-title">${esc(c.title)}</div>` : ''}
        ${c.desc ? `<div class="msg-card-desc">${linkifyHtml(esc(c.desc)).replace(/\n/g, '<br/>')}</div>` : ''}
        ${rows}
        ${c.prompt ? `<div class="msg-card-prompt">${esc(c.prompt)}</div>` : ''}
        ${link ? `<a class="msg-card-link" href="${link}" target="_blank" rel="noreferrer noopener">打开链接</a>` : ''}
        ${btns ? `<div class="msg-card-btns">${btns}</div>` : ''}
      </div>
    </div>`;
  }

  function renderMessagePreview(e) {
    const m = e.message || {};
    const raw = e.raw || {};
    const out = isOutgoing(e);
    const content = normalizeQQMarkdown(stripCtl(m.content || ''));
    let payload = null;
    const trimmed = content.trim();
    if (/^[\[{]/.test(trimmed)) {
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed && (parsed.ark || parsed.embed || parsed.card || parsed.prompt || parsed.title)) payload = parsed;
      } catch {
        /* 普通文本 */
      }
    }
    if (!payload) {
      for (const k of ['ark', 'embed', 'card']) {
        if (raw && raw[k]) {
          payload = { [k]: raw[k] };
          break;
        }
      }
    }
    if (!payload && raw && raw.ark_data) payload = { ark_data: raw.ark_data };
    // 机器人发出时记录的原始 body（v1.6.2+）：markdown / card / media 都能还原
    const body = m.payload || (raw && raw.body) || null;
    let mdBody = '';
    let mediaInfo = null;
    if (body && typeof body === 'object') {
      if (!payload) {
        if (body.ark) payload = { ark: body.ark };
        else if (body.card) payload = { card: body.card };
        else if (body.embed) payload = { embed: body.embed };
      }
      const md = body.markdown;
      if (md) mdBody = stripCtl(typeof md === 'string' ? md : String(md.content || ''));
      if (body.media && body.media.file_info) mediaInfo = body.media.file_info;
    }
    const atts = [...(Array.isArray(m.attachments) ? m.attachments : []), ...(Array.isArray(raw.attachments) ? raw.attachments : [])];
    const imgs = atts.filter((a) => a && /^image\//i.test(String(a.content_type || '')) && safeUrl(a.url || a.voice_wav_url));
    const files = atts.filter((a) => a && !/^image\//i.test(String(a.content_type || '')));
    const cardHtml = payload ? renderCardPreview(payload) : '';
    let textHtml = '';
    if (!cardHtml) {
      if (mdBody) {
        textHtml = `<div class="msg-md">${renderMarkdown(mdBody)}</div>`;
      } else if (mediaInfo) {
        const fi = typeof mediaInfo === 'string' ? mediaInfo : String(mediaInfo.file_info || '');
        const size = typeof mediaInfo === 'object' ? Number(mediaInfo.file_size) || 0 : 0;
        textHtml = `<div class="msg-text muted">富媒体消息${size ? `（${(size / 1024).toFixed(1)} KB）` : ''}${fi ? `<br/><span class="mono" style="font-size:11px;word-break:break-all">${esc(fi)}</span>` : ''}</div>`;
      } else if (content) {
        if (content === '[卡片消息]' || content === '[富媒体消息]') {
          textHtml = `<div class="msg-text muted">${esc(content)}（具体内容见下方原始事件）</div>`;
        } else if (/(^|\n)(#{1,6}\s|[-*+]\s|\d+[.)]\s|>\s)|\*\*|`|\[[^\]]+\]\([^)]+\)/.test(content)) {
          textHtml = `<div class="msg-md">${renderMarkdown(content)}</div>`;
        } else {
          textHtml = `<div class="msg-text">${linkifyHtml(esc(content)).replace(/\n/g, '<br/>')}</div>`;
        }
      }
    }
    const imgHtml = imgs
      .map((a) => {
        const u = safeUrl(a.url || a.voice_wav_url);
        return u ? `<a href="${u}" target="_blank" rel="noreferrer noopener"><img class="bubble-img" src="${u}" referrerpolicy="no-referrer" loading="lazy" alt="" /></a>` : '';
      })
      .join('');
    const fileHtml = files
      .map((a) => {
        const u = safeUrl(a.url);
        const name = esc(a.filename || a.content_type || '附件');
        return `<div class="att-item"><div class="att-ico">📎</div><div class="att-meta"><span class="att-name">${name}</span><div class="item-sub">${esc(a.content_type || '')}${a.size ? ' · ' + (a.size / 1024).toFixed(1) + ' KB' : ''}</div></div>${u ? `<a class="btn btn-sm btn-ghost" href="${u}" target="_blank" rel="noreferrer">打开</a>` : ''}</div>`;
      })
      .join('');
    const btnHtml = (Array.isArray(m.elements) ? m.elements : [])
      .map((el) => {
        const label = (el && ((el.render_data && el.render_data.label) || el.text || el.label)) || '';
        return label ? `<button class="btn btn-sm" disabled>${esc(label)}</button>` : '';
      })
      .filter(Boolean)
      .join('');
    const author = m.author || {};
    const initial = esc(String(author.username || accountName(e.accountId) || '?').slice(0, 1));
    const avatar = safeUrl(author.avatar);
    const empty = !textHtml && !cardHtml && !imgHtml && !fileHtml && !btnHtml;
    return `<div class="msg-preview">
      <div class="msg-preview-head">
        <span class="user-avatar" style="width:34px;height:34px;font-size:13px">${avatar ? `<img src="${avatar}" alt="" referrerpolicy="no-referrer" />` : initial}</span>
        <div style="min-width:0">
          <div style="font-weight:600">${esc(author.username || accountName(e.accountId) || '未知')}</div>
          <div class="item-sub">${out ? '机器人发出的消息' : '收到的消息'} · ${fmtDateTime(e.ts)}</div>
        </div>
        <div class="spacer"></div>
        <span class="badge ${out ? 'info' : 'ok'}">${out ? '发出' : '收到'}</span>
      </div>
      ${empty ? '<div class="item-sub">这条消息没有可渲染的正文（见下方原始事件）</div>' : ''}
      ${textHtml}
      ${cardHtml}
      ${imgHtml ? `<div class="bubble-imgs">${imgHtml}</div>` : ''}
      ${fileHtml ? `<div class="att-list" style="margin-top:8px">${fileHtml}</div>` : ''}
      ${btnHtml ? `<div class="msg-card-btns">${btnHtml}</div>` : ''}
    </div>`;
  }

  function openEventDrawer(id) {
    const e = state.events.find((x) => x.id === id);
    if (!e) return;
    const m = e.message || {};
    const ge = isGroupEvent(e);
    const out = isOutgoing(e);
    const gmeta = ge ? GROUP_EVENT_META[e.name] : null;
    const gid = eventGroupId(e);
    const actor = eventActor(e);
    const [kl, kc] = ge ? [gmeta.label, gmeta.badge] : out ? ['发出', 'info'] : kindMeta(m.kind || 'other');
    const target = m.group_openid || m.user_openid || m.channel_id || '';
    const type = m.kind === 'group' ? 'group' : m.kind === 'c2c' ? 'c2c' : 'channel';
    const atts = Array.isArray(m.attachments) ? m.attachments : [];
    const attachmentHtml = atts.length
      ? `<h4 style="margin:0 0 8px;font-size:13px">附件（${atts.length}）</h4>
         <div class="att-list">${atts
           .map((a) => {
             const href = a.url || '';
             const isImg = String(a.content_type || '').startsWith('image/');
             const size = a.size ? `${(a.size / 1024).toFixed(1)} KB` : '';
             const dims = a.width && a.height ? `${a.width}×${a.height}` : '';
             const name = esc(a.filename || a.content_type || '附件');
             return `<div class="att-item">
               ${
                 isImg && href
                   ? `<a href="${esc(href)}" target="_blank" rel="noreferrer"><img class="att-thumb" src="${esc(href)}" alt="" referrerpolicy="no-referrer" loading="lazy" /></a>`
                   : '<div class="att-ico">📎</div>'
               }
               <div class="att-meta">
                 ${href ? `<a class="att-name" href="${esc(href)}" target="_blank" rel="noreferrer">${name}</a>` : `<span class="att-name">${name}</span>`}
                 <div class="item-sub">${esc(a.content_type || '')}${size ? ' · ' + size : ''}${dims ? ' · ' + dims : ''}${href ? '' : ' · 链接缺失'}</div>
                 ${a.voice_wav_url ? `<a class="item-sub" href="${esc(a.voice_wav_url)}" target="_blank" rel="noreferrer">语音 WAV</a>` : ''}
               </div>
               ${href ? `<a class="btn btn-sm btn-ghost" href="${esc(href)}" target="_blank" rel="noreferrer">打开</a>` : ''}
             </div>`;
           })
           .join('')}</div>`
      : '';
    const body = `
      <div class="row" style="margin-bottom:14px">
        <span class="badge ${kc}">${kl}</span>
        <span class="acct-badge">${esc(accountName(e.accountId))}</span>
        <span class="badge">${esc(e.name)}</span>
        <span class="item-sub">${fmtDateTime(e.ts)}</span>
        <span class="badge violet">${esc(e.source)}</span>
      </div>
      ${ge ? '' : `<h4 style="margin:0 0 8px;font-size:13px">消息预览</h4>${renderMessagePreview(e)}`}
      <dl class="kv" style="margin-bottom:16px">
        ${ge ? `<dt>事件</dt><dd>${esc(gmeta.label)}（${esc(e.name)}）</dd>` : ''}
        ${out ? `<dt>方向</dt><dd>机器人发出（${esc(e.source || 'api')}）</dd>` : ''}
        ${ge ? `<dt>说明</dt><dd>${esc(groupEventText(e))}</dd>` : ''}
        ${ge && gid ? `<dt>群 OpenID</dt><dd>${esc(gid)}</dd>` : ''}
        ${ge && actor ? `<dt>成员 / 操作人</dt><dd>${esc(actor)}</dd>` : ''}
        ${ge && e.raw?.verify_info ? `<dt>验证信息</dt><dd>${esc(e.raw.verify_info)}</dd>` : ''}
        ${ge && e.raw?.apply_source ? `<dt>申请来源</dt><dd>${esc(e.raw.apply_source)}</dd>` : ''}
        ${m.id ? `<dt>消息 ID</dt><dd>${esc(m.id)}</dd>` : ''}
        ${m.author?.id ? `<dt>发送者</dt><dd>${esc(m.author.username || '')} · ${esc(m.author.id)}</dd>` : ''}
        ${m.group_openid ? `<dt>群 OpenID</dt><dd>${esc(m.group_openid)}</dd>` : ''}
        ${m.user_openid ? `<dt>用户 OpenID</dt><dd>${esc(m.user_openid)}</dd>` : ''}
        ${m.channel_id ? `<dt>子频道</dt><dd>${esc(m.channel_id)}</dd>` : ''}
        ${m.command?.name ? `<dt>命令解析</dt><dd>${esc(m.command.name)} ${esc((m.command.args || []).join(' '))}</dd>` : ''}
      </dl>
      ${attachmentHtml}
      <h4 style="margin:0 0 8px;font-size:13px">原始事件</h4>
      <pre class="code" style="max-height:300px">${esc(JSON.stringify(e, null, 2))}</pre>
      ${
        m.id && !out && !ge
          ? `<h4 style="margin:18px 0 8px;font-size:13px">快速回复（使用 ${esc(accountName(e.accountId))} 的凭证）</h4>
             <div class="field"><textarea id="reply-text" placeholder="输入要回复的内容">收到：${esc(m.cleanContent || '')}</textarea></div>
             <button class="btn btn-primary" data-act="send-reply" data-type="${type}" data-target="${esc(target)}" data-msgid="${esc(m.id)}" data-account="${esc(e.accountId || '')}">发送回复</button>`
          : ''
      }`;
    openDrawer(ge ? '群事件详情' : out ? '机器人消息' : '消息详情', body);
  }

  /* ================= 连接 ================= */

  const FALLBACK_INTENTS = [
    { name: 'GUILDS', bit: 1 << 0, group: '频道', label: '频道基础', desc: '频道创建 / 更新 / 删除', risk: false },
    { name: 'GUILD_MEMBERS', bit: 1 << 1, group: '频道', label: '频道成员', desc: '成员加入 / 资料变更 / 移除', risk: false },
    { name: 'GUILD_MODERATION', bit: 1 << 2, group: '频道', label: '频道管理', desc: '频道审计等管理事件', risk: true },
    { name: 'GUILD_EMOJIS_AND_STICKERS', bit: 1 << 3, group: '频道', label: '频道表情与贴纸', desc: '表情、贴纸变更', risk: true },
    { name: 'GUILD_VOICE_STATES', bit: 1 << 6, group: '频道', label: '频道语音状态', desc: '语音频道进出状态', risk: true },
    { name: 'GUILD_MESSAGES', bit: 1 << 9, group: '频道', label: '频道全量消息', desc: '频道内全部消息（仅私域机器人）', risk: true },
    { name: 'GUILD_MESSAGE_REACTIONS', bit: 1 << 10, group: '频道', label: '频道表情表态', desc: '消息表情表态添加 / 移除', risk: false },
    { name: 'DIRECT_MESSAGE', bit: 1 << 12, group: '频道', label: '频道私信', desc: '用户与机器人的频道私信', risk: false },
    { name: 'PUBLIC_GUILD_MESSAGES', bit: 1 << 30, group: '频道', label: '频道 @ 消息', desc: '公域频道里 @ 机器人的消息', risk: false },
    { name: 'MESSAGE_AUDIT', bit: 1 << 27, group: '频道', label: '消息审核结果', desc: '消息审核通过 / 拒绝（需申请）', risk: true },
    { name: 'FORUMS_EVENT', bit: 1 << 28, group: '频道', label: '论坛事件', desc: '主题 / 帖子 / 评论（仅私域）', risk: true },
    { name: 'AUDIO_ACTION', bit: 1 << 29, group: '频道', label: '音频房事件', desc: '上麦 / 下麦 / 播放（需申请）', risk: true },
    { name: 'GROUP_AND_C2C_EVENT', bit: 1 << 25, group: '群聊 / 单聊', label: '群聊与单聊消息', desc: '群 @ 消息、单聊消息、好友与进退群事件', risk: false },
    { name: 'INTERACTION', bit: 1 << 26, group: '互动', label: '互动事件', desc: '按钮回调、指令面板等互动', risk: false },
  ];

  function intentMeta(name) {
    const list = state.intents.length ? state.intents : FALLBACK_INTENTS;
    return list.find((i) => i.name === name) || null;
  }

  function intentGroupsHtml(selected, defs) {
    const pref = ['群聊 / 单聊', '频道', '互动'];
    const groups = [...new Set(defs.map((i) => i.group))].sort((a, b) => {
      const ia = pref.indexOf(a);
      const ib = pref.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    if (!groups.includes(state.intentTab)) state.intentTab = groups[0];
    const tabs = groups
      .map((g) => {
        const items = defs.filter((i) => i.group === g);
        const on = items.filter((i) => selected.has(i.name)).length;
        return `<button type="button" class="${state.intentTab === g ? 'on' : ''}" data-act="intent-tab" data-group="${esc(g)}">${esc(g)}<em>${on}/${items.length}</em></button>`;
      })
      .join('');
    const panels = groups
      .map((g) => {
        const items = defs.filter((i) => i.group === g);
        return `<div class="intent-group ${state.intentTab === g ? 'on' : ''}" data-group="${esc(g)}">
          <div class="chips">${items
            .map(
              (i) =>
                `<span class="chip intent-chip ${selected.has(i.name) ? 'on' : ''} ${i.risk ? 'risk' : ''}" data-act="intent-toggle" data-intent="${esc(i.name)}" title="${esc(i.desc || '')}"><b>${esc(i.label)}</b><small>${esc(i.name)}</small>${i.risk ? '<em>需权限</em>' : ''}</span>`,
            )
            .join('')}</div>
        </div>`;
      })
      .join('');
    return `<div class="segmented intent-tabs">${tabs}</div><div class="intent-groups">${panels}</div>`;
  }

  function updateIntentCounts() {
    $$('.intent-tabs button').forEach((btn) => {
      const g = btn.dataset.group;
      const panel = document.querySelector(`.intent-group[data-group="${g}"]`);
      if (!panel) return;
      const total = panel.querySelectorAll('.intent-chip').length;
      const on = panel.querySelectorAll('.intent-chip.on').length;
      const em = btn.querySelector('em');
      if (em) em.textContent = `${on}/${total}`;
    });
  }

  function openIntentWarn(name) {
    const meta = intentMeta(name);
    openModal(
      '该 Intent 需要平台权限',
      `<p style="margin-top:0">${esc(meta?.label || name)}（<code>${esc(name)}</code>）通常需要开放平台单独开通；没有权限时，网关会以 <b>4014</b> 直接断开连接。</p>
       <p class="item-sub">框架已自动保持关闭。如果确认机器人已开通该权限，可以手动开启。</p>`,
      `<button class="btn btn-ghost" data-close="modal">知道了（保持关闭）</button>
       <button class="btn btn-primary" data-act="intent-force-on" data-intent="${esc(name)}">仍然开启</button>`,
    );
  }

  function pageConnection() {
    const st = state.status;
    const acc = activeAccount();
    if (!st || !acc) return `<div class="card empty"><b>还没有账户</b>先去「账户」页添加一个</div>`;
    const gw = acc.gateway || {};
    const [label, cls] = connMeta(acc.state);
    const selected = new Set(acc.intents || []);
    const intentDefs = state.intents.length ? state.intents : FALLBACK_INTENTS;
    const mask = intentDefs.reduce((a, i) => a | (selected.has(i.name) ? i.bit : 0), 0);
    const webhookUrl = location.origin + acc.webhookPath;
    const token = acc.token || {};
    const ttl = token.ttlLeft || 0;
    const pct = clamp((ttl / 7200000) * 100, 0, 100);

    return `
    <div class="card">
      <div class="card-head">
        <h3 class="card-title">接入方式 <small>${esc(acc.name)}</small></h3>
        <div class="segmented">
          <button class="${acc.mode !== 'webhook' ? 'on' : ''}" data-act="set-mode" data-mode="ws" data-id="${esc(acc.id)}">WebSocket</button>
          <button class="${acc.mode === 'webhook' ? 'on' : ''}" data-act="set-mode" data-mode="webhook" data-id="${esc(acc.id)}">WebHook</button>
        </div>
      </div>
      <p class="item-sub">${
        acc.mode === 'webhook'
          ? '平台通过 HTTPS 回调推送事件。每个账户有独立回调路径，需要在其开放平台后台分别填写；端口仅支持 80 / 443 / 8080 / 8443。'
          : '框架主动连接 QQ 网关，支持心跳、断线重连与会话恢复（resume），适合本地或内网部署。'
      }</p>
    </div>

    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3 class="card-title">WebSocket 状态</h3>
          <span class="badge ${cls}">${esc(label)}</span>
        </div>
        <dl class="kv">
          <dt>网关地址</dt><dd>${esc(gw.url || '（未获取）')}</dd>
          <dt>会话 ID</dt><dd>${esc(gw.sessionId || '—')}</dd>
          <dt>事件序号</dt><dd>${gw.seq ?? '—'}</dd>
          <dt>心跳延迟</dt><dd>${gw.latency || 0} ms</dd>
          <dt>分片</dt><dd>[${(gw.shard || [0, 1]).join(', ')}]</dd>
          <dt>重连次数</dt><dd>${gw.reconnects || 0}${gw.round ? `（第 ${gw.round} 轮冷却后继续）` : ''}</dd>
          <dt>本轮已重试</dt><dd>${gw.attempts || 0} / 8${gw.cooldownUntil ? ` · 冷却剩余 ${Math.max(0, Math.ceil((gw.cooldownUntil - Date.now()) / 1000))} 秒` : ''}</dd>
          <dt>最近错误</dt><dd style="color:${gw.lastError ? 'var(--danger)' : 'var(--dim)'}">${esc(gw.lastError || '无')}</dd>
        </dl>
        <div class="row" style="margin-top:16px">
          <button class="btn btn-primary" data-act="account-restart" data-id="${esc(acc.id)}">重连</button>
          <button class="btn" data-act="account-stop" data-id="${esc(acc.id)}">断开</button>
          <button class="btn btn-ghost" data-act="account-start" data-id="${esc(acc.id)}">启动</button>
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">事件订阅 Intents</h3>
          <span class="item-sub mono">0x${Number(mask).toString(16)}</span>
        </div>
        <div class="chips" style="margin-bottom:14px">
          ${intentGroupsHtml(selected, intentDefs)}
        </div>
        <div class="input-row">
          <label class="field"><span class="field-label">分片 ID</span><input id="shard-id" type="number" value="${acc.shardId ?? 0}" /></label>
          <label class="field"><span class="field-label">分片总数</span><input id="shard-count" type="number" value="${acc.shardCount ?? 1}" /></label>
        </div>
        <button class="btn" data-act="save-intents" data-id="${esc(acc.id)}">保存并重连</button>
        <button class="btn btn-sm btn-ghost" data-act="intents-all">全选</button>
        <p class="field-hint" style="margin-top:10px">无权限的 Intent 会导致网关 4013/4014 关闭连接，请只勾选已开通的事件。默认只勾选公共消息集合。</p>
      </div>
    </div>

    <div class="grid g2">
      <div class="card">
        <div class="card-head">
          <h3 class="card-title">WebHook 回调</h3>
          <button class="btn btn-sm" data-act="copy" data-copy="${esc(webhookUrl)}">复制地址</button>
        </div>
        <div class="field">
          <span class="field-label">当前账户回调地址</span>
          <input type="text" value="${esc(webhookUrl)}" readonly />
        </div>
        <dl class="kv">
          <dt>验签</dt><dd>${st.config?.webhook?.verifySignature ? '已开启（Ed25519）' : '已关闭'}</dd>
          <dt>接收</dt><dd>${acc.webhook?.received ?? 0} 次</dd>
          <dt>验签通过</dt><dd>${acc.webhook?.verified ?? 0} 次</dd>
          <dt>拒绝</dt><dd>${acc.webhook?.rejected ?? 0} 次</dd>
        </dl>
        <p class="field-hint" style="margin-top:10px">每个账户路径不同，需分别到各自开放平台后台填写；本地调试可用内网穿透映射到 ${esc(location.origin)}。</p>
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">访问凭证</h3>
          <button class="btn btn-sm" data-act="refresh-token" data-id="${esc(acc.id)}">刷新</button>
        </div>
        <div class="row between" style="margin-bottom:8px">
          <span class="badge ${token.hasToken ? 'ok' : 'err'}">${token.hasToken ? '有效' : '未获取'}</span>
          <span class="mono" style="font-size:12px;color:var(--muted)">剩余 ${fmtDur(ttl)}</span>
        </div>
        <div class="progress ${pct < 15 ? 'danger' : pct < 40 ? 'warn' : ''}"><i style="width:${pct}%"></i></div>
        <dl class="kv" style="margin-top:14px">
          <dt>到期时间</dt><dd>${token.expiresAt ? fmtDateTime(token.expiresAt) : '—'}</dd>
          <dt>刷新策略</dt><dd>到期前 60 秒自动刷新</dd>
          <dt>调用统计</dt><dd>${fmtNum(acc.api?.total)} 次 / 失败 ${fmtNum(acc.api?.fail)}</dd>
        </dl>
      </div>
    </div>`;
  }

  /* ================= 接口 ================= */

  function pageApi() {
    const acc = activeAccount();
    return `
    <div class="api-layout">
      <div class="api-groups">
        <button class="api-group ${state.apiGroup === '全部' ? 'on' : ''}" data-act="api-group" data-group="全部">全部 <em>${state.endpoints.length}</em></button>
        ${state.groups
          .map(
            (g) =>
              `<button class="api-group ${state.apiGroup === g ? 'on' : ''}" data-act="api-group" data-group="${esc(g)}">${esc(g)} <em>${state.endpoints.filter((e) => e.group === g).length}</em></button>`,
          )
          .join('')}
      </div>
      <div>
        <div class="card flat" style="margin-bottom:14px">
          <div class="row between">
            <input id="api-search" type="text" placeholder="搜索接口名 / 路径，例如 发送群聊消息" style="max-width:330px" />
            <div class="row">
              <span class="badge info">当前账户：${esc(acc?.name || '无')}</span>
              <span class="badge">${state.endpoints.length} 个接口</span>
              <button class="btn btn-sm btn-ghost" data-act="copy" data-copy="${esc(state.pluginToken)}">复制插件令牌</button>
            </div>
          </div>
        </div>
        <div id="api-list" class="api-list">${apiListHtml()}</div>
      </div>
    </div>`;
  }

  function apiListHtml() {
    const q = state.apiQuery.trim().toLowerCase();
    let list = state.endpoints
      .filter((e) => state.apiGroup === '全部' || e.group === state.apiGroup)
      .filter((e) => !q || `${e.name} ${e.key} ${e.path}`.toLowerCase().includes(q));
    list = list.slice().sort((a, b) => (METHOD_ORDER[a.method] ?? 9) - (METHOD_ORDER[b.method] ?? 9));
    if (!list.length) return `<div class="card empty">没有匹配的接口</div>`;
    return list
      .map(
        (e) => `<div class="api-item" data-act="open-api" data-key="${esc(e.key)}">
          <span class="method ${e.method}">${e.method}</span>
          <span class="api-name">${esc(e.name)}</span>
          <span class="spacer"></span>
          <span class="api-path">${esc(e.path)}</span>
        </div>`,
      )
      .join('');
  }

  function renderApiList() {
    const el = $('#api-list');
    if (el) el.innerHTML = apiListHtml();
  }

  function openEndpoint(key) {
    const ep = state.endpoints.find((e) => e.key === key);
    if (!ep) return;
    const acc = activeAccount();
    const params = ep.params || [];
    const query = ep.query || [];
    const bodyExample = ep.bodyExample ? JSON.stringify(ep.bodyExample, null, 2) : '';
    const html = `
      <div class="row" style="margin-bottom:12px">
        <span class="method ${ep.method}">${ep.method}</span>
        <span class="mono" style="font-size:12.5px;color:var(--muted);word-break:break-all">${esc(ep.path)}</span>
        <span class="spacer"></span>
        ${ep.docs ? `<a class="btn btn-sm btn-ghost" href="${esc(ep.docs)}" target="_blank" rel="noreferrer">官方文档</a>` : ''}
      </div>
      <p class="item-sub">使用账户：<b>${esc(acc?.name || '无')}</b>${acc ? '（' + esc(acc.appIdMasked || '未配置') + '）' : ''}</p>
      ${ep.notes ? `<p class="item-sub" style="margin-bottom:14px">${esc(ep.notes)}</p>` : ''}
      ${
        params.length
          ? `<h4 style="margin:0 0 8px;font-size:13px">路径参数</h4>
             <div class="input-row">${params
               .map(
                 (p) =>
                   `<label class="field"><span class="field-label">${esc(p.name)}${p.required ? ' *' : ''}</span><input type="text" data-param="${esc(p.name)}" placeholder="${esc(p.example || p.desc)}" /></label>`,
               )
               .join('')}</div>`
          : ''
      }
      ${
        query.length
          ? `<h4 style="margin:8px 0 8px;font-size:13px">Query 参数</h4>
             <div class="input-row">${query
               .map(
                 (q) =>
                   `<label class="field"><span class="field-label">${esc(q.name)}</span><input type="text" data-query="${esc(q.name)}" placeholder="${esc(q.example || q.desc)}" /></label>`,
               )
               .join('')}</div>`
          : ''
      }
      ${
        bodyExample
          ? `<h4 style="margin:8px 0 8px;font-size:13px">请求体（JSON）</h4>
             <div class="field"><textarea id="ep-body" style="min-height:150px">${esc(bodyExample)}</textarea></div>`
          : ''
      }
      <div class="row" style="margin-top:6px">
        <button class="btn btn-primary" data-act="api-call" data-key="${esc(ep.key)}">发起调用</button>
        <button class="btn btn-ghost" data-act="api-curl" data-key="${esc(ep.key)}">复制插件调用</button>
      </div>
      <div id="api-result" style="margin-top:16px"></div>`;
    openModal(ep.name, html, '');
  }

  async function callEndpoint(key) {
    const ep = state.endpoints.find((e) => e.key === key);
    if (!ep) return;
    const acc = activeAccount();
    if (!acc) return toast('没有可用账户', 'err');
    const params = {};
    for (const p of ep.params || []) {
      const el = $(`[data-param="${p.name}"]`);
      if (el && el.value.trim()) params[p.name] = el.value.trim();
    }
    for (const p of ep.params || []) {
      if (p.required && !params[p.name]) return toast(`缺少路径参数 ${p.name}`, 'err');
    }
    const query = {};
    for (const q of ep.query || []) {
      const el = $(`[data-query="${q.name}"]`);
      if (el && el.value.trim()) query[q.name] = el.value.trim();
    }
    let body;
    const bodyEl = $('#ep-body');
    if (bodyEl && bodyEl.value.trim()) {
      try {
        body = JSON.parse(bodyEl.value);
      } catch (e) {
        return toast('请求体不是合法 JSON：' + e.message, 'err');
      }
    }
    const box = $('#api-result');
    box.innerHTML = `<div class="item-sub">调用中…</div>`;
    try {
      const r = await api('/api/call', { method: 'POST', body: { accountId: acc.id, key, params, query, body } });
      box.innerHTML = `
        <div class="row" style="margin-bottom:8px">
          <span class="badge ${r.ok ? 'ok' : 'err'}">${r.ok ? '成功' : '失败'}</span>
          <span class="badge">HTTP ${r.status ?? '—'}</span>
          <span class="badge">${r.duration ?? 0} ms</span>
          <span class="badge violet">${esc(accountName(r.accountId))}</span>
          ${r.code ? `<span class="badge warn">code ${esc(r.code)}</span>` : ''}
          ${r.traceId ? `<span class="badge">trace ${esc(String(r.traceId).slice(0, 10))}</span>` : ''}
          <span class="spacer"></span>
          <button class="btn btn-sm btn-ghost" data-act="copy" data-copy-target="api-json">复制 JSON</button>
        </div>
        ${r.message && !r.ok ? `<p class="item-sub" style="color:var(--danger)">${esc(r.message)}</p>` : ''}
        <pre class="code" id="api-json">${esc(JSON.stringify(r.data ?? r, null, 2))}</pre>`;
    } catch (e) {
      box.innerHTML = `<div class="badge err">调用失败</div><p class="item-sub">${esc(e.message)}</p>`;
    }
  }

  /* ================= 插件 ================= */

  function pluginStatusBadge(p) {
    const map = {
      running: ['ok', '运行中'],
      idle: ['', '待启动'],
      starting: ['warn', '启动中'],
      stopped: ['warn', '已停止'],
      error: ['err', '异常'],
      disabled: ['', '已禁用'],
    };
    const [c, t] = map[p.status] || ['', p.status];
    return `<span class="badge ${c}"><i class="dot ${c}"></i>${t}</span>`;
  }

  function typeLabel(t) {
    return { js: 'JS', http: 'HTTP', pull: '拉取', process: '进程', dll: '易语言 DLL' }[t] || t;
  }

  let pluginNoticeTimer = null;

  function clearPluginNotice() {
    clearTimeout(pluginNoticeTimer);
    pluginNoticeTimer = null;
    state.pluginNotice = null;
  }

  function setPluginNotice(type, title, message) {
    clearTimeout(pluginNoticeTimer);
    const at = Date.now();
    state.pluginNotice = { type, title, message, at };
    if (state.page === 'plugins') render();
    pluginNoticeTimer = setTimeout(() => {
      if (state.pluginNotice && state.pluginNotice.at === at) {
        state.pluginNotice = null;
        pluginNoticeTimer = null;
        if (state.page === 'plugins') render();
      }
    }, 5000);
  }

  function pagePlugins() {
    return `
    <div class="card flat">
      <div class="row between">
        <div class="row">
          <span class="badge info">${state.plugins.length} 个插件</span>
          <span class="badge ok">${state.plugins.filter((p) => p.status === 'running').length} 运行中</span>
          <span class="item-sub mono" style="font-size:11px">${esc(state.status?.paths?.plugins || '')}</span>
        </div>
        <div class="row">
          <a class="btn btn-sm" href="/docs.html" target="_blank" rel="noreferrer">开发文档</a>
          <button class="btn btn-sm" data-act="plugin-import">导入插件</button>
          <button class="btn btn-sm" data-act="plugins-reload">重新加载</button>
          <button class="btn btn-sm btn-ghost" data-act="install-sample">安装示例</button>
          <button class="btn btn-sm btn-primary" data-act="plugin-create">新建插件</button>
        </div>
      </div>
    </div>
    ${
      state.pluginNotice
        ? `<div class="action-notice ${state.pluginNotice.type === 'err' ? 'err' : 'ok'}" id="plugin-notice" role="status">
            <span class="action-notice-ico">${state.pluginNotice.type === 'err' ? '!' : '✓'}</span>
            <div style="flex:1;min-width:0">
              <b>${esc(state.pluginNotice.title || (state.pluginNotice.type === 'err' ? '操作失败' : '操作成功'))}</b>
              <div class="item-sub" style="margin-top:2px">${esc(state.pluginNotice.message)}</div>
            </div>
            <button class="icon-btn" data-act="plugin-notice-close" title="关闭提示">✕</button>
          </div>`
        : ''
    }
    <div class="plugin-grid">
      ${
        state.plugins.length
          ? state.plugins
              .map(
                (p) => `<div class="card plugin-card">
          <div class="plugin-top">
            <div class="plugin-ico">${esc((p.name || p.id).slice(0, 1).toUpperCase())}</div>
            <div style="flex:1;min-width:0">
              <div class="plugin-name">${esc(p.name)}</div>
              <div class="plugin-sub mono">${esc(p.id)} · v${esc(p.version)} · ${typeLabel(p.type)} · 优先级 ${p.priority}</div>
              <div class="item-sub" style="font-size:11px;color:var(--dim);margin-top:1px">作者 ${esc(p.author || '未填写')}</div>
            </div>
            ${pluginStatusBadge(p)}
          </div>
          <div class="plugin-desc">${esc(p.description || '（无描述）')}</div>
          <div class="chips">${(p.events || []).slice(0, 4).map((e) => `<span class="chip static">${esc(e)}</span>`).join('')}${(p.events || []).length > 4 ? `<span class="chip static">+${p.events.length - 4}</span>` : ''}</div>
          <div class="row" style="gap:14px;font-size:11.5px;color:var(--dim)">
            <span>分发 ${p.stats?.dispatched || 0}</span>
            <span>平均 ${p.stats?.avgMs || 0}ms</span>
            <span style="color:${p.stats?.errors ? 'var(--danger)' : 'inherit'}">错误 ${p.stats?.errors || 0}</span>
            ${p.queue ? `<span>队列 ${p.queue}</span>` : ''}
          </div>
          ${p.lastError ? `<div class="item-sub" style="color:var(--danger);font-size:11px">${esc(p.lastError)}</div>` : ''}
          <div class="plugin-foot">
            <button class="btn btn-sm" data-act="plugin-toggle" data-id="${esc(p.id)}" data-enabled="${p.enabled ? '0' : '1'}">${p.enabled ? '停用' : '启用'}</button>
            <button class="btn btn-sm" data-act="plugin-reload" data-id="${esc(p.id)}">重载</button>
            <button class="btn btn-sm" data-act="plugin-test" data-id="${esc(p.id)}">测试</button>
            <button class="btn btn-sm" data-act="plugin-update" data-id="${esc(p.id)}" title="用新版本 zip 覆盖代码，保留配置与 data 数据">更新</button>
            <button class="btn btn-sm btn-ghost" data-act="plugin-edit" data-id="${esc(p.id)}">编辑</button>
            <button class="btn btn-sm btn-danger" data-act="plugin-delete" data-id="${esc(p.id)}">删除</button>
          </div>
        </div>`,
              )
              .join('')
          : `<div class="card empty"><b>还没有插件</b>点右上角「安装示例」或「新建插件」开始</div>`
      }
    </div>
    <div class="card">
      <div class="card-head"><h3 class="card-title">外部程序接入（可选）</h3><span class="badge">JS 插件不需要令牌</span></div>
      <p class="item-sub" style="margin-top:0">创建插件不需要令牌，只要名称、版本、作者、介绍。只有你的程序在框架外通过 HTTP 拉事件 / 回动作时，才需要下面的令牌。开发写法见 <a href="/docs.html" target="_blank" rel="noreferrer">插件开发文档</a>。</p>
      <details class="adv">
        <summary>查看插件令牌与接口地址</summary>
        <div class="grid g2" style="margin-top:12px">
          <div>
            <dl class="kv">
              <dt>插件令牌</dt><dd class="mono">${esc(String(state.pluginToken || '').slice(0, 4))}••••••••${esc(String(state.pluginToken || '').slice(-2))}</dd>
              <dt>拉取地址</dt><dd>GET ${esc(state.pluginApiBase)}/pull?plugin=&lt;id&gt;&amp;timeout=25000</dd>
              <dt>动作地址</dt><dd>POST ${esc(state.pluginApiBase)}/action</dd>
              <dt>鉴权方式</dt><dd>Authorization: Bearer &lt;插件令牌&gt;</dd>
            </dl>
          </div>
          <div>
            <p class="item-sub" style="margin-top:0">易语言 / Python / Go / C# 等外部程序：长轮询 <code>/pull</code> 拿事件，处理完 POST <code>/action</code> 回传 <code>reply</code>。事件里带 <code>account_id</code>，动作里带回 <code>accountId</code> 即可用对应账户发送。</p>
            <div class="row">
              <button class="btn btn-sm" data-act="copy" data-copy="${esc(state.pluginToken)}">复制令牌</button>
              <a class="btn btn-sm btn-ghost" href="/docs.html" target="_blank" rel="noreferrer">打开开发文档</a>
            </div>
          </div>
        </div>
      </details>
    </div>`;
  }

  function openPluginEditor(id) {
    clearPluginNotice();
    api(`/api/plugins/${encodeURIComponent(id)}`).then((r) => {
      const files = r.files || {};
      const manifest = files['plugin.json'] || '{}';
      const entryName = r.plugin?.type === 'js' ? 'index.js' : '';
      const entry = entryName ? files[entryName] || '' : '';
      const hasSettings = !!r.plugin?.hasSettings;
      const settingsPane = hasSettings
        ? `<iframe id="plugin-settings-frame" class="api-doc-frame" src="/api/plugins/${encodeURIComponent(id)}/settings?t=${Date.now()}" sandbox="allow-scripts allow-popups" referrerpolicy="no-referrer" title="${esc(r.plugin?.name || id)} 设置"></iframe>
           <div id="plugin-settings-status" class="plugin-settings-status"></div>
           <p class="field-hint" style="margin-top:8px">设置页由插件编写，保存后写入 <code>plugin.json</code> 的 <code>config</code>。页面通过 <code>parent.postMessage({ type: 'jlw-settings-save', config: {...} }, '*')</code> 保存，不能访问面板数据。</p>`
        : `<div class="api-doc-empty">
            <div class="api-doc-empty-ico">SET</div>
            <b>该插件还没有设置页面</b>
            <p class="item-sub">插件作者可以创建 <code>settings.html</code>，在编辑页第一页直接内嵌显示，用于设置插件数据。</p>
            <button class="btn btn-sm btn-primary" data-act="plugin-settings-edit" data-id="${esc(id)}" style="margin-top:6px">创建设置页面</button>
          </div>`;
      const body = `
        <div class="segmented plugin-edit-tabs" id="plugin-edit-tabs">
          <button class="on" data-plugin-tab="settings">设置</button>
          <button data-plugin-tab="code">插件文件</button>
        </div>
        <div id="plugin-edit-pane-settings" class="plugin-edit-pane">
          <div class="row between" style="margin-bottom:10px">
            <div class="row">
              <span class="badge info">设置页</span>
              <span class="mono item-sub">settings.html</span>
            </div>
            ${hasSettings ? `<a class="btn btn-sm" href="/plugin-settings.html?plugin=${encodeURIComponent(id)}" target="_blank" rel="noreferrer">新页面</a>` : ''}
          </div>
          ${settingsPane}
        </div>
        <div id="plugin-edit-pane-code" class="plugin-edit-pane hidden">
          <div class="row" style="margin-bottom:10px">
            <span class="badge info">${esc(r.plugin?.type)}</span>
            <span class="mono item-sub">${esc(r.dir)}</span>
          </div>
          <h4 style="margin:0 0 8px;font-size:13px">plugin.json</h4>
          <div class="field"><textarea id="plugin-manifest" style="min-height:230px">${esc(manifest)}</textarea></div>
          ${
            entryName
              ? `<h4 style="margin:0 0 8px;font-size:13px">${esc(entryName)}</h4>
                 <div class="field"><textarea id="plugin-entry" style="min-height:230px">${esc(entry)}</textarea></div>`
              : ''
          }
        </div>`;
      openModal(`编辑插件 · ${r.plugin?.name || id}`, body, `
        <button class="btn" data-act="plugin-api" data-id="${esc(id)}">API 文档</button>
        <button class="btn" data-act="plugin-settings-edit" data-id="${esc(id)}">编辑设置页</button>
        <button class="btn btn-ghost" data-close="modal">取消</button>
        <button class="btn btn-primary" id="plugin-save-code" data-act="plugin-save" data-id="${esc(id)}" data-entry="${esc(entryName)}">保存并重载</button>
        <button class="btn btn-primary hidden" id="plugin-save-settings" data-act="plugin-settings-save-request" data-id="${esc(id)}">保存设置</button>`, { persistent: true, wide: true });

      state.settingsPluginId = id;
      const tabs = [...document.querySelectorAll('#plugin-edit-tabs [data-plugin-tab]')];
      const switchTab = (tab) => {
        tabs.forEach((b) => b.classList.toggle('on', b.dataset.pluginTab === tab));
        $('#plugin-edit-pane-settings')?.classList.toggle('hidden', tab !== 'settings');
        $('#plugin-edit-pane-code')?.classList.toggle('hidden', tab !== 'code');
        $('#plugin-save-settings')?.classList.toggle('hidden', tab !== 'settings' || !hasSettings);
        $('#plugin-save-code')?.classList.toggle('hidden', tab === 'settings');
      };
      tabs.forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.pluginTab)));
      switchTab('settings');
      const frame = $('#plugin-settings-frame');
      if (frame) {
        frame.addEventListener('load', () => {
          const p = state.plugins.find((x) => x.id === id);
          try {
            frame.contentWindow.postMessage({ type: 'jlw-settings-init', config: p?.config || {} }, '*');
          } catch {
            /* ignore */
          }
        });
      }
    }).catch((e) => toast('打开插件编辑失败：' + e.message, 'err'));
  }

  function defaultApiDoc(name, id) {
    const safeName = String(name || id).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const safeId = String(id).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${safeName} · API 文档</title>
<style>
  body { max-width: 860px; margin: 32px auto; padding: 0 20px; color: #1f2937; font: 14px/1.7 "Microsoft YaHei", "Segoe UI", sans-serif; }
  h1 { margin: 0 0 4px; font-size: 26px; }
  h2 { margin: 28px 0 8px; padding-top: 12px; border-top: 1px solid #e5e7eb; font-size: 18px; }
  .sub { color: #6b7280; margin: 0 0 18px; }
  .tip { padding: 10px 14px; border-left: 3px solid #5b8cff; background: #f3f7ff; color: #475569; border-radius: 0 8px 8px 0; }
  code { padding: 1px 5px; border-radius: 5px; background: #f1f5f9; color: #1d4ed8; font-family: Consolas, monospace; }
  pre { padding: 12px 14px; overflow: auto; border-radius: 8px; background: #0f172a; color: #dbeafe; }
  pre code { padding: 0; background: none; color: inherit; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 8px 10px; border-bottom: 1px solid #e5e7eb; text-align: left; vertical-align: top; }
  th { color: #475569; background: #f8fafc; }
</style>
</head>
<body>
<h1>${safeName}</h1>
<p class="sub">插件 ID：<code>${safeId}</code> · 这里写插件自己的 API / 命令 / 事件说明，供其它插件开发者阅读。</p>
<div class="tip">这份 HTML 保存在插件目录的 <code>api.html</code>，不会执行任何框架接口；可以按自己的需要修改样式和内容。</div>

<h2>命令</h2>
<table>
  <thead><tr><th>命令</th><th>参数</th><th>说明</th></tr></thead>
  <tbody>
    <tr><td><code>/ping</code></td><td>无</td><td>延迟测试</td></tr>
    <tr><td><code>/help</code></td><td>无</td><td>显示帮助</td></tr>
  </tbody>
</table>

<h2>事件</h2>
<p>订阅的事件：<code>GROUP_AT_MESSAGE_CREATE</code>、<code>GROUP_MESSAGE_CREATE</code>、<code>C2C_MESSAGE_CREATE</code>。</p>

<h2>提供给其它插件的接口</h2>
<p>在这里写清楚接口名、输入、输出和示例。例如：</p>
<pre><code>接口：GET /your-plugin/status
返回：{ "ok": true, "data": { ... } }</code></pre>
</body>
</html>`;
  }

  function openPluginApiEditor(id) {
    clearPluginNotice();
    api(`/api/plugins/${encodeURIComponent(id)}`)
      .then((r) => {
        const name = r.plugin?.name || id;
        const html = r.files?.['api.html'] || defaultApiDoc(name, id);
        const body = `
          <div class="row" style="margin-bottom:10px">
            <span class="badge info">API 文档</span>
            <span class="mono item-sub">api.html</span>
          </div>
          <p class="item-sub" style="margin-top:0">写一个完整的 HTML 文件，保存后可在插件卡片点「API」查看。文档运行在沙箱 iframe 中，不能读取面板数据。</p>
          <div class="field"><textarea id="plugin-api-html" class="api-doc-editor" spellcheck="false">${esc(html)}</textarea></div>
          <div id="plugin-api-preview-wrap" class="hidden" style="margin-top:14px">
            <div class="row between" style="margin-bottom:8px">
              <h4 style="margin:0;font-size:13px">预览</h4>
              <button class="btn btn-sm btn-ghost" data-act="plugin-api-preview">刷新预览</button>
            </div>
            <iframe id="plugin-api-preview" class="api-doc-frame" sandbox="allow-scripts allow-popups" referrerpolicy="no-referrer" title="API 文档预览"></iframe>
          </div>`;
        openModal(`API 文档 · ${name}`, body, `
          <button class="btn btn-ghost" data-close="modal">取消</button>
          <button class="btn" data-act="plugin-api-preview">预览</button>
          <button class="btn btn-primary" data-act="plugin-api-save" data-id="${esc(id)}">保存 API 文档</button>`, { persistent: true, wide: true });
      })
      .catch((e) => toast('打开 API 文档失败：' + e.message, 'err'));
  }

  function defaultSettingsDoc(name, id) {
    const safeName = String(name || id).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const safeId = String(id).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${safeName} · 设置</title>
<style>
  body { max-width: 720px; margin: 28px auto; padding: 0 20px; color: #1f2937; font: 14px/1.7 "Microsoft YaHei", "Segoe UI", sans-serif; }
  h1 { margin: 0 0 4px; font-size: 24px; }
  .sub { color: #6b7280; margin: 0 0 20px; }
  label { display: block; margin: 14px 0 6px; color: #475569; font-size: 13px; }
  input { width: 100%; box-sizing: border-box; padding: 9px 11px; border: 1px solid #cbd5e1; border-radius: 8px; font: inherit; }
  button { margin-top: 16px; padding: 9px 18px; border: 0; border-radius: 8px; background: #5b8cff; color: #fff; font: inherit; cursor: pointer; }
  code { padding: 1px 5px; border-radius: 5px; background: #f1f5f9; color: #1d4ed8; }
  #status { margin-top: 10px; color: #16a34a; font-size: 13px; }
  .tip { padding: 10px 14px; border-left: 3px solid #5b8cff; background: #f3f7ff; color: #475569; border-radius: 0 8px 8px 0; }
</style>
</head>
<body>
<h1>${safeName}</h1>
<p class="sub">插件 ID：<code>${safeId}</code> · 这个设置页由插件作者编写。</p>
<div class="tip">修改后点「保存设置」，会写入 <code>plugin.json</code> 的 <code>config</code>。不要在这里放密码或令牌。</div>

<label for="example">示例配置</label>
<input id="example" placeholder="插件自己的配置值" />
<button id="save" type="button">保存设置</button>
<div id="status"></div>

<script>
  var config = {};
  function render() {
    document.getElementById('example').value = config.example || '';
  }
  window.addEventListener('message', function (e) {
    var m = e.data || {};
    if (m.type === 'jlw-settings-init') {
      config = m.config || {};
      render();
    }
    if (m.type === 'jlw-settings-save-request') save();
    if (m.type === 'jlw-settings-saved') {
      var el = document.getElementById('status');
      el.textContent = m.ok ? '设置已保存' : ('保存失败：' + (m.error || ''));
      el.style.color = m.ok ? '#16a34a' : '#dc2626';
    }
  });
  function save() {
    var next = Object.assign({}, config, { example: document.getElementById('example').value });
    parent.postMessage({ type: 'jlw-settings-save', config: next }, '*');
  }
  document.getElementById('save').addEventListener('click', save);
</script>
</body>
</html>`;
  }

  function openPluginSettingsEditor(id) {
    clearPluginNotice();
    api(`/api/plugins/${encodeURIComponent(id)}`)
      .then((r) => {
        const name = r.plugin?.name || id;
        const html = r.files?.['settings.html'] || defaultSettingsDoc(name, id);
        const body = `
          <div class="row" style="margin-bottom:10px">
            <span class="badge info">设置页</span>
            <span class="mono item-sub">settings.html</span>
          </div>
          <p class="item-sub" style="margin-top:0">保存后点「编辑插件」第一页会直接内嵌这个页面。页面通过 <code>parent.postMessage</code> 与框架通信，不能读取面板数据。</p>
          <div class="field"><textarea id="plugin-settings-html" class="api-doc-editor" spellcheck="false">${esc(html)}</textarea></div>
          <div id="plugin-settings-preview-wrap" class="hidden" style="margin-top:14px">
            <div class="row between" style="margin-bottom:8px">
              <h4 style="margin:0;font-size:13px">预览</h4>
              <button class="btn btn-sm btn-ghost" data-act="plugin-settings-preview">刷新预览</button>
            </div>
            <iframe id="plugin-settings-preview" class="api-doc-frame" sandbox="allow-scripts allow-popups" referrerpolicy="no-referrer" title="设置页预览"></iframe>
          </div>`;
        openModal(`设置页 · ${name}`, body, `
          <button class="btn btn-ghost" data-close="modal">取消</button>
          <button class="btn" data-act="plugin-settings-preview">预览</button>
          <button class="btn btn-primary" data-act="plugin-settings-save" data-id="${esc(id)}">保存设置页</button>`, { persistent: true, wide: true });
      })
      .catch((e) => toast('打开设置页失败：' + e.message, 'err'));
  }

  function openPluginApiViewer(id) {
    clearPluginNotice();
    const p = state.plugins.find((x) => x.id === id);
    const name = p?.name || id;
    const hasDoc = !!p?.hasApiDoc;
    const body = `
      <div class="row" style="margin-bottom:10px">
        <span class="badge info">API 文档</span>
        <span class="mono item-sub">api.html</span>
      </div>
      ${
        hasDoc
          ? `<iframe class="api-doc-frame" src="/api/plugins/${encodeURIComponent(id)}/api-doc?t=${Date.now()}" sandbox="allow-scripts allow-popups" referrerpolicy="no-referrer" title="${esc(name)} API 文档"></iframe>`
          : `<div class="api-doc-empty">
              <div class="api-doc-empty-ico">API</div>
              <b>该插件还没有 API 文档</b>
              <p class="item-sub">创建 <code>api.html</code> 后，这里会直接内嵌显示插件自己的 API 页面，而不是源码。</p>
            </div>`
      }`;
    openModal(`插件 API · ${name}`, body, `
      <button class="btn" data-act="plugin-api-edit" data-id="${esc(id)}">${hasDoc ? '编辑 HTML' : '创建 API 文档'}</button>
      ${hasDoc ? `<a class="btn" href="/api/plugins/${encodeURIComponent(id)}/api-doc?t=${Date.now()}" target="_blank" rel="noreferrer">新页面</a>` : ''}
      <button class="btn btn-primary" data-close="modal">关闭</button>`, { wide: true });
  }

  function openPluginTester(id) {
    clearPluginNotice();
    const p = state.plugins.find((x) => x.id === id);
    const acc = activeAccount();
    const body = `
      <p class="item-sub" style="margin-top:0">发送一条模拟事件给插件 <b>${esc(p?.name || id)}</b>，使用账户 <b>${esc(acc?.name || '无')}</b>（不会真的发到 QQ）。</p>
      <div class="input-row">
        <label class="field"><span class="field-label">事件类型</span>
          <select id="test-event">
            <option>GROUP_AT_MESSAGE_CREATE</option>
            <option>C2C_MESSAGE_CREATE</option>
            <option>GROUP_MESSAGE_CREATE</option>
          </select>
        </label>
        <label class="field"><span class="field-label">群 / 用户 OpenID</span><input id="test-openid" type="text" value="TEST_GROUP" /></label>
      </div>
      <label class="field"><span class="field-label">消息内容</span><input id="test-content" type="text" value="/ping" /></label>
      <div id="test-result" style="margin-top:12px"></div>`;
    openModal(`测试插件 · ${p?.name || id}`, body, `
      <button class="btn btn-ghost" data-close="modal">关闭</button>
      <button class="btn btn-primary" data-act="plugin-test-run" data-id="${esc(id)}">发送测试事件</button>`);
  }

  /* ================= 日志 ================= */

  function logLineHtml(rec) {
    const lv = rec.level || 'info';
    const sc = rec.scope ? `<span class="sc">[${esc(rec.scope)}]</span> ` : '';
    const metaText = rec.meta ? ' ' + JSON.stringify(rec.meta) : '';
    const meta = metaText
      ? `<span style="color:var(--dim)"> ${esc(metaText.length > 180 ? metaText.slice(0, 180) + '…' : metaText)}</span>`
      : '';
    return `<div class="log-line"><span class="t">${fmtTime(rec.t)}</span><span class="lv ${lv}">${lv.toUpperCase()}</span><span>${sc}${esc(rec.msg)}${meta}</span></div>`;
  }

  function filteredLogs() {
    const q = state.logQuery.trim().toLowerCase();
    return state.logs.filter((l) => {
      if (state.logLevel && l.level !== state.logLevel) return false;
      if (q && !`${l.msg || ''} ${JSON.stringify(l.meta || {})}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }

  function renderLogLines() {
    const list = filteredLogs().slice(-600);
    return list.map(logLineHtml).join('') || '<div class="empty">暂无匹配日志</div>';
  }

  /** 市场首页地址：带上面板版本号，面板升级后 iframe 一定重新加载，不吃 bfcache/旧缓存 */
  function marketHomeUrl() {
    const v = (state.status && state.status.version) || '0';
    return '/market-proxy/?v=' + encodeURIComponent(v);
  }

  function pageMarket() {
    return `<div class="market-page">
      <div class="market-bar">
        <div>
          <h3 class="card-title" style="margin:0">VloSBoT 插件市场</h3>
          <p class="item-sub" style="margin:3px 0 0">浏览、下载插件本体 / 源码；内嵌自 <code>vlos.jlworld.net</code>，需要联网；按正常网页嵌入，打开固定从市场首页开始。</p>
          <p class="item-sub" style="margin:3px 0 0">登录面板时会用同一个聚龙账户自动登录市场；要换账户或市场显示登录页时，点【市场登录】选账户补登一次（框架重启后通常需要补一次）。</p>
        </div>
        <div class="card-actions">
          <a class="btn btn-sm" href="https://vlos.jlworld.net/" target="_blank" rel="noopener noreferrer">外部打开</a>
          <button class="btn btn-sm" data-act="market-login">市场登录</button>
          <button class="btn btn-sm" data-act="market-refresh">刷新</button>
        </div>
      </div>
      <div class="market-wrap" id="market-wrap">
        <iframe id="market-frame" class="market-frame" src="${marketHomeUrl()}" title="VloSBoT 插件市场" referrerpolicy="no-referrer" allow="clipboard-write"></iframe>
      </div>
    </div>`;
  }

  function pageLogs() {
    const hist = isHistoryDate(state.logDate);
    return `
    <div class="card flat">
      <div class="row between">
        <div class="row">
          <div class="segmented">
            ${[
              ['', '全部'],
              ['info', 'INFO'],
              ['warn', 'WARN'],
              ['error', 'ERROR'],
            ]
              .map(([k, l]) => `<button class="${state.logLevel === k ? 'on' : ''}" data-act="log-level" data-level="${k}">${l}</button>`)
              .join('')}
          </div>
          <div class="row nowrap" style="gap:8px">
            <input id="log-search" type="text" placeholder="搜索日志内容" style="width:190px" />
            <input id="log-date" type="date" value="${esc(state.logDate)}" max="${todayKey()}" title="选择日期查看当天日志" />
            <button class="btn btn-sm ${hist ? '' : 'btn-ghost'}" data-act="log-today">今天</button>
          </div>
          ${hist ? `<span class="badge warn">历史 ${esc(state.logDate)}</span>` : ''}
        </div>
        <div class="row">
          <button class="btn btn-sm" data-act="log-pause" ${hist ? 'disabled' : ''}>${state.paused ? '继续' : '暂停'}</button>
          <button class="btn btn-sm btn-ghost" data-act="clear-logs">清空视图</button>
          <a class="btn btn-sm btn-ghost" href="/api/logs/download${state.logDate ? '?date=' + encodeURIComponent(state.logDate) : ''}">下载</a>
        </div>
      </div>
      ${hist ? `<p class="field-hint" style="margin:8px 0 0">正在查看 <b>${esc(state.logDate)}</b> 的历史日志（只读，实时推送已暂停）；点「今天」回到实时日志。</p>` : ''}
    </div>
    <div class="card" style="padding:10px">
      <div id="log-view" class="log-view" style="max-height:calc(100vh - 250px)">${renderLogLines()}</div>
    </div>`;
  }

  /** 本地日期 YYYY-MM-DD（面板按本机时区） */
  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function isHistoryDate(day) {
    return !!day && day !== todayKey();
  }

  async function loadLogsDate(day) {
    state.logDate = String(day || '');
    try {
      const r = await api('/api/logs?limit=2000' + (state.logDate ? '&date=' + encodeURIComponent(state.logDate) : ''));
      state.logs = r.logs || [];
    } catch (e) {
      toast('读取日志失败：' + e.message, 'err');
    }
    if (state.page === 'logs') render();
  }

  function appendLogLine(rec) {
    const view = $('#log-view');
    if (!view) return;
    if (state.logLevel && rec.level !== state.logLevel) return;
    const q = state.logQuery.trim().toLowerCase();
    if (q && !`${rec.msg || ''} ${JSON.stringify(rec.meta || {})}`.toLowerCase().includes(q)) return;
    const atBottom = view.scrollTop + view.clientHeight >= view.scrollHeight - 40;
    const tpl = document.createElement('template');
    tpl.innerHTML = logLineHtml(rec);
    view.appendChild(tpl.content);
    while (view.children.length > 800) view.removeChild(view.firstChild);
    if (atBottom) view.scrollTop = view.scrollHeight;
  }

  /* ================= 设置 ================= */

  function pageSettings() {
    const s = state.status;
    if (!s) return skeleton();
    const c = s.config || {};
    const srv = c.server || {};
    const wh = c.webhook || {};
    const pl = c.plugins || {};
    const lg = c.log || {};
    const st = c.storage || {};
    const sysRestart = s.system?.restart || { enabled: false, minutes: 0, nextAt: 0 };
    const nextRestartText =
      sysRestart.enabled && sysRestart.nextAt ? `下次重启：${fmtDateTime(sysRestart.nextAt)}` : '启用后按设定分钟数自动重启。';
    return `
    <div class="card" style="border-color:rgba(91,140,255,.3)">
      <div class="row between">
        <div>
          <div style="font-weight:600">账户级配置已移至「账户」页</div>
          <div class="item-sub">AppID / AppSecret / 接入方式 / 前缀 / Intents / WebHook 路径都属于单个账户；这里只保留全局设置。</div>
        </div>
        <button class="btn btn-primary" data-act="goto" data-page="accounts">管理账户</button>
      </div>
    </div>
    <div class="card">
      <div class="card-head">
        <h3 class="card-title">聚龙账户登录</h3>
        <span class="badge ${state.user ? 'ok' : 'err'}">${state.user ? '已登录' : '未登录'}</span>
      </div>
      <div class="row" style="gap:12px;margin-bottom:14px">
        <div class="user-avatar" style="width:42px;height:42px;font-size:16px">${state.user?.avatar ? `<img src="${esc(state.user.avatar)}" alt="">` : esc((state.user?.name || '聚').slice(0, 1))}</div>
        <div style="min-width:0">
          <div style="font-weight:600">${esc(state.user?.name || '未登录')}</div>
          <div class="item-sub mono">${esc(state.user?.email || '')}${state.user?.id ? ' · ' + esc(state.user.id) : ''}</div>
        </div>
        <div class="spacer"></div>
        <button class="btn btn-sm" data-act="jlw-me">刷新资料</button>
        <button class="btn btn-sm btn-ghost" data-act="logout">退出登录</button>
      </div>
      <label class="field"><span class="field-label">聚龙账户站点</span><input id="set-jlw-base" type="text" value="${esc(c.jlw?.baseUrl || '')}" placeholder="https://你的站点域名" /></label>
      <p class="field-hint" style="margin:-6px 0 12px">登录接口：<code>{站点}{c.jlw?.apiPath || '/api/plugin/jl-account'}/login</code></p>
      <div class="row between" style="margin:4px 0 14px">
        <span class="field-label">跳过证书校验（自签名证书）</span>
        <label class="switch"><input id="set-jlw-insecure" type="checkbox" ${c.jlw?.insecureTls ? 'checked' : ''} /><span></span></label>
      </div>
      <div class="row">
        <button class="btn btn-sm btn-primary" data-act="save-settings">保存账户设置</button>
        <button class="btn btn-sm" data-act="jlw-test">测试连接</button>
        <span class="field-hint">密码只在登录时提交给账户服务，不会写入本机；登录态保存在本机 session。</span>
      </div>
    </div>
    <div class="grid g2">
      <div class="card">
        <div class="card-head"><h3 class="card-title">服务与面板</h3><span class="badge ${srv.host === '0.0.0.0' ? 'warn' : ''}">${esc(srv.host)}:${srv.port}</span></div>
        <div class="input-row">
          <label class="field"><span class="field-label">监听地址</span><input id="set-host" type="text" value="${esc(srv.host || '127.0.0.1')}" /></label>
          <label class="field"><span class="field-label">端口</span><input id="set-port" type="number" value="${srv.port || 8686}" /></label>
        </div>
        <div class="row between" style="margin:4px 0 14px">
          <span class="field-label">启动时自动打开浏览器</span>
          <label class="switch"><input id="set-openbrowser" type="checkbox" ${srv.openBrowser !== false ? 'checked' : ''} /><span></span></label>
        </div>
        <div class="row between">
          <span class="field-label">校验 WebHook 签名（Ed25519）</span>
          <label class="switch"><input id="set-verify" type="checkbox" ${wh.verifySignature !== false ? 'checked' : ''} /><span></span></label>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3 class="card-title">插件</h3></div>
        <div class="row between" style="margin:4px 0 14px">
          <span class="field-label">启用插件系统</span>
          <label class="switch"><input id="set-plugins" type="checkbox" ${pl.enabled !== false ? 'checked' : ''} /><span></span></label>
        </div>
        <label class="field"><span class="field-label">单插件超时（毫秒）</span><input id="set-timeout" type="number" value="${pl.defaultTimeoutMs || 8000}" /></label>
        <label class="field"><span class="field-label">事件队列上限</span><input id="set-maxqueue" type="number" value="${pl.maxQueue || 200}" /></label>
        <p class="field-hint" style="margin:0">插件目录：<code>${esc(s.paths?.plugins || '')}</code></p>
      </div>

      <div class="card">
        <div class="card-head"><h3 class="card-title">日志与存储</h3></div>
        <label class="field"><span class="field-label">存储方式</span>
          <select id="set-engine">
            <option value="sqlite" ${(st.engine || 'sqlite') !== 'json' ? 'selected' : ''}>SQLite（jlwbot.db，推荐）</option>
            <option value="json" ${st.engine === 'json' ? 'selected' : ''}>JSON / JSONL 文件</option>
          </select>
          <span class="field-hint">切换会把现有配置/会话/日志/消息迁移到目标格式，然后自动重启。SQLite 用 <code>~JlWBoT/jlwbot.db</code>；JSON 用 <code>config.json</code> + <code>data/sessions.json</code> + <code>logs/*.jsonl</code> + <code>data/messages-*.jsonl</code>。</span>
        </label>
        <label class="field"><span class="field-label">日志级别</span>
          <select id="set-loglevel">
            ${['debug', 'info', 'warn', 'error'].map((l) => `<option value="${l}" ${lg.level === l ? 'selected' : ''}>${l.toUpperCase()}</option>`).join('')}
          </select>
        </label>
        <div class="row between" style="margin:4px 0 10px">
          <span class="field-label">接口调用日志</span>
          <label class="switch"><input id="set-logapi" type="checkbox" ${lg.api !== false ? 'checked' : ''} /><span></span></label>
        </div>
        <div class="row between" style="margin:4px 0 10px">
          <span class="field-label">记录请求/响应内容（打码）</span>
          <label class="switch"><input id="set-logapibody" type="checkbox" ${lg.apiBody === true ? 'checked' : ''} /><span></span></label>
        </div>
        <p class="field-hint" style="margin:-2px 0 14px">成功的接口调用记在 <b>DEBUG</b>（把上面级别调到 DEBUG 才显示）；失败调用记 <b>WARN</b>，默认 INFO 就能看到。内容日志会打码 token/secret 并截断。</p>
        <div class="row between" style="margin:4px 0 14px">
          <span class="field-label">控制台输出</span>
          <label class="switch"><input id="set-logconsole" type="checkbox" ${lg.console !== false ? 'checked' : ''} /><span></span></label>
        </div>
        <div class="row between" style="margin:4px 0 14px">
          <span class="field-label">记录消息到 JSONL</span>
          <label class="switch"><input id="set-storemsg" type="checkbox" ${st.messages !== false ? 'checked' : ''} /><span></span></label>
        </div>
        <label class="field"><span class="field-label">消息保留条数（内存）</span><input id="set-maxmsg" type="number" value="${st.maxMessages || 20000}" /></label>
        <dl class="kv" style="margin-top:6px">
          <dt>数据目录</dt><dd>${esc(s.paths?.data || '')}</dd>
          <dt>日志目录</dt><dd>${esc(s.paths?.logs || '')}</dd>
          <dt>配置文件</dt><dd>${esc(s.paths?.config || '')}</dd>
        </dl>
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">定时重启</h3>
          <span class="badge ${sysRestart.enabled ? 'ok' : ''}">${sysRestart.enabled ? '每 ' + sysRestart.minutes + ' 分钟' : '未启用'}</span>
        </div>
        <div class="row between" style="margin:4px 0 12px">
          <span class="field-label">启用定时重启</span>
          <label class="switch"><input id="set-restart-enabled" type="checkbox" ${sysRestart.enabled ? 'checked' : ''} /><span></span></label>
        </div>
        <label class="field"><span class="field-label">重启间隔（分钟）</span><input id="set-restart-minutes" type="number" min="1" max="10080" value="${sysRestart.minutes || 360}" /></label>
        <p class="field-hint" style="margin:-6px 0 12px">进程内重启：不关启动器窗口，几秒内恢复；会断开网关后重新连接。${nextRestartText}</p>
        <button class="btn btn-sm" data-act="system-restart">立即重启</button>
      </div>

      <div class="card">
        <div class="card-head">
          <h3 class="card-title">版本与更新</h3>
          <span id="upd-badge" class="badge">未检查</span>
        </div>
        <dl class="kv" style="margin:0 0 12px">
          <dt>当前版本</dt><dd id="upd-current">v${esc(s.version || '—')}</dd>
          <dt>更新页最新</dt><dd id="upd-latest">${state.update?.latest ? 'v' + esc(state.update.latest) : '—'}</dd>
          <dt>上次检查</dt><dd id="upd-checked">${state.updateAt ? fmtDateTime(state.updateAt) : '—'}</dd>
        </dl>
        <div class="row" style="flex-wrap:wrap">
          <button class="btn btn-sm btn-primary" data-act="check-update">检查更新</button>
          <button class="btn btn-sm" data-act="update-run" ${state.update?.hasUpdate ? '' : 'disabled'}>下载并重启</button>
          <a class="btn btn-sm btn-ghost" href="https://www.jlworld.net/QQBOT" target="_blank" rel="noopener">打开更新页</a>
        </div>
        <p class="field-hint" style="margin:10px 0 0">也可以点左上角图标检查更新。只有更新页版本<b>高于</b>本机才会提示；更新只覆盖程序文件，保留 <code>~JlWBoT</code>。</p>
      </div>

      <div class="card">
        <div class="card-head"><h3 class="card-title">公网 IP</h3></div>
        <div class="row between" style="margin-bottom:12px">
          <div>
            <div class="mono" style="font-size:16px">${esc(state.ip?.ip || '—')}</div>
            <div class="item-sub">${state.ip?.error ? esc(state.ip.error) : state.ip?.updatedAt ? '更新于 ' + fmtDateTime(state.ip.updatedAt) : '尚未获取'}</div>
          </div>
          <button class="btn btn-sm" data-act="ip-refresh">重新探测</button>
        </div>
        <dl class="kv">
          <dt>探测源</dt><dd>${esc(state.ip?.source || '—')}</dd>
          <dt>主机名</dt><dd>${esc(state.ip?.hostname || '—')}</dd>
          <dt>内网地址</dt><dd>${(state.ip?.local || []).map((l) => esc(l.address)).join('<br/>') || '—'}</dd>
        </dl>
        <p class="field-hint" style="margin-top:10px">公网 IP 由服务端多源探测（ipify / ipip / ipw.cn 等），离线时显示“获取失败”，右上角胶囊可点击复制。</p>
      </div>
    </div>

    <div class="card flat">
      <div class="row between">
        <div>
          <div style="font-weight:600">保存全局配置</div>
          <div class="item-sub">修改端口后需要重启进程才能生效；其余配置立即生效。</div>
        </div>
        <div class="row">
          <button class="btn btn-ghost" data-act="refresh">放弃修改</button>
          <button class="btn btn-primary" data-act="save-settings">保存</button>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h3 class="card-title">关于</h3></div>
      <div class="grid g2">
        <dl class="kv">
          <dt>框架版本</dt><dd>JlWBoT v${esc(s.version)}</dd>
          <dt>Node.js</dt><dd>${esc(s.server.node)}</dd>
          <dt>平台</dt><dd>${esc(s.server.platform)}</dd>
          <dt>进程 PID</dt><dd>${s.server.pid}</dd>
          <dt>面板运行</dt><dd>${fmtDur(s.server.uptime)}</dd>
          <dt>账户数量</dt><dd>${state.accounts.length}</dd>
        </dl>
        <div>
          <p class="item-sub" style="margin-top:0">官方文档：<a href="https://bot.q.qq.com/wiki/develop/api-v2/" target="_blank" rel="noreferrer">QQ 机器人 API v2</a> · 项目文档见 <code>docs/</code> 目录。</p>
          <button class="btn btn-sm" data-act="copy" data-copy="${esc(s.server.dataDir)}">复制数据目录</button>
        </div>
      </div>
    </div>`;
  }

  async function saveSettings() {
    const val = (id) => $(id)?.value?.trim() ?? '';
    const checked = (id) => !!$(id)?.checked;
    const patch = {
      server: {
        host: val('#set-host') || '127.0.0.1',
        port: Number(val('#set-port')) || 8686,
        openBrowser: checked('#set-openbrowser'),
      },
      webhook: {
        verifySignature: checked('#set-verify'),
      },
      plugins: {
        enabled: checked('#set-plugins'),
        defaultTimeoutMs: Number(val('#set-timeout')) || 8000,
        maxQueue: Number(val('#set-maxqueue')) || 200,
      },
      log: {
        level: $('#set-loglevel')?.value || 'info',
        console: checked('#set-logconsole'),
        api: checked('#set-logapi'),
        apiBody: checked('#set-logapibody'),
      },
      system: {
        restart: {
          enabled: checked('#set-restart-enabled'),
          minutes: Math.max(1, Number(val('#set-restart-minutes')) || 360),
        },
      },
      storage: {
        messages: checked('#set-storemsg'),
        maxMessages: Number(val('#set-maxmsg')) || 20000,
      },
      jlw: {
        baseUrl: val('#set-jlw-base'),
        insecureTls: checked('#set-jlw-insecure'),
      },
    };
    try {
      const engine = $('#set-engine')?.value || 'sqlite';
      const curEngine = (state.status?.config?.storage?.engine || 'sqlite') === 'json' ? 'json' : 'sqlite';
      const r = await api('/api/config', { method: 'POST', body: { patch } });
      if (engine !== curEngine) {
        await api('/api/storage/engine', { method: 'POST', body: { engine } });
        toast('存储方式已切换，正在迁移并重启…', 'ok');
        return;
      }
      toast(r.restartRequired ? '已保存，端口变更需重启进程' : '配置已保存', r.restartRequired ? 'warn' : 'ok');
      await refreshAll();
    } catch (e) {
      toast(e.message, 'err');
    }
  }

  /* ================= 抽屉 / 弹窗 ================= */

  function openDrawer(title, html) {
    $('#drawer-title').textContent = title;
    $('#drawer-body').innerHTML = html;
    $('#drawer').classList.remove('hidden');
  }
  function openModal(title, html, footer = '', opts = {}) {
    state.modalPersistent = !!opts.persistent;
    $('#modal-title').textContent = title;
    $('#modal-body').innerHTML = html;
    $('#modal-foot').innerHTML = footer;
    $('#modal').classList.toggle('persistent', state.modalPersistent);
    $('#modal').classList.toggle('wide', !!opts.wide);
    $('#modal').classList.remove('hidden');
  }
  function closeAll() {
    state.modalPersistent = false;
    state.settingsPluginId = null;
    $('#modal').classList.remove('persistent');
    $('#modal').classList.remove('wide');
    $('#drawer').classList.add('hidden');
    $('#modal').classList.add('hidden');
  }

  function openSendTest(prefill = {}) {
    const acc = activeAccount();
    const body = `
      <p class="item-sub" style="margin-top:0">使用账户 <b>${esc(acc?.name || '无')}</b> 发送</p>
      <div class="input-row">
        <label class="field"><span class="field-label">目标类型</span>
          <select id="send-type">
            <option value="group" ${prefill.type === 'group' ? 'selected' : ''}>群聊（group_openid）</option>
            <option value="c2c" ${prefill.type === 'c2c' ? 'selected' : ''}>单聊（user_openid）</option>
            <option value="channel" ${prefill.type === 'channel' ? 'selected' : ''}>频道（channel_id）</option>
          </select>
        </label>
        <label class="field"><span class="field-label">目标 ID</span><input id="send-target" type="text" value="${esc(prefill.target || '')}" placeholder="群 OpenID / 用户 OpenID / 子频道 ID" /></label>
      </div>
      <label class="field"><span class="field-label">内容</span><textarea id="send-content" style="min-height:110px">${esc(prefill.content || '你好，这是一条测试消息')}</textarea></label>
      <div class="input-row">
        <label class="field"><span class="field-label">被动回复 msg_id（可选）</span><input id="send-msgid" type="text" value="${esc(prefill.msg_id || '')}" placeholder="消息事件用；5 分钟内有效" /></label>
        <label class="field"><span class="field-label">msg_seq（可选）</span><input id="send-seq" type="number" value="1" /></label>
      </div>
      <label class="field"><span class="field-label">事件 id（event_id，可选）</span><input id="send-eventid" type="text" value="${esc(prefill.event_id || '')}" placeholder="GROUP_ADD_ROBOT / GROUP_MSG_RECEIVE / INTERACTION_CREATE 用；不能和 msg_id 同时填" /></label>
      <p class="field-hint">msg_id 与 event_id 二选一：消息事件用 msg_id；GROUP_ADD_ROBOT 等事件用 event_id；GROUP_MEMBER_ADD / GROUP_MEMBER_REMOVE 没有被动回复，留空即发主动消息（需主动消息权限）。</p>
      <div id="send-result"></div>`;
    openModal('发送消息', body, `
      <button class="btn btn-ghost" data-close="modal">关闭</button>
      <button class="btn btn-primary" data-act="send-run">发送</button>`);
  }

  function openNewPlugin() {
    clearPluginNotice();
    const body = `
      <p class="item-sub" style="margin-top:0">创建插件不需要令牌。填好名称、版本、作者、介绍即可，插件 ID 由框架自动生成。</p>
      <div class="input-row">
        <label class="field"><span class="field-label">插件名称 <span style="color:var(--danger)">*</span></span><input id="np-name" type="text" maxlength="60" placeholder="例如：天气查询" /></label>
        <label class="field"><span class="field-label">版本</span><input id="np-version" type="text" maxlength="24" value="1.0.0" placeholder="1.0.0" /></label>
      </div>
      <label class="field"><span class="field-label">作者</span><input id="np-author" type="text" maxlength="64" placeholder="你的名字 / 团队名" /></label>
      <label class="field"><span class="field-label">插件介绍</span><textarea id="np-desc" maxlength="500" style="min-height:90px" placeholder="一句话说明这个插件做什么、怎么用"></textarea></label>
      <details class="adv">
        <summary>高级：接入方式（默认「拉取」，可稍后修改）</summary>
        <label class="field" style="margin-top:10px"><span class="field-label">插件类型</span>
          <select id="np-type">
            <option value="pull" selected>拉取 —— 易语言 / 外部程序长轮询（推荐）</option>
            <option value="js">JS —— 框架进程内运行</option>
            <option value="http">HTTP —— 框架把事件推给你的服务</option>
            <option value="process">进程 —— 框架自动拉起 EXE</option>
            <option value="dll">易语言 DLL —— 拉起 DLL 宿主</option>
          </select>
        </label>
      </details>
      <p class="field-hint">创建后可在「编辑」里改 plugin.json、事件订阅和代码；详细写法见插件页的「开发文档」。</p>`;
    openModal('新建插件', body, `
      <button class="btn btn-ghost" data-close="modal">取消</button>
      <button class="btn btn-primary" data-act="plugin-create-run">创建</button>`);
  }

  const IMPORT_TYPES = {
    zip: {
      label: '插件压缩包（.zip）',
      accept: '.zip,application/zip',
      hint: 'zip 根目录或单层子目录里要有 plugin.json；整包解压到新插件目录，不会覆盖同名插件。',
    },
    folder: {
      label: '插件文件夹（多文件）',
      folder: true,
      hint: '选择包含 plugin.json 的插件文件夹，会保留内部相对路径；适合直接从别的机器拷贝插件目录。',
    },
    js: {
      label: 'JS 插件（.js）',
      accept: '.js,text/javascript',
      hint: '自动创建 type=js 的 plugin.json，文件保存为 index.js；插件名称取文件名。',
    },
    dll: {
      label: '易语言 DLL（.dll）',
      accept: '.dll,application/octet-stream',
      hint: '自动创建 type=dll 的 plugin.json，dll.path 指向该文件；仍需自行准备 32 位宿主 EXE。',
    },
    exe: {
      label: '进程插件（.exe）',
      accept: '.exe,application/octet-stream',
      hint: '自动创建 type=process 的 plugin.json，并设为 launch.command；启动参数可稍后编辑。',
    },
    json: {
      label: '插件清单（.json）',
      accept: '.json,application/json',
      hint: '只导入 plugin.json，不会带代码文件；适合先建骨架，再用「编辑」补 index.js。',
    },
  };

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const text = String(reader.result || '');
        const comma = text.indexOf(',');
        resolve(comma >= 0 ? text.slice(comma + 1) : '');
      };
      reader.onerror = () => reject(new Error('读取文件失败：' + file.name));
      reader.readAsDataURL(file);
    });
  }

  async function readImportPayload(type, fileList) {
    const files = Array.from(fileList || []);
    const out = [];
    let total = 0;
    for (const f of files) {
      total += f.size;
      if (total > 12 * 1024 * 1024) throw new Error('导入文件总大小不能超过 12MB');
      out.push({
        name: f.name,
        path: f.webkitRelativePath || f.name,
        data: await fileToBase64(f),
      });
    }
    return out;
  }

  function openPluginUpdate(id) {
    const p = state.plugins.find((x) => x.id === id);
    const name = p?.name || id;
    openModal(
      `更新插件 · ${name}`,
      `<p class="item-sub" style="margin-top:0">当前版本：<b>v${esc(p?.version || '?')}</b> · ID：<code>${esc(id)}</code></p>
      <div class="field">
        <span class="field-label">新版本插件 zip</span>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button type="button" class="btn" id="upd-pick">选择文件</button>
          <span class="item-sub" id="upd-files">未选择文件</span>
        </div>
        <input id="upd-file" type="file" accept=".zip,application/zip" style="display:none" />
      </div>
      <p class="field-hint">只接受同 ID 的 zip。会替换插件代码，保留 <code>plugin.json</code> 里的 <code>config</code>、启用状态和 <code>data/</code> 用户数据；失败会自动回滚。</p>`,
      `<button class="btn btn-ghost" data-close="modal">取消</button>
       <button class="btn btn-primary" data-act="plugin-update-run" data-id="${esc(id)}">开始更新</button>`,
    );
    const input = $('#upd-file');
    const label = $('#upd-files');
    $('#upd-pick').addEventListener('click', () => input.click());
    input.addEventListener('change', () => {
      const f = input.files?.[0];
      label.textContent = f ? `${f.name} · ${fmtBytes(f.size)}` : '未选择文件';
    });
  }

  function openImportPlugin() {
    clearPluginNotice();
    const options = Object.entries(IMPORT_TYPES)
      .map(([key, cfg]) => `<option value="${key}">${esc(cfg.label)}</option>`)
      .join('');
    const body = `
      <label class="field"><span class="field-label">导入类型</span>
        <select id="imp-type">${options}</select>
      </label>
      <p class="field-hint" id="imp-hint"></p>
      <div class="field">
        <span class="field-label">选择文件</span>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button type="button" class="btn" id="imp-pick">选择文件</button>
          <span class="item-sub" id="imp-files">未选择文件</span>
        </div>
        <input id="imp-file" type="file" style="display:none" />
      </div>
      <p class="field-hint">导入前请确认插件来源可信；同名插件不会被覆盖。总大小上限 12MB。</p>`;
    openModal('导入插件', body, `
      <button class="btn btn-ghost" data-close="modal">取消</button>
      <button class="btn btn-primary" data-act="plugin-import-run">开始导入</button>`);

    const typeSel = $('#imp-type');
    const input = $('#imp-file');
    const pick = $('#imp-pick');
    const label = $('#imp-files');
    const hint = $('#imp-hint');

    const applyType = () => {
      const cfg = IMPORT_TYPES[typeSel.value] || IMPORT_TYPES.zip;
      input.value = '';
      input.accept = cfg.accept || '';
      input.multiple = !!cfg.folder;
      if (cfg.folder) {
        input.setAttribute('webkitdirectory', '');
        input.setAttribute('directory', '');
      } else {
        input.removeAttribute('webkitdirectory');
        input.removeAttribute('directory');
      }
      hint.textContent = cfg.hint;
      label.textContent = '未选择文件';
    };
    const showFiles = () => {
      const cfg = IMPORT_TYPES[typeSel.value] || IMPORT_TYPES.zip;
      const files = Array.from(input.files || []);
      if (!files.length) {
        label.textContent = '未选择文件';
        return;
      }
      if (cfg.folder) {
        const root = (files[0].webkitRelativePath || '').split('/')[0] || '文件夹';
        const total = files.reduce((n, f) => n + f.size, 0);
        label.textContent = `${root} · ${files.length} 个文件 · ${fmtBytes(total)}`;
      } else {
        label.textContent = `${files[0].name} · ${fmtBytes(files[0].size)}`;
      }
    };

    typeSel.addEventListener('change', applyType);
    pick.addEventListener('click', () => input.click());
    input.addEventListener('change', showFiles);
    applyType();
  }

  function openDeletePlugin(id) {
    clearPluginNotice();
    const p = state.plugins.find((x) => x.id === id);
    const name = p?.name || id;
    const body = `
      <p style="margin-top:0">确定删除插件 <b>${esc(name)}</b>（<code>${esc(id)}</code>）？</p>
      <div class="card flat" style="padding:12px;border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.06)">
        <div style="color:var(--danger);font-weight:600;margin-bottom:4px">这个操作不可恢复</div>
        <div class="item-sub">插件目录会被整个删除，包含其中的代码、DLL、EXE 和配置：</div>
        <div class="mono" style="font-size:11.5px;margin-top:6px;word-break:break-all">${esc(p?.dir || '')}</div>
      </div>
      <p class="field-hint">如果只是暂时不用，可以点「停用」而不是删除。示例插件删除后可点「安装示例」恢复。</p>`;
    openModal('删除插件', body, `
      <button class="btn btn-ghost" data-close="modal">取消</button>
      <button class="btn btn-danger" data-act="plugin-delete-confirm" data-id="${esc(id)}">确认删除</button>`);
  }

  /* ================= 动作分发 ================= */

  const actions = {
    goto: (d) => {
      if (d.page !== 'plugins') clearPluginNotice();
      state.page = d.page;
      render();
    },
    refresh: () => refreshAll(),
    'market-refresh': () => {
      const f = $('#market-frame');
      if (f) f.src = '/market-proxy/?t=' + Date.now();
    },
    'market-login': async () => {
      const me = ((state.user && state.user.email) || '').trim().toLowerCase();
      let allowed = [];
      try {
        const scope = await api('/api/auth/scope');
        allowed = (scope.allowed || [])
          .map((a) => String((a && a.email) || '').trim().toLowerCase())
          .filter(Boolean);
      } catch {
        /* 读不到登录范围就只显示当前账户 */
      }
      if (me && !allowed.includes(me)) allowed.unshift(me);
      if (!allowed.length && me) allowed = [me];
      const options = allowed
        .map((e) => `<option value="${esc(e)}" ${e === me ? 'selected' : ''}>${esc(e)}${e === me ? '（当前面板账户）' : ''}</option>`)
        .join('');
      openModal(
        '登录插件市场',
        `<p class="item-sub" style="margin-top:0">市场账号和面板账号分开：后台允许多人编辑时，可以选【登录范围】里任意一个聚龙账户登录市场。密码只用于这一次登录，不会保存。</p>
         <label class="field"><span class="field-label">用哪个聚龙账户登录市场</span>
           <select id="market-account">${options || '<option value="">（没有可用账户）</option>'}</select>
           <span class="field-hint">列表来自左下角【登录范围】，默认选当前面板账户。</span>
         </label>
         <label class="field"><span class="field-label">该账户密码</span><input id="market-password" type="password" autocomplete="current-password" placeholder="聚龙账户密码" /></label>
         <div id="market-login-result" class="field-hint"></div>`,
        `<button class="btn btn-ghost" data-close="modal">取消</button>
         <button class="btn btn-primary" data-act="market-login-run">登录</button>`,
      );
    },
    'market-login-run': async () => {
      const mail = ($('#market-account') || {}).value || '';
      const password = ($('#market-password') || {}).value || '';
      const box = $('#market-login-result');
      if (!mail) {
        if (box) box.textContent = '没有可选的聚龙账户，请先在左下角【登录范围】添加';
        return;
      }
      if (!password) {
        if (box) box.textContent = '请填写聚龙账户密码';
        return;
      }
      const btn = $('[data-act="market-login-run"]');
      if (btn) btn.disabled = true;
      if (box) box.textContent = '正在用 ' + mail + ' 登录市场…';
      try {
        const r = await api('/api/market/login', { method: 'POST', body: { password, mail } });
        closeAll();
        toast('插件市场已登录（' + ((r && r.mail) || mail) + '）', 'ok');
        const f = $('#market-frame');
        if (f) f.src = '/market-proxy/?t=' + Date.now();
      } catch (e) {
        if (box) box.textContent = e.message;
        else toast(e.message, 'err');
      } finally {
        if (btn) btn.disabled = false;
      }
    },
    'update-run': () => startUpdate(),
    'check-update': async () => {
      const btn = $('[data-act="check-update"]');
      if (btn) {
        btn.disabled = true;
        btn.textContent = '检查中…';
      }
      try {
        await checkUpdate(true, true);
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.textContent = '检查更新';
        }
      }
    },
    'scope-add': async () => {
      const input = $('#scope-email');
      const email = String(input?.value || '').trim();
      if (!email) return toast('请输入聚龙账户邮箱', 'err');
      try {
        const r = await api('/api/auth/scope', { method: 'POST', body: { email } });
        state.authScope = r;
        renderLoginScopePill();
        toast('已加入登录范围：' + email, 'ok');
        await openLoginScopeModal();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'scope-remove': async (d) => {
      let key = '';
      try {
        key = decodeURIComponent(d.key || '');
      } catch {
        key = d.key || '';
      }
      if (!key) return;
      if (!confirm(`确定从登录范围移除 ${key}？\n移除后该账户将无法登录后台。`)) return;
      try {
        const r = await api('/api/auth/scope/' + encodeURIComponent(key), { method: 'DELETE' });
        state.authScope = r;
        renderLoginScopePill();
        toast('已移除：' + key, 'ok');
        await openLoginScopeModal();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'msg-filter': (d) => {
      state.msgFilter = d.filter;
      if (d.filter === 'all') {
        state.msgGroup = '';
        state.msgGroupAccount = '';
        state.msgGroupName = '';
      }
      render();
    },
    'msg-group-filter': (d) => {
      state.msgGroup = d.group || '';
      state.msgGroupAccount = d.account || '';
      state.msgGroupName = d.name || d.group || '';
      render();
    },
    'msg-group-clear': () => {
      state.msgGroup = '';
      state.msgGroupAccount = '';
      state.msgGroupName = '';
      render();
    },
    'view-event': (d) => openEventDrawer(d.id),
    'send-test': (d) => openSendTest(d),
    'inject-event': async () => {
      const acc = activeAccount();
      if (!acc) return toast('没有可用账户', 'err');
      try {
        await api('/api/events/inject', { method: 'POST', body: { accountId: acc.id, t: 'GROUP_AT_MESSAGE_CREATE', d: { content: '/帮助' } } });
        toast('已注入一条模拟群消息（' + acc.name + '）', 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'refresh-token': async (d) => {
      const acc = d.id ? { id: d.id } : activeAccount();
      if (!acc) return toast('没有可用账户', 'err');
      try {
        await api(`/api/accounts/${encodeURIComponent(acc.id)}/token/refresh`, { method: 'POST', body: {} });
        toast('access_token 已刷新', 'ok');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'ip-refresh': () => refreshIp(true),
    'account-new': () => openAccountModal(''),
    'account-edit': (d) => openAccountModal(d.id),
    'account-save': (d) => saveAccount(d.id),
    'account-active': (d) => {
      state.accountId = d.id;
      localStorage.setItem('jlw-account', d.id);
      renderChrome();
      toast('已切换到 ' + accountName(d.id), 'ok');
      render();
    },
    'account-toggle': async (d) => {
      const enable = d.enabled === '1';
      try {
        // 「启用到池中」：把三项一起打开，保证账户真正进入池子并保持在线
        const body = enable ? { enabled: true, autoConnect: true, autoReconnect: true } : { enabled: false };
        await api('/api/accounts/' + encodeURIComponent(d.id), { method: 'PATCH', body });
        await refreshStatus();
        toast(enable ? '账户已启用到池中' : '账户已停用（整账户禁用）', 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'account-start': async (d) => {
      try {
        await api(`/api/accounts/${encodeURIComponent(d.id)}/start`, { method: 'POST', body: {} });
        toast('正在启动…');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'account-stop': async (d) => {
      try {
        await api(`/api/accounts/${encodeURIComponent(d.id)}/stop`, { method: 'POST', body: {} });
        toast('已断开');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'account-restart': async (d) => {
      try {
        await api(`/api/accounts/${encodeURIComponent(d.id)}/restart`, { method: 'POST', body: {} });
        toast('正在重连…');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'account-delete': async (d) => {
      const acc = state.accounts.find((a) => a.id === d.id);
      if (!confirm(`删除账户「${acc?.name || d.id}」？该账户的凭证与连接会一并移除（数据目录里的日志/消息保留）。`)) return;
      try {
        await api('/api/accounts/' + encodeURIComponent(d.id), { method: 'DELETE' });
        toast('账户已删除', 'ok');
        if (state.accountId === d.id) state.accountId = '';
        await refreshAll();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'account-copy-webhook': (d) => {
      const acc = state.accounts.find((a) => a.id === d.id);
      if (!acc) return;
      copyText(location.origin + acc.webhookPath, '回调地址已复制');
    },
    'set-mode': async (d) => {
      try {
        await api(`/api/accounts/${encodeURIComponent(d.id)}/mode`, { method: 'POST', body: { mode: d.mode } });
        toast('已切换到 ' + (d.mode === 'webhook' ? 'WebHook' : 'WebSocket'), 'ok');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'intent-tab': (d) => {
      state.intentTab = d.group;
      $$('.intent-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.group === d.group));
      $$('.intent-group').forEach((g) => g.classList.toggle('on', g.dataset.group === d.group));
    },
    'intent-toggle': (d, el) => {
      if (!el.classList.contains('on') && intentMeta(d.intent)?.risk) {
        openIntentWarn(d.intent);
        return;
      }
      el.classList.toggle('on');
      updateIntentCounts();
    },
    'intent-force-on': (d) => {
      const chip = document.querySelector(`.intent-chip[data-intent="${d.intent}"]`);
      if (chip) chip.classList.add('on');
      updateIntentCounts();
      closeAll();
      toast('已开启；保存后如果无权限会被网关拒绝并自动回退', 'warn');
    },
    'intents-all': () => {
      $$('.chip[data-intent]').forEach((c) => c.classList.add('on'));
      updateIntentCounts();
      toast('已全选；无权限的 Intent 会导致 4014，请确认机器人已开通对应权限', 'warn');
    },
    'save-intents': async (d) => {
      const intents = $$('.chip[data-intent]')
        .filter((c) => c.classList.contains('on'))
        .map((c) => c.dataset.intent);
      try {
        await api('/api/accounts/' + encodeURIComponent(d.id), {
          method: 'PATCH',
          body: {
            intents,
            shardId: Number($('#shard-id')?.value || 0),
            shardCount: Number($('#shard-count')?.value || 1),
          },
        });
        await api(`/api/accounts/${encodeURIComponent(d.id)}/restart`, { method: 'POST', body: {} });
        toast('Intents 已保存并重连', 'ok');
        await refreshStatus();
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'api-group': (d) => {
      state.apiGroup = d.group;
      render();
    },
    'open-api': (d) => openEndpoint(d.key),
    'api-call': (d) => callEndpoint(d.key),
    'api-curl': (d) => {
      const ep = state.endpoints.find((e) => e.key === d.key);
      if (!ep) return;
      const body = { action: 'endpoint', endpoint: ep.key, params: {}, query: {}, body: ep.bodyExample || {} };
      copyText(JSON.stringify({ plugin: 'el-sample', actions: [body] }, null, 2), '已复制插件调用 JSON（填入 params 后 POST 到 /plugin-api/v1/action）');
    },
    'send-reply': async (d) => {
      const content = $('#reply-text')?.value || '';
      if (!content.trim()) return toast('回复内容为空', 'err');
      try {
        const r = await api('/api/send', {
          method: 'POST',
          body: { accountId: d.account, type: d.type, target: d.target, content, msg_id: d.msgid },
        });
        toast(r.ok ? '回复已发送' : r.message || '发送失败', r.ok ? 'ok' : 'err');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'send-run': async () => {
      const acc = activeAccount();
      if (!acc) return toast('没有可用账户', 'err');
      const type = $('#send-type')?.value;
      const target = $('#send-target')?.value?.trim();
      const content = $('#send-content')?.value || '';
      if (!target) return toast('请填写目标 ID', 'err');
      const msgid = $('#send-msgid')?.value?.trim();
      const eventid = $('#send-eventid')?.value?.trim();
      if (msgid && eventid) return toast('msg_id 与 event_id 只能填一个', 'err');
      const body = { accountId: acc.id, type, target, content };
      if (eventid) {
        body.event_id = eventid;
      } else if (msgid) {
        body.msg_id = msgid;
        body.msg_seq = Number($('#send-seq')?.value || 1);
      }
      try {
        const r = await api('/api/send', { method: 'POST', body });
        $('#send-result').innerHTML = `<div class="badge ${r.ok ? 'ok' : 'err'}">${r.ok ? '发送成功' : '发送失败'}</div><pre class="code" style="margin-top:10px">${esc(JSON.stringify(r.data ?? r, null, 2))}</pre>`;
      } catch (e) {
        $('#send-result').innerHTML = `<div class="badge err">失败</div><p class="item-sub">${esc(e.message)}</p>`;
      }
    },
    'plugins-reload': async () => {
      clearPluginNotice();
      const btn = document.querySelector('[data-act="plugins-reload"]');
      const t0 = Date.now();
      if (btn) {
        btn.disabled = true;
        btn.textContent = '加载中…';
      }
      try {
        await api('/api/plugins/reload', { method: 'POST', body: {} });
        await refreshPlugins();
        setPluginNotice('ok', '全部插件重载成功', `已重新加载 ${state.plugins.length} 个插件，用时 ${Date.now() - t0}ms。`);
      } catch (e) {
        try {
          await refreshPlugins();
        } catch {
          /* 保留原始错误提示 */
        }
        setPluginNotice('err', '全部插件重载失败', `重新加载插件失败：${e.message}`);
      }
    },
    'install-sample': async () => {
      try {
        await api('/api/plugins/install-sample', { method: 'POST', body: {} });
        await refreshPlugins();
        toast('示例插件已安装', 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'plugin-toggle': async (d) => {
      clearPluginNotice();
      const p = state.plugins.find((x) => x.id === d.id);
      const name = p?.name || d.id;
      const enable = d.enabled === '1';
      const btn = [...document.querySelectorAll('[data-act="plugin-toggle"]')].find((b) => b.dataset.id === d.id);
      if (btn) {
        btn.disabled = true;
        btn.textContent = enable ? '启用中…' : '停用中…';
      }
      try {
        await api(`/api/plugins/${encodeURIComponent(d.id)}/enable`, { method: 'POST', body: { enabled: enable } });
        await refreshPlugins();
        setPluginNotice(
          'ok',
          enable ? '插件已启用' : '插件已停用',
          `插件「${name}」（${d.id}）已${enable ? '启用' : '停用'}。`,
        );
      } catch (e) {
        try {
          await refreshPlugins();
        } catch {
          /* 保留原始错误提示 */
        }
        setPluginNotice(
          'err',
          enable ? '插件启用失败' : '插件停用失败',
          `插件「${name}」（${d.id}）${enable ? '启用' : '停用'}失败：${e.message}`,
        );
      }
    },
    'plugin-reload': async (d) => {
      clearPluginNotice();
      const p = state.plugins.find((x) => x.id === d.id);
      const name = p?.name || d.id;
      const btn = [...document.querySelectorAll('[data-act="plugin-reload"]')].find((b) => b.dataset.id === d.id);
      const t0 = Date.now();
      if (btn) {
        btn.disabled = true;
        btn.textContent = '重载中…';
      }
      try {
        await api(`/api/plugins/${encodeURIComponent(d.id)}/reload`, { method: 'POST', body: {} });
        await refreshPlugins();
        setPluginNotice('ok', '插件重载成功', `插件「${name}」（${d.id}）重载成功，用时 ${Date.now() - t0}ms。`);
      } catch (e) {
        try {
          await refreshPlugins();
        } catch {
          /* 保留原始错误提示 */
        }
        setPluginNotice('err', '插件重载失败', `插件「${name}」（${d.id}）重载失败：${e.message}`);
      }
    },
    'plugin-notice-close': () => {
      clearPluginNotice();
      render();
    },
    'plugin-test': (d) => openPluginTester(d.id),
    'plugin-api': (d) => openPluginApiViewer(d.id),
    'plugin-api-edit': (d) => openPluginApiEditor(d.id),
    'plugin-api-preview': () => {
      const html = $('#plugin-api-html')?.value ?? '';
      const wrap = $('#plugin-api-preview-wrap');
      const frame = $('#plugin-api-preview');
      if (!frame) return;
      frame.srcdoc = html;
      wrap?.classList.remove('hidden');
      wrap?.scrollIntoView({ block: 'nearest' });
    },
    'plugin-api-save': async (d) => {
      const html = $('#plugin-api-html')?.value ?? '';
      const p = state.plugins.find((x) => x.id === d.id);
      const name = p?.name || d.id;
      try {
        await api(`/api/plugins/${encodeURIComponent(d.id)}/file`, {
          method: 'POST',
          body: { name: 'api.html', content: html },
        });
        closeAll();
        await refreshPlugins();
        setPluginNotice('ok', 'API 文档已保存', `插件「${name}」（${d.id}）的 api.html 已保存，可从卡片「API」查看。`);
      } catch (e) {
        toast('API 文档保存失败：' + e.message, 'err');
      }
    },
    'plugin-settings-edit': (d) => openPluginSettingsEditor(d.id),
    'plugin-settings-preview': () => {
      const html = $('#plugin-settings-html')?.value ?? '';
      const wrap = $('#plugin-settings-preview-wrap');
      const frame = $('#plugin-settings-preview');
      if (!frame) return;
      frame.srcdoc = html;
      wrap?.classList.remove('hidden');
      wrap?.scrollIntoView({ block: 'nearest' });
    },
    'plugin-settings-save': async (d) => {
      const html = $('#plugin-settings-html')?.value ?? '';
      const p = state.plugins.find((x) => x.id === d.id);
      const name = p?.name || d.id;
      try {
        await api(`/api/plugins/${encodeURIComponent(d.id)}/file`, {
          method: 'POST',
          body: { name: 'settings.html', content: html },
        });
        closeAll();
        await refreshPlugins();
        setPluginNotice('ok', '设置页已保存', `插件「${name}」（${d.id}）的 settings.html 已保存。`);
      } catch (e) {
        toast('设置页保存失败：' + e.message, 'err');
      }
    },
    'plugin-settings-save-request': (d) => {
      const frame = $('#plugin-settings-frame');
      const status = $('#plugin-settings-status');
      if (!frame) return toast('该插件还没有设置页面', 'err');
      if (status) {
        status.textContent = '正在保存…';
        status.className = 'plugin-settings-status';
      }
      frame.contentWindow.postMessage({ type: 'jlw-settings-save-request' }, '*');
    },
    'plugin-edit': (d) => openPluginEditor(d.id),
    'plugin-create': () => openNewPlugin(),
    'plugin-create-run': async () => {
      const name = $('#np-name')?.value?.trim();
      const version = $('#np-version')?.value?.trim() || '1.0.0';
      const author = $('#np-author')?.value?.trim() || '';
      const description = $('#np-desc')?.value?.trim() || '';
      const type = $('#np-type')?.value || 'pull';
      if (!name) return toast('请填写插件名称', 'err');
      try {
        const r = await api('/api/plugins/create', { method: 'POST', body: { name, version, author, description, type } });
        closeAll();
        await refreshPlugins();
        toast(`插件已创建：${r.plugin?.name || name}（ID: ${r.id}）`, 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'plugin-import': () => openImportPlugin(),
    'plugin-update': (d) => openPluginUpdate(d.id),
    'plugin-update-run': async (d) => {
      const id = d.id;
      const input = $('#upd-file');
      const files = Array.from(input?.files || []);
      if (!files.length) return toast('请选择新版本插件 zip', 'err');
      const btn = document.querySelector('#modal-foot [data-act="plugin-update-run"]');
      if (btn) {
        btn.disabled = true;
        btn.textContent = '更新中…';
      }
      try {
        const payload = await readImportPayload('zip', files);
        const r = await api(`/api/plugins/${encodeURIComponent(id)}/update`, {
          method: 'POST',
          body: { files: payload },
        });
        closeAll();
        await refreshPlugins();
        setPluginNotice(
          'ok',
          '插件已更新',
          `插件「${r.plugin?.name || id}」已从 v${r.previousVersion || '?'} 更新到 v${r.version || '?'}，配置与 data 已保留。`,
        );
        toast('插件已更新', 'ok');
      } catch (e) {
        toast('更新失败：' + e.message, 'err');
        if (btn) {
          btn.disabled = false;
          btn.textContent = '开始更新';
        }
      }
    },
    'plugin-import-run': async () => {
      const type = $('#imp-type')?.value || 'zip';
      const input = $('#imp-file');
      const files = Array.from(input?.files || []);
      if (!files.length) return toast('请选择要导入的文件', 'err');
      const btn = document.querySelector('#modal-foot [data-act="plugin-import-run"]');
      if (btn) {
        btn.disabled = true;
        btn.textContent = '导入中…';
      }
      try {
        const payload = await readImportPayload(type, files);
        const r = await api('/api/plugins/import', { method: 'POST', body: { type, files: payload } });
        closeAll();
        await refreshPlugins();
        toast(`已导入：${r.plugin?.name || r.id}`, 'ok');
      } catch (e) {
        toast(e.message, 'err');
        if (btn) {
          btn.disabled = false;
          btn.textContent = '开始导入';
        }
      }
    },
    'plugin-delete': (d) => openDeletePlugin(d.id),
    'plugin-delete-confirm': async (d) => {
      const p = state.plugins.find((x) => x.id === d.id);
      const name = p?.name || d.id;
      try {
        await api(`/api/plugins/${encodeURIComponent(d.id)}`, { method: 'DELETE' });
        closeAll();
        await refreshPlugins();
        setPluginNotice('ok', '插件已删除', `插件「${name}」（${d.id}）已删除，插件目录已移除。`);
      } catch (e) {
        closeAll();
        try {
          await refreshPlugins();
        } catch {
          /* 保留原始错误提示 */
        }
        setPluginNotice('err', '插件删除失败', `插件「${name}」（${d.id}）删除失败：${e.message}`);
      }
    },
    'plugin-save': async (d) => {
      try {
        const manifest = JSON.parse($('#plugin-manifest')?.value || '{}');
        await api(`/api/plugins/${encodeURIComponent(d.id)}/manifest`, { method: 'POST', body: { manifest } });
        const entry = d.entry;
        if (entry) {
          const content = $('#plugin-entry')?.value ?? '';
          await api(`/api/plugins/${encodeURIComponent(d.id)}/file`, { method: 'POST', body: { name: entry, content } });
        }
        closeAll();
        await refreshPlugins();
        toast('已保存并重载', 'ok');
      } catch (e) {
        toast('保存失败：' + e.message, 'err');
      }
    },
    'plugin-test-run': async (d) => {
      const acc = activeAccount();
      const body = {
        accountId: acc?.id,
        t: $('#test-event')?.value,
        content: $('#test-content')?.value,
        group_openid: $('#test-openid')?.value,
      };
      const box = $('#test-result');
      box.innerHTML = '<div class="item-sub">执行中…</div>';
      try {
        const r = await api(`/api/plugins/${encodeURIComponent(d.id)}/test`, { method: 'POST', body });
        box.innerHTML = `<div class="row" style="margin-bottom:8px"><span class="badge ok">测试成功</span><span class="item-sub">测试事件已交给插件，下面是原始返回</span></div><pre class="code">${esc(JSON.stringify(r, null, 2))}</pre>`;
      } catch (e) {
        box.innerHTML = `<div class="row" style="margin-bottom:8px"><span class="badge err">测试失败</span><span class="item-sub">${esc(e.message)}</span></div>`;
      }
    },
    'log-level': (d) => {
      state.logLevel = d.level;
      render();
    },
    'log-pause': () => {
      state.paused = !state.paused;
      render();
    },
    'log-today': () => loadLogsDate(''),
    'msg-today': () => loadEventsDate(''),
    'clear-logs': () => {
      state.logs = [];
      render();
      toast('日志视图已清空（文件保留）');
    },
    'save-settings': () => saveSettings(),
    'system-restart': async () => {
      try {
        const r = await api('/api/system/restart', { method: 'POST', body: {} });
        toast(r.restarting ? '正在重启，几秒后刷新页面' : '已提交重启', 'ok');
        setTimeout(() => location.reload(), 4000);
      } catch (e) {
        toast('重启失败：' + e.message, 'err');
      }
    },
    'jlw-test': async () => {
      const val = (id) => $(id)?.value?.trim() ?? '';
      const body = {
        baseUrl: val('#set-jlw-base'),
        insecureTls: !!$('#set-jlw-insecure')?.checked,
      };
      toast('正在测试连接…');
      try {
        const r = await api('/api/jlw/test', { method: 'POST', body });
        toast(r.message || '连接正常', 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'jlw-me': async () => {
      try {
        const r = await api('/api/me/refresh', { method: 'POST', body: {} });
        state.user = r.user;
        renderChrome();
        if (state.page === 'settings') render();
        toast('资料已刷新', 'ok');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    logout: async () => {
      if (!confirm('退出当前聚龙账户登录？')) return;
      try {
        await api('/api/logout', { method: 'POST', body: {} });
      } catch {
        /* ignore */
      }
      state.user = null;
      state.loggedIn = false;
      showLogin();
    },
    'plugin-token-rotate': async () => {
      if (!confirm('重置插件令牌后，所有易语言/外部插件都需要更新令牌。继续？')) return;
      try {
        const r = await api('/api/plugins/token/rotate', { method: 'POST', body: {} });
        await refreshAll();
        copyText(r.token, '插件令牌已重置并复制');
      } catch (e) {
        toast(e.message, 'err');
      }
    },
    'ip-copy': () => {
      const ip = state.ip?.ip;
      if (ip) return copyText(ip, '公网 IP 已复制：' + ip);
      refreshIp(true);
    },
    copy: (d, el) => {
      let text = d.copy;
      if (d.copyTarget) {
        const target = document.getElementById(d.copyTarget);
        text = target?.textContent || '';
      }
      copyText(text);
    },
    'drawer-close': () => $('#drawer').classList.add('hidden'),
    'modal-close': () => $('#modal').classList.add('hidden'),
  };

  window.addEventListener('message', async (e) => {
    const frame = document.getElementById('plugin-settings-frame');
    if (!frame || e.source !== frame.contentWindow) return;
    const msg = e.data || {};
    if (msg.type !== 'jlw-settings-save' && msg.type !== 'jlw-settings-refresh' && msg.type !== 'jlw-settings-review-refresh' && msg.type !== 'jlw-settings-ping') return;
    const id = state.settingsPluginId;
    if (!id) return;
    const status = document.getElementById('plugin-settings-status');
    if (msg.type === 'jlw-settings-ping') {
      try {
        e.source.postMessage({ type: 'jlw-settings-pong' }, '*');
      } catch {
        /* ignore */
      }
      return;
    }
    // 只刷新审核快照：重新读插件设置页里的 JSON 块发给 iframe，不换 src、不动未保存的编辑
    if (msg.type === 'jlw-settings-review-refresh') {
      try {
        const res = await fetch(`/api/plugins/${encodeURIComponent(id)}/settings?t=${Date.now()}`, { credentials: 'same-origin', cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const html = await res.text();
        const blocks = {};
        const re = /<script id="([^"]+)" type="application\/json">([\s\S]*?)<\/script>/g;
        let m;
        while ((m = re.exec(html))) blocks[m[1]] = m[2].trim();
        e.source.postMessage({ type: 'jlw-settings-snapshots', blocks }, '*');
        if (status) {
          status.textContent = '审核数据已刷新';
          status.className = 'plugin-settings-status ok';
        }
      } catch (err) {
        e.source.postMessage({ type: 'jlw-settings-snapshots', blocks: null, error: err.message }, '*');
        if (status) {
          status.textContent = '刷新审核数据失败：' + err.message;
          status.className = 'plugin-settings-status err';
        }
      }
      return;
    }
    if (msg.type === 'jlw-settings-refresh') {
      if (status) {
        status.textContent = '正在刷新审核数据…';
        status.className = 'plugin-settings-status';
      }
      // 先回执，设置页就不用降级到独立页面
      try {
        e.source.postMessage({ type: 'jlw-settings-refreshed' }, '*');
      } catch {
        /* ignore */
      }
      // 由面板给 iframe 换新 src：走插件设置页自己的 CSP 与登录态，脚本才能执行
      frame.removeAttribute('srcdoc');
      frame.src = `/api/plugins/${encodeURIComponent(id)}/settings?t=${Date.now()}`;
      setTimeout(() => {
        if (status && status.textContent === '正在刷新审核数据…') {
          status.textContent = '审核数据已刷新';
          status.className = 'plugin-settings-status ok';
        }
      }, 1200);
      return;
    }
    if (status) {
      status.textContent = '正在保存…';
      status.className = 'plugin-settings-status';
    }
    try {
      const config = msg.config && typeof msg.config === 'object' && !Array.isArray(msg.config) ? msg.config : {};
      await api(`/api/plugins/${encodeURIComponent(id)}/config`, { method: 'POST', body: { config } });
      const p = state.plugins.find((x) => x.id === id);
      if (p) p.config = config;
      if (status) {
        status.textContent = '设置已保存';
        status.className = 'plugin-settings-status ok';
      }
      frame.contentWindow.postMessage({ type: 'jlw-settings-saved', ok: true }, '*');
      refreshPlugins().catch(() => {});
    } catch (err) {
      if (status) {
        status.textContent = '保存失败：' + err.message;
        status.className = 'plugin-settings-status err';
      }
      frame.contentWindow.postMessage({ type: 'jlw-settings-saved', ok: false, error: err.message }, '*');
    }
  });

  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) {
      const which = closer.dataset.close;
      if (which === 'drawer') $('#drawer').classList.add('hidden');
      if (which === 'modal') {
        if (state.modalPersistent && closer.classList.contains('modal-mask')) return;
        state.modalPersistent = false;
        state.settingsPluginId = null;
        $('#modal').classList.remove('persistent');
        $('#modal').classList.remove('wide');
        $('#modal').classList.add('hidden');
      }
      return;
    }
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const act = el.dataset.act;
    const fn = actions[act];
    if (!fn) return;
    if (el.disabled) return;
    Promise.resolve(fn(el.dataset, el)).catch((err) => toast(err.message, 'err'));
  });

  document.addEventListener('change', (e) => {
    if (e.target.id === 'msg-account') {
      state.msgAccount = e.target.value;
      refreshEvents().then(renderMessagesList).catch(() => {});
    }
  });

  /* ================= 启动 ================= */

  let loginMode = 'login';

  function setLoginMode(mode) {
    loginMode = ['login', 'register', 'reset'].includes(mode) ? mode : 'login';
    $$('#login-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.mode === loginMode));
    $('#login-code-row')?.classList.toggle('hidden', loginMode === 'login');
    $('#login-name-row')?.classList.toggle('hidden', loginMode !== 'register');
    const pwdLabel = $('#login-password-label');
    if (pwdLabel) pwdLabel.textContent = loginMode === 'login' ? '密码' : loginMode === 'register' ? '设置密码' : '新密码';
    const pwd = $('#login-password');
    if (pwd) {
      pwd.value = '';
      pwd.placeholder = loginMode === 'login' ? '聚龙账户密码' : '至少 6 位';
      pwd.autocomplete = loginMode === 'login' ? 'current-password' : 'new-password';
    }
    const submit = $('#login-submit');
    if (submit) submit.textContent = loginMode === 'login' ? '登录控制台' : loginMode === 'register' ? '注册并登录' : '重置密码并登录';
    $('#login-links')?.classList.toggle('hidden', loginMode !== 'login');
    const err = $('#login-error');
    if (err) err.textContent = '';
  }

  async function sendLoginCode() {
    const email = $('#login-email').value.trim();
    const err = $('#login-error');
    if (!email) {
      err.textContent = '请先填写邮箱';
      return;
    }
    const btn = $('#btn-send-code');
    const purpose = loginMode === 'register' ? 'register' : 'reset';
    btn.disabled = true;
    btn.textContent = '发送中…';
    try {
      const r = await api('/api/jlw/send-code', { method: 'POST', body: { email, purpose } });
      toast(r.message || '验证码已发送', 'ok');
      let left = Number(r.cooldown) || 60;
      btn.textContent = `${left} 秒后重试`;
      const timer = setInterval(() => {
        left -= 1;
        if (left <= 0) {
          clearInterval(timer);
          btn.disabled = false;
          btn.textContent = '获取验证码';
        } else {
          btn.textContent = `${left} 秒后重试`;
        }
      }, 1000);
    } catch (e) {
      err.textContent = e.message;
      btn.disabled = false;
      btn.textContent = '获取验证码';
    }
  }

  /* ---------------- 白天/夜晚 + 背景氛围 ---------------- */
  const THEME_KEY = 'jlw-theme';
  let themeAnimTimer = null;

  /** 切换主题：写 localStorage、同步所有按钮文案、挂 560ms 颜色渐变 */
  function applyTheme(theme, animate = true) {
    const next = theme === 'light' ? 'light' : 'dark';
    const root = document.documentElement;
    const changed = root.dataset.theme !== next;
    if (animate && changed) {
      root.classList.add('theme-anim');
      clearTimeout(themeAnimTimer);
      themeAnimTimer = setTimeout(() => root.classList.remove('theme-anim'), 560);
    }
    root.dataset.theme = next;
    try {
      localStorage.setItem(THEME_KEY, next);
    } catch {
      /* ignore */
    }
    for (const btn of $$('.js-theme-toggle')) {
      const ico = btn.querySelector('.tt-ico');
      const lab = btn.querySelector('.tt-label');
      if (ico) ico.textContent = next === 'light' ? '☀️' : '🌙';
      if (lab) lab.textContent = next === 'light' ? '白天' : '夜晚';
      btn.title = next === 'light' ? '当前：白天风格 · 点击切到夜晚' : '当前：夜晚风格 · 点击切到白天';
    }
  }

  /** 上浮光点：位置/大小/速度随机，只挂一次 */
  function mountMotes() {
    const box = document.querySelector('.motes');
    if (!box || box.childElementCount) return;
    let html = '';
    for (let i = 0; i < 18; i++) {
      const size = 3 + Math.round(Math.random() * 6);
      html +=
        `<i style="left:${Math.round(Math.random() * 100)}%;` +
        `width:${size}px;height:${size}px;` +
        `animation-duration:${24 + Math.round(Math.random() * 30)}s,${7 + Math.round(Math.random() * 7)}s;` +
        `animation-delay:${-Math.round(Math.random() * 45)}s,${-Math.round(Math.random() * 8)}s;` +
        `--drift:${10 + Math.round(Math.random() * 34)}px"></i>`;
    }
    box.innerHTML = html;
  }

  async function boot() {
    const savedEmail = localStorage.getItem('jlw-email');
    if (savedEmail && $('#login-email') && !$('#login-email').value) $('#login-email').value = savedEmail;
    setLoginMode('login');
    await checkSession();
  }

  document.addEventListener('DOMContentLoaded', () => {
    mountMotes();
    applyTheme(localStorage.getItem(THEME_KEY) || 'dark', false);
    $$('.js-theme-toggle').forEach((btn) =>
      btn.addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'light' ? 'dark' : 'light')),
    );

    // 头像加载失败时回退到昵称首字
    document.addEventListener(
      'error',
      (e) => {
        const img = e.target;
        if (!img || img.tagName !== 'IMG') return;
        const box = img.closest('.avatar');
        if (!box) return;
        box.textContent = img.dataset.initial || '?';
      },
      true,
    );

    $$('#login-tabs button').forEach((b) => b.addEventListener('click', () => setLoginMode(b.dataset.mode)));
    $('#login-links').addEventListener('click', (e) => {
      const a = e.target.closest('[data-login-mode]');
      if (!a) return;
      e.preventDefault();
      setLoginMode(a.dataset.loginMode);
    });
    $('#btn-send-code').addEventListener('click', sendLoginCode);

    $('#login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = $('#login-error');
      err.textContent = '';
      const email = $('#login-email').value.trim();
      const password = $('#login-password').value;
      const code = $('#login-code')?.value.trim() || '';
      const name = $('#login-name')?.value.trim() || '';
      if (!email) {
        err.textContent = '请输入邮箱';
        return;
      }
      if (!password) {
        err.textContent = '请输入密码';
        return;
      }

      let url = '/api/login';
      let payload = { email, password };
      if (loginMode === 'register') {
        if (!/^\d{6}$/.test(code)) {
          err.textContent = '请输入 6 位邮箱验证码';
          return;
        }
        if (password.length < 6) {
          err.textContent = '密码至少 6 位';
          return;
        }
        if (name.length < 2 || name.length > 20) {
          err.textContent = '名称需要 2-20 个字';
          return;
        }
        url = '/api/jlw/register';
        payload = { email, code, password, name };
      } else if (loginMode === 'reset') {
        if (!/^\d{6}$/.test(code)) {
          err.textContent = '请输入 6 位邮箱验证码';
          return;
        }
        if (password.length < 6) {
          err.textContent = '新密码至少 6 位';
          return;
        }
        url = '/api/jlw/reset-password';
        payload = { email, code, password };
      }

      const btn = $('#login-submit');
      const label = btn.textContent;
      btn.disabled = true;
      btn.textContent = loginMode === 'login' ? '登录中…' : '提交中…';
      try {
        const r = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          credentials: 'same-origin',
        });
        const data = await r.json().catch(() => ({}));
        if (!r.ok || !data.ok) throw new Error(data.error || '操作失败');
        state.user = data.user || null;
        localStorage.setItem('jlw-email', email);
        $('#login-password').value = '';
        $('#login-code').value = '';
        await showApp();
      } catch (e2) {
        err.textContent = e2.message;
      } finally {
        btn.disabled = false;
        btn.textContent = label;
      }
    });

    $('#btn-logout').addEventListener('click', async () => {
      if (!confirm('退出当前聚龙账户登录？')) return;
      try {
        await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
      } catch {
        /* ignore */
      }
      state.user = null;
      state.loggedIn = false;
      showLogin();
    });

    $('#user-chip').addEventListener('click', () => {
      state.page = 'settings';
      render();
    });

    $('#btn-refresh').addEventListener('click', () => refreshAll());
    $('#ip-pill').addEventListener('click', () => actions['ip-copy']());
    $('#update-pill').addEventListener('click', openUpdateModal);
    // 左上角图标：点一下检查更新（发现新版本会直接弹更新框）
    const brand = document.querySelector('.brand');
    if (brand) {
      brand.title = '点击检查更新';
      brand.addEventListener('click', () => checkUpdate(true, true));
    }
    $('#update-overlay-close').addEventListener('click', hideUpdateOverlay);
    $('#login-scope-pill').addEventListener('click', () => openLoginScopeModal());
    $('#account-select').addEventListener('change', (e) => {
      state.accountId = e.target.value;
      localStorage.setItem('jlw-account', state.accountId);
      renderChrome();
      render();
    });

    $$('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.page = btn.dataset.page;
        render();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !state.modalPersistent) closeAll();
      if (e.key === 'r' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        refreshAll();
      }
    });

    boot();
    setInterval(() => {
      if (state.loggedIn && !state.wsOk) refreshStatus();
    }, 8000);
    setInterval(() => {
      if (state.loggedIn) refreshIp(false);
    }, 10 * 60 * 1000);
    setInterval(() => {
      if (state.loggedIn && !state.updating) checkUpdate(false);
    }, 15 * 60 * 1000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && state.loggedIn && !state.updating) checkUpdate(false);
    });
  });
})();
