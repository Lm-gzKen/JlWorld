'use strict';
/**
 * 独立更新器：由面板进程启动，等旧进程退出后：
 *   1. 解压更新包（顶层目录通常是 JlW-BoT）
 *   2. 校验 src/index.js / package.json
 *   3. 备份旧 src 与启动文件
 *   4. 覆盖到安装目录（保留 ~JlWBoT 用户数据）
 *   5. 用新 runtime/node.exe 重新启动
 *
 * 这个文件会被复制到 ~JlWBoT/updates/ 下运行，不能 require 项目内模块。
 */
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

function arg(name, fallback = '') {
  const i = process.argv.indexOf(name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : fallback;
}

const pid = Number(arg('--pid', '0'));
const zipFile = path.resolve(arg('--zip'));
const root = path.resolve(arg('--root'));
const nodeArg = path.resolve(arg('--node', process.execPath));
const version = arg('--version', '');
const logFile = path.resolve(arg('--log', path.join(path.dirname(zipFile), 'update.log')));
let restartArgs = ['--no-open'];
try {
  const decoded = JSON.parse(Buffer.from(arg('--args-b64', ''), 'base64').toString('utf8'));
  if (Array.isArray(decoded)) restartArgs = decoded.map(String);
} catch {
  /* 用默认参数 */
}

const updatesDir = path.dirname(logFile);
const readyFile = path.resolve(arg('--ready', path.join(updatesDir, 'apply-ready.json')));
const tempDir = path.join(updatesDir, 'extract-' + Date.now());
const backupDir = path.join(updatesDir, `backup-${version || 'unknown'}-${Date.now()}`);
const backupItems = ['src', 'package.json', 'config.default.json', 'start.cmd', '启动机器人.cmd'];
let readyWritten = false;
let oldProcessGone = false;

function writeReady(payload) {
  try {
    fs.mkdirSync(path.dirname(readyFile), { recursive: true });
    fs.writeFileSync(readyFile, JSON.stringify({ ...payload, at: Date.now() }), 'utf8');
    if (payload.ok) readyWritten = true;
  } catch {
    /* ignore */
  }
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  try {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    fs.appendFileSync(logFile, line + '\r\n', 'utf8');
  } catch {
    /* ignore */
  }
  console.log(line);
}

function startOld() {
  if (!oldProcessGone || !readyWritten) return;
  const runtimeNode = path.join(root, 'runtime', 'node.exe');
  const nodeExe = fs.existsSync(runtimeNode) ? runtimeNode : nodeArg;
  const entry = path.join(root, 'src', 'index.js');
  if (!fs.existsSync(nodeExe) || !fs.existsSync(entry)) return;
  try {
    const child = spawn(nodeExe, [entry, ...restartArgs], {
      cwd: root,
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    child.unref();
    log(`已回滚并重新启动旧版本，PID ${child.pid || '?'}`);
  } catch (e) {
    log('旧版本重启失败：' + e.message);
  }
}

function fail(msg) {
  writeReady({ ok: false, error: msg });
  log('ERROR ' + msg);
  startOld();
  process.exit(1);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function alive(target) {
  try {
    process.kill(target, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM';
  }
}

function psQuote(s) {
  return "'" + String(s).replace(/'/g, "''") + "'";
}

function extract(zip, dest) {
  fs.mkdirSync(dest, { recursive: true });
  if (process.platform === 'win32') {
    const ps = `Expand-Archive -LiteralPath ${psQuote(zip)} -DestinationPath ${psQuote(dest)} -Force`;
    const r = spawnSync(
      path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps],
      { windowsHide: true, encoding: 'utf8', timeout: 240000, maxBuffer: 16 * 1024 * 1024 },
    );
    if (r.error) throw r.error;
    if (r.status !== 0) throw new Error((r.stderr || r.stdout || 'Expand-Archive 失败').trim().slice(0, 500));
    return;
  }
  const r = spawnSync('unzip', ['-q', '-o', zip, '-d', dest], { encoding: 'utf8', timeout: 240000 });
  if (r.error || r.status !== 0) {
    throw new Error((r.error && r.error.message) || (r.stderr || 'unzip 失败').trim());
  }
}

function findRoot(dest) {
  const entries = fs.readdirSync(dest, { withFileTypes: true }).filter((x) => x.name !== '__MACOSX');
  if (entries.length === 1 && entries[0].isDirectory()) return path.join(dest, entries[0].name);
  return dest;
}

function copyTree(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const name of fs.readdirSync(src)) copyTree(path.join(src, name), path.join(dst, name));
    return;
  }
  if (st.isFile()) copyFileRetry(src, dst);
}

function copyFileRetry(src, dst) {
  let last = null;
  const tmp = dst + '.jlw-new';
  for (let i = 0; i < 10; i++) {
    try {
      fs.copyFileSync(src, tmp);
      fs.renameSync(tmp, dst);
      return;
    } catch (e) {
      last = e;
      try {
        fs.rmSync(tmp, { force: true });
      } catch {
        /* ignore */
      }
      if (!['EBUSY', 'EPERM', 'EACCES', 'EEXIST'].includes(e.code)) throw e;
      // Windows 上旧 node.exe 退出后可能短暂被占用
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 300);
    }
  }
  throw last;
}

function parseV(v) {
  const m = String(v || '').match(/(\d+)\.(\d+)\.(\d+)/);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}

function sameVersion(a, b) {
  const x = parseV(a);
  const y = parseV(b);
  return !!x && !!y && x[0] === y[0] && x[1] === y[1] && x[2] === y[2];
}

function restore() {
  for (const item of backupItems) {
    const src = path.join(backupDir, item);
    if (!fs.existsSync(src)) continue;
    const dst = path.join(root, item);
    try {
      fs.rmSync(dst, { recursive: true, force: true });
      copyTree(src, dst);
      log('已回滚 ' + item);
    } catch (e) {
      log('回滚失败 ' + item + '：' + e.message);
    }
  }
}

function cleanOldBackups() {
  try {
    const list = fs
      .readdirSync(updatesDir)
      .filter((n) => n.startsWith('backup-'))
      .map((n) => path.join(updatesDir, n))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
    for (const old of list.slice(2)) fs.rmSync(old, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
}

async function main() {
  log(`更新器启动：目标 v${version || '?'}，安装目录 ${root}`);
  if (!zipFile || !fs.existsSync(zipFile)) fail('找不到更新包：' + zipFile);
  if (!root || !fs.existsSync(path.join(root, 'src', 'index.js'))) fail('安装目录里没有 src/index.js：' + root);

  // 先解压和校验，不碰正在运行的旧文件
  extract(zipFile, tempDir);
  const pkgRoot = findRoot(tempDir);
  const pkgFile = path.join(pkgRoot, 'package.json');
  const entryFile = path.join(pkgRoot, 'src', 'index.js');
  if (!fs.existsSync(pkgFile) || !fs.existsSync(entryFile)) fail('更新包结构不正确（缺少 package.json 或 src/index.js）');
  let pkg = {};
  try {
    pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
  } catch (e) {
    fail('更新包 package.json 无法解析：' + e.message);
  }
  if (version && pkg.version && !sameVersion(pkg.version, version)) {
    fail(`更新包版本 ${pkg.version} 与页面版本 ${version} 不一致，已拒绝安装`);
  }
  writeReady({ ok: true, version: pkg.version || version });
  log(`更新包校验通过：v${pkg.version || '?'}`);

  // 等旧面板进程退出（最多 90 秒）
  if (pid > 0) {
    const deadline = Date.now() + 90000;
    while (Date.now() < deadline && alive(pid)) await sleep(250);
    if (alive(pid)) fail('旧进程 90 秒内没有退出，放弃更新');
    oldProcessGone = true;
    log('旧进程已退出');
  } else {
    oldProcessGone = true;
  }

  // 备份可回滚的运行文件
  fs.mkdirSync(backupDir, { recursive: true });
  for (const item of backupItems) {
    const src = path.join(root, item);
    if (fs.existsSync(src)) copyTree(src, path.join(backupDir, item));
  }
  log('旧版本已备份：' + backupDir);

  try {
    for (const name of fs.readdirSync(pkgRoot)) {
      if (name === '~JlWBoT') continue;
      copyTree(path.join(pkgRoot, name), path.join(root, name));
    }
    log('文件覆盖完成，~JlWBoT 用户数据未改动');
  } catch (e) {
    log('覆盖失败：' + e.message);
    restore();
    fail('更新失败，已回滚：' + e.message);
  }

  try {
    fs.writeFileSync(
      path.join(updatesDir, 'last-update.json'),
      JSON.stringify({ version: pkg.version || version, appliedAt: Date.now(), zip: zipFile, backup: backupDir }, null, 2),
      'utf8',
    );
  } catch {
    /* ignore */
  }

  // 用新 runtime 启动；没有 runtime 时退回更新器自己的 node
  const runtimeNode = path.join(root, 'runtime', 'node.exe');
  const nodeExe = fs.existsSync(runtimeNode) ? runtimeNode : nodeArg;
  const entry = path.join(root, 'src', 'index.js');
  if (!fs.existsSync(nodeExe)) fail('找不到可用的 node.exe：' + nodeExe);
  if (!fs.existsSync(entry)) fail('新版本缺少 src/index.js');

  log(`重新启动：${nodeExe} ${entry} ${restartArgs.join(' ')}`);
  let spawnError = null;
  const child = spawn(nodeExe, [entry, ...restartArgs], {
    cwd: root,
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.on('error', (e) => {
    spawnError = e;
  });
  child.unref();
  await sleep(800);
  if (spawnError || !child.pid) fail('新版本启动失败：' + (spawnError ? spawnError.message : '没有进程 PID'));

  log(`更新完成，新进程 PID ${child.pid}`);
  cleanOldBackups();
  try {
    fs.rmSync(tempDir, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
  process.exit(0);
}

main().catch((e) => fail(e.stack || e.message));
