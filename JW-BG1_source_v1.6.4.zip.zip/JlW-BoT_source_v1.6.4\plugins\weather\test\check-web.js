'use strict';
/**
 * 前端资源语法检查（面板没有登录态时也能跑）：
 *   - settings.html / api.html 是否是完整 HTML
 *   - 内联 <script> 能否 new Function（语法合法）
 *   - settings.html 是否带 WX_DATA 占位区 + wx-data JSON 块
 *   - plugin.json 的关键字段与 index.js 的版本号是否一致
 */
const fs = require('node:fs');
const path = require('node:path');

const dir = path.join(__dirname, '..');
let bad = 0;
const ok = (cond, msg, extra) => {
  if (cond) console.log('  ✓ ' + msg + (extra ? '（' + extra + '）' : ''));
  else {
    bad++;
    console.log('  ✗ ' + msg + (extra ? ' —— ' + extra : ''));
  }
};

function checkHtml(file, { requireScript = true } = {}) {
  const p = path.join(dir, file);
  if (!fs.existsSync(p)) {
    ok(false, file + ' 存在');
    return '';
  }
  const html = fs.readFileSync(p, 'utf8');
  ok(/<html/i.test(html) && /<\/html>/i.test(html), file + ' 是完整 HTML');
  const n = (html.match(/\uFFFD/g) || []).length;
  ok(n === 0, file + ' 没有编码损坏', n ? n + ' 处 U+FFFD' : '');
  if (!requireScript) return html;
  const blocks = [...html.matchAll(/<script(?![^>]*type="application\/json")[^>]*>([\s\S]*?)<\/script>/gi)];
  if (!blocks.length) ok(false, file + ' 有内联脚本');
  for (const [i, m] of blocks.entries()) {
    const src = m[1];
    if (!src.trim()) continue;
    try {
      // eslint-disable-next-line no-new-func
      new Function(src);
      ok(true, `${file} 内联脚本 #${i + 1} 语法通过`);
    } catch (e) {
      ok(false, `${file} 内联脚本 #${i + 1} 语法错误`, e.message);
    }
  }
  return html;
}

console.log('· settings.html');
const settings = checkHtml('settings.html');
ok(settings.includes('<!-- WX_DATA_START -->') && settings.includes('<!-- WX_DATA_END -->'), 'settings.html 有 WX_DATA 占位区');
const dataMatch = settings.match(/<script id="wx-data" type="application\/json">([\s\S]*?)<\/script>/);
ok(!!dataMatch, 'settings.html 有 wx-data JSON 块');
if (dataMatch) {
  try {
    JSON.parse(dataMatch[1]);
    ok(true, 'wx-data 初始 JSON 合法');
  } catch (e) {
    ok(false, 'wx-data 初始 JSON 合法', e.message);
  }
}
for (const k of ['data-text-key', 'cfg-time', 'card-width', 'save-btn', 'subs-body', 'schedule-detail']) {
  ok(settings.includes(k), 'settings.html 有 ' + k);
}
ok(settings.includes('id="page-settings"') && settings.includes('id="page-reply"') && settings.includes('id="page-subs"'), 'settings.html 分成「设置」「订阅列表」「回复信息」三页');
ok(settings.includes('data-tab="subs"'), 'settings.html 有订阅列表页签');
ok(settings.includes('data-tab="reply"'), 'settings.html 有回复信息页签');
ok(!settings.includes('cfg-check'), '设置页不再有「检查间隔」输入（固定每分钟）');
ok(!settings.includes('cfg-catchup'), '设置页不再有「补推上限」输入（不补推）');
ok(!settings.includes('cfg-maxpush'), '设置页不再有「每轮最多推几人」（人数无上限）');

console.log('· api.html');
checkHtml('api.html', { requireScript: false });

console.log('· 插件文件');
for (const f of ['plugin.json', 'index.js', 'README.md', 'lib/weather.js', 'lib/texts.js', 'lib/card.js', 'lib/render-image.js', 'lib/render.ps1', 'lib/media.js', 'lib/store.js', 'data/cities.json']) {
  ok(fs.existsSync(path.join(dir, f)), f + ' 存在');
}
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8'));
const indexSrc = fs.readFileSync(path.join(dir, 'index.js'), 'utf8');
ok(manifest.id === 'weather', 'plugin.json id=weather');
ok(manifest.type === 'js', 'plugin.json type=js');
ok(manifest.version === '1.3.2', 'plugin.json 版本 1.3.2', manifest.version);
ok(indexSrc.includes(`PLUGIN_VERSION = '${manifest.version}'`), 'index.js 版本号与 plugin.json 一致');
ok(!('checkSeconds' in manifest.config), 'config 不再有 checkSeconds（固定每分钟）');
ok(!('catchupMaxDays' in manifest.config), 'config 不再有 catchupMaxDays（不补推）');
ok(!('maxPushPerTick' in manifest.config), 'config 不再有 maxPushPerTick（人数无上限）');
ok(!('catchupNote' in manifest.config.texts), 'texts 不再有 catchupNote');
for (const k of ['menuTitle', 'menu', 'menuGroupTitle', 'menuGroup']) ok(!!manifest.config.texts[k], 'texts 有菜单 ' + k);
const events = manifest.events || [];
for (const e of ['C2C_MESSAGE_CREATE', 'GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE']) ok(events.includes(e), 'events 含 ' + e);
ok((manifest.commands || []).includes('天气'), 'commands 含 天气');
ok(manifest.config && manifest.config.texts && typeof manifest.config.texts.weather === 'string', 'config.texts.weather 是模板');
for (const k of ['weatherTitle', 'queryTitle', 'help', 'subscribed', 'badTime', 'error']) ok(manifest.config.texts[k], 'texts 有 ' + k);
ok(manifest.config.card && manifest.config.card.footer, 'config.card.footer 存在');
ok(manifest.config.render && manifest.config.render.enabled !== false, 'config.render 可出图');
ok(typeof manifest.timeout === 'number' && manifest.timeout >= 20000, 'timeout 足够出图', String(manifest.timeout));

console.log(bad ? `\n有 ${bad} 项失败` : '\n全部通过 ✅');
process.exitCode = bad ? 1 : 0;
