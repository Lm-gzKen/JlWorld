﻿# 打包离线版：把 node.exe 复制进 runtime\，之后整个目录可脱离本机 Node 运行
# 用法：powershell -ExecutionPolicy Bypass -File tools\打包离线版.ps1

param(
  [string]$NodePath = ""
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$runtime = Join-Path $root "runtime"

if (-not $NodePath) {
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if (-not $cmd) { throw "PATH 中找不到 node，请用 -NodePath 指定 node.exe 路径" }
  $NodePath = $cmd.Source
}

if (-not (Test-Path $NodePath)) { throw "找不到 $NodePath" }

New-Item -ItemType Directory -Force -Path $runtime | Out-Null
Copy-Item $NodePath (Join-Path $runtime "node.exe") -Force

$ver = & (Join-Path $runtime "node.exe") -v
Write-Host ""
Write-Host "  离线运行时已就绪：runtime\node.exe  ($ver)" -ForegroundColor Green
Write-Host "  以后双击 start.cmd 即可运行，不再依赖系统安装的 Node.js。" -ForegroundColor Green
Write-Host ""
Write-Host "  注意：runtime\ 约 90MB，复制整个项目目录即可带走。" -ForegroundColor DarkGray
