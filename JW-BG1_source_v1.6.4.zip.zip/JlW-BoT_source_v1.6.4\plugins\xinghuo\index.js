'use strict';
/**
 * 星火 · QQ 机器人插件（JlWBoT v1.4.15+）
 *
 * 功能：
 *   1. 自动收集：私聊消息 / 加好友 / 机器人进群 / 退群事件里的 openid，落本地用户库；
 *   2. zip 导入：设置页解析私聊包 / 群聊包（CSV），合并进用户库；
 *   3. 公告：Markdown 双栏编辑，给全部好友 openid 发主动私聊（支持测试发送 / 进度 / 失败记录）；
 *   4. 兑换码：读取 VloS 余额（VloS 余额合计），后台发码，
 *      用户发送 `/xh 兑换码` 兑换龙晶 / 玄玉（只写入 VloS 余额）。
 *
 * 设置页是 sandbox iframe，只能保存 config：
 *   - 导入 / 发码 / 发公告 = config.tasks 任务队列（按 id 去重，保存多次只执行一次）
 *   - 数据展示 = 插件把只读快照写进 settings.html 的 XH_DATA 占位区
 */

const path = require('node:path');

const { openStore, closeStore, getVsql } = require('./lib/store-factory');
const U = require('./lib/util');
const { normalizeConfig, DEFAULT_ANNOUNCEMENT } = require('./lib/defaults');
const snapshot = require('./lib/snapshot');
const sender = require('./lib/sender');
const vlosApi = require('./lib/vlos');
const profileApi = require('./lib/profile');
const qqapi = require('./lib/qqapi');
const { buildKeyboard, isKeyboardReject } = require('./lib/buttons');

const PLUGIN_ID = 'xinghuo';
const PLUGIN_VERSION = '1.7.3';

const GROUP_MESSAGE_EVENTS = new Set(['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE']);
const FRIEND_EVENTS = new Set(['FRIEND_ADD', 'FRIEND_DEL']);

let rt = null;

/* ======================= 初始化 ======================= */

function ensureRuntime(ctx) {
  const dir = ctx.plugin?.dir || path.resolve(__dirname);
  if (rt && rt.dir === dir) {
    // config 在框架里只在重载时变化；这里仍然同步一次，避免热重载边界读到旧值
    if (ctx.plugin?.config) rt.cfg = normalizeConfig(ctx.plugin.config);
    return rt;
  }
  if (rt) closeStore(rt.store);
  const cfg = normalizeConfig(ctx.plugin?.config);
  const store = openStore({ dir, log: ctx.log, storage: cfg.storage });
  const vsqlReady = !!getVsql();
  const storageError = store.storageInfo?.error || '';
  if (!vsqlReady) {
    ctx.log?.error?.(
      '星火缺少前置插件 VSQL（内置 SQLite 服务）：请先安装并启用 VSQL，再重载星火。' +
        '当前已临时回退 JSON，数据不会丢，但其他插件无法读取 xinghuo_ 共享表。',
    );
  } else if (storageError) {
    ctx.log?.error?.('星火无法使用前置 VSQL：' + storageError);
  }
  rt = {
    dir,
    cfg,
    store,
    log: ctx.log,
    frameworkConfig: ctx.config,
    bot: null,
    accountId: '',
    lastApi: null,
    lastAccountId: '',
    accounts: [],
    version: PLUGIN_VERSION,
    disposed: false,
    sending: false,
    workerTimer: null,
    snapshotTimer: null,
    profileRunning: false,
    profileTimer: null,
    profileDone: 0,
    profileFailed: 0,
    profileError: '',
    profileStartedAt: 0,
    profilePrefer: 'friend',
    profileFilter: null,
    profileRetryCount: 0,
    profileLastError: null,
    groupFetching: new Set(),
    groupFetchFailedAt: new Map(),
    redeeming: new Set(),
    cooldowns: new Map(),
    snapshotAt: 0,
    warned: new Set(),
  };
  return rt;
}

function listAccounts(ctx) {
  try {
    const list = ctx.config?.listAccounts?.() || [];
    return list.map((a) => ({ id: a.id, name: a.name || a.id, appId: String(a.appId || '') }));
  } catch {
    return [];
  }
}

/** 用 /users/@me 把账户显示名换成机器人 QQ 昵称（配置里常常只有 accxxx） */
async function hydrateAccountNames(r) {
  let changed = 0;
  const jobs = (r.accounts || [])
    .filter((a) => a && a.id)
    .map(async (a) => {
      try {
        const res = await qqapi.callEndpoint({
          config: r.frameworkConfig,
          accountId: a.id,
          endpoint: 'get_bot_me',
          timeoutMs: 6000,
        });
        const name = res.ok && res.data ? res.data.username || res.data.name || res.data.nickname || '' : '';
        if (name && name !== a.name) {
          a.name = String(name).slice(0, 80);
          changed++;
        }
      } catch {
        /* 拿不到就保留配置名 / 账户 ID */
      }
    });
  if (!jobs.length) return 0;
  await Promise.all(jobs);
  if (changed && !r.disposed) snapshot.refresh(r);
  return changed;
}

/** onLoad 时账户可能还没连上：错峰重试几次，拿到昵称就刷新快照 */
function scheduleAccountNames(r, index = 0) {
  const delays = [3000, 9000, 20000];
  if (index >= delays.length) return;
  const t = setTimeout(async () => {
    try {
      const changed = await hydrateAccountNames(r);
      if (!changed) scheduleAccountNames(r, index + 1);
    } catch {
      scheduleAccountNames(r, index + 1);
    }
  }, delays[index]);
  if (t.unref) t.unref();
}

/** 账户 → appId（用于 qlogo 头像直链） */
function appIdOf(r, accountId) {
  const id = String(accountId || '').trim();
  const acc = (r.accounts || []).find((a) => a.id === id) || (r.accounts || [])[0];
  return acc?.appId || '';
}

function avatarFor(r, accountId, openid, fallback = '') {
  const raw = String(fallback || '').trim();
  if (raw) return raw;
  return U.qlogoAvatar(appIdOf(r, accountId), openid);
}

function warnOnce(r, key, message) {
  if (!r || r.warned.has(key)) return;
  r.warned.add(key);
  r.log?.warn?.(message);
}

async function onLoad(ctx) {
  let r;
  try {
    r = ensureRuntime(ctx);
    r.log = ctx.log || r.log;
    r.frameworkConfig = ctx.config;
    r.accounts = listAccounts(ctx);
    {
      const map = {};
      for (const a of r.accounts) if (a.id && a.appId) map[a.id] = a.appId;
      const filled = r.store.backfillAvatars(map, r.accounts[0]?.appId || '');
      if (filled) r.log.info(`星火：已为 ${filled} 个好友/群补头像（群头像为群名首字兜底）`);
    }
    scheduleAccountNames(r);
    // 插件重载后 onLoad 没有事件上下文；但上一次事件留下的 bot 实例仍然可用
    try {
      const last = globalThis.__XINGHUO_LAST_BOT__;
      if (last && last.bot && Date.now() - (last.at || 0) < 24 * 3600 * 1000) r.bot = last.bot;
    } catch {
      /* ignore */
    }
    try {
      const lastApi = globalThis.__XINGHUO_LAST_API__;
      if (lastApi && lastApi.api && Date.now() - (lastApi.at || 0) < 24 * 3600 * 1000) {
        r.lastApi = lastApi.api;
        r.lastAccountId = lastApi.accountId || '';
      }
    } catch {
      /* ignore */
    }

    const counts = r.store.counts();
    const storageInfo = r.store.storageInfo || {};
    r.log.info(
      `星火 v${PLUGIN_VERSION} 已加载：好友 ${counts.friendsActive}/${counts.friends} · ` +
        `群 ${counts.groupsActive}/${counts.groups} · 兑换码 ${counts.codes} · ` +
        `VloS ${vlosApi.isReady() ? '已连接' : '未连接'} · 存储 ${String(storageInfo.driver || 'json').toUpperCase()}`,
    );
    if (storageInfo.error) r.log.warn('星火：' + storageInfo.error);

    if (!vlosApi.isReady()) {
      warnOnce(r, 'no-vlos', '星火：VloS 插件未加载；余额读取不可用，兑换到账需要 VloS 或备用发奖 Key');
    }

    // 1) 先执行设置页任务：导入 / 发码 / 建公告（通常几十毫秒内完成）
    await processTasks(r);
    r.store.flush();

    // 2) 先写一份快照，设置页刷新后立刻能看到任务结果
    snapshot.refresh(r);

    // 3) 再读余额（VloS 同步 API，很快；异常也不影响主流程）
    await refreshBalance(r);

    // 4) 继续未发完的公告 / 未补完的头像名称
    scheduleWorker(r);
    scheduleProfileWorker(r, 1200);
  } catch (e) {
    (ctx.log || console).error('星火初始化失败：' + (e?.stack || e));
  }
}

async function onUnload() {
  if (!rt) return;
  const r = rt;
  r.disposed = true;
  if (r.workerTimer) clearTimeout(r.workerTimer);
  if (r.snapshotTimer) clearTimeout(r.snapshotTimer);
  if (r.profileTimer) clearTimeout(r.profileTimer);
  r.workerTimer = null;
  r.snapshotTimer = null;
  r.profileTimer = null;
  try {
    r.store.flush();
  } catch {
    /* ignore */
  }
  closeStore(r.store);
  rt = null;
}

/* ======================= 事件 ======================= */

async function onEvent(ctx) {
  let r;
  try {
    r = ensureRuntime(ctx);
    r.log = ctx.log || r.log;
    r.frameworkConfig = ctx.config || r.frameworkConfig;
    r.bot = ctx.bot || r.bot;
    const accountId = String(ctx.account?.id || '');
    if (!r.accountId) r.accountId = accountId;
    if (r.cfg.enabledAccountIds.length && !r.cfg.enabledAccountIds.includes(accountId)) return null;

    const evtName = String(ctx.event?.name || ctx.event?.t || '');
    r.store.bumpEvent(evtName);

    try {
      globalThis.__XINGHUO_LAST_BOT__ = { bot: ctx.bot || null, accountId, at: Date.now() };
      if (ctx.api) globalThis.__XINGHUO_LAST_API__ = { api: ctx.api, accountId, at: Date.now() };
    } catch {
      /* ignore */
    }
    if (ctx.api) {
      r.lastApi = ctx.api;
      r.lastAccountId = accountId;
    }

    collectEvent(r, ctx, evtName);

    const m = ctx.message;
    if (!m || m.author?.bot) return null;
    if (m.kind !== 'group' && m.kind !== 'c2c') return null;

    const raw = String(m.cleanContent ?? m.content ?? '').trim();
    if (!raw || !matchCommand(r.cfg, raw)) return null;
    return await handleCommand(ctx, r, raw);
  } catch (e) {
    try {
      (r?.log || ctx.log || console).warn('星火处理事件失败：' + (e?.stack || e));
    } catch {
      /* ignore */
    }
    return null;
  }
}

function messageIdentity(m) {
  const out = [];
  const push = (v) => {
    const s = String(v || '').trim();
    if (s && !out.includes(s)) out.push(s);
  };
  push(m?.user_openid);
  push(m?.author?.user_openid);
  push(m?.author?.id);
  push(m?.author?.member_openid);
  push(m?.author?.union_openid);
  return out;
}

function collectEvent(r, ctx, evtName) {
  const m = ctx.message;
  const raw = ctx.event?.raw || {};
  const accountId = String(ctx.account?.id || '');

  if (evtName === 'C2C_MESSAGE_CREATE' && m) {
    const openid = m.user_openid || m.author?.user_openid || m.author?.id;
    if (openid) {
      const before = r.store.data.friends[openid];
      const wasInvalid = before && before.status === 'invalid';
      const info = r.store.upsertFriend({
        openid,
        accountId,
        name: m.author?.username,
        avatar: m.author?.avatar || avatarFor(r, accountId, openid),
        unionOpenid: m.author?.union_openid,
        source: 'event',
      });
      if (wasInvalid) {
        r.log.info(`星火：好友 ${U.maskOpenid(openid)} 发来消息，已恢复「有效」`);
        scheduleSnapshot(r, 300);
      } else if (info && (!info.user.name || !info.user.avatar)) {
        scheduleProfileWorker(r, 600);
      }
      if (!wasInvalid) scheduleSnapshot(r, info?.created ? 1000 : 20000);
    }
    return;
  }

  if (evtName === 'FRIEND_ADD') {
    const openid = raw.openid || raw.user_openid || raw.user?.openid || raw.user?.user_openid;
    if (openid) {
      const info = r.store.upsertFriend({ openid, accountId, avatar: avatarFor(r, accountId, openid), source: 'event' });
      if (info?.created) {
        r.log.info(`星火：新增好友 openid=${U.maskOpenid(openid)}`);
        if (m?.author?.username) info.user.name = m.author.username;
      }
      scheduleProfileWorker(r, 600);
      scheduleSnapshot(r, 1000);
    }
    return;
  }

  if (evtName === 'FRIEND_DEL') {
    const openid = raw.openid || raw.user_openid || raw.user?.openid || raw.user?.user_openid;
    if (openid) {
      r.store.markFriendRemoved(openid, accountId);
      r.log.info(`星火：好友已删除 openid=${U.maskOpenid(openid)}`);
      scheduleSnapshot(r, 1000);
    }
    return;
  }

  if (GROUP_MESSAGE_EVENTS.has(evtName) && m?.group_openid) {
    const info = r.store.upsertGroup({
      group_openid: m.group_openid,
      unionGroupOpenid: m.union_group_openid || m.author?.union_group_openid,
      accountId,
      source: 'event',
    });
    if (info?.created) r.log.info(`星火：新群 openid=${U.maskOpenid(m.group_openid)}`);
    maybeFetchGroupProfile(r, ctx, m.group_openid, info?.created);
    scheduleSnapshot(r, info?.created ? 1000 : 20000);
    return;
  }

  if (evtName === 'GROUP_ADD_ROBOT') {
    const group = raw.group_openid || raw.group?.group_openid;
    if (group) {
      const info = r.store.upsertGroup({ group_openid: group, unionGroupOpenid: raw.union_group_openid, accountId, source: 'event' });
      r.log.info(`星火：机器人加入群 openid=${U.maskOpenid(group)}`);
      maybeFetchGroupProfile(r, ctx, group, info?.created);
      scheduleSnapshot(r, 1000);
    }
    return;
  }

  if (evtName === 'GROUP_DEL_ROBOT') {
    const group = raw.group_openid || raw.group?.group_openid;
    if (group) {
      r.store.markGroupLeft(group, accountId);
      r.log.info(`星火：机器人退出群 openid=${U.maskOpenid(group)}`);
      scheduleSnapshot(r, 1000);
    }
  }
}

function maybeFetchGroupProfile(r, ctx, groupOpenid, force = false) {
  if (!ctx.api || typeof ctx.api.call !== 'function' || !groupOpenid) return;
  const existing = r.store.data.groups[groupOpenid];
  if (!force && existing?.name && existing?.avatar) return;
  if (!force && existing?.profileAt && existing?.profileError) return;
  if (r.groupFetching.has(groupOpenid)) return;
  const failedAt = r.groupFetchFailedAt?.get?.(groupOpenid) || 0;
  if (!force && failedAt && Date.now() - failedAt < 10 * 60 * 1000) return;
  r.groupFetching.add(groupOpenid);
  Promise.resolve()
    .then(() => ctx.api.call('group_info', { params: { group_openid: groupOpenid } }))
    .then((res) => {
      if (!res || res.ok === false) throw new Error(res?.message || '群资料接口失败');
      const p = profileApi.parseGroup(res.data);
      r.store.applyProfile('group', groupOpenid, p);
      scheduleSnapshot(r, 800);
    })
    .catch((e) => {
      r.store.markProfileError('group', groupOpenid, e?.message || String(e));
      r.profileLastError = { kind: 'group', id: groupOpenid, code: e?.code || '', message: e?.message || String(e), at: Date.now() };
      if (!r.groupFetchFailedAt) r.groupFetchFailedAt = new Map();
      r.groupFetchFailedAt.set(groupOpenid, Date.now());
      if (r.groupFetchFailedAt.size > 500) {
        const first = r.groupFetchFailedAt.keys().next().value;
        r.groupFetchFailedAt.delete(first);
      }
      r.log.debug?.(`星火：读取群资料失败 ${U.maskOpenid(groupOpenid)}：${e?.message || e}`);
    })
    .finally(() => r.groupFetching.delete(groupOpenid));
}

function scheduleSnapshot(r, delay = 20000) {
  if (!r || r.disposed) return;
  const due = Date.now() + Math.max(200, Number(delay) || 20000);
  // 已有定时器：新的到期时间更早才重排（新增好友 / 群要尽快反映到设置页）
  if (r.snapshotTimer) {
    if (r.snapshotDue && r.snapshotDue <= due) return;
    clearTimeout(r.snapshotTimer);
    r.snapshotTimer = null;
  }
  r.snapshotDue = due;
  const t = setTimeout(() => {
    r.snapshotTimer = null;
    r.snapshotDue = 0;
    if (!r.disposed) snapshot.refresh(r);
  }, Math.max(200, due - Date.now()));
  if (t.unref) t.unref();
  r.snapshotTimer = t;
}

function scheduleProfileWorker(r, delay = 200) {
  if (!r || r.disposed || !r.cfg.profile?.enabled) return;
  if (r.profileRunning || r.profileTimer) return;
  const t = setTimeout(() => {
    r.profileTimer = null;
    runProfileWorker(r).catch((e) => r.log.warn('星火资料补全异常：' + (e?.message || e)));
  }, Math.max(50, Number(delay) || 200));
  if (t.unref) t.unref();
  r.profileTimer = t;
}

async function fetchProfileRes(r, next) {
  const endpoint = next.kind === 'group' ? 'group_info' : 'get_user_info';
  const params = next.kind === 'group' ? { group_openid: next.id } : { user_openid: next.id };
  let directErr = null;

  // 有事件上下文 / 上次事件留下的 pluginApi 时，直接在本进程调接口，绕过本地 HTTP
  if (r.lastApi && typeof r.lastApi.call === 'function' && (!next.accountId || next.accountId === r.lastAccountId)) {
    try {
      const res = await r.lastApi.call(endpoint, { params });
      if (res && res.ok !== false) {
        const p = next.kind === 'group' ? profileApi.parseGroup(res.data) : profileApi.parseFriend(res.data);
        return { ok: true, ...p, empty: !p.name && !p.avatar, via: 'direct' };
      }
      directErr = { code: res?.code || '', message: res?.message || '' };
    } catch (e) {
      directErr = { code: 'THROW', message: e?.message || String(e) };
    }
  }

  const res =
    next.kind === 'group'
      ? await profileApi.fetchGroup(r.frameworkConfig, next.accountId, next.id)
      : await profileApi.fetchFriend(r.frameworkConfig, next.accountId, next.id);
  if (!res.ok && directErr) {
    res.message = `${res.message || ''}（直连 ${directErr.code || ''} ${directErr.message || ''}）`.trim();
  }
  res.via = 'http';
  return res;
}

async function runProfileWorker(r) {  if (r.profileRunning || r.disposed) return;
  r.profileRunning = true;
  r.profileStartedAt = Date.now();
  r.profileDone = 0;
  r.profileFailed = 0;
  r.profileError = '';
  r.profileLastError = null;
  let streak = 0;
  {
    const st = r.store.profileStats();
    r.log.info(`星火资料补全开始：待补好友 ${st.pendingFriends} / 群 ${st.pendingGroups}`);
  }
  try {
    while (!r.disposed) {
      const next = r.store.nextPendingProfile(r.profilePrefer, r.profileFilter);
      if (!next) break;
      if (r.cfg.profile.maxPerRun && r.profileDone + r.profileFailed >= r.cfg.profile.maxPerRun) break;
      r.store.markProfileAttempt(next.kind, next.id);
      let res;
      try {
        res = await fetchProfileRes(r, next);
      } catch (e) {
        res = { ok: false, code: 'THROW', message: e?.message || String(e), transient: false };
      }
      if (r.disposed) break;
      if (res.ok) {
        r.store.applyProfile(next.kind, next.id, res);
        if (res.empty) {
          r.profileFailed++;
          r.profileLastError = { kind: next.kind, id: next.id, code: 'EMPTY', message: '接口未返回名称/头像', at: Date.now() };
        } else {
          r.profileDone++;
        }
        streak = 0;
      } else if (res.transient) {
        r.store.revertProfileAttempt(next.kind, next.id);
        r.profileLastError = { kind: next.kind, id: next.id, code: res.code || '', message: res.message || '', at: Date.now() };
        streak++;
        if (streak >= 3) {
          r.profileError = res.message || res.code || '资料接口连续失败';
          break;
        }
        await U.sleep(1500);
        continue;
      } else {
        r.store.markProfileError(next.kind, next.id, res.message || res.code || '获取资料失败');
        r.profileLastError = { kind: next.kind, id: next.id, code: res.code || '', message: res.message || '', at: Date.now() };
        r.profileFailed++;
        if (r.profileFailed <= 3) {
          r.log.warn(
            `星火资料补全失败 ${next.kind}=${U.maskOpenid(next.id)} code=${res.code || '-'} ${String(res.message || '').slice(0, 200)}`,
          );
        }
      }
      if ((r.profileDone + r.profileFailed) % 10 === 0) {
        r.store.saveNow();
        snapshot.refresh(r);
      }
      await U.sleep(Math.max(200, r.cfg.profile.delayMs));
    }
  } finally {
    r.profileRunning = false;
    r.store.saveNow();
    snapshot.refresh(r);
    if (r.profileDone || r.profileFailed || r.profileError) {
      r.log.info(
        `星火资料补全：成功 ${r.profileDone} / 失败 ${r.profileFailed}` + (r.profileError ? `（${r.profileError}）` : ''),
      );
    }
    if (r.profileDone > 0) r.profileRetryCount = 0;
    let pending = !!r.store.nextPendingProfile(r.profilePrefer, r.profileFilter);
    if (r.profileFilter && !pending) {
      // 本次「刷新选中 / 补全某一类」目标已完成，不要顺手把另一类也刷了
      r.profileFilter = null;
      pending = false;
    }
    if (!r.disposed && pending) {
      if (!r.profileError) scheduleProfileWorker(r, 3000);
      else if (r.profileRetryCount < 2) {
        r.profileRetryCount++;
        scheduleProfileWorker(r, 20000);
      }
    }
  }
}



function parseCommand(cfg, text) {
  let s = String(text || '').trim();
  const prefix = String(cfg.command?.prefix || '');
  if (prefix && (s.startsWith(prefix) || (prefix === '/' && s.startsWith('／')))) {
    s = s.slice(prefix.length);
  } else if (s.startsWith('/') || s.startsWith('／')) {
    s = s.slice(1);
  }
  const tokens = s.split(/\s+/).filter(Boolean);
  return { name: (tokens.shift() || '').toLowerCase(), tokens };
}

function matchCommand(cfg, text) {
  if (!cfg.command?.enabled) return false;
  const { name } = parseCommand(cfg, text);
  if (!name) return false;
  return (cfg.command.names || []).includes(name);
}

function md(content) {
  return { replies: [{ type: 'markdown', markdown: { content: String(content || '') } }] };
}

function txt(content) {
  return { reply: String(content || '') };
}

function cmdTag(command, label) {
  const text = encodeURIComponent(String(command || ''));
  const show = encodeURIComponent(String(label || command || ''));
  return `<qqbot-cmd-input text="${text}" show="${show}" />`;
}

async function handleCommand(ctx, r, text) {
  const { tokens } = parseCommand(r.cfg, text);
  const sub = String(tokens[0] || '').toLowerCase();

  if (!tokens.length || ['help', '?', '帮助', '说明', '菜单'].includes(sub)) return helpReply(r);

  if (['余额', '钱包', 'balance', 'wallet', 'me', '我的', '资料'].includes(sub)) {
    return profileReply(ctx, r);
  }

  const codeArgs = tokens.filter((t) => !['兑换', '兑换码', 'redeem', 'use', 'code'].includes(t.toLowerCase()));
  const codeArg = codeArgs.join('');
  if (!codeArg) return helpReply(r);
  return redeem(ctx, r, codeArg);
}

function helpReply(r) {
  const cmd = (r.cfg.command.prefix || '/') + (r.cfg.command.names[0] || 'xh');
  const lines = [
    '## 星火 · 兑换码',
    `- 发送 ${cmdTag(`${cmd} 兑换码`, '兑换码')} 兑换龙晶 / 玄玉`,
    `- 发送 ${cmdTag(`${cmd} 余额`, '余额')} 查看我的 VloS 余额`,
    '',
    '> 兑换码由管理员发放；每个码可能有使用次数与有效期，兑换前请先让 VloS 识别你的账户（/add、/login 或 /bindopenid）。',
    '',
    `示例：\`${U.escapeMarkdown(cmd)} XHXXXXXXXXXX\``,
  ];
  return md(lines.join('\n'));
}

async function profileReply(ctx, r) {
  const m = ctx.message;
  const ids = messageIdentity(m);
  const user = vlosApi.resolveUser(ids);
  const cmd = (r.cfg.command.prefix || '/') + (r.cfg.command.names[0] || 'xh');
  if (!user) {
    return md(
      [
        '## 还没有绑定 VloS 账户',
        '> 星火的龙晶 / 玄玉会写到 **VloS 余额**，需要先让 VloS 识别你的账户。',
        '',
        `- 注册：私聊发送 ${cmdTag('/add 邮箱', '/add 邮箱')}`,
        `- 已有账户：私聊发送 ${cmdTag('/login 邮箱 密码', '/login 邮箱 密码')}`,
        `- 绑定当前 OpenID：私聊发送 ${cmdTag('/bindopenid', '/bindopenid')}`,
        '',
        '绑定后再发送 ' + cmdTag(`${cmd} 余额`, '余额') + ' 就能看到了。',
      ].join('\n'),
    );
  }
  const p = vlosApi.publicUser(user);
  return md(
    [
      '## 我的 VloS 账户',
      `- **邮箱**：${U.escapeMarkdown(p.email || '（未绑定）')}`,
      `- **QQ**：${U.escapeMarkdown(p.qq || '（未绑定）')}`,
      `- **VloS 余额**：龙晶 ${p.vlosBalance.longjing} · 玄玉 ${p.vlosBalance.xuanyu}`,
      '',
      '> VloS 余额由 VloS 管理；是否提交到聚龙世界由 VloS 决定（例如下次签到一并入账）。',
      '',
      `兑换码：${cmdTag(`${cmd} 兑换码`, '兑换码')}`,
    ].join('\n'),
  );
}

async function redeem(ctx, r, codeArg) {
  if (!r.cfg.redeem.enabled) return txt('星火兑换功能已关闭。');

  const code = U.normalizeCode(codeArg);
  if (code.length < 6) return txt('兑换码格式不正确，请检查后重试。');

  const c = r.store.getCode(code);
  if (!c) return md('## 兑换码不存在\n> 请检查是否输入完整（不区分大小写，横线可省略）。');
  if (c.status === 'disabled') return md('## 兑换码已停用\n> 这张码已被管理员停用。');
  if (c.status === 'failed') return md('## 兑换码异常\n> 这张码上次兑换时出现异常，请联系管理员处理。');
  if (c.status === 'redeeming') return txt('这张兑换码正在兑换中，请稍后重试。');
  if (c.status === 'exhausted' || (c.maxUses > 0 && c.uses >= c.maxUses)) return md('## 兑换码已被使用\n> 每个兑换码都有使用次数，这张已经用完了。');
  if (r.store.isExpired(c)) return md('## 兑换码已过期\n> 请联系管理员获取新的兑换码。');

  const m = ctx.message;
  const ids = messageIdentity(m);
  const userKey = ids[0] || '';
  const accountId = String(ctx.account?.id || '');

  if (c.oncePerUser && Array.isArray(c.redeemedBy) && c.redeemedBy.some((x) => ids.includes(String(x.openid || '')))) {
    return md('## 你已经兑换过这张码\n> 同一张兑换码每个用户只能兑换一次。');
  }

  const cooldown = r.cfg.redeem.cooldownSec;
  if (cooldown > 0 && userKey) {
    const last = r.cooldowns.get(userKey) || 0;
    if (Date.now() - last < cooldown * 1000) {
      return txt(`操作太频繁，请 ${Math.ceil((cooldown * 1000 - (Date.now() - last)) / 1000)} 秒后再试。`);
    }
    r.cooldowns.set(userKey, Date.now());
  }

  const hasReward = c.longjing > 0 || c.xuanyu > 0;
  let user = null;
  if (hasReward) {
    user = vlosApi.resolveUser(ids);
    if (!user) {
      return md(
        [
          '## 需要先绑定 VloS 账户',
          '> 兑换的龙晶 / 玄玉会写入 **VloS 余额**，请先让 VloS 识别到你。',
          '',
          `- 注册：私聊 ${cmdTag('/add 邮箱', '/add 邮箱')}`,
          `- 已有账户：私聊 ${cmdTag('/login 邮箱 密码', '/login 邮箱 密码')}`,
          `- 仅绑定 OpenID：私聊 ${cmdTag('/bindopenid', '/bindopenid')}`,
          '',
          '> 绑定完成后再发送一次兑换指令即可。',
        ].join('\n'),
      );
    }
    if (!user.email) {
      return md(
        [
          '## VloS 账户还没有邮箱',
          '> 请先在私聊里用 `/login 邮箱 密码` 登录，或 `/add 邮箱` 注册。',
          `> 当前识别到的账户：${U.escapeMarkdown(user.name || user.key || '')}`,
        ].join('\n'),
      );
    }
  }

  const begin = r.store.beginRedeem(code);
  if (!begin.ok) {
    if (begin.reason === 'busy') return txt('这张兑换码正在兑换中，请稍后重试。');
    if (begin.reason === 'used') return md('## 兑换码已被使用\n> 这张已经用完了。');
    if (begin.reason === 'expired') return md('## 兑换码已过期\n> 请联系管理员获取新的兑换码。');
    return txt('兑换码当前不可用，请稍后重试。');
  }

  r.redeeming.add(code);
  let granted = { longjing: 0, xuanyu: 0 };
  try {
    let result = { ok: true, via: 'none', granted };
    if (hasReward) {
      result = await vlosApi.credit(user.key || user.email, { longjing: c.longjing, xuanyu: c.xuanyu }, `星火兑换码 ${code}`);
      granted = result.granted || granted;
    }

    if (!result.ok) {
      r.store.abortRedeem(code, { error: result.message || '发放失败', granted });
      r.log.warn(
        `星火兑换失败 code=${code} openid=${U.maskOpenid(userKey)} granted=${granted.longjing}/${granted.xuanyu}：${result.message || ''}`,
      );
      if (granted.longjing > 0 || granted.xuanyu > 0) {
        return md(
          [
            '## 兑换未完全成功',
            `> 已到账：龙晶 ${granted.longjing} · 玄玉 ${granted.xuanyu}`,
            '> 剩余部分发放失败，这张码已冻结，请联系管理员处理（不要重复尝试）。',
          ].join('\n'),
        );
      }
      return md(
        '## 兑换失败\n> ' +
          U.escapeMarkdown(result.message || '奖励没有发放成功') +
          '\n> 兑换码已恢复可用，请稍后重试。\n> 如果一直失败，请联系管理员查看日志。',
      );
    }

    const record = {
      openid: userKey,
      accountId,
      email: user?.email || '',
      qq: user?.qq || '',
      name: user?.name || '',
      at: Date.now(),
      via: result.via || '',
      longjing: granted.longjing,
      xuanyu: granted.xuanyu,
    };
    const done = r.store.finishRedeem(code, record);
    snapshot.refresh(r);
    r.log.info(
      `星火兑换成功 code=${code} openid=${U.maskOpenid(userKey)} email=${record.email || '-'} ` +
        `龙晶+${granted.longjing} 玄玉+${granted.xuanyu} via=${record.via} ` +
        `VloS余额 ${result.before ? `${result.before.longjing}/${result.before.xuanyu}` : '?'} -> ` +
        `${result.after ? `${result.after.longjing}/${result.after.xuanyu}` : '?'}`,
    );

    const lines = ['## 兑换成功', `> 兑换码：\`${code}\``, ''];
    if (granted.longjing) lines.push(`- **龙晶**：+${granted.longjing}`);
    if (granted.xuanyu) lines.push(`- **玄玉**：+${granted.xuanyu}`);
    if (hasReward) {
      lines.push('- **到账位置**：VloS 余额');
    }
    if (done && done.maxUses > 1) lines.push(`- **本码剩余次数**：${Math.max(0, done.maxUses - done.uses)}`);
    if (c.message) {
      lines.push('', '> ' + String(c.message).split(/\r?\n/).map((x) => U.escapeMarkdown(x.trim())).filter(Boolean).join('\n> '));
    }
    return md(lines.join('\n'));
  } catch (e) {
    r.store.abortRedeem(code, { error: e?.message || String(e), granted });
    r.log.error(`星火兑换异常 code=${code}：${e?.stack || e}`);
    return md('## 兑换失败\n> 服务暂时不可用，兑换码已恢复可用，请稍后重试。');
  } finally {
    r.redeeming.delete(code);
  }
}

/* ======================= 设置页任务 ======================= */

async function processTasks(r) {
  const tasks = Array.isArray(r.cfg.tasks) ? r.cfg.tasks : [];
  for (const task of tasks) {
    if (!task || !task.id || r.store.taskDone(task.id)) continue;
    try {
      const result = await runTask(r, task);
      r.store.markTask(task.id, { type: task.type, ok: true, result });
      r.log.info(`星火任务 ${task.type} 完成：${summarize(result)}`);
    } catch (e) {
      r.store.markTask(task.id, { type: task.type, ok: false, error: e?.message || String(e) });
      r.log.warn(`星火任务 ${task.type} 失败：${e?.message || e}`);
    }
  }
}

function summarize(result) {
  try {
    return JSON.stringify(result).slice(0, 300);
  } catch {
    return String(result);
  }
}

async function runTask(r, task) {
  const payload = task.payload && typeof task.payload === 'object' ? task.payload : {};
  switch (task.type) {
    case 'import-users':
      return runImport(r, payload);
    case 'create-codes':
      return runCreateCodes(r, payload);
    case 'code-action':
      return runCodeAction(r, payload);
    case 'announce':
      return runAnnounce(r, payload);
    case 'announce-test':
      return runAnnounceTest(r, payload);
    case 'announce-cancel':
      return runAnnounceCancel(r, payload);
    case 'save-announcement':
      return runSaveAnnouncement(r, payload);
    case 'delete-announcement':
      return runDeleteAnnouncement(r, payload);
    case 'send-announcement':
      return runSendAnnouncement(r, payload);
    case 'refresh-profiles':
      return runRefreshProfiles(r, payload);
    case 'refresh-balance':
      return refreshBalance(r, true);
    default:
      throw new Error('未知任务类型：' + task.type);
  }
}

function runImport(r, payload) {
  const items = Array.isArray(payload.items)
    ? payload.items
    : [{ kind: payload.kind === 'group' ? 'group' : 'friend', rows: payload.rows }];
  const out = {};
  for (const item of items) {
    const kind = item?.kind === 'group' ? 'group' : 'friend';
    const rows = Array.isArray(item?.rows) ? item.rows : [];
    if (!rows.length) continue;
    const maxRows = r.cfg.import.maxRows;
    if (rows.length > maxRows) throw new Error(`单次导入超过上限 ${maxRows} 行`);
    const res = r.store.mergeRows(kind, rows, {
      source: U.cleanStr(payload.source || '', 200),
      accountId: U.cleanStr(payload.accountId || '', 80),
      appId: appIdOf(r, payload.accountId),
    });
    out[kind === 'group' ? 'groups' : 'friends'] = res;
  }
  if (!Object.keys(out).length) throw new Error('没有可导入的行');
  scheduleProfileWorker(r, 100);
  snapshot.refresh(r);
  return { ...out, profile: r.store.profileStats() };
}

function runCreateCodes(r, payload) {
  const list = Array.isArray(payload.codes) ? payload.codes : [];
  if (!list.length) throw new Error('没有要生成的兑换码');
  if (list.length > 500) throw new Error('单次最多生成 500 个兑换码');
  const res = r.store.createCodes(list, { createdBy: U.cleanStr(payload.createdBy || '', 80) });
  if (!res.created.length) throw new Error(res.skipped[0]?.reason || '没有生成任何兑换码');
  snapshot.refresh(r);
  return res;
}

function runCodeAction(r, payload) {
  const code = U.normalizeCode(payload.code);
  const action = String(payload.action || '');
  if (!['disable', 'enable', 'delete'].includes(action)) throw new Error('未知操作：' + action);
  const res = r.store.codeAction(code, action);
  if (!res.ok) throw new Error(res.reason === 'not_found' ? '兑换码不存在' : '操作失败');
  snapshot.refresh(r);
  return res;
}

function runAnnounce(r, payload) {
  const markdown = String(payload.markdown || r.cfg.announce.markdown || DEFAULT_ANNOUNCEMENT).slice(0, 20000);
  if (!markdown.trim()) throw new Error('公告内容为空');
  const enabled = new Set(r.cfg.enabledAccountIds || []);
  const targets = r.store
    .activeFriends()
    .filter((u) => !enabled.size || !u.accountId || enabled.has(u.accountId))
    .map((u) => ({ openid: u.openid, accountId: u.accountId || '' }));
  if (!targets.length) throw new Error('好友库为空（或启用的账户下没有好友）：先收一条私聊或导入私聊包');
  const job = r.store.createAnnouncement({
    markdown,
    targets,
    buttons: payload.buttons || [],
    delayMs: U.cleanInt(payload.delayMs, { min: 300, max: 60000, fallback: r.cfg.announce.delayMs }),
    maxPerRun: U.cleanInt(payload.maxPerRun, { min: 0, fallback: r.cfg.announce.maxPerRun }),
    createdBy: U.cleanStr(payload.createdBy || '', 80),
  });
  snapshot.refresh(r);
  return { id: job.id, total: job.total, delayMs: job.delayMs };
}

async function runAnnounceTest(r, payload) {
  const markdown = String(payload.markdown || r.cfg.announce.markdown || '').slice(0, 20000);
  if (!markdown.trim()) throw new Error('公告内容为空');
  const openid = String(payload.openid || r.cfg.announce.testOpenid || r.cfg.announce.adminOpenids[0] || '').trim();
  if (!openid) throw new Error('没有测试目标：先在设置页填「测试 OpenID」');
  if (!U.isValidOpenid(openid)) throw new Error('测试 OpenID 格式不正确（6–128 位字母数字 _ -）');
  const accountId = String(payload.accountId || r.accountId || '').trim();
  let res = await sender.sendC2CMarkdown({ config: r.frameworkConfig, accountId, openid, markdown });
  if (!res.ok && ['NETWORK', 'TIMEOUT'].includes(res.code) && r.bot) {
    res = await sender.sendC2CMarkdownDirect(r.bot, openid, markdown);
  }
  if (!res.ok) throw new Error(`测试发送失败：${res.message || res.code || '未知错误'}`);
  return { openid: U.maskOpenid(openid), code: res.code || '', via: res.via || '' };
}

function runAnnounceCancel(r, payload) {
  const job = r.store.cancelAnnouncement(String(payload.id || ''));
  if (!job) throw new Error('公告任务不存在');
  snapshot.refresh(r);
  return { id: job.id, status: job.status };
}

function runSaveAnnouncement(r, payload) {
  const markdown = String(payload.markdown || '').slice(0, 20000);
  const title = String(payload.title || '').slice(0, 120);
  if (!markdown.trim() && !title.trim()) throw new Error('公告标题和内容不能都为空');
  const res = r.store.saveTemplate({ id: String(payload.id || ''), title, markdown, buttons: payload.buttons });
  snapshot.refresh(r);
  return res;
}

function runDeleteAnnouncement(r, payload) {
  const ok = r.store.deleteTemplate(String(payload.id || ''));
  if (!ok) throw new Error('公告不存在');
  snapshot.refresh(r);
  return { id: String(payload.id || ''), deleted: true };
}

function runSendAnnouncement(r, payload) {
  const tpl = r.store.getTemplate(String(payload.templateId || ''));
  if (!tpl) throw new Error('公告不存在：先在「新建公告」保存');
  const enabled = new Set(r.cfg.enabledAccountIds || []);
  const active = r.store
    .activeFriends()
    .filter((u) => !enabled.size || !u.accountId || enabled.has(u.accountId));
  let targets = active;
  const selected = Array.isArray(payload.openids)
    ? payload.openids.map((x) => String(x || '').trim()).filter(U.isValidOpenid)
    : [];
  if (selected.length) {
    const set = new Set(selected);
    targets = active.filter((u) => set.has(u.openid));
    if (!targets.length) throw new Error('选中的好友都不在有效好友库里');
  }
  if (!targets.length) throw new Error('好友库为空（或启用的账户下没有好友）：先收一条私聊或导入私聊包');

  const job = r.store.createAnnouncement({
    markdown: tpl.markdown,
    title: tpl.title,
    templateId: tpl.id,
    buttons: tpl.buttons || [],
    targets: targets.map((u) => ({ openid: u.openid, accountId: u.accountId || '' })),
    delayMs: U.cleanInt(payload.delayMs, { min: 300, max: 60000, fallback: r.cfg.announce.delayMs }),
    maxPerRun: U.cleanInt(payload.maxPerRun, { min: 0, fallback: r.cfg.announce.maxPerRun }),
    createdBy: U.cleanStr(payload.createdBy || '', 80),
  });
  r.store.markTemplateSent(tpl.id, job.id);
  snapshot.refresh(r);
  scheduleWorker(r);
  return { id: job.id, title: tpl.title, templateId: tpl.id, total: job.total, delayMs: job.delayMs };
}

function runRefreshProfiles(r, payload) {
  const scope = ['friend', 'group', 'all'].includes(payload.scope) ? payload.scope : 'all';
  const ids = Array.isArray(payload.ids)
    ? payload.ids.map((x) => String(x || '').trim()).filter(U.isValidOpenid)
    : [];
  const onlyFailed = !!payload.onlyFailed;
  const count = r.store.resetProfiles(scope, ids, { onlyFailed });
  r.profilePrefer = scope === 'all' ? 'friend' : scope;
  r.profileFilter = { scope, ids: new Set(ids) };
  r.profileLastError = null;
  scheduleProfileWorker(r, 50);
  snapshot.refresh(r);
  return { scope, selected: ids.length, onlyFailed, count, profile: r.store.profileStats() };
}

/* ======================= 公告发送 ======================= */

function scheduleWorker(r) {
  if (!r || r.disposed || r.workerTimer || r.sending) return;
  const job = r.store.runnableAnnouncement();
  if (!job) return;
  const t = setTimeout(() => {
    r.workerTimer = null;
    runAnnouncement(r, job.id).catch((e) => r.log.warn('星火公告发送异常：' + (e?.message || e)));
  }, 80);
  if (t.unref) t.unref();
  r.workerTimer = t;
}

async function runAnnouncement(r, jobId) {
  if (r.sending) return;
  r.sending = true;
  try {
    let job = r.store.getAnnouncement(jobId);
    if (!job) return;
    if (job.status === 'queued') {
      job = r.store.updateAnnouncement(jobId, { status: 'running', startedAt: Date.now() });
      r.log.info(`星火公告开始：${job.id}，目标 ${job.total} 人，间隔 ${job.delayMs}ms`);
    }

    while (!r.disposed) {
      job = r.store.getAnnouncement(jobId);
      if (!job || job.status !== 'running') break;
      if (job.cursor >= job.targets.length) {
        r.store.updateAnnouncement(jobId, { status: 'done', finishedAt: Date.now() });
        snapshot.refresh(r);
        r.log.info(`星火公告完成：${job.id}，成功 ${job.sent} / 失败 ${job.failed} / 共 ${job.total}`);
        break;
      }
      if (job.maxPerRun && job.sent + job.failed >= job.maxPerRun) {
        r.store.updateAnnouncement(jobId, { status: 'done', finishedAt: Date.now(), stoppedByLimit: true });
        snapshot.refresh(r);
        r.log.info(`星火公告达到单次上限：${job.id}，已发 ${job.sent} / 失败 ${job.failed}`);
        break;
      }

      const target = job.targets[job.cursor];
      const res = await sendOne(r, target, job.markdown, job.buttons);
      if (r.disposed) break;

      const current = r.store.getAnnouncement(jobId);
      if (!current || current.status !== 'running') break;
      const after = r.store.recordAnnouncementResult(jobId, target, res);
      if (!res.ok) {
        r.log.warn(
          `星火公告发送失败 openid=${U.maskOpenid(target.openid)} code=${res.code || '-'} ${String(res.message || '').slice(0, 200)}`,
        );
        // 接收失败的好友标记为「无效」，避免下次群发继续撞同一个 openid；
        // 本地网络 / 令牌问题不是好友的错，不标记。
        if (!['NETWORK', 'TIMEOUT', 'NO_TOKEN', 'READ_ERROR'].includes(String(res.code || ''))) {
          r.store.markFriendInvalid(target.openid, `${res.code || ''} ${res.message || '发送失败'}`.trim());
        }
      }
      if (after && (after.cursor % 10 === 0 || !res.ok)) {
        r.store.saveNow();
        snapshot.refresh(r);
      }

      if (r.disposed) break;
      await U.sleep(job.delayMs);
    }
  } finally {
    r.sending = false;
    if (!r.disposed) {
      snapshot.refresh(r);
      scheduleWorker(r);
    }
  }
}

async function sendOne(r, target, markdown, buttons) {
  const openid = String(target?.openid || '');
  const accountId = String(target?.accountId || r.accountId || '');
  const keyboard = buildKeyboard(buttons);
  let res = await sender.sendC2CMarkdown({ config: r.frameworkConfig, accountId, openid, markdown, keyboard });

  // 自定义按钮需要开放平台开通；没开通时 QQ 会拒整条消息。去掉键盘重发一次纯 Markdown，
  // 不让「按钮不可用」把好友误标为无效。
  if (!res.ok && keyboard && isKeyboardReject(res)) {
    r.log.warn(`星火：按钮被 QQ 拒绝（${res.code || '-'} ${res.message || ''}），已改发纯 Markdown`);
    const retry = await sender.sendC2CMarkdown({ config: r.frameworkConfig, accountId, openid, markdown });
    if (retry.ok) retry.keyboardDropped = true;
    res = retry;
  }

  // 本地 HTTP 不可用（面板刚重启 / 端口被占用）时，尝试用事件里保存的 bot 实例
  if (!res.ok && ['NETWORK', 'TIMEOUT', 'NO_TOKEN'].includes(res.code) && r.bot) {
    let direct = await sender.sendC2CMarkdownDirect(r.bot, openid, markdown, keyboard);
    if (!direct.ok && keyboard && isKeyboardReject(direct)) {
      const plain = await sender.sendC2CMarkdownDirect(r.bot, openid, markdown);
      if (plain.ok) plain.keyboardDropped = true;
      direct = plain;
    }
    if (direct.ok || !res.ok) res = direct;
  }

  // 频控：等 3 秒重试一次
  if (!res.ok && /40034|40054005|频率|过于频繁|freq/i.test(`${res.code} ${res.message}`)) {
    await U.sleep(3000);
    if (r.disposed) return res;
    const retry = await sender.sendC2CMarkdown({ config: r.frameworkConfig, accountId, openid, markdown, keyboard });
    if (retry.ok || !res.ok) res = retry;
  }
  return res;
}

/* ======================= 余额 ======================= */

async function refreshBalance(r, force = false) {
  try {
    const bal = vlosApi.readBalance();
    r.store.setBalance(bal);
    if (force) r.store.saveNow();
    if (!bal.ready) {
      warnOnce(r, 'balance-' + (bal.error || ''), '星火：读取 VloS 余额失败：' + (bal.error || '未知原因'));
    } else if (force) {
      r.log.info(`星火余额：VloS余额合计 龙晶 ${bal.pool.vlosLongjing} · 玄玉 ${bal.pool.vlosXuanyu}`);
    }
    snapshot.refresh(r);
    return bal;
  } catch (e) {
    r.store.setBalance({ ready: false, error: e?.message || String(e), pool: null });
    r.log.warn('星火：读取 VloS 余额异常：' + (e?.message || e));
    snapshot.refresh(r);
    return null;
  }
}

module.exports = {
  onLoad,
  onEvent,
  onUnload,
  /** 给测试/其它插件用的只读入口（不作为正式 API 承诺） */
  __internal: {
    PLUGIN_ID,
    PLUGIN_VERSION,
    parseCommand,
    matchCommand,
    messageIdentity,
    runTask,
  },
};
