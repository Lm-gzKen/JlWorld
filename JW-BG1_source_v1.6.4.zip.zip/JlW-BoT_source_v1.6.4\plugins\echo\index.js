'use strict';
// 回声示例：最小可用的 JS 插件
// 支持命令：/ping  /echo 任意文本
module.exports = {
  async onLoad(ctx) {
    ctx.log.info('echo 插件已加载');
  },

  async onEvent(ctx) {
    const { message, plugin } = ctx;
    if (!message) return null;
    const text = (message.cleanContent || '').trim();

    if (!text) return null;

    // 不依赖前缀的简单匹配
    if (/^\/?ping$/i.test(text)) {
      return { reply: 'pong · ' + new Date().toLocaleTimeString('zh-CN', { hour12: false }) };
    }
    if (/^\/?echo\s+/i.test(text)) {
      return { reply: text.replace(/^\/?echo\s+/i, '') };
    }

    // 命令未匹配时不回复（返回 null），把机会留给后续插件
    if (!message.command?.name) return null;
    if (message.command.name === '帮助' || message.command.name === 'help') {
      return {
        replies: [
          {
            type: 'text',
            content: `可用命令：\n/ping  —— 延迟测试\n/echo <文本>  —— 回声\n\n当前插件：${plugin.id}`,
          },
        ],
      };
    }
    return null;
  },
};
