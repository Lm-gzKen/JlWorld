'use strict';
/**
 * 回响（huixiang）插件测试
 *
 *   A. 单元测试：假 ctx 直接调用插件模块，覆盖 Markdown 报文、回退、字段缺失
 *   B. 端到端：假 QQ 服务器 + 真实框架进程 + 真实插件加载，覆盖四条命令与“普通聊天不回复”
 *
 * 运行：node test/huixiang-e2e.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');
const { parseCommand } = require('../src/core/bot');

const ROOT = path.resolve(__dirname, '..');
const PLUGIN_DIR = path.resolve(process.env.HUIXIANG_PLUGIN_DIR || path.join(ROOT, '~JlWBoT', 'plugins', 'huixiang'));
const FRAMEWORK_VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 10000, interval = 120, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

function shiftDay(delta) {
  const d = new Date();
  d.setDate(d.getDate() + delta);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/* ================= A. 单元测试 ================= */

let unitSeq = 0;

function makeMessage(content, opts = {}) {
  const kind = opts.kind || 'group';
  const user = opts.user || 'U_UNIT';
  const message = {
    id: opts.id || 'MSG_UNIT_' + ++unitSeq,
    kind,
    content,
    cleanContent: content,
    group_openid: kind === 'group' ? opts.group || 'G_UNIT' : '',
    user_openid: kind === 'c2c' ? user : '',
    channel_id: opts.channel_id || '',
    guild_id: opts.guild_id || '',
    author: {
      id: user,
      member_openid: kind === 'group' ? opts.member || 'U_MEMBER' : '',
      user_openid: kind === 'c2c' ? user : '',
      username: '单元用户',
      bot: !!opts.bot,
    },
  };
  message.command = opts.noCommand ? undefined : parseCommand(message.cleanContent.trim(), '');
  return message;
}

function makeCtx(message, overrides = {}) {
  const sent = [];
  const api = {
    me: async () => ({
      ok: true,
      duration: 42,
      data: { username: '单元机器人', avatar: 'http://thirdqq.qlogo.cn/unit.png' },
    }),
    reply: async (msg, payload) => {
      sent.push(payload);
      return { ok: true };
    },
    ...(overrides.api || {}),
  };
  return {
    plugin: { id: 'huixiang', dir: PLUGIN_DIR, config: {} },
    framework: { version: '1.2.0' },
    event: { ts: Date.now(), source: 'ws' },
    account: { id: 'a1', name: '单元账户' },
    log: { info() {}, warn() {}, error() {} },
    bot: { info: () => ({ name: '单元机器人', avatar: 'http://thirdqq.qlogo.cn/unit.png', mode: 'ws' }) },
    message,
    sent,
    ...(overrides.ctx || {}),
    api,
  };
}

async function unitTests() {
  const plugin = require(path.join(PLUGIN_DIR, 'index.js'));
  let passed = 0;
  const ok = (cond, label) => {
    assert.ok(cond, label);
    console.log('  ✓ ' + label);
    passed++;
  };

  // /ping
  let out = await plugin.onEvent(makeCtx(makeMessage('/ping')));
  ok(
    /^砰！ · 延迟 42ms · \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(out.reply),
    '/ping 输出：' + out.reply,
  );

  const refMsg = makeMessage('/ping');
  refMsg.scene = { source: 'default', ext: ['msg_idx=REFIDX_UNIT==', 'auth_token=x'] };
  const refCtx = makeCtx(refMsg);
  out = await plugin.onEvent(refCtx);
  ok(
    out === null && refCtx.sent[0]?.message_reference?.message_id === 'REFIDX_UNIT==',
    '/ping 引用原消息',
  );

  out = await plugin.onEvent(makeCtx(makeMessage('/PING')));
  ok(String(out.reply).startsWith('砰！ ·'), '/PING 大小写不敏感');

  out = await plugin.onEvent(makeCtx(makeMessage('ping')));
  ok(out === null, '不带 / 的 ping 不回复');

  out = await plugin.onEvent(makeCtx(makeMessage('状态')));
  ok(out === null, '不带 / 的 状态 不回复');

  out = await plugin.onEvent(makeCtx(makeMessage('／ping')));
  ok(String(out.reply).startsWith('砰！ ·'), '全角 ／ping 仍识别');

  out = await plugin.onEvent(
    makeCtx(makeMessage('/ping'), { api: { me: async () => ({ ok: false, code: 11244, message: 'token invalid' }) } }),
  );
  ok(String(out.reply).includes('延迟 --'), '接口不可用时 /ping 显示 --');

  // /状态：Markdown
  const statusCtx = makeCtx(makeMessage('/状态'));
  out = await plugin.onEvent(statusCtx);
  const payload = statusCtx.sent[0];
  ok(out === null && statusCtx.sent.length === 1 && payload.msg_type === 2, '/状态 直接发送 msg_type=2');
  const md = payload.markdown.content;
  ok(md.includes('![头像 #48px #48px](https://thirdqq.qlogo.cn/unit.png)'), '状态卡头像转 https');
  ok(md.includes('**单元机器人**'), '状态卡含机器人名称');
  ok(md.includes('- 接入方式：WebSocket 长连接'), '状态卡含接入方式');
  ok(md.includes('- 框架版本：v1.2.0'), '状态卡含框架版本');
  ok(/- 运行时长：\d/.test(md), '状态卡含运行时长');
  ok(md.includes('[框架下载【https://www.jlworld.net/】](https://www.jlworld.net/)'), '状态卡含下载链接');

  // downloadUrl 可配置
  const cfgCtx = makeCtx(makeMessage('/状态'), {
    ctx: { plugin: { id: 'huixiang', dir: PLUGIN_DIR, config: { downloadUrl: 'https://example.com/dl' } } },
  });
  await plugin.onEvent(cfgCtx);
  ok(
    cfgCtx.sent[0].markdown.content.includes('[框架下载【https://example.com/dl】](https://example.com/dl)'),
    'config.downloadUrl 生效',
  );

  // Markdown 发送失败 → 纯文本
  out = await plugin.onEvent(
    makeCtx(makeMessage('/状态'), {
      api: { reply: async () => ({ ok: false, code: 40054001, message: 'markdown not allowed' }) },
    }),
  );
  ok(
    out && out.reply.startsWith('回响 · 运行状态') && out.reply.includes('框架下载【https://www.jlworld.net/】'),
    'Markdown 失败自动回退纯文本',
  );

  // 频道场景不发 Markdown
  const chCtx = makeCtx(makeMessage('/状态', { kind: 'channel', channel_id: 'CH1', guild_id: 'GD1' }));
  out = await plugin.onEvent(chCtx);
  ok(out && out.reply.includes('回响 · 运行状态') && chCtx.sent.length === 0, '频道场景走纯文本');

  // 无头像
  const noAvatarCtx = makeCtx(makeMessage('/状态'), {
    api: { me: async () => ({ ok: true, duration: 5, data: { username: '无头像', avatar: '' } }) },
    ctx: { bot: { info: () => ({ name: '无头像', avatar: '', mode: 'ws' }) } },
  });
  await plugin.onEvent(noAvatarCtx);
  ok(noAvatarCtx.sent[0].markdown.content.startsWith('**无头像**'), '无头像时省略图片');

  // /openid
  out = await plugin.onEvent(makeCtx(makeMessage('/openid', { member: 'M_OPEN_1' })));
  ok(String(out.reply).includes('M_OPEN_1') && out.reply.includes('群成员 OpenID'), '/openid 返回群成员 openid');

  out = await plugin.onEvent(makeCtx(makeMessage('/openid', { kind: 'c2c', user: 'U_OPEN_9' })));
  ok(String(out.reply).includes('U_OPEN_9') && out.reply.includes('单聊用户 OpenID'), '/openid 返回单聊 openid');

  out = await plugin.onEvent(makeCtx(makeMessage('/opendi', { member: 'M_ALIAS' })));
  ok(String(out.reply).includes('M_ALIAS'), '/opendi 旧笔误写法仍兼容');

  // /gopenid
  out = await plugin.onEvent(makeCtx(makeMessage('/gopenid', { group: 'G_OPEN_7' })));
  ok(String(out.reply).includes('G_OPEN_7') && out.reply.includes('当前群聊 OpenID'), '/gopenid 返回群 openid');

  out = await plugin.onEvent(makeCtx(makeMessage('/gopenid', { kind: 'c2c', user: 'U1' })));
  ok(String(out.reply).includes('不是群聊会话'), '/gopenid 单聊提示无群 openid');

  // /data：单账户（config.json 不存在 → 只用当前账户）
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hx-data-'));
  const msgDir = path.join(dataDir, 'data');
  fs.mkdirSync(msgDir);
  const dump = (arr) => arr.map((x) => JSON.stringify(x)).join('\n') + '\n';
  fs.writeFileSync(
    path.join(msgDir, `messages-${shiftDay(-1)}.jsonl`),
    dump([
      { kind: 'group', group_openid: 'G1' },
      { kind: 'group', group_openid: 'G1' },
      { kind: 'group', group_openid: 'G2' },
      { kind: 'c2c', user_openid: 'U1' },
    ]),
  );
  fs.writeFileSync(
    path.join(msgDir, `messages-${shiftDay(0)}.jsonl`),
    dump([
      { kind: 'group', group_openid: 'G1' },
      { kind: 'group', group_openid: 'G3' },
      { kind: 'c2c', user_openid: 'U2' },
    ]),
  );

  const dataCtx = makeCtx(makeMessage('/data'), { ctx: { framework: { version: '1.2.0', dataDir } } });
  out = await plugin.onEvent(dataCtx);
  const dtxt = String(out.reply);
  ok(dtxt.startsWith('回响 · 数据总览\n【单元账户】'), '/data 按账户分节');
  ok(dtxt.includes('群聊总数：3'), '/data 群聊总数');
  ok(dtxt.includes('▲今日添加：+1'), '/data 今日新增群 ▲');
  ok(dtxt.includes('私聊总数：2'), '/data 私聊总数');
  ok(dtxt.includes('群聊今日消息：2 条'), '/data 群聊今日消息');
  ok(dtxt.includes('▼对比昨日：-1'), '/data 群聊对比昨日 ▼');
  ok(dtxt.includes('私聊今日消息：1 条'), '/data 私聊今日消息');
  ok(dtxt.includes('对比昨日：0'), '/data 私聊对比昨日 0');
  ok(dtxt.includes('全量群聊（本机器人）：—'), '/data 无 bot_state 时显示 —');

  // /data：双账户按 bot_state / user info 反推归属
  const dataDir2 = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hx-data2-'));
  fs.mkdirSync(path.join(dataDir2, 'data'));
  fs.copyFileSync(path.join(msgDir, `messages-${shiftDay(-1)}.jsonl`), path.join(dataDir2, 'data', `messages-${shiftDay(-1)}.jsonl`));
  fs.copyFileSync(path.join(msgDir, `messages-${shiftDay(0)}.jsonl`), path.join(dataDir2, 'data', `messages-${shiftDay(0)}.jsonl`));
  fs.writeFileSync(
    path.join(dataDir2, 'config.json'),
    JSON.stringify({ accounts: [{ id: 'a1', name: '甲' }, { id: 'a2', name: '乙' }] }),
    'utf8',
  );

  const splitCtx = makeCtx(makeMessage('/data'), {
    ctx: { account: { id: 'a1', name: '甲' }, framework: { version: '1.2.0', dataDir: dataDir2 } },
    api: {
      request: async (method, p) => {
        if (p.includes('/groups/G3/bot_state')) return { ok: true, data: { member_role: 'admin', recv_msg_setting: 'all' } };
        if (p.includes('/groups/')) return { ok: false, code: 11255 };
        if (p.includes('/users/U1/info')) return { ok: true, data: {} };
        if (p.includes('/users/')) return { ok: false, code: 11255 };
        return { ok: false, code: 0 };
      },
    },
  });
  out = await plugin.onEvent(splitCtx);
  const stxt = String(out.reply);
  ok(stxt.includes('【甲】') && stxt.includes('【乙】'), '/data 双账户分节');
  ok(stxt.includes('群聊总数：1') && stxt.includes('群聊总数：2'), '/data 双账户群聊总数拆分');
  ok(stxt.includes('群聊今日消息：1 条') && stxt.includes('▼对比昨日：-2'), '/data 双账户消息与昨日对比拆分');
  ok(stxt.includes('全量群聊（本机器人）：1 个'), '/data 当前账户全量群统计');
  ok(stxt.includes('全量群聊（本机器人）：—'), '/data 另一账户未查时显示 —');

  out = await plugin.onEvent(makeCtx(makeMessage('/数据'), { ctx: { framework: { version: '1.2.0', dataDir } } }));
  ok(String(out.reply).includes('数据总览'), '/数据 别名可用');

  // /data -1：昨天
  out = await plugin.onEvent(makeCtx(makeMessage('/data -1'), { ctx: { framework: { version: '1.2.0', dataDir } } }));
  const ytxt = String(out.reply);
  ok(ytxt.startsWith(`回响 · 数据总览（${shiftDay(-1)}）\n【单元账户】`), '/data -1 显示昨天');
  ok(ytxt.includes('群聊总数：2') && ytxt.includes('▲今日添加：+2'), '/data -1 群聊总数/新增');
  ok(ytxt.includes('群聊今日消息：3 条') && ytxt.includes('▲对比昨日：+3'), '/data -1 消息/对比');
  ok(!ytxt.includes('全量群聊'), '/data -1 不显示实时全量/管理员');

  // /data -2：超出已有记录
  out = await plugin.onEvent(makeCtx(makeMessage('/data -2'), { ctx: { framework: { version: '1.2.0', dataDir } } }));
  ok(String(out.reply).includes('没有'), '/data -2 超出历史提示');

  // 非法参数
  out = await plugin.onEvent(makeCtx(makeMessage('/data abc'), { ctx: { framework: { version: '1.2.0', dataDir } } }));
  ok(String(out.reply).startsWith('用法：'), '/data 非法参数提示用法');

  // VSQL 每日记录（假 VSQL API）
  const upserts = [];
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([
    [
      'VSQL',
      {
        isReady: () => true,
        db: () => ({
          table: () => {},
          tx: (fn) => fn(),
          upsert: (table, row) => upserts.push({ table, row }),
        }),
      },
    ],
  ]);
  await plugin.onEvent(makeCtx(makeMessage('/data'), { ctx: { framework: { version: '1.2.0', dataDir } } }));
  const todayRow = upserts.find(
    (x) => x.table === 'huixiang_daily' && x.row.date === shiftDay(0) && x.row.account_id === 'a1',
  );
  ok(!!todayRow && todayRow.row.group_msgs === 2 && todayRow.row.c2c_msgs === 1, '/data 写入 VSQL 每日记录');
  delete globalThis.__JLWBOT_PLUGIN_APIS__;

  fs.rmSync(dataDir, { recursive: true, force: true });
  fs.rmSync(dataDir2, { recursive: true, force: true });

  // 过滤
  out = await plugin.onEvent(makeCtx(makeMessage('今天天气不错')));
  ok(out === null, '普通聊天不回复');

  out = await plugin.onEvent(makeCtx(makeMessage('/ping', { bot: true })));
  ok(out === null, '机器人消息不回复');

  const prefixed = makeMessage('/ping');
  prefixed.command = { name: '', args: [], text: '', matched: false };
  out = await plugin.onEvent(makeCtx(prefixed));
  ok(out === null, '前缀不匹配不回复');

  // 框架没给 command 对象时按首词兜底
  out = await plugin.onEvent(makeCtx(makeMessage('/openid', { noCommand: true, member: 'M_FALLBACK' })));
  ok(String(out.reply).includes('M_FALLBACK'), '缺少 command 对象时按首词兜底');

  console.log(`  单元测试通过 ${passed} 项`);
  return passed;
}

/* ================= B. 端到端 ================= */

async function main() {
  assert.ok(fs.existsSync(path.join(PLUGIN_DIR, 'plugin.json')), '找不到插件目录：' + PLUGIN_DIR);

  console.log('\n回响插件测试\n');
  console.log('[1/2] 单元测试（假 ctx）');
  const unitPassed = await unitTests();

  console.log('\n[2/2] 端到端（假 QQ + 真实框架 + 真实插件）');
  const mock = await new MockQQ({ port: 0, accounts: { app_hx: 'sec_hx' } }).start();
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const panelPort = 22100 + Math.floor(Math.random() * 400);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hx-'));
  const pluginDst = path.join(dataDir, 'plugins', 'huixiang');
  fs.mkdirSync(path.dirname(pluginDst), { recursive: true });
  fs.cpSync(PLUGIN_DIR, pluginDst, { recursive: true });
  // 阻止框架把仓库里的示例插件复制到临时数据目录，避免 echo/status 抢答
  fs.writeFileSync(path.join(dataDir, 'plugins', '.seeded'), 'test\n', 'utf8');
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port: panelPort, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        accounts: [
          {
            id: 'a1',
            name: '回响测试',
            appId: 'app_hx',
            clientSecret: 'sec_hx',
            enabled: true,
            mode: 'ws',
            sandbox: false,
            prefix: '',
            tokenUrl: mock.base + '/app/getAppAccessToken',
            tokenUrlAlt: mock.base + '/app/getAppAccessToken',
            apiBase: mock.base,
            apiBaseSandbox: mock.base,
            gatewayUrl: mock.wsUrl,
            intents: ['GUILDS', 'GROUP_AND_C2C_EVENT'],
            shardId: 0,
            shardCount: 1,
          },
        ],
        plugins: { enabled: true, defaultTimeoutMs: 8000 },
        log: { level: 'info', console: false },
        storage: { messages: false, events: 100 },
      },
      null,
      2,
    ),
    'utf8',
  );

  // /data 统计用的历史消息记录（storage.messages=false，运行中的消息不会改写 fixture）
  // 注意：框架 1.4.16+ 会把 JSONL 迁进 SQLite，迁移按记录里的 t 分天，所以 fixture 必须带 t
  const historyDir = path.join(dataDir, 'data');
  fs.mkdirSync(historyDir, { recursive: true });
  const dump = (arr) => arr.map((x) => JSON.stringify(x)).join('\n') + '\n';
  const tsYesterday = Date.parse(`${shiftDay(-1)}T12:00:00+08:00`);
  const tsToday = Date.parse(`${shiftDay(0)}T12:00:00+08:00`);
  fs.writeFileSync(
    path.join(historyDir, `messages-${shiftDay(-1)}.jsonl`),
    dump([
      { t: tsYesterday, kind: 'group', group_openid: 'G1' },
      { t: tsYesterday, kind: 'group', group_openid: 'G1' },
      { t: tsYesterday, kind: 'group', group_openid: 'G2' },
      { t: tsYesterday, kind: 'c2c', user_openid: 'U1' },
    ]),
  );
  fs.writeFileSync(
    path.join(historyDir, `messages-${shiftDay(0)}.jsonl`),
    dump([
      { t: tsToday, kind: 'group', group_openid: 'G1' },
      { t: tsToday, kind: 'group', group_openid: 'G3' },
      { t: tsToday, kind: 'c2c', user_openid: 'U2' },
    ]),
  );

  // 说明：沙箱环境不允许通过 pipe 捕获子进程输出（EPERM），所以用 ignore；
  // 排查失败时读临时数据目录里的 jsonl 日志。
  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const readLogTail = (dir, lines = 40) => {
    try {
      const logDir = path.join(dir, 'logs');
      const files = fs.readdirSync(logDir).filter((f) => f.endsWith('.jsonl')).sort();
      if (!files.length) return '(无日志文件)';
      const text = fs.readFileSync(path.join(logDir, files[files.length - 1]), 'utf8');
      return text
        .split('\n')
        .filter(Boolean)
        .slice(-lines)
        .map((l) => {
          try {
            const r = JSON.parse(l);
            return `${r.time} ${r.level} ${r.scope || ''} ${r.msg}${r.meta ? ' ' + JSON.stringify(r.meta) : ''}`;
          } catch {
            return l;
          }
        })
        .join('\n');
    } catch (e) {
      return '(读取日志失败: ' + e.message + ')';
    }
  };

  const base = `http://127.0.0.1:${panelPort}`;
  const sentBy = (id) => mock.sent.filter((s) => s.body.msg_id === id);
  let seq = 7000;
  let passed = 0;
  const ok = (cond, label) => {
    assert.ok(cond, label);
    console.log('  ✓ ' + label);
    passed++;
  };

  const push = (t, d) =>
    mock.push(t, d, { appId: 'app_hx', seq: ++seq });

  const groupEvent = (content, { id, group = 'G_HX', user = 'U_HX' } = {}) => {
    const msgId = id || 'MSG_IN_' + ++seq;
    push('GROUP_MESSAGE_CREATE', {
      id: msgId,
      content,
      group_openid: group,
      author: { id: user, member_openid: user, username: '端到端用户', member_role: 'member' },
      timestamp: new Date().toISOString(),
      message_type: 0,
      message_scene: { source: 'default', ext: ['msg_idx=REFIDX_E2E==', 'auth_token=x'] },
    });
    return msgId;
  };

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 20000, 200, '框架启动');
    ok(true, '框架启动');

    await waitFor(() => mock.identifies.app_hx, 15000, 150, '机器人上线');
    ok(mock.identifies.app_hx.token === 'QQBot mock_token_app_hx', '假 QQ 鉴权完成');

    // 1. /ping（普通群消息，不带 @）
    const idPing = groupEvent('/ping');
    const ping = await waitFor(() => sentBy(idPing)[0], 8000, 120, '/ping 回复');
    ok(
      ping.body.msg_type === 0 &&
        /^砰！ · 延迟 \d+ms · \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(ping.body.content)),
      '/ping → ' + ping.body.content,
    );
    ok(ping.body.message_reference?.message_id === 'REFIDX_E2E==', '/ping 引用原消息');

    // 2. /PING 大小写
    const idUpper = groupEvent('/PING');
    const upper = await waitFor(() => sentBy(idUpper)[0], 8000, 120, '/PING 回复');
    ok(String(upper.body.content).startsWith('砰！ ·'), '/PING 大小写不敏感');

    // 3. @ 机器人的消息
    const atId = 'MSG_IN_AT';
    push('GROUP_AT_MESSAGE_CREATE', {
      id: atId,
      content: '<@!10000> /ping',
      group_openid: 'G_HX',
      author: { id: 'U_AT', member_openid: 'U_AT', username: '艾特用户' },
      timestamp: new Date().toISOString(),
    });
    const atReply = await waitFor(() => sentBy(atId)[0], 8000, 120, '@ 消息回复');
    ok(String(atReply.body.content).startsWith('砰！ ·'), '@ 消息去掉 <@!id> 后仍命中 /ping');

    // 4. /状态（Markdown）
    const idStatus = groupEvent('/状态');
    const status = await waitFor(() => sentBy(idStatus)[0], 8000, 120, '/状态 回复');
    const md = status.body.markdown?.content || '';
    ok(status.body.msg_type === 2, '/状态 使用 Markdown（msg_type=2）');
    ok(md.includes('![头像 #48px #48px](https://thirdqq.qlogo.cn/mock-avatar.png)'), '状态卡头像 https');
    ok(md.includes('**MockBot-app_hx**'), '状态卡含机器人名称');
    ok(md.includes('- 接入方式：WebSocket 长连接'), '状态卡含接入方式');
    ok(md.includes(`- 框架版本：v${FRAMEWORK_VERSION}`), '状态卡含框架版本');
    ok(/- 运行时长：\d/.test(md), '状态卡含运行时长');
    ok(md.includes('[框架下载【https://www.jlworld.net/】](https://www.jlworld.net/)'), '状态卡含下载链接');
    ok(sentBy(idStatus).length === 1, '一条消息只回一条（没有 Markdown + 文本双发）');

    // 5. /openid（群）
    const idOpen = groupEvent('/openid', { user: 'U_MEMBER_88' });
    const open = await waitFor(() => sentBy(idOpen)[0], 8000, 120, '/openid 回复');
    ok(
      String(open.body.content).includes('U_MEMBER_88') && String(open.body.content).includes('群成员 OpenID'),
      '/openid 返回群成员 openid',
    );

    // 6. /gopenid（群）
    const idG = groupEvent('/gopenid', { group: 'G_OPEN_66' });
    const g = await waitFor(() => sentBy(idG)[0], 8000, 120, '/gopenid 回复');
    ok(String(g.body.content).includes('G_OPEN_66'), '/gopenid 返回当前群 openid');

    // 7. 单聊 /openid
    const c2cId = 'MSG_IN_C2C';
    push('C2C_MESSAGE_CREATE', {
      id: c2cId,
      content: '/openid',
      author: { id: 'U_C2C_1', user_openid: 'U_C2C_1', username: '单聊用户' },
      timestamp: new Date().toISOString(),
    });
    const c2c = await waitFor(() => sentBy(c2cId)[0], 8000, 120, '单聊 /openid 回复');
    ok(
      String(c2c.body.content).includes('U_C2C_1') && String(c2c.body.content).includes('单聊用户 OpenID'),
      '单聊 /openid 返回 user_openid',
    );

    // 8. 普通聊天不回复
    const idChat = groupEvent('今天天气不错');
    await sleep(700);
    ok(sentBy(idChat).length === 0, '普通聊天不回复');

    // 8b. 不带 / 的命令词不回复
    const idBare = groupEvent('ping');
    await sleep(700);
    ok(sentBy(idBare).length === 0, '不带 / 的 ping 不回复');

    const idBareStatus = groupEvent('状态');
    await sleep(500);
    ok(sentBy(idBareStatus).length === 0, '不带 / 的 状态 不回复');

    // 9. 未登记命令不回复
    const idHelp = groupEvent('/help');
    await sleep(500);
    ok(sentBy(idHelp).length === 0, '未登记命令不回复');

    // 10. /data（读取预置的历史消息记录）
    const idData = groupEvent('/data');
    const dataReply = await waitFor(() => sentBy(idData)[0], 8000, 120, '/data 回复');
    const dtxt = String(dataReply.body.content);
    ok(dtxt.startsWith('回响 · 数据总览\n【回响测试】'), '/data 按账户分节: ' + dtxt);
    ok(dtxt.includes('群聊总数：3'), '/data 群聊总数 = 3');
    ok(dtxt.includes('▲今日添加：+1'), '/data 今日新增群 = +1');
    ok(dtxt.includes('群聊今日消息：2 条'), '/data 群聊今日消息 = 2');
    ok(dtxt.includes('▼对比昨日：-1'), '/data 群聊对比昨日 = -1');
    ok(dtxt.includes('私聊今日消息：1 条'), '/data 私聊今日消息 = 1');
    ok(dtxt.includes('对比昨日：0'), '/data 私聊对比昨日 = 0');
    ok(dtxt.includes('全量群聊（本机器人）：3 个'), '/data 全量群聊 = 3');
    ok(dtxt.includes('管理员群（本机器人）：3 个'), '/data 管理员群 = 3');

    console.log(`\n全部通过（单元 ${unitPassed} 项 + 端到端 ${passed} 项）\n`);
  } catch (e) {
    console.error('\n测试失败：', e.message);
    console.error('--- 框架日志 ---');
    console.error(readLogTail(dataDir));
    process.exitCode = 1;
  } finally {
    child.kill();
    await sleep(300);
    await mock.stop();
    await jlwMock.stop();
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
