'use strict';
/**
 * 回响 × VSQL 真实集成测试：
 *   临时框架同时加载 VSQL + 回响 → 造历史消息 → /data → 直接读 shared.db 的 huixiang_daily
 *
 * 运行：node test/huixiang-vsql-e2e.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { DatabaseSync } = require('node:sqlite');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const HX_DIR = path.join(ROOT, '~JlWBoT', 'plugins', 'huixiang');
const VSQL_DIR = path.join(ROOT, 'plugins', 'VSQL');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function shiftDay(delta) {
  const d = new Date();
  d.setDate(d.getDate() + delta);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

async function waitFor(fn, timeout = 15000, interval = 150, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

async function main() {
  assert.ok(fs.existsSync(path.join(VSQL_DIR, 'plugin.json')), '找不到 VSQL 插件：' + VSQL_DIR);
  console.log('\n回响 × VSQL 集成测试\n');

  const mock = await new MockQQ({ port: 0, accounts: { app_hx: 'sec_hx' } }).start();
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const panelPort = 24100 + Math.floor(Math.random() * 400);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-hx-vsql-'));

  // 插件：回响 + VSQL（VSQL 关掉 HTTP，避免和运行中的实例抢端口）
  const pluginsDir = path.join(dataDir, 'plugins');
  fs.mkdirSync(pluginsDir, { recursive: true });
  fs.writeFileSync(path.join(pluginsDir, '.seeded'), 'test\n', 'utf8');
  fs.cpSync(HX_DIR, path.join(pluginsDir, 'huixiang'), { recursive: true });
  fs.cpSync(VSQL_DIR, path.join(pluginsDir, 'VSQL'), { recursive: true });
  const vsqlManifestFile = path.join(pluginsDir, 'VSQL', 'plugin.json');
  const vsqlManifest = JSON.parse(fs.readFileSync(vsqlManifestFile, 'utf8'));
  vsqlManifest.config = vsqlManifest.config || {};
  vsqlManifest.config.http = { ...(vsqlManifest.config.http || {}), enabled: false };
  fs.writeFileSync(vsqlManifestFile, JSON.stringify(vsqlManifest, null, 2), 'utf8');

  const vsqlData = path.join(pluginsDir, 'VSQL', 'data', 'dbs');
  fs.rmSync(path.join(pluginsDir, 'VSQL', 'data'), { recursive: true, force: true });

  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port: panelPort, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        accounts: [
          {
            id: 'a1',
            name: '回响测试',
            appId: 'app_hx',
            clientSecret: 'sec_hx',
            enabled: true,
            mode: 'ws',
            sandbox: false,
            prefix: '',
            tokenUrl: mock.base + '/app/getAppAccessToken',
            tokenUrlAlt: mock.base + '/app/getAppAccessToken',
            apiBase: mock.base,
            apiBaseSandbox: mock.base,
            gatewayUrl: mock.wsUrl,
            intents: ['GUILDS', 'GROUP_AND_C2C_EVENT'],
            shardId: 0,
            shardCount: 1,
          },
        ],
        plugins: { enabled: true, defaultTimeoutMs: 8000 },
        log: { level: 'info', console: false },
        storage: { messages: false, events: 100 },
      },
      null,
      2,
    ),
    'utf8',
  );

  // 历史消息 fixture（带 t，框架迁移按 t 分天）
  const historyDir = path.join(dataDir, 'data');
  fs.mkdirSync(historyDir, { recursive: true });
  const dump = (arr) => arr.map((x) => JSON.stringify(x)).join('\n') + '\n';
  const tsYesterday = Date.parse(`${shiftDay(-1)}T12:00:00+08:00`);
  const tsToday = Date.parse(`${shiftDay(0)}T12:00:00+08:00`);
  fs.writeFileSync(
    path.join(historyDir, `messages-${shiftDay(-1)}.jsonl`),
    dump([
      { t: tsYesterday, kind: 'group', group_openid: 'G1' },
      { t: tsYesterday, kind: 'group', group_openid: 'G1' },
      { t: tsYesterday, kind: 'group', group_openid: 'G2' },
      { t: tsYesterday, kind: 'c2c', user_openid: 'U1' },
    ]),
  );
  fs.writeFileSync(
    path.join(historyDir, `messages-${shiftDay(0)}.jsonl`),
    dump([
      { t: tsToday, kind: 'group', group_openid: 'G1' },
      { t: tsToday, kind: 'group', group_openid: 'G3' },
      { t: tsToday, kind: 'c2c', user_openid: 'U2' },
    ]),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${panelPort}`;
  let passed = 0;
  const ok = (cond, label) => {
    assert.ok(cond, label);
    console.log('  ✓ ' + label);
    passed++;
  };

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 20000, 200, '框架启动');
    ok(true, '框架启动（VSQL + 回响）');

    await waitFor(() => mock.identifies.app_hx, 15000, 150, '机器人上线');
    ok(true, '机器人上线');

    // 触发 /data，插件会写 VSQL
    const msgId = 'MSG_HX_VSQL_1';
    mock.push(
      'GROUP_MESSAGE_CREATE',
      {
        id: msgId,
        content: '/data',
        group_openid: 'G_HX',
        author: { id: 'U_HX', member_openid: 'U_HX', username: '测试用户' },
        timestamp: new Date().toISOString(),
        message_type: 0,
      },
      { appId: 'app_hx', seq: 9101 },
    );
    const reply = await waitFor(() => mock.sent.find((s) => s.body.msg_id === msgId), 10000, 150, '/data 回复');
    ok(String(reply.body.content).includes('群聊总数：3'), '/data 正常回复');

    // 等 VSQL 落库（/data 内是同步写，回复时已完成；再留一点余量）
    await sleep(500);
    const dbFile = path.join(vsqlData, 'shared.db');
    await waitFor(() => fs.existsSync(dbFile), 8000, 150, 'VSQL shared.db');
    const db = new DatabaseSync(dbFile, { readOnly: true });
    try {
      db.exec('PRAGMA busy_timeout = 3000');
      const rows = db.prepare('SELECT * FROM huixiang_daily ORDER BY date, account_id').all();
      ok(rows.length >= 2, `huixiang_daily 已写入（${rows.length} 行）`);
      const today = rows.find((r) => r.date === shiftDay(0));
      const yest = rows.find((r) => r.date === shiftDay(-1));
      ok(!!today && today.account_id === 'a1', '今日行 account_id 正确');
      ok(!!today && today.groups_total === 3 && today.groups_new === 1, '今日群总数/新增正确');
      ok(!!today && today.group_msgs === 2 && today.c2c_msgs === 1, '今日消息数正确');
      ok(!!yest && yest.groups_total === 2 && yest.group_msgs === 3, '昨日行正确');
    } finally {
      db.close();
    }

    // /data -1 走历史日期
    const msgId2 = 'MSG_HX_VSQL_2';
    mock.push(
      'GROUP_MESSAGE_CREATE',
      {
        id: msgId2,
        content: '/data -1',
        group_openid: 'G_HX',
        author: { id: 'U_HX', member_openid: 'U_HX', username: '测试用户' },
        timestamp: new Date().toISOString(),
        message_type: 0,
      },
      { appId: 'app_hx', seq: 9102 },
    );
    const reply2 = await waitFor(() => mock.sent.find((s) => s.body.msg_id === msgId2), 10000, 150, '/data -1 回复');
    ok(String(reply2.body.content).startsWith(`回响 · 数据总览（${shiftDay(-1)}）`), '/data -1 返回昨天');

    console.log(`\n全部通过（${passed} 项）\n`);
  } catch (e) {
    console.error('\n测试失败：', e.message);
    process.exitCode = 1;
  } finally {
    child.kill();
    await sleep(300);
    await mock.stop();
    await jlwMock.stop();
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
