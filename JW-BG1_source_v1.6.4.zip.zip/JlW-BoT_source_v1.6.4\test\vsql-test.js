'use strict';
/**
 * VSQL 插件自测（不需要真实 QQ、不联网、不碰线上数据）
 *
 *   node test/vsql-test.js
 *
 * 覆盖：命名空间隔离、建表/增删改查、where/order/limit、事务与回滚、预编译、
 * 迁移、kv、结构查询、ATTACH 开关、只读、关闭语义、备份、LRU、管理指令、HTTP 网关。
 */

const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const PLUGIN_DIR = path.join(__dirname, '..', 'plugins', 'VSQL');
const PLUGIN = require(path.join(PLUGIN_DIR, 'index.js'));
const DB_LIB = require(path.join(PLUGIN_DIR, 'lib', 'db.js'));

const TMP = path.join(__dirname, '.tmp-vsql');
const DBS = path.join(TMP, 'dbs');

let passed = 0;
let failed = 0;
const failures = [];
const checks = [];

function check(name, fn) {
  checks.push({ name, fn });
}
function ok(cond, message) {
  if (!cond) throw new Error(message || '断言失败');
}
function eq(actual, expected, message) {
  assert.strictEqual(actual, expected, message);
}
function closeTo(actual, expected, message) {
  ok(Math.abs(actual - expected) < 1, message || `${actual} != ${expected}`);
}

let ctx = null;
let vsql = null;

function makeLog() {
  const logs = [];
  const push = (level) => (msg) => logs.push(`${level}:${msg}`);
  return { logs, info: push('info'), warn: push('warn'), error: push('error'), debug: push('debug') };
}

function makeConfig(patch = {}) {
  const base = {
    dataDir: DBS,
    defaultNamespace: 'shared',
    maxOpen: 16,
    autoCreate: true,
    allowAttach: false,
    busyTimeoutMs: 5000,
    injectSettings: false,
    http: { enabled: false, host: '127.0.0.1', port: 0, token: '', maxRows: 1000 },
    admin: { enabled: true, openids: [], allowWrite: false, maxRows: 30, groupEnabled: false },
  };
  const out = { ...base, ...patch };
  out.http = { ...base.http, ...(patch.http || {}) };
  out.admin = { ...base.admin, ...(patch.admin || {}) };
  return out;
}

async function boot(patch = {}) {
  if (ctx) {
    try {
      await PLUGIN.onUnload(ctx);
    } catch {
      /* ignore */
    }
    ctx = null;
  }
  fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(DBS, { recursive: true });
  ctx = {
    plugin: { id: 'VSQL', dir: PLUGIN_DIR, config: makeConfig(patch) },
    log: makeLog(),
    framework: { version: '1.4.15', dataDir: TMP },
    config: { get: () => null },
  };
  await PLUGIN.onLoad(ctx);
  vsql = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL');
  return vsql;
}

function sendIn(text, openid = 'ADMIN', kind = 'c2c') {
  return PLUGIN.onEvent({
    ...ctx,
    message: {
      kind,
      id: 'MSG_' + Math.random().toString(36).slice(2),
      author: { user_openid: openid, member_openid: openid },
      command: {
        name: 'vsql',
        text,
        args: text.split(/\s+/).filter(Boolean),
        matched: true,
      },
    },
  });
}

function sendAdmin(text, openid = 'ADMIN') {
  return sendIn(text, openid, 'c2c');
}

/* ======================= 用例 ======================= */

check('plugin.json：id/version/type/事件/配置齐备', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(PLUGIN_DIR, 'plugin.json'), 'utf8'));
  eq(manifest.id, 'VSQL');
  eq(manifest.type, 'js');
  ok(manifest.version, '必须有版本号');
  ok(manifest.events.includes('C2C_MESSAGE_CREATE'), '管理指令走私聊事件');
  eq(manifest.commands[0], 'vsql');
  ok(manifest.config && manifest.config.http && manifest.config.admin, '默认配置必须含 http/admin');
  ok(manifest.priority < 100, '数据库服务应早于业务插件分发');
});

check('加载：isReady + 注册到 __JLWBOT_PLUGIN_APIS__', async () => {
  await boot();
  ok(vsql, '注册表里应有 VSQL');
  ok(vsql.isReady(), 'isReady 应为 true');
  eq(vsql.pluginId, 'VSQL');
  ok(vsql.version, 'version');
  ok(globalThis.__JLWBOT_PLUGIN_APIS__ instanceof Map);
  ok(ctx.log.logs.some((l) => l.includes('已加载')), '应写加载日志');
});

check('命名空间：自动建库、文件存在、WAL 模式、默认库 shared', async () => {
  const db = vsql.db('myplugin');
  eq(db.namespace, 'myplugin');
  ok(fs.existsSync(path.join(DBS, 'myplugin.db')), '应创建 myplugin.db');
  eq(String(db.pragma('journal_mode')).toLowerCase(), 'wal');
  const def = vsql.db();
  eq(def.namespace, 'shared');
  ok(fs.existsSync(path.join(DBS, 'shared.db')), '默认命名空间也应是独立文件');
  // 文件头校验：SQLite format 3
  const head = fs.readFileSync(path.join(DBS, 'myplugin.db')).subarray(0, 15).toString('latin1');
  eq(head, 'SQLite format 3');
});

check('建表 + 插入 + 查询：table() 自动 id、get/all', async () => {
  const db = vsql.db('rows');
  const logs = db.table('logs', { msg: 'TEXT NOT NULL DEFAULT ""', kind: 'TEXT' });
  const r = logs.insert({ msg: 'hello', kind: 'test' });
  eq(r.changes, 1);
  eq(r.lastInsertRowid, 1);
  const row = logs.get({ id: 1 });
  eq(row.msg, 'hello');
  eq(row.kind, 'test');
  eq(logs.all().length, 1);
  const cols = logs.columns().map((c) => c.name);
  ok(cols.includes('id') && cols.includes('msg') && cols.includes('kind'), '列应齐全：' + cols.join(','));
});

check('upsert：按主键插入与更新，change 数正确', async () => {
  const db = vsql.db('up');
  db.table('u', { openid: 'TEXT PRIMARY KEY', score: 'INTEGER NOT NULL DEFAULT 0' });
  db.upsert('u', { openid: 'A', score: 1 });
  eq(db.count('u'), 1);
  db.upsert('u', { openid: 'A', score: 9 });
  eq(db.count('u'), 1, 'upsert 不应插重复行');
  eq(db.get('SELECT score FROM u WHERE openid = ?', 'A').score, 9);
  // 显式冲突列
  const db2 = vsql.db('up2');
  db2.exec('CREATE TABLE w(a TEXT UNIQUE, b INTEGER)');
  db2.upsert('w', { a: 'x', b: 1 }, ['a']);
  db2.upsert('w', { a: 'x', b: 2 }, ['a']);
  eq(db2.get('SELECT b FROM w').b, 2);
});

check('update / del / count / exists', async () => {
  const db = vsql.db('crud');
  db.table('t', { name: 'TEXT', score: 'INTEGER NOT NULL DEFAULT 0' });
  db.insertMany('t', [{ name: 'a', score: 1 }, { name: 'b', score: 2 }, { name: 'c', score: 3 }]);
  eq(db.count('t'), 3);
  eq(db.update('t', { score: 10 }, { name: 'b' }).changes, 1);
  eq(db.get('SELECT score FROM t WHERE name = ?', 'b').score, 10);
  eq(db.exists('t', { name: 'c' }), true);
  eq(db.exists('t', { name: 'zzz' }), false);
  eq(db.del('t', { 'score <': 5 }).changes, 2);
  eq(db.count('t'), 1);
  eq(db.del('t', null).changes, 1, 'where=null 应删全部');
  eq(db.count('t'), 0);
});

check('where：> / in / like / is null / $or', async () => {
  const db = vsql.db('where');
  db.table('p', { name: 'TEXT', age: 'INTEGER', note: 'TEXT' });
  db.insertMany('p', [
    { name: 'alice', age: 20, note: null },
    { name: 'bob', age: 30, note: 'x' },
    { name: 'carol', age: 40, note: null },
  ]);
  eq(db.select('p', { 'age >': 25 }).length, 2);
  eq(db.select('p', { 'age >=': 30, 'age <': 40 }).length, 1);
  eq(db.select('p', { age: [20, 40] }).length, 2);
  eq(db.select('p', { 'name like': 'a%' }).length, 1);
  eq(db.select('p', { note: null }).length, 2);
  eq(db.select('p', { 'note is null': true }).length, 2);
  eq(db.select('p', { 'note is not null': true }).length, 1);
  eq(db.select('p', { $or: [{ name: 'alice' }, { age: 40 }] }).length, 2);
  eq(db.select('p', { $and: [{ 'age >': 25 }, { 'age <': 40 }] }).length, 1);
  assert.throws(() => db.select('p', { 'age between': 1 }), (e) => e.code === 'BAD_OPERATOR');
  assert.throws(() => db.select('p', { 'age ~~': 1 }), (e) => e.code === 'BAD_WHERE_KEY');
  assert.throws(() => db.select('p', { 'bad name': 1 }), (e) => /^BAD_/.test(e.code));
  assert.throws(() => db.select('p', { $xor: [] }), (e) => e.code === 'BAD_WHERE_KEY');
});

check('order / limit / offset / columns', async () => {
  const db = vsql.db('page');
  db.table('s', { n: 'INTEGER NOT NULL' });
  db.insertMany('s', [{ n: 3 }, { n: 1 }, { n: 5 }, { n: 2 }]);
  eq(db.select('s', null, { order: 'n DESC' }).map((r) => r.n).join(','), '5,3,2,1');
  eq(db.select('s', null, { order: 'n ASC', limit: 2 }).map((r) => r.n).join(','), '1,2');
  eq(db.select('s', null, { order: 'n ASC', limit: 2, offset: 2 }).map((r) => r.n).join(','), '3,5');
  const rows = db.select('s', null, { order: 'n ASC', columns: ['n'] });
  eq(Object.keys(rows[0]).join(','), 'n');
  assert.throws(() => db.select('s', null, { order: 'n; DROP TABLE s' }), (e) => e.code === 'BAD_ORDER');
  assert.throws(() => db.select('s', null, { limit: -1 }), (e) => e.code === 'BAD_LIMIT');
});

check('事务：提交、回滚、嵌套 SAVEPOINT', async () => {
  const db = vsql.db('tx');
  db.table('t', { v: 'INTEGER' });
  const out = db.tx(() => {
    db.insert('t', { v: 1 });
    db.insert('t', { v: 2 });
    return 'done';
  });
  eq(out, 'done');
  eq(db.count('t'), 2);

  assert.throws(() =>
    db.tx(() => {
      db.insert('t', { v: 3 });
      throw new Error('boom');
    }),
  );
  eq(db.count('t'), 2, '抛错必须回滚');

  // 外层事务里的内层保存点回滚，不影响外层已写入的数据
  db.tx(() => {
    db.insert('t', { v: 4 });
    try {
      db.tx(() => {
        db.insert('t', { v: 5 });
        throw new Error('inner');
      });
    } catch {
      /* 忽略内层失败 */
    }
    db.insert('t', { v: 6 });
  });
  eq(db.select('t', { v: 5 }).length, 0, '内层应回滚');
  eq(db.select('t', { v: 4 }).length + db.select('t', { v: 6 }).length, 2, '外层应保留');
});

check('事务：async 函数必须被拒绝且不留下半截数据', async () => {
  const db = vsql.db('txa');
  db.table('t', { v: 'INTEGER' });
  let err = null;
  try {
    db.tx(async () => {
      db.insert('t', { v: 1 });
    });
  } catch (e) {
    err = e;
  }
  ok(err && err.code === 'ASYNC_TX', '应抛 ASYNC_TX：' + (err && err.code));
  eq(db.count('t'), 0, 'async 事务必须回滚');
});

check('预编译语句：反复 run/get/all + columns', async () => {
  const db = vsql.db('stmt');
  db.table('t', { name: 'TEXT' });
  const st = db.prepare('INSERT INTO t(name) VALUES(?)');
  st.run('a');
  st.run('b');
  eq(db.count('t'), 2);
  const q = db.prepare('SELECT * FROM t ORDER BY id');
  eq(q.all().length, 2);
  eq(q.get().name, 'a');
  eq(q.value(), 1);
  eq(q.columns().map((c) => c.name).join(','), 'id,name');
});

check('命名参数 :id 与自动归一化（bool/Date/对象/undefined）', async () => {
  const db = vsql.db('param');
  db.table('t', { name: 'TEXT', flag: 'INTEGER', at: 'TEXT', meta: 'TEXT' });
  const at = new Date('2026-01-02T03:04:05.000Z');
  db.run(
    'INSERT INTO t(name, flag, at, meta) VALUES(:name, :flag, :at, :meta)',
    { name: 'x', flag: true, at, meta: { a: 1 } },
  );
  const row = db.get('SELECT * FROM t WHERE name = :name', { name: 'x' });
  eq(row.flag, 1);
  eq(row.at, at.toISOString());
  eq(JSON.parse(row.meta).a, 1);
  db.run('INSERT INTO t(name, flag) VALUES(?, ?)', 'y', false);
  eq(db.get("SELECT flag FROM t WHERE name = 'y'").flag, 0);
  // undefined → NULL
  db.run('UPDATE t SET meta = ? WHERE name = ?', undefined, 'y');
  eq(db.get("SELECT meta FROM t WHERE name = 'y'").meta, null);
});

check('kv：set/get/incr/has/all/del/clear', async () => {
  const db = vsql.db('kv');
  db.kv.set('a', { x: 1 });
  eq(db.kv.get('a').x, 1);
  eq(db.kv.get('missing', 'fallback'), 'fallback');
  db.kv.set('n', 1);
  eq(db.kv.incr('n'), 2);
  eq(db.kv.incr('n', 3), 5);
  eq(db.kv.has('a'), true);
  eq(db.kv.all().n, 5);
  eq(db.kv.keys().sort().join(','), 'a,n');
  eq(db.kv.del('a'), true);
  eq(db.kv.has('a'), false);
  db.kv.set('b', 1);
  eq(db.kv.clear(), 2);
  eq(db.kv.keys().length, 0);
});

check('迁移：user_version 推进、只跑新步骤、幂等', async () => {
  const db = vsql.db('mig');
  eq(db.userVersion(), 0);
  const first = db.migrate([
    (d) => d.exec('CREATE TABLE IF NOT EXISTS t(id INTEGER PRIMARY KEY, v TEXT)'),
    { version: 2, up: (d) => d.exec('ALTER TABLE t ADD COLUMN n INTEGER NOT NULL DEFAULT 0') },
  ]);
  eq(first.from, 0);
  eq(first.to, 2);
  eq(first.applied.join(','), '1,2');
  eq(db.userVersion(), 2);
  const second = db.migrate([
    (d) => d.exec('CREATE TABLE should_not_exist(x)'),
    { version: 2, up: () => { throw new Error('不应重复执行'); } },
    { version: 3, sql: 'CREATE INDEX IF NOT EXISTS idx_t_n ON t(n)' },
  ]);
  eq(second.applied.join(','), '3');
  eq(db.hasTable('should_not_exist'), false, '已应用的版本不应重跑');
  assert.throws(() => db.setUserVersion(-1), (e) => e.code === 'BAD_VERSION');
});

check('结构查询：tables/columns/indexes/schema/hasTable/dropTable/primaryKeys', async () => {
  const db = vsql.db('schema');
  db.table(
    'u',
    { openid: 'TEXT PRIMARY KEY', score: 'INTEGER NOT NULL DEFAULT 0' },
    { indexes: [['score'], { columns: ['openid'], unique: true, name: 'uq_u_openid' }] },
  );
  const tables = db.tables();
  eq(tables.length, 1);
  eq(tables[0].name, 'u');
  eq(tables[0].rows, 0);
  eq(db.hasTable('u'), true);
  eq(db.primaryKeys('u').join(','), 'openid');
  const cols = db.columns('u');
  ok(cols.some((c) => c.name === 'score' && c.notnull === 1), '列信息应完整');
  const idx = db.indexes('u');
  ok(idx.some((i) => i.name === 'uq_u_openid' && i.unique), '唯一索引应存在：' + JSON.stringify(idx));
  ok(idx.some((i) => i.name === 'idx_u_score'), '普通索引应存在');
  const ddl = db.schema('u');
  ok(ddl.some((r) => /CREATE TABLE/i.test(r.sql)), '应能取到建表语句');
  db.dropTable('u');
  eq(db.hasTable('u'), false);
});

check('info / pragma / 文件大小', async () => {
  const db = vsql.db('info');
  db.table('t', { v: 'INTEGER' });
  db.insert('t', { v: 1 });
  const info = db.info();
  eq(info.namespace, 'info');
  ok(info.file.endsWith('info.db'));
  ok(info.size > 0, '应有文件大小');
  eq(info.tables.length, 1);
  eq(info.tables[0].rows, 1);
  ok(info.sqliteVersion, '应能读到 SQLite 版本');
  eq(String(db.pragma('journal_mode')).toLowerCase(), 'wal');
  eq(db.pragma('user_version'), 0);
});

check('命名空间隔离：两个库各自的表互不可见', async () => {
  const a = vsql.db('iso-a');
  const b = vsql.db('iso-b');
  a.table('only_a', { v: 'INTEGER' });
  eq(a.hasTable('only_a'), true);
  eq(b.hasTable('only_a'), false);
  ok(fs.existsSync(path.join(DBS, 'iso-a.db')));
  ok(fs.existsSync(path.join(DBS, 'iso-b.db')));
  assert.notEqual(path.resolve(a.file), path.resolve(b.file));
});

check('非法命名空间 / 非法表名会报错（不落文件）', async () => {
  for (const bad of ['../evil', 'a/b', 'name with space', '-x', 'x'.repeat(60)]) {
    assert.throws(() => vsql.db(bad), (e) => e.code === 'BAD_NAMESPACE', `应拒绝：${bad}`);
  }
  const db = vsql.db('ident');
  assert.throws(() => db.table('bad table', { v: 'INTEGER' }), (e) => e.code === 'BAD_IDENTIFIER');
  assert.throws(() => db.insert('t; DROP TABLE x', { v: 1 }), (e) => e.code === 'BAD_IDENTIFIER');
  assert.throws(() => db.select('t', { 'id = 1 OR 1': 1 }), (e) => e.code === 'BAD_WHERE_KEY');
});

check('ATTACH 默认禁用', async () => {
  const db = vsql.db('attach-a');
  db.table('t', { v: 'INTEGER' });
  const other = path.join(DBS, 'attach-b.db').replace(/\\/g, '/');
  assert.throws(() => db.exec(`ATTACH DATABASE '${other}' AS other`), (e) => e.code === 'ATTACH_DISABLED');
});

check('ATTACH 打开后可用（allowAttach=true）', async () => {
  await boot({ allowAttach: true });
  const a = vsql.db('attach-a');
  a.table('t', { v: 'INTEGER' });
  a.insert('t', { v: 1 });
  const b = vsql.db('attach-b');
  b.table('t2', { v: 'INTEGER' });
  b.insert('t2', { v: 42 });
  b.close();
  const other = path.join(DBS, 'attach-b.db').replace(/\\/g, '/');
  a.exec(`ATTACH DATABASE '${other}' AS other`);
  eq(a.value('SELECT v FROM other.t2'), 42);
  a.exec('DETACH DATABASE other');
});

check('timestamps：插入自动填、upsert 不重置 created_at', async () => {
  const db = vsql.db('ts');
  const t = db.table('kv_ts', { k: 'TEXT PRIMARY KEY', v: 'INTEGER' }, { timestamps: true });
  t.insert({ k: 'a', v: 1 });
  const first = t.get({ k: 'a' });
  ok(first.created_at > 0 && first.updated_at > 0, '应自动填时间戳');
  await new Promise((r) => setTimeout(r, 8));
  t.upsert({ k: 'a', v: 2 });
  const second = t.get({ k: 'a' });
  eq(second.v, 2);
  eq(second.created_at, first.created_at, 'upsert 不应重置 created_at');
  ok(second.updated_at >= first.updated_at, 'updated_at 应更新');
  // 名字像 attach 的表不应被 ATTACH 守卫误伤
  db.exec('CREATE TABLE attach_log(x INTEGER)');
  eq(db.hasTable('attach_log'), true);
});

check('只读句柄：能读不能写；不存在的库报 NS_NOT_FOUND', async () => {
  const db = vsql.db('ro');
  db.table('t', { v: 'INTEGER' });
  db.insert('t', { v: 7 });
  db.close();
  const ro = vsql.db('ro', { readOnly: true });
  eq(ro.value('SELECT v FROM t'), 7);
  assert.throws(() => ro.run('INSERT INTO t(v) VALUES(?)', 8), (e) => e.code === 'READ_ONLY');
  ro.close();
  assert.throws(() => vsql.db('never-existed', { readOnly: true }), (e) => e.code === 'NS_NOT_FOUND');
  assert.throws(() => vsql.db('never-existed', { create: false }), (e) => e.code === 'NS_NOT_FOUND');
});

check('关闭语义：close 后操作抛 DB_CLOSED，且可重新打开', async () => {
  const db = vsql.db('closing');
  db.table('t', { v: 'INTEGER' });
  db.close();
  eq(db.closed, true);
  assert.throws(() => db.get('SELECT 1'), (e) => e.code === 'DB_CLOSED');
  const again = vsql.db('closing');
  ok(again !== db, '应拿到新句柄');
  eq(again.count('t'), 0);
  again.close();
});

check('备份：默认目录 + 内容可读', async () => {
  const db = vsql.db('backup');
  db.table('t', { v: 'INTEGER' });
  db.insertMany('t', [{ v: 1 }, { v: 2 }]);
  const result = await db.backup();
  ok(result.ok);
  ok(fs.existsSync(result.file), '备份文件应存在：' + result.file);
  eq(path.dirname(result.file), path.join(DBS, 'backups'));
  const check2 = new DatabaseSync(result.file, { readOnly: true });
  try {
    eq(check2.prepare('SELECT COUNT(*) AS n FROM t').get().n, 2);
  } finally {
    check2.close();
  }
  const custom = path.join(TMP, 'custom-backup.db');
  const r2 = await db.backup(custom);
  ok(fs.existsSync(r2.file));
});

check('list / openCount / maxOpen 自动关闭最久未使用', async () => {
  await boot({ maxOpen: 2 });
  const a = vsql.db('lru-a');
  a.table('t', { v: 'INTEGER' });
  const b = vsql.db('lru-b');
  b.table('t', { v: 'INTEGER' });
  vsql.db('lru-c').table('t', { v: 'INTEGER' });
  eq(vsql.openCount(), 2);
  eq(a.closed, true, 'a 应被 LRU 关闭');
  ok(!b.closed, 'b 应仍然打开');
  const list = vsql.list();
  ok(list.length >= 3, '应列出 3 个库：' + list.map((x) => x.namespace).join(','));
  ok(list.find((x) => x.namespace === 'lru-a'), 'lru-a 应在列表里');
});

check('内存库：不落盘，随句柄关闭消失', async () => {
  await boot();
  const mem = vsql.db('scratch', { memory: true });
  mem.table('t', { v: 'INTEGER' });
  mem.insert('t', { v: 1 });
  eq(mem.count('t'), 1);
  ok(!fs.existsSync(path.join(DBS, 'scratch.db')), '内存库不应生成文件');
  mem.close();
});

check('管理指令：未配置管理员时把 OpenID 回给本人', async () => {
  await boot({ admin: { openids: [] } });
  const res = await sendAdmin('stats', 'USER_1');
  ok(res && res.reply.includes('USER_1'), '应回自己的 OpenID：' + JSON.stringify(res));
  ok(res.reply.includes('管理员'), '应提示如何配置');
});

check('管理指令：非管理员静默忽略', async () => {
  await boot({ admin: { openids: ['ADMIN'] } });
  const res = await sendAdmin('stats', 'SOMEONE_ELSE');
  eq(res, null);
});

check('管理指令：stats / list / tables / schema', async () => {
  await boot({ admin: { openids: ['ADMIN'] } });
  const db = vsql.db('adm');
  db.table('t', { v: 'INTEGER' });
  db.insert('t', { v: 1 });
  const stats = await sendAdmin('stats');
  ok(stats.reply.includes('VSQL v'), stats.reply);
  ok(stats.reply.includes('数据目录'), stats.reply);
  const list = await sendAdmin('list');
  ok(list.reply.includes('adm'), list.reply);
  const tables = await sendAdmin('tables adm');
  ok(tables.reply.includes('t') && tables.reply.includes('1 行'), tables.reply);
  const schema = await sendAdmin('schema adm');
  ok(schema.reply.includes('CREATE TABLE'), schema.reply);
  const help = await sendAdmin('help');
  ok(help.reply.includes('/vsql stats'), help.reply);
});

check('管理指令：SQL 默认只读，allowWrite 后才能写', async () => {
  await boot({ admin: { openids: ['ADMIN'], allowWrite: false } });
  const db = vsql.db('adm2');
  db.table('t', { v: 'INTEGER' });
  db.insert('t', { v: 5 });
  const sel = await sendAdmin('sql adm2 SELECT * FROM t');
  ok(sel.reply.includes('5') && sel.reply.includes('1 行'), sel.reply);
  const denied = await sendAdmin("sql adm2 INSERT INTO t(v) VALUES(6)");
  ok(denied.reply.includes('已拒绝'), denied.reply);
  eq(db.count('t'), 1, '写 SQL 不应生效');

  await boot({ admin: { openids: ['ADMIN'], allowWrite: true } });
  const db2 = vsql.db('adm2');
  db2.table('t', { v: 'INTEGER' });
  const wrote = await sendAdmin('sql adm2 INSERT INTO t(v) VALUES(6)');
  ok(wrote.reply.includes('changes=1'), wrote.reply);
  eq(db2.count('t'), 1);
  const bad = await sendAdmin('sql adm2 SELECT * FROM no_such_table');
  ok(bad.reply.includes('SQL 执行失败'), bad.reply);
});

check('群聊：默认不响应 /vsql（私聊专用）', async () => {
  await boot({ admin: { openids: ['ADMIN'], groupEnabled: false } });
  eq(await sendIn('stats', 'ADMIN', 'group'), null, '默认群聊应完全静默');
});

check('群聊：打开 groupEnabled 后管理员可用，非管理员仍静默', async () => {
  await boot({ admin: { openids: ['ADMIN'], groupEnabled: true } });
  const okRes = await sendIn('stats', 'ADMIN', 'group');
  ok(okRes && okRes.reply.includes('VSQL v'), '管理员在群里应得到状态：' + JSON.stringify(okRes));
  eq(await sendIn('stats', 'SOMEONE_ELSE', 'group'), null, '非管理员在群里应静默');
});

check('管理指令：token', async () => {
  await boot({ http: { enabled: true, port: 0 }, admin: { openids: ['ADMIN'] } });
  const res = await sendAdmin('token');
  ok(res.reply.includes('令牌'), res.reply);
  ok(vsql.token().length > 20, '应有 HTTP 令牌');
});

check('HTTP 网关：health 免令牌，其它接口要 Bearer', async () => {
  await boot({ http: { enabled: true, port: 0 } });
  await vsql.db('httpns').table('t', { v: 'INTEGER' }).insert({ v: 1 });
  const base = vsql.http().url;
  ok(base, '应拿到网关地址');
  const health = await fetch(`${base}/health`).then((r) => r.json());
  eq(health.ok, true);
  eq(health.name, 'VSQL');
  const unauth = await fetch(`${base}/namespaces`);
  eq(unauth.status, 401);
  const wrong = await fetch(`${base}/namespaces`, { headers: { Authorization: 'Bearer nope' } });
  eq(wrong.status, 401);
});

check('HTTP 网关：namespaces / info / query 各 mode / exec / backup', async () => {
  const base = vsql.http().url;
  const token = vsql.token();
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  const nss = await fetch(`${base}/namespaces`, { headers }).then((r) => r.json());
  ok(nss.ok && nss.namespaces.some((x) => x.namespace === 'httpns'), JSON.stringify(nss));

  const info = await fetch(`${base}/info?ns=httpns`, { headers }).then((r) => r.json());
  eq(info.info.namespace, 'httpns');

  const all = await fetch(`${base}/query`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'SELECT * FROM t', mode: 'all' }),
  }).then((r) => r.json());
  eq(all.ok, true);
  eq(all.rows.length, 1);
  eq(all.rows[0].v, 1);

  const one = await fetch(`${base}/query`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'SELECT * FROM t WHERE id=?', params: [1], mode: 'get' }),
  }).then((r) => r.json());
  eq(one.row.v, 1);

  const scalar = await fetch(`${base}/query`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'SELECT COUNT(*) FROM t', mode: 'value' }),
  }).then((r) => r.json());
  eq(scalar.value, 1);

  const run = await fetch(`${base}/query`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'INSERT INTO t(v) VALUES(?)', params: [2], mode: 'run' }),
  }).then((r) => r.json());
  eq(run.changes, 1);

  const exec = await fetch(`${base}/exec`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'CREATE TABLE IF NOT EXISTS t2(x INTEGER); INSERT INTO t2 VALUES(3);' }),
  }).then((r) => r.json());
  eq(exec.ok, true);

  const bk = await fetch(`${base}/backup`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns' }),
  }).then((r) => r.json());
  ok(bk.ok && fs.existsSync(bk.file), JSON.stringify(bk));

  const badMode = await fetch(`${base}/query`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ ns: 'httpns', sql: 'SELECT 1', mode: 'nope' }),
  });
  eq(badMode.status, 400);

  const badJson = await fetch(`${base}/query`, { method: 'POST', headers, body: '{oops' });
  eq(badJson.status, 400);

  const missing = await fetch(`${base}/nope`, { headers });
  eq(missing.status, 404);
});

check('HTTP 网关重载：同端口能立刻重新监听（插件重载竞态）', async () => {
  await boot({ http: { enabled: true, port: 0 }, admin: { openids: ['ADMIN'] } });
  const port = vsql.http().port;
  ok(port > 0, '首次应拿到端口');
  await boot({ http: { enabled: true, port }, admin: { openids: ['ADMIN'] } });
  eq(vsql.http().port, port, '重载后应仍用同一端口，不应被挤到 +1');
  const health = await fetch(`${vsql.http().url}/health`).then((r) => r.json());
  eq(health.ok, true);
});

check('卸载：HTTP 停止、注册表移除、句柄全关', async () => {
  const url = vsql.http().url;
  await vsql.db('before-unload').table('t', { v: 'INTEGER' });
  await PLUGIN.onUnload(ctx);
  ctx = {
    plugin: { id: 'VSQL', dir: PLUGIN_DIR, config: makeConfig() },
    log: makeLog(),
    framework: { version: '1.4.15', dataDir: TMP },
  };
  eq(vsql.isReady(), false);
  ok(!globalThis.__JLWBOT_PLUGIN_APIS__.has('VSQL'), '注册表应移除 VSQL');
  let alive = true;
  try {
    await fetch(`${url}/health`);
  } catch {
    alive = false;
  }
  ok(!alive, '卸载后 HTTP 端口应已关闭');
});

check('跨插件使用：模拟业务插件懒取 API 建表读写', async () => {
  await boot(); // 上一条用例卸载过，这里重新加载，模拟「插件重载后仍然可用」
  const consumer = () => {
    const v = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL');
    if (!v || !v.isReady()) throw new Error('VSQL 未就绪');
    const db = v.db('consumer-plugin');
    db.table('score', { openid: 'TEXT PRIMARY KEY', value: 'INTEGER NOT NULL DEFAULT 0' });
    db.upsert('score', { openid: 'U9', value: 3 });
    return db.get('SELECT value FROM score WHERE openid = ?', 'U9').value;
  };
  eq(consumer(), 3);
  eq(consumer(), 3, '重复调用应幂等');
  ok(vsql.list().some((x) => x.namespace === 'consumer-plugin'), '应出现在命名空间列表');
});

check('并发：共用命名空间原子自增不丢更新；两个连接写同一文件不报 busy', async () => {
  // 两个「插件」共用同一个命名空间，各自 300 次 UPDATE，交错让出事件循环
  const db = vsql.db('conc');
  db.table('counter', { id: 'INTEGER PRIMARY KEY', n: 'INTEGER NOT NULL DEFAULT 0' });
  db.run('INSERT INTO counter(id, n) VALUES(1, 0)');
  const bump = async () => {
    for (let i = 0; i < 300; i++) {
      db.run('UPDATE counter SET n = n + 1 WHERE id = 1');
      if (i % 50 === 0) await new Promise((r) => setImmediate(r));
    }
  };
  await Promise.all([bump(), bump()]);
  eq(db.get('SELECT n FROM counter WHERE id = 1').n, 600, '原子自增不应丢更新');

  // 两个独立连接打开同一个文件（模拟外部进程），WAL + busy_timeout 应能吃下交错写入
  const file = path.join(DBS, 'conc2.db');
  const c1 = new DB_LIB.NamespaceDB({ namespace: 'conc2', file, allowAttach: false });
  const c2 = new DB_LIB.NamespaceDB({ namespace: 'conc2', file, allowAttach: false });
  c1.exec('CREATE TABLE IF NOT EXISTS t(id INTEGER PRIMARY KEY, v INTEGER)');
  const write = async (conn, base) => {
    for (let i = 0; i < 100; i++) {
      conn.run('INSERT INTO t(v) VALUES(?)', base + i);
      if (i % 20 === 0) await new Promise((r) => setImmediate(r));
    }
  };
  await Promise.all([write(c1, 0), write(c2, 1000)]);
  eq(c1.value('SELECT COUNT(*) FROM t'), 200, '两个连接的写入都应落盘');
  c1.close();
  c2.close();
});

check('表名/列名支持中文（建表、读写、where、order）', async () => {
  const db = vsql.db('zh');
  const t = db.table(
    '用户表',
    { 昵称: 'TEXT NOT NULL DEFAULT ""', 积分: 'INTEGER NOT NULL DEFAULT 0' },
    { indexes: [['积分']] },
  );
  t.insert({ 昵称: '小明', 积分: 10 });
  t.insert({ 昵称: '小红', 积分: 20 });
  eq(t.get({ 昵称: '小明' }).积分, 10);
  eq(db.select('用户表', { '积分 >': 10 }, { order: '积分 DESC' }).length, 1);
  eq(db.update('用户表', { 积分: 11 }, { 昵称: '小明' }).changes, 1);
  eq(db.count('用户表'), 2);
  ok(db.hasTable('用户表'), '中文表名应存在');
  ok(t.columns().some((c) => c.name === '积分'), '中文列名应存在');
  assert.throws(() => db.table('带 空格', { a: 'TEXT' }), (e) => e.code === 'BAD_IDENTIFIER');
});

check('结构 API：createTable / renameTable / addColumn / renameColumn / dropColumn', async () => {
  const db = vsql.db('schema-api');
  db.createTable('t1', { a: 'TEXT' });
  eq(db.hasTable('t1'), true);
  db.renameTable('t1', 't2');
  eq(db.hasTable('t1'), false);
  eq(db.hasTable('t2'), true);
  db.addColumn('t2', 'b', 'INTEGER NOT NULL DEFAULT 0');
  ok(db.columns('t2').some((c) => c.name === 'b'), '加列应生效');
  db.renameColumn('t2', 'b', 'c');
  ok(db.columns('t2').some((c) => c.name === 'c'), '改列名应生效');
  db.dropColumn('t2', 'c');
  ok(!db.columns('t2').some((c) => c.name === 'c'), '删列应生效');
  db.insert('t2', { a: 'x' });
  eq(db.count('t2'), 1);
});

check('跨插件共用 shared：A 建表，B/C 直接读写', async () => {
  const a = vsql.db(); // 不传命名空间 = shared
  a.createTable('跨插件表', { 键: 'TEXT PRIMARY KEY', 值: 'INTEGER NOT NULL DEFAULT 0' });
  a.upsert('跨插件表', { 键: 'k', 值: 1 });
  const b = vsql.db(); // 模拟另一个插件
  eq(b.value('SELECT 值 FROM 跨插件表 WHERE 键 = ?', 'k'), 1);
  b.run('UPDATE 跨插件表 SET 值 = 值 + 1 WHERE 键 = ?', 'k');
  eq(b.value('SELECT 值 FROM 跨插件表'), 2);
  ok(vsql.tables().some((t) => t.name === '跨插件表'), '共享库里应能看到表');
  const found = vsql.findTable('跨插件表');
  eq(found.namespace, 'shared');
});

check('findTable 能跨命名空间找到表', async () => {
  const db = vsql.db('private-a');
  db.createTable('私表', { v: 'INTEGER' });
  const found = vsql.findTable('私表');
  ok(found, '应能找到');
  eq(found.namespace, 'private-a');
  eq(vsql.findTable('根本不存在的表'), null);
});

check('设置页快照：注入从盘符开始的完整路径（只写副本）', async () => {
  const dir = fs.mkdtempSync(path.join(TMP, 'snap-'));
  const target = path.join(dir, 'settings.html');
  const source = path.join(PLUGIN_DIR, 'settings.html');
  fs.copyFileSync(source, target);
  const sourceBefore = fs.readFileSync(source, 'utf8');
  const rt = {
    version: '1.0.1',
    pluginDir: dir,
    dataDir: path.join(dir, 'data', 'dbs'),
    manager: { defaultNamespace: 'shared' },
    config: { injectSettings: true, http: { enabled: false } },
    http: null,
    log: null,
  };
  eq(PLUGIN.__test.injectSettingsSnapshot(rt), true);
  const html = fs.readFileSync(target, 'utf8');
  const m = html.match(/<script type="application\/json" id="vsql-runtime">([\s\S]*?)<\/script>/);
  ok(m, '应有快照占位');
  const snap = JSON.parse(m[1]);
  eq(snap.dataDir, path.join(dir, 'data', 'dbs'));
  eq(snap.pluginDir, dir);
  ok(snap.dataDir.startsWith(dir), '绝对路径应从盘符开始');
  // 幂等：再注入一次内容不变
  PLUGIN.__test.injectSettingsSnapshot(rt);
  eq(fs.readFileSync(target, 'utf8'), html);
  // 不碰源文件
  eq(fs.readFileSync(source, 'utf8'), sourceBefore);
  // 关闭注入后不写
  rt.config.injectSettings = false;
  eq(PLUGIN.__test.injectSettingsSnapshot(rt), false);
});

check('设置页数据浏览：列出所有表 + 样例行 + 敏感列打码 + 每表行数上限', async () => {
  await boot();
  const rt = PLUGIN.__test.getRuntime();
  const db = vsql.db('aaa-preview');
  db.createTable('账号', { openid: 'TEXT PRIMARY KEY', 昵称: 'TEXT', token: 'TEXT', 余额: 'INTEGER' });
  db.insertMany(
    '账号',
    Array.from({ length: 25 }, (_, i) => ({ openid: 'U' + i, 昵称: '用户' + i, token: 'secret-' + i, 余额: i })),
  );
  db.createTable('空表', { a: 'TEXT' });

  const preview = PLUGIN.__test.buildPreview(rt);
  ok(preview.generatedAt > 0, '应有生成时间');
  const ns = preview.namespaces.find((n) => n.namespace === 'aaa-preview');
  ok(ns, '应包含命名空间');
  const table = ns.tables.find((t) => t.name === '账号');
  eq(table.rows, 25, '应给出真实行数');
  eq(table.sample.length, 10, '默认每表预览 10 行');
  eq(table.sample[0].token, '***', 'token 列应打码');
  eq(table.sample[0].昵称, '用户0', '中文列/值应正常');
  eq(ns.tables.find((t) => t.name === '空表').sample.length, 0);
  ok(!ns.tables.some((t) => t.name.startsWith('__vsql_')), '内部表不应出现在预览里');
  eq(preview.defaultNamespace, 'shared');
});

check('设置页数据快照：注入表清单与样例行（只写副本）', async () => {
  const dir = fs.mkdtempSync(path.join(TMP, 'snapdata-'));
  const target = path.join(dir, 'settings.html');
  const source = path.join(PLUGIN_DIR, 'settings.html');
  fs.copyFileSync(source, target);
  const before = fs.readFileSync(source, 'utf8');
  const rt = PLUGIN.__test.getRuntime();
  const fake = Object.assign({}, rt, {
    pluginDir: dir,
    dataDir: path.join(dir, 'data', 'dbs'),
    config: Object.assign({}, rt.config, { injectSettings: true }),
  });

  eq(PLUGIN.__test.injectSettingsSnapshot(fake), true);
  const html = fs.readFileSync(target, 'utf8');
  const m = html.match(/<script type="application\/json" id="vsql-data">([\s\S]*?)<\/script>/);
  ok(m, '应有数据快照占位');
  const data = JSON.parse(m[1]);
  const ns = data.namespaces.find((n) => n.namespace === 'aaa-preview');
  ok(ns, '快照应含命名空间');
  const acc = ns.tables.find((t) => t.name === '账号');
  ok(acc, '快照应含账号表');
  eq(acc.sample[0].token, '***', '快照里也必须打码');
  ok(html.includes('id="vsql-runtime"'), '运行时快照应同时存在');
  eq(fs.readFileSync(source, 'utf8'), before, '源模板不应被修改');
});

check('卸载顺序：onUnload 同步关库，插件目录可立即删除（更新不会 EPERM）', async () => {
  await boot();
  const db = vsql.db('unload-order');
  db.table('t', { v: 'INTEGER' });
  const dir = path.join(TMP, 'dbs');
  await PLUGIN.onUnload(ctx);
  let err = null;
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch (e) {
    err = e;
  }
  eq(err, null, '卸载后应能立刻删除数据库文件：' + (err && err.message));
});

check('docs：api.html 与 settings.html 关键内容', () => {
  const apiHtml = fs.readFileSync(path.join(PLUGIN_DIR, 'api.html'), 'utf8');
  for (const need of ['vsql.db(', 'db.table(', 'db.run(', 'db.tx(', 'db.migrate(', 'db.kv', '/query', 'ATTACH', 'DB_CLOSED']) {
    ok(apiHtml.includes(need), `api.html 缺少 ${need}`);
  }
  const settings = fs.readFileSync(path.join(PLUGIN_DIR, 'settings.html'), 'utf8');
  for (const need of ['jlw-settings-init', 'jlw-settings-save', 'allowAttach', 'adminOpenids', 'httpPort']) {
    ok(settings.includes(need), `settings.html 缺少 ${need}`);
  }
  ok(fs.existsSync(path.join(PLUGIN_DIR, 'README.md')), '插件 README 应存在');
});

/* ======================= 运行 ======================= */

async function run() {
  for (const { name, fn } of checks) {
    try {
      await fn();
      passed++;
      console.log(`  ✓ ${name}`);
    } catch (e) {
      failed++;
      failures.push({ name, error: e });
      console.log(`  ✗ ${name}\n      ${e.message}`);
    }
  }
  try {
    await PLUGIN.onUnload(ctx);
  } catch {
    /* ignore */
  }
  fs.rmSync(TMP, { recursive: true, force: true });
  console.log(`\n${passed} passed, ${failed} failed, ${checks.length} total`);
  if (failed) {
    console.log('\n失败详情：');
    for (const f of failures) console.log(`- ${f.name}: ${f.error.stack || f.error.message}`);
    process.exitCode = 1;
  }
}

run();
