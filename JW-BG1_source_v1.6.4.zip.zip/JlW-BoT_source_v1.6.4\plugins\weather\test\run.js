'use strict';
/**
 * 天气查询插件 · 自检（不联网、不出图；--live 才打真实接口）
 *
 *   node plugins/weather/test/run.js
 *   node plugins/weather/test/run.js --live
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const S = require('../lib/subscribe');
const C = require('../lib/cities');
const T = require('../lib/texts');
const cards = require('../lib/card');
const weather = require('../lib/weather');
const media = require('../lib/media');
const U = require('../lib/util');
const { openStore } = require('../lib/store');
const index = require('../index');

let pass = 0;
let fail = 0;
const failures = [];

function ok(cond, name, extra) {
  if (cond) {
    pass++;
    return true;
  }
  fail++;
  failures.push(name + (extra ? ' —— ' + extra : ''));
  console.log('  ✗ ' + name + (extra ? ' —— ' + extra : ''));
  return false;
}

function eq(actual, expect, name) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expect);
  return ok(a === e, name, `期望 ${e}，实际 ${a}`);
}

function section(title) {
  console.log('\n· ' + title);
}

/* ======================= 1. 时间解析 ======================= */
section('时间解析 parseTime');
{
  const cases = [
    ['0800', '0800'], ['800', '0800'], ['8', '0800'], ['8:00', '0800'], ['8：05', '0805'],
    ['8点', '0800'], ['8点30', '0830'], ['8点半', '0830'], ['八点', '0800'], ['十点', '1000'],
    ['十八点', '1800'], ['二十三点五十', '2350'], ['早上八点', '0800'], ['上午9点15分', '0915'],
    ['下午两点十八分', '1418'], ['下午2:18', '1418'], ['晚上8点', '2000'], ['晚上9点半', '2130'],
    ['傍晚6点', '1800'], ['中午12点', '1200'], ['中午1点', '1300'], ['凌晨1点', '0100'],
    ['凌晨12点', '0000'], ['2130', '2130'], ['2359', '2359'], ['0000', '0000'], ['１４：１８', '1418'],
  ];
  for (const [input, expect] of cases) eq(S.parseTime(input), expect, `parseTime(${input})`);
  for (const bad of ['', 'abc', '25:00', '24:00', '12:61', '9999', '午夜', '八十五点']) {
    ok(S.parseTime(bad) == null, `parseTime 拒绝非法输入 ${JSON.stringify(bad)}`, String(S.parseTime(bad)));
  }
  eq(S.formatTime('0800'), '08:00', 'formatTime');
  eq(S.minutesOf('2130'), 1290, 'minutesOf 2130');
  eq(S.firstPushText('0800', new Date(2026, 10, 24, 9, 0)), '明天 08:00', '首次推送：已过点 → 明天');
  eq(S.firstPushText('0800', new Date(2026, 10, 24, 7, 0)), '今天 08:00', '首次推送：未到点 → 今天');
}

/* ======================= 2. 到点判定（按分钟） ======================= */
section('到点判定 dueNow / 分钟调度');
{
  const at = (h, m) => new Date(2026, 10, 24, h, m, 0);
  const base = { enabled: true, time: '0800', lastDate: '', code: '101280109' };
  const today = '2026-11-24';

  ok(S.dueNow({ ...base }, at(8, 0)).due === true, '时间正好 08:00 → 推');
  ok(S.dueNow({ ...base }, at(8, 1)).due === false, '08:01 不在这一分钟 → 跳过（不补推）');
  ok(S.dueNow({ ...base }, at(7, 59)).due === false, '07:59 还没到 → 跳过');
  ok(S.dueNow({ ...base, lastDate: today, lastTime: '0800' }, at(8, 0)).due === false, '本分钟已经推过 → 不重复');
  ok(S.dueNow({ ...base, lastDate: today, lastTime: '0801' }, at(8, 0)).due === true, '同一天推过但不同分钟 → 仍可推（改时间后能生效）');
  ok(S.dueNow({ ...base, lastDate: today, lastTime: '' }, at(8, 0)).due === true, 'lastDate 是今天但没记时间（旧数据）→ 照推');
  ok(S.dueNow({ ...base, lastDate: '2026-11-23' }, at(8, 0)).due === true, '昨天推过、今天到点 → 推');
  ok(S.dueNow({ ...base, enabled: false }, at(8, 0)).due === false, '已关闭 → 不推');
  ok(S.dueNow({ ...base, code: '', lat: null }, at(8, 0)).due === false, '没有城市 → 不推');
  ok(S.dueNow({ ...base, code: '', lat: 23.1, lon: 113.3 }, at(8, 0)).due === true, '只有经纬度也能推');
  eq(S.dueNow({ ...base }, at(8, 0)).reason, undefined, '到点时不带 reason');
  eq(S.dueNow({ ...base, enabled: false }, at(8, 0)).reason, 'disabled', '关闭的 reason');
  eq(S.dueNow({ ...base }, at(8, 1)).reason, 'not-this-minute', '错过的 reason');
  eq(S.dueNow({ ...base, lastDate: today, lastTime: '0800' }, at(8, 0)).reason, 'already-this-minute', '本分钟已推的 reason');

  // 分钟工具
  eq(S.minuteKey(at(8, 5)), '0805', 'minuteKey');
  eq(S.minuteKey(at(23, 59)), '2359', 'minuteKey 23:59');
  const ms = S.msToNextMinute(new Date(2026, 10, 24, 8, 0, 30).getTime());
  eq(ms, 30000, 'msToNextMinute = 距下个整分 30s');
  ok(S.msToNextMinute(new Date(2026, 10, 24, 8, 0, 0).getTime()) === 60000, '整分时刻 → 等满 60s');
}

/* ======================= 3. 城市解析 ======================= */
section('城市解析 cities.resolve');
{
  const good = [
    ['天河', '101280109'], ['天河区', '101280109'], ['广州天河', '101280109'],
    ['广东省广州市天河区', '101280109'], ['广州', '101280101'], ['北京', '101010100'],
    ['北京朝阳', '101010300'], ['深圳南山', '101280604'], ['浦东新区', '101020600'],
    ['西安', '101110101'], ['杭州西湖', '101210113'], ['苏州昆山', '101190404'],
    ['乌鲁木齐', '101130101'], ['吉林', '101060201'], ['香港', '101320101'],
  ];
  for (const [input, code] of good) {
    const r = C.resolve(input);
    ok(r.ok && r.code === code, `resolve(${input}) = ${code}`, r.ok ? r.code : r.reason);
  }
  ok(C.resolve('朝阳').ok, 'resolve(朝阳) 有唯一解（北京朝阳）');
  const nocity = C.resolve('广东');
  ok(!nocity.ok && nocity.reason === 'need-city', 'resolve(广东) 要求具体到市');
  ok(!C.resolve('这个地名根本不存在').ok, 'resolve(不存在) → 失败');
  ok(C.resolve('').reason === 'empty', 'resolve(空) → empty');
  const st = C.stats();
  ok(st.provinces === 34 && st.cities > 300 && st.districts > 2000, '城市表规模', JSON.stringify(st));
}

/* ======================= 4. 指令解析 ======================= */
section('指令解析 parseIntent');
{
  eq(index.parseIntent('/天气 广州 天河'), { kind: 'query', city: '广州 天河' }, '/天气 广州 天河');
  eq(index.parseIntent('天气 天河'), { kind: 'query', city: '天河' }, '天气 天河（不带斜杠）');
  eq(index.parseIntent('/天气 订阅 广州 天河'), { kind: 'subscribe', city: '广州 天河' }, '/天气 订阅 城市');
  eq(index.parseIntent('/天气 订阅'), { kind: 'subscribe', city: '' }, '/天气 订阅（缺城市）');
  eq(index.parseIntent('/天气 时间 0800'), { kind: 'time', time: '0800' }, '/天气 时间 0800');
  eq(index.parseIntent('/天气 时间 晚上9点半'), { kind: 'time', time: '晚上9点半' }, '/天气 时间（中文）');
  eq(index.parseIntent('/天气 取消订阅'), { kind: 'cancel' }, '/天气 取消订阅');
  eq(index.parseIntent('/天气'), { kind: 'auto' }, '/天气 无参数');
  eq(index.parseIntent('天气 帮助').kind, 'help', '帮助');
  eq(index.parseIntent('订阅消息 天气 开启'), null, '旧指令不再响应');
  eq(index.parseIntent('随便说点什么'), null, '无关消息 → null');
  eq(index.parseIntent(''), null, '空消息 → null');
}

/* ======================= 5. 成品串（宜/不宜、措辞） ======================= */
section('成品串 finalize');
{
  const mk = (over = {}) =>
    weather.finalize(
      {
        ok: true,
        src: 'test',
        now: { temp: 17.8, humidity: 64, windDir: '北风', windScale: '3级', windSpeed: '6.2km/h', pressure: 1023, aqi: 157, ...(over.now || {}) },
        today: { text: '阴', high: 27, low: 15, sunrise: '06:38', sunset: '17:43', uv: 6.1, ...(over.today || {}) },
        quality: over.quality,
        rain: over.rain,
      },
      new Date(2026, 10, 12, 8, 0),
    );
  const w = mk({ quality: '中度污染', rain: { checked: true, segments: [], summary: '', snow: false } });
  eq(w.final.quality_s, '中度污染（AQI 157）', '空气质量串');
  eq(w.final.uv_s, '强（6.1）', '紫外线串');
  eq(w.final.wind_s, '北风 3级（6.2km/h）', '风速串');
  eq(w.final.pressure_s, '1023 hPa', '气压串');
  eq(w.final.humidity_s, '64%', '湿度串');
  eq(w.final.sun_s, '06:38 / 17:43', '日出日落串');
  eq(w.final.rain_s, '今天没有降雨', '没有降水段 → 今天没有降雨');
  eq(w.final.greet, '早上好', '问候语（8 点）');
  ok(w.final.bad.includes('空气差'), 'AQI>150 → 不宜户外运动', w.final.bad);

  eq(mk({ today: { text: '雷阵雨', uv: 3 } }).final.good, '室内活动、看电影', '雷雨 → 宜室内');
  eq(mk({ today: { text: '小雪', high: 1 } }).final.rain_s, '今天有降雪', '雪 → 降雨措辞改成降雪');
  eq(mk({ today: { text: '雾' }, now: { aqi: 40 } }).final.bad, '晨练、开窗通风', '雾 → 不宜晨练');
  eq(mk({ today: { text: '晴', uv: 9 }, now: { aqi: 40 } }).final.bad, '长时间暴晒', '晴天 UV≥8 → 不宜暴晒');
  eq(mk({ today: { text: '多云', uv: 2 }, now: { aqi: 40 } }).final.good, '出行、运动', '多云 → 宜出行');
  eq(mk({ today: { text: '小雨', uv: 2 } }).final.rain_s, '今天有降雨', '无逐小时数据但有雨 → 今天有降雨');
  const seg = mk({ rain: { checked: true, segments: [{ at: 16, hours: 2, text: '小雨' }], summary: '2 小时后开始小雨（约 2 小时）', snow: false } });
  eq(seg.final.rain_s, '2 小时后开始小雨（约 2 小时）', '有降水段 → 用段摘要');
}

/* ======================= 6. 文案模板 ======================= */
section('文案模板 texts');
{
  eq(T.renderTemplate('城市：{city}，温度 {temp}℃', { city: '天河', temp: 20 }), '城市：天河，温度 20℃', '占位符替换');
  eq(T.renderTemplate('未知：{nope} 结束', {}), '未知： 结束', '未知占位符 → 空串');
  eq(T.renderTemplate('{a}-{b}', { a: 1, b: null }), '1-', 'null → 空串');
  const lines = T.toLines('\n\n第一行\n\n\n第二行\n\n', {});
  eq(lines, ['第一行', '', '第二行'], 'toLines 去掉首尾空行、合并多空行');
  eq(T.toLines('a\nb', {}, { maxLines: 1 }), ['a'], 'maxLines 生效');

  const texts = T.normalizeTexts({ help: '', weatherTitle: '自定义 {src}' });
  ok(texts.help === T.DEFAULT_TEXTS.help, '空文案回退默认');
  eq(texts.weatherTitle, '自定义 {src}', '自定义文案保留');
  ok(T.normalizeTexts({}).badTime.includes('不太像时间'), '默认文案齐全');

  const card = T.normalizeCard({ width: 100, radius: 999, text: '#fff' });
  eq(card.width, 480, 'width 下限钳制');
  eq(card.radius, 60, 'radius 上限钳制');
  eq(card.text, '#fff', '颜色自定义');
  ok(T.normalizeCard({}).bgFrom.startsWith('#'), '默认颜色齐全');

  const vars = T.weatherVars(
    { ok: true, src: 'S', now: { temp: 18, aqi: 22 }, today: { text: '晴', high: 25, low: 15 }, final: { greet: '早上好', wind_s: 'W', quality_s: 'Q', uv_s: 'U', pressure_s: 'P', humidity_s: 'H', sun_s: 'SUN', good: 'G', bad: 'B', rain_s: 'R' } },
    { district: '天河', city: '广州', display: '广东·广州·天河', code: '101', time: '0800' },
    new Date(2026, 10, 12, 8, 0),
  );
  eq([vars.city, vars.temp, vars.time, vars.date], ['天河', '18', '08:00', '2026-11-12'], 'weatherVars 关键字段');
  ok(vars.week.startsWith('星期'), 'weatherVars 星期');
  eq(T.infoVars({ display: 'X', time: '0800', enabled: true, lastDate: '2026-11-23', lastTime: '0800' }).lastPush, '2026-11-23 08:00', 'infoVars 上次推送');
  eq(T.infoVars({ enabled: false }).status, '已关闭', 'infoVars 状态');
}

/* ======================= 7. 卡片 spec ======================= */
section('卡片 spec');
{
  const card = T.normalizeCard({});
  const spec = cards.buildSpec({
    title: '天气推送 · 中国天气网',
    lines: ['早上好，2026-11-12 星期四', '', '天河区 阴', '温度：15℃ ~ 27℃', '宜：出行', '不宜：户外运动（空气差）'],
    footer: '/天气 订阅 广州 天河  ·  /天气 时间 0800',
    card,
  });
  ok(spec.width === 780, '宽度来自配置', String(spec.width));
  ok(spec.height > 400, '高度按行数算', String(spec.height));
  ok(spec.background.type === 'linear', '渐变背景');
  const texts = spec.items.filter((i) => i.type === 'text');
  ok(texts.some((t) => t.text.includes('天河区 阴')), '正文有天气');
  ok(texts.some((t) => t.text.includes('/天气 订阅')), '页脚有指令');
  ok(spec.items.some((i) => i.type === 'rect' && i.color === card.panel), '有面板矩形');
  ok(spec.items.some((i) => i.type === 'rect' && i.color === card.accent), '有强调条');
  const goodLine = texts.find((t) => t.text.startsWith('宜：'));
  const badLine = texts.find((t) => t.text.startsWith('不宜：'));
  eq(goodLine.color, card.good, '「宜」用绿');
  eq(badLine.color, card.bad, '「不宜」用红');
  const longSpec = cards.buildSpec({ title: '长'.repeat(120), lines: ['长'.repeat(200)], footer: 'f'.repeat(400), card });
  ok(longSpec.items.filter((i) => i.type === 'text').every((t) => t.text.length < 200), '超长文本被截断');
  const text = cards.specToText(spec);
  ['天气推送', '天河区 阴', '温度：15℃ ~ 27℃', '/天气 订阅'].forEach((k) => ok(text.includes(k), 'specToText 含 ' + k));
  ok(cards.estimateWidth('中文', 25) > cards.estimateWidth('ab', 25), '中文估宽 > 英文');
}

/* ======================= 8. 存储：JSON 回退 ======================= */
section('存储 JsonStore');
{
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wx-store-'));
  const log = { info() {}, warn() {}, error() {}, debug() {} };
  const store = openStore({ dir, log }); // 没装假 VSQL → 回退 JSON
  ok(store.driver === 'json', '没有 VSQL 时回退 JSON', store.driver);
  ok(store.info().note.includes('VSQL'), 'info 说明回退原因');

  const s1 = store.upsert({ openid: 'U1', accountId: 'accA', code: '101280109', display: '广东·广州·天河', time: '8点', enabled: true });
  eq(s1.time, '0800', '时间规范化');
  eq(store.counts(), { total: 1, enabled: 1, withCity: 1 }, 'counts');
  store.patch('U1', { lastDate: '2026-11-24', lastTime: '0800', pushCount: 3 });
  const reopen = openStore({ dir, log });
  const got = reopen.get('U1');
  ok(got && got.lastDate === '2026-11-24' && got.pushCount === 3, '重新打开后数据还在');
  ok(reopen.remove('U1') === true, 'remove');
  eq(openStore({ dir, log }).counts().total, 0, '删除落盘');

  reopen.recordTask({ id: 't1', action: 'test', openid: 'U1', at: 1, ok: true, message: 'ok' });
  ok(reopen.taskDone('t1'), '任务记账');
  ok(!reopen.taskDone('t2'), '未执行任务');
  eq(reopen.recentTasks(5).length, 1, 'recentTasks');
  fs.rmSync(dir, { recursive: true, force: true });
}

/* ======================= 9. 存储：VSQL 驱动（用 node:sqlite 冒充 VSQL） ======================= */
section('存储 VsqlStore');
{
  const { DatabaseSync } = require('node:sqlite');
  const raw = new DatabaseSync(':memory:');
  const fakeDb = {
    exec: (sql) => raw.exec(sql),
    run: (sql, ...p) => {
      const st = raw.prepare(sql);
      return st.run(...p);
    },
    get: (sql, ...p) => raw.prepare(sql).get(...p),
    all: (sql, ...p) => raw.prepare(sql).all(...p),
    info: () => ({ file: ':memory:' }),
    namespace: 'shared',
  };
  const fakeVsql = { isReady: () => true, db: () => fakeDb, version: 'test' };
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', fakeVsql]]);

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wx-vsql-'));
  const log = { info() {}, warn() {}, error() {}, debug() {} };
  const store = openStore({ dir, log });
  ok(store.driver === 'vsql', '有 VSQL 时用 VSQL', store.driver);

  store.upsert({ openid: 'U1', accountId: 'accA', code: '101280109', display: '广东·广州·天河', province: '广东', city: '广州', district: '天河', lat: 23.1, lon: 113.3, time: '0800', enabled: true });
  const got = store.get('U1');
  ok(got && got.code === '101280109' && got.lat === 23.1, '写入 Redis 后读回', JSON.stringify(got));
  ok(got.enabled === true, 'enabled 布尔还原');
  eq(store.counts().enabled, 1, 'counts（VSQL）');

  store.patch('U1', { lastDate: '2026-11-24', lastTime: '0800', pushCount: 7 });
  const after = store.get('U1');
  eq([after.lastDate, after.pushCount], ['2026-11-24', 7], 'patch（VSQL）');

  store.upsert({ openid: 'U1', display: '广东·深圳·南山', code: '101280604', enabled: false });
  const updated = store.get('U1');
  eq([updated.display, updated.enabled], ['广东·深圳·南山', false], '同 openid 覆盖更新');

  const rows = raw.prepare('SELECT COUNT(*) AS n FROM weather_subs').get();
  eq(Number(rows.n), 1, '表里只有一行（按 openid 主键）');
  const cols = raw.prepare('PRAGMA table_info(weather_subs)').all().map((c) => c.name);
  ['openid', 'account_id', 'last_date', 'push_count', 'enabled'].forEach((c) => ok(cols.includes(c), 'VSQL 列 ' + c, cols.join(',')));

  store.recordTask({ id: 't1', action: 'del', openid: 'U1', at: 2, ok: true, message: '删除' });
  ok(store.taskDone('t1'), '任务记账（VSQL）');
  ok(store.remove('U1') === true, '删除（VSQL）');
  eq(store.counts().total, 0, '删除后为空（VSQL）');
  ok(store.info().tables.includes('weather_subs'), 'info 报出表名');

  raw.close();
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
  fs.rmSync(dir, { recursive: true, force: true });
}

/* ======================= 10. 富媒体回复 ======================= */
async function testMedia() {
  section('富媒体 media');
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]);
  const calls = [];
  const ctx = {
    message: { kind: 'c2c', user_openid: 'U1' },
    log: { warn() {} },
    api: {
      call: async (endpoint, opts) => {
        calls.push({ endpoint, opts });
        return { ok: true, data: { file_info: 'FI123' } };
      },
    },
  };
  const r = await media.replyImage(ctx, png);
  ok(r.ok && r.replies[0].type === 'media' && r.replies[0].file_info === 'FI123', '上传后返回 media 回复');
  ok(calls[0].endpoint === 'c2c_file_upload', '单聊走 c2c_file_upload', calls[0].endpoint);
  ok(calls[0].opts.body.file_type === 1 && typeof calls[0].opts.body.file_data === 'string', 'body 带 file_data(base64)');

  const groupCtx = { ...ctx, message: { kind: 'group', group_openid: 'G1' }, api: { call: async (e, o) => (calls.push({ endpoint: e, opts: o }), { ok: true, data: { file_info: 'G' } }) } };
  await media.replyImage(groupCtx, png);
  ok(calls[calls.length - 1].endpoint === 'group_file_upload', '群聊走 group_file_upload');

  const failCtx = { ...ctx, api: { call: async () => ({ ok: false, code: 'X', message: 'nope' }) } };
  const fail = await media.replyImage(failCtx, png);
  ok(fail.ok === false, '上传失败 → 调用方走文本兜底');
  const noTarget = await media.replyImage({ message: { kind: 'c2c' } }, png);
  ok(noTarget.ok === false, '没有 openid → 失败');
}

/* ======================= 11. 插件入口（不出图，走文本兜底） ======================= */
async function testEntry() {
  section('插件入口（render 关闭 → 文本兜底）');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wx-ctx-'));
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  fs.writeFileSync(
    path.join(dir, 'settings.html'),
    '<!-- WX_DATA_START -->\n<script id="wx-data" type="application/json">{}</script>\n<!-- WX_DATA_END -->',
    'utf8',
  );
  const logs = [];
  const log = {
    info: (m) => logs.push(['info', m]),
    warn: (m) => logs.push(['warn', m]),
    error: (m) => logs.push(['error', m]),
    debug: () => {},
  };
  const ctx = {
    plugin: { id: 'weather', dir, config: { checkSeconds: 300, cacheTtlMs: 0, render: { enabled: false } } },
    config: { get: (k, d) => d },
    log,
    account: { id: 'accA' },
    bot: { sendC2C: async () => ({ ok: true }) },
    message: null,
  };
  await index.onLoad(ctx);
  ok(logs.some((l) => /已加载/.test(l[1])), 'onLoad 打日志');
  ok(logs.some((l) => /存储 JSON/.test(l[1])), '日志标出存储驱动');
  {
    // 回归：v1.3.0 先写快照后挂调度，设置页会一直显示「调度未运行」
    const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
    const m = html.match(/<script id="wx-data" type="application\/json">([\s\S]*?)<\/script>/);
    const snap = JSON.parse(m[1]);
    ok(snap.runtime && snap.runtime.running === true, 'onLoad 后快照里调度是「运行中」', JSON.stringify(snap.runtime && snap.runtime.schedule));
  }

  const say = async (text, kind = 'c2c') => {
    const msg =
      kind === 'group'
        ? { kind: 'group', group_openid: 'G1', cleanContent: text, content: text, author: { member_openid: 'M1' } }
        : { kind: 'c2c', user_openid: 'U1', cleanContent: text, content: text, author: { user_openid: 'U1' } };
    const evt = { name: kind === 'group' ? 'GROUP_MESSAGE_CREATE' : 'C2C_MESSAGE_CREATE', accountId: 'accA', message: msg };
    const out = await index.onEvent({ ...ctx }, evt);
    if (!out) return null;
    return out.reply || (out.replies || []).map((r) => r.content).join('\n');
  };

  ok((await say('你好')) == null, '无关消息不回复');
  ok((await say('订阅消息 天气 开启')) == null, '旧指令不再响应');

  const help = await say('/天气');
  ok(help && help.includes('订阅每日推送'), '/天气（私聊未订阅）→ 菜单（文本兜底）');

  const g = await say('/天气 广州 天河', 'group');
  ok(g && g.includes('天河'), '群聊 /天气 城市 → 返回该城市信息', String(g).slice(0, 40));

  const go = await say('/天气 订阅 广州 天河', 'group');
  ok(go && /私聊/.test(go), '群里订阅 → 提示去私聊');

  const notFound = await say('/天气 火星表面');
  ok(notFound && notFound.includes('没查到'), '认不出的地名');

  const timeEarly = await say('/天气 时间 0800');
  ok(timeEarly && /还没设置城市/.test(timeEarly), '没设城市就设时间 → 提示先设城市');

  const badTime = await say('/天气 时间 99:99');
  ok(badTime && /不太像时间/.test(badTime), '非法时间');

  // 群聊 /天气 不带城市 → 群菜单
  const gn = await say('/天气', 'group');
  ok(gn && /群里只能用/.test(gn), '群里 /天气 不带城市 → 群菜单', String(gn).slice(0, 30));

  await index.onUnload();
  fs.rmSync(dir, { recursive: true, force: true });
}

/* ======================= 12. 真实接口（可选） ======================= */
async function testLive() {
  section('真实接口（--live）');
  const geo = await require('../lib/geocode').geocode('广东省 广州市 天河区', { timeoutMs: 6000 });
  ok(geo.ok, 'geocode(天河区)', JSON.stringify(geo).slice(0, 160));
  for (const [name, code] of [
    ['广东·广州·天河', '101280109'],
    ['北京·朝阳', '101010300'],
    ['上海·浦东新区', '101020600'],
  ]) {
    const w = await weather.getWeather(
      { code, lat: geo.ok ? geo.lat : null, lon: geo.ok ? geo.lon : null, name },
      { timeoutMs: 8000, cacheTtlMs: 0, force: true },
    );
    ok(w.ok, `getWeather(${name})`, JSON.stringify(w.errors || []));
    if (w.ok) {
      console.log(`    → ${w.src}：${w.today.text} ${w.now.temp}℃ · ${w.final.quality_s} · 紫外线 ${w.final.uv_s} · ${w.final.rain_s}`);
      console.log(`      宜：${w.final.good} / 不宜：${w.final.bad}`);
    }
  }
}

(async () => {
  await testMedia();
  await testEntry();
  if (process.argv.includes('--live')) await testLive();
  console.log('\n' + '─'.repeat(60));
  console.log(`自检结果：通过 ${pass} · 失败 ${fail}`);
  if (fail) {
    console.log('失败项：');
    for (const f of failures) console.log('  - ' + f);
    process.exitCode = 1;
  } else {
    console.log('全部通过 ✅');
  }
})();
