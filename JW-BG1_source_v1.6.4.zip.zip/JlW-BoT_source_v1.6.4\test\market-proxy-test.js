'use strict';
/** 插件市场代理：去 XFO、根路径改写、API/下载转发、不泄露面板 Cookie */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  let seenCookie = '';
  let seenInm = '';
  let autoLoginCalls = 0;
  const MARKET_ACCOUNTS = { 'user@test.local': 'MARKET-TOKEN-7', 'other@test.local': 'MARKET-TOKEN-8' };
  const upstream = http.createServer((req, res) => {
    seenCookie = String(req.headers.cookie || '');
    seenInm = String(req.headers['if-none-match'] || '');
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/') {
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'X-Frame-Options': 'SAMEORIGIN',
        'Content-Security-Policy': "frame-ancestors 'self'",
      });
      return res.end(
        `<!doctype html><html><head><link rel="stylesheet" href="/assets/app.css"></head><body>
        <div id="home-page">MARKET-HOME</div>
        <a href="/">首页</a><a href="/home">去首页</a>
        <a href="/developer" data-view="/developer.html">开发者中心</a>
        <iframe id="viewFrame" src="/home-view.html"></iframe>
        <script>fetch('/api/plugins')</script><script src="/assets/market.js"></script>
        </body></html>`,
      );
    }
    if (u.pathname === '/index.html') {
      // 真实市场的 /index.html 是「插件列表」页，不是首页；代理根路径不能落到这里
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end('<!doctype html><html><body><div id="list-page">MARKET-LIST</div></body></html>');
    }
    if (u.pathname === '/assets/app.css') {
      res.writeHead(200, { 'Content-Type': 'text/css' });
      return res.end('body{background:url(/assets/bg.png)}');
    }
    if (u.pathname === '/assets/market.js') {
      res.writeHead(200, {
        'Content-Type': 'application/javascript',
        ETag: 'W/"market-js-1"',
        'Cache-Control': 'no-cache',
      });
      return res.end(
        "const PATHS = {'/home-view.html':'/home','/index.html':'/market','/developer.html':'/developer'};\n" +
          "fetch('/api/plugins'); window.open('/api/files/7/download');",
      );
    }
    if (u.pathname === '/home-view.html') {
      res.writeHead(200, { 'Content-Type': 'text/html', 'X-Frame-Options': 'SAMEORIGIN' });
      return res.end('<b>home view</b>');
    }
    if (u.pathname === '/api/v1/plugins' && req.method === 'POST') {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => {
        const buf = Buffer.concat(chunks);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, len: buf.length, sha: crypto.createHash('sha256').update(buf).digest('hex') }));
      });
      return;
    }
    if (u.pathname === '/api/auth/auto-login' && req.method === 'POST') {
      autoLoginCalls++;
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        const token = MARKET_ACCOUNTS[body.mail];
        if (!token || body.password !== 'secret123') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ ok: false, msg: '邮箱或密码不正确' }));
        }
        res.writeHead(200, {
          'Content-Type': 'application/json',
          'Set-Cookie': [`vlos_sid=${token}; Path=/; HttpOnly; SameSite=Lax; Secure`],
        });
        res.end(JSON.stringify({ ok: true, user: { email: body.mail }, msg: '登录成功' }));
      });
      return;
    }
    if (u.pathname === '/api/me') {
      const hit = Object.entries(MARKET_ACCOUNTS).find(([, token]) => seenCookie.includes('vlos_sid=' + token));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ user: hit ? { email: hit[0] } : null }));
    }
    if (u.pathname === '/api/auth/logout' && req.method === 'POST') {
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Set-Cookie': ['vlos_sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax'],
      });
      return res.end(JSON.stringify({ ok: true }));
    }
    if (u.pathname === '/assets/common.js') {
      res.writeHead(200, { 'Content-Type': 'application/javascript' });
      return res.end(
        "const embedded = (() => { try { return window.self !== window.top; } catch { return true; } })();\n" +
          "if (window.self !== window.top) { console.log('embedded'); }\n",
      );
    }
    if (u.pathname === '/assets/login.js') {
      res.writeHead(200, { 'Content-Type': 'application/javascript' });
      return res.end("function done(){ window.top.location.href='/home'; }");
    }
    if (u.pathname === '/api/plugins') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ok: true, items: [{ id: 'p1' }] }));
    }
    if (u.pathname === '/api/files/7/download') {
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="p1.zip"' });
      return res.end(Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x99]));
    }
    res.writeHead(404);
    res.end('no');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const jlw = await new MockJlw({ port: 0 }).start();
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-market-'));
  const port = 19011 + Math.floor(Math.random() * 30);
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        log: { level: 'warn', console: false },
      },
      null,
      2,
    ),
  );
  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: {
      ...process.env,
      JLW_DATA_DIR: dataDir,
      JLW_ALLOW_LOCAL_SITE: '1',
      JLW_ALLOW_ALL_LOGIN: '1',
      JLW_MARKET_URL: upstreamBase,
    },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };

  try {
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      try {
        if ((await fetch(base + '/health')).ok) break;
      } catch {
        /* retry */
      }
      await sleep(200);
    }
    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    const cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];

    const unauth = await fetch(base + '/market-proxy/');
    check(unauth.status === 401, '未登录不能访问市场代理');

    const page = await fetch(base + '/market-proxy/', { headers: { Cookie: cookie } });
    const html = await page.text();
    check(page.status === 200, '市场首页代理成功');
    check(html.includes('MARKET-HOME') && !html.includes('MARKET-LIST'), '根路径映射到市场首页（不是 /index.html 列表页）');
    check(html.includes('href="/market-proxy/"'), '首页根链接改写到 /market-proxy/');
    check(!page.headers.get('x-frame-options'), '已去掉 X-Frame-Options');
    check(!page.headers.get('content-security-policy'), '已去掉上游 CSP');
    check(html.includes('/market-proxy/assets/app.css'), 'HTML 根路径资源改写');
    check(html.includes('/market-proxy/home'), 'HTML 链接改写');
    check(html.includes('/market-proxy/home-view.html'), '嵌套 iframe 改写');
    check(html.includes('/market-proxy/api/plugins'), '内联 JS API 改写');
    check(!seenCookie.includes('jlw_sid='), '不把面板会话 Cookie 转发给市场');

    const css = await fetch(base + '/market-proxy/assets/app.css', { headers: { Cookie: cookie } }).then((r) => r.text());
    check(css.includes('/market-proxy/assets/bg.png'), 'CSS url 改写');

    const js = await fetch(base + '/market-proxy/assets/market.js', { headers: { Cookie: cookie } }).then((r) => r.text());
    check(js.includes('/market-proxy/api/plugins'), 'JS API 路径改写');
    check(js.includes('/market-proxy/api/files/7/download'), 'JS 下载路径改写');
    check(js.includes("'/market-proxy/developer.html'"), '栏目路由 developer.html 也改写到代理路径（否则点了没反应）');
    check(html.includes('data-view="/market-proxy/developer.html"'), '顶栏 data-view 与路由一致');
    check(html.includes('bindInner') && html.includes('/market-proxy/developer.html'), '外壳页注入了栏目点击补丁（顶栏 + 内层站内链接）');
    const inner = await fetch(base + '/market-proxy/home-view.html', { headers: { Cookie: cookie } }).then((r) => r.text());
    check(!inner.includes('__jlwNavBound'), '内层视图不重复注入补丁');

    // 上传插件：zip 是二进制，代理必须原样转发（不能 toString 再编码）
    const zipBytes = Buffer.alloc(4096);
    for (let i = 0; i < zipBytes.length; i++) zipBytes[i] = i % 256;
    const upRes = await fetch(base + '/market-proxy/api/v1/plugins?name=test', {
      method: 'POST',
      headers: { Cookie: cookie, 'Content-Type': 'application/zip' },
      body: zipBytes,
    });
    const upJson = await upRes.json();
    const expectSha = crypto.createHash('sha256').update(zipBytes).digest('hex');
    check(upJson.ok === true && upJson.len === zipBytes.length, '上传 zip 二进制原样转发（长度一致）');
    check(upJson.sha === expectSha, '上传 zip 内容未损坏（sha256 一致）');

    // 缓存：改写过的 JS 不能被浏览器 304 复用（否则升级后还在跑旧 shell.js）
    const jsCached = await fetch(base + '/market-proxy/assets/market.js', {
      headers: { Cookie: cookie, 'If-None-Match': 'W/"market-js-1"' },
    });
    check(jsCached.status === 200, '带 If-None-Match 仍返回完整 JS');
    check(jsCached.headers.get('cache-control') === 'no-store' && !jsCached.headers.get('etag'), '改写内容禁止缓存（no-store，去掉 ETag）');
    check(!seenInm, '不把 If-None-Match 转发给市场（避免 304 用旧内容）');

    const json = await fetch(base + '/market-proxy/api/plugins', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(json.ok === true && json.items?.[0]?.id === 'p1', '市场 API JSON 透传');
    check(seenCookie.includes('vlos_sid=MARKET-TOKEN-7'), '登录后自动带上市场会话（免二次登录）');
    check(!seenCookie.includes('jlw_sid='), '自动登录后仍不泄露面板会话 Cookie');

    const forced = await fetch(base + '/market-proxy/api/plugins', {
      headers: { Cookie: cookie + '; vlos_sid=BROWSER-OLD' },
    }).then((r) => r.json());
    check(forced.ok === true && seenCookie.includes('vlos_sid=MARKET-TOKEN-7') && !seenCookie.includes('BROWSER-OLD'), '服务端市场会话覆盖浏览器里的旧值');

    const navJs = await fetch(base + '/market-proxy/assets/login.js', { headers: { Cookie: cookie } }).then((r) => r.text());
    check(!/top\.location/.test(navJs) && navJs.includes('location.reload()'), '市场登录后不再顶掉面板（iframe 内就地刷新）');

    const commonJs = await fetch(base + '/market-proxy/assets/common.js', { headers: { Cookie: cookie } }).then((r) => r.text());
    check(
      commonJs.includes('__jlwMarketInOwnShell()') && !commonJs.includes('return window.self !== window.top;'),
      '内嵌判定改为「父窗口是市场外壳」，面板里不再隐藏顶栏',
    );
    check(commonJs.includes('function __jlwMarketInOwnShell'), '注入了内嵌判定辅助函数');
    check(commonJs.includes("if (window.self !== window.top)"), '其它 window.top 判断保持原样');

    const me = await fetch(base + '/market-proxy/api/me', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(me.user?.email === 'user@test.local', '内嵌市场已登录（/api/me 有用户）');
    check(autoLoginCalls === 1, '一次面板登录只调一次市场自动登录');

    const st = await fetch(base + '/api/market/status', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(st.signedIn === true && st.mail === 'user@test.local', '市场登录态可查询（/api/market/status）');

    const dl = await fetch(base + '/market-proxy/api/files/7/download', { headers: { Cookie: cookie } });
    const bytes = Buffer.from(await dl.arrayBuffer());
    check(dl.status === 200 && bytes.equals(Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x99])), '插件下载二进制透传');
    check((dl.headers.get('content-disposition') || '').includes('p1.zip'), '下载文件名保留');

    // 同一账户再登录一次：应该复用缓存的市场会话，不再消耗自动登录接口的限流额度
    const login2 = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    const cookie2 = ((login2.headers.getSetCookie ? login2.headers.getSetCookie()[0] : login2.headers.get('set-cookie')) || '').split(';')[0];
    const me2 = await fetch(base + '/market-proxy/api/me', { headers: { Cookie: cookie2 } }).then((r) => r.json());
    check(me2.user?.email === 'user@test.local', '再次登录面板仍自动带市场会话');
    check(autoLoginCalls === 1, '重复登录复用缓存，不再调自动登录（省限流额度）');

    // 在 iframe 里点「退出登录」：服务端缓存要一起丢掉，不能又注入回去
    const lo = await fetch(base + '/market-proxy/api/auth/logout', {
      method: 'POST',
      headers: { Cookie: cookie2, 'Content-Type': 'application/json' },
      body: '{}',
    });
    check(lo.status === 200, '市场内可正常退出登录');
    const afterLogout = await fetch(base + '/market-proxy/api/me', { headers: { Cookie: cookie2 } }).then((r) => r.json());
    check(!afterLogout.user, '市场退出后不再注入旧会话');

    // 框架重启、面板会话还在：用密码补一次市场登录
    const bad = await fetch(base + '/api/market/login', {
      method: 'POST',
      headers: { Cookie: cookie2, 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'wrong-pass' }),
    });
    const badBody = await bad.json();
    check(bad.status === 400 && /密码/.test(badBody.error || ''), '补登录密码错误时返回市场报错');

    const relogin = await fetch(base + '/api/market/login', {
      method: 'POST',
      headers: { Cookie: cookie2, 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'secret123' }),
    });
    const reloginBody = await relogin.json();
    check(relogin.status === 200 && reloginBody.signedIn === true, '手动补登录市场成功');
    const meAgain = await fetch(base + '/market-proxy/api/me', { headers: { Cookie: cookie2 } }).then((r) => r.json());
    check(meAgain.user?.email === 'user@test.local', '补登录后内嵌市场直接可用');
    check(autoLoginCalls === 3, '只有缓存失效时才真正调用自动登录接口');

    // 多人编辑场景：指定登录范围里的另一个账户登录市场
    const other = await fetch(base + '/api/market/login', {
      method: 'POST',
      headers: { Cookie: cookie2, 'Content-Type': 'application/json' },
      body: JSON.stringify({ mail: 'other@test.local', password: 'secret123' }),
    });
    const otherBody = await other.json();
    check(other.status === 200 && otherBody.mail === 'other@test.local', '可以指定另一个授权账户登录市场');
    const meOther = await fetch(base + '/market-proxy/api/me', { headers: { Cookie: cookie2 } }).then((r) => r.json());
    check(meOther.user?.email === 'other@test.local', '切换后市场会话换成新账户');
    check(seenCookie.includes('vlos_sid=MARKET-TOKEN-8'), '转发时带的是新账户的市场会话');
    const stOther = await fetch(base + '/api/market/status', { headers: { Cookie: cookie2 } }).then((r) => r.json());
    check(stOther.signedIn === true && stOther.mail === 'other@test.local', '状态接口反映当前市场账户');
    check(autoLoginCalls === 4, '切换账户只调一次自动登录');
  } finally {
    child.kill();
    await sleep(200);
    await jlw.stop();
    await new Promise((r) => upstream.close(r));
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
