'use strict';
/* JlWBoT 内置文档页：零依赖 Markdown 渲染 + 目录 + 代码复制 */
(() => {
  const content = document.getElementById('docs-content');
  const tocEl = document.getElementById('docs-toc');
  const searchEl = document.getElementById('docs-search');
  const sideEl = document.querySelector('.docs-side');
  const themeBtn = document.getElementById('docs-theme');
  const tocToggle = document.getElementById('docs-toc-toggle');
  const copyAllBtn = document.getElementById('docs-copy-all');
  let docText = '';

  /* ---------- 主题 ---------- */
  const savedTheme = localStorage.getItem('jlw-theme') || 'dark';
  document.documentElement.dataset.theme = savedTheme;
  themeBtn?.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    localStorage.setItem('jlw-theme', next);
  });
  tocToggle?.addEventListener('click', () => sideEl?.classList.toggle('open'));
  sideEl?.addEventListener('click', (e) => {
    if (e.target.closest('a')) sideEl.classList.remove('open');
  });

  /* ---------- 工具 ---------- */
  const esc = (s) =>
    String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  function inline(text) {
    let s = esc(text);
    const codes = [];
    s = s.replace(/`([^`]+)`/g, (_, code) => {
      codes.push(code);
      return '\u0000' + (codes.length - 1) + '\u0000';
    });
    s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) => {
      const url = href.replace(/&amp;/g, '&');
      return `<a href="${esc(url)}" target="_blank" rel="noreferrer">${label}</a>`;
    });
    s = s.replace(/&lt;(https?:\/\/[^\s&]+)&gt;/g, (_, url) => `<a href="${url}" target="_blank" rel="noreferrer">${url}</a>`);
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');
    s = s.replace(/\u0000(\d+)\u0000/g, (_, n) => `<code>${codes[Number(n)]}</code>`);
    return s;
  }

  const stripInline = (text) =>
    String(text)
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/~~([^~]+)~~/g, '$1')
      .trim();

  function slugify(text) {
    const s = stripInline(text)
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fa5\s-]/g, '')
      .trim()
      .replace(/\s+/g, '-');
    return s || 'section';
  }

  const isTableStart = (lines, i) => {
    const line = lines[i] || '';
    const next = lines[i + 1] || '';
    return line.includes('|') && next.includes('|') && /^\s*\|?\s*:?-{3,}/.test(next);
  };

  const isBlockStart = (line) =>
    /^(```|#{1,4}\s|>\s?|\s*([-*+]|\d+\.)\s+|\s*---+\s*$)/.test(line);

  function splitRow(line) {
    return line
      .trim()
      .replace(/^\|/, '')
      .replace(/\|$/, '')
      .split('|')
      .map((c) => c.trim());
  }

  function parseList(lines, start, out) {
    const items = [];
    let i = start;
    while (i < lines.length) {
      const m = /^(\s*)([-*+]|\d+\.)\s+(.*)$/.exec(lines[i]);
      if (!m) break;
      const indent = m[1].replace(/\t/g, '  ').length;
      const ordered = /^\d+\./.test(m[2]);
      let text = m[3];
      i++;
      while (
        i < lines.length &&
        lines[i].trim() &&
        !/^(\s*)([-*+]|\d+\.)\s+/.test(lines[i]) &&
        !isBlockStart(lines[i]) &&
        !isTableStart(lines, i)
      ) {
        text += ' ' + lines[i].trim();
        i++;
      }
      items.push({ indent, text, ordered });
    }

    let html = '';
    const stack = [];
    for (const it of items) {
      const tag = it.ordered ? 'ol' : 'ul';
      while (stack.length && it.indent < stack[stack.length - 1].indent) {
        html += `</li></${stack.pop().tag}>`;
      }
      if (!stack.length) {
        html += `<${tag}>`;
        stack.push({ indent: it.indent, tag });
      } else if (it.indent > stack[stack.length - 1].indent) {
        html += `<${tag}>`;
        stack.push({ indent: it.indent, tag });
      } else {
        html += '</li>';
        if (stack[stack.length - 1].tag !== tag) {
          html += `</${stack.pop().tag}><${tag}>`;
          stack.push({ indent: it.indent, tag });
        }
      }
      html += `<li>${inline(it.text)}`;
    }
    while (stack.length) html += `</li></${stack.pop().tag}>`;
    out.push(html);
    return i;
  }

  function render(md) {
    const lines = String(md).replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    const toc = [];
    const used = new Map();
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];

      if (!line.trim()) {
        i++;
        continue;
      }

      /* 代码块 */
      const fence = /^```([\w+-]*)\s*$/.exec(line);
      if (fence) {
        const lang = fence[1] || 'text';
        const langLabel =
          { e: '易语言', el: '易语言', js: 'javascript', py: 'python', cs: 'csharp', sh: 'shell', text: 'text' }[lang] || lang;
        i++;
        const buf = [];
        while (i < lines.length && !/^```\s*$/.test(lines[i])) buf.push(lines[i++]);
        i++;
        out.push(
          `<div class="code-block"><div class="code-head"><span>${esc(langLabel)}</span>` +
            `<button class="code-copy" type="button">复制</button></div>` +
            `<pre><code>${esc(buf.join('\n'))}</code></pre></div>`,
        );
        continue;
      }

      /* 标题 */
      const head = /^(#{1,4})\s+(.*)$/.exec(line);
      if (head) {
        const level = head[1].length;
        const text = head[2].trim();
        let id = slugify(text);
        if (used.has(id)) {
          const n = used.get(id) + 1;
          used.set(id, n);
          id = `${id}-${n}`;
        } else {
          used.set(id, 1);
        }
        out.push(`<h${level} id="${esc(id)}">${inline(text)}</h${level}>`);
        if (level === 2 || level === 3) toc.push({ level, text: stripInline(text), id });
        i++;
        continue;
      }

      /* 分隔线 */
      if (/^\s*---+\s*$/.test(line)) {
        out.push('<hr>');
        i++;
        continue;
      }

      /* 引用 */
      if (/^>\s?/.test(line)) {
        const buf = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) {
          buf.push(lines[i].replace(/^>\s?/, ''));
          i++;
        }
        out.push(`<blockquote><p>${inline(buf.join(' '))}</p></blockquote>`);
        continue;
      }

      /* 表格 */
      if (isTableStart(lines, i)) {
        const header = splitRow(lines[i]);
        i += 2;
        const rows = [];
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) {
          rows.push(splitRow(lines[i]));
          i++;
        }
        out.push('<div class="table-wrap"><table><thead><tr>');
        out.push(header.map((c) => `<th>${inline(c)}</th>`).join(''));
        out.push('</tr></thead><tbody>');
        for (const row of rows) {
          while (row.length < header.length) row.push('');
          out.push('<tr>' + row.slice(0, header.length).map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>');
        }
        out.push('</tbody></table></div>');
        continue;
      }

      /* 列表 */
      if (/^\s*([-*+]|\d+\.)\s+/.test(line)) {
        i = parseList(lines, i, out);
        continue;
      }

      /* 段落 */
      const buf = [];
      while (
        i < lines.length &&
        lines[i].trim() &&
        !isBlockStart(lines[i]) &&
        !isTableStart(lines, i) &&
        !/^```/.test(lines[i])
      ) {
        buf.push(lines[i].trim());
        i++;
      }
      if (buf.length) out.push(`<p>${inline(buf.join(' '))}</p>`);
    }

    return { html: out.join('\n'), toc };
  }

  /* ---------- 目录 ---------- */
  function buildToc(toc) {
    if (!tocEl) return;
    tocEl.innerHTML =
      toc
        .map(
          (t) =>
            `<a class="lvl${t.level}" href="#${esc(t.id)}" data-text="${esc(t.text.toLowerCase())}">${esc(t.text)}</a>`,
        )
        .join('') || '<span class="item-sub" style="padding:8px 10px">（无目录）</span>';
    const links = [...tocEl.querySelectorAll('a')];
    const map = new Map(links.map((a) => [decodeURIComponent(a.getAttribute('href').slice(1)), a]));
    const heads = [...content.querySelectorAll('h2[id], h3[id]')];

    const setActive = () => {
      let cur = heads[0];
      for (const h of heads) {
        if (h.getBoundingClientRect().top <= 110) cur = h;
        else break;
      }
      links.forEach((a) => a.classList.remove('active'));
      if (cur && map.get(cur.id)) {
        const active = map.get(cur.id);
        active.classList.add('active');
        const r = active.getBoundingClientRect();
        const pr = tocEl.getBoundingClientRect();
        if (r.top < pr.top + 4 || r.bottom > pr.bottom - 4) active.scrollIntoView({ block: 'nearest' });
      }
    };
    window.addEventListener('scroll', setActive, { passive: true });
    setActive();

    searchEl?.addEventListener('input', () => {
      const q = searchEl.value.trim().toLowerCase();
      for (const a of links) {
        const hit = !q || (a.dataset.text || '').includes(q) || a.textContent.toLowerCase().includes(q);
        a.style.display = hit ? '' : 'none';
      }
    });
  }

  /* ---------- 复制 ---------- */
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }

  content?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.code-copy');
    if (!btn) return;
    const code = btn.closest('.code-block')?.querySelector('code')?.textContent || '';
    await copyText(code);
    const old = btn.textContent;
    btn.textContent = '已复制';
    setTimeout(() => (btn.textContent = old), 1200);
  });

  function docPlainText() {
    const clone = content.cloneNode(true);
    clone.querySelectorAll('.code-copy').forEach((b) => b.remove());
    const holder = document.createElement('div');
    holder.setAttribute('aria-hidden', 'true');
    holder.style.cssText = 'position:fixed;left:-10000px;top:0;width:1000px;opacity:0;pointer-events:none;z-index:-1;';
    holder.appendChild(clone);
    document.body.appendChild(holder);
    const text = clone.innerText || clone.textContent || '';
    holder.remove();
    return text.replace(/\n{3,}/g, '\n\n').trim();
  }

  copyAllBtn?.addEventListener('click', async () => {
    if (!docText) return;
    const old = copyAllBtn.textContent;
    copyAllBtn.disabled = true;
    try {
      await copyText(docText);
      copyAllBtn.textContent = '已复制全文';
    } catch {
      copyAllBtn.textContent = '复制失败';
    }
    setTimeout(() => {
      copyAllBtn.disabled = false;
      copyAllBtn.textContent = old;
    }, 2400);
  });

  function fixDocLinks() {
    for (const a of content.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('/') || /^[a-z]+:/i.test(href)) continue;
      if (!/\.md$/i.test(href)) continue;
      const name = href.split('/').pop();
      a.href = '/docs.html?doc=' + encodeURIComponent(name);
      a.target = '_self';
    }
  }

  const docName = new URLSearchParams(location.search).get('doc') || 'plugin.md';
  const rawLink = document.querySelector('.docs-side-foot a');
  if (rawLink) rawLink.href = '/docs/' + encodeURIComponent(docName);

  /* ---------- 加载 ---------- */
  fetch('/docs/' + encodeURIComponent(docName), { cache: 'no-store' })
    .then((r) => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.text();
    })
    .then((md) => {
      const { html, toc } = render(md);
      content.innerHTML = html;
      const h1 = content.querySelector('h1');
      if (h1) {
        const title = h1.textContent.trim();
        document.title = /^JlWBoT/i.test(title) ? title : 'JlWBoT · ' + title;
      }
      fixDocLinks();
      buildToc(toc);
      docText = docPlainText();
      if (copyAllBtn) {
        copyAllBtn.disabled = false;
        copyAllBtn.title = `复制当前文档全文（${docText.length.toLocaleString('zh-CN')} 字，纯文本，适合转发）`;
      }
    })
    .catch((e) => {
      content.innerHTML = `<div class="docs-error">文档加载失败：${esc(e.message)}<br>请确认 <code>docs/${esc(docName)}</code> 存在，或直接打开 <a href="/docs/${encodeURIComponent(docName)}" target="_blank" rel="noreferrer">Markdown 原文</a>。</div>`;
    });
})();
