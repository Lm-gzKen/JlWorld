'use strict';
/**
 * 定时重启配置 + 接口调用日志 + 面板重启接口
 *   node test/restart-log-test.js
 */
const assert = require('assert');
const http = require('http');
const { EventEmitter } = require('events');

const ROOT = require('path').resolve(__dirname, '..');
const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}

function captureLogger() {
  const recs = [];
  const mk = (scope) => ({
    info: (msg, meta) => recs.push({ level: 'info', scope, msg, meta }),
    warn: (msg, meta) => recs.push({ level: 'warn', scope, msg, meta }),
    error: (msg, meta) => recs.push({ level: 'error', scope, msg, meta }),
    debug: (msg, meta) => recs.push({ level: 'debug', scope, msg, meta }),
    trace: () => {},
    child: (s) => mk(scope ? scope + '/' + s : s),
  });
  const logger = mk('root');
  logger.subscribe = () => () => {};
  logger.recent = () => recs;
  return { logger, recs };
}

(async () => {
  /* ---------------- 定时重启配置 ---------------- */
  const maintenance = require('../src/core/maintenance');
  const n1 = maintenance.normalizeRestart({ enabled: true, minutes: 30 });
  check(n1.enabled && n1.minutes === 30, '读取启用状态与分钟数', JSON.stringify(n1));
  check(maintenance.normalizeRestart({ enabled: true, minutes: 0 }).enabled === false, '分钟数 0 视为不启用');
  check(maintenance.normalizeRestart({ enabled: false, minutes: 30 }).enabled === false, '关闭开关后不启用');
  check(maintenance.normalizeRestart({ enabled: true, minutes: -5 }).minutes === 0, '负数分钟被归零');
  check(maintenance.normalizeRestart({ enabled: true, minutes: 999999 }).minutes === maintenance.MAX_MINUTES, '超长分钟被截到上限');
  const cfg = { get: (k, d) => (k === 'system.restart' ? { enabled: true, minutes: 45 } : d) };
  check(maintenance.readRestartConfig(cfg).minutes === 45, 'readRestartConfig 读配置');
  const next = maintenance.nextRestartAt(10, 1000);
  check(next === 1000 + 600000, 'nextRestartAt 计算正确', String(next));
  check(maintenance.msUntil(1000 + 600000, 1000) === 600000, 'msUntil 计算剩余时间');
  check(maintenance.msUntil(0) === 0, '没有计划时剩余为 0');
  check(/每 10 分钟/.test(maintenance.describeRestart({ enabled: true, minutes: 10 })), 'describeRestart 描述清楚');

  /* ---------------- 接口调用日志 ---------------- */
  const srv = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      if (req.url.startsWith('/ok')) {
        res.writeHead(200, { 'Content-Type': 'application/json', 'x-tps-trace-id': 'TRACE1' });
        return res.end(JSON.stringify({ id: 'MSG1', ok: true }));
      }
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ code: 40034024, message: 'msg_id 无效' }));
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const apiBase = `http://127.0.0.1:${srv.address().port}`;
  const QQApi = require('../src/core/api');

  function makeApi(logCfg = {}, recs) {
    const config = {
      get: (k, d) => {
        if (k === 'bot.apiBase') return apiBase;
        if (k === 'bot.sandbox') return false;
        if (k === 'log.api') return logCfg.api !== undefined ? logCfg.api : true;
        if (k === 'log.apiBody') return logCfg.apiBody === true;
        return d;
      },
    };
    const token = { get: async () => 'tok', header: () => 'QQBot tok', invalidate: () => {} };
    const { logger, recs: captured } = captureLogger();
    const api = new QQApi({ config, token, logger, accountId: 'a1' });
    return { api, captured };
  }

  {
    const { api, captured } = makeApi({}, []);
    const r = await api.get('/ok');
    check(r.ok === true, '接口调用成功');
    const rec = captured.find((x) => x.level === 'debug' && /\/ok/.test(x.msg));
    check(!!rec, '成功调用写入 DEBUG 日志', JSON.stringify(captured.map((c) => c.msg)));
    check(/GET \/ok → 200/.test(rec.msg), '日志包含方法/路径/状态', rec.msg);
    check(/ms/.test(rec.msg), '日志包含耗时');
    check(rec.meta?.traceId === 'TRACE1', '日志带 traceId', JSON.stringify(rec.meta));
    check(/api:a1$/.test(rec.scope || ''), '日志带账户 scope', rec.scope);
    check(!('req' in (rec.meta || {})), '默认不记录请求体');
  }

  {
    const { api, captured } = makeApi({}, []);
    const r = await api.post('/fail', { content: 'hi', access_token: 'abcdefghijklmnop' });
    check(r.ok === false && r.code === 40034024, '失败调用返回错误码');
    const rec = captured.find((x) => x.level === 'warn' && /\/fail/.test(x.msg));
    check(!!rec, '失败调用写入 WARN 日志', JSON.stringify(captured.map((c) => c.msg)));
    check(/code=40034024/.test(rec.msg), '失败日志包含 code', rec.msg);
    check(/msg_id 无效/.test(rec.msg), '失败日志包含接口 message', rec.msg);
  }

  {
    const { api, captured } = makeApi({ apiBody: true }, []);
    await api.post('/ok', { content: 'hi', access_token: 'abcdefghijklmnop' });
    const rec = captured.find((x) => x.level === 'debug' && /\/ok/.test(x.msg));
    check(!!rec?.meta?.req, '开启 apiBody 后记录请求体');
    check(/\*\*\*\*\*\*/.test(rec.meta.req), '请求体里的 token 被打码', rec.meta.req);
    check(!/abcdefghijklmnop/.test(rec.meta.req), '请求体不出现明文 token');
    check(!!rec.meta.res, '开启 apiBody 后记录响应体', JSON.stringify(rec.meta.res));
  }

  {
    const { api, captured } = makeApi({ api: false }, []);
    await api.get('/ok');
    await api.get('/fail');
    check(captured.filter((x) => x.level === 'debug' || x.level === 'warn').length === 0, '关闭 log.api 后不写调用日志');
  }

  {
    // 网络错误也要有日志
    const { api, captured } = makeApi({}, []);
    const bad = new QQApi({
      config: {
        get: (k, d) => (k === 'bot.apiBase' ? 'http://127.0.0.1:1' : k === 'log.api' ? true : d),
      },
      token: { get: async () => 't', header: () => 'QQBot t', invalidate: () => {} },
      logger: captureLogger().logger,
      accountId: 'bad',
    });
    const r = await bad.get('/x', { retry: 0 });
    check(r.ok === false && r.code === 'NETWORK_ERROR', '网络错误返回 NETWORK_ERROR');
  }

  await new Promise((r) => srv.close(r));

  /* ---------------- 面板重启接口 ---------------- */
  const PanelServer = require('../src/core/server');
  const port = 21600 + Math.floor(Math.random() * 300);
  const { logger } = captureLogger();
  const host = new EventEmitter();
  host.info = () => ({ count: 0, configured: 0 });
  host.status = () => ({ accounts: [], counts: {}, today: 0 });
  host.list = () => [];
  host.events = () => [];
  host.webhookAccount = () => null;
  const config = {
    data: {},
    get: (k, d) => (k === 'server.port' ? port : k === 'server.host' ? '127.0.0.1' : d),
    set() {},
    save() {},
    jlw: () => ({ baseUrl: '' }),
    isLoginAllowed: () => true,
    publicConfig: () => ({ system: { restart: { enabled: true, minutes: 15 } } }),
    update: () => ({}),
  };
  let restarted = 0;
  let configChanged = null;
  const panel = new PanelServer({
    config,
    logger,
    host,
    plugins: { list: () => [], registry: new Map(), info: () => ({}) },
    endpoints: [],
    webhook: {},
    netinfo: {},
    session: { get: () => ({ sid: 's1', user: { email: 'a@b.c' } }), destroy() {} },
    jlw: {},
    updater: {},
    watchdogMs: 5000,
    onManualRestart: () => {
      restarted++;
      return true;
    },
    onConfigChange: (patch) => {
      configChanged = patch;
    },
  });
  const base = `http://127.0.0.1:${port}`;
  await panel.start();

  const st = await fetch(base + '/api/status').then((r) => r.json());
  check(st.system?.restart?.enabled === false, '状态里有 system.restart 默认值', JSON.stringify(st.system));

  panel.setRestartSchedule({ enabled: true, minutes: 15, nextAt: Date.now() + 900000 });
  const st2 = await fetch(base + '/api/status').then((r) => r.json());
  check(st2.system?.restart?.minutes === 15 && st2.system.restart.enabled === true, 'setRestartSchedule 反映到 /api/status', JSON.stringify(st2.system));

  const rs = await fetch(base + '/api/system/restart', { method: 'POST', body: '{}' }).then((r) => r.json());
  check(rs.ok === true && rs.restarting === true, 'POST /api/system/restart 返回重启中', JSON.stringify(rs));
  check(restarted === 1, '重启回调被调用一次', String(restarted));

  const cfgRes = await fetch(base + '/api/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ patch: { system: { restart: { enabled: true, minutes: 5 } } } }),
  }).then((r) => r.json());
  check(cfgRes.ok === true, '保存 system.restart 配置成功', JSON.stringify(cfgRes));
  check(!!configChanged && configChanged.system, '配置变更触发 onConfigChange', JSON.stringify(configChanged));

  await panel.stop();
  try { panel.server.closeAllConnections?.(); } catch {}
  await new Promise((r) => setTimeout(r, 120));

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
