'use strict';
/**
 * VloS · 运行中的框架只读联调（需要框架在 8686 端口运行，且本机有面板会话）
 *
 *   node test/vlos-live.js
 *
 * 不写真实聚龙账户、不发邮件、不改 users.json。注册 / 绑定流程用 test/vlos-test.js 的假 API 验证。
 */

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const BASE = process.env.VLOS_BASE || 'http://127.0.0.1:8686';

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) {
    pass++;
    console.log(`  ✓ ${name}`);
  } else {
    fail++;
    console.log(`  ✗ ${name}${detail ? '\n      ' + detail : ''}`);
  }
}

function sid() {
  // 旧版框架：data/sessions.json；1.5+：data/jlwbot.db 的 sessions 表
  try {
    const sessions = JSON.parse(fs.readFileSync(path.join(ROOT, '~JlWBoT', 'data', 'sessions.json'), 'utf8'));
    const first = Object.keys(sessions).find((k) => sessions[k] && (!sessions[k].expiresAt || sessions[k].expiresAt > Date.now()));
    if (first) return first;
  } catch {
    /* 试数据库 */
  }
  try {
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(path.join(ROOT, '~JlWBoT', 'jlwbot.db'), { readOnly: true });
    try {
      const row = db.prepare('SELECT sid FROM sessions WHERE expires > ? ORDER BY created DESC LIMIT 1').get(Date.now());
      if (row && row.sid) return String(row.sid);
    } finally {
      db.close();
    }
  } catch {
    /* ignore */
  }
  return '';
}

async function request(pathname, { method = 'GET', body } = {}) {
  const res = await fetch(BASE + pathname, {
    method,
    headers: {
      Cookie: `jlw_sid=${encodeURIComponent(sid())}`,
      'x-jlw-session': sid(),
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* html */
  }
  return { status: res.status, text, json };
}

function mdOf(json) {
  const r = json?.result?.result || json?.result;
  return r?.replies?.[0]?.markdown?.content || r?.reply || '';
}

/** 提取 markdown 指令标签里的 text（已 urlencode），用于断言 */
function cmdTexts(md) {
  const out = [];
  String(md || '').replace(/text="([^"]*)"/g, (_, v) => {
    try {
      out.push(decodeURIComponent(v));
    } catch (e) {
      /* ignore */
    }
    return _;
  });
  return out;
}

(async () => {
  console.log(`=== VloS 只读联调 ${BASE} ===`);
  if (!sid()) {
    console.error('找不到面板会话（~JlWBoT/data/sessions.json），请先在面板登录。');
    process.exit(1);
  }

  const health = await request('/health');
  check('框架 /health', health.status === 200 && health.json?.ok === true, health.text.slice(0, 200));

  const list = await request('/api/plugins');
  const vlos = (list.json?.plugins || []).find((p) => p.id === 'VloS');
  const pkgVersion = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugins', 'VloS', 'package.json'), 'utf8')).version;
  check('VloS 已加载并运行', !!vlos && vlos.status === 'running', JSON.stringify(vlos));
  check('运行版本与 package.json 一致', vlos?.version === pkgVersion, `运行 ${vlos?.version} / 源码 ${pkgVersion}`);
  check('设置页已登记', !!vlos?.hasSettings);
  check('API 文档已登记', !!vlos?.hasApiDoc);

  const settings = await request('/api/plugins/VloS/settings');
  check('GET 设置页 200', settings.status === 200);
  check('设置页含聚龙账户 baseUrl', settings.text.includes('baseUrl'));
  check('设置页含发奖 Key', settings.text.includes('clearKey') && settings.text.includes('walletMode'));
  check('设置页不再有 SMTP / 邮件编辑器', !settings.text.includes('smtpHost') && !settings.text.includes('contenteditable'));
  check('设置页含 菜单 / 群管 / 进退群', ['data-tab="menu"', 'data-tab="guard"', 'data-tab="welcome"'].every((x) => settings.text.includes(x)));
  check('设置页含 指令 / 用户', ['data-tab="commands"', 'data-tab="users"', 'vlos-users-data'].every((x) => settings.text.includes(x)));
  check('设置页含自定义蓝色指令变量', settings.text.includes('{cmd:/Arknights|明日方舟}') && settings.text.includes('{cmd:指令|显示文字}'));
  check('设置页含 审核', settings.text.includes('data-tab="review"') && settings.text.includes('vlos-callbacks-data'));
  check('设置页含审核刷新按钮', settings.text.includes('reviewRefresh'));
  const reviewSnapMatch = settings.text.match(/<script id="vlos-callbacks-data"[^>]*>([\s\S]*?)<\/script>/);
  let reviewSnap = null;
  try {
    reviewSnap = JSON.parse(reviewSnapMatch[1]);
  } catch {
    /* ignore */
  }
  check('审核快照含 groups（已通过列表）', !!reviewSnap && typeof reviewSnap.groups === 'object');
  check('设置页用户快照不含 token', settings.text.includes('3407556894@qq.com') && !/tok_[A-Za-z0-9]/.test(settings.text));

  const apiDoc = await request('/api/plugins/VloS/api-doc');
  check('GET API 文档 200', apiDoc.status === 200);
  check('API 文档含 /bindqq', apiDoc.text.includes('/bindqq'));
  check('API 文档含 currency-add', apiDoc.text.includes('currency-add'));
  check('API 文档含 /菜单同步', apiDoc.text.includes('/菜单同步'));

  const help = await request('/api/plugins/VloS/test', { method: 'POST', body: { content: '/vlos' } });
  const helpMd = mdOf(help.json);
  check('/vlos 返回 Markdown', help.status === 200 && helpMd.includes('## VloS 指令'), helpMd.slice(0, 200));
  const cmds = cmdTexts(helpMd);
  check('/vlos 指令是可点击标签', helpMd.includes('qqbot-cmd-input') && cmds.length >= 8, cmds.join(','));
  check('/vlos 含 /add', cmds.includes('/add') && helpMd.includes('注册聚龙账户'));
  check('/vlos 含 /bindqq', cmds.includes('/bindqq'));
  check('/vlos 含 /bindopenid', cmds.includes('/bindopenid'));
  check('/vlos 含 /菜单', cmds.includes('/菜单'));
  check('/vlos 含 /群管', cmds.includes('/群管'));
  check('/vlos 签到模式是聚龙世界链接', helpMd.includes('签到模式：[聚龙世界](https://www.jlworld.net)'), helpMd.slice(-160));

  const menu = await request('/api/plugins/VloS/test', { method: 'POST', body: { content: '/菜单' } });
  const menuMd = mdOf(menu.json);
  check('/菜单 返回可点击指令标签', menu.status === 200 && menuMd.includes('## 菜单') && menuMd.includes('qqbot-cmd-input'), menuMd.slice(0, 240));

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail) process.exitCode = 1;
})().catch((e) => {
  console.error('联调失败：' + (e.stack || e));
  process.exitCode = 1;
});
