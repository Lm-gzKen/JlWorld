# QQ 机器人 API v2 接口清单

> 本文件由 `node tools/gen-api-doc.js` 自动生成，与 `src/core/endpoints.js` 保持同步。
> 共 67 个接口，全部可在面板「接口」页直接调试，也可由插件通过 `action=endpoint` 调用。
> 文末另有**插件市场上传 API**（把插件 zip 发布到 VloSBoT 插件市场），不属于 QQ API。

## 调用方式

- 面板：直接填写参数调用，自动带上 `access_token`。
- 插件：`{"action":"endpoint","endpoint":"send_group_message","params":{"group_openid":"..."},"body":{...}}`
- 任意请求：`{"action":"api","method":"POST","path":"/v2/groups/xxx/messages","body":{...}}`

## 消息 · 群聊

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 发送群聊消息 | POST | `/v2/groups/{group_openid}/messages` | `send_group_message` |
| 撤回群聊消息 | DELETE | `/v2/groups/{group_openid}/messages/{message_id}` | `recall_group_message` |
| 群聊富媒体上传 | POST | `/v2/groups/{group_openid}/files` | `group_file_upload` |
| 群聊分片预上传 | POST | `/v2/groups/{group_openid}/upload_prepare` | `group_upload_prepare` |
| 群聊分片上传完成 | POST | `/v2/groups/{group_openid}/upload_part_finish` | `group_upload_part_finish` |

### 发送群聊消息 · `send_group_message`

```http
POST /v2/groups/{group_openid}/messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | B2C3D4E5F6... |

**请求体示例**

```json
{
  "msg_type": 0,
  "content": "你好，我是机器人",
  "msg_id": "",
  "msg_seq": 1
}
```

> 被动回复 60 分钟内、同一 msg_id 最多 5 次；机器人是群主/管理员时最多 50 次（群内与私聊回复共用）。消息事件传 msg_id（可配 msg_seq）；GROUP_ADD_ROBOT / GROUP_MSG_RECEIVE / INTERACTION_CREATE 传 event_id，不要带 msg_seq；GROUP_MEMBER_ADD / GROUP_MEMBER_REMOVE 没有被动回复接口，只能发主动消息（需主动消息权限）。msg_type 0文本 2Markdown 7富媒体 8图文卡片；Markdown 支持 <qqbot-at-user id="..."/>、<qqbot-at-everyone/>、<qqbot-cmd-input text="..." show="..."/>（点击把指令填入输入框）；<qqbot-cmd-enter/> 群聊不支持

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_messages.post.html)

### 撤回群聊消息 · `recall_group_message`

```http
DELETE /v2/groups/{group_openid}/messages/{message_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |
| `message_id` | 是 | 消息 ID | — |

> 仅 2 分钟内可撤回

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_messages_message_id.delete.html)

### 群聊富媒体上传 · `group_file_upload`

```http
POST /v2/groups/{group_openid}/files
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "file_type": 1,
  "url": "https://example.com/a.png",
  "srv_send_msg": false
}
```

> file_type 1图片 2视频 3语音 4文件；返回 file_info 用于发消息 media

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_files.post.html)

### 群聊分片预上传 · `group_upload_prepare`

```http
POST /v2/groups/{group_openid}/upload_prepare
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "file_type": 2,
  "file_size": "1048576",
  "file_name": "video.mp4",
  "md5": "",
  "sha1": "",
  "md5_10m": ""
}
```

> 返回 upload_id 与各分片 presigned_url，PUT 上传后调 upload_part_finish

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_id_upload_prepare.post.html)

### 群聊分片上传完成 · `group_upload_part_finish`

```http
POST /v2/groups/{group_openid}/upload_part_finish
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "upload_id": "",
  "part_index": 0,
  "block_size": "",
  "md5": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_id_upload_part_finish.post.html)

## 消息 · 单聊

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 发送单聊消息 | POST | `/v2/users/{user_openid}/messages` | `send_c2c_message` |
| 流式发送单聊消息 | POST | `/v2/users/{user_openid}/stream_messages` | `send_c2c_stream` |
| 撤回单聊消息 | DELETE | `/v2/users/{user_openid}/messages/{message_id}` | `recall_c2c_message` |
| 单聊富媒体上传 | POST | `/v2/users/{user_openid}/files` | `c2c_file_upload` |
| 单聊分片预上传 | POST | `/v2/users/{user_openid}/upload_prepare` | `c2c_upload_prepare` |
| 单聊分片上传完成 | POST | `/v2/users/{user_openid}/upload_part_finish` | `c2c_upload_part_finish` |

### 发送单聊消息 · `send_c2c_message`

```http
POST /v2/users/{user_openid}/messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

**请求体示例**

```json
{
  "msg_type": 0,
  "content": "你好",
  "msg_id": "",
  "msg_seq": 1
}
```

> 被动回复 60 分钟内、最多 4 次；也可用群消息的 msg_id 私聊回复该群消息发送者（要求好友关系，与群内回复共用次数上限）；主动消息受频控。Markdown 支持 <qqbot-cmd-enter text="..."/>（点击直接发送）、<qqbot-cmd-input text="..." show="..."/>、<qqbot-at-user/>

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_openid_messages.post.html)

### 流式发送单聊消息 · `send_c2c_stream`

```http
POST /v2/users/{user_openid}/stream_messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

**请求体示例**

```json
{
  "input_mode": "append",
  "input_state": 1,
  "index": 0,
  "content_type": "text",
  "content_raw": "正在思考…",
  "msg_id": "",
  "msg_seq": 1
}
```

> 首片不传 stream_msg_id，服务端在 id 返回；后续分片 index 递增

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_openid_stream_messages.post.html)

### 撤回单聊消息 · `recall_c2c_message`

```http
DELETE /v2/users/{user_openid}/messages/{message_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |
| `message_id` | 是 | 消息 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_openid_messages_message_id.delete.html)

### 单聊富媒体上传 · `c2c_file_upload`

```http
POST /v2/users/{user_openid}/files
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

**请求体示例**

```json
{
  "file_type": 1,
  "url": "https://example.com/a.png",
  "srv_send_msg": false
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_openid_files.post.html)

### 单聊分片预上传 · `c2c_upload_prepare`

```http
POST /v2/users/{user_openid}/upload_prepare
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

**请求体示例**

```json
{
  "file_type": 1,
  "file_size": "1024",
  "file_name": "a.png",
  "md5": "",
  "sha1": "",
  "md5_10m": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_id_upload_prepare.post.html)

### 单聊分片上传完成 · `c2c_upload_part_finish`

```http
POST /v2/users/{user_openid}/upload_part_finish
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

**请求体示例**

```json
{
  "upload_id": "",
  "part_index": 0,
  "block_size": "",
  "md5": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_id_upload_part_finish.post.html)

## 消息 · 频道

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 发送频道消息 | POST | `/channels/{channel_id}/messages` | `send_channel_message` |
| 获取频道消息 | GET | `/channels/{channel_id}/messages` | `get_channel_messages` |
| 撤回频道消息 | DELETE | `/channels/{channel_id}/messages/{message_id}` | `recall_channel_message` |
| 发送私信消息 | POST | `/dms/{guild_id}/messages` | `send_dms_message` |

### 发送频道消息 · `send_channel_message`

```http
POST /channels/{channel_id}/messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |

**请求体示例**

```json
{
  "content": "hello",
  "msg_id": "",
  "image": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id_messages.post.html)

### 获取频道消息 · `get_channel_messages`

```http
GET /channels/{channel_id}/messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `limit` | 条数 1-100 | 20 |
| `before` | 上一页消息 id | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id_messages.get.html)

### 撤回频道消息 · `recall_channel_message`

```http
DELETE /channels/{channel_id}/messages/{message_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |
| `message_id` | 是 | 消息 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id_messages_message_id.delete.html)

### 发送私信消息 · `send_dms_message`

```http
POST /dms/{guild_id}/messages
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 私信频道 ID | — |

**请求体示例**

```json
{
  "content": "hello",
  "msg_id": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/dms_guild_id_messages.post.html)

## 机器人

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 获取机器人详情 | GET | `/users/@me` | `get_bot_me` |
| 获取机器人频道列表 | GET | `/users/@me/guilds` | `get_bot_guilds` |
| 获取用户基本信息 | GET | `/v2/users/{user_openid}/info` | `get_user_info` |
| 生成分享链接 | POST | `/v2/generate_url_link` | `generate_url_link` |
| 获取 WSS 接入点 | GET | `/gateway` | `get_gateway` |
| 获取带分片 WSS 接入点 | GET | `/gateway/bot` | `get_gateway_bot` |

### 获取机器人详情 · `get_bot_me`

```http
GET /users/@me
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/users_me.get.html)

### 获取机器人频道列表 · `get_bot_guilds`

```http
GET /users/@me/guilds
```

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `before` | 上一页 | — |
| `after` | 下一页 | — |
| `limit` | 条数 | 100 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/users_me_guilds.get.html)

### 获取用户基本信息 · `get_user_info`

```http
GET /v2/users/{user_openid}/info
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `user_openid` | 是 | 用户 OpenID | — |

> 返回昵称 / 头像 / union_openid；单聊与群聊消息事件也会下发昵称、头像和群内昵称 member_nickname

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_users_user_openid_info.get.html)

### 生成分享链接 · `generate_url_link`

```http
POST /v2/generate_url_link
```

**请求体示例**

```json
{
  "callback_data": ""
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_generate_url_link.post.html)

### 获取 WSS 接入点 · `get_gateway`

```http
GET /gateway
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/gateway.get.html)

### 获取带分片 WSS 接入点 · `get_gateway_bot`

```http
GET /gateway/bot
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/gateway_bot.get.html)

## 群聊管理

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 获取群基本信息 | GET | `/v2/groups/{group_openid}/info` | `group_info` |
| 获取机器人群内状态 | GET | `/v2/groups/{group_openid}/bot_state` | `group_bot_state` |
| 获取群成员列表 | GET | `/v2/groups/{group_openid}/members` | `group_members` |
| 获取群成员信息 | GET | `/v2/groups/{group_openid}/members/{member_openid}` | `group_member_info` |
| 批量移除群成员 | POST | `/v2/groups/{group_openid}/batch_remove_members` | `batch_remove_members` |
| 查询群黑名单 | GET | `/v2/groups/{group_openid}/member_blacklist` | `member_blacklist_query` |
| 群黑名单操作 | POST | `/v2/groups/{group_openid}/member_blacklist` | `member_blacklist_op` |
| 查询群禁言状态 | GET | `/v2/groups/{group_openid}/restrict_chat_setting` | `restrict_chat_query` |
| 设置群成员禁言 | POST | `/v2/groups/{group_openid}/restrict_chat_setting` | `restrict_chat_set` |
| 入群申请列表 | GET | `/v2/groups/{group_openid}/join_request_list` | `join_request_list` |
| 入群申请审批 | POST | `/v2/groups/{group_openid}/approval_join_request/{member_openid}` | `approval_join_request` |
| 入群自动审批策略列表 | GET | `/v2/groups/join_approval_strategy` | `join_strategy_list` |
| 创建入群自动审批策略 | POST | `/v2/groups/join_approval_strategy` | `join_strategy_create` |
| 修改入群自动审批策略 | PATCH | `/v2/groups/join_approval_strategy/{strategy_id}` | `join_strategy_update` |
| 执行入群自动审批策略 | POST | `/v2/groups/join_approval_strategy/{strategy_id}/execute` | `join_strategy_execute` |
| 修改策略白名单 | POST | `/v2/groups/join_approval_strategy/{strategy_id}/whitelist_users` | `join_strategy_whitelist` |
| 删除入群自动审批策略 | DELETE | `/v2/groups/join_approval_strategy/{strategy_id}` | `join_strategy_delete` |

### 获取群基本信息 · `group_info`

```http
GET /v2/groups/{group_openid}/info
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

> 返回群名称、群头像等；绑定 3 方应用时含 union_group_openid

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_info.get.html)

### 获取机器人群内状态 · `group_bot_state`

```http
GET /v2/groups/{group_openid}/bot_state
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_bot_state.get.html)

### 获取群成员列表 · `group_members`

```http
GET /v2/groups/{group_openid}/members
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `cursor` | 分页游标，首次空 | — |

> 内邀能力，需白名单；每页最多 30 条

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_members.get.html)

### 获取群成员信息 · `group_member_info`

```http
GET /v2/groups/{group_openid}/members/{member_openid}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |
| `member_openid` | 是 | 成员 OpenID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_members_member_openid.get.html)

### 批量移除群成员 · `batch_remove_members`

```http
POST /v2/groups/{group_openid}/batch_remove_members
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "member_openids": [
    "OPENID1",
    "OPENID2"
  ]
}
```

> 单次最多 20 个；需要群主/管理员授权

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_batch_remove_members.post.html)

### 查询群黑名单 · `member_blacklist_query`

```http
GET /v2/groups/{group_openid}/member_blacklist
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `cursor` | 分页游标 | — |
| `limit` | 默认20 最大100 | 20 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_member_blacklist.get.html)

### 群黑名单操作 · `member_blacklist_op`

```http
POST /v2/groups/{group_openid}/member_blacklist
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "op": "add",
  "member_openids": [
    "OPENID1"
  ]
}
```

> op: add / del；用户仍在群中时无法拉黑

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_member_blacklist.post.html)

### 查询群禁言状态 · `restrict_chat_query`

```http
GET /v2/groups/{group_openid}/restrict_chat_setting
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_restrict_chat_setting.get.html)

### 设置群成员禁言 · `restrict_chat_set`

```http
POST /v2/groups/{group_openid}/restrict_chat_setting
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**请求体示例**

```json
{
  "members": [
    {
      "op": "add",
      "member_openid": "OPENID1",
      "mute_expire_at": "2026-12-31T23:59:59+08:00"
    }
  ]
}
```

> op: add / update / del；单次≤20，最长 30 天

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_restrict_chat_setting.post.html)

### 入群申请列表 · `join_request_list`

```http
GET /v2/groups/{group_openid}/join_request_list
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `cursor` | 分页游标 | — |
| `limit` | 默认20 最大50 | 20 |

> 需要机器人为群管理员；也可由 GROUP_JOIN_REQUEST 事件实时拿到 join_request_id

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_join_request_list.get.html)

### 入群申请审批 · `approval_join_request`

```http
POST /v2/groups/{group_openid}/approval_join_request/{member_openid}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `group_openid` | 是 | 群 OpenID | — |
| `member_openid` | 是 | 成员 OpenID | — |

**请求体示例**

```json
{
  "op": "approve",
  "join_request_id": "",
  "reject_reason": "",
  "add_to_member_blacklist": false
}
```

> op: approve / decline；join_request_id 取自 GROUP_JOIN_REQUEST 事件；仅群管理员可用

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_approval_join_request_member_openid.post.html)

### 入群自动审批策略列表 · `join_strategy_list`

```http
GET /v2/groups/join_approval_strategy
```

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `cursor` | 分页游标 | — |
| `limit` | 默认20 最大50 | 20 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy.get.html)

### 创建入群自动审批策略 · `join_strategy_create`

```http
POST /v2/groups/join_approval_strategy
```

**请求体示例**

```json
{
  "group_openids": [
    "GROUP_OPENID"
  ],
  "is_enable": "on",
  "remark": "自动审批"
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy.post.html)

### 修改入群自动审批策略 · `join_strategy_update`

```http
PATCH /v2/groups/join_approval_strategy/{strategy_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `strategy_id` | 是 | 策略 ID | — |

**请求体示例**

```json
{
  "is_enable": "off"
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy_strategy_id.patch.html)

### 执行入群自动审批策略 · `join_strategy_execute`

```http
POST /v2/groups/join_approval_strategy/{strategy_id}/execute
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `strategy_id` | 是 | 策略 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy_strategy_id_execute.post.html)

### 修改策略白名单 · `join_strategy_whitelist`

```http
POST /v2/groups/join_approval_strategy/{strategy_id}/whitelist_users
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `strategy_id` | 是 | 策略 ID | — |

**请求体示例**

```json
{
  "op": "add",
  "user_ids": [
    "123456789"
  ]
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy_strategy_id_whitelist_users.post.html)

### 删除入群自动审批策略 · `join_strategy_delete`

```http
DELETE /v2/groups/join_approval_strategy/{strategy_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `strategy_id` | 是 | 策略 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_join_approval_strategy_strategy_id.delete.html)

## 消息交互

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 查询全局自定义菜单 | GET | `/v2/menu` | `get_menu` |
| 修改全局自定义菜单 | PUT | `/v2/menu` | `update_menu` |
| 查询指令面板列表 | GET | `/v2/panels` | `list_panels` |
| 创建指令面板 | POST | `/v2/panels` | `create_panel` |
| 查询指令面板详情 | GET | `/v2/panels/{panel_id}` | `get_panel` |
| 修改指令面板 | PUT | `/v2/panels/{panel_id}` | `update_panel` |
| 修改面板关联对象 | PUT | `/v2/panels/{panel_id}/target` | `update_panel_target` |
| 删除指令面板 | DELETE | `/v2/panels/{panel_id}` | `delete_panel` |
| 互动事件响应 | PUT | `/interactions/{interaction_id}` | `interaction_ack` |

### 查询全局自定义菜单 · `get_menu`

```http
GET /v2/menu
```

> 仅单聊生效

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_menu.get.html)

### 修改全局自定义菜单 · `update_menu`

```http
PUT /v2/menu
```

**请求体示例**

```json
{
  "menu": {
    "items": [
      {
        "name": "帮助",
        "type": "send_message",
        "send_message": "/帮助"
      }
    ]
  }
}
```

> 全量覆盖，最多 10 项；仅单聊生效；type send_message / link / menu / switch，send_message 即点击后填入输入框的文本

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_menu.put.html)

### 查询指令面板列表 · `list_panels`

```http
GET /v2/panels
```

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `scope` | c2c/group/channel/dm | c2c |
| `cursor` | 游标 | — |
| `limit` | 默认20 最大50 | 20 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels.get.html)

### 创建指令面板 · `create_panel`

```http
POST /v2/panels
```

**请求体示例**

```json
{
  "scope": "group",
  "target_type": "all",
  "panel": {
    "items": [
      {
        "name": "签到",
        "desc": "每日签到",
        "type": "command"
      }
    ],
    "remark": ""
  }
}
```

> 一个机器人最多 20 个面板；c2c / group 支持 target_type=specific，channel / dm 只能 all；item type=command 时 name 就是点击后填入输入框的指令（≤14 字符），desc ≤30 字符

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels.post.html)

### 查询指令面板详情 · `get_panel`

```http
GET /v2/panels/{panel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `panel_id` | 是 | 面板 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels_panel_id.get.html)

### 修改指令面板 · `update_panel`

```http
PUT /v2/panels/{panel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `panel_id` | 是 | 面板 ID | — |

**请求体示例**

```json
{
  "panel": {
    "items": [
      {
        "name": "签到",
        "desc": "每日签到",
        "type": "command"
      }
    ],
    "remark": ""
  }
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels_panel_id.put.html)

### 修改面板关联对象 · `update_panel_target`

```http
PUT /v2/panels/{panel_id}/target
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `panel_id` | 是 | 面板 ID | — |

**请求体示例**

```json
{
  "target_type": "specific",
  "user_openids": [],
  "group_openids": []
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels_panel_id_target.put.html)

### 删除指令面板 · `delete_panel`

```http
DELETE /v2/panels/{panel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `panel_id` | 是 | 面板 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_panels_panel_id.delete.html)

### 互动事件响应 · `interaction_ack`

```http
PUT /interactions/{interaction_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `interaction_id` | 是 | 互动 ID | — |

**请求体示例**

```json
{
  "code": 0
}
```

> code 0成功 1失败 2频繁 3重复 4无权限 5仅管理员

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/interactions_interaction_id.put.html)

## 频道管理

| 接口 | 方法 | 路径 | key |
| --- | --- | --- | --- |
| 获取频道详情 | GET | `/guilds/{guild_id}` | `get_guild` |
| 获取子频道列表 | GET | `/guilds/{guild_id}/channels` | `get_guild_channels` |
| 创建子频道 | POST | `/guilds/{guild_id}/channels` | `create_guild_channel` |
| 获取子频道详情 | GET | `/channels/{channel_id}` | `get_channel` |
| 修改子频道 | PATCH | `/channels/{channel_id}` | `update_channel` |
| 删除子频道 | DELETE | `/channels/{channel_id}` | `delete_channel` |
| 获取频道成员列表 | GET | `/guilds/{guild_id}/members` | `get_guild_members` |
| 获取频道成员详情 | GET | `/guilds/{guild_id}/members/{user_id}` | `get_guild_member` |
| 移除频道成员 | DELETE | `/guilds/{guild_id}/members/{user_id}` | `remove_guild_member` |
| 获取身份组列表 | GET | `/guilds/{guild_id}/roles` | `get_guild_roles` |
| 创建身份组 | POST | `/guilds/{guild_id}/roles` | `create_guild_role` |
| 修改身份组 | PATCH | `/guilds/{guild_id}/roles/{role_id}` | `update_guild_role` |
| 删除身份组 | DELETE | `/guilds/{guild_id}/roles/{role_id}` | `delete_guild_role` |
| 获取频道禁言状态 | GET | `/guilds/{guild_id}/mute` | `guild_mute` |
| 修改频道禁言状态 | PATCH | `/guilds/{guild_id}/mute` | `guild_mute_set` |
| 修改成员禁言状态 | PATCH | `/guilds/{guild_id}/members/{user_id}/mute` | `member_mute_set` |
| 获取频道公告 | GET | `/guilds/{guild_id}/announces` | `get_announces` |
| 创建频道公告 | POST | `/guilds/{guild_id}/announces` | `create_announce` |
| 删除频道公告 | DELETE | `/guilds/{guild_id}/announces/{message_id}` | `delete_announce` |
| 修改子频道权限 | PUT | `/channels/{channel_id}/permissions/{user_id}` | `channel_permission_put` |

### 获取频道详情 · `get_guild`

```http
GET /guilds/{guild_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id.get.html)

### 获取子频道列表 · `get_guild_channels`

```http
GET /guilds/{guild_id}/channels
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_channels.get.html)

### 创建子频道 · `create_guild_channel`

```http
POST /guilds/{guild_id}/channels
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**请求体示例**

```json
{
  "name": "新频道",
  "type": 0,
  "position": 1,
  "parent_id": "0",
  "private_type": 0
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_channels.post.html)

### 获取子频道详情 · `get_channel`

```http
GET /channels/{channel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id.get.html)

### 修改子频道 · `update_channel`

```http
PATCH /channels/{channel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |

**请求体示例**

```json
{
  "name": "改名",
  "position": 2
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id.patch.html)

### 删除子频道 · `delete_channel`

```http
DELETE /channels/{channel_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id.delete.html)

### 获取频道成员列表 · `get_guild_members`

```http
GET /guilds/{guild_id}/members
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `after` | 上一页最后 user_id | 0 |
| `limit` | 1-1000 | 100 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_members.get.html)

### 获取频道成员详情 · `get_guild_member`

```http
GET /guilds/{guild_id}/members/{user_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `user_id` | 是 | 用户 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_members_user_id.get.html)

### 移除频道成员 · `remove_guild_member`

```http
DELETE /guilds/{guild_id}/members/{user_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `user_id` | 是 | 用户 ID | — |

**请求体示例**

```json
{
  "add_blacklist": false,
  "delete_history_msg_days": 0
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_members_user_id.delete.html)

### 获取身份组列表 · `get_guild_roles`

```http
GET /guilds/{guild_id}/roles
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_roles.get.html)

### 创建身份组 · `create_guild_role`

```http
POST /guilds/{guild_id}/roles
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**请求体示例**

```json
{
  "name": "管理员组",
  "color": 16711680,
  "hoist": 0,
  "mentionable": 0
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_roles.post.html)

### 修改身份组 · `update_guild_role`

```http
PATCH /guilds/{guild_id}/roles/{role_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `role_id` | 是 | 身份组 ID | — |

**请求体示例**

```json
{
  "name": "新名字",
  "color": 65280
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_roles_role_id.patch.html)

### 删除身份组 · `delete_guild_role`

```http
DELETE /guilds/{guild_id}/roles/{role_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `role_id` | 是 | 身份组 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_roles_role_id.delete.html)

### 获取频道禁言状态 · `guild_mute`

```http
GET /guilds/{guild_id}/mute
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_mute.get.html)

### 修改频道禁言状态 · `guild_mute_set`

```http
PATCH /guilds/{guild_id}/mute
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**请求体示例**

```json
{
  "mute_end_timestamp": "1700000000",
  "mute_seconds": "600"
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_mute.patch.html)

### 修改成员禁言状态 · `member_mute_set`

```http
PATCH /guilds/{guild_id}/members/{user_id}/mute
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `user_id` | 是 | 用户 ID | — |

**请求体示例**

```json
{
  "mute_end_timestamp": "1700000000",
  "mute_seconds": "600"
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_members_user_id_mute.patch.html)

### 获取频道公告 · `get_announces`

```http
GET /guilds/{guild_id}/announces
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**Query 参数**

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `limit` | 条数 | 20 |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_announces.get.html)

### 创建频道公告 · `create_announce`

```http
POST /guilds/{guild_id}/announces
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |

**请求体示例**

```json
{
  "channel_id": "123456",
  "message_id": "xxxx",
  "announces_type": 0,
  "recommend_channels": []
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_announces.post.html)

### 删除频道公告 · `delete_announce`

```http
DELETE /guilds/{guild_id}/announces/{message_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `guild_id` | 是 | 频道 ID | — |
| `message_id` | 是 | 公告消息 ID | — |

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/guilds_guild_id_announces_message_id.delete.html)

### 修改子频道权限 · `channel_permission_put`

```http
PUT /channels/{channel_id}/permissions/{user_id}
```

**路径参数**

| 参数 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- |
| `channel_id` | 是 | 子频道 ID | — |
| `user_id` | 是 | 用户 ID | — |

**请求体示例**

```json
{
  "add": "1",
  "remove": "0"
}
```

[官方文档](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/channels_channel_id_permissions_user_id.put.html)

## 插件市场上传 API（VloSBoT 插件市场）

> 把打好的插件 zip 上传/更新到 VloSBoT 插件市场（`https://vlos.jlworld.net`）。这部分不属于 QQ 机器人 API，是市场提供给插件作者的上传接口。

### 认证与令牌

- 请求头：`Authorization: Bearer <令牌>`。
- 令牌在「开发者中心 → API 令牌」生成；面板会显示**创建时间**和**最近使用**，点「重新生成」后旧令牌立刻失效。
- 令牌等同密码：不要写进插件代码、不要提交到仓库、不要发给别人；泄露立即重新生成。

### 请求体

- 请求体直接是 **zip 二进制**：`Content-Type: application/zip`，curl 用 `--data-binary "@插件.zip"`。
- **不要**用 `multipart/form-data`（不要 `-F`），否则会被拒绝。
- 单包上限 **200 MB**；同一插件同一个版本号不能重复发布，换版本号就是发新版本。

### 接口

| 用途 | 方法 | 地址 |
| --- | --- | --- |
| 创建新插件 | POST | `https://vlos.jlworld.net/api/v1/plugins` |
| 更新已有插件 | POST | `https://vlos.jlworld.net/api/v1/plugins/{插件ID}/releases` |
| 查看自己 + 插件 ID | GET | `https://vlos.jlworld.net/api/v1/me` |

可选查询参数（创建/更新通用）：`name`、`author`、`summary`、`tags`、`version`、`changelog`、`filename`；不传 `name`、`version` 时自动从 zip 里解析（zip 内 `plugin.json`）。

### 示例

创建新插件：

```bash
curl -X POST "https://vlos.jlworld.net/api/v1/plugins?name=插件名&tags=工具" \
  -H "Authorization: Bearer <令牌>" \
  -H "Content-Type: application/zip" \
  --data-binary "@插件.zip"
```

更新已有插件（换个版本号就是发新版本）：

```bash
curl -X POST "https://vlos.jlworld.net/api/v1/plugins/<插件ID>/releases?version=1.2.0&changelog=修复问题" \
  -H "Authorization: Bearer <令牌>" \
  -H "Content-Type: application/zip" \
  --data-binary "@插件.zip"
```

查看自己的插件 ID：

```bash
curl "https://vlos.jlworld.net/api/v1/me" -H "Authorization: Bearer <令牌>"
```

### 返回

- 成功：`{"ok":true,"plugin":{"id":"...","version":"..."},"msg":"..."}`
- 失败：`{"error":"原因"}`（HTTP 非 2xx）

> 令牌状态里的「最近使用」可以判断令牌是否被外部脚本用过；怀疑泄露时重新生成，旧令牌立即失效，记得同步更新 CI/发布脚本里的令牌。
