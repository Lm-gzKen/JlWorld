'use strict';
/** 登录范围：只有允许列表中的聚龙账户能登录，且移除后现有会话失效 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const jlw = await new MockJlw({ port: 0 }).start();
  jlw.users.set('other@test.local', {
    password: 'secret123',
    id: 'usr_other0002',
    name: '其他用户',
    bio: '另一个测试账户',
    avatar: '/uploads/avatars/usr_other0002.jpg',
  });

  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-auth-scope-'));
  const port = 18961 + Math.floor(Math.random() * 40);
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        auth: { allowed: [{ email: 'user@test.local', id: 'usr_test0001', name: '测试员', source: 'test' }] },
        log: { level: 'warn', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: {
      ...process.env,
      JLW_DATA_DIR: dataDir,
      JLW_ALLOW_LOCAL_SITE: '1',
      JLW_ALLOW_ALL_LOGIN: '0',
    },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };
  const login = (email) =>
    fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: 'secret123' }),
    });
  const cookieOf = (res) =>
    ((res.headers.getSetCookie ? res.headers.getSetCookie()[0] : res.headers.get('set-cookie')) || '').split(';')[0];

  try {
    const deadline = Date.now() + 20000;
    let ready = false;
    while (Date.now() < deadline) {
      try {
        if ((await fetch(base + '/health')).ok) {
          ready = true;
          break;
        }
      } catch {
        /* retry */
      }
      await sleep(200);
    }
    if (!ready) throw new Error('服务未启动');

    const unauth = await fetch(base + '/api/auth/scope');
    check(unauth.status === 401, '未登录不能读取登录范围');

    const allowed = await login('user@test.local');
    check(allowed.status === 200, '允许列表中的账户可以登录');
    const userCookie = cookieOf(allowed);

    const scope = await fetch(base + '/api/auth/scope', { headers: { Cookie: userCookie } }).then((r) => r.json());
    check(scope.ok === true && scope.count === 1 && scope.allowed[0].email === 'user@test.local', '登录范围返回允许账户');

    const denied = await login('other@test.local');
    const deniedBody = await denied.json();
    check(denied.status === 403 && deniedBody.code === 'NOT_ALLOWED', '密码正确但不在范围 -> 403');

    const badAdd = await fetch(base + '/api/auth/scope', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: userCookie },
      body: JSON.stringify({ email: 'not-an-email' }),
    });
    check(badAdd.status === 400, '拒绝格式错误的邮箱');

    const added = await fetch(base + '/api/auth/scope', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: userCookie },
      body: JSON.stringify({ email: 'other@test.local' }),
    }).then((r) => r.json());
    check(added.ok === true && added.count === 2, '面板可以添加登录账户');

    const other = await login('other@test.local');
    check(other.status === 200, '新加入的账户可以登录');
    const otherCookie = cookieOf(other);

    const removed = await fetch(base + '/api/auth/scope/' + encodeURIComponent('user@test.local'), {
      method: 'DELETE',
      headers: { Cookie: otherCookie },
    }).then((r) => r.json());
    check(removed.ok === true && removed.count === 1, '面板可以移除登录账户');

    const oldSession = await fetch(base + '/api/status', { headers: { Cookie: userCookie } });
    check(oldSession.status === 401, '被移除账户的旧会话失效');

    const last = await fetch(base + '/api/auth/scope/' + encodeURIComponent('other@test.local'), {
      method: 'DELETE',
      headers: { Cookie: otherCookie },
    });
    check(last.status === 400, '拒绝移除最后一个登录账户');
  } finally {
    child.kill();
    await sleep(200);
    await jlw.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
