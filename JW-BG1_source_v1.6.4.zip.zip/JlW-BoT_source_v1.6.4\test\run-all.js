'use strict';
/**
 * 主回归跑批：不需要 npm，直接用 runtime/node.exe 或系统 node 运行。
 *   node test/run-all.js
 */
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const tests = [
  ['核心自测', 'selftest.js'],
  ['回复引用/事件回复', 'reply-event-test.js'],
  ['稳定性/自愈', 'resilience-test.js'],
  ['定时重启/接口日志', 'restart-log-test.js'],
  ['重启端到端', 'restart-e2e.js'],
  ['重连冷却循环', 'reconnect-loop-test.js'],
  ['机器人/面板隔离', 'isolation-test.js'],
  ['单实例/重复运行', 'single-instance-test.js'],
  ['结束进程', 'stop-all-test.js'],
  ['插件回复闸门', 'reply-guard-test.js'],
  ['历史日志/消息', 'history-view-test.js'],
  ['消息预览渲染', 'message-preview-test.js'],
  ['SQLite 迁移', 'db-migrate-test.js'],
  ['存储方式切换', 'storage-engine-test.js'],
  ['网关端到端', 'gateway-e2e.js'],
  ['账户连接开关', 'account-modes-test.js'],
  ['账户站点自愈', 'config-site-repair.js'],
  ['登录范围', 'auth-scope-test.js'],
  ['插件更新/回滚', 'plugin-update-test.js'],
  ['插件市场代理', 'market-proxy-test.js'],
  ['更新解析/下载/覆盖', 'update-test.js'],
  ['更新接口', 'update-api-test.js'],
];

let failed = 0;
const started = Date.now();
for (const [name, file] of tests) {
  console.log(`\n===== ${name}（${file}）=====`);
  const r = spawnSync(process.execPath, [path.join(__dirname, file)], {
    cwd: ROOT,
    stdio: 'inherit',
    windowsHide: true,
  });
  if (r.error) {
    failed++;
    console.error(`[${name}] 启动失败：${r.error.message}`);
  } else if (r.status !== 0) {
    failed++;
    console.error(`[${name}] 失败，退出码 ${r.status}`);
  }
}
const seconds = ((Date.now() - started) / 1000).toFixed(1);
console.log(`\n===== 主回归结束：${tests.length - failed}/${tests.length} 个测试文件通过，用时 ${seconds}s =====`);
process.exit(failed ? 1 : 0);
