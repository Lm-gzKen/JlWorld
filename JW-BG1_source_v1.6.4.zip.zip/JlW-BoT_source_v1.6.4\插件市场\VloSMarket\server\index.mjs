// JlW-BoT 插件市场 —— 站点入口。零第三方依赖：node:http + node:sqlite。
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { loadConfig, ensureDirs, ROOT } from './config.mjs';
import { openDb, makeStore } from './db.mjs';
import { createJlw } from './jlw.mjs';
import { HttpError, readJson, sendJson, sendText, serveStatic, clientIp, parseCookies } from './http.mjs';
import * as httpHelpers from './http.mjs';
import { createSession, readSession, renewCookie, purgeExpired } from './session.mjs';
import registerAuth from './routes/auth.mjs';
import registerPlugins from './routes/plugins.mjs';
import registerApi from './routes/api.mjs';
import registerSocial from './routes/social.mjs';
import registerCommunity from './routes/community.mjs';
import registerAdmin from './routes/admin.mjs';
import registerSite from './routes/site.mjs';
import { isAdmin, isSuperAdmin } from './roles.mjs';

const cfg = loadConfig();
const dirs = ensureDirs(cfg);
const store = makeStore(openDb(path.join(dirs.data, 'market.db'), { dataDir: cfg.dataDir }));
const jlw = createJlw(cfg);
const STARTED_AT = Date.now();
const APP_VERSION = (() => {
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version || '0.0.0';
  } catch {
    return '0.0.0';
  }
})();

// ------------------------------------------------ 路由表
const routes = [];
function add(method, pattern, handler) {
  const keys = [];
  const rx = new RegExp(
    '^' + pattern.replace(/\/:([A-Za-z0-9_]+)/g, (_m, k) => (keys.push(k), '/([^/]+)')) + '$'
  );
  routes.push({ method, rx, keys, handler });
}
const router = {
  get: (p, h) => add('GET', p, h),
  post: (p, h) => add('POST', p, h),
  patch: (p, h) => add('PATCH', p, h),
  delete: (p, h) => add('DELETE', p, h),
};

registerAuth(router);
registerPlugins(router);
registerApi(router);
registerSocial(router);
registerCommunity(router);
registerAdmin(router);
registerSite(router);

// 版本握手：前端加载后会对照这个版本，服务端还是旧代码时直接提示「请重启」
router.get('/api/version', () => ({ version: APP_VERSION, startedAt: STARTED_AT }));

// ------------------------------------------------ 日志
const logDir = dirs.logs;
function log(...parts) {
  const line = `[${new Date().toISOString()}] ${parts.join(' ')}`;
  console.log(line);
  try {
    fs.appendFileSync(path.join(logDir, 'access.log'), line + '\n');
  } catch {}
}
fs.writeFileSync(path.join(logDir, 'server.log'), '');

// ------------------------------------------------ 请求处理
// 根路径 "/" 直接就是首页外壳；插件市场在 /market
// 已删除的「接口文档 / 管理后台」旧链接统一回首页，避免留下死链
const ALIASES = {
  '/': '/home.html',
  '/home': '/home.html',
  '/market': '/index.html',
  '/developer': '/developer.html',
  '/docs': '/home.html',
  '/admin': '/home.html',
};

async function handle(req, res) {
  const started = Date.now();
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const ip = clientIp(req, cfg.trustProxy);
  const pathname = url.pathname;

  // 安全响应头
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  // 允许被其他项目用 iframe 内嵌（含跨域）
  res.setHeader('Content-Security-Policy', "frame-ancestors *");

  // ---- Let's Encrypt HTTP-01 验证文件 ----
  // 宝塔申请/续签证书时，会把验证文件写到「站点根目录」的 .well-known/acme-challenge/。
  // 而本站的静态目录只有 public/，不单独放行这条的话 LE 拿到的是我们自己那个 404 页
  // （报错长这样：Invalid response from http://域名/.well-known/...: 404），证书签不下来。
  // 文件名白名单只允许字母数字下划线中划线，天然挡住路径穿越。
  const acme = /^\/\.well-known\/acme-challenge\/([A-Za-z0-9_-]{1,128})$/.exec(pathname);
  if (acme && (req.method === 'GET' || req.method === 'HEAD')) {
    const file = path.join(ROOT, '.well-known', 'acme-challenge', acme[1]);
    try {
      const body = fs.readFileSync(file);
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Length': body.length,
        'Cache-Control': 'no-store',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
      log(req.method, pathname, 200, ip, `${Date.now() - started}ms`);
      return;
    } catch {
      sendText(res, 404, 'not found', 'text/plain; charset=utf-8');
      return;
    }
  }

  // ---- http 入口自动跳 https ----
  // 只有当 publicUrl 已经写成 https（说明 https 入口真能用了）才生效，
  // 且必须放过 ACME 验证路径：首次签发时 https 还不存在，跳过去验证就断了。
  if (cfg.publicUrl && /^https:/i.test(cfg.publicUrl) && !req.socket.encrypted && !pathname.startsWith('/.well-known/')) {
    res.writeHead(301, { Location: String(cfg.publicUrl).replace(/\/+$/, '') + (req.url || '/') });
    res.end();
    return;
  }

  // ---- 静态资源 ----
  if (!pathname.startsWith('/api/')) {
    // 注意带上 url.search：静态资源要靠 ?v=内容指纹判断能不能强缓存，
    // 只传 pathname 的话查询串会被丢掉，指纹判断永远不成立。
    const target = ALIASES[pathname] || pathname + url.search;
    if (serveStatic(res, cfg.publicDir, target)) {
      log(req.method, pathname, 200, ip, `${Date.now() - started}ms`);
      return;
    }
    sendText(res, 404, '404 页面不存在', 'text/plain; charset=utf-8');
    return;
  }

  // ---- API ----
  const session = readSession(store, req, cfg);
  renewCookie(res, session, cfg); // 滑动续期：同步延长浏览器里的 Cookie
  const user = session ? store.get('SELECT * FROM users WHERE email = ?', session.email) : null;

  const c = {
    req,
    res,
    url,
    query: url.searchParams,
    params: {},
    cfg,
    store,
    jlw,
    dirs,
    ip,
    user,
    session,
    helpers: httpHelpers,
    // 挂在 HTTPS 后面时（publicUrl 以 https:// 开头）给会话 Cookie 加 Secure
    cookieSecure: /^https:/i.test(cfg.publicUrl || ''),
    cookieToken: () => parseCookies(req).vlos_sid || '',
    json: () => readJson(req, 512 * 1024),
    mustUser() {
      if (!user) throw new HttpError(401, '请先登录聚龙世界账户');
      return user;
    },
    isAdmin: isAdmin(store, user),
    mustAdmin() {
      if (!user) throw new HttpError(401, '请先登录聚龙世界账户');
      if (!isAdmin(store, user)) throw new HttpError(403, '仅管理员可操作');
      return user;
    },
    mustSuper() {
      if (!user) throw new HttpError(401, '请先登录聚龙世界账户');
      if (!isSuperAdmin(user)) throw new HttpError(403, '仅超级管理员可操作');
      return user;
    },
    newSession(email) {
      return createSession(store, email, req, cfg, ip);
    },
  };

  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.rx.exec(pathname);
    if (!m) continue;
    r.keys.forEach((k, i) => (c.params[k] = decodeURIComponent(m[i + 1])));
    const out = await r.handler(c);
    if (out === null || res.writableEnded) return;
    sendJson(res, 200, out);
    log(req.method, pathname, 200, ip, user ? user.email : '-', `${Date.now() - started}ms`);
    return;
  }

  sendJson(res, 404, { error: '接口不存在' });
}

// 两个入口（HTTP / HTTPS）共用同一个请求处理器
function onRequest(req, res) {
  // 下载大文件时不要因为客户端断连而崩溃
  req.on('error', () => {});
  res.on('error', () => {});
  handle(req, res).catch((err) => {
    const status = err instanceof HttpError ? err.status : 500;
    const msg = err instanceof HttpError ? err.message : '服务器内部错误';
    if (status >= 500) log('ERROR', req.method, req.url, err && err.stack ? err.stack : String(err));
    if (!res.writableEnded) {
      try {
        sendJson(res, status, { error: msg });
      } catch {
        res.destroy();
      }
    }
    if (status >= 400 && status !== 401) {
      log(req.method, req.url, status, msg);
    }
  });
}

// 服务器实例在下面「启动」段按 httpsOnly 决定用 http 还是 https 创建

// ------------------------------------------------ HTTPS（自带 TLS，不需要 Nginx）
// 为什么需要自己说 TLS：SakuraFrp 的 HTTPS 隧道是 SNI 透传，节点不解密，
// 本地端口必须能回应 TLS 握手。两种用法：
//   A（单端口，推荐）："httpsOnly": true + 证书  → 主端口(8300) 直接说 HTTPS，不跑 HTTP
//   B（双端口）：只填证书、不开 httpsOnly        → 主端口继续 HTTP，另开 httpsPort(8443)
let tlsServer = null; // 只有 B 方案会用到
let certMtime = 0;

const absOf = (p) => (path.isAbsolute(p) ? p : path.resolve(ROOT, p));
const hasCert = () => !!(cfg.certFile && cfg.keyFile);
const useHttpsOnly = () => !!(cfg.httpsOnly && hasCert());

function readCertPair() {
  return {
    cert: fs.readFileSync(absOf(cfg.certFile), 'utf8'),
    key: fs.readFileSync(absOf(cfg.keyFile), 'utf8'),
  };
}

function certStamp() {
  try {
    return fs.statSync(absOf(cfg.certFile)).mtimeMs + fs.statSync(absOf(cfg.keyFile)).mtimeMs;
  } catch {
    return 0;
  }
}

// 主入口：httpsOnly 且证书可读时直接上 HTTPS，否则回退成普通 HTTP（不让站点因为证书配错而整体不可用）
let server = null;
let mainScheme = 'http';
if (useHttpsOnly()) {
  try {
    server = https.createServer(readCertPair(), onRequest);
    mainScheme = 'https';
  } catch (err) {
    console.error(`  ⚠️  httpsOnly 已开启但证书加载失败：${err && err.message ? err.message : String(err)}`);
    console.error('     本次先按普通 HTTP 启动，避免站点直接不可用；请检查 certFile / keyFile');
  }
}
if (!server) {
  server = http.createServer(onRequest);
  mainScheme = 'http';
}

// B 方案：额外开一个 HTTPS 端口
function startExtraHttps() {
  if (!hasCert() || useHttpsOnly()) return;
  let srv;
  try {
    srv = https.createServer(readCertPair(), onRequest);
  } catch (err) {
    console.error(`  ⚠️  HTTPS 未启动：${err && err.message ? err.message : String(err)}`);
    console.error('     config.json 的 certFile / keyFile 填绝对路径，或相对站点根目录的路径');
    return;
  }
  tlsServer = srv;
  const port = Number(cfg.httpsPort) || 8443;
  srv.on('error', (err) => {
    console.error(`  ⚠️  HTTPS 端口 ${port} 启动失败：${err.code === 'EADDRINUSE' ? '端口被占用' : err.message}`);
  });
  srv.listen(port, cfg.host, () => {
    console.log(`  HTTPS 入口  : https://${cfg.host}:${port}   （证书 ${path.basename(absOf(cfg.certFile))}）`);
  });
}

// 证书续签后热加载：宝塔每 90 天换新文件，发现 mtime 变了就换，不用重启进程
function startCertWatch() {
  if (!hasCert()) return;
  certMtime = certStamp();
  setInterval(() => {
    const now = certStamp();
    if (!now || now === certMtime) return;
    try {
      const pair = readCertPair();
      if (tlsServer) tlsServer.setSecureContext(pair);
      if (mainScheme === 'https') server.setSecureContext(pair);
      certMtime = now;
      log('HTTPS 证书已热加载（续签后自动生效）');
    } catch (err) {
      log('HTTPS 证书热加载失败：' + err.message);
    }
  }, 10 * 60 * 1000).unref();
}

// ------------------------------------------------ 启动
const cleaned = purgeExpired(store);
if (cleaned) log(`清理过期会话 ${cleaned} 条`);

// 清理上次没发完的上传暂存包（超过 zipStageMin 分钟的直接删）
try {
  const maxAge = Math.max(10, Number(cfg.zipStageMin) || 120) * 60000;
  for (const name of fs.readdirSync(dirs.tmp)) {
    const file = path.join(dirs.tmp, name);
    try {
      if (Date.now() - fs.statSync(file).mtimeMs > maxAge) fs.unlinkSync(file);
    } catch {}
  }
} catch {}

server.listen(cfg.port, cfg.host, () => {
  const url = `${mainScheme}://${cfg.host === '0.0.0.0' ? '127.0.0.1' : cfg.host}:${cfg.port}`;
  console.log('');
  console.log(`  ${cfg.siteName}`);
  console.log(`  站点根目录  : ${ROOT}`);
  console.log(`  数据目录    : ${cfg.dataDir}`);
  console.log(`  本地地址    : ${url}`);
  console.log(`  聚龙世界    : ${cfg.officialSite}`);
  if (mainScheme === 'https') {
    console.log(`  HTTPS 入口  : 就是主端口（单端口模式），证书 ${path.basename(absOf(cfg.certFile))}`);
  }
  console.log(`  首页        : ${url}/home`);
  console.log(`  插件市场    : ${url}/market`);
  console.log(`  开发者中心  : ${url}/developer`);
  console.log('');
  console.log(`  账户接口    : ${cfg.vlosBase}`);
  console.log('  上传格式    : 仅 .zip，上传后自动解析插件名称与版本号');
  console.log('');
  console.log('  按 Ctrl+C 停止服务');
  console.log('');

  startExtraHttps(); // B 方案；A 方案不会输出
  startCertWatch();

  if (process.argv.includes('--open')) {
    const cmd = process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    const args = process.platform === 'win32' ? ['/c', 'start', '', url] : [url];
    try {
      spawn(cmd, args, { detached: true, stdio: 'ignore' }).unref();
    } catch {}
  }
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n端口 ${cfg.port} 已被占用。请修改 config.json 里的 port，或关掉占用该端口的程序。\n`);
  } else {
    console.error('服务启动失败：', err);
  }
  process.exit(1);
});

function shutdown() {
  console.log('\n正在停止服务…');
  try {
    if (tlsServer) tlsServer.close();
  } catch {}
  server.close(() => {
    try {
      store.close();
    } catch {}
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3000);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
