'use strict';
/**
 * 首次运行引导：登录范围为空时，在 CMD 控制台要求添加第一个聚龙账户。
 * 也支持无交互环境用 --allow-email 预置。
 */
const { normalizeEmail, isValidEmail } = require('./config');

async function ensureFirstAllowed(config, { allowEmail = '' } = {}) {
  if (allowEmail) {
    try {
      const entry = config.addAllowedAccount(allowEmail, { source: 'first-run-cli' });
      console.log(`\n✓ 已添加登录账户：${entry.email}`);
      console.log('  启动后请用该邮箱登录；登录后在左下角【登录范围】添加更多账户。\n');
      return { ok: true, added: entry };
    } catch (e) {
      console.error('添加失败：' + e.message);
      return { ok: false, error: e.message, printed: true };
    }
  }
  if (config.hasLoginAccounts()) return { ok: true, existing: true };
  if (process.env.JLW_ALLOW_ALL_LOGIN === '1') {
    console.warn('[WARN] JLW_ALLOW_ALL_LOGIN=1：已临时关闭登录范围限制（仅测试/应急使用）');
    return { ok: true, bypass: true };
  }

  const file = config.file;
  const help = [
    '',
    '  首次运行需要先添加一个允许登录的聚龙账户。',
    '  登录范围决定哪些聚龙账户可以进入后台；未添加的账户会被拒绝。',
    '',
    '  当前没有交互式控制台，无法询问邮箱。请任选一种方式：',
    '    1) 在有控制台的窗口运行 启动机器人.cmd 或 node src/index.js',
    '    2) node src/index.js --allow-email you@example.com',
    `    3) 手动编辑 ${file} 的 auth.allowed`,
    '',
  ].join('\n');

  if (!process.stdin.isTTY) {
    return { ok: false, error: 'NO_TTY', message: help, printed: false };
  }

  const readline = require('readline/promises');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.on('SIGINT', () => {
    console.log('\n已取消。');
    rl.close();
    process.exit(130);
  });

  console.log('\n==============================================================');
  console.log(' 首次运行：设置允许登录后台的聚龙账户');
  console.log('==============================================================');
  console.log(' 只有列表里的聚龙账户可以登录；未添加的账户会被拒绝。');
  console.log(' 这里填聚龙世界注册邮箱。\n');

  try {
    let email = '';
    for (;;) {
      const first = (await rl.question('聚龙账户邮箱：')).trim();
      if (!isValidEmail(first)) {
        console.log('  邮箱格式不正确，请重新输入。\n');
        continue;
      }
      const again = (await rl.question(`再次输入确认 ${normalizeEmail(first)}：`)).trim();
      if (normalizeEmail(again) !== normalizeEmail(first)) {
        console.log('  两次输入不一致，请重新输入。\n');
        continue;
      }
      email = normalizeEmail(first);
      break;
    }
    const entry = config.addAllowedAccount(email, { source: 'first-run-cli' });
    console.log(`\n✓ 已添加第一个登录账户：${entry.email}`);
    console.log('  启动后请用该邮箱登录；登录后在左下角【登录范围】添加更多账户。\n');
    return { ok: true, added: entry };
  } catch (e) {
    console.error('\n首次运行设置失败：' + e.message);
    return { ok: false, error: e.message, printed: true };
  } finally {
    rl.close();
  }
}

module.exports = { ensureFirstAllowed };
