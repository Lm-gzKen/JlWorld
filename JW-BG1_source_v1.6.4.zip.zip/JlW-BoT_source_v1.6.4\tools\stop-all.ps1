﻿#requires -Version 5.1
# 结束进程：一次性结束本项目所有相关进程
#   - 启动器（powershell tools\start-panel.ps1，含自动重启）
#   - 主进程 node src\index.js（前台 / -Background 隐藏都算）
#   - 插件子进程（DLL 宿主 / EXE，随父进程 taskkill /T 一起结束）
#   - 面板端口占用者（兜底）
# 同时写 ~JlWBoT/stop.flag，阻止启动器在进程退出后自动重启；清 run.pid。
# 用法：结束进程.cmd   或   powershell -File tools\stop-all.ps1 [-ProjectOnly] [-Quiet] [-Port 8686]

param([switch]$Quiet, [switch]$ProjectOnly, [int]$Port = 0)

$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
$rootNorm = $root.TrimEnd('\')
$killed = @()
$selfPid = $PID

function Write-Line($text, $color = 'Gray') {
  if ($Quiet) { return }
  Write-Host $text -ForegroundColor $color
}

function Kill-Tree([int]$procId, [string]$label) {
  try {
    & taskkill /PID $procId /T /F 2>$null | Out-Null
    $script:killed += [pscustomobject]@{ pid = $procId; label = $label }
    return $true
  } catch {
    return $false
  }
}

# 0) 先立“停止标记”：启动器看到它就不会再自动拉起新进程
$flagFile = Join-Path $root '~JlWBoT\stop.flag'
try {
  New-Item -ItemType Directory -Force -Path (Split-Path $flagFile) | Out-Null
  Set-Content -LiteralPath $flagFile -Value ('stopped at ' + (Get-Date).ToString('s')) -Encoding UTF8
} catch { }

# 1) 面板端口（config.json 可能是 UTF-8 无 BOM）
if ($Port -le 0) {
  $cfgPath = Join-Path $root '~JlWBoT\config.json'
  if (Test-Path -LiteralPath $cfgPath) {
    try {
      $cfg = [System.IO.File]::ReadAllText($cfgPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
      if ($cfg.server -and $cfg.server.port) { $Port = [int]$cfg.server.port }
    } catch { }
  }
}

# 2) 多轮扫描：先杀启动器（否则它会重启 node），再杀 node；最后按端口兜底
for ($pass = 1; $pass -le 4; $pass++) {
  $procs = @()
  try { $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) } catch { }

  $found = 0
  foreach ($p in $procs) {
    $name = [string]$p.Name
    $cl = [string]$p.CommandLine
    if (-not $cl) { continue }
    if ($p.ProcessId -eq $selfPid) { continue }
    if ($cl -match 'stop-all\.ps1|stop-panel\.ps1|force-stop\.ps1|结束进程\.cmd|停止机器人\.cmd|强制关闭\.cmd') { continue }

    $hasRoot = $cl.Contains($rootNorm)
    $isNode = $name -match '^node(\.exe)?$'
    $isLauncher = $name -match '^(powershell|pwsh)(\.exe)?$' -and $cl -match 'start-panel\.ps1'

    $target = $false
    if ($isLauncher) {
      $target = $hasRoot -or (-not $ProjectOnly)
    } elseif ($isNode) {
      $target = $hasRoot -or ((-not $ProjectOnly) -and ($cl -match 'src[\\/]index\.js'))
    }
    if (-not $target) { continue }

    $snippet = $cl.Substring(0, [Math]::Min(90, $cl.Length))
    if (Kill-Tree $p.ProcessId $snippet) { $found++ }
  }

  # 端口兜底：路径不同的副本也能清掉
  if ($Port -gt 0) {
    try {
      Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | ForEach-Object {
        $owner = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        if ($owner -and $owner.ProcessName -match '^node$') {
          if (Kill-Tree $owner.Id ('port ' + $Port + ' -> PID ' + $owner.Id)) { $found++ }
        }
      }
    } catch { }
  }

  Start-Sleep -Milliseconds 500
  if ($found -eq 0) { break }
}

# 3) 清运行锁（stop.flag 保留，下次 启动机器人.cmd 会删）
$lockFile = Join-Path $root '~JlWBoT\run.pid'
if (Test-Path -LiteralPath $lockFile) {
  Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
}

# 4) 确认端口
$stillListening = $false
if ($Port -gt 0) {
  try { $stillListening = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue).Count -gt 0 } catch { }
}

if ($Quiet) { exit 0 }

Write-Line ''
Write-Line '  ==============================================================' 'DarkCyan'
Write-Line '   JlWBoT 结束进程' 'White'
Write-Line '  ==============================================================' 'DarkCyan'
Write-Line ''
if ($killed.Count -gt 0) {
  foreach ($k in ($killed | Sort-Object pid -Unique)) {
    Write-Line ('  已结束 PID ' + $k.pid + ' · ' + $k.label) 'Green'
  }
} else {
  Write-Line '  没有发现正在运行的 JlWBoT 进程' 'DarkGray'
}
if ($Port -gt 0) {
  if ($stillListening) {
    Write-Line ('  [警告] 端口 ' + $Port + ' 仍被占用（可能不是 node）：用 netstat -ano | findstr ' + $Port + ' 查') 'Yellow'
  } else {
    Write-Line ('  端口 ' + $Port + ' 已释放') 'DarkGray'
  }
}
Write-Line ('  已写入停止标记：' + $flagFile) 'DarkGray'
Write-Line '  再运行 启动机器人.cmd 会清除标记并正常启动。' 'DarkGray'
Write-Line ''
exit 0
