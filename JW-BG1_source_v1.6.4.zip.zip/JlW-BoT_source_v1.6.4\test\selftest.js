'use strict';
/**
 * 自测脚本：node test/selftest.js
 * 覆盖 Ed25519 官方样例、WS 帧、事件归一化、插件分发、面板 API、插件拉取/动作
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');
const seedTestPlugins = require('./seed-plugins');

const ROOT = path.resolve(__dirname, '..');
const results = [];

async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    results.push({ name, ok: true, ms: Date.now() - t0 });
    console.log(`  \x1b[32m✓\x1b[0m ${name} \x1b[90m${Date.now() - t0}ms\x1b[0m`);
  } catch (e) {
    results.push({ name, ok: false, error: e.message, ms: Date.now() - t0 });
    console.log(`  \x1b[31m✗\x1b[0m ${name}\n    ${e.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* 测试用最小 ZIP 生成器（store，不压缩） */
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function makeZip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const data = Buffer.isBuffer(content) ? content : Buffer.from(content);
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);
    lh.writeUInt16LE(0x800, 6);
    lh.writeUInt16LE(0, 8);
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(data.length, 18);
    lh.writeUInt32LE(data.length, 22);
    lh.writeUInt16LE(nameBuf.length, 26);
    const local = Buffer.concat([lh, nameBuf, data]);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(20, 4);
    ch.writeUInt16LE(20, 6);
    ch.writeUInt16LE(0x800, 8);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(data.length, 20);
    ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(nameBuf.length, 28);
    ch.writeUInt32LE(offset, 42);
    centrals.push(Buffer.concat([ch, nameBuf]));
    locals.push(local);
    offset += local.length;
  }
  const cd = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(Object.keys(files).length, 8);
  eocd.writeUInt16LE(Object.keys(files).length, 10);
  eocd.writeUInt32LE(cd.length, 12);
  eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, eocd]);
}

async function main() {
  console.log('\nJlWBoT 自测\n');

  /* ---------------- 单元 ---------------- */
  await test('工具函数：深合并 / ID / 时间', () => {
    const U = require('../src/core/util');
    const merged = U.deepMerge({ a: 1, b: { c: 2, d: 3 } }, { b: { c: 9 }, e: 4 });
    assert.deepEqual(merged, { a: 1, b: { c: 9, d: 3 }, e: 4 });
    assert.equal(U.uid(8).length, 8);
    assert.match(U.nowIso(), /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}\+08:00$/);
    assert.equal(U.clamp(15, 0, 10), 10);
  });

  await test('WebHook：官方 Ed25519 样例签名一致', () => {
    const W = require('../src/core/webhook');
    const secret = 'DG5g3B4j9X2KOErG';
    const sig = W.sign(secret, '1725442341' + 'Arq0D5A61EgUu4OxUvOp');
    assert.equal(
      sig,
      '87befc99c42c651b3aac0278e71ada338433ae26fcb24307bdc5ad38c1adc2d01bcfcadc0842edac85e85205028a1132afe09280305f13aa6909ffc2d652c706',
    );
    assert.equal(W.verify(secret, '1725442341Arq0D5A61EgUu4OxUvOp', sig), true);
    assert.equal(W.verify(secret, 'tampered', sig), false);
    const ts = '1725442341';
    const body = JSON.stringify({ d: { plain_token: 'Arq0D5A61EgUu4OxUvOp', event_ts: ts }, op: 13 });
    const reqSig = W.sign(secret, ts + body);
    const vr = W.verifyRequest({
      headers: { 'x-signature-ed25519': reqSig, 'x-signature-timestamp': ts },
      rawBody: body,
      secret,
      maxSkewMs: 0,
    });
    assert.equal(vr.ok, true);
    const resp = W.validationResponse(secret, { plain_token: 'Arq0D5A61EgUu4OxUvOp', event_ts: '1725442341' });
    assert.equal(resp.signature, sig);
  });

  await test('WebHook：拒绝错误签名与缺头', () => {
    const W = require('../src/core/webhook');
    const r1 = W.verifyRequest({ headers: {}, rawBody: '{}', secret: 'abc' });
    assert.equal(r1.ok, false);
    const r2 = W.verifyRequest({
      headers: { 'x-signature-ed25519': '00'.repeat(64), 'x-signature-timestamp': String(Math.floor(Date.now() / 1000)) },
      rawBody: '{}',
      secret: 'DG5g3B4j9X2KOErG',
    });
    assert.equal(r2.ok, false);
  });

  await test('事件归一化：群聊 / 单聊 / 频道 / 命令解析', () => {
    const Bot = require('../src/core/bot');
    const U = require('../src/core/util');
    const config = {
      get: (k, d) => (k === 'bot.prefix' ? '/' : d),
      secret: () => '',
    };
    const fakeLogger = { child: () => ({ info() {}, warn() {}, error() {}, debug() {} }) };
    const bot = Object.create(Bot.prototype);
    bot.config = config;
    const g = bot.normalize('GROUP_AT_MESSAGE_CREATE', {
      id: 'M1',
      content: ' /天气 北京',
      group_openid: 'G1',
      author: { id: 'U1', member_openid: 'M1', username: '小明', member_role: 'member' },
      timestamp: '2026-01-01T00:00:00+08:00',
    });
    assert.equal(g.kind, 'group');
    assert.equal(g.group_openid, 'G1');
    assert.equal(g.cleanContent.trim(), '/天气 北京');
    assert.equal(g.command.name, '天气');
    assert.deepEqual(g.command.args, ['北京']);

    const c = bot.normalize('C2C_MESSAGE_CREATE', {
      id: 'M2',
      content: '你好',
      author: { id: 'U2', user_openid: 'UO2', username: '小红' },
    });
    assert.equal(c.kind, 'c2c');
    assert.equal(c.user_openid, 'UO2');

    const ch = bot.normalize('AT_MESSAGE_CREATE', {
      id: 'M3',
      content: '<@!123> 你好',
      channel_id: 'C1',
      guild_id: 'GD1',
      author: { id: 'U3', username: '阿三' },
    });
    assert.equal(ch.kind, 'channel');
    assert.equal(ch.cleanContent, '你好');

    assert.equal(Bot.parseCommand('/echo abc', '/').name, 'echo');
    assert.equal(Bot.parseCommand('echo abc', '/').matched, false);
    assert.equal(Bot.substitutePath('/v2/groups/{group_openid}/messages', { group_openid: 'a b' }), '/v2/groups/a%20b/messages');
    void U;
  });

  await test('插件结果归一化', () => {
    const P = require('../src/core/plugins');
    const r = P.normalizeResult({ reply: 'hi', actions: [{ action: 'log', message: 'x' }], stop: true });
    assert.equal(r.replies.length, 1);
    assert.equal(r.actions.length, 1);
    assert.equal(r.stop, true);
    const r2 = P.normalizeResult(['a', { replies: ['b', { type: 'markdown', content: 'c' }] }]);
    assert.equal(r2.replies.length, 3);
    assert.equal(P.normalizeResult(null).replies.length, 0);
  });

  await test('错误分类：IP 白名单不刷新 token', async () => {
    const http = require('http');
    const QQApi = require('../src/core/api');
    const Gateway = require('../src/core/gateway');
    assert.equal(
      QQApi.isIpWhitelistError(401, { code: 11298, err_code: 40023002, message: '接口访问源IP不在白名单' }),
      true,
    );
    assert.equal(QQApi.isIpWhitelistError(400, { code: 100017, message: '接口调用超过频率限制' }), false);
    assert.equal(
      Gateway.isIpWhitelistResult({ status: 401, code: 11298, data: { err_code: 40023002, message: '接口访问源IP不在白名单' } }),
      true,
    );
    assert.equal(
      Gateway.isRateLimitResult({ status: 400, code: 100017, data: { err_code: 40023001, message: '接口调用超过频率限制' } }),
      true,
    );

    const srv = http.createServer((req, res) => {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ code: 11298, err_code: 40023002, message: '接口访问源IP不在白名单' }));
    });
    await new Promise((r) => srv.listen(0, '127.0.0.1', r));
    let refreshes = 0;
    const api = new QQApi({
      config: {
        get: (k, d) => (k === 'bot.apiBase' ? 'http://127.0.0.1:' + srv.address().port : d),
        secret: () => 'secret',
      },
      token: {
        get: async () => 't',
        header: () => 'QQBot t',
        invalidate: () => refreshes++,
      },
      logger: { child: () => ({ warn() {}, error() {}, info() {}, child() { return this; } }) },
      accountId: 'test',
    });
    const r = await api.get('/gateway');
    assert.equal(r.ok, false);
    assert.equal(r.fatal, true);
    assert.equal(r.code, 11298);
    assert.equal(refreshes, 0, 'IP 白名单错误不应刷新 token');
    await new Promise((r) => srv.close(r));
  });

  await test('接口注册表：路径完整且方法合法', () => {
    const eps = require('../src/core/endpoints');
    assert.ok(eps.length >= 40, '接口数量不足：' + eps.length);
    const keys = new Set();
    for (const e of eps) {
      assert.ok(e.key && e.group && e.name && e.path.startsWith('/'), '接口字段缺失：' + JSON.stringify(e.key));
      assert.ok(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(e.method), '非法方法：' + e.key);
      assert.ok(!keys.has(e.key), '重复 key：' + e.key);
      keys.add(e.key);
      for (const p of e.params || []) assert.ok(e.path.includes('{' + p.name + '}'), `路径缺少参数 ${p.name}：${e.key}`);
    }
  });

  await test('JsonlWriter：写入与读取', async () => {
    const U = require('../src/core/util');
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-jsonl-'));
    const w = new U.JsonlWriter(dir, 'test', { maxFileMB: 1, keepDays: 1 });
    w.write({ a: 1 });
    w.write({ a: 2 });
    await new Promise((r) => w._stream.end(r));
    w.close();
    const files = U.listJsonl(dir, 'test');
    assert.equal(files.length, 1);
    const rows = U.tailJsonl(files[0], 10);
    assert.equal(rows.length, 2);
    assert.equal(rows[1].a, 2);
    fs.rmSync(dir, { recursive: true, force: true });
  });

  /* ---------------- 集成 ---------------- */
  const port = 19091 + Math.floor(Math.random() * 200);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-e2e-'));
  seedTestPlugins(dataDir, ROOT);
  const secret = 'DG5g3B4j9X2KOErG';
  const base = `http://127.0.0.1:${port}`;
  const jlwMock = await new MockJlw({ port: 0 }).start();
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        bot: { appId: '1234567890', clientSecret: secret, mode: 'webhook', sandbox: false },
        webhook: { path: '/qqbot/webhook', verifySignature: true, ackOp12: true },
        plugins: { enabled: true, defaultTimeoutMs: 4000 },
        log: { level: 'info', console: false },
      },
      null,
      2,
    ),
  );

  let child = null;
  const auth = { 'Content-Type': 'application/json' };

  await test('集成：启动服务并健康检查', async () => {
    child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
      cwd: ROOT,
      env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    child.stderr.on('data', (d) => {
      const s = String(d);
      if (/Error|错误/.test(s)) console.log('    [child]', s.trim().slice(0, 300));
    });
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      try {
        const r = await fetch(base + '/health');
        if (r.ok) return;
      } catch {
        /* retry */
      }
      await sleep(250);
    }
    throw new Error('服务未在 20 秒内启动');
  });

  await test('集成：聚龙账户登录与面板会话', async () => {
    const bad = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'wrong-password' }),
    });
    assert.equal(bad.status, 401);
    assert.match((await bad.json()).error, /密码/);

    const ok = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    assert.equal(ok.status, 200);
    const data = await ok.json();
    assert.equal(data.user.name, '测试员');
    assert.equal(data.user.email, 'user@test.local');
    const setCookie = (ok.headers.getSetCookie ? ok.headers.getSetCookie()[0] : ok.headers.get('set-cookie')) || '';
    assert.ok(setCookie.includes('jlw_sid='), '未下发会话 Cookie');
    auth.Cookie = setCookie.split(';')[0];

    const sess = await fetch(base + '/api/session', { headers: { Cookie: auth.Cookie } }).then((x) => x.json());
    assert.equal(sess.loggedIn, true);
    assert.equal(sess.user.name, '测试员');
    assert.equal(sess.site.baseUrl, jlwMock.base);
  });

  await test('集成：注册 / 找回密码流程', async () => {
    const email = 'newbie@test.local';
    const sc = await fetch(base + '/api/jlw/send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, purpose: 'register' }),
    }).then((x) => x.json());
    assert.equal(sc.ok, true);

    const bad = await fetch(base + '/api/jlw/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code: '000000', password: 'pass123', name: '新用户' }),
    });
    assert.equal(bad.status, 400);

    const reg = await fetch(base + '/api/jlw/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code: '123456', password: 'pass123', name: '新用户' }),
    });
    assert.equal(reg.status, 200);
    const regData = await reg.json();
    assert.equal(regData.user.name, '新用户');
    const cookie = ((reg.headers.getSetCookie ? reg.headers.getSetCookie()[0] : reg.headers.get('set-cookie')) || '').split(';')[0];
    assert.ok(cookie.includes('jlw_sid='));
    const me = await fetch(base + '/api/me', { headers: { Cookie: cookie } }).then((x) => x.json());
    assert.equal(me.user.email, email);

    await fetch(base + '/api/jlw/send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, purpose: 'reset' }),
    });
    const reset = await fetch(base + '/api/jlw/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code: '123456', password: 'newpass456' }),
    });
    assert.equal(reset.status, 200);
    const login2 = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: 'newpass456' }),
    });
    assert.equal(login2.status, 200);
    await fetch(base + '/api/logout', { method: 'POST', headers: { Cookie: cookie }, body: '{}' });
  });

  await test('集成：面板鉴权与状态接口', async () => {
    const bad = await fetch(base + '/api/status');
    assert.equal(bad.status, 401);
    const r = await fetch(base + '/api/status', { headers: auth });
    const data = await r.json();
    assert.equal(data.ok, true);
    assert.equal(data.bot.mode, 'webhook');
    assert.ok(data.server.dataDir.toLowerCase().includes('jlw-e2e'));
    assert.ok(data.plugins.count >= 3, '插件数量异常：' + data.plugins.count);
  });

  await test('集成：注入事件触发 JS 插件', async () => {
    const r = await fetch(base + '/api/events/inject', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ t: 'GROUP_AT_MESSAGE_CREATE', d: { content: '/ping', group_openid: 'G_E2E' } }),
    }).then((x) => x.json());
    assert.equal(r.ok, true);
    await sleep(700);
    const pl = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
    const echo = pl.plugins.find((p) => p.id === 'echo');
    assert.ok(echo.stats.dispatched >= 1, 'echo 未被分发');
    const ev = await fetch(base + '/api/events?limit=5', { headers: auth }).then((x) => x.json());
    assert.ok(ev.events.some((e) => e.message?.cleanContent?.includes('/ping')));
  });

  await test('集成：WebHook 验证握手（Ed25519 签名）', async () => {
    const W = require('../src/core/webhook');
    const d = { plain_token: 'Arq0D5A61EgUu4OxUvOp', event_ts: '1725442341' };
    const body = JSON.stringify({ d, op: 13 });
    // 官方回调验证请求不带签名头，应答由机器人签名
    const r = await fetch(base + '/qqbot/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    const data = await r.json();
    assert.equal(r.status, 200);
    assert.equal(data.plain_token, d.plain_token);
    assert.equal(data.signature, W.sign(secret, d.event_ts + d.plain_token));

    const bad = await fetch(base + '/qqbot/webhook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Signature-Ed25519': 'ab'.repeat(64), 'X-Signature-Timestamp': String(Math.floor(Date.now() / 1000)) },
      body: JSON.stringify({ id: 'x', op: 0, t: 'C2C_MESSAGE_CREATE', d: {} }),
    });
    assert.equal(bad.status, 401);
  });

  await test('集成：WebHook 事件 ACK 并进入总线', async () => {
    const W = require('../src/core/webhook');
    const ts = String(Math.floor(Date.now() / 1000));
    const body = JSON.stringify({
      id: 'WH_EVT_1',
      op: 0,
      t: 'C2C_MESSAGE_CREATE',
      d: {
        id: 'WH_MSG_1',
        content: '/帮助',
        author: { id: 'U_WH', user_openid: 'UO_WH', username: '回调用户' },
        timestamp: new Date().toISOString(),
      },
    });
    const sig = W.sign(secret, ts + body);
    const r = await fetch(base + '/qqbot/webhook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Signature-Ed25519': sig, 'X-Signature-Timestamp': ts },
      body,
    });
    const data = await r.json();
    assert.equal(r.status, 200);
    assert.equal(data.op, 12);
    await sleep(500);
    const ev = await fetch(base + '/api/events?limit=10', { headers: auth }).then((x) => x.json());
    assert.ok(ev.events.some((e) => e.name === 'C2C_MESSAGE_CREATE'), 'WebHook 事件未进入总线');
  });

  await test('集成：插件令牌 / 长轮询 / 动作回调', async () => {
    const info = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
    const ptoken = info.info.token;
    assert.ok(ptoken.length >= 20);
    // 插件是启动后异步加载的：先等 el-sample 进入注册表
    let elSample = null;
    for (let i = 0; i < 50; i++) {
      const list = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
      elSample = (list.plugins || []).find((p) => p.id === 'el-sample');
      if (elSample && elSample.enabled && elSample.status === 'running') break;
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.ok(elSample && elSample.enabled, 'el-sample 未加载');
    // 直接走面板的「测试事件」入口，把事件放进 pull 队列（网关分发由 gateway-e2e 覆盖）
    const queued = await fetch(base + '/api/plugins/el-sample/test', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ t: 'GROUP_AT_MESSAGE_CREATE', content: '天气 上海', group_openid: 'G_PULL' }),
    }).then((x) => x.json());
    assert.ok(queued.ok && queued.result?.queued, '测试事件未入队：' + JSON.stringify(queued));
    const pull = await fetch(`${base}/plugin-api/v1/pull?plugin=el-sample&timeout=3000&token=${ptoken}`).then((x) => x.json());
    assert.ok(pull.events && pull.events.length >= 1, '拉取为空：' + JSON.stringify(pull));
    assert.ok(pull.events[0].message.cleanContent.includes('天气'));
    const act = await fetch(base + '/plugin-api/v1/action', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + ptoken, 'Content-Type': 'application/json' },
      body: JSON.stringify({ plugin: 'el-sample', actions: [{ action: 'log', level: 'info', message: 'selftest-action' }] }),
    }).then((x) => x.json());
    assert.equal(act.ok, true);
    const unauth = await fetch(`${base}/plugin-api/v1/pull?plugin=el-sample&timeout=1000`).then((x) => x.status);
    assert.equal(unauth, 401);
  });

  await test('集成：接口调试透传（未配置凭证时的错误归一化）', async () => {
    const r = await fetch(base + '/api/call', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ key: 'get_bot_me', params: {}, query: {}, body: {} }),
    }).then((x) => x.json());
    assert.equal(r.ok, false);
    assert.ok(['TOKEN_ERROR', 'TIMEOUT', 'NETWORK_ERROR'].includes(r.code), '异常错误码：' + r.code);
  });

  await test('集成：新建插件只填元数据（不需要令牌）', async () => {
    const created = await fetch(base + '/api/plugins/create', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        name: '测试天气',
        version: '2.3.4',
        author: '测试作者',
        description: '只填名称/版本/作者/介绍',
      }),
    }).then((x) => x.json());
    assert.equal(created.ok, true);
    assert.ok(created.id, '未生成插件 ID');
    assert.ok(fs.existsSync(path.join(created.dir, 'plugin.json')), 'plugin.json 未写入');
    const manifest = JSON.parse(fs.readFileSync(path.join(created.dir, 'plugin.json'), 'utf8'));
    assert.equal(manifest.name, '测试天气');
    assert.equal(manifest.version, '2.3.4');
    assert.equal(manifest.author, '测试作者');
    assert.equal(manifest.description, '只填名称/版本/作者/介绍');
    assert.equal(manifest.type, 'pull');
    assert.ok(!('token' in manifest), '插件元数据不应包含令牌');
    const list = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
    const item = list.plugins.find((p) => p.id === created.id);
    assert.ok(item, '新建插件未出现在列表');
    assert.equal(item.version, '2.3.4');
    assert.equal(item.author, '测试作者');
  });

  await test('集成：导入 JS 插件并删除', async () => {
    const code = "module.exports = { async onEvent() { return null; } };\n";
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'js',
        files: [{ name: 'import-js-test.js', path: 'import-js-test.js', data: Buffer.from(code).toString('base64') }],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    assert.equal(imported.id, 'import-js-test');
    assert.ok(fs.existsSync(path.join(imported.dir, 'index.js')));
    const manifest = JSON.parse(fs.readFileSync(path.join(imported.dir, 'plugin.json'), 'utf8'));
    assert.equal(manifest.type, 'js');
    assert.equal(manifest.entry, 'index.js');

    const del = await fetch(base + '/api/plugins/' + imported.id, { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
    assert.ok(!fs.existsSync(imported.dir), '删除后目录仍存在');
    const list = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
    assert.ok(!list.plugins.some((p) => p.id === imported.id), '删除后仍在列表');
  });

  await test('集成：导入 ZIP 插件（含中文文件名）并删除', async () => {
    const manifest = {
      id: 'zip-import-test',
      name: 'ZIP 导入测试',
      version: '1.2.3',
      author: '测试作者',
      type: 'js',
      entry: 'index.js',
      events: ['GROUP_AT_MESSAGE_CREATE'],
    };
    const zip = makeZip({
      'zip-import-test/plugin.json': JSON.stringify(manifest, null, 2),
      'zip-import-test/index.js': "module.exports = { async onEvent() { return null; } };\n",
      'zip-import-test/说明.txt': '中文文件',
    });
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'zip',
        files: [{ name: 'zip-import-test.zip', path: 'zip-import-test.zip', data: zip.toString('base64') }],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    assert.equal(imported.id, 'zip-import-test');
    assert.ok(fs.existsSync(path.join(imported.dir, 'index.js')));
    assert.ok(fs.existsSync(path.join(imported.dir, '说明.txt')));
    assert.equal(JSON.parse(fs.readFileSync(path.join(imported.dir, 'plugin.json'), 'utf8')).version, '1.2.3');

    const del = await fetch(base + '/api/plugins/' + imported.id, { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
    assert.ok(!fs.existsSync(imported.dir));
  });

  await test('集成：导入文件夹插件并删除', async () => {
    const manifest = {
      id: 'folder-import-test',
      name: '文件夹导入测试',
      version: '0.2.0',
      author: '测试作者',
      type: 'js',
      entry: 'index.js',
      events: ['GROUP_AT_MESSAGE_CREATE'],
    };
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'folder',
        files: [
          { name: 'plugin.json', path: 'folder-import-test/plugin.json', data: Buffer.from(JSON.stringify(manifest)).toString('base64') },
          { name: 'index.js', path: 'folder-import-test/index.js', data: Buffer.from("module.exports = {};\n").toString('base64') },
        ],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    assert.equal(imported.id, 'folder-import-test');
    assert.ok(fs.existsSync(path.join(imported.dir, 'index.js')));
    const del = await fetch(base + '/api/plugins/' + imported.id, { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
    assert.ok(!fs.existsSync(imported.dir));
  });

  await test('集成：重载失败会返回具体错误', async () => {
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'js',
        files: [
          {
            name: 'invalid-reload-test.js',
            path: 'invalid-reload-test.js',
            data: Buffer.from('this is not valid javascript\n').toString('base64'),
          },
        ],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    const reload = await fetch(base + '/api/plugins/' + imported.id + '/reload', {
      method: 'POST',
      headers: auth,
      body: '{}',
    });
    assert.equal(reload.status, 400, '加载失败时应返回 400');
    const body = await reload.json();
    assert.equal(body.ok, false);
    assert.ok(body.error && body.error.length > 0, '缺少失败原因');
    const del = await fetch(base + '/api/plugins/' + imported.id, { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
  });

  await test('集成：插件 API 文档保存与沙箱访问', async () => {
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'js',
        files: [
          {
            name: 'api-doc-test.js',
            path: 'api-doc-test.js',
            data: Buffer.from("module.exports = {};\n").toString('base64'),
          },
        ],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    const html = '<!doctype html><html><body><h1>API DOC TEST</h1></body></html>';
    const saved = await fetch(base + '/api/plugins/api-doc-test/file', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ name: 'api.html', content: html }),
    }).then((x) => x.json());
    assert.equal(saved.ok, true);
    const doc = await fetch(base + '/api/plugins/api-doc-test/api-doc', { headers: auth });
    assert.equal(doc.status, 200);
    assert.match(doc.headers.get('content-security-policy') || '', /sandbox/);
    assert.ok((await doc.text()).includes('API DOC TEST'));
    const list = await fetch(base + '/api/plugins', { headers: auth }).then((x) => x.json());
    assert.equal(list.plugins.find((p) => p.id === 'api-doc-test')?.hasApiDoc, true);
    const del = await fetch(base + '/api/plugins/api-doc-test', { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
  });

  await test('集成：插件设置页与 config 保存', async () => {
    const imported = await fetch(base + '/api/plugins/import', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({
        type: 'js',
        files: [
          {
            name: 'settings-doc-test.js',
            path: 'settings-doc-test.js',
            data: Buffer.from("module.exports = {};\n").toString('base64'),
          },
        ],
      }),
    }).then((x) => x.json());
    assert.equal(imported.ok, true, imported.error);
    const html = '<!doctype html><html><body><h1>SETTINGS TEST</h1></body></html>';
    const saved = await fetch(base + '/api/plugins/settings-doc-test/file', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ name: 'settings.html', content: html }),
    }).then((x) => x.json());
    assert.equal(saved.ok, true);
    const page = await fetch(base + '/api/plugins/settings-doc-test/settings', { headers: auth });
    assert.equal(page.status, 200);
    assert.match(page.headers.get('content-security-policy') || '', /sandbox/);
    const cfg = await fetch(base + '/api/plugins/settings-doc-test/config', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ config: { value: 'hello', interval: 60 } }),
    }).then((x) => x.json());
    assert.equal(cfg.ok, true);
    const manifest = JSON.parse(
      fs.readFileSync(path.join(dataDir, 'plugins', 'settings-doc-test', 'plugin.json'), 'utf8'),
    );
    assert.deepEqual(manifest.config, { value: 'hello', interval: 60 });
    const del = await fetch(base + '/api/plugins/settings-doc-test', { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
  });

  await test('集成：插件开发文档路由', async () => {
    const r = await fetch(base + '/docs/plugin.md');
    assert.equal(r.status, 200);
    const text = await r.text();
    assert.ok(text.includes('易语言实战'), '文档缺少易语言章节');
    assert.ok(text.includes('Python') && text.includes('C#'), '文档缺少其它语言示例');
    assert.ok(text.includes('创建插件不需要令牌'), '文档未说明创建插件不需要令牌');
  });

  await test('集成：配置读写与插件令牌', async () => {
    const cfg = await fetch(base + '/api/config', { headers: auth }).then((x) => x.json());
    assert.equal(cfg.config.accounts.length, 1);
    assert.equal(cfg.config.accounts[0].clientSecret, '******');
    assert.equal(cfg.config.accounts[0].hasSecret, true);
    assert.equal(cfg.config.server.token, undefined, '访问令牌应已移除');
    assert.equal(cfg.config.plugins.token, '******');
    assert.equal(cfg.config.jlw.baseUrl, jlwMock.base);
    const rot = await fetch(base + '/api/plugins/token/rotate', { method: 'POST', headers: auth, body: '{}' }).then((x) => x.json());
    assert.equal(rot.ok, true);
    assert.ok(rot.token.length > 20);
    const upd = await fetch(base + '/api/accounts/main', {
      method: 'PATCH',
      headers: auth,
      body: JSON.stringify({ prefix: '/' }),
    }).then((x) => x.json());
    assert.equal(upd.ok, true);
    assert.equal(upd.account.prefix, '/');
  });

  await test('集成：多账户增删与状态聚合', async () => {
    const created = await fetch(base + '/api/accounts', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ name: '副号', appId: 'app2', clientSecret: 'sec2', mode: 'webhook', enabled: false }),
    }).then((x) => x.json());
    assert.equal(created.ok, true);
    const st = await fetch(base + '/api/status', { headers: auth }).then((x) => x.json());
    assert.equal(st.accounts.length, 2);
    assert.equal(st.accounts[1].name, '副号');
    assert.ok(st.accounts[1].webhookPath.includes(created.account.id));
    const patch = await fetch(base + '/api/accounts/' + created.account.id, {
      method: 'PATCH',
      headers: auth,
      body: JSON.stringify({ name: '副号改名' }),
    }).then((x) => x.json());
    assert.equal(patch.account.name, '副号改名');
    const del = await fetch(base + '/api/accounts/' + created.account.id, { method: 'DELETE', headers: auth }).then((x) => x.json());
    assert.equal(del.ok, true);
    const st2 = await fetch(base + '/api/status', { headers: auth }).then((x) => x.json());
    assert.equal(st2.accounts.length, 1);
  });

  await test('集成：公网 IP 接口（离线时降级）', async () => {
    const r = await fetch(base + '/api/netinfo', { headers: auth }).then((x) => x.json());
    assert.equal(r.ok, true);
    assert.equal(typeof r.ip, 'string');
    assert.ok(Array.isArray(r.local));
  });

  await test('集成：退出登录使会话失效', async () => {
    const out = await fetch(base + '/api/logout', { method: 'POST', headers: auth, body: '{}' }).then((x) => x.json());
    assert.equal(out.ok, true);
    const after = await fetch(base + '/api/status', { headers: auth });
    assert.equal(after.status, 401);
  });

  /* 收尾 */
  if (child) {
    child.kill();
    await sleep(400);
  }
  await jlwMock.stop();
  fs.rmSync(dataDir, { recursive: true, force: true });

  const failed = results.filter((r) => !r.ok);
  console.log(`\n共 ${results.length} 项，通过 ${results.length - failed.length}，失败 ${failed.length}\n`);
  if (failed.length) {
    for (const f of failed) console.log(`  ✗ ${f.name}: ${f.error}`);
    process.exitCode = 1;
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
