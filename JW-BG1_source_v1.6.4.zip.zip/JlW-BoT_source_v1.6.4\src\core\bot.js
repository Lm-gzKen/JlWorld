'use strict';
/**
 * 机器人核心：事件归一化、去重、消息回复、插件输出执行
 */
const { EventEmitter } = require('events');
const path = require('path');
const U = require('./util');
const store = require('./store');
const { SAFE } = require('./intents');
const Gateway = require('./gateway');
const ReplyGuard = require('./reply-guard');

const MESSAGE_EVENTS = new Set([
  'GROUP_AT_MESSAGE_CREATE',
  'GROUP_MESSAGE_CREATE',
  'C2C_MESSAGE_CREATE',
  'AT_MESSAGE_CREATE',
  'MESSAGE_CREATE',
  'DIRECT_MESSAGE_CREATE',
]);

/**
 * 没有 message 字段的事件，被动回复只能用事件外层 id（body.event_id），不能传 msg_id。
 * 官方只对下面这几个事件开放 event_id 被动回复。
 */
const EVENT_PASSIVE_REPLY = new Set(['GROUP_ADD_ROBOT', 'GROUP_MSG_RECEIVE', 'INTERACTION_CREATE']);

/**
 * 明确没有被动回复接口的事件：既不能用 msg_id，也不能用 event_id，只能发群主动消息。
 * 主动消息需要机器人有群主动消息权限，没权限就只能记录/跳过。
 */
const EVENT_NO_PASSIVE_REPLY = new Set([
  'GROUP_MEMBER_ADD',
  'GROUP_MEMBER_REMOVE',
  'GROUP_DEL_ROBOT',
  'GROUP_JOIN_REQUEST',
  'FRIEND_ADD',
  'FRIEND_DEL',
]);

const MSG_ID_EVENTS_HINT = '消息事件用 msg_id（可选 msg_seq），GROUP_ADD_ROBOT 等事件用 event_id，两者不能同时传';

class Bot extends EventEmitter {
  constructor({ account, config, logger, api, token, plugins }) {
    super();
    this.account = account || { id: 'main', name: '主账号', appId: '' };
    this.config = config;
    this.logger = logger;
    this.log = logger.child('bot:' + this.account.id);
    this.api = api;
    this.token = token;
    this.plugins = plugins;
    this.gateway = new Gateway({ config, token, logger, api });
    this.replyGuard = new ReplyGuard({ config, logger: this.log, accountId: this.account.id });
    this.self = null;
    this.lastGoodIntents = null;
    this.state = 'off';
    this.startedAt = 0;
    this.mode = config.get('bot.mode', 'ws');
    this.events = [];
    this.seen = new Map();
    this.seqMap = new Map();
    this.counts = { group: 0, c2c: 0, channel: 0, dm: 0, other: 0, total: 0 };
    this.dayCounts = { day: U.dayKey(), total: 0 };
    // 消息写 SQLite（messages 表）；关掉 storage.messages 就不落库
    this.messageWriter = this.config.get('storage.messages')
      ? {
          write: (rec) => {
            try {
              store.insertMessage(rec);
            } catch (e) {
              this.log.warn('消息写入 SQLite 失败：' + e.message);
            }
          },
        }
      : null;
    this.lastEventAt = 0;
    this._bindGateway();
    this._cleanupTimer = setInterval(() => this._cleanup(), 60000);
    if (this._cleanupTimer.unref) this._cleanupTimer.unref();
  }

  _bindGateway() {
    // 所有网关回调都过 _guard：机器人连接问题只影响账户状态，不能把框架/面板带崩
    this.gateway.on(
      'state',
      this._guard('state', () => this.emit('status', this.status())),
    );
    this.gateway.on(
      'ready',
      this._guard('ready', (d) => {
        // READY 里的 user 常常没有 avatar，不能整块覆盖已从 /users/@me 取到的资料
        const user = d?.user || {};
        const prev = this.self || {};
        this.self = normalizeAvatar({ ...prev, ...user, avatar: user.avatar || prev.avatar || '' });
        if (!this.self.avatar) this._fetchSelf().catch(() => {});
        this.state = 'online';
        const cur = this.config.get('bot.intents', []);
        if (Array.isArray(cur) && cur.length) this.lastGoodIntents = [...cur];
        this.emit('status', this.status());
      }),
    );
    this.gateway.on(
      'dispatch',
      this._guard('dispatch', (p) => this.handleEvent({ ...p, source: 'ws' })),
    );
    // 网关自己发的提示（例如重连用尽进入冷却）转发到面板
    this.gateway.on(
      'notice',
      this._guard('notice', (n) => {
        this.emit('notice', { ...n, accountId: this.account.id, accountName: this.account.name });
        this.emit('status', this.status());
      }),
    );
    this.gateway.on(
      'fatal',
      this._guard('fatal', ({ code, reason, hint }) => {
      // IP 白名单：刷新 token 无用，停止重连并提示用户加白名单
      if (code === 11298) {
        this.state = 'error';
        this.lastError = reason || '接口访问源 IP 不在白名单';
        this.log.error(`QQ 接口 IP 白名单拦截：${this.lastError}`);
        this.emit('notice', {
          level: 'error',
          message: `${this.account.name}：${hint || '当前公网 IP 不在 QQ 机器人 IP 白名单，已停止自动重连。请到开放平台添加当前公网 IP，或关闭白名单后点「重连」。'}`,
          accountId: this.account.id,
        });
        this.emit('status', this.status());
        return;
      }
      // 其它致命错误（兜底）：v1.3.8 起重连用尽改为冷却循环，不再走这里
      if (!code) {
        this.state = 'error';
        this.lastError = reason || '网关连接失败';
        this.log.error(this.lastError);
        this.emit('notice', {
          level: 'error',
          message: `${this.account.name}：${hint || '网关连接失败，请检查网络或 IP 白名单后点「重连」。'}`,
          accountId: this.account.id,
        });
        this.emit('status', this.status());
        return;
      }
      // Intent 无权限：自动关闭异常订阅，回退到上一次可用集合后重连
      if (code === 4013 || code === 4014) {
        const cur = this.config.get('bot.intents', []);
        const fallback = this.lastGoodIntents && this.lastGoodIntents.length ? this.lastGoodIntents : SAFE;
        const same =
          JSON.stringify([...cur].sort()) === JSON.stringify([...fallback].sort());
        if (!same) {
          this.config.update({ bot: { intents: fallback } });
          this.log.warn(`Intent 无权限（${code}），已自动回退到可用集合并重连`, { intents: fallback });
          this.emit('notice', {
            level: 'warn',
            message: `Intent 无权限（${code}），已自动关闭异常订阅并重连`,
            accountId: this.account.id,
          });
          this.state = 'reconnecting';
          this.emit('status', this.status());
          setTimeout(() => {
            if (this.gateway.state !== 'online') this.gateway.connect();
          }, 1200);
          return;
        }
      }
      this.state = 'error';
      this.lastError = `${code} ${reason}`;
      this.log.error(`网关致命错误：${code} ${reason}`);
      this.emit('status', this.status());
      }),
    );
  }

  localUrl() {
    return `http://127.0.0.1:${this.config.get('server.port', 8686)}`;
  }

  async start() {
    this.startedAt = Date.now();
    this.mode = this.config.get('bot.mode', 'ws');
    // 账户级开关：掉线后是否一直自动重连（面板「异常重连」）
    this.gateway.autoReconnect = this.config.get('bot.autoReconnect', true) !== false;
    if (!this.config.get('bot.appId') || !this.config.secret()) {
      this.state = 'unconfigured';
      this.log.warn('尚未配置 AppID / AppSecret，请在面板「设置」中填写');
      this.emit('status', this.status());
      return;
    }
    this.state = 'starting';
    this.emit('status', this.status());
    this._fetchSelf().catch(() => {});
    if (this.mode === 'webhook') {
      this.state = 'webhook';
      this.emit('status', this.status());
      this.log.info('WebHook 模式已启用，等待平台回调');
    } else {
      await this.gateway.connect();
    }
  }

  async _fetchSelf() {
    try {
      const res = await this.api.get('/users/@me');
      if (res.ok) {
        this.self = normalizeAvatar(res.data);
        this.emit('status', this.status());
      } else if (res.fatal || res.code === 11298) {
        this.lastError = res.message || '接口访问源 IP 不在白名单';
        this.log.error(`获取机器人资料失败：${this.lastError}`);
        this.emit('notice', {
          level: 'error',
          message: `${this.account.name}：当前公网 IP 不在 QQ 机器人 IP 白名单，接口调用被拒绝。请到 QQ 开放平台添加当前公网 IP（面板右上角可复制），或关闭白名单后点「重连」。`,
          accountId: this.account.id,
        });
        this.emit('status', this.status());
      }
    } catch {
      /* ignore */
    }
  }

  async stop() {
    this.gateway.disconnect();
    this.state = 'off';
    this.emit('status', this.status());
  }

  async restart() {
    await this.stop();
    await U.sleep(300);
    await this.start();
  }

  /** 面板「异常重连」开关：关闭后掉线不再自动重连；重新打开时若已掉线则立刻补连一次 */
  setAutoReconnect(on) {
    const enabled = on !== false;
    this.gateway.autoReconnect = enabled;
    const idle = ['online', 'connecting', 'identifying', 'resuming'];
    const canRetry = enabled && this.mode !== 'webhook' && this.startedAt && !this.gateway.manualClose && !idle.includes(this.gateway.state);
    if (canRetry) {
      this.gateway.connect().catch((e) => this.log.error('重新开启异常重连后连接失败：' + e.message));
    }
    this.emit('status', this.status());
    return { ok: true, autoReconnect: enabled };
  }

  async setMode(mode) {
    if (!['ws', 'webhook'].includes(mode)) return { ok: false, error: 'mode 只能是 ws / webhook' };
    this.config.update({ bot: { mode } });
    this.mode = mode;
    if (this.state !== 'off') await this.restart();
    return { ok: true, mode, accountId: this.account.id };
  }

  /* ---------------- 事件入口 ---------------- */

  _guard(name, fn) {
    return (...args) => {
      try {
        return fn(...args);
      } catch (e) {
        // 机器人侧（网关/插件）的异常不能影响框架面板
        try {
          this.log.error(`网关事件 ${name} 处理异常：${e.message}`, {
            stack: String(e.stack || '')
              .split('\n')
              .slice(0, 6)
              .join('\n'),
          });
        } catch {
          /* ignore */
        }
        return undefined;
      }
    };
  }

  handleEvent(payload) {
    try {
      return this._handleEvent(payload);
    } catch (e) {
      try {
        this.log.error('事件处理异常：' + e.message);
      } catch {
        /* ignore */
      }
      return undefined;
    }
  }

  _handleEvent({ t, d, id, s, source }) {
    if (!t) return;
    const evtId = id || (d?.id ? `${t}:${d.id}` : `${t}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`);
    if (this._isDuplicate(evtId)) return;

    const now = Date.now();
    const message = this.normalize(t, d, source);
    const evt = {
      id: evtId,
      eventId: id || '',
      name: t,
      t,
      ts: now,
      time: U.nowIso(),
      source: source || 'ws',
      seq: s,
      raw: d,
      message,
      account: {
        id: this.account.id,
        name: this.account.name,
        appIdMasked: this.account.appId ? this.account.appId.slice(0, 4) + '****' + this.account.appId.slice(-4) : '',
      },
      accountId: this.account.id,
    };
    this.lastEventAt = now;
    if (message) {
      this.log.debug(`收到事件 ${t}（${message.kind}）`, {
        eventId: evtId,
        group: message.group_openid || undefined,
        user: message.author?.id || undefined,
        content: message.cleanContent ? message.cleanContent.slice(0, 80) : undefined,
      });
    } else {
      this.log.debug(`收到事件 ${t}`, { eventId: evtId });
    }
    this.events.unshift(evt);
    const max = this.config.get('storage.events', 500);
    if (this.events.length > max) this.events.length = max;

    if (message) this._countMessage(message);
    this.emit('event', evt);

    if (message && this.messageWriter) {
      this.messageWriter.write({
        t: now,
        time: evt.time,
        event: t,
        accountId: this.account.id,
        accountName: this.account.name,
        kind: message.kind,
        id: message.id,
        content: message.content,
        author: message.author?.id,
        name: message.author?.username,
        group_openid: message.group_openid,
        user_openid: message.user_openid,
        channel_id: message.channel_id,
        guild_id: message.guild_id,
        attachments: message.attachments?.length || 0,
      });
    }

    // 交给插件（异步，不阻塞网关）
    this.plugins
      .dispatch(evt)
      .catch((e) => this.log.error('插件分发异常: ' + e.message));
  }

  _isDuplicate(key) {
    if (this.seen.has(key)) return true;
    this.seen.set(key, Date.now());
    if (this.seen.size > 20000) {
      const cut = Date.now() - 10 * 60 * 1000;
      for (const [k, v] of this.seen) if (v < cut) this.seen.delete(k);
    }
    return false;
  }

  _cleanup() {
    const cut = Date.now() - 15 * 60 * 1000;
    for (const [k, v] of this.seqMap) if (v.at < cut) this.seqMap.delete(k);
    for (const [k, v] of this.seen) if (v < Date.now() - 10 * 60 * 1000) this.seen.delete(k);
  }

  _countMessage(msg) {
    this.counts.total++;
    if (this.dayCounts.day !== U.dayKey()) this.dayCounts = { day: U.dayKey(), total: 0 };
    this.dayCounts.total++;
    if (this.counts[msg.kind] !== undefined) this.counts[msg.kind]++;
  }

  /* ---------------- 归一化 ---------------- */

  normalize(t, d, source) {
    if (!MESSAGE_EVENTS.has(t) || !d) return null;
    const base = {
      id: d.id || '',
      kind: 'other',
      content: d.content || '',
      cleanContent: stripMentions(d.content || ''),
      timestamp: d.timestamp || '',
      source: source || 'ws',
      attachments: d.attachments || [],
      mentions: d.mentions || [],
      elements: d.msg_elements || [],
      scene: d.message_scene || null,
      author: {
        id: d.author?.id || d.author?.member_openid || d.author?.user_openid || '',
        username: d.author?.username || '',
        member_nickname: d.author?.member_nickname || '',
        avatar: d.author?.avatar || '',
        member_openid: d.author?.member_openid || '',
        user_openid: d.author?.user_openid || '',
        union_openid: d.author?.union_openid || '',
        role: d.author?.member_role || '',
        bot: !!d.author?.bot,
      },
    };

    if (t === 'GROUP_AT_MESSAGE_CREATE' || t === 'GROUP_MESSAGE_CREATE') {
      base.kind = 'group';
      base.group_openid = d.group_openid || '';
      base.union_group_openid = d.union_group_openid || '';
      base.message_type = d.message_type;
    } else if (t === 'C2C_MESSAGE_CREATE') {
      base.kind = 'c2c';
      base.user_openid = d.author?.user_openid || d.author?.id || '';
      base.author.user_openid = base.user_openid;
    } else if (t === 'AT_MESSAGE_CREATE' || t === 'MESSAGE_CREATE') {
      base.kind = 'channel';
      base.channel_id = d.channel_id || '';
      base.guild_id = d.guild_id || '';
      base.cleanContent = stripMentions(d.content || '');
    } else if (t === 'DIRECT_MESSAGE_CREATE') {
      base.kind = 'dm';
      base.channel_id = d.channel_id || '';
      base.guild_id = d.guild_id || '';
    }

    base.command = parseCommand(base.cleanContent.trim(), this.config.get('bot.prefix', ''));
    return base;
  }

  /* ---------------- 回复 ---------------- */

  nextSeq(msgId) {
    const cur = this.seqMap.get(msgId);
    const next = cur ? cur.n + 1 : 1;
    this.seqMap.set(msgId, { n: next, at: Date.now() });
    return next;
  }

  _bodyFromContent(content, extra = {}) {
    if (content && typeof content === 'object') return { msg_type: 0, ...content, ...extra };
    return { msg_type: 0, content: String(content ?? ''), ...extra };
  }

  _outgoingText(body) {
    if (!body) return '';
    if (typeof body.content === 'string' && body.content) return body.content;
    if (body.markdown && typeof body.markdown === 'object' && body.markdown.content) return String(body.markdown.content);
    if (body.card) return '[卡片消息]';
    if (body.media?.file_info) return '[富媒体消息]';
    return '';
  }

  /**
   * 记录机器人自己发出的消息：进「消息」页、也写 messages JSONL。
   * 不抛异常——记录失败不能影响发送本身。
   */
  _recordOutgoing(kind, target, body, result, source) {
    try {
      const content = this._outgoingText(body);
      const msgId = result?.data?.id || '';
      const ts = Date.now();
      const author = {
        id: this.self?.id || '',
        username: this.self?.username || this.config.get('bot.name', '') || this.account.name,
        bot: true,
        avatar: this.self?.avatar || '',
      };
      const message = {
        id: msgId,
        kind,
        content,
        cleanContent: content,
        timestamp: new Date(ts).toISOString(),
        author,
        group_openid: target.group_openid || '',
        user_openid: target.user_openid || '',
        channel_id: target.channel_id || '',
        attachments: [],
        mentions: [],
      };
      const evt = {
        id: 'out:' + (msgId || U.uid(12)),
        eventId: '',
        name: 'BOT_MESSAGE_CREATE',
        t: 'BOT_MESSAGE_CREATE',
        ts,
        time: U.nowIso(),
        source: source || 'api',
        direction: 'out',
        seq: undefined,
        raw: { id: msgId, target, ...target, body: body || null },
        message: { ...message, payload: body || null },
        account: {
          id: this.account.id,
          name: this.account.name,
          appIdMasked: this.account.appId ? this.account.appId.slice(0, 4) + '****' + this.account.appId.slice(-4) : '',
        },
        accountId: this.account.id,
      };
      this.events.unshift(evt);
      const max = this.config.get('storage.events', 500);
      if (this.events.length > max) this.events.length = max;
      this._countMessage(message);
      if (this.messageWriter) {
        this.messageWriter.write({
          t: ts,
          time: evt.time,
          event: evt.name,
          direction: 'out',
          accountId: this.account.id,
          accountName: this.account.name,
          kind,
          id: msgId,
          content,
          author: author.id,
          name: author.username,
          group_openid: message.group_openid,
          user_openid: message.user_openid,
          channel_id: message.channel_id,
          attachments: 0,
          payload: body || null,
        });
      }
      this.emit('event', evt);
    } catch (e) {
      try {
        this.log.warn('记录发送消息失败：' + e.message);
      } catch {
        /* ignore */
      }
    }
  }

  async _postAndRecord(kind, target, pathStr, body, source) {
    const r = await this.api.post(pathStr, body);
    if (r && r.ok) this._recordOutgoing(kind, target, body, r, source);
    return r;
  }

  _checkReplyBody(body) {
    if (body.msg_id && body.event_id) {
      return { ok: false, code: 'BAD_REPLY_REF', error: MSG_ID_EVENTS_HINT };
    }
    if (body.event_id && body.msg_seq !== undefined) {
      return { ok: false, code: 'BAD_REPLY_REF', error: 'event_id 被动回复不能带 msg_seq（msg_seq 只属于 msg_id）' };
    }
    return null;
  }

  async reply(message, content, extra = {}) {
    if (!message) {
      return { ok: false, code: 'NO_MESSAGE', error: '该事件没有消息上下文；GROUP_ADD_ROBOT 等事件请用 replyEvent(evt, ...)' };
    }
    if (extra && extra.event_id) {
      return { ok: false, code: 'BAD_REPLY_REF', error: '消息事件用 msg_id 回复，不要传 event_id；事件被动回复请用 replyEvent(evt, ...)' };
    }
    const body = this._bodyFromContent(content, extra);
    const bad = this._checkReplyBody(body);
    if (bad) return bad;
    if (message.kind === 'group') {
      if (!body.msg_id && message.id) body.msg_id = message.id;
      if (body.msg_id && body.msg_seq === undefined) body.msg_seq = this.nextSeq(body.msg_id);
      return this._postAndRecord('group', { group_openid: message.group_openid }, `/v2/groups/${encodeURIComponent(message.group_openid)}/messages`, body, 'reply');
    }
    if (message.kind === 'c2c') {
      if (!body.msg_id && message.id) body.msg_id = message.id;
      if (body.msg_id && body.msg_seq === undefined) body.msg_seq = this.nextSeq(body.msg_id);
      return this._postAndRecord('c2c', { user_openid: message.user_openid }, `/v2/users/${encodeURIComponent(message.user_openid)}/messages`, body, 'reply');
    }
    if (message.kind === 'channel' || message.kind === 'dm') {
      if (!body.msg_id && message.id) body.msg_id = message.id;
      return this._postAndRecord('channel', { channel_id: message.channel_id }, `/channels/${encodeURIComponent(message.channel_id)}/messages`, body, 'reply');
    }
    return { ok: false, error: '该事件不支持回复' };
  }

  /**
   * 事件被动回复：GROUP_ADD_ROBOT / GROUP_MSG_RECEIVE / INTERACTION_CREATE。
   * body 只带 event_id，绝不带 msg_id / msg_seq；其他事件明确拒绝，避免用错接口。
   */
  async replyEvent(evt, content, extra = {}) {
    if (!evt) return { ok: false, code: 'NO_EVENT', error: '缺少事件上下文' };
    const name = evt.t || evt.name || '';
    const eventId = evt.eventId || evt.raw?.id || '';
    if (!eventId) return { ok: false, code: 'NO_EVENT_ID', error: `${name || '事件'} 缺少事件 id，无法被动回复` };
    if (EVENT_NO_PASSIVE_REPLY.has(name)) {
      return {
        ok: false,
        code: 'NO_PASSIVE_REPLY',
        error: `${name} 没有被动回复接口：不能传 msg_id，也不能传 event_id；请改用主动群消息（sendGroup / 动作 send_group_message，需要群主动消息权限）`,
      };
    }
    if (!EVENT_PASSIVE_REPLY.has(name)) {
      return {
        ok: false,
        code: 'NO_PASSIVE_REPLY',
        error: `${name} 不能被动回复；支持 event_id 的只有 GROUP_ADD_ROBOT / GROUP_MSG_RECEIVE / INTERACTION_CREATE，其他事件请用主动消息`,
      };
    }
    const group = evt.raw?.group_openid || evt.message?.group_openid || extra.group_openid;
    if (!group) return { ok: false, code: 'NO_GROUP', error: `${name} 缺少 group_openid，无法被动回复` };
    const body = this._bodyFromContent(content, extra);
    delete body.msg_id;
    delete body.msg_seq;
    delete body.group_openid;
    body.event_id = eventId;
    return this._postAndRecord('group', { group_openid: group }, `/v2/groups/${encodeURIComponent(group)}/messages`, body, 'reply-event');
  }

  async sendGroup(groupOpenid, content, opts = {}) {
    const body = this._bodyFromContent(content, opts);
    const bad = this._checkReplyBody(body);
    if (bad) return bad;
    return this._postAndRecord('group', { group_openid: groupOpenid }, `/v2/groups/${encodeURIComponent(groupOpenid)}/messages`, body, 'send');
  }

  async sendC2C(userOpenid, content, opts = {}) {
    const body = this._bodyFromContent(content, opts);
    const bad = this._checkReplyBody(body);
    if (bad) return bad;
    return this._postAndRecord('c2c', { user_openid: userOpenid }, `/v2/users/${encodeURIComponent(userOpenid)}/messages`, body, 'send');
  }

  async sendChannel(channelId, content, opts = {}) {
    const body = this._bodyFromContent(content, opts);
    const bad = this._checkReplyBody(body);
    if (bad) return bad;
    return this._postAndRecord('channel', { channel_id: channelId }, `/channels/${encodeURIComponent(channelId)}/messages`, body, 'send');
  }

  /** 面板/接口测试统一入口 */
  async send({ type, target, content, msg_id, event_id, msg_seq, msg_type, markdown, media, keyboard, card }) {
    const extra = {};
    if (msg_id) extra.msg_id = msg_id;
    if (event_id) extra.event_id = event_id;
    if (!event_id && msg_seq !== undefined && msg_seq !== '') extra.msg_seq = Number(msg_seq);
    if (msg_type !== undefined && msg_type !== '') extra.msg_type = Number(msg_type);
    if (markdown) extra.markdown = typeof markdown === 'string' ? JSON.parse(markdown) : markdown;
    if (media) extra.media = typeof media === 'string' ? JSON.parse(media) : media;
    if (keyboard) extra.keyboard = typeof keyboard === 'string' ? JSON.parse(keyboard) : keyboard;
    if (card) extra.card = typeof card === 'string' ? JSON.parse(card) : card;
    const payload = { ...(content && typeof content === 'object' ? content : { content: String(content ?? '') }), ...extra };
    if (type === 'group') return this.sendGroup(target, payload);
    if (type === 'c2c') return this.sendC2C(target, payload);
    if (type === 'channel') return this.sendChannel(target, payload);
    return { ok: false, error: 'type 必须是 group / c2c / channel' };
  }

  /* ---------------- 插件输出 ---------------- */

  /** 插件回复闸门：同一目标限频/去重，防止异常刷屏（配置 plugins.replyGuard） */
  _guardOutgoing(pluginId, kind, target, content, passive = true) {
    try {
      const text =
        this._outgoingText(content) ||
        (typeof content === 'string' ? content : content?.content ? String(content.content) : '');
      return this.replyGuard.check({ pluginId, kind, target, text, passive }).ok;
    } catch {
      return true;
    }
  }

  _replyTarget(msg, evt, kind) {
    if (kind === 'group') return msg?.group_openid || evt?.raw?.group_openid || '';
    if (kind === 'c2c') return msg?.user_openid || evt?.raw?.openid || '';
    return msg?.channel_id || evt?.raw?.channel_id || '';
  }

  async applyPluginOutput(plugin, evt, out) {
    let replied = false;
    const results = [];
    const msg = evt.message;
    for (const reply of out.replies) {
      const content = this._replyToPayload(reply);
      if (!content) continue;
      const kind = msg?.kind || 'group';
      if (!this._guardOutgoing(plugin.id, kind, this._replyTarget(msg, evt, kind), content)) {
        results.push({ type: 'reply', ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' });
        continue;
      }
      // 有 message 的事件走 msg_id 被动回复；GROUP_ADD_ROBOT 这类事件走 event_id；
      // 进群/退群等没有被动回复接口的事件会在 replyEvent 里被明确拒绝并给出提示。
      const r = msg ? await this.reply(msg, content) : await this.replyEvent(evt, content);
      results.push({ type: 'reply', ok: r.ok, code: r.code, message: r.message });
      if (r.ok) replied = true;
      if (!r.ok) this.log.warn(`插件 ${plugin.id} 回复失败: ${r.message}`, { code: r.code });
    }
    for (const action of out.actions) {
      try {
        const r = await this.executeAction(plugin, evt, action);
        results.push(r);
        if (r?.ok && r.replied) replied = true;
      } catch (e) {
        results.push({ ok: false, error: e.message });
        this.log.warn(`插件 ${plugin.id} 动作失败: ${e.message}`);
      }
    }
    return { replied, results };
  }

  _replyToPayload(reply) {
    if (!reply) return null;
    if (reply.type === 'markdown' || reply.markdown) {
      return { msg_type: 2, markdown: typeof reply.markdown === 'object' ? reply.markdown : { content: String(reply.content || '') } };
    }
    if (reply.type === 'media' || reply.file_info) {
      return { msg_type: 7, media: { file_info: reply.file_info || reply.media?.file_info } };
    }
    if (reply.type === 'card' || reply.card) {
      return { msg_type: 8, card: reply.card };
    }
    if (reply.content !== undefined) return { msg_type: reply.msg_type ?? 0, content: String(reply.content) };
    return null;
  }

  async executeAction(plugin, evt, action) {
    const a = action.action || action.type;
    const msg = evt.message;
    const guarded = (kind, target, content, passive = true) => this._guardOutgoing(plugin.id, kind, target, content, passive);
    switch (a) {
      case 'reply': {
        const kind = msg?.kind || 'group';
        const target = this._replyTarget(msg, evt, kind);
        if (!guarded(kind, target, action.content ?? action.reply)) {
          return { ok: false, action: a, replied: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' };
        }
        const r = msg ? await this.reply(msg, action.content ?? action.reply, action) : await this.replyEvent(evt, action.content ?? action.reply, action);
        return { ok: r.ok, action: a, replied: r.ok, id: r.data?.id, code: r.code, message: r.message };
      }
      case 'send_group_message': {
        const target = action.group_openid || msg?.group_openid;
        if (!guarded('group', target, action.content, false)) return { ok: false, action: a, replied: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' };
        const r = await this.sendGroup(target, action.content, action);
        return { ok: r.ok, action: a, replied: true, id: r.data?.id, code: r.code, message: r.message };
      }
      case 'send_c2c_message': {
        const target = action.user_openid || msg?.user_openid;
        if (!guarded('c2c', target, action.content, false)) return { ok: false, action: a, replied: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' };
        const r = await this.sendC2C(target, action.content, action);
        return { ok: r.ok, action: a, replied: true, id: r.data?.id, code: r.code, message: r.message };
      }
      case 'send_channel_message': {
        const target = action.channel_id || msg?.channel_id;
        if (!guarded('channel', target, action.content, false)) return { ok: false, action: a, replied: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' };
        const r = await this.sendChannel(target, action.content, action);
        return { ok: r.ok, action: a, replied: true, id: r.data?.id, code: r.code, message: r.message };
      }
      case 'endpoint': {
        const ep = this.plugins.endpoints.find((x) => x.key === action.endpoint);
        if (!ep) return { ok: false, action: a, error: '未知接口 ' + action.endpoint };
        const p = substitutePath(ep.path, action.params || {});
        const r = await this.api.request(ep.method, p, { query: action.query, body: action.body });
        return { ok: r.ok, action: a, endpoint: ep.key, data: r.data, code: r.code, message: r.message };
      }
      case 'api': {
        const r = await this.api.request(action.method || 'GET', action.path, {
          query: action.query,
          body: action.body,
        });
        return { ok: r.ok, action: a, data: r.data, code: r.code, message: r.message };
      }
      case 'interaction_ack': {
        const id = action.interaction_id || evt.raw?.id;
        const r = await this.api.put(`/interactions/${encodeURIComponent(id)}`, { code: action.code ?? 0 });
        return { ok: r.ok, action: a, code: r.code, message: r.message };
      }
      case 'log':
        this.log[action.level || 'info'](`[${plugin.id}] ${action.message || action.content || ''}`);
        return { ok: true, action: a };
      case 'noop':
        return { ok: true, action: a };
      default:
        return { ok: false, action: a, error: '未知动作类型 ' + a };
    }
  }

  /* ---------------- 插件侧 API ---------------- */

  pluginApi(plugin) {
    const self = this;
    return {
      async call(key, { params, query, body } = {}) {
        const ep = self.plugins.endpoints.find((x) => x.key === key);
        if (!ep) throw new Error('未知接口 ' + key);
        const p = substitutePath(ep.path, params || {});
        return self.api.request(ep.method, p, { query, body });
      },
      async request(method, pathStr, opts = {}) {
        return self.api.request(method, pathStr, opts);
      },
      sendGroup: (g, content, opts) =>
        self._guardOutgoing(plugin.id, 'group', g, content, false) ? self.sendGroup(g, content, opts) : { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' },
      sendC2C: (u, content, opts) =>
        self._guardOutgoing(plugin.id, 'c2c', u, content, false) ? self.sendC2C(u, content, opts) : { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' },
      sendChannel: (c, content, opts) =>
        self._guardOutgoing(plugin.id, 'channel', c, content, false) ? self.sendChannel(c, content, opts) : { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' },
      reply: (message, content, extra) =>
        self._guardOutgoing(plugin.id, message?.kind || 'group', self._replyTarget(message, null, message?.kind || 'group'), content)
          ? self.reply(message, content, extra)
          : { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' },
      replyEvent: (evt, content, extra) =>
        self._guardOutgoing(plugin.id, 'group', evt?.raw?.group_openid || evt?.message?.group_openid || '', content)
          ? self.replyEvent(evt, content, extra)
          : { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' },
      me: () => self.api.get('/users/@me'),
      get groupInfo() {
        return (g) => self.api.get(`/v2/groups/${encodeURIComponent(g)}/info`);
      },
    };
  }

  pluginFacade(plugin) {
    const self = this;
    const pid = plugin?.id || 'plugin';
    const blocked = { ok: false, code: 'REPLY_GUARD', message: '回复被限流丢弃' };
    return {
      info: () => self.publicInfo(),
      reply: (message, content, extra) => {
        const kind = message?.kind || 'group';
        return self._guardOutgoing(pid, kind, self._replyTarget(message, null, kind), content) ? self.reply(message, content, extra) : blocked;
      },
      replyEvent: (evt, content, extra) =>
        self._guardOutgoing(pid, 'group', evt?.raw?.group_openid || evt?.message?.group_openid || '', content)
          ? self.replyEvent(evt, content, extra)
          : blocked,
      sendGroup: (g, content, opts) => (self._guardOutgoing(pid, 'group', g, content, false) ? self.sendGroup(g, content, opts) : blocked),
      sendC2C: (u, content, opts) => (self._guardOutgoing(pid, 'c2c', u, content, false) ? self.sendC2C(u, content, opts) : blocked),
      sendChannel: (c, content, opts) => (self._guardOutgoing(pid, 'channel', c, content, false) ? self.sendChannel(c, content, opts) : blocked),
      send: (p) => self.send(p),
      self: () => self.self,
    };
  }

  /* ---------------- 状态 ---------------- */

  publicInfo() {
    const appId = this.config.get('bot.appId', '');
    return {
      accountId: this.account.id,
      accountName: this.account.name,
      appId,
      appIdMasked: appId ? appId.slice(0, 4) + '****' + appId.slice(-4) : '',
      name: this.self?.username || this.config.get('bot.name', '') || '未连接',
      avatar: this.self?.avatar || '',
      id: this.self?.id || '',
      mode: this.mode,
      sandbox: !!this.config.get('bot.sandbox'),
      prefix: this.config.get('bot.prefix', ''),
      intents: this.gateway ? this.gateway.intentsMask() : 0,
    };
  }

  status() {
    const gw = this.gateway.info();
    const state =
      this.mode === 'webhook'
        ? this.state === 'webhook'
          ? 'webhook'
          : this.state
        : this.state === 'unconfigured'
          ? 'unconfigured'
          : gw.state;
    return {
      accountId: this.account.id,
      accountName: this.account.name,
      state,
      mode: this.mode,
      startedAt: this.startedAt,
      uptime: this.startedAt ? Date.now() - this.startedAt : 0,
      gateway: gw,
      self: this.self,
      intents: this.gateway.intentsMask(),
      counts: this.counts,
      today: this.dayCounts.total,
      lastEventAt: this.lastEventAt,
      token: this.token.info(),
      api: this.api.stats,
      webhook: this.mode === 'webhook' ? { path: this.config.get('webhook.path') } : null,
      localUrl: this.localUrl(),
    };
  }
}

function stripMentions(text) {
  return String(text || '')
    .replace(/<@!?\d+>/g, '')
    .replace(/<@!?[^>]+>/g, '')
    .replace(/^[\s\u3000]+|[\s\u3000]+$/g, '');
}

function parseCommand(text, prefix) {
  let body = String(text || '').trim();
  if (prefix) {
    if (!body.startsWith(prefix)) return { name: '', args: [], text: '', matched: false };
    body = body.slice(prefix.length).trim();
  } else if (/^[/／]/.test(body)) {
    // 没配置前缀时，兼容大家习惯的 /签到 写法
    body = body.slice(1).trim();
  }
  if (!body) return { name: '', args: [], text: '', matched: true };
  const m = body.match(/^(\S+)(?:\s+([\s\S]*))?$/);
  const name = (m?.[1] || '').slice(0, 32);
  const rest = m?.[2] || '';
  return {
    name,
    args: rest ? rest.split(/\s+/).filter(Boolean) : [],
    text: rest,
    matched: true,
  };
}

function normalizeAvatar(user) {
  if (!user || typeof user !== 'object') return user;
  if (user.avatar) user.avatar = String(user.avatar).replace(/^http:\/\//i, 'https://');
  return user;
}

function substitutePath(template, params) {
  return template.replace(/\{(\w+)\}/g, (_, k) => {
    const v = params[k];
    if (v === undefined || v === null || v === '') throw new Error(`缺少路径参数 ${k}`);
    return encodeURIComponent(String(v));
  });
}

module.exports = Bot;
module.exports.stripMentions = stripMentions;
module.exports.parseCommand = parseCommand;
module.exports.substitutePath = substitutePath;
module.exports.EVENT_PASSIVE_REPLY = EVENT_PASSIVE_REPLY;
module.exports.EVENT_NO_PASSIVE_REPLY = EVENT_NO_PASSIVE_REPLY;
