'use strict';
/**
 * 稳定性：崩溃取证 / 心跳 / 面板端口自愈 / 控制台写失败不崩
 *   node test/resilience-test.js
 */
const assert = require('assert');
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}

function tempDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function stubLogger() {
  const mk = () => ({ info() {}, warn() {}, error() {}, debug() {}, trace() {} });
  const logger = mk();
  logger.child = () => mk();
  logger.subscribe = () => () => {};
  logger.recent = () => [];
  return logger;
}

(async () => {
  /* ---------------- 崩溃取证 ---------------- */
  const dir1 = tempDir('jlw-health-');
  const health = require('../src/core/health');
  const logs = [];
  const beforeListeners = process.listenerCount('uncaughtException');
  const guard = new health.CrashGuard({
    dataDir: dir1,
    version: '9.9.9',
    logger: { info() {}, warn() {}, error: (m) => logs.push(m), debug() {} },
  }).install();

  process.emit('uncaughtException', new Error('boom-uncaught'), 'uncaughtException');
  process.emit('unhandledRejection', new Error('boom-reject'), Promise.resolve());
  check(process.listenerCount('uncaughtException') >= 1, '未捕获异常有兜底监听（进程不会直接退出）');
  check(beforeListeners + 1 === process.listenerCount('uncaughtException'), '安装后 uncaughtException 监听 +1', String(beforeListeners));

  const crashes = health.readCrashes(dir1, 10);
  check(crashes.length >= 2, '崩溃记录写入 crash.log', 'count=' + crashes.length);
  check(crashes.some((c) => c.kind === 'uncaughtException' && /boom-uncaught/.test(c.message)), '未捕获异常被记录');
  check(crashes.some((c) => c.kind === 'unhandledRejection' && /boom-reject/.test(c.message)), '未处理 Promise 拒绝被记录');
  check(/boom-uncaught/.test(logs.join('\n')), '崩溃同时写进日志');
  check(fs.existsSync(health.crashPath(dir1)), 'crash.log 路径正确', health.crashPath(dir1));

  // 幂等：重复 install 不叠加监听
  const n1 = process.listenerCount('uncaughtException');
  guard.install();
  check(process.listenerCount('uncaughtException') === n1, '重复 install 不重复注册监听');

  /* ---------------- 心跳 ---------------- */
  guard.heartbeatMs = 40;
  guard.startHeartbeat();
  await sleep(120);
  const hb = health.readHeartbeat(dir1);
  check(hb && hb.pid === process.pid, '心跳文件写入 pid', JSON.stringify(hb));
  check(typeof hb?.uptimeSec === 'number', '心跳包含运行时长');
  check(health.wasUncleanShutdown(dir1, 999999)?.pid === process.pid, '换一个 pid 启动时能识别“上次没正常收尾”');
  check(health.wasUncleanShutdown(dir1, process.pid) === null, '同一 pid 不误报');
  guard.markCleanExit();
  check(health.wasUncleanShutdown(dir1, 999999) === null, '正常退出后不再误报异常退出');
  guard.uninstall();
  check(process.listenerCount('uncaughtException') === beforeListeners, 'uninstall 后监听恢复原状');

  /* ---------------- 控制台写失败不崩 ---------------- */
  const dir2 = tempDir('jlw-logger-');
  process.env.JLW_DATA_DIR = dir2;
  const Logger = require('../src/core/logger');
  const origWrite = process.stdout.write;
  let threw = false;
  try {
    process.stdout.write = () => {
      throw new Error('EPIPE fake');
    };
    const logger = new Logger({ log: { level: 'info', console: true } });
    for (let i = 0; i < 5; i++) logger.info('控制台坏掉时的日志 ' + i);
  } catch {
    threw = true;
  } finally {
    process.stdout.write = origWrite;
  }
  check(!threw, 'stdout 写入抛错时 logger 不把进程带崩');
  const logLogger = new Logger({ log: { level: 'info', console: true } });
  check(logLogger.console === true, '新 logger 默认开启控制台');
  const failLogger = new Logger({ log: { level: 'info', console: true } });
  const orig2 = process.stdout.write;
  try {
    process.stdout.write = () => {
      throw new Error('EPIPE fake 2');
    };
    for (let i = 0; i < 4; i++) failLogger.info('x');
  } finally {
    process.stdout.write = orig2;
  }
  check(failLogger.console === false, '连续写失败后自动关闭控制台输出');
  const db = require('../src/core/db');
  const saved = db.logsByDay(db.dayOf(Date.now()), { limit: 20 });
  check(saved.some((l) => l.msg === 'x'), '控制台失败时日志仍写入 SQLite', 'rows=' + saved.length);

  /* ---------------- 面板端口自愈 ---------------- */
  const PanelServer = require('../src/core/server');
  const port = 21000 + Math.floor(Math.random() * 400);
  const logger = stubLogger();
  const host = new EventEmitter();
  host.info = () => ({ count: 0, configured: 0 });
  host.list = () => [];
  host.events = () => [];
  host.webhookAccount = () => null;
  const config = {
    data: {},
    get: (k, d) => (k === 'server.port' ? port : k === 'server.host' ? '127.0.0.1' : d),
    set() {},
    save() {},
    jlw: () => ({ baseUrl: '' }),
    isLoginAllowed: () => true,
  };
  const panel = new PanelServer({
    config,
    logger,
    host,
    plugins: { list: () => [], registry: new Map() },
    endpoints: [],
    webhook: {},
    netinfo: {},
    session: { get: () => ({ sid: 's1', user: { email: 'a@b.c' } }), destroy() {} },
    jlw: {},
    updater: {},
    watchdogMs: 300,
  });

  const base = `http://127.0.0.1:${port}`;
  await panel.start();
  const h1 = await fetch(base + '/health').then((r) => r.json());
  check(h1.ok === true && h1.pid === process.pid, '/health 返回 pid', JSON.stringify(h1));
  check(h1.listening === true, '/health 报告正在监听');

  // 模拟“整个端口掉了”：直接关掉 server，看门狗应自动重新 listen
  await new Promise((r) => panel.server.close(r));
  check(panel.server.listening === false, '模拟端口停止监听');
  let recovered = false;
  for (let i = 0; i < 30; i++) {
    await sleep(150);
    try {
      const r = await fetch(base + '/health', { signal: AbortSignal.timeout(1500) });
      if (r.ok) {
        recovered = true;
        break;
      }
    } catch {
      /* 还没恢复 */
    }
  }
  check(recovered, '看门狗自动恢复 HTTP 端口');
  const h2 = recovered ? await fetch(base + '/health').then((r) => r.json()) : null;
  check(h2?.listening === true, '恢复后 listening=true');

  // 畸形 WebSocket 帧不能影响 HTTP 服务
  const sock = net.connect(port, '127.0.0.1');
  await new Promise((r) => sock.on('connect', r));
  sock.write(
    'GET /ws HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
      'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n',
  );
  await sleep(120);
  sock.write(Buffer.from([0x81, 0x7f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff]));
  await sleep(120);
  sock.destroy();
  await sleep(120);
  const h3 = await fetch(base + '/health').then((r) => r.json());
  check(h3.ok === true, '畸形 WS 帧之后 HTTP 仍正常');

  await panel.stop();
  check(panel.server.listening === false, 'stop 之后不再监听');
  await sleep(700);
  check(panel.server.listening === false, '主动 stop 不会被看门狗重新拉起');

  /* ---------------- 清理 ---------------- */
  try {
    fs.rmSync(dir1, { recursive: true, force: true });
    fs.rmSync(dir2, { recursive: true, force: true });
  } catch {
    /* ignore */
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
