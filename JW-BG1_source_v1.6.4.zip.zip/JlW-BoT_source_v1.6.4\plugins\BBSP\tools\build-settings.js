'use strict';
/**
 * BBSP · 构建设置页
 *
 * 面板给插件设置页的 CSP 是 sandbox + `default-src 'none'`：只能有内联样式和内联脚本，
 * 不能外链 JS/CSS，也不能联网。所以工作台必须打成一个单文件 settings.html。
 *
 * 用法：
 *   node plugins/BBSP/tools/build-settings.js
 *
 * 产物：plugins/BBSP/settings.html（插件目录根）
 * 源文件：ui/index.html + ui/style.css + lib/*.js + ui/app.js
 * 自测会重新构建并对比，防止忘记重新生成。
 */

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'settings.html');

const MODULES = {
  './blocks': path.join(ROOT, 'lib', 'blocks.js'),
  './project': path.join(ROOT, 'lib', 'project.js'),
  './codegen': path.join(ROOT, 'lib', 'codegen.js'),
  './pe': path.join(ROOT, 'lib', 'pe.js'),
  './config': path.join(ROOT, 'lib', 'config.js'),
};

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

function guardInline(text, tag) {
  // 避免源码里的 </script> / </style> 提前闭合内联块
  return text.replace(new RegExp('</' + tag, 'gi'), '<\\/' + tag);
}

function build() {
  const template = read(path.join(ROOT, 'ui', 'index.html'));
  const css = read(path.join(ROOT, 'ui', 'style.css'));
  const app = read(path.join(ROOT, 'ui', 'app.js'));
  const version = JSON.parse(read(path.join(ROOT, 'plugin.json'))).version;

  const parts = [];
  parts.push('/* BBSP settings bundle · 由 tools/build-settings.js 生成，请勿手改 */');
  parts.push('(function () {');
  parts.push("  'use strict';");
  parts.push('  var __mods = Object.create(null);');
  parts.push('  var __cache = Object.create(null);');
  parts.push('  function __define(id, factory) { __mods[id] = factory; }');
  parts.push('  function __require(id) {');
  parts.push('    if (__cache[id]) return __cache[id].exports;');
  parts.push('    var mod = { exports: {} };');
  parts.push('    __cache[id] = mod;');
  parts.push('    if (!__mods[id]) throw new Error("missing module: " + id);');
  parts.push('    __mods[id](mod, mod.exports, __require);');
  parts.push('    return mod.exports;');
  parts.push('  }');
  for (const [id, file] of Object.entries(MODULES)) {
    parts.push('  __define(' + JSON.stringify(id) + ', function (module, exports, require) {');
    parts.push(read(file));
    parts.push('  });');
  }
  parts.push('  window.BBSP = {');
  parts.push("    blocks: __require('./blocks'),");
  parts.push("    project: __require('./project'),");
  parts.push("    codegen: __require('./codegen'),");
  parts.push("    pe: __require('./pe'),");
  parts.push("    config: __require('./config'),");
  parts.push('  };');
  parts.push('})();');
  parts.push(app);

  const js = guardInline(parts.join('\n'), 'script');
  const safeCss = guardInline(css, 'style');

  let html = template.replace('/*__BBSP_CSS__*/', () => '\n' + safeCss + '\n      ');
  html = html.replace('/*__BBSP_JS__*/', () => '\n' + js + '\n    ');
  html = html.replace('</head>', '<!-- BBSP v' + version + ' · generated from ui/ + lib/ by tools/build-settings.js -->\n  </head>');
  return { html, version, bytes: Buffer.byteLength(html) };
}

function main() {
  const { html, version, bytes } = build();
  fs.writeFileSync(OUT, html, 'utf8');
  console.log(`BBSP settings.html 已生成：v${version}，${(bytes / 1024).toFixed(1)} KB → ${OUT}`);
}

if (require.main === module) main();

module.exports = { build, OUT };
