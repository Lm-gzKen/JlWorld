'use strict';
/**
 * 日志：环形缓冲 + 文件（JSONL 按日轮转）+ 面板实时订阅
 */
const path = require('path');
const U = require('./util');
const store = require('./store');

const LEVELS = { trace: 10, debug: 20, info: 30, warn: 40, error: 50 };
const COLORS = { trace: '\x1b[90m', debug: '\x1b[36m', info: '\x1b[32m', warn: '\x1b[33m', error: '\x1b[31m' };
const RESET = '\x1b[0m';

class Logger {
  constructor(cfg) {
    this.cfg = cfg || {};
    this.level = LEVELS[this.cfg.log?.level || 'info'] || 30;
    this.console = this.cfg.log?.console !== false;
    this.buffer = [];
    this.maxBuffer = 3000;
    this.subs = new Set();
    this._dbFails = 0;
    this.writer = null; // 日志现在写 SQLite（logs 表）；保留字段兼容旧调用
  }

  configure(cfg) {
    this.cfg = cfg;
    this.level = LEVELS[cfg.log?.level || 'info'] || 30;
    this.console = cfg.log?.console !== false;
  }

  child(scope) {
    const parent = this;
    const mk = (level) => (msg, meta) => parent._write(level, msg, meta, scope);
    return {
      scope,
      trace: mk('trace'),
      debug: mk('debug'),
      info: mk('info'),
      warn: mk('warn'),
      error: mk('error'),
      child: (s) => parent.child(scope ? scope + '/' + s : s),
    };
  }

  _write(level, msg, meta, scope) {
    if ((LEVELS[level] || 30) < this.level) return;
    const rec = {
      t: Date.now(),
      time: U.nowIso(),
      level,
      scope: scope || undefined,
      msg: typeof msg === 'string' ? msg : JSON.stringify(msg),
      meta: meta === undefined ? undefined : safeMeta(meta),
    };
    this.buffer.push(rec);
    if (this.buffer.length > this.maxBuffer) this.buffer.splice(0, this.buffer.length - this.maxBuffer);
    try {
      store.insertLog(rec);
      this._dbFails = 0;
    } catch (e) {
      this._dbFails++;
      if (this._dbFails <= 3) {
        try {
          process.stderr.write('[logger] 写入 SQLite 失败: ' + e.message + '\n');
        } catch {
          /* ignore */
        }
      }
    }
    if (this.console) {
      const c = COLORS[level] || '';
      const scopeStr = rec.scope ? `[${rec.scope}] ` : '';
      const metaStr = rec.meta ? ' ' + JSON.stringify(rec.meta) : '';
      // 控制台可能被关掉/管道断开（EPIPE）或处于“选中文字”的冻结状态；
      // 写失败只关掉控制台输出，绝不能把主进程带崩。
      try {
        process.stdout.write(`${c}${rec.time.slice(11, 23)} ${level.toUpperCase().padEnd(5)} ${scopeStr}${rec.msg}${metaStr}${RESET}\n`);
        this._stdoutFails = 0;
      } catch {
        this._stdoutFails = (this._stdoutFails || 0) + 1;
        if (this._stdoutFails >= 3) {
          this.console = false;
          try {
            store.insertLog({ t: Date.now(), level: 'warn', msg: '控制台输出已关闭（stdout 写入失败），日志继续写入' });
          } catch {
            /* ignore */
          }
        }
      }
    }
    for (const fn of this.subs) {
      try {
        fn(rec);
      } catch {
        /* ignore */
      }
    }
  }

  subscribe(fn) {
    this.subs.add(fn);
    return () => this.subs.delete(fn);
  }

  recent(limit = 300, level) {
    let out = this.buffer;
    if (level) {
      const min = LEVELS[level] || 0;
      out = out.filter((r) => (LEVELS[r.level] || 0) >= min);
    }
    return out.slice(-limit);
  }

  /** 停止重启/退出前调用：把文件流收尾 */
  close() {
    // 日志已经写进 SQLite；数据库连接由 index.js 统一关闭
  }

  trace() {
    this._write('trace', ...arguments);
  }
  debug() {
    this._write('debug', ...arguments);
  }
  info() {
    this._write('info', ...arguments);
  }
  warn() {
    this._write('warn', ...arguments);
  }
  error() {
    this._write('error', ...arguments);
  }
}

const SECRET_KEYS = /token|secret|authorization|password|passwd|signature|cookie/i;
function safeMeta(meta) {
  if (typeof meta === 'string') return redactString(meta);
  try {
    return JSON.parse(
      JSON.stringify(meta, (k, v) => {
        if (typeof v === 'string' && SECRET_KEYS.test(k)) {
          return v.length > 8 ? v.slice(0, 4) + '******' + v.slice(-2) : '******';
        }
        if (typeof v === 'string' && v.length > 800) return v.slice(0, 800) + '…';
        return v;
      }),
    );
  } catch {
    return String(meta);
  }
}

function redactString(s) {
  return String(s)
    .replace(/(QQBot\s+)[\w\-._~+/]+=*/g, '$1******')
    .replace(/(access_token["'\s:=]+)[\w\-._~+/]+=*/gi, '$1******');
}

module.exports = Logger;
module.exports.LEVELS = LEVELS;
module.exports.safeMeta = safeMeta;
