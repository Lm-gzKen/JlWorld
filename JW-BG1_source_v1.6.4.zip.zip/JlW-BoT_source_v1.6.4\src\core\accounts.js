'use strict';
/**
 * 账户池：多个 QQ 机器人账户同时在线
 * 每个账户独享 access_token、API 客户端、网关连接与事件计数；
 * 插件、日志、存储、面板由所有账户共享。
 */
const { EventEmitter } = require('events');
const TokenManager = require('./token');
const QQApi = require('./api');
const Bot = require('./bot');

class AccountHost extends EventEmitter {
  constructor({ config, logger, plugins, endpoints }) {
    super();
    this.config = config;
    this.logger = logger;
    this.plugins = plugins;
    this.endpoints = endpoints;
    this.accounts = new Map();
    this.startedAt = Date.now();
  }

  /* ---------------- 构建 / 销毁 ---------------- */

  _build(acc) {
    const log = this.logger.child('acc:' + acc.id);
    const view = this.config.accountView(acc);
    const token = new TokenManager({ config: view, logger: this.logger, accountId: acc.id });
    const api = new QQApi({ config: view, token, logger: this.logger, accountId: acc.id });
    const bot = new Bot({ account: acc, config: view, logger: this.logger, api, token, plugins: this.plugins });
    const rt = {
      id: acc.id,
      account: acc,
      view,
      token,
      api,
      bot,
      webhook: { received: 0, verified: 0, rejected: 0, lastAt: 0, lastError: null },
    };
    // 账户侧事件转发加隔离：单个账户连接/状态异常不能影响面板
    bot.on('event', (evt) => this._safeEmit('event', evt));
    bot.on('status', () => this._safeEmit('status', this.status()));
    bot.on('notice', (n) => this._safeEmit('notice', { ...n, accountId: acc.id, accountName: acc.name }));
    this.accounts.set(acc.id, rt);
    return rt;
  }

  _safeEmit(event, payload) {
    try {
      this.emit(event, payload);
    } catch (e) {
      try {
        this.logger.error(`账户事件分发异常 ${event}: ${e.message}`);
      } catch {
        /* ignore */
      }
    }
  }

  async init() {
    let started = 0;
    const skipped = [];
    for (const acc of this.config.listAccounts()) {
      const rt = this._build(acc);
      if (!acc.enabled) {
        skipped.push(acc.name + '（已停用）');
        continue;
      }
      if (acc.autoConnect === false) {
        skipped.push(acc.name + '（未开启自动连接）');
        continue;
      }
      started++;
      rt.bot.start().catch((e) => this.logger.error(`账户 ${acc.name} 启动失败: ${e.message}`));
    }
    this.logger.info(
      `账户池加载完成：${this.accounts.size} 个账户（自动连接 ${started} 个${skipped.length ? '，跳过：' + skipped.join('、') : ''}）`,
    );
    // 兜底：确实该自动连接、却根本没进过 start() 的账户，补一次并留下日志
    const timer = setTimeout(() => {
      for (const rt of this.accounts.values()) {
        if (!rt.account.enabled || rt.account.autoConnect === false) continue;
        if (rt.bot.startedAt) continue;
        this.logger.warn(`账户 ${rt.account.name} 启动后仍未开始连接，自动补连一次`);
        rt.bot.start().catch((e) => this.logger.error(`账户 ${rt.account.name} 补连失败: ${e.message}`));
      }
    }, 5000);
    timer.unref?.();
  }

  /* ---------------- 查询 ---------------- */

  get(id) {
    return this.accounts.get(id) || null;
  }

  botFor(id) {
    const rt = this.accounts.get(id);
    return rt ? rt.bot : null;
  }

  apiFor(id) {
    const rt = this.accounts.get(id);
    return rt ? rt.api : null;
  }

  tokenFor(id) {
    const rt = this.accounts.get(id);
    return rt ? rt.token : null;
  }

  defaultRuntime() {
    const list = [...this.accounts.values()];
    return list.find((r) => r.account.enabled && r.bot.state !== 'unconfigured') || list.find((r) => r.account.enabled) || list[0] || null;
  }

  defaultBot() {
    return this.defaultRuntime()?.bot || null;
  }

  resolve(id) {
    return this.accounts.get(id) || this.defaultRuntime();
  }

  webhookAccount(pathname) {
    return [...this.accounts.values()].find((r) => r.account.webhookPath === pathname) || null;
  }

  list() {
    return [...this.accounts.values()].map((rt) => this._view(rt));
  }

  _view(rt) {
    const st = rt.bot.status();
    return {
      ...st,
      intents: rt.account.intents,
      intentsMask: st.intents,
      id: rt.id,
      name: rt.account.name,
      appId: rt.account.appId,
      enabled: rt.account.enabled,
      autoConnect: rt.account.autoConnect !== false,
      autoReconnect: rt.account.autoReconnect !== false,
      appIdMasked: rt.account.appId ? rt.account.appId.slice(0, 4) + '****' + rt.account.appId.slice(-4) : '',
      sandbox: !!rt.account.sandbox,
      prefix: rt.account.prefix,
      webhookPath: rt.account.webhookPath,
      webhook: rt.webhook,
      hasCredentials: !!(rt.account.appId && rt.account.clientSecret),
    };
  }

  status() {
    const accounts = this.list();
    const agg = { total: 0, today: 0, online: 0, configured: 0, group: 0, c2c: 0, channel: 0 };
    for (const a of accounts) {
      agg.total += a.counts?.total || 0;
      agg.today += a.today || 0;
      agg.group += a.counts?.group || 0;
      agg.c2c += a.counts?.c2c || 0;
      agg.channel += a.counts?.channel || 0;
      if (a.state === 'online' || a.state === 'webhook') agg.online++;
      if (a.hasCredentials) agg.configured++;
    }
    const active = this.defaultRuntime();
    return {
      accounts,
      aggregate: agg,
      activeId: active ? active.id : null,
      // 兼容旧字段：默认账户状态
      bot: active ? this._view(active) : null,
      startedAt: this.startedAt,
    };
  }

  events(limit = 100, accountId = '') {
    const all = [];
    for (const rt of this.accounts.values()) {
      if (accountId && rt.id !== accountId) continue;
      for (const e of rt.bot.events) all.push(e);
    }
    all.sort((a, b) => b.ts - a.ts);
    return all.slice(0, limit);
  }

  /* ---------------- 生命周期 ---------------- */

  async start(id) {
    const rt = this.resolve(id);
    if (!rt) return { ok: false, error: '没有可用账户' };
    rt.account.enabled = true;
    this.config.updateAccount(rt.id, { enabled: true });
    await rt.bot.start();
    return { ok: true, id: rt.id, status: this._view(rt) };
  }

  async stop(id) {
    const rt = this.resolve(id);
    if (!rt) return { ok: false, error: '没有可用账户' };
    await rt.bot.stop();
    return { ok: true, id: rt.id, status: this._view(rt) };
  }

  async restart(id) {
    const rt = this.resolve(id);
    if (!rt) return { ok: false, error: '没有可用账户' };
    await rt.bot.restart();
    return { ok: true, id: rt.id };
  }

  async setMode(id, mode) {
    const rt = this.resolve(id);
    if (!rt) return { ok: false, error: '没有可用账户' };
    return rt.bot.setMode(mode);
  }

  async add(input) {
    const acc = this.config.addAccount(input);
    const rt = this._build(acc);
    if (!acc.enabled) this.logger.info(`账户 ${acc.name} 已创建（已停用，未连接）`);
    else if (acc.autoConnect === false) this.logger.info(`账户 ${acc.name} 已创建（未开启自动连接，未连接）`);
    else await rt.bot.start();
    this.emit('status', this.status());
    return { ok: true, account: this._view(rt) };
  }

  async update(id, patch) {
    const rt = this.accounts.get(id);
    if (!rt) return { ok: false, error: '账户不存在' };
    const before = JSON.stringify({
      appId: rt.account.appId,
      secret: rt.account.clientSecret,
      mode: rt.account.mode,
      intents: rt.account.intents,
      sandbox: rt.account.sandbox,
      shardId: rt.account.shardId,
      shardCount: rt.account.shardCount,
      tokenUrl: rt.account.tokenUrl,
      tokenUrlAlt: rt.account.tokenUrlAlt,
      apiBase: rt.account.apiBase,
      gatewayUrl: rt.account.gatewayUrl,
    });
    const prev = {
      appId: rt.account.appId,
      secret: rt.account.clientSecret,
      tokenUrl: rt.account.tokenUrl,
      tokenUrlAlt: rt.account.tokenUrlAlt,
    };
    const acc = this.config.updateAccount(id, patch);
    if (!acc) return { ok: false, error: '账户不存在' };
    Object.assign(rt.account, acc);
    // 异常重连是实时开关：改完立即生效，不用重启账户
    if (patch.autoReconnect !== undefined) {
      try {
        rt.bot.setAutoReconnect(acc.autoReconnect !== false);
      } catch (e) {
        this.logger.warn(`账户 ${acc.name} 切换异常重连失败：${e.message}`);
      }
    }
    if (
      prev.appId !== acc.appId ||
      prev.secret !== acc.clientSecret ||
      prev.tokenUrl !== acc.tokenUrl ||
      prev.tokenUrlAlt !== acc.tokenUrlAlt
    ) {
      rt.token.invalidate();
    }
    const after = JSON.stringify({
      appId: acc.appId,
      secret: acc.clientSecret,
      mode: acc.mode,
      intents: acc.intents,
      sandbox: acc.sandbox,
      shardId: acc.shardId,
      shardCount: acc.shardCount,
      tokenUrl: acc.tokenUrl,
      apiBase: acc.apiBase,
      gatewayUrl: acc.gatewayUrl,
    });
    if (before !== after && acc.enabled) {
      await rt.bot.restart();
    } else if (patch.enabled === false) {
      await rt.bot.stop();
    } else if (patch.enabled === true) {
      await rt.bot.start();
    }
    this.emit('status', this.status());
    return { ok: true, account: this._view(rt) };
  }

  async remove(id) {
    const rt = this.accounts.get(id);
    if (!rt) return { ok: false, error: '账户不存在' };
    await rt.bot.stop().catch(() => {});
    rt.token.stop();
    this.accounts.delete(id);
    this.config.removeAccount(id);
    this.emit('status', this.status());
    return { ok: true };
  }

  async send({ accountId, id, ...payload }) {
    const rt = this.accounts.get(accountId || id) || this.defaultRuntime();
    if (!rt) return { ok: false, error: '没有可用账户' };
    const r = await rt.bot.send(payload);
    return { ...r, accountId: rt.id };
  }

  /** 账户访问令牌的刷新 */
  async refreshToken(id) {
    const rt = this.resolve(id);
    if (!rt) return { ok: false, error: '没有可用账户' };
    await rt.token.get(true);
    return { ok: true, id: rt.id, token: rt.token.info() };
  }

  info() {
    return {
      count: this.accounts.size,
      online: this.list().filter((a) => a.state === 'online' || a.state === 'webhook').length,
      configured: this.list().filter((a) => a.hasCredentials).length,
    };
  }

  async dispose() {
    for (const rt of this.accounts.values()) {
      try {
        await rt.bot.stop();
      } catch {
        /* ignore */
      }
      try {
        rt.token.stop();
      } catch {
        /* ignore */
      }
    }
    this.accounts.clear();
  }
}

module.exports = AccountHost;
