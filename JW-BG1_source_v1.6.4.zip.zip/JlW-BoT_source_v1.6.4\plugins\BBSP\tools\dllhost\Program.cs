// BBSP · DLL 调用宿主（x86 / x64 各编译一份）
//
// 作用：Node 是 64 位进程，无法直接 LoadLibrary 32 位 DLL（易语言 DLL 基本都是 32 位）。
// 这个宿主是一层很薄的桥：标准输入读一行 JSON 请求，LoadLibrary + GetProcAddress，
// 用运行时生成的委托（DynamicMethod/TypeBuilder）按声明的返回类型/参数类型直接 call，
// 再把结果作为一行 JSON 从标准输出写回。宿主本身不保存业务状态，由 BBSP 管理进程。
//
// 协议（每行一个 JSON）：
//   启动 → {"ok":true,"ready":true,"arch":"x86|x64","pid":1234}
//   请求 → {"action":"call","dll":"C:\\x.dll","fn":"Add","conv":"stdcall","ret":"int",
//           "args":[{"type":"int","value":1},{"type":"text_ansi","value":"你好"}]}
//   响应 → {"ok":true,"value":3,"fnResolved":"_Add@8","ms":0}
//   心跳 → {"action":"ping"} → {"ok":true,"arch":"x86","pid":...}
// 出错 → {"ok":false,"error":"..."}（进程不退出，方便下一次继续用）
//
// 编译：tools\dllhost\build-dllhost.ps1（用系统自带的 .NET Framework csc，不需要 VS）

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;

internal static class BbspDllHost
{
    [DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr LoadLibraryW(string path);

    [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern IntPtr GetProcAddress(IntPtr module, string name);

    [DllImport("kernel32", SetLastError = true)]
    private static extern bool FreeLibrary(IntPtr module);

    private static readonly Dictionary<string, IntPtr> Modules = new Dictionary<string, IntPtr>(StringComparer.OrdinalIgnoreCase);
    private static readonly Dictionary<string, Type> DelegateTypes = new Dictionary<string, Type>(StringComparer.Ordinal);
    private static int _typeSeq;

    private static void Main()
    {
        Console.OutputEncoding = new UTF8Encoding(false);
        var stdin = new StreamReader(Console.OpenStandardInput(), new UTF8Encoding(false));
        var stdout = new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false));
        stdout.AutoFlush = true;

        var ser = new JavaScriptSerializer();
        ser.MaxJsonLength = int.MaxValue;

        var hello = new Dictionary<string, object>();
        hello["ok"] = true;
        hello["ready"] = true;
        hello["arch"] = IntPtr.Size == 8 ? "x64" : "x86";
        hello["pid"] = Process.GetCurrentProcess().Id;
        hello["clr"] = Environment.Version.ToString();
        stdout.WriteLine(ser.Serialize(hello));

        string line;
        while ((line = stdin.ReadLine()) != null)
        {
            line = line.Trim();
            if (line.Length == 0) continue;

            Dictionary<string, object> result;
            var sw = Stopwatch.StartNew();
            try
            {
                var req = ser.Deserialize<Dictionary<string, object>>(line);
                result = Handle(ser, req ?? new Dictionary<string, object>());
            }
            catch (Exception e)
            {
                result = Error(e.GetType().Name + ": " + e.Message);
            }
            result["ms"] = sw.ElapsedMilliseconds;
            try
            {
                stdout.WriteLine(ser.Serialize(result));
            }
            catch (Exception e)
            {
                stdout.WriteLine(ser.Serialize(Error("SERIALIZE_FAILED: " + e.Message)));
            }
        }
    }

    private static Dictionary<string, object> Handle(JavaScriptSerializer ser, Dictionary<string, object> req)
    {
        var action = Str(req, "action", "call").ToLowerInvariant();
        if (action == "ping")
        {
            var ping = new Dictionary<string, object>();
            ping["ok"] = true;
            ping["arch"] = IntPtr.Size == 8 ? "x64" : "x86";
            ping["pid"] = Process.GetCurrentProcess().Id;
            ping["modules"] = Modules.Count;
            return ping;
        }
        if (action == "unload")
        {
            foreach (var kv in Modules) { try { FreeLibrary(kv.Value); } catch { } }
            Modules.Clear();
            var un = new Dictionary<string, object>();
            un["ok"] = true;
            un["unloaded"] = true;
            return un;
        }
        if (action != "call") return Error("UNKNOWN_ACTION: " + action);

        var dllPath = Str(req, "dll", "");
        var fnName = Str(req, "fn", "").Trim();
        if (dllPath.Length == 0) return Error("缺少 dll 路径");
        if (fnName.Length == 0) return Error("缺少函数名");
        if (!File.Exists(dllPath)) return Error("DLL 不存在：" + dllPath);

        var convName = Str(req, "conv", "stdcall").ToLowerInvariant();
        var conv = convName == "cdecl" ? CallingConvention.Cdecl : CallingConvention.StdCall;
        var retName = NormalizeType(Str(req, "ret", "int"));
        var argList = ToList(Get(req, "args"));

        // 参数：先按声明类型解析出（委托参数类型，实际调用值，调用后要释放的字符串指针）
        var paramTypes = new List<Type>();
        var callArgs = new List<object>();
        var allocs = new List<IntPtr>();
        try
        {
            for (var i = 0; i < argList.Count; i++)
            {
                var a = argList[i] as Dictionary<string, object>;
                if (a == null) { paramTypes.Add(typeof(int)); callArgs.Add(0); continue; }
                var t = NormalizeType(Str(a, "type", "int"));
                var raw = Get(a, "value");
                switch (t)
                {
                    case "int":
                        paramTypes.Add(typeof(int));
                        callArgs.Add(ToInt(raw));
                        break;
                    case "bool":
                        paramTypes.Add(typeof(int));
                        callArgs.Add(ToBool(raw) ? 1 : 0);
                        break;
                    case "long":
                        paramTypes.Add(typeof(long));
                        callArgs.Add(ToLong(raw));
                        break;
                    case "float":
                        paramTypes.Add(typeof(float));
                        callArgs.Add((float)ToDouble(raw));
                        break;
                    case "double":
                        paramTypes.Add(typeof(double));
                        callArgs.Add(ToDouble(raw));
                        break;
                    case "ptr":
                        paramTypes.Add(typeof(IntPtr));
                        callArgs.Add(ToPtr(raw));
                        break;
                    case "text_utf8":
                    {
                        var bytes = Encoding.UTF8.GetBytes(raw == null ? "" : Convert.ToString(raw));
                        var p = AllocBytes(bytes, true);
                        allocs.Add(p);
                        paramTypes.Add(typeof(IntPtr));
                        callArgs.Add(p);
                        break;
                    }
                    default: // text_ansi（易语言文本型）
                    {
                        var bytes = AnsiEncoding.GetBytes(raw == null ? "" : Convert.ToString(raw));
                        var p = AllocBytes(bytes, true);
                        allocs.Add(p);
                        paramTypes.Add(typeof(IntPtr));
                        callArgs.Add(p);
                        break;
                    }
                }
            }

            var module = LoadModule(dllPath);
            if (module == IntPtr.Zero) return Error("LoadLibrary 失败（" + (IntPtr.Size == 8 ? "64 位" : "32 位") + " 宿主加载不了该 DLL，可能是位数不匹配）：" + dllPath + " / Win32 错误 " + Marshal.GetLastWin32Error());

            IntPtr fnPtr = IntPtr.Zero;
            string fnResolved = null;
            foreach (var name in CandidateNames(fnName, paramTypes, retName))
            {
                fnPtr = GetProcAddress(module, name);
                if (fnPtr != IntPtr.Zero) { fnResolved = name; break; }
            }
            if (fnPtr == IntPtr.Zero)
            {
                return Error("DLL 里找不到导出函数「" + fnName + "」（已尝试 " + string.Join(", ", CandidateNames(fnName, paramTypes, retName)) + "）。请确认函数是「公开」的，或改成导出表里的原始名字。");
            }

            var retType = RetType(retName);
            var delType = GetDelegateType(conv, retType, paramTypes.ToArray());
            var del = Marshal.GetDelegateForFunctionPointer(fnPtr, delType);
            object value = del.DynamicInvoke(callArgs.ToArray());

            var result = new Dictionary<string, object>();
            result["ok"] = true;
            result["fnResolved"] = fnResolved;
            result["ret"] = retName;
            result["value"] = ConvertReturn(retName, value);
            return result;
        }
        finally
        {
            for (var i = 0; i < allocs.Count; i++) { try { Marshal.FreeCoTaskMem(allocs[i]); } catch { } }
        }
    }

    private static IEnumerable<string> CandidateNames(string fn, List<Type> ps, string retName)
    {
        var clean = fn.Trim();
        while (clean.StartsWith("_")) clean = clean.Substring(1);
        while (clean.StartsWith("@")) clean = clean.Substring(1);
        var at = clean.LastIndexOf('@');
        if (at > 0)
        {
            int n;
            if (int.TryParse(clean.Substring(at + 1), out n)) clean = clean.Substring(0, at);
        }

        var list = new List<string>();
        Add(list, fn.Trim());
        Add(list, clean);
        if (IntPtr.Size == 4)
        {
            var stack = 0;
            foreach (var t in ps)
            {
                if (t == typeof(long) || t == typeof(double)) stack += 8; else stack += 4;
            }
            Add(list, "_" + clean + "@" + stack);
            Add(list, clean + "@" + stack);
            Add(list, "@" + clean + "@" + stack);
            Add(list, "_" + clean);
        }
        return list;
    }

    private static void Add(List<string> list, string s)
    {
        if (string.IsNullOrEmpty(s)) return;
        if (!list.Contains(s)) list.Add(s);
    }

    private static IntPtr LoadModule(string path)
    {
        IntPtr m;
        if (Modules.TryGetValue(path, out m) && m != IntPtr.Zero) return m;
        m = LoadLibraryW(path);
        if (m != IntPtr.Zero) Modules[path] = m;
        return m;
    }

    private static IntPtr AllocBytes(byte[] bytes, bool nulTerminate)
    {
        var size = bytes.Length + (nulTerminate ? 1 : 0);
        var p = Marshal.AllocCoTaskMem(size);
        Marshal.Copy(bytes, 0, p, bytes.Length);
        if (nulTerminate) Marshal.WriteByte(p, bytes.Length, 0);
        return p;
    }

    private static Type RetType(string retName)
    {
        switch (retName)
        {
            case "void": return typeof(void);
            case "long": return typeof(long);
            case "double": return typeof(double);
            case "float": return typeof(float);
            case "text_ansi":
            case "text_utf8":
            case "ptr": return typeof(IntPtr);
            default: return typeof(int); // int / bool
        }
    }

    private static object ConvertReturn(string retName, object value)
    {
        if (retName == "void") return null;
        if (value == null) return null;
        if (retName == "text_ansi")
        {
            var p = (IntPtr)value;
            return p == IntPtr.Zero ? "" : Marshal.PtrToStringAnsi(p);
        }
        if (retName == "text_utf8")
        {
            var p = (IntPtr)value;
            if (p == IntPtr.Zero) return "";
            // .NET Framework 4.0 没有 Marshal.PtrToStringUTF8，手工按 NUL 截断再解 UTF-8
            var bytes = new List<byte>();
            for (var i = 0; i < 1024 * 1024; i++)
            {
                var b = Marshal.ReadByte(p, i);
                if (b == 0) break;
                bytes.Add(b);
            }
            return Encoding.UTF8.GetString(bytes.ToArray());
        }
        if (retName == "ptr")
        {
            var p = (IntPtr)value;
            return p.ToInt64();
        }
        if (retName == "bool") return Convert.ToInt32(value) != 0;
        return value;
    }

    private static Type GetDelegateType(CallingConvention conv, Type retType, Type[] ps)
    {
        var key = conv + "|" + retType.FullName + "|";
        for (var i = 0; i < ps.Length; i++) key += ps[i].FullName + ";";
        Type cached;
        if (DelegateTypes.TryGetValue(key, out cached)) return cached;

        var ab = AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("BbspDyn" + (_typeSeq++)), AssemblyBuilderAccess.Run);
        var mb = ab.DefineDynamicModule("BbspDyn");
        var tb = mb.DefineType(
            "BbspDelegate" + (_typeSeq++),
            TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Class,
            typeof(MulticastDelegate));
        var ctor = tb.DefineConstructor(
            MethodAttributes.RTSpecialName | MethodAttributes.HideBySig | MethodAttributes.Public,
            CallingConventions.Standard,
            new[] { typeof(object), typeof(IntPtr) });
        ctor.SetImplementationFlags(MethodImplAttributes.Runtime | MethodImplAttributes.Managed);
        var invoke = tb.DefineMethod(
            "Invoke",
            MethodAttributes.Public | MethodAttributes.HideBySig | MethodAttributes.NewSlot | MethodAttributes.Virtual,
            retType,
            ps);
        invoke.SetImplementationFlags(MethodImplAttributes.Runtime | MethodImplAttributes.Managed);

        var attrCtor = typeof(UnmanagedFunctionPointerAttribute).GetConstructor(new[] { typeof(CallingConvention) });
        tb.SetCustomAttribute(new CustomAttributeBuilder(attrCtor, new object[] { conv }));

        var made = tb.CreateType();
        DelegateTypes[key] = made;
        return made;
    }

    /* ---------------- 小工具 ---------------- */

    private static readonly Encoding AnsiEncoding = Encoding.GetEncoding(0);

    private static string NormalizeType(string t)
    {
        t = (t ?? "").Trim().ToLowerInvariant();
        switch (t)
        {
            case "int":
            case "int32":
            case "整数":
            case "整数型":
                return "int";
            case "bool":
            case "boolean":
            case "逻辑":
            case "逻辑型":
                return "bool";
            case "long":
            case "int64":
            case "长整数":
            case "长整数型":
                return "long";
            case "float":
            case "小数":
                return "float";
            case "double":
            case "小数型":
                return "double";
            case "text":
            case "string":
            case "text_ansi":
            case "文本":
            case "文本型":
                return "text_ansi";
            case "text_utf8":
            case "utf8":
                return "text_utf8";
            case "ptr":
            case "pointer":
            case "指针":
                return "ptr";
            case "void":
            case "none":
            case "无":
            case "无返回值":
                return "void";
            default:
                return t;
        }
    }

    private static Dictionary<string, object> Error(string message)
    {
        var d = new Dictionary<string, object>();
        d["ok"] = false;
        d["error"] = message ?? "unknown error";
        return d;
    }

    private static object Get(Dictionary<string, object> d, string key)
    {
        object v;
        return d != null && d.TryGetValue(key, out v) ? v : null;
    }

    private static string Str(Dictionary<string, object> d, string key, string fallback)
    {
        var v = Get(d, key);
        if (v == null) return fallback;
        var s = Convert.ToString(v);
        return s == null ? fallback : s;
    }

    private static List<object> ToList(object o)
    {
        var list = new List<object>();
        if (o == null) return list;
        var arr = o as object[];
        if (arr != null) { list.AddRange(arr); return list; }
        var en = o as IEnumerable;
        if (en != null) { foreach (var x in en) list.Add(x); return list; }
        list.Add(o);
        return list;
    }

    private static int ToInt(object v)
    {
        if (v == null) return 0;
        if (v is bool) return ((bool)v) ? 1 : 0;
        if (v is string)
        {
            var s = ((string)v).Trim();
            if (s.Length == 0) return 0;
            long l;
            if (long.TryParse(s, out l)) return unchecked((int)l);
            double d;
            if (double.TryParse(s, out d)) return (int)d;
            return 0;
        }
        return Convert.ToInt32(v);
    }

    private static long ToLong(object v)
    {
        if (v == null) return 0;
        if (v is string)
        {
            var s = ((string)v).Trim();
            if (s.Length == 0) return 0;
            long parsed;
            if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase) && long.TryParse(s.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out parsed)) return parsed;
            if (long.TryParse(s, out parsed)) return parsed;
            double d;
            if (double.TryParse(s, out d)) return (long)d;
            return 0;
        }
        return Convert.ToInt64(v);
    }

    private static double ToDouble(object v)
    {
        if (v == null) return 0;
        if (v is string)
        {
            var s = ((string)v).Trim();
            if (s.Length == 0) return 0;
            double d;
            if (double.TryParse(s, out d)) return d;
            return 0;
        }
        return Convert.ToDouble(v);
    }

    private static bool ToBool(object v)
    {
        if (v == null) return false;
        if (v is bool) return (bool)v;
        if (v is string)
        {
            var s = ((string)v).Trim().ToLowerInvariant();
            return s == "1" || s == "true" || s == "yes" || s == "真";
        }
        return Convert.ToInt64(v) != 0;
    }

    private static IntPtr ToPtr(object v)
    {
        return new IntPtr(ToLong(v));
    }
}
