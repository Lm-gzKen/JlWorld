'use strict';
/** 根据 src/core/endpoints.js 生成 docs/API接口.md，保持文档与代码同步 */
const fs = require('fs');
const path = require('path');
const endpoints = require('../src/core/endpoints');

const ROOT = path.resolve(__dirname, '..');
const lines = [];
lines.push('# QQ 机器人 API v2 接口清单');
lines.push('');
lines.push('> 本文件由 `node tools/gen-api-doc.js` 自动生成，与 `src/core/endpoints.js` 保持同步。');
lines.push('> 共 ' + endpoints.length + ' 个接口，全部可在面板「接口」页直接调试，也可由插件通过 `action=endpoint` 调用。');
lines.push('> 文末另有**插件市场上传 API**（把插件 zip 发布到 VloSBoT 插件市场），不属于 QQ API。');
lines.push('');
lines.push('## 调用方式');
lines.push('');
lines.push('- 面板：直接填写参数调用，自动带上 `access_token`。');
lines.push('- 插件：`{"action":"endpoint","endpoint":"send_group_message","params":{"group_openid":"..."},"body":{...}}`');
lines.push('- 任意请求：`{"action":"api","method":"POST","path":"/v2/groups/xxx/messages","body":{...}}`');
lines.push('');
for (const group of endpoints.groups) {
  lines.push('## ' + group);
  lines.push('');
  lines.push('| 接口 | 方法 | 路径 | key |');
  lines.push('| --- | --- | --- | --- |');
  for (const e of endpoints.filter((x) => x.group === group)) {
    lines.push(`| ${e.name} | ${e.method} | \`${e.path}\` | \`${e.key}\` |`);
  }
  lines.push('');
  for (const e of endpoints.filter((x) => x.group === group)) {
    lines.push('### ' + e.name + ' · `' + e.key + '`');
    lines.push('');
    lines.push('```http');
    lines.push(e.method + ' ' + e.path);
    lines.push('```');
    lines.push('');
    if (e.params?.length) {
      lines.push('**路径参数**');
      lines.push('');
      lines.push('| 参数 | 必填 | 说明 | 示例 |');
      lines.push('| --- | --- | --- | --- |');
      for (const p of e.params) lines.push(`| \`${p.name}\` | ${p.required ? '是' : '否'} | ${p.desc} | ${p.example || '—'} |`);
      lines.push('');
    }
    if (e.query?.length) {
      lines.push('**Query 参数**');
      lines.push('');
      lines.push('| 参数 | 说明 | 示例 |');
      lines.push('| --- | --- | --- |');
      for (const q of e.query) lines.push(`| \`${q.name}\` | ${q.desc} | ${q.example || '—'} |`);
      lines.push('');
    }
    if (e.bodyExample) {
      lines.push('**请求体示例**');
      lines.push('');
      lines.push('```json');
      lines.push(JSON.stringify(e.bodyExample, null, 2));
      lines.push('```');
      lines.push('');
    }
    if (e.notes) {
      lines.push('> ' + e.notes);
      lines.push('');
    }
    if (e.docs) {
      lines.push('[官方文档](' + e.docs + ')');
      lines.push('');
    }
  }
}

/* ---------------- 文末附录：插件市场上传 API ---------------- */
lines.push('## 插件市场上传 API（VloSBoT 插件市场）');
lines.push('');
lines.push('> 把打好的插件 zip 上传/更新到 VloSBoT 插件市场（`https://vlos.jlworld.net`）。这部分不属于 QQ 机器人 API，是市场提供给插件作者的上传接口。');
lines.push('');
lines.push('### 认证与令牌');
lines.push('');
lines.push('- 请求头：`Authorization: Bearer <令牌>`。');
lines.push('- 令牌在「开发者中心 → API 令牌」生成；面板会显示**创建时间**和**最近使用**，点「重新生成」后旧令牌立刻失效。');
lines.push('- 令牌等同密码：不要写进插件代码、不要提交到仓库、不要发给别人；泄露立即重新生成。');
lines.push('');
lines.push('### 请求体');
lines.push('');
lines.push('- 请求体直接是 **zip 二进制**：`Content-Type: application/zip`，curl 用 `--data-binary "@插件.zip"`。');
lines.push('- **不要**用 `multipart/form-data`（不要 `-F`），否则会被拒绝。');
lines.push('- 单包上限 **200 MB**；同一插件同一个版本号不能重复发布，换版本号就是发新版本。');
lines.push('');
lines.push('### 接口');
lines.push('');
lines.push('| 用途 | 方法 | 地址 |');
lines.push('| --- | --- | --- |');
lines.push('| 创建新插件 | POST | `https://vlos.jlworld.net/api/v1/plugins` |');
lines.push('| 更新已有插件 | POST | `https://vlos.jlworld.net/api/v1/plugins/{插件ID}/releases` |');
lines.push('| 查看自己 + 插件 ID | GET | `https://vlos.jlworld.net/api/v1/me` |');
lines.push('');
lines.push('可选查询参数（创建/更新通用）：`name`、`author`、`summary`、`tags`、`version`、`changelog`、`filename`；不传 `name`、`version` 时自动从 zip 里解析（zip 内 `plugin.json`）。');
lines.push('');
lines.push('### 示例');
lines.push('');
lines.push('创建新插件：');
lines.push('');
lines.push('```bash');
lines.push('curl -X POST "https://vlos.jlworld.net/api/v1/plugins?name=插件名&tags=工具" \\');
lines.push('  -H "Authorization: Bearer <令牌>" \\');
lines.push('  -H "Content-Type: application/zip" \\');
lines.push('  --data-binary "@插件.zip"');
lines.push('```');
lines.push('');
lines.push('更新已有插件（换个版本号就是发新版本）：');
lines.push('');
lines.push('```bash');
lines.push('curl -X POST "https://vlos.jlworld.net/api/v1/plugins/<插件ID>/releases?version=1.2.0&changelog=修复问题" \\');
lines.push('  -H "Authorization: Bearer <令牌>" \\');
lines.push('  -H "Content-Type: application/zip" \\');
lines.push('  --data-binary "@插件.zip"');
lines.push('```');
lines.push('');
lines.push('查看自己的插件 ID：');
lines.push('');
lines.push('```bash');
lines.push('curl "https://vlos.jlworld.net/api/v1/me" -H "Authorization: Bearer <令牌>"');
lines.push('```');
lines.push('');
lines.push('### 返回');
lines.push('');
lines.push('- 成功：`{"ok":true,"plugin":{"id":"...","version":"..."},"msg":"..."}`');
lines.push('- 失败：`{"error":"原因"}`（HTTP 非 2xx）');
lines.push('');
lines.push('> 令牌状态里的「最近使用」可以判断令牌是否被外部脚本用过；怀疑泄露时重新生成，旧令牌立即失效，记得同步更新 CI/发布脚本里的令牌。');
lines.push('');

const out = path.join(ROOT, 'docs', 'API接口.md');
fs.writeFileSync(out, lines.join('\n'), 'utf8');
console.log('已生成', out, '共', endpoints.length, '个接口');
