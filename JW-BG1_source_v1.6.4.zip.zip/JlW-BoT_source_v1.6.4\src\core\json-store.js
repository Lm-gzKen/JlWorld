'use strict';
/**
 * JSON / JSONL 文件后端（storage.engine = "json"）
 * 与 db.js 暴露同名接口，由 store.js 按引擎分发：
 *   - 配置：~JlWBoT/config.json（主存）
 *   - 会话：~JlWBoT/data/sessions.json
 *   - 日志：~JlWBoT/logs/jlwbot-YYYY-MM-DD*.jsonl
 *   - 消息：~JlWBoT/data/messages-YYYY-MM-DD*.jsonl
 */
const fs = require('fs');
const path = require('path');
const U = require('./util');

const writers = new Map();
function writer(dir, name, opts) {
  const key = dir + '|' + name;
  let w = writers.get(key);
  if (!w) {
    w = new U.JsonlWriter(dir, name, opts);
    writers.set(key, w);
  }
  return w;
}

function days(dir, prefix) {
  try {
    const map = new Map();
    for (const f of fs.readdirSync(dir)) {
      if (!f.startsWith(prefix + '-') || !f.endsWith('.jsonl')) continue;
      const rest = f.slice(prefix.length + 1, -'.jsonl'.length);
      const day = rest.slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) continue;
      let size = 0;
      try {
        size = fs.statSync(path.join(dir, f)).size;
      } catch {
        /* ignore */
      }
      const cur = map.get(day) || { date: day, count: 0, size: 0 };
      cur.size += size;
      map.set(day, cur);
    }
    return [...map.values()].sort((a, b) => b.date.localeCompare(a.date));
  } catch {
    return [];
  }
}

function dayFiles(dir, prefix, day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return [];
  try {
    return fs
      .readdirSync(dir)
      .filter((f) => {
        if (!f.startsWith(prefix + '-') || !f.endsWith('.jsonl')) return false;
        const rest = f.slice(prefix.length + 1, -'.jsonl'.length);
        return rest === day || rest.startsWith(day + '-');
      })
      .map((f) => path.join(dir, f))
      .sort();
  } catch {
    return [];
  }
}

function readLines(files) {
  const out = [];
  for (const fp of files) {
    let text = '';
    try {
      text = fs.readFileSync(fp, 'utf8');
    } catch {
      continue;
    }
    for (const line of text.split('\n')) {
      const s = line.trim();
      if (!s) continue;
      try {
        out.push(JSON.parse(s));
      } catch {
        /* ignore */
      }
    }
  }
  return out;
}

function countLines(files) {
  let n = 0;
  for (const fp of files) {
    try {
      const text = fs.readFileSync(fp, 'utf8');
      for (const line of text.split('\n')) if (line.trim()) n++;
    } catch {
      /* ignore */
    }
  }
  return n;
}

function kvGet(key, fallback = null) {
  if (key !== 'config') return fallback;
  const v = U.readJson(U.p('config.json'), null);
  return v || fallback;
}

function kvGetWithTime(key) {
  if (key !== 'config') return null;
  const file = U.p('config.json');
  if (!fs.existsSync(file)) return null;
  try {
    return { value: U.readJson(file, null), updated: fs.statSync(file).mtimeMs };
  } catch {
    return null;
  }
}

function kvSet(key, value) {
  if (key === 'config') U.writeJson(U.p('config.json'), value);
}

function insertLog(rec) {
  writer(U.p('logs'), 'jlwbot', { maxFileMB: 16, keepDays: 7 }).write(rec);
}

function normalizeTs(rec) {
  let ts = Number(rec && rec.t) || 0;
  if (!(ts > 1e11)) ts = Date.parse((rec && rec.time) || '') || ts || Date.now();
  return ts;
}

function rowToLog(rec) {
  return {
    t: normalizeTs(rec),
    time: rec.time || new Date(normalizeTs(rec)).toISOString(),
    level: rec.level || 'info',
    scope: rec.scope || undefined,
    msg: rec.msg == null ? '' : String(rec.msg),
    meta: rec.meta,
  };
}

function logsByDay(day, { level = '', q = '', limit = 2000 } = {}) {
  const min = { debug: 20, info: 30, warn: 40, error: 50 }[level] || 0;
  const rank = { trace: 10, debug: 20, info: 30, warn: 40, error: 50 };
  let list = readLines(dayFiles(U.p('logs'), 'jlwbot', day)).map(rowToLog);
  if (min) list = list.filter((l) => (rank[l.level] || 30) >= min);
  if (q) list = list.filter((l) => (l.msg || '').toLowerCase().includes(q) || JSON.stringify(l.meta || {}).toLowerCase().includes(q));
  list.sort((a, b) => a.t - b.t);
  return list.slice(-Math.max(1, Number(limit) || 2000));
}

function logDates() {
  return days(U.p('logs'), 'jlwbot').map((d) => ({ date: d.date, count: countLines(dayFiles(U.p('logs'), 'jlwbot', d.date)) }));
}

function logCount(day) {
  return countLines(dayFiles(U.p('logs'), 'jlwbot', day));
}

function insertMessage(rec) {
  writer(U.p('data'), 'messages', { maxFileMB: 32, keepDays: 30 }).write(rec);
}

function rowToMessage(rec) {
  const ts = normalizeTs(rec);
  return {
    t: ts,
    time: rec.time || new Date(ts).toISOString(),
    event: rec.event || '',
    direction: rec.direction || 'in',
    kind: rec.kind || '',
    id: rec.id || '',
    content: rec.content == null ? '' : String(rec.content),
    author: rec.author || '',
    name: rec.name || '',
    accountId: rec.accountId || '',
    accountName: rec.accountName || '',
    group_openid: rec.group_openid || '',
    user_openid: rec.user_openid || '',
    channel_id: rec.channel_id || '',
    guild_id: rec.guild_id || '',
    attachments: Number(rec.attachments) || 0,
    payload: rec.payload || undefined,
  };
}

function messagesByDay(day, { account = '', limit = 2000 } = {}) {
  let list = readLines(dayFiles(U.p('data'), 'messages', day)).map(rowToMessage);
  if (account) list = list.filter((m) => m.accountId === account);
  list.sort((a, b) => a.t - b.t);
  return list.slice(-Math.max(1, Number(limit) || 2000));
}

function messageDates() {
  return days(U.p('data'), 'messages').map((d) => ({ date: d.date, count: countLines(dayFiles(U.p('data'), 'messages', d.date)) }));
}

function sessionLoadAll() {
  const raw = U.readJson(U.p('data', 'sessions.json'), {});
  return Object.entries(raw || {})
    .map(([sid, s]) => ({ ...s, sid }))
    .filter((s) => s && s.sid);
}

function sessionSaveAll(list) {
  const obj = {};
  for (const s of list) if (s && s.sid) obj[s.sid] = s;
  U.writeJson(U.p('data', 'sessions.json'), obj);
}

function pruneDir(dir, prefix, keepDays) {
  const cut = U.dayKey(new Date(Date.now() - Math.max(1, keepDays) * 86400000));
  for (const d of days(dir, prefix)) {
    if (d.date >= cut) continue;
    for (const fp of dayFiles(dir, prefix, d.date)) {
      try {
        fs.unlinkSync(fp);
      } catch {
        /* ignore */
      }
    }
  }
}

function pruneLogs(keepDays = 7) {
  pruneDir(U.p('logs'), 'jlwbot', keepDays);
}

function pruneMessages(keepDays = 30) {
  pruneDir(U.p('data'), 'messages', keepDays);
}

function checkpoint() {}
function close() {
  for (const w of writers.values()) {
    try {
      w.close();
    } catch {
      /* ignore */
    }
  }
  writers.clear();
}

module.exports = {
  kvGet,
  kvGetWithTime,
  kvSet,
  insertLog,
  logsByDay,
  logDates,
  logCount,
  insertMessage,
  messagesByDay,
  messageDates,
  sessionLoadAll,
  sessionSaveAll,
  pruneLogs,
  pruneMessages,
  checkpoint,
  close,
  normalizeTs,
  rowToLog,
  rowToMessage,
};
