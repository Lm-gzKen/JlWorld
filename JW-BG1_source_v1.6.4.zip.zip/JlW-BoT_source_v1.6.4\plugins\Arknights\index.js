'use strict';
/**
 * 明日方舟（Arknights）— JlWBoT 进程内 JS 插件
 *
 * 指令（大小写不敏感，只响应以 / 或 ／ 开头的消息）：
 *   /Arknights                    菜单（含全部指令）
 *   /Arknights 登录 手机号 密码      鹰角账号登录（建议私聊）
 *   /Arknights 登录 手机号           发送短信验证码（之后直接回 6 位数字）
 *   /Arknights 验证码 123456         用验证码完成登录（也可省略指令）
 *   /Arknights 导入 token=xxx        用已有鹰角 token 登录
 *   /Arknights 账号 / 切换 2         查看 / 切换绑定角色
 *   /Arknights 登出                  清除本机凭据
 *   /Arknights 签到                  森空岛签到（明日方舟 + 终末地）
 *   /Arknights 个人数据 [-rg -jj -jm -hd -sx -gy -all]
 *                                    个人数据卡片（常驻任务 / 招募；-all 一张长图）
 *   /Arknights 肉鸽|基建|剿灭|干员|活动|生息
 *                                    单独查询（基建=家具+基建，剿灭=剿灭+保全，干员=干员+时装）
 *
 * 数据来源：森空岛（zonai.skland.com）+ 鹰角账号（as.hypergryph.com）
 * 只在本机 data/accounts.json 保存 cred/token，回复与日志都不会输出凭据。
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const SK = require('./lib/skland');
const Service = require('./lib/service');
const { Store, MissingDependency } = require('./lib/store');
const { Renderer } = require('./lib/draw');
const C = require('./lib/card');
const CMD = require('./lib/commands');
const TPL = require('./lib/templates');

const PLUGIN_ID = 'Arknights';
const COMMAND_NAMES = new Set(['arknights', 'ark', 'ak', '方舟', '明日方舟', '森空岛']);

const DEFAULTS = {
  iconUrl: '',
  render: { enabled: true, timeoutMs: 20000, maxConcurrent: 2 },
  api: { platform: '1', vName: '1.28.0', dId: '' },
  mediaKeep: 40,
};

/** 子命令别名 → 内部键 */
const ALIASES = new Map(
  Object.entries({
    菜单: 'menu',
    menu: 'menu',
    help: 'menu',
    帮助: 'menu',
    指令: 'menu',
    功能: 'menu',
    登录: 'login',
    登陆: 'login',
    login: 'login',
    验证码: 'code',
    code: 'code',
    导入: 'import',
    import: 'import',
    登出: 'logout',
    logout: 'logout',
    账号: 'accounts',
    accounts: 'accounts',
    角色: 'accounts',
    绑定: 'accounts',
    切换: 'switch',
    switch: 'switch',
    刷新: 'refresh',
    refresh: 'refresh',
    签到: 'sign',
    sign: 'sign',
    checkin: 'sign',
    打卡: 'sign',
    个人数据: 'profile',
    个人: 'profile',
    数据: 'profile',
    名片: 'profile',
    profile: 'profile',
    me: 'profile',
    info: 'profile',
    肉鸽: 'rg',
    rouge: 'rg',
    roguelike: 'rg',
    rg: 'rg',
    家具: 'jg',
    furniture: 'jg',
    jg: 'jg',

    基建: 'jj',
    building: 'jj',
    jj: 'jj',
    剿灭: 'jm',
    campaign: 'jm',
    jm: 'jm',

    保全: 'bq',
    tower: 'bq',
    bq: 'bq',
    活动: 'hd',
    activity: 'hd',
    hd: 'hd',
    生息: 'sx',
    生息演算: 'sx',
    sandbox: 'sx',
    sx: 'sx',
    干员: 'gy',
    chars: 'gy',
    gy: 'gy',
  }),
);

const DATA_COMMANDS = {
  rg: { title: '集成战略（肉鸽）', build: C.rogueSection },
  // 家具 / 基建 合并成一张图
  jg: { title: '家具 · 基建', build: C.homeSection },
  jj: { title: '家具 · 基建', build: C.homeSection },
  // 剿灭 / 保全 合并成一张图
  jm: { title: '剿灭 · 保全', build: C.combatSection },
  bq: { title: '剿灭 · 保全', build: C.combatSection },
  hd: { title: '活动进度', build: C.activitySection },
  sx: { title: '生息演算', build: C.sandboxSection },
  gy: { title: '干员 · 时装', build: C.charSkinSections },
};

const FLAG_KEYS = new Set(Object.keys(DATA_COMMANDS));

/** 允许登录的会话类型：单聊 / 频道私信 */
const PRIVATE_KINDS = new Set(['c2c', 'dm']);

/** 需要私聊才能用的子命令 */
const PRIVATE_ONLY = new Set(['login', 'code', 'import']);

/** 登录用法（触发词跟随设置页配置） */
function loginUsage(rt) {
  const t = (key) => CMD.byKey(rt?.commands, key).trigger;
  return [
    '**登录森空岛（仅限私聊）**',
    '',
    `- 私聊发送 \`/Arknights ${t('login')} 手机号 密码\`：账号密码登录`,
    `- 私聊发送 \`/Arknights ${t('login')} 手机号\`：收到短信后**直接回 6 位数字**即可，不用再带指令`,
    `  也可以直接 \`/Arknights ${t('login')} 手机号 123456\``,
    `- 私聊发送 \`/Arknights ${t('import')} token=鹰角token\`：用已有 token 登录`,
    '',
    '⚠️ 登录指令**只能在私聊里使用**，群聊里发送不会处理（避免账号信息在群里暴露）。',
  ].join('\n');
}

function privateLoginHint(rt) {
  const t = (key) => CMD.byKey(rt?.commands, key).trigger;
  return [
    '🔒 登录只能在**私聊**里进行。',
    '',
    '请私聊机器人（点开机器人头像 → 发消息）发送：',
    `- \`/Arknights ${t('login')} 手机号 密码\` 账号密码登录`,
    `- \`/Arknights ${t('login')} 手机号\` 短信验证码登录（收到后直接回 6 位数字）`,
    '',
    `登录成功后再回群里发 \`/Arknights ${t('sign')}\`、\`/Arknights ${t('profile')}\` 即可。`,
  ].join('\n');
}

class UserError extends Error {}

/* ======================= 运行时 ======================= */

let runtime = null;
/** 待验证码登录的临时状态：userKey → { phone, at } */
const pendingCodes = new Map();
/** 进行中的用户请求：userKey:kind（防连点重复签到） */
const inflight = new Set();
/**
 * 同一条消息只处理一次：某些部署会把一个事件投递两遍（双订阅 / 重复安装），
 * 表现为「同一条指令回两条消息」，这里按 message.id 去重兜底。
 */
const DEDUPE_MS = 30000;
const SHARED_KEY = '__ARKNIGHTS_SHARED__';
// 插件报错统一前缀：框架看到这个前缀只写日志、不往聊天发
const ERROR_PREFIX = '【[404 error]';
function errText(msg) {
  return `${ERROR_PREFIX} ${String(msg === undefined || msg === null ? '' : msg).trim()}】`;
}

/**
 * 去重表挂在 globalThis 上：插件被重复加载成两个实例时也共享同一份，
 * 这样「双订阅 / 重复安装」导致的同一条消息两次回复也能被拦下。
 */
function sharedState() {
  const g = globalThis;
  const cur = g[SHARED_KEY];
  // 兼容旧版本留下的共享对象（可能只有 seen/sends，没有 live），避免 .keys() 读 undefined
  if (!cur || typeof cur !== 'object') {
    g[SHARED_KEY] = { seen: new Map(), sends: new Map(), live: new Map(), seq: 0 };
    return g[SHARED_KEY];
  }
  if (!(cur.seen instanceof Map)) cur.seen = new Map();
  if (!(cur.sends instanceof Map)) cur.sends = new Map();
  if (!(cur.live instanceof Map)) cur.live = new Map();
  if (typeof cur.seq !== 'number') cur.seq = 0;
  return cur;
}

/** 当前活着的实例里序号最大的那个（最后加载 = 配置最新），只有它负责回消息 */
function newestLiveSeq() {
  const st = sharedState();
  let best = 0;
  for (const seq of st.live.keys()) if (seq > best) best = seq;
  return best;
}

const seenMessages = sharedState().seen;
const recentSends = sharedState().sends;

function dedupeKey(message) {
  if (!message) return '';
  const id = message.id || message.msgId || message.message_id || '';
  if (id) return 'id:' + id;
  const who = userKeyOf(message);
  return 'c:' + who + ':' + String(message.cleanContent || message.content || '').slice(0, 80);
}

/** 返回 true 表示这条消息已经处理过，直接跳过 */
function alreadyHandled(message, log) {
  const key = dedupeKey(message);
  if (!key) return false;
  const now = Date.now();
  const last = seenMessages.get(key) || 0;
  if (last && now - last < DEDUPE_MS) {
    log?.warn?.('同一条消息重复投递，已跳过一次（' + key + '）');
    return true;
  }
  seenMessages.set(key, now);
  if (seenMessages.size > 200) {
    for (const [k, ts] of seenMessages) if (now - ts > DEDUPE_MS) seenMessages.delete(k);
  }
  return false;
}

/** 相同内容短时间内重复发送时返回 true（发送前拦截） */
function duplicateSend(message, content, log) {
  const key = dedupeKey(message) + '|' + String(content || '').slice(0, 120);
  const now = Date.now();
  const last = recentSends.get(key) || 0;
  if (last && now - last < 5000) {
    log?.warn?.('检测到重复发送，已拦下第二条');
    return true;
  }
  recentSends.set(key, now);
  if (recentSends.size > 100) {
    for (const [k, ts] of recentSends) if (now - ts > 5000) recentSends.delete(k);
  }
  return false;
}

/**
 * 风控冷却：森空岛返回 10000（请求异常）后，短时间内别再打接口。
 * 用户连点刷新 / 个人数据会持续加深风控，冷却期内直接给提示。
 */
const riskCooldown = new Map();
const RISK_COOLDOWN_MS = 20000;
/** 这些子指令都要打森空岛接口，冷却期内直接拦下 */
const RISK_SUBS = new Set(['sign', 'profile', 'refresh', 'rg', 'jj', 'jm', 'gy', 'hd', 'sx']);

function markRiskCooldown(userKey) {
  if (userKey) riskCooldown.set(userKey, Date.now() + RISK_COOLDOWN_MS);
}

function riskCooldownLeft(userKey) {
  const until = riskCooldown.get(userKey) || 0;
  const left = until - Date.now();
  if (left <= 0) {
    if (until) riskCooldown.delete(userKey);
    return 0;
  }
  return Math.ceil(left / 1000);
}
/** 菜单图标素材缓存：accountId|iconUrl → qqbot-media:// */
const iconMediaCache = new Map();

function ensureRuntime(ctx) {
  if (runtime) return runtime;
  const dir = ctx.plugin?.dir || __dirname;
  const rawConfig = ctx.plugin?.config && typeof ctx.plugin.config === 'object' ? ctx.plugin.config : {};
  // 判断是不是「全新未配置」的 plugin.json（被更新包覆盖过）：有指令表就说明是用户配置过的
  const freshConfig = !(Array.isArray(rawConfig.commands) && rawConfig.commands.length);
  if (freshConfig) {
    const saved = loadSettingsSnapshot(dir);
    if (Array.isArray(saved.commands) && saved.commands.length) rawConfig.commands = saved.commands;
    if (saved.replies && typeof saved.replies === 'object' && Object.keys(saved.replies).length) {
      rawConfig.replies = saved.replies;
      (ctx.log || console).info?.('已从 data/settings.json 恢复用户设置（指令表 / 回复模板）');
    }
  }
  const cfg = mergeConfig(rawConfig);
  const log = ctx.log || console;
  let store = null;
  let depMissing = '';
  try {
    store = new Store(path.join(dir, 'data'));
  } catch (e) {
    if (e?.code === 'MISSING_DEP') depMissing = e.dependency || 'VSQL';
    else throw e;
  }
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  const renderer = new Renderer({ dir, cfg: cfg.render, log });
  // 指令表：默认值 + 设置页里用户改过的触发词/备注
  const commands = CMD.resolveCommands(rawConfig);
  const commandMap = CMD.commandMap(commands);
  // rawConfig 是框架 manifest.config 的同一个对象引用：
  // 往里写 accountsView / commandsInfo，面板 /api/plugins 列表（plugins.list()）就能读到，设置页即可展示。
  runtime = { dir, cfg, rawConfig, log, store, depMissing, renderer, commands, commandMap, accountsJson: '', accountsTimer: null };
  return runtime;
}

function mergeConfig(raw) {
  const cfg = { ...DEFAULTS, ...raw };
  cfg.render = { ...DEFAULTS.render, ...(raw.render || {}) };
  cfg.api = { ...DEFAULTS.api, ...(raw.api || {}) };
  if (raw.render === false) cfg.render.enabled = false;
  return cfg;
}

function apiOpts() {
  const api = runtime?.cfg?.api || DEFAULTS.api;
  return {
    platform: String(api.platform || '1'),
    vName: String(api.vName || '1.28.0'),
    dId: String(api.dId || ''),
  };
}

/* ======================= 设置页：账号授权摘要 ======================= */

/** QQ 用户标识脱敏，只用于面板展示 */
function maskUserKey(key) {
  const s = String(key || '');
  if (!s) return '—';
  if (s.length <= 10) return `${s.slice(0, 3)}…${s.slice(-2)}`;
  return `${s.slice(0, 6)}…${s.slice(-4)}`;
}

/**
 * 生成给设置页（settings.html）看的账号摘要。
 * 注意：这里绝不能放 cred / token —— 只放登录状态、绑定角色、签到日期等展示信息。
 */
function buildAccountsView(rt) {
  const users = rt.store ? rt.store.all() : [];
  return users.map((u) => {
    const active = u.active || {};
    return {
      key: maskUserKey(u.key),
      name: u.name || '',
      phoneTail: u.phoneTail || '',
      loggedIn: !!(u.cred && u.token),
      createdAt: u.createdAt || 0,
      updatedAt: u.updatedAt || 0,
      bindings: (u.bindings || []).map((b) => ({
        game: b.game,
        gameLabel: b.game === 'endfield' ? '终末地' : '明日方舟',
        uid: b.uid,
        name: b.roleName || b.nickName || '',
        channel: b.channelName || '',
        level: b.level || '',
        active: (active[b.game] || '') === b.uid,
      })),
      lastSign: Object.entries(u.lastSign || {})
        .map(([target, rec]) => ({ target, date: rec?.date || '' }))
        .filter((x) => x.date),
    };
  });
}

/**
 * 把账号摘要写回 manifest.config（同一对象引用），面板 GET /api/plugins 就能拿到。
 * 只改内存，不写 plugin.json —— 避免把用户授权信息落到插件配置文件里。
 */
function publishAccounts(rt, { force = false } = {}) {
  try {
    if (!rt?.rawConfig || typeof rt.rawConfig !== 'object') return;
    const view = buildAccountsView(rt);
    const json = JSON.stringify(view);
    if (!force && json === rt.accountsJson) return;
    rt.accountsJson = json;
    rt.rawConfig.accountsView = view;
    rt.rawConfig.accountsUpdatedAt = Date.now();
  } catch (e) {
    rt?.log?.warn?.('同步账号摘要到设置页失败：' + (e?.message || e));
  }
}

/**
 * 把「指令表」同步给面板设置页：设置页据此渲染可编辑的【指令】列表。
 * 只写内存中的 manifest.config，不落 plugin.json。
 */
function publishCommands(rt) {
  try {
    if (!rt?.rawConfig || typeof rt.rawConfig !== 'object') return;
    rt.rawConfig.commandsInfo = (rt.commands || []).map((c) => ({
      key: c.key,
      group: c.group,
      trigger: c.trigger,
      note: c.note,
      defTrigger: c.defTrigger,
      defNote: c.defNote,
    }));
  } catch (e) {
    rt?.log?.warn?.('同步指令表到设置页失败：' + (e?.message || e));
  }
}


/* ======================= 插件入口 ======================= */
module.exports = {
  async onLoad(ctx) {
    try {
      const rt = ensureRuntime(ctx);
      const st = sharedState();
      st.seq += 1;
      const mySeq = st.seq;
      st.live.set(mySeq, Date.now());
      rt.instanceSeq = mySeq;
      if (st.live.size > 1) {
        rt.log.warn('检测到明日方舟插件有 ' + st.live.size + ' 个实例在运行（重复安装 / 面板重复启用），只让最新的实例 #' + mySeq + ' 回消息，旧的静默');
      }
      // 注册对外 API：其他 JS 插件可通过 globalThis.__JLWBOT_PLUGIN_APIS__.get('Arknights') 取到
      require('./api').bind(rt);
      // 把账号摘要 + 指令表同步给面板设置页（settings.html）
      publishAccounts(rt, { force: true });
      publishCommands(rt);
      publishReplies(rt);
      saveSettingsSnapshot(rt);
      if (rt.accountsTimer) clearInterval(rt.accountsTimer);
      rt.accountsTimer = setInterval(() => {
        publishAccounts(rt);
      }, 30000);
      if (rt.accountsTimer.unref) rt.accountsTimer.unref();
      if (rt.depMissing) {
        rt.log.error('缺少前置插件 ' + rt.depMissing + '（SQLite 存储服务）：请在面板启用 VSQL 后重载本插件，指令暂时不可用');
      } else {
        rt.log.info(`明日方舟插件已加载（存储 VSQL · shared 库 ${rt.store.dbFile || '(路径未知)'}）`);
      }
    } catch (e) {
      (ctx.log || console).error('明日方舟插件初始化失败：' + (e?.message || e));
    }
  },

  async onEvent(ctx) {
    try {
      const mySeq = runtime?.instanceSeq || 0;
      const newest = newestLiveSeq();
      if (mySeq && newest && mySeq !== newest) return null; // 旧实例：让最新配置的实例回
      if (!runtime?.store) {
        try {
          runtime.store = new Store(path.join(runtime.dir, 'data'));
          runtime.depMissing = '';
          runtime.log.info('前置插件 VSQL 已就绪，账号存储已接上');
          publishAccounts(runtime, { force: true });
        } catch (e) {
          runtime.depMissing = e?.code === 'MISSING_DEP' ? e.dependency || 'VSQL' : runtime.depMissing;
        }
      }
      if (!runtime?.store) {
        return {
          reply:
            `明日方舟插件缺少前置插件 **${runtime?.depMissing || 'VSQL'}**（SQLite 存储服务）。\n` +
            '请在面板「插件」页启用 VSQL，然后重载明日方舟插件。',
        };
      }
      if (alreadyHandled(ctx.message, (ctx.log || console))) return null;
      return await route(ctx);
    } catch (e) {
      if (e instanceof UserError) return { reply: e.message };
      const rt = ensureRuntime(ctx);
      if (e?.name === 'ServiceError') {
        rt.log.warn('明日方舟业务提示：' + (e?.message || e));
        return { reply: errText(e.message) };
      }
      if (e?.name === 'SklandError') {
        // 接口错误属于预期分支，只记一行，不打堆栈；带上业务码 / HTTP / 路径 / 时钟偏差便于定位
        const detail = [
          e?.message || e,
          Number.isFinite(e?.code) ? `code ${e.code}` : '',
          e?.status ? `HTTP ${e.status}` : '',
          e?.path || '',
          Number.isFinite(e?.clockSkew) && Math.abs(e.clockSkew) >= 60 ? `时钟偏差 ${e.clockSkew}s` : '',
        ]
          .filter(Boolean)
          .join(' · ');
        rt.log.warn('明日方舟接口错误：' + detail);
        if (Number(e?.code) === 10000) markRiskCooldown(userKeyOf(ctx.message));
        // 报错只留在框架日志/控制台，不发到群聊或私聊
        return null;
      }
      rt.log.error('明日方舟插件异常：' + (e?.stack || e));
      // 未预料的异常同样不往聊天里发，避免把堆栈/内部错误暴露给群成员
      return null;
    }
  },

  async onUnload(ctx) {
    try {
      const st = sharedState();
      st.live.delete(runtime?.instanceSeq || 0);
      // 关掉 SQLite 句柄，避免热重载时留下 -wal / 锁文件
      try {
        runtime?.store?.close?.();
      } catch {
        /* ignore */
      }
      ctx.log?.info('明日方舟插件已卸载');
    } catch {
      /* ignore */
    }
    if (runtime?.accountsTimer) {
      clearInterval(runtime.accountsTimer);
      runtime.accountsTimer = null;
    }
    try {
      require('./api').unbind();
    } catch {
      /* ignore */
    }
    runtime = null;
    pendingCodes.clear();
    iconMediaCache.clear();
  },
};

/* ======================= 设置快照 ======================= */

/**
 * 用户设置（指令表 + 回复模板）在 plugin.json 里，但更新插件时很容易被覆盖。
 * 这里额外在 data/settings.json 存一份：如果 plugin.json 是「全新未配置」的，
 * 加载时用快照恢复，做到「换版本不丢设置」。
 */
function settingsSnapshotPath(dir) {
  return path.join(dir, 'data', 'settings.json');
}

function loadSettingsSnapshot(dir) {
  try {
    const raw = fs.readFileSync(settingsSnapshotPath(dir), 'utf8');
    const j = JSON.parse(raw);
    return j && typeof j === 'object' ? j : {};
  } catch {
    return {};
  }
}

function saveSettingsSnapshot(rt) {
  try {
    const data = {
      version: 1,
      commands: Array.isArray(rt.rawConfig?.commands) ? rt.rawConfig.commands : [],
      replies: rt.rawConfig?.replies && typeof rt.rawConfig.replies === 'object' ? rt.rawConfig.replies : {},
      updatedAt: Date.now(),
    };
    fs.mkdirSync(path.join(rt.dir, 'data'), { recursive: true });
    fs.writeFileSync(settingsSnapshotPath(rt.dir), JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    rt?.log?.warn?.('保存设置快照失败：' + (e?.message || e));
  }
}

/* ======================= 回复模板 ======================= */

/** 取用户自定义模板；空串表示用内置回复 */
function replyTemplate(rt, key) {
  const raw = rt?.rawConfig?.replies;
  const md = raw && typeof raw === 'object' ? raw[key] : '';
  return typeof md === 'string' ? md.trim() : '';
}

/** 套模板：返回 markdown（空串 = 没自定义，调用方走内置回复） */
function applyTemplate(rt, key, extra) {
  const md = replyTemplate(rt, key);
  if (!md) return '';
  return TPL.render(md, Object.assign(TPL.globalVars(rt.commands), extra || {}));
}

/** 角色列表 → 文本行（模板变量 accounts 用） */
function bindingLines(list, active) {
  return (list || [])
    .map((b, i) => {
      const mark = active && active[b.game] === b.uid ? ' ✅' : '';
      return `${i + 1}. ${gameLabel(b.game)} · ${b.roleName || b.nickName || '未命名'}（UID ${b.uid}）${b.channelName ? ` · ${b.channelName}` : ''}${mark}`;
    })
    .join('\n');
}

/** 签到结果 → 模板变量 */
function signVars(result) {
  const map = {};
  const games = [];
  for (const a of result.accounts || []) {
    const g = a.game === 'endfield' ? 'endfield' : 'arknights';
    const line = formatSignLine(a);
    const title = a.game === 'endfield' ? '**终末地**' : '**明日方舟**';
    map[g + '.name'] = a.name || '未命名';
    map[g + '.uid'] = a.uid || '';
    map[g + '.status'] = a.status || '';
    map[g + '.line'] = line;
    map[g + '.awards'] = (a.awards || []).map((x) => `${x.name} ×${x.count ?? '?'}`).join('、');
    map[g + '.days'] = Number.isFinite(a.daysSigned) ? String(a.daysSigned) : '';
    map[g] = `${title} · ${map[g + '.name']}（UID ${map[g + '.uid']}）` + '\n' + line;
    games.push(map[g]);
  }
  map.games = games.join('\n\n');
  const errs = (result.accounts || []).filter((a) => a.status === 'failed');
  map.errors = errs.length ? '**失败**\n' + errs.map((a) => `- ${a.name || a.uid}：${a.message || '未知错误'}`).join('\n') : '';
  return map;
}

/** 把模板表同步给设置页（编辑器要默认模板 / 变量说明 / 预览示例值） */
function publishReplies(rt) {
  try {
    if (!rt?.rawConfig || typeof rt.rawConfig !== 'object') return;
    rt.rawConfig.repliesInfo = TPL.infoList(rt.commands);
  } catch (e) {
    rt?.log?.warn?.('同步回复模板到设置页失败：' + (e?.message || e));
  }
}

/* ======================= 路由 ======================= */

async function route(ctx) {
  const message = ctx.message;
  if (!message) return null;
  if (message.author?.bot) return null;

  const rawText = String(message.cleanContent ?? message.content ?? '').trim();

  // 验证码登录：私聊里发过 /Arknights login 手机号 后，直接回复 6 位数字即可校验，
  // 不需要再带指令；校验失败保持沉默，成功才继续（不打断正常聊天）。
  if (/^\d{6}$/.test(rawText) && PRIVATE_KINDS.has(message.kind)) {
    const key = userKeyOf(message);
    const pending = key ? pendingCodes.get(key) : null;
    if (pending && Date.now() - pending.at < 5 * 60000) {
      return handleBareCode(ctx, key, pending, rawText);
    }
  }

  if (!/^[/／]/.test(rawText)) return null;
  const command = message.command;
  if (command && command.matched === false) return null;

  const head = normalizeCommand(command?.name || firstWord(rawText));
  if (!COMMAND_NAMES.has(head)) return null;

  const rt = ensureRuntime(ctx);
  const tokens = splitTokens(command?.args?.length ? command.args : restWords(rawText));
  const { flags, words } = splitFlags(tokens);
  // 先按设置页里用户自定义的触发词匹配，再回退到内置别名
  const firstToken = words.length ? normalizeCommand(words[0]) : '';
  const sub = !firstToken ? 'menu' : rt.commandMap.get(firstToken) || ALIASES.get(firstToken) || '';

  if (!sub) return helpHint(ctx, words[0]);
  const userKey = userKeyOf(message);
  if (!userKey) return { reply: '无法识别你的用户标识，请稍后再试。' };

  // 刚被风控过就先别打接口，避免越重试越糟
  if (RISK_SUBS.has(sub)) {
    const left = riskCooldownLeft(userKey);
    if (left > 0) {
      return {
        reply:
          `森空岛刚返回「请求异常（code 10000）」，为避免加重风控请 ${left} 秒后再试。` +
          '\n如果一直这样，可看日志里的 code / HTTP 状态 / 时钟偏差。',
      };
    }
  }

  // 登录相关指令只允许私聊：群聊/频道里直接拦下，提示私聊机器人
  if (PRIVATE_ONLY.has(sub) && !PRIVATE_KINDS.has(message.kind)) {
    return sendHint(ctx, privateLoginHint(rt));
  }

  switch (sub) {
    case 'menu':
      return sendMenu(ctx);
    case 'login':
      return handleLogin(ctx, userKey, words.slice(1));
    case 'code':
      return handleCodeLogin(ctx, userKey, words.slice(1));
    case 'import':
      return handleImport(ctx, userKey, words.slice(1));
    case 'logout':
      return handleLogout(ctx, userKey);
    case 'accounts':
      return handleAccounts(ctx, userKey, flags);
    case 'switch':
      return handleSwitch(ctx, userKey, words.slice(1));
    case 'refresh':
      return handleRefresh(ctx, userKey);
    case 'sign':
      return withGuard(userKey, 'sign', () => handleSign(ctx, userKey));
    case 'profile': {
      const uidArg = words.slice(1).find((w) => /^\d{6,}$/.test(w)) || '';
      return withGuard(userKey, 'profile', () => handleProfile(ctx, userKey, flags, uidArg));
    }
    default:
      if (DATA_COMMANDS[sub]) return withGuard(userKey, 'data', () => handleData(ctx, userKey, sub, flags));
      return helpHint(ctx, words[0]);
  }
}

/** 同一用户同一类请求串行，避免连点触发重复签到 / 重复渲染 */
async function withGuard(userKey, kind, fn) {
  const id = `${userKey}:${kind}`;
  if (inflight.has(id)) return { reply: '上一个请求还在处理中，稍等几秒再试~' };
  inflight.add(id);
  try {
    return await fn();
  } finally {
    inflight.delete(id);
  }
}

/* ======================= 菜单 ======================= */

async function sendMenu(ctx) {
  const rt = ensureRuntime(ctx);
  const icon = await menuIconMarkdown(ctx, rt);
  const isPrivate = PRIVATE_KINDS.has(ctx.message?.kind);
  const cmd = (key) => `\`${('/Arknights ' + CMD.byKey(rt.commands, key).trigger).trim()}\``;
  const note = (key) => CMD.byKey(rt.commands, key).note;

  // 登录类指令只能在私聊用，群聊菜单里不列这些条目，只提示去私聊
  const account = isPrivate
    ? [
        '**账号（仅私聊）**',
        `- ${cmd('login')} 手机号 密码 — ${note('login')}`,
        `- ${cmd('login')} 手机号 — 发短信验证码，收到后直接回 6 位数字`,
        `- ${cmd('code')} 123456 — ${note('code')}`,
        `- ${cmd('import')} token=… — ${note('import')}`,
        `- ${cmd('accounts')} — ${note('accounts')}　${cmd('switch')} 2 — ${note('switch')}`,
        `- ${cmd('logout')} — ${note('logout')}`,
      ]
    : [
        '**账号**',
        '- 登录请**私聊机器人**：点开机器人头像发消息，群里发送登录指令会被拦下',
        `- ${cmd('accounts')} — ${note('accounts')}　${cmd('switch')} 2 — ${note('switch')}`,
        `- ${cmd('logout')} — ${note('logout')}`,
      ];

  const body = [
    '## 明日方舟 · 森空岛',
    '',
    ...account,
    '',
    '**签到 / 数据**',
    `- ${cmd('sign')} — ${note('sign')}`,
    `- ${cmd('profile')} — ${note('profile')}`,
    '- 参数（叠加在个人数据后）：`-rg` 肉鸽　`-jj` 家具+基建　`-jm` 剿灭+保全　`-gy` 干员+时装',
    '　`-hd` 活动　`-sx` 生息　`-all` 全部（**一张长图**，只回 1 条）　`-json` 返回原始 JSON',
    `- 单独查询：${cmd('rg')}、${cmd('jj')}、${cmd('jm')}、${cmd('gy')}、${cmd('hd')}、${cmd('sx')}`,
    `- ${cmd('refresh')} — ${note('refresh')}`,
    '',
    '**其它**',
    `- ${cmd('menu')} — ${note('menu')}`,
    '',
    '> 点击下方按钮会把指令**填入输入框**（不会直接发送），补全参数后按发送即可。',
    '> 指令与备注可在面板「编辑插件 → 设置 → 指令」里修改。',
    '> 数据来自森空岛，非实时；理智按 1 点 / 6 分钟估算。',
  ].join('\n');

  const custom = applyTemplate(rt, 'menu', {});
  const plain = custom ? stripMarkdown(custom) : plainMenu(rt, isPrivate);
  const text = custom || body;
  return sendRich(ctx, icon ? icon + '\n\n' + text : text, plain, { keyboard: menuKeyboard(rt, isPrivate) });
}

function plainMenu(rt, isPrivate = true) {
  const t = (key) => CMD.byKey(rt.commands, key).trigger;
  const login = isPrivate
    ? [
        `/Arknights ${t('login')} 手机号 密码   登录（仅限私聊）`,
        `/Arknights ${t('login')} 手机号        发送短信验证码（收到后直接回 6 位数字）`,
        `/Arknights ${t('code')} 123456      也可用指令提交验证码（仅限私聊）`,
        `/Arknights ${t('import')} token=…       用已有 token 登录（仅限私聊）`,
      ]
    : ['登录请私聊机器人（群里发送登录指令会被拦下）'];
  return [
    '明日方舟 · 森空岛',
    '',
    ...login,
    `/Arknights ${t('accounts')} / ${t('switch')} 2      查看 / 切换角色`,
    `/Arknights ${t('logout')}               清除本机凭据`,
    `/Arknights ${t('sign')}               森空岛签到（方舟 + 终末地）`,
    `/Arknights ${t('profile')}           个人数据卡片（含任务 / 招募）`,
    `/Arknights ${t('profile')} -all      全部数据（一张长图）`,
    `/Arknights ${t('jj')}               家具 + 基建（一张图）`,
    `/Arknights ${t('jm')}               剿灭 + 保全（一张图）`,
    `/Arknights ${t('rg')}|${t('gy')}|${t('hd')}|${t('sx')}`,
    `/Arknights ${t('refresh')}               重新同步绑定`,
  ].join('\n');
}

/** 键盘按钮：只把指令填进输入框（enter=false），用户补全参数后自己发送 */
function fillButton(id, label, data) {
  return {
    id: String(id),
    render_data: { label: label.slice(0, 8), visited_label: label.slice(0, 8), style: 1 },
    action: {
      type: 2,
      permission: { type: 2 },
      data,
      enter: false,
      reply: false,
      unsupport_tips: '请升级 QQ 客户端后使用按钮',
    },
  };
}

function menuKeyboard(rt, isPrivate = true) {
  // 所有按钮都是「只填入输入框」：enter=false，用户补全参数后自己发送
  const t = (key) => CMD.byKey(rt.commands, key).trigger;
  // 群聊里不挂登录按钮（登录只能私聊），私聊里挂「登录」
  const firstRow = [
    fillButton(1, t('sign'), `/Arknights ${t('sign')}`),
    fillButton(2, t('profile'), `/Arknights ${t('profile')}`),
    fillButton(3, t('accounts'), `/Arknights ${t('accounts')}`),
  ];
  if (isPrivate) firstRow.push(fillButton(4, t('login'), `/Arknights ${t('login')} `));
  return {
    content: {
      rows: [
        { buttons: firstRow },
        { buttons: [fillButton(5, t('rg'), `/Arknights ${t('rg')}`), fillButton(6, t('jj'), `/Arknights ${t('jj')}`), fillButton(7, t('jm'), `/Arknights ${t('jm')}`), fillButton(8, t('gy'), `/Arknights ${t('gy')}`)] },
        { buttons: [fillButton(9, t('hd'), `/Arknights ${t('hd')}`), fillButton(10, t('sx'), `/Arknights ${t('sx')}`), fillButton(11, '全部数据', `/Arknights ${t('profile')} -all`), fillButton(12, t('refresh'), `/Arknights ${t('refresh')}`)] },
        { buttons: [fillButton(13, t('logout'), `/Arknights ${t('logout')}`), fillButton(14, '菜单', '/Arknights')] },
      ],
    },
  };
}
/** 登录提示底部按钮：手机登录 / 密码登录 / token 登录，点击只填入指令，用户补全后再发 */
function loginKeyboard(rt) {
  const t = (key) => CMD.byKey(rt.commands, key).trigger;
  return {
    content: {
      rows: [
        {
          buttons: [
            fillButton(21, '手机登录', `/Arknights ${t('login')} `),
            fillButton(22, '密码登录', `/Arknights ${t('login')} 手机号 密码`),
            fillButton(23, 'token', `/Arknights ${t('import')} token=`),
          ],
        },
      ],
    },
  };
}

/** 菜单图标：上传到 QQ 素材库，用 qqbot-media:// 引用（外链在客户端会裂图） */
async function menuIconMarkdown(ctx, rt) {
  const url = String(rt.cfg.iconUrl || '').trim();
  if (!url) return '';
  const key = `${ctx.account?.id || ''}|${url}`;
  const cached = iconMediaCache.get(key);
  if (cached && Date.now() - cached.at < 30 * 86400000) {
    return `![明日方舟 #48px #48px](${cached.url})`;
  }
  try {
    const local = await rt.renderer.icon(url);
    if (!local) return '';
    const buffer = fs.readFileSync(local);
    const media = await uploadImageMedia(ctx, buffer, 'arknights-icon');
    if (!media?.url) return '';
    iconMediaCache.set(key, { url: media.url, at: Date.now() });
    return `![明日方舟 #48px #48px](${media.url})`;
  } catch (e) {
    rt.log.warn('菜单图标上传失败：' + (e?.message || e));
    return '';
  }
}

/* ======================= 登录 ======================= */

async function handleLogin(ctx, userKey, args) {
  const rt = ensureRuntime(ctx);
  if (!PRIVATE_KINDS.has(ctx.message?.kind)) return sendHint(ctx, privateLoginHint(rt));
  const tokenArg = pickKV(args, 'token');
  if (tokenArg) return doTokenLogin(ctx, userKey, tokenArg);
  if (!args.length) return sendHint(ctx, loginUsage(rt), { keyboard: loginKeyboard(rt) });

  const phone = args.find((a) => /^1\d{10}$/.test(a)) || '';
  if (!phone) return sendHint(ctx, '手机号格式不对，应为 11 位手机号。\n\n' + loginUsage(rt), { keyboard: loginKeyboard(rt) });
  const rest = args.filter((a) => a !== phone).join(' ').trim();

  if (rest) {
    // 已经发过验证码时，/Arknights login 手机号 123456 直接当验证码用
    const pending = pendingCodes.get(userKey);
    if (pending && pending.phone === phone && /^\d{4,8}$/.test(rest) && Date.now() - pending.at < 5 * 60000) {
      pendingCodes.delete(userKey);
      const token = await SK.loginByPhoneCode(phone, rest);
      return completeLogin(ctx, userKey, token, { phoneTail: phone.slice(-4), method: 'phone' });
    }
    return doPasswordLogin(ctx, userKey, phone, rest);
  }

  const sent = await SK.sendPhoneCode(phone);
  if (!sent.ok) return { reply: sent.msg };
  pendingCodes.set(userKey, { phone, at: Date.now() });
  return sendHint(
    ctx,
    `验证码已发送到 ${maskPhone(phone)}，5 分钟内直接回复 **6 位数字** 即可完成登录。\n` +
      '（收不到短信时改用：/Arknights login 手机号 密码）',
    { keyboard: loginKeyboard(rt) },
  );
}

/**
 * 私聊里直接回复 6 位数字验证码：
 * - 校验通过 → 继续登录并回复结果
 * - 校验失败 → 不提示（保持沉默，避免猜码和刷屏），状态保留 5 分钟可继续重试
 */
async function handleBareCode(ctx, userKey, pending, code) {
  const rt = ensureRuntime(ctx);
  try {
    const token = await SK.loginByPhoneCode(pending.phone, code);
    pendingCodes.delete(userKey);
    return completeLogin(ctx, userKey, token, { phoneTail: pending.phone.slice(-4), method: 'phone' });
  } catch (e) {
    rt.log.warn('验证码校验未通过（静默）：' + (e?.message || e));
    return null;
  }
}

async function handleCodeLogin(ctx, userKey, args) {
  const rt = ensureRuntime(ctx);
  if (!PRIVATE_KINDS.has(ctx.message?.kind)) return sendHint(ctx, privateLoginHint(rt));
  const code = (args[0] || '').replace(/\D/g, '');
  if (!/^\d{4,8}$/.test(code)) return { reply: '用法：/Arknights 验证码 123456' };
  const pending = pendingCodes.get(userKey);
  if (!pending || Date.now() - pending.at > 5 * 60000) {
    return { reply: '没有待验证的登录，请先发送：/Arknights login 手机号' };
  }
  pendingCodes.delete(userKey);
  const token = await SK.loginByPhoneCode(pending.phone, code);
  return completeLogin(ctx, userKey, token, { phoneTail: pending.phone.slice(-4), method: 'phone' });
}

async function doPasswordLogin(ctx, userKey, phone, password, note = '') {
  const token = await SK.loginByPassword(phone, password);
  return completeLogin(ctx, userKey, token, { phoneTail: phone.slice(-4), note, method: 'password', hyToken: token });
}

async function handleImport(ctx, userKey, args) {
  const rt = ensureRuntime(ctx);
  if (!PRIVATE_KINDS.has(ctx.message?.kind)) return sendHint(ctx, privateLoginHint(rt));
  const token = pickKV(args, 'token') || (args[0] && args[0].length > 40 ? args[0] : '');
  if (!token) return { reply: '用法：/Arknights 导入 token=鹰角token' };
  return doTokenLogin(ctx, userKey, token);
}

async function doTokenLogin(ctx, userKey, token) {
  const clean = String(token || '').trim().replace(/^token=/i, '');
  if (clean.length < 20) return { reply: 'token 看起来不完整，请重新复制。' };
  return completeLogin(ctx, userKey, clean, { method: 'token', hyToken: clean });
}

/** 鹰角 token → 森空岛 cred → 保存绑定 */
async function completeLogin(ctx, userKey, token, { phoneTail = '', note = '', method = '', hyToken = '' } = {}) {
  const rt = ensureRuntime(ctx);
  const opts = apiOpts();
  const code = await SK.grantOauthCode(token, opts);
  const cred = await SK.generateCred(code, opts);
  rt.store.setSession(userKey, {
    cred: cred.cred,
    token: cred.token,
    userId: cred.userId,
    phoneTail,
    method,
    hyToken: method === 'phone' ? '' : hyToken || token,
  });
  publishAccounts(rt, { force: true });
  let bindings = [];
  try {
    bindings = await refreshBindings(ctx, userKey);
  } catch (e) {
    rt.log.warn('登录后同步绑定失败：' + (e?.message || e));
  }
  const plainNote = note ? '\n' + note : '';
  if (!bindings.length) {
    return {
      reply:
        '森空岛登录成功，但没有读到绑定角色。请先在森空岛 App 绑定明日方舟 / 终末地角色，然后发送 /Arknights 刷新。' +
        plainNote,
    };
  }
  const lines = ['## 森空岛登录成功', ''];
  for (const b of bindings) {
    lines.push(`- ${gameLabel(b.game)} · ${b.roleName || b.nickName || '未命名'}（UID ${b.uid}${b.channelName ? ` · ${b.channelName}` : ''}）`);
  }
  lines.push('', '接下来可以：`/Arknights 签到`、`/Arknights 个人数据`');
  if (note) lines.push('', note);
  const listText = bindings
    .map((b) => `- ${gameLabel(b.game)} · ${b.roleName || b.nickName || '未命名'}（UID ${b.uid}${b.channelName ? ` · ${b.channelName}` : ''}）`)
    .join('\n');
  const md = applyTemplate(rt, 'login', { accounts: listText, count: String(bindings.length) });
  if (md) return sendHint(ctx, md);
  const plain = lines.join('\n').replace(/\*\*/g, '').replace(/^#+ /gm, '');
  return sendRich(ctx, lines.join('\n'), plain);
}

async function handleLogout(ctx, userKey) {
  const rt = ensureRuntime(ctx);
  const user = rt.store.get(userKey);
  if (!user || (!user.cred && !user.token)) return { reply: '你还没有登录森空岛。' };
  rt.store.clearSession(userKey);
  pendingCodes.delete(userKey);
  publishAccounts(rt, { force: true });
  const md = applyTemplate(rt, 'logout', {});
  if (md) return sendHint(ctx, md);
  return { reply: '已清除本机保存的森空岛凭据。' };
}

/* ======================= 绑定 / 账号 ======================= */

function sessionOf(userKey) {
  if (!runtime) throw new UserError('插件尚未初始化，请稍后重试。');
  try {
    return Service.session(runtime, userKey);
  } catch (e) {
    throw new UserError(e.message);
  }
}

async function refreshBindings(ctx, userKey) {
  const rt = ensureRuntime(ctx);
  const list = await Service.refreshBindings(rt, userKey);
  publishAccounts(rt);
  return list;
}

async function ensureBindings(ctx, userKey) {
  const rt = ensureRuntime(ctx);
  return Service.bindings(rt, userKey);
}

async function handleAccounts(ctx, userKey, flags) {
  const rt = ensureRuntime(ctx);
  if (!rt.store.get(userKey)?.cred) return { reply: '你还没有登录森空岛。' };
  const list = await ensureBindings(ctx, userKey);
  if (!list.length) return { reply: '没有读到绑定角色。请先在森空岛 App 绑定角色后发送 /Arknights 刷新。' };
  publishAccounts(rt);
  const active = rt.store.get(userKey).active || {};
  const lines = ['## 已绑定角色', ''];
  list.forEach((b, i) => {
    const mark = active[b.game] === b.uid ? ' ✅' : '';
    lines.push(
      `${i + 1}. ${gameLabel(b.game)} · ${b.roleName || b.nickName || '未命名'}（UID ${b.uid}）${b.channelName ? ` · ${b.channelName}` : ''}${mark}`,
    );
  });
  lines.push('', '用 `/Arknights 切换 序号` 或 `/Arknights 切换 UID` 切换当前角色。');
  const md = applyTemplate(rt, 'accounts', { accounts: bindingLines(list, active), count: String(list.length) });
  if (md) return sendHint(ctx, md);
  return sendRich(ctx, lines.join('\n'), lines.join('\n').replace(/^#+ /gm, '').replace(/✅/g, '(当前)'));
}

async function handleSwitch(ctx, userKey, args) {
  const rt = ensureRuntime(ctx);
  let list = await ensureBindings(ctx, userKey);
  if (!list.length) return { reply: '没有可切换的角色。' };
  const target = String(args[0] || '').trim();
  if (!target) {
    return { reply: '用法：/Arknights 切换 序号 或 /Arknights 切换 UID\n' + list.map((b, i) => `${i + 1}. ${b.roleName || b.nickName}（${b.uid}）`).join('\n') };
  }
  let picked = null;
  if (/^\d+$/.test(target) && target.length <= 3) {
    const idx = Number(target) - 1;
    picked = list[idx] || null;
  }
  if (!picked) picked = list.find((b) => b.uid === target) || null;
  if (!picked) return { reply: `没有找到 ${target} 对应的角色，发送 /Arknights 账号 查看列表。` };
  rt.store.setActive(userKey, picked.game, picked.uid);
  publishAccounts(rt);
  const md = applyTemplate(rt, 'switch', {
    game: gameLabel(picked.game),
    name: picked.roleName || picked.nickName || '未命名',
    uid: picked.uid,
    channel: picked.channelName || '',
  });
  if (md) return sendHint(ctx, md);
  return { reply: `已切换：${gameLabel(picked.game)} · ${picked.roleName || picked.nickName || '未命名'}（UID ${picked.uid}）` };
}

async function handleRefresh(ctx, userKey) {
  const list = await refreshBindings(ctx, userKey);
  if (!list.length) return { reply: '同步完成，但没有读到绑定角色。请先在森空岛 App 绑定角色。' };
  const lines = ['## 绑定已同步', ''];
  list.forEach((b, i) => lines.push(`${i + 1}. ${gameLabel(b.game)} · ${b.roleName || b.nickName || '未命名'}（UID ${b.uid}）`));
  const md = applyTemplate(rt, 'refresh', { accounts: bindingLines(list), count: String(list.length) });
  if (md) return sendHint(ctx, md);
  return sendRich(ctx, lines.join('\n'), lines.join('\n').replace(/^#+ /gm, ''));
}

/* ======================= 签到 ======================= */

async function handleSign(ctx, userKey) {
  const rt = ensureRuntime(ctx);
  const result = await Service.signAll(rt, userKey);
  if (!result.accounts.length) {
    return { reply: '没有找到已绑定的明日方舟 / 终末地角色。请先在森空岛 App 绑定，然后发送 /Arknights 刷新。' };
  }

  const lines = ['## 森空岛签到', ''];
  const plain = ['森空岛签到', ''];
  for (const a of result.accounts) {
    const title = a.game === 'endfield' ? '**终末地**' : '**明日方舟**';
    const line = formatSignLine(a);
    lines.push(
          `${title} · ${a.name || '未命名'}（UID ${a.uid}）`,
          ...(line.startsWith('> ') ? ['', line] : [line]),
          '',
        );
    plain.push(`${a.game === 'endfield' ? '终末地' : '明日方舟'} · ${a.name || '未命名'}（${a.uid}）`, stripMarkdown(line), '');
  }
  publishAccounts(rt);
  const md = applyTemplate(rt, 'sign', signVars(result));
  if (md) return sendHint(ctx, md);
  return sendRich(ctx, lines.join('\n'), plain.join('\n'));
}

/** 把签到结果结构化成一行文案 */
function formatSignLine(a) {
  const parts = [];
  if (a.status === 'signed') {
    const awards = (a.awards || []).map((x) => `${x.name} ×${x.count ?? '?'}`).join('、');
    parts.push(awards ? `签到成功 · 获得 ${awards}` : '签到成功');
  } else if (a.status === 'already') {
    parts.push('今日已签到');
  } else {
    parts.push(`> ${a.message || '未知错误'}`);
  }
  if (Number.isFinite(a.daysSigned)) parts.push(`本月已签 ${a.daysSigned} 天`);
  if (Array.isArray(a.tomorrowAwards) && a.tomorrowAwards.length) {
    parts.push(`明日 ${a.tomorrowAwards.map((x) => `${x.name} ×${x.count ?? '?'}`).join('、')}`);
  }
  return parts.join(' · ');
}

/* ======================= 个人数据 ======================= */

async function handleProfile(ctx, userKey, flags, uidArg) {
  const rt = ensureRuntime(ctx);
  const binding = await resolveBinding(ctx, userKey, uidArg);
  if (!binding) return null;
  const data = await fetchPlayerInfo(ctx, userKey, binding);
  if (flags.has('json')) {
    const json = JSON.stringify(data, null, 2);
    return sendRich(ctx, '```json\n' + json.slice(0, 1800) + (json.length > 1800 ? '\n…(已截断)' : '') + '\n```', json.slice(0, 1200));
  }
  if (!data || !data.status || !data.status.uid) {
    throw new UserError(
      '森空岛没有返回可用的个人数据。\n' +
        '可能是角色主页设为不公开、接口字段有变，或该 UID 不属于当前账号。\n' +
        '可以发 `/Arknights 个人数据 -json` 看原始返回。',
    );
  }
  return renderProfile(ctx, binding, data, flags);
}

async function renderProfile(ctx, binding, data, flags) {
  const rt = ensureRuntime(ctx);
  const status = data?.status || {};
  const iconPath = await rt.renderer.icon(rt.cfg.iconUrl).catch(() => '');
  const avatarPath = await rt.renderer.image(status.avatar?.url || '').catch(() => '');
  const v = C.normalize(data);
  // -all 也只用一张长图：所有面板拼在同一张卡片里，只发 1 条被动消息
  const sections = C.buildFlagSections(v, flags);
  const fallback = profileFallback(data, binding, flags);
  if (!rt.renderer.available()) return { reply: fallback };

  const spec = C.buildProfileCard(data, {
    iconPath,
    avatarPath,
    channel: binding.channelName || '',
    sections,
  });
  try {
    const img = await rt.renderer.render(spec);
    const caption = applyTemplate(rt, 'profile', {
      name: status.name || binding.roleName || '',
      uid: status.uid || binding.uid || '',
      level: status.level || '',
      game: gameLabel(binding.game),
      channel: binding.channelName || '',
      ap: status.ap ?? '',
      ap_max: status.apMax ?? '',
    });
    if (await sendCard(ctx, img, caption)) return null;
    return { reply: caption ? fallback + '\n\n' + stripMarkdown(caption) : fallback };
  } catch (e) {
    rt.log.warn('个人数据卡片渲染失败：' + (e?.message || e));
    return { reply: fallback };
  }
}

function profileFallback(data, binding, flags) {
  const v = C.normalize(data);
  const parts = [C.profileText(data, { channel: binding.channelName })];
  const sections = C.buildFlagSections(v, flags);
  for (const s of sections) parts.push('', C.sectionText(s));
  return parts.join('\n');
}

/* ======================= 单独数据查询 ======================= */

async function handleData(ctx, userKey, key, flags) {
  const rt = ensureRuntime(ctx);
  const binding = await resolveBinding(ctx, userKey, '');
  if (!binding) return null;
  const data = await fetchPlayerInfo(ctx, userKey, binding);
  if (!data || !data.status || !data.status.uid) {
    throw new UserError('森空岛没有返回可用的个人数据，可发 `/Arknights 个人数据 -json` 看原始返回。');
  }
  if (flags.has('json')) {
    // 只输出这一类数据相关的字段，方便核对真实返回（例如肉鸽到底带了哪些键）
    const sliced = sliceDataForJson(key, data);
    const json = JSON.stringify(sliced, null, 2);
    return sendRich(ctx, '```json\n' + json.slice(0, 1800) + (json.length > 1800 ? '\n…(已截断)' : '') + '\n```', json.slice(0, 1200));
  }
  const v = C.normalize(data);
  const built = DATA_COMMANDS[key].build(v);
  const sections = (Array.isArray(built) ? built : [built]).filter((s) => s && s.rows && s.rows.length);
  const subtitle = `${v.status.name || '博士'} · UID ${v.status.uid || binding.uid}${binding.channelName ? ` · ${binding.channelName}` : ''}`;
  const iconPath = await rt.renderer.icon(rt.cfg.iconUrl).catch(() => '');
  const spec = C.buildDetailCard({ title: DATA_COMMANDS[key].title, subtitle, sections, iconPath });
  const fallback = `${DATA_COMMANDS[key].title}\n${subtitle}\n\n${sections.map((s) => C.sectionText(s)).join('\n\n')}`;
  if (!rt.renderer.available()) return { reply: fallback };
  try {
    const img = await rt.renderer.render(spec);
    const tplKey = key === 'jg' ? 'jj' : key === 'bq' ? 'jm' : key;
    const caption = applyTemplate(rt, tplKey, {
      name: v.status.name || '',
      uid: v.status.uid || binding.uid || '',
      title: DATA_COMMANDS[key].title,
      channel: binding.channelName || '',
    });
    if (await sendCard(ctx, img, caption)) return null;
    return { reply: caption ? fallback + '\n\n' + stripMarkdown(caption) : fallback };
  } catch (e) {
    rt.log.warn('数据卡片渲染失败：' + (e?.message || e));
    return { reply: fallback };
  }
}

/** 数据类指令 -json 只返回相关切片，便于核对真实字段 */
function sliceDataForJson(key, data) {
  const d = data || {};
  const status = d.status || {};
  const head = { name: status.name || '', uid: status.uid || '' };
  switch (key) {
    case 'rg':
      return { ...head, rogue: d.rogue ?? null, rogueInfoMap: d.rogueInfoMap ?? null };
    case 'jg':
    case 'jj':
      return { ...head, furnitureCnt: status.furnitureCnt, building: d.building ?? null };
    case 'jm':
    case 'bq':
      return {
        ...head,
        campaign: d.campaign ?? null,
        campaignInfoMap: d.campaignInfoMap ?? null,
        tower: d.tower ?? null,
        towerInfoMap: d.towerInfoMap ?? null,
      };
    case 'hd':
      return { ...head, activity: d.activity ?? null, activityInfoMap: d.activityInfoMap ?? null };
    case 'sx':
      return { ...head, sandbox: d.sandbox ?? null };
    case 'gy':
      return {
        ...head,
        charCnt: status.charCnt,
        skinCnt: status.skinCnt,
        chars: Array.isArray(d.chars) ? d.chars.slice(0, 2) : null,
        skins: Array.isArray(d.skins) ? d.skins.slice(0, 2) : null,
        charInfoSample: pickSample(d.charInfoMap, 3),
        skinInfoSample: pickSample(d.skinInfoMap, 3),
      };
    default:
      return d;
  }
}

function pickSample(map, n) {
  if (!map || typeof map !== 'object') return null;
  const out = {};
  for (const k of Object.keys(map).slice(0, n)) out[k] = map[k];
  return out;
}

/* ======================= 数据获取 ======================= */

async function resolveBinding(ctx, userKey, uidArg) {
  const rt = ensureRuntime(ctx);
  try {
    return await Service.resolveBinding(rt, userKey, uidArg, 'arknights');
  } catch (e) {
    if (e instanceof Service.ServiceError) throw new UserError(e.message);
    throw e;
  }
}

async function fetchPlayerInfo(ctx, userKey, binding) {
  const rt = ensureRuntime(ctx);
  try {
    return await Service.playerInfo(rt, userKey, binding);
  } catch (e) {
    if (e instanceof Service.ServiceError) throw new UserError(e.message);
    throw e;
  }
}

/* ======================= 发送 ======================= */

async function sendRich(ctx, markdown, plain, opts = {}) {
  const message = ctx.message;
  const canMarkdown = ctx.api?.reply && message && (message.kind === 'group' || message.kind === 'c2c');
  if (duplicateSend(message, markdown, runtime?.log)) return null;
  if (canMarkdown) {
    const payload = { msg_type: 2, markdown: { content: markdown } };
    if (opts.keyboard) payload.keyboard = opts.keyboard;
    const r = await ctx.api.reply(message, payload);
    if (r?.ok) return null;
    if (opts.keyboard) {
      const r2 = await ctx.api.reply(message, { msg_type: 2, markdown: { content: markdown } });
      if (r2?.ok) return null;
    }
  }
  return { reply: plain || stripMarkdown(markdown) };
}

/** 纯文本类提示（登录用法等）也走 Markdown：能渲染就渲染，不支持时自动退化为去标记的纯文本 */
async function sendHint(ctx, markdown, opts = {}) {
  return sendRich(ctx, markdown, stripMarkdown(markdown), opts);
}

/** 发卡片：素材库 → Markdown 图片（可带 @）；失败回退富媒体；再失败返回 false */
async function sendCard(ctx, img, caption = '') {
  const message = ctx.message;
  if (!ctx.api?.reply || !message) return false;
  const media = await uploadImageMedia(ctx, img.buffer, 'arknights-card');
  if (media?.url) {
    const atTag =
      message.kind === 'group' && message.author?.member_openid
        ? `<qqbot-at-user id="${message.author.member_openid}" />`
        : '';
    const markdown = [atTag, `![明日方舟 #${img.width}px #${img.height}px](${media.url})`, caption].filter(Boolean).join('\n');
    const r = await ctx.api.reply(message, { msg_type: 2, markdown: { content: markdown } });
    if (r?.ok) {
      scheduleCleanup(ctx);
      return true;
    }
    ctx.log?.warn?.(`卡片 Markdown 发送失败（${r?.code ?? r?.message ?? '未知'}），尝试富媒体`);
  }
  const fileInfo = await uploadRichMedia(ctx, img.buffer);
  if (fileInfo) {
    const r = await ctx.api.reply(message, { msg_type: 7, media: { file_info: fileInfo } });
    if (r?.ok) return true;
  }
  return false;
}

/** 上传到 QQ 素材库（prepare → PUT → complete），返回 { url, id } */
async function uploadImageMedia(ctx, buffer, baseName = 'arknights-image') {
  const api = ctx.api;
  if (!api?.request || !buffer?.length) return null;
  const kind = detectImage(buffer);
  if (!kind) return null;
  const md5 = crypto.createHash('md5').update(buffer).digest('hex');
  const sha1 = crypto.createHash('sha1').update(buffer).digest('hex');
  const fileName = `${baseName}-${Date.now()}.${kind.ext}`;
  try {
    const prep = await api.request('POST', '/v2/media-images/prepare', {
      body: { file_name: fileName, file_size: buffer.length, content_type: kind.type, md5, sha1 },
    });
    if (!prep?.ok || !prep.data?.upload_id || !prep.data?.presigned_url) {
      ctx.log?.warn?.('素材 prepare 失败：' + (prep?.code ?? prep?.message ?? '未知'));
      return null;
    }
    const put = await fetch(prep.data.presigned_url, {
      method: 'PUT',
      headers: { 'Content-Type': kind.type },
      body: buffer,
    });
    if (!put.ok) {
      ctx.log?.warn?.(`素材 PUT 失败：HTTP ${put.status}`);
      return null;
    }
    const done = await api.request('POST', '/v2/media-images/complete', {
      body: { upload_id: prep.data.upload_id, md5 },
    });
    if (!done?.ok || !done.data?.url) {
      ctx.log?.warn?.('素材 complete 失败：' + (done?.code ?? done?.message ?? '未知'));
      return null;
    }
    return { url: done.data.url, id: done.data.image_id };
  } catch (e) {
    ctx.log?.warn?.('素材上传异常：' + (e?.message || e));
    return null;
  }
}

/** 富媒体（msg_type=7）兜底：file_upload 拿 file_info */
async function uploadRichMedia(ctx, buffer) {
  const api = ctx.api;
  const message = ctx.message;
  if (!api?.call || !message || (message.kind !== 'group' && message.kind !== 'c2c')) return '';
  const params = message.kind === 'group' ? { group_openid: message.group_openid } : { user_openid: message.user_openid };
  if (!params.group_openid && !params.user_openid) return '';
  const endpoint = message.kind === 'group' ? 'group_file_upload' : 'c2c_file_upload';
  try {
    const r = await api.call(endpoint, {
      params,
      body: { file_type: 1, file_data: buffer.toString('base64'), srv_send_msg: false },
    });
    if (r?.ok && r.data?.file_info) return r.data.file_info;
    ctx.log?.warn?.('富媒体上传失败：' + (r?.code ?? r?.message ?? '未知'));
  } catch (e) {
    ctx.log?.warn?.('富媒体上传异常：' + (e?.message || e));
  }
  return '';
}

function detectImage(buffer) {
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
    return { ext: 'png', type: 'image/png' };
  }
  if (buffer[0] === 0xff && buffer[1] === 0xd8) return { ext: 'jpg', type: 'image/jpeg' };
  if (buffer.slice(0, 3).toString('ascii') === 'GIF') return { ext: 'gif', type: 'image/gif' };
  if (buffer.slice(8, 12).toString('ascii') === 'WEBP') return { ext: 'webp', type: 'image/webp' };
  return null;
}

/** 素材库上限 100 张：发完异步清理，只保留最近 N 张 */
function scheduleCleanup(ctx) {
  const timer = setTimeout(() => cleanupMedia(ctx).catch(() => {}), 1500);
  if (timer.unref) timer.unref();
}

async function cleanupMedia(ctx) {
  const api = ctx.api;
  if (!api?.request) return;
  const keep = Math.max(10, Number(ensureRuntime(ctx).cfg.mediaKeep) || DEFAULTS.mediaKeep);
  const list = await api.request('GET', '/v2/media-images');
  const images = list?.ok ? list.data?.images || [] : [];
  const mine = images.filter((img) => String(img?.file_name || '').startsWith('arknights-card-'));
  if (mine.length <= keep) return;
  for (const img of mine.slice(keep)) {
    if (!img?.image_id) continue;
    try {
      await api.request('DELETE', `/v2/media-images/${encodeURIComponent(img.image_id)}/delete`);
    } catch {
      /* 清理失败不影响回复 */
    }
  }
}

/* ======================= 工具 ======================= */

function userKeyOf(message) {
  const a = message?.author || {};
  return a.union_openid || message?.user_openid || a.user_openid || a.member_openid || a.id || '';
}

function gameLabel(game) {
  return game === 'endfield' ? '终末地' : '明日方舟';
}

function normalizeCommand(name) {
  return String(name || '')
    .trim()
    .replace(/^[/／]+/, '')
    .toLowerCase();
}

function firstWord(text) {
  return String(text || '').trim().split(/\s+/)[0] || '';
}

function restWords(text) {
  return String(text || '')
    .trim()
    .split(/\s+/)
    .slice(1);
}

/** 把 "/Arknights 个人数据 -rg" 拆成 token；支持全角空格与全角减号 */
function splitTokens(args) {
  const out = [];
  for (const raw of args || []) {
    const s = String(raw).trim();
    if (!s) continue;
    // 一个参数里可能带全角空格
    for (const part of s.split(/[\u3000\s]+/)) {
      if (part) out.push(part);
    }
  }
  return out;
}

function splitFlags(tokens) {
  const flags = new Set();
  const words = [];
  for (const token of tokens) {
    const m = String(token).match(/^[-－—–]{1,2}([a-zA-Z]+)$/);
    if (m) {
      const key = m[1].toLowerCase();
      flags.add(key);
      continue;
    }
    words.push(token);
  }
  return { flags, words };
}

function pickKV(args, key) {
  for (const token of args || []) {
    const m = String(token).match(new RegExp(`^${key}[=:](.+)$`, 'i'));
    if (m) return m[1].trim();
  }
  return '';
}

function maskPhone(phone) {
  const s = String(phone || '');
  if (s.length !== 11) return s;
  return `${s.slice(0, 3)}****${s.slice(-4)}`;
}

function stripMarkdown(md) {
  return String(md || '')
    .replace(/```[a-z]*\n?/gi, '')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/^[-*]\s+/gm, '· ')
    .replace(/^>\s?/gm, '')
    .trim();
}

function friendlyError(e) {
  if (!e) return '未知错误';
  if (e?.name === 'SklandError') {
    if (e.kind === 'network') return `网络异常：${e.message}`;
    // 鹰角「一处登录、其他授权自动登出」：404 / 10000 等统一给明确提示
    if (Service.isKick(e)) return Service.KICK_MESSAGE;
    if (e.code === 10002) return '森空岛登录状态失效，请重新登录：/Arknights 登录 手机号 密码';
    if (e.code === 10001) return '森空岛凭据无效或已过期，请重新登录。';
    const codeText = Number.isFinite(e.code) ? `（code ${e.code}）` : '';
    return (e.message || '森空岛接口返回错误') + codeText;
  }
  if (e?.name === 'TimeoutError') return '请求超时，请稍后再试。';
  return `出错了：${e?.message || e}`;
}

function helpHint(ctx, word) {
  return { reply: `未知指令「${word}」。\n发送 /Arknights 查看全部指令（可在面板「编辑插件 → 设置 → 指令」里改指令词）。` };
}

module.exports._internal = {
  splitFlags,
  splitTokens,
  normalizeCommand,
  userKeyOf,
  stripMarkdown,
  formatSignLine,
  sharedState,
  newestLiveSeq,
  friendlyError,
};
