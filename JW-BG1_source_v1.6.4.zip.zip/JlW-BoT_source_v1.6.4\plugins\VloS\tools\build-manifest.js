'use strict';
/**
 * 重新生成 plugin.json（config 默认值来自 lib/defaults.js）。
 *
 * 用法：
 *   node tools/build-manifest.js
 *
 * 说明：
 *   - 源码模板里的 jlAccount.key 保持空字符串；
 *   - 部署到运行目录后，用面板「插件 → VloS → 设置」填写发奖 Key，
 *     或直接修改运行目录 plugin.json 的 config.jlAccount.key。
 */
const fs = require('node:fs');
const path = require('node:path');
const { DEFAULT_CONFIG } = require('../lib/defaults');
const pkg = require('../package.json');

const config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
config.jlAccount.key = '';

const manifest = {
  id: 'VloS',
  name: 'VloS · 聚龙世界',
  version: pkg.version,
  author: pkg.author,
  description: pkg.description,
  enabled: true,
  type: 'js',
  priority: 60,
  events: [
    'GROUP_AT_MESSAGE_CREATE',
    'GROUP_MESSAGE_CREATE',
    'C2C_MESSAGE_CREATE',
    'AT_MESSAGE_CREATE',
    'MESSAGE_CREATE',
    'DIRECT_MESSAGE_CREATE',
    'GROUP_MEMBER_ADD',
    'GROUP_MEMBER_REMOVE',
    'GROUP_JOIN_REQUEST',
    'GROUP_ADD_ROBOT',
    'GROUP_DEL_ROBOT',
  ],
  commands: [],
  timeout: 60000,
  entry: 'index.js',
  config,
};

fs.writeFileSync(path.join(__dirname, '..', 'plugin.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');
console.log(`plugin.json 已生成：${Object.keys(config).join(', ')}`);
