// 站点公开信息（首页公告 / 副标题 / 聚龙世界地址）+ 管理员改公告。
import { HttpError } from '../http.mjs';
import { isAdmin } from '../roles.mjs';

const s = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

export default function register(router) {
  router.get('/api/settings', (c) => {
    const get = (k) => {
      const r = c.store.get('SELECT value, updated FROM settings WHERE key=?', k);
      return r ? { value: r.value, updated: r.updated } : { value: '', updated: 0 };
    };
    const announcement = get('announcement');
    return {
      announcement: {
        value: announcement.value || c.cfg.announcement || '',
        updated: announcement.updated || 0,
      },
      botName: get('bot_name'),
      officialSite: c.cfg.officialSite,
      siteName: c.cfg.siteName,
      canEdit: isAdmin(c.store, c.user),
    };
  });

  // 管理员改首页公告 / 副标题（写进 settings 表，不会因为换代码文件而丢失）
  router.post('/api/admin/settings', async (c) => {
    const me = c.mustAdmin();
    const b = await c.json();
    const now = Date.now();
    const put = (k, v) =>
      c.store.run(
        `INSERT INTO settings (key, value, updated, updated_by) VALUES (?,?,?,?)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated, updated_by=excluded.updated_by`,
        k,
        v,
        now,
        me.email
      );
    if (b.announcement !== undefined) {
      const text = String(b.announcement == null ? '' : b.announcement);
      if (text.length > 20000) throw new HttpError(400, '公告太长了（上限 20000 字）');
      put('announcement', text);
    }
    if (b.botName !== undefined) put('bot_name', s(b.botName, 80));
    return { ok: true, msg: '已保存' };
  });
}
