# 天气查询 · JlWBoT 插件

> 类型 `js`（框架进程内）· 群聊查天气 / 私聊订阅每日推送 · **回复统一是图片**（富媒体）· 数据存 **VSQL** · 文案与卡片外观可在设置页改
>
> 插件 ID：`weather`　版本：`1.3.2`　目录：`~JlWBoT/plugins/weather/`

![天气卡](docs/card-preview.png)

---

## 1. 指令

| 场景 | 指令 | 作用 |
| --- | --- | --- |
| 群 / 私聊 | `/天气 城市` | 查这个城市，返回天气卡图片 |
| 私聊 | `/天气 订阅 城市` | 订阅每日推送（城市必填；时间沿用已设的，否则用 `defaultTime`） |
| 私聊 | `/天气 时间 0800` | 设每天推送时间并开启（`8:00`、`早上八点`、`晚上9点半` 都认） |
| 私聊 | `/天气 取消订阅` | 关闭推送（数据保留） |
| 私聊 | `/天气` | 已订阅看状态；没订阅看用法 |
| 群聊 | `/天气`（不带城市） | **弹群聊菜单**（图片，内容可编辑） |
| 群聊 | `/天气 订阅 …` / `/天气 时间 …` / `/天气 取消订阅` | 返回「请在私聊里操作」卡（订阅只走私聊） |

- 地名可以写到区/县：`/天气 广州 天河`、`/天气 天河区`、`/天气 广东省广州市天河区`、`/天气 浦东新区`。
- 前缀 `/`、`／` 带不带都行；`天气 广州 天河` 同样有效。
- 同名区县（朝阳、南山、西湖）按「直辖市 → 省会 → 重点城市」先验挑；打平就回一张候选卡，把可复制的指令列出来。
- 其它插件的指令（如 `订阅消息 签到 开启`）不会响应、不会抢消息。
- **群聊只开放「/天气 城市」**：不带城市就回菜单；订阅、改时间、取消订阅只有私聊能用。
- 菜单文案在设置页「回复信息」里（`menu` 私聊 / `menuGroup` 群聊），标题同理。

![群聊菜单](docs/menu-group.png)

---

## 2. 回复都是图片

![订阅成功](docs/card-subscribed.png)

每一条回复（包括订阅成功、状态、取消、报错）都是一张图：

```text
标题（可配：天气推送 · 数据源 / 天气查询 · 数据源 / 订阅成功 / …）
── 强调条
┌ 面板
│ 问候，日期 星期
│ 城市 天气
│ 温度 / 当前 / 风速 / 空气质量 / 紫外线 / 气压 / 湿度 / 日出日落
│ 宜 / 不宜 / 最近降雨
└
页脚（可配，默认是三条指令提示）
```

出图链路（零 npm 依赖，不用 canvas / sharp / 无头浏览器）：

```text
lib/card.js      天气模型 + 模板 → 绘制指令 JSON（矩形/文字/强调条）
lib/render.ps1   Windows 自带 PowerShell + GDI+ 画 PNG（微软雅黑，780×H，约 200~500ms）
lib/media.js     事件里上传（file_data base64）拿 file_info → 被动回复 msg_type=7
lib/sender.js    定时推送没事件上下文 → 本地 /plugin-api 两步：上传 + 发送
```

任何一步失败都会**自动退回同内容的纯文本**（`specToText`），不会静默丢消息。
出图不可用时设置页「出图」会标红，日志里也有说明。

> 为什么不做按钮：QQ 电脑版不支持机器人卡片/按钮的展示，私聊里按钮也不稳；页脚直接给可复制的指令更可靠。

### 定时推送走的是「主动消息」

- 推送**不带** `msg_id`，是标准主动消息（`POST /v2/users/{openid}/messages`，body 只有 `msg_type=7 + media.file_info`）。
- 所以需要「主动消息」权限；没权限时 QQ 会拒绝，插件会把 `fail_count/last_error` 写进 VSQL，并在日志里给出人话提示（见下）。
- 失败提示映射：`40034105` → 没开主动消息权限；`TOKEN_ERROR / invalid appid` → 框架 AppSecret 不对；`11321` → openid 无效；`NETWORK` → 连不上本地面板接口。

---

## 3. 安装 / 部署

### 3.1 交付包（推荐）

```text
插件\天气查询-【v1.3.2】.zip      ← 根目录就是 plugin.json，可直接「导入插件」
```

- **新机器**：面板「插件」→「导入插件」→「插件压缩包」→ 选它。装好目录是 `~JlWBoT/plugins/weather/`。
- **已有旧版**：插件卡片「更新」选这个 zip（会保留 `config` 与 `data/`）。
- `~JlWBoT/plugins/weather` 已存在时「导入」会报「插件已存在」（保护），用「更新」或先删目录。

### 3.2 从源码目录直接装

```powershell
Copy-Item -Recurse -Force "plugins\weather" "$env:USERPROFILE\Desktop\聚龙世界\QQ机器人\DSH机器人\~JlWBoT\plugins\weather"
```

### 3.3 前置条件

1. **VSQL 插件**（框架内置，`plugins/VSQL`）：数据存进 shared 库的 `weather_subs` / `weather_tasks`。没装也能跑（自动回退 `data/subs.json`），但设置页会标黄提醒，跨插件也就读不到数据了。
2. **机器人要有「主动消息」权限**：定时推送没有 `msg_id`。没开权限时发送失败，插件**不写 `lastDate`**，下一轮继续重试，错误写进 `lastError`。
3. **Windows**（出图用 PowerShell + System.Drawing）。Linux 下插件仍可用，但只会发纯文本。
4. 框架 ≥ v1.6.1（用到 `ctx.api.call` 的 endpoint、`/plugin-api/v1/action` 的 endpoint 动作、设置页消息协议）。

---

## 4. 目录结构

```text
plugins/weather/
├─ plugin.json          元数据 / 事件 / 命令 / 默认 config（含 texts、card、render）
├─ index.js             指令路由 + 定时器 + 设置页任务 + 设置页快照
├─ lib/
│  ├─ cities.js         地名 → 中国天气网 AREAID（离线 34 省/375 市/2846 区县）
│  ├─ geocode.js        Photon / open-meteo 经纬度（兜底 + 补逐小时降水）
│  ├─ weather.js        d1 / itboy / open-meteo / wttr 取数 + 成品串（宜不宜、降雨措辞）
│  ├─ texts.js          文案模板 / 卡片外观默认值 + 占位符渲染
│  ├─ card.js           卡片 → 绘制指令（含超长截断、自动配色）
│  ├─ render-image.js   Renderer（PowerShell 调用、并发限制、缓存清理）
│  ├─ render.ps1        GDI+ 绘制脚本（源自 Arknights 插件，见文件头注释）
│  ├─ media.js          事件上下文里的上传 + 图片回复
│  ├─ sender.js         定时推送（本地 /plugin-api：上传 + 发送，失败退文本）
│  ├─ store.js          VSQL 主存储（JSON 回退，两个驱动同接口）
│  ├─ subscribe.js      时间解析 + 到点判定（纯函数）
│  └─ util.js           原子写 / http / varJson / 温度解析
├─ data/
│  ├─ cities.json       离线行政区表（约 61 KB）
│  ├─ subs.json         VSQL 缺席时的回退存储（自动生成）
│  └─ cache/cards/      出图缓存（1 小时后自动清）
├─ tools/build-cities.js 重新生成 cities.json（只有要更新城市表时才跑）
├─ settings.html        面板设置页（订阅表 / 文案编辑 / 卡片外观 / 参数 / 任务）
├─ api.html             对外接口文档（面板「API」按钮打开）
├─ docs/*.png           预览图
├─ README.md
└─ test/
   ├─ run.js            自检 180 项（不联网、不出图）：时间/分钟调度/城市/指令/成品串/文案/卡片/存储/富媒体/入口
   ├─ e2e.js            端到端 56 项：真实取数 + 真实出图 + 菜单 + 每分钟调度（含 8 人同分钟无上限）
   ├─ check-web.js      前端语法 + manifest 一致性
   └─ check-package.js  交付包校验（按「导入插件」的 zip 规则）
```

---

## 5. 数据存储（VSQL）

```sql
-- 一个人一条订阅
weather_subs(openid PK, account_id, code, display, province, city, district,
             lat, lon, time, enabled, last_date, last_time,
             push_count, fail_count, last_error, created, updated)

-- 设置页任务执行记录（同 id 只执行一次）
weather_tasks(id PK, action, openid, at, ok, message)
```

- 落库走 `vsql.db()` 的 shared 库，**每次操作重新取句柄**（VSQL 重载会关掉旧句柄，缓存句柄会抛 `DB_CLOSED`）。
- 其它插件可以直接读：`vsql.db().all('SELECT * FROM weather_subs')`。
- 删除/改写某人的订阅：直接改表，或在设置页点「暂停 / 删除」。
- VSQL 没启用时回退 `data/subs.json`（先写 `.tmp` 再 rename，不持有文件句柄），设置页会显示 `JSON` 并给出提示。

---

## 6. 文案与卡片外观（都能改）

设置页分成 **三个页面**（顶部页签切换，也支持 `#settings` / `#subs` / `#reply`）：

1. **设置** —— 运行状态 / 卡片外观 / 运行参数 / 任务记录；
2. **订阅列表** —— 谁订了哪个城市、每天几点、上次推送、累计失败，带「测试 / 暂停 / 删除」；
3. **回复信息** —— 30 条文案模板（含群聊菜单与私聊菜单）。

改完点右上角「保存设置」，写入 `plugin.json` 并重载插件。

**占位符**（`config.texts` 里用）：

```text
{greet} {date} {week} {city} {district} {display} {text} {high} {low} {temp} {feels}
{wind} {quality} {aqi} {uv} {pressure} {humidity} {sun} {sunrise} {sunset}
{good} {bad} {rain} {src} {alarm} {code} {time} {status} {firstAt}
{query} {options} {input} {message}
```

规则：

- 未知占位符 → 空串；缺数据的字段会显示 `暂无数据`（风速/空气质量/紫外线那几行为成品串）。
- 正文按行渲染，行数决定卡片高度；连续空行最多保留一行。
- 以 `宜：` / `不宜：` / `⚠` / `数据源：` 开头的行自动上色（绿/红/黄/灰），其余用正文色。
- 卡片外观可调：宽度（480–1440）、圆角、字体、正文/背景/面板/强调色、页脚文案。
- 「全部恢复默认文案」按钮用插件内置的 `DEFAULT_TEXTS`（快照里的 `defaults`）。

**默认文案长这样**（`config.texts.weather`）：

```text
{greet}，{date} {week}

{city} {text}
温度：{low}℃ ~ {high}℃
当前：{temp}℃
风速：{wind}
空气质量：{quality}
紫外线：{uv}
气压：{pressure}
湿度：{humidity}
日出日落：{sun}

宜：{good}
不宜：{bad}
最近降雨：{rain}
```

---

## 7. 数据源与容错

| 优先级 | 源 | 用途 | 需要 |
| --- | --- | --- | --- |
| 1 | `d1.weather.com.cn/weather_index/<AREAID>.html` | 中国天气网区县级：当前温湿度/风(含 km/h)/气压/能见度/AQI、今日天气、7 天、预警、生活指数 | AREAID |
| 2 | `t.weather.itboy.net/api/weather/city/<AREAID>` | 中文天气、日出日落、感冒提示、7 天（补 1 的空缺） | AREAID |
| 3 | `api.open-meteo.com/v1/forecast` | 逐小时降水（几小时后下雨）、紫外线、体感、风速 km/h | 经纬度 |
| 4 | `wttr.in/<名字>?format=j1&lang=zh` | 前三个全挂时兜底 | 地名 |

- **区县级定位靠离线表**：中国天气网「按名字查代码」接口已失效，open-meteo/GeoNames 也查不到中文区县名，所以 3221 条三级行政区表直接打进 `data/cities.json`。
- 经纬度只在订阅时顺手取一次（Photon，认中文区县名），用来补逐小时降水与紫外线；拿不到不影响主卡片。
- 经纬度只补「降水/紫外线/体感」，不覆盖中国天气网的温度（`looksLike()` 会在明显不是同一地时直接丢弃）。
- 缓存默认 10 分钟：同城多人同时到点只打一次接口。
- 全挂时用 24 小时内的旧缓存并在卡片上加一行「接口暂时不通」；连缓存都没有就发一张「这次没查成」卡。

**宜 / 不宜**是按天气 + 紫外线 + 空气质量本地推的（不是黄历），规则与参考插件 `wx_finalize` 一致：

| 天气 | 宜 | 不宜 |
| --- | --- | --- |
| 雷 | 室内活动、看电影 | 户外运动、使用电器 |
| 雪 | 赏雪、室内活动 | 骑车、户外久留 |
| 雨 | 室内活动、备好雨具 | 户外运动、晾晒 |
| 雾/霾/尘/沙 | 室内活动、戴口罩 | 晨练、开窗通风 |
| 晴 | 户外活动、晾晒被褥 | UV≥6 长时间暴晒，否则贪凉 |
| 云/阴 | 出行、运动 | 晒被子 |
| 补充 | — | UV≥8 加「不涂防晒」；AQI>150 改「户外运动（空气差）」 |

**最近降雨**：有逐小时数据时按降水段说「2 小时后开始小雨（约 2 小时）」「今天没有降雨/降雪」；没有逐小时数据时按今日天气措辞；低温（≤2℃）或雪天用「降雪」。

---

## 8. 每分钟调度（不补推、不重试）

- 调度固定 **每分钟整点** 检查一次（加载那一刻也会先按当前分钟检查一次）
- 参数：`TICK_MS = 60000`，加载后先对齐到下一个整分，不会跟整分错位）。
- 每一轮只看一件事：**「推送时间 == 当前这一分钟」的订阅**，有就推，没有就直接跳过。
- 结果只有这几种：

| 情况 | 行为 |
| --- | --- |
| 当前分钟有订阅、今天没推过 | 推，**人数无上限**（并发 4 路取数 + 出图；同一分钟再多人也会全部处理） |
| 当前分钟没有订阅 | 什么都不做，等下一分钟 |
| 这一分钟没推完（并发队列还没跑完） | 仍在同一分钟就继续；跨分钟即作废（不补推） |
| 框架停机 / 插件停用错过的那一分钟 | **不补推**，恢复后只看新的当前分钟 |
| 发送失败（没权限 / 网络 / QQ 报错） | 记 `failCount` + `lastError`，**这一条当天算处理完，不重试** |
| 设时间/订阅那一刻 | **不预写** `lastDate`；到点只看「当前分钟」，所以设完当天的那个点就能推 |
| 本分钟已经推过（`lastDate` = 今天且 `lastTime` = 当前分钟） | 不重复推；同一天改了时间，新的那一分钟照样会推 |

> v1.2.0 行为变更：v1.1.0 及更早是「每 20 秒扫一遍 + 错过补推 + 失败下一轮重试」，
> 现在改成严格的「按当前分钟匹配」——宁可漏，也不补发。

## 9. 配置项

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `fetchTimeoutMs` | 6000 | 单次取数超时 |
| `sendTimeoutMs` | 30000 | 推送超时 |
| `cacheTtlMs` | 600000 | 天气缓存（0=不缓存） |
| `defaultTime` | `0800` | 订阅时给的默认时间 |
| `geocodeOnSubscribe` | `true` | 订阅时是否顺手取经纬度（关掉就没有逐小时降水/紫外线） |
| `render.enabled` | `true` | 出图开关（关掉后全部走纯文本） |
| `render.timeoutMs` | 20000 | 单张出图超时 |
| `render.maxConcurrent` | 2 | 同时出图数量 |
| `texts.*` | 见 `plugin.json` | 每条回复的标题 + 正文模板 |
| `card.*` | 见 `plugin.json` | 宽度/圆角/字体/配色/页脚 |
| `tasks` | `[]` | 设置页任务队列（`del / enable / disable / test`） |

---

## 10. 自测

```powershell
# 纯逻辑自检（180 项：时间解析、分钟调度判定、城市解析、指令解析、成品串、文案模板、卡片 spec、
#                JSON 存储、VSQL 存储（用 node:sqlite 冒充 VSQL）、富媒体回复、插件入口）
node plugins\weather\test\run.js

# 端到端（56 项）：真实取数 + 真实出图 + 菜单 + 每分钟调度，跑完在 test\output\ 留下 10 张卡片 PNG
node plugins\weather\test\e2e.js
node plugins\weather\test\e2e.js --json      # 强制走 JSON 回退再跑一遍

# 前端资源语法 + manifest 一致性
node plugins\weather\test\check-web.js

# 交付包校验
node plugins\weather\test\check-package.js "插件\天气查询-【v1.3.2】.zip"
```

---

## 11. 排障

| 现象 | 原因 / 处理 |
| --- | --- |
| 发指令没反应 | ① 先确认你私聊的是**这个实例连上的机器人**（看面板账户是否 online；日志里 `invalid appid or secret` 说明该账户连不上，收不到消息）；② 面板日志搜 `plugin:weather`；③ 群里要 `/天气 …` 开头 |
| 订了但到点没推 | 设置页「订阅列表」看那条的上次推送/失败次数与「最近错误」；常见：没开主动消息权限、AppSecret 不对、openid 失效 |
| 设了 17:16，17:16 却没推 | v1.3.2 之前的版本会在设时间时预写「今天已推」，把当天 17:16 那次挡掉。升级后**重新设一次时间**（或换个下一分钟）即可 |
| 回复是文字不是图片 | 设置页「出图」标红 = PowerShell/GDI+ 不可用（非 Windows、被安全软件拦、`render.enabled=false`）；日志有「出图失败」原因 |
| 图片发不出去 | 上传失败会退文本；常见是「主动消息」权限或该机器人不支持富媒体（日志里有 code/message） |
| 到点没推 | 看设置页「最近错误」：`TOKEN_ERROR`（AppID/Secret）、权限错误（没开主动消息）、`lastDate` 是不是已是今天 |
| 存储显示 JSON | 没装/没启用 VSQL：装好 VSQL 后重载天气插件即可，旧 JSON 数据会保留但不自动迁移（可手工搬） |
| 地名认不出 | 表里没有（乡镇/街道/新地标）：写到区县再试，插件也会退回 Photon 地理编码 |
| 时间设不上 | 只认 `0800 / 8:00 / 8点 / 八点 / 早上八点 / 下午两点十八分 / 晚上9点半 / 2130`；非法会回「这个时间没认出来」卡 |
| 温度/降雨对不上 | 温度来自中国天气网，逐小时降水来自 open-meteo，两个源本来会差一点；以中国天气网为准 |
| 多账户发错号 | 订阅记录里的 `account_id` 决定用哪个机器人发 |
| 删插件报文件占用 | 本插件不持有文件句柄；真遇到是别的插件（见项目 README 坑 27） |

---

## 12. 打包发布

```powershell
$stage = "tmp\pack\weather"
Remove-Item -Recurse -Force tmp\pack -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $stage | Out-Null
Copy-Item -Recurse -Force plugins\weather\* $stage
# 别把运行期数据打进去
Get-ChildItem -Path $stage -Recurse -File | Where-Object { $_.Name -match '^(subs\.json|.*\.log|.*\.tmp)$' } | Remove-Item -Force
Remove-Item -Recurse -Force "$stage\data\cache","$stage\test\output" -ErrorAction SilentlyContinue

Compress-Archive -Path "$stage\*" -DestinationPath "插件\天气查询-【v1.3.2】.zip" -CompressionLevel Optimal -Force
node plugins\weather\test\check-package.js "插件\天气查询-【v1.3.2】.zip"
```

发版前同步三处版本号：`plugin.json#version`、`index.js` 的 `PLUGIN_VERSION`、包名 `【v…】`（`check-web.js` 会校验前两者一致）。

---

## 13. 与参考插件（`查询_天气` · VloSBoT 32 位 C DLL）的对应关系

参考实现是另一套框架的 C 插件 DLL（自建 107 端口监听 + `plugins_list/up/down` 导出），本插件跑在 JlWBoT 的 `type: js` 通道。
**产品行为对齐，实现形态按本框架重写**：

| 能力 | 参考实现 | 本插件 |
| --- | --- | --- |
| 私聊订阅 | ini 文件 + 私聊指令 | VSQL `weather_subs` + `/天气 订阅 / 时间 / 取消订阅` |
| 群聊查询 | 参考实现只做私聊 | **新增**：群 `/天气 城市` 查天气 |
| 回复形态 | Markdown + QQ 按钮 | **图片**（GDI+ 出图 + 富媒体 msg_type=7），页脚给可复制指令 |
| 城市定位 | 50 城表 + 在线地理编码 | 3221 条离线三级表 + Photon 兜底 |
| 取数 | open-meteo 打底 + itboy 覆盖 + wttr 兜底 | d1 打底 + itboy 补 → open-meteo 补降水/UV → wttr 兜底 |
| 宜 / 不宜 | `wx_finalize` 按天气+UV+AQI 推 | 同一套规则（见第 7 节表格） |
| 到点 / 补推 | `sub_due`（今天已推 / 过点补推 / 停机补推 / 超限只推进度） | v1.2.0 起改为 `dueNow`：只看当前分钟，**不补推、失败不重试** |
| 文案可编辑 | 编辑 DLL 源码 | `config.texts` / `config.card`，设置页直接改模板 |
| 存储 | 每人一个 `.ini` | VSQL shared 库（跨插件可读） |
| 观测 | `天气.log` + 自检脚本 | 面板日志 `plugin:weather` + 设置页统计/任务记录 + 4 个自测脚本 |
