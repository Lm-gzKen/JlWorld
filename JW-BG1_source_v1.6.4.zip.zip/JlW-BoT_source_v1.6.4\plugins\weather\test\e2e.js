'use strict';
/**
 * 天气查询 · 端到端联调（真实取数 + 真实出图；不会真的发 QQ 消息）
 *
 *   node plugins/weather/test/e2e.js            # 用 VSQL 假后端（node:sqlite）
 *   node plugins/weather/test/e2e.js --json     # 强制走 JSON 回退
 *
 * 会把每条指令真正走一遍：解析 → 取数 → 出图 → 「上传」（这里只截下 PNG，不真的上传）。
 * 生成的图片保存在 test/output/*.png，方便肉眼看排版。
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const index = require('../index');

function currentMinute(offset = 0) {
  const d = new Date(Date.now() + offset * 60000);
  return String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0');
}

let pass = 0;
let fail = 0;
const saved = [];

function ok(cond, name, extra) {
  if (cond) {
    pass++;
    console.log('  ✓ ' + name + (extra ? '（' + extra + '）' : ''));
  } else {
    fail++;
    console.log('  ✗ ' + name + (extra ? ' —— ' + extra : ''));
  }
  return !!cond;
}

function installFakeVsql() {
  const { DatabaseSync } = require('node:sqlite');
  const raw = new DatabaseSync(':memory:');
  const db = {
    exec: (sql) => raw.exec(sql),
    run: (sql, ...p) => raw.prepare(sql).run(...p),
    get: (sql, ...p) => raw.prepare(sql).get(...p),
    all: (sql, ...p) => raw.prepare(sql).all(...p),
    info: () => ({ file: ':memory:' }),
    namespace: 'shared',
  };
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VSQL', { isReady: () => true, db: () => db, version: 'test' }]]);
  return raw;
}

(async () => {
  const useJson = process.argv.includes('--json');
  const raw = useJson ? null : installFakeVsql();

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wx-e2e-'));
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  // 模拟「装好的插件目录」：出图脚本必须在 <插件目录>/lib/render.ps1
  fs.mkdirSync(path.join(dir, 'lib'), { recursive: true });
  fs.copyFileSync(path.join(__dirname, '..', 'lib', 'render.ps1'), path.join(dir, 'lib', 'render.ps1'));
  fs.writeFileSync(
    path.join(dir, 'settings.html'),
    '<!-- WX_DATA_START -->\n<script id="wx-data" type="application/json">{}</script>\n<!-- WX_DATA_END -->',
    'utf8',
  );
  const outDir = path.join(__dirname, 'output');
  fs.mkdirSync(outDir, { recursive: true });

  const logs = [];
  const uploads = [];
  const replies = [];
  const log = {
    info: (m) => logs.push(['info', m]),
    warn: (m) => logs.push(['warn', m]),
    error: (m) => logs.push(['error', m]),
    debug: () => {},
  };

  const makeCtx = (kind = 'c2c') => ({
    plugin: { id: 'weather', dir, config: { checkSeconds: 300, cacheTtlMs: 0 } },
    config: {
      get: (k, d) => {
        if (k === 'server.port') return 9; // 没有服务：主动推送一定失败，用来验证记账
        if (k === 'server.host') return '127.0.0.1';
        if (k === 'plugins.token') return 'dummy';
        return d;
      },
    },
    log,
    account: { id: 'acciot33', name: '测试机器人' },
    bot: { sendC2C: async () => ({ ok: false, code: 'NO_NET', message: '测试环境不发真消息' }) },
    message: kind === 'group' ? { kind: 'group', group_openid: 'G1' } : { kind: 'c2c', user_openid: 'E2E_OPENID' },
    api: {
      call: async (endpoint, opts) => {
        const b64 = opts && opts.body && opts.body.file_data;
        if (b64) {
          uploads.push({ endpoint, params: opts.params, size: Buffer.from(b64, 'base64').length, b64 });
        }
        return { ok: true, data: { file_info: 'FILEINFO-' + uploads.length } };
      },
      reply: async (message, content) => {
        replies.push({ kind: message.kind, content });
        return { ok: true, data: { id: 'MSG' + replies.length } };
      },
    },
  });

  const ctx = makeCtx('c2c');
  await index.onLoad(ctx);
  ok(logs.some((l) => /已加载/.test(l[1])), 'onLoad 打日志');
  ok(logs.some((l) => new RegExp(useJson ? '存储 JSON' : '存储 VSQL').test(l[1])), '存储驱动正确', useJson ? 'JSON' : 'VSQL');
  ok(logs.some((l) => /出图 可用/.test(l[1])), '出图可用');
  {
    const snapHtml = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
    const sm = snapHtml.match(/<script id="wx-data" type="application\/json">([\s\S]*?)<\/script>/);
    const snap = JSON.parse(sm[1]);
    ok(snap.runtime && snap.runtime.running === true, 'onLoad 后快照显示调度运行中');
  }

  const send = async (text, kind = 'c2c') => {
    const c = makeCtx(kind);
    const msg =
      kind === 'group'
        ? { kind: 'group', group_openid: 'G1', cleanContent: text, content: text, author: { member_openid: 'M1' } }
        : { kind: 'c2c', user_openid: 'E2E_OPENID', cleanContent: text, content: text, author: { user_openid: 'E2E_OPENID' } };
    // 真实框架里 ctx.message 与 evt.message 是同一个对象，这里保持一致
    c.message = msg;
    const evt = { name: kind === 'group' ? 'GROUP_MESSAGE_CREATE' : 'C2C_MESSAGE_CREATE', accountId: 'acciot33', message: msg };
    const before = uploads.length;
    const out = await index.onEvent(c, evt);
    const up = uploads.length > before ? uploads[uploads.length - 1] : null;
    return { out, up };
  };

  const savePng = (name, up) => {
    if (!up) return null;
    const file = path.join(outDir, name + '.png');
    fs.writeFileSync(file, Buffer.from(up.b64, 'base64'));
    saved.push(file);
    return file;
  };

  // 0) 私聊 /天气（未订阅）→ 菜单；群聊 /天气 → 群菜单
  let r = await send('/天气');
  savePng('00-menu-c2c', r.up);
  ok(r.out && Array.isArray(r.out.replies) && r.out.replies[0].type === 'media', '私聊 /天气（未订阅）→ 菜单图片');
  r = await send('/天气', 'group');
  savePng('00-menu-group', r.up);
  ok(r.out && Array.isArray(r.out.replies), '群聊 /天气 → 群菜单图片');

  // 1) 私聊查天气
  r = await send('/天气 广州 天河');
  let file = savePng('01-query-c2c', r.up);
  ok(r.out && Array.isArray(r.out.replies) && r.out.replies[0].type === 'media', '私聊查询 → 返回图片（media）');
  ok(r.up && r.up.endpoint === 'c2c_file_upload', '单聊用 c2c_file_upload', r.up && r.up.endpoint);
  ok(r.up && r.up.size > 5000, 'PNG 大小合理', r.up ? r.up.size + 'B' : '');
  ok(file && fs.existsSync(file), '图片已落盘', file && path.basename(file));

  // 2) 群聊查天气
  r = await send('/天气 深圳 南山', 'group');
  savePng('02-query-group', r.up);
  ok(r.out && Array.isArray(r.out.replies) && r.out.replies[0].type === 'media', '群聊查询 → 返回图片');
  ok(r.up && r.up.endpoint === 'group_file_upload', '群聊用 group_file_upload', r.up && r.up.endpoint);

  // 3) 订阅
  r = await send('/天气 订阅 广州 天河');
  savePng('03-subscribed', r.up);
  ok(r.out && Array.isArray(r.out.replies), '订阅成功 → 图片');
  {
    const store = require('../lib/store').openStore({ dir, log });
    const sub = store.get('E2E_OPENID');
    ok(sub && sub.enabled === true, '订阅已写入存储');
    ok(sub && sub.code === '101280109', '订阅记下 AREAID', sub && sub.code);
    ok(sub && /^\d{4}$/.test(sub.time), '订阅给了默认时间', sub && sub.time);
  }

  // 4) 设时间
  r = await send('/天气 时间 晚上9点半');
  savePng('04-timeset', r.up);
  ok(r.out && Array.isArray(r.out.replies), '设时间 → 图片');
  {
    const store = require('../lib/store').openStore({ dir, log });
    const sub = store.get('E2E_OPENID');
    ok(sub && sub.time === '2130', '时间存成 2130', sub && sub.time);
  }

  // 5) 状态
  r = await send('/天气');
  savePng('05-status', r.up);
  ok(r.out && Array.isArray(r.out.replies), '/天气（已订阅）→ 状态图片');

  // 6) 群聊订阅 → 提示去私聊
  r = await send('/天气 订阅 广州 天河', 'group');
  savePng('06-group-only', r.up);
  ok(r.out && Array.isArray(r.out.replies), '群里订阅 → 图片提示');

  // 7) 认不出的地名
  r = await send('/天气 火星表面');
  ok(r.out && Array.isArray(r.out.replies), '认不出地名 → 图片提示');

  // 8) 非法时间
  r = await send('/天气 时间 99:99');
  ok(r.out && Array.isArray(r.out.replies), '非法时间 → 图片提示');

  // 9) 无关消息 / 旧指令
  ok((await send('你好')).out == null, '无关消息不回复');
  ok((await send('/订阅消息 天气 开启')).out == null, '旧指令不再响应');

  // 10) 取消订阅
  r = await send('/天气 取消订阅');
  savePng('07-cancelled', r.up);
  ok(r.out && Array.isArray(r.out.replies), '取消订阅 → 图片');
  {
    const store = require('../lib/store').openStore({ dir, log });
    const sub = store.get('E2E_OPENID');
    ok(sub && sub.enabled === false, '取消后 enabled=false');
  }

  // 11) 每分钟调度：把订阅时间改成「当前分钟」，tick 一次应该推出去（用本地假 action 服务接包）
  const http = require('node:http');
  const pushes = [];
  const fake = http.createServer((req, res) => {
    if (req.method !== 'POST' || !req.url.startsWith('/plugin-api/v1/action')) {
      res.writeHead(404);
      return res.end('no');
    }
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      let body = {};
      try {
        body = JSON.parse(raw);
      } catch {
        /* ignore */
      }
      const action = { endpoint: body.endpoint, params: body.params, body: body.body };
      pushes.push(action);
      const fileInfo = 'FI_PUSH';
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, results: [{ ok: true, endpoint: body.endpoint, data: { file_info: fileInfo } }] }));
    });
  });
  await new Promise((r2) => fake.listen(0, '127.0.0.1', r2));
  const fakePort = fake.address().port;

  const minuteNow = currentMinute();

  await index.onUnload();
  const ctx3 = makeCtx('c2c');
  ctx3.config = {
    get: (k, d) => {
      if (k === 'server.port') return fakePort;
      if (k === 'server.host') return '127.0.0.1';
      if (k === 'plugins.token') return 'dummy';
      return d;
    },
  };
  ctx3.plugin = { ...ctx3.plugin, config: { cacheTtlMs: 0 } };
  await index.onLoad(ctx3);
  {
    const store = require('../lib/store').openStore({ dir, log });
    store.upsert({ openid: 'E2E_OPENID', accountId: 'acciot33', code: '101280109', display: '广东·广州·天河', city: '广州', district: '天河', time: minuteNow, enabled: true, lastDate: '' });
  }
  await index.tick();
  {
    const store = require('../lib/store').openStore({ dir, log });
    const sub = store.get('E2E_OPENID');
    ok(pushes.length >= 2, '每分钟调度 → 上传 + 发送两个动作', pushes.map((p) => p.endpoint).join(' → '));
    ok(pushes[0] && pushes[0].endpoint === 'c2c_file_upload', '先上传图片');
    ok(pushes[1] && pushes[1].endpoint === 'send_c2c_message', '再发送图片');
    ok(pushes[1] && pushes[1].body && pushes[1].body.msg_type === 7, '发送用 msg_type=7');
    ok(pushes[1] && pushes[1].body && pushes[1].body.media && pushes[1].body.media.file_info === 'FI_PUSH', '带 file_info');
    ok(sub && sub.lastDate === new Date().toISOString().slice(0, 10), '推送成功后 lastDate = 今天', sub && sub.lastDate);
    ok(sub && sub.lastTime === minuteNow, '记下推送时间', sub && sub.lastTime);
    ok(sub && sub.pushCount === 1, 'pushCount +1', sub && String(sub.pushCount));
    const pngBody = pushes[0] && pushes[0].body && pushes[0].body.file_data;
    if (pngBody) {
      const file = path.join(outDir, '08-minute-push.png');
      fs.writeFileSync(file, Buffer.from(pngBody, 'base64'));
      saved.push(file);
      ok(fs.statSync(file).size > 5000, '推送图片落盘', file && path.basename(file));
    } else ok(false, '推送图片落盘');

    // 同一分钟再跑一次：今天已推过 → 不再推
    const before = pushes.length;
    await index.tick();
    ok(pushes.length === before, '同一天同一分钟不会重复推');
  }

  // 12) 发送失败：不补推、不重试（lastDate 也写今天）
  await index.onUnload();
  const ctx4 = makeCtx('c2c');
  ctx4.config = { get: (k, d) => (k === 'server.port' ? 9 : k === 'server.host' ? '127.0.0.1' : k === 'plugins.token' ? 'dummy' : d) };
  ctx4.plugin = { ...ctx4.plugin, config: { cacheTtlMs: 0 } };
  await index.onLoad(ctx4);
  {
    const store = require('../lib/store').openStore({ dir, log });
    store.upsert({ openid: 'E2E_FAIL', accountId: 'acciot33', code: '101280109', display: '广东·广州·天河', city: '广州', district: '天河', time: currentMinute(), enabled: true, lastDate: '' });
  }
  await index.tick();
  {
    const store = require('../lib/store').openStore({ dir, log });
    const sub = store.get('E2E_FAIL');
    ok(sub && sub.failCount >= 1, '发送失败 → failCount 增加', sub && String(sub.failCount));
    ok(sub && sub.lastDate === new Date().toISOString().slice(0, 10), '发送失败也写 lastDate（按设置不补推）', sub && sub.lastDate);
    ok(sub && sub.lastError && /NETWORK|TIMEOUT|失败/.test(sub.lastError), '失败原因写进 lastError', sub && sub.lastError);
    const before = sub && sub.failCount;
    await index.tick();
    const after = store.get('E2E_FAIL');
    ok(after && after.failCount === before, '下一轮不再重试（不补推）', after && String(after.failCount));
  }
  // 12.5) 人数无上限：同一分钟放 8 个人，应该全部推出去（老版本会被 maxPushPerTick=5 截断）
  {
    const minuteNow2 = currentMinute();
    await index.onUnload();
    const ctx5 = makeCtx('c2c');
    ctx5.config = {
      get: (k, d) => {
        if (k === 'server.port') return fakePort;
        if (k === 'server.host') return '127.0.0.1';
        if (k === 'plugins.token') return 'dummy';
        return d;
      },
    };
    ctx5.plugin = { ...ctx5.plugin, config: { cacheTtlMs: 0 } };
    await index.onLoad(ctx5);
    const store = require('../lib/store').openStore({ dir, log });
    for (let i = 0; i < 8; i++) {
      store.upsert({
        openid: 'E2E_MULTI_' + i,
        accountId: 'acciot33',
        code: '101280109',
        display: '广东·广州·天河',
        city: '广州',
        district: '天河',
        time: minuteNow2,
        enabled: true,
        lastDate: '',
      });
    }
    pushes.length = 0;
    await index.tick();
    const sends = pushes.filter((p) => p.endpoint === 'send_c2c_message');
    ok(sends.length === 8, '同一分钟 8 个人全部推出去（人数无上限）', '实际发送 ' + sends.length + ' 条');
    const today = new Date().toISOString().slice(0, 10);
    const stillDue = store.list().filter((s) => /^E2E_MULTI_/.test(s.openid) && s.lastDate !== today);
    ok(stillDue.length === 0, '8 个人都写上了今天的 lastDate', stillDue.map((s) => s.openid).join(','));
    const snapHtml = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
    const snapJson = snapHtml.match(/<script id="wx-data" type="application\/json">([\s\S]*?)<\/script>/);
    let snapCfg = {};
    try {
      snapCfg = (JSON.parse(snapJson[1]).config || {});
    } catch {
      snapCfg = {};
    }
    ok(!('maxPushPerTick' in snapCfg), '快照 config 不再有 maxPushPerTick');

    // 回归（v1.3.2）：旧逻辑在「设时间/订阅」时预写 lastDate=今天，会把当天真正到点那次挡掉。
    // 现在只按「本分钟是否推过」判断，这种旧数据也应该照推。
    const m3 = currentMinute();
    store.upsert({
      openid: 'E2E_STALE',
      accountId: 'acciot33',
      code: '101280109',
      display: '广东·广州·天河',
      city: '广州',
      district: '天河',
      time: m3,
      enabled: true,
      lastDate: new Date().toISOString().slice(0, 10),
      lastTime: '0001',
    });
    pushes.length = 0;
    await index.tick();
    const staleSends = pushes.filter((p) => p.endpoint === 'send_c2c_message');
    ok(staleSends.length === 1, 'lastDate=今天但 lastTime 不同 → 仍然推（不再被挡）', '实际 ' + staleSends.length + ' 条');
    const staleSub = store.get('E2E_STALE');
    ok(staleSub && staleSub.lastTime === m3, '推完把 lastTime 更新成本分钟', staleSub && staleSub.lastTime);
  }

  await new Promise((r2) => fake.close(r2));

  // 13) 设置页「测试推送」任务：本地 HTTP 不通 + bot 兜底失败 → 如实记账
  await index.onUnload();
  const ctx2 = makeCtx('c2c');
  ctx2.plugin = { ...ctx2.plugin, config: { checkSeconds: 300, tasks: [{ id: 'e2e-task-1', action: 'test', openid: 'E2E_OPENID', at: Date.now() }] } };
  await index.onLoad(ctx2);
  await new Promise((res) => setTimeout(res, 2500));
  {
    const store = require('../lib/store').openStore({ dir, log });
    const rec = store.recentTasks(5).find((t) => t.id === 'e2e-task-1');
    ok(!!rec, '设置页任务被执行');
    ok(rec && (rec.ok === false || rec.ok === 0), '推送失败被如实记录（本地没有服务）', rec && String(rec.message).slice(0, 50));
  }

  // 12) 快照
  const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
  const m = html.match(/<script id="wx-data" type="application\/json">([\s\S]*?)<\/script>/);
  ok(!!m, '设置页快照已写入');
  if (m) {
    const data = JSON.parse(m[1]);
    ok(data.storage && data.storage.driver === (useJson ? 'json' : 'vsql'), '快照标出存储驱动', data.storage && data.storage.driver);
    ok(data.counts && data.counts.total >= 1, '快照里有订阅数', data.counts && String(data.counts.total));
    ok(data.config && data.config.texts && data.config.texts.weather, '快照带文案模板');
    ok(data.defaults && data.defaults.texts && data.defaults.texts.weather, '快照带默认文案（设置页恢复默认用）');
    ok(data.runtime && data.runtime.render && data.runtime.render.count > 0, '快照带出图统计');
    ok(data.runtime && data.runtime.schedule && data.runtime.schedule.everySeconds === 60, '快照标明每分钟调度', data.runtime && JSON.stringify(data.runtime.schedule));
    ok(!('checkSeconds' in (data.config || {})), '快照 config 不再有 checkSeconds');
    ok(!('catchupMaxDays' in (data.config || {})), '快照 config 不再有 catchupMaxDays');
  }

  await index.onUnload();
  if (raw) raw.close();
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
  fs.rmSync(dir, { recursive: true, force: true });

  console.log('\n  生成图片：');
  for (const f of saved) console.log('    ' + f.replace(process.cwd() + path.sep, '') + '  ' + fs.statSync(f).size + 'B');

  console.log('\n' + '─'.repeat(62));
  console.log(`端到端结果：通过 ${pass} · 失败 ${fail}`);
  if (fail) process.exitCode = 1;
  else console.log('全部通过 ✅');
})().catch((e) => {
  console.error('e2e 崩溃：' + (e?.stack || e));
  process.exitCode = 1;
});
