'use strict';
/**
 * 单实例锁：同一个数据目录只允许一个框架进程在跑。
 * 目的：避免“旧进程还没退、新进程又起来”导致两个网关同时收事件、重复回消息。
 *
 * 规则：
 * - 锁文件 <dataDir>/run.pid，内容是 { pid, at, dir }；
 * - 启动时若锁里的 PID 还活着且不是自己 → 拒绝启动（--force 可强开）；
 * - PID 已不存在（崩溃/断电留下的）→ 直接接管；
 * - 进程内重启沿用同一个 PID，不碰锁；正常退出时删锁。
 */
const fs = require('fs');
const path = require('path');

function lockFile(dataDir) {
  return path.join(dataDir, 'run.pid');
}

function pidAlive(pid) {
  if (!pid || pid === process.pid) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    // Windows 上对无权限的进程会抛 EPERM，说明它存在
    return e && e.code === 'EPERM';
  }
}

function readLock(dataDir) {
  try {
    const raw = fs.readFileSync(lockFile(dataDir), 'utf8');
    const obj = JSON.parse(raw);
    return {
      pid: Number(obj?.pid) || 0,
      at: Number(obj?.at) || 0,
      dir: obj?.dir || '',
      raw,
    };
  } catch {
    return null;
  }
}

function acquire(dataDir, { force = false } = {}) {
  const file = lockFile(dataDir);
  const prev = readLock(dataDir);
  const prevPid = prev?.pid || 0;

  if (prevPid && prevPid !== process.pid && pidAlive(prevPid) && !force) {
    const mins = prev.at ? Math.max(1, Math.round((Date.now() - prev.at) / 60000)) : 0;
    return {
      ok: false,
      file,
      pid: prevPid,
      error:
        `已有另一个 JlWBoT 实例在运行（PID ${prevPid}${mins ? `，已运行约 ${mins} 分钟` : ''}），` +
        '同一个数据目录只能跑一个，否则会重复收消息/重复回复。' +
        '请先结束旧进程（或运行 停止机器人.cmd）；确认要强开可加 --force。',
    };
  }

  try {
    fs.writeFileSync(
      file,
      JSON.stringify({ pid: process.pid, at: Date.now(), dir: path.resolve(dataDir), node: process.version }, null, 2),
    );
    return { ok: true, file, pid: process.pid, replaced: prevPid || 0, stale: !!prevPid && !pidAlive(prevPid) };
  } catch (e) {
    return { ok: false, file, error: '无法写入运行锁 ' + file + '：' + e.message };
  }
}

function release(file) {
  try {
    const cur = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (Number(cur?.pid) === process.pid) fs.unlinkSync(file);
    return true;
  } catch {
    return false;
  }
}

module.exports = { lockFile, acquire, release, readLock, pidAlive };
