'use strict';
/**
 * VloS · 对外 API（供其他 JS 插件在同进程内调用）
 *
 *   const vlos = globalThis.__JLWBOT_PLUGIN_APIS__?.get('VloS');
 *   const user = vlos.getUser('3407556894');        // openid / QQ / 邮箱
 *   vlos.balance(user.key);                         // 插件签到账本
 *   vlos.wallet(user.key);                          // 聚龙钱包（缓存）
 *   vlos.vlosBalance(user.key);                     // VloS 余额（原暂存余额）
 *   vlos.addVlosBalance(user.key, { longjing: 10 }, { reason: '小游戏' }); // 加减 VloS 余额
 *   await vlos.addWallet(user.key, { longjing: 10 }, { reason: '小游戏' }); // 真实入聚龙钱包
 *
 * 说明：
 * - getUser / balance / wallet / vlosBalance / addVlosBalance / setVlosBalance 是同步的；
 * - addWallet 需要配置聚龙发奖 Key（currency-add / currency-sub），返回 Promise；
 * - 所有返回对象都是副本；API 不暴露 token / 密码 / Key。
 */

const T = require('./lib/text');

let runtimeRef = null;

const api = {
  pluginId: 'VloS',
  version: '2.0.1',

  isReady() {
    return !!runtimeRef;
  },

  bind(runtime) {
    runtimeRef = runtime || null;
    if (runtimeRef && runtimeRef.version) api.version = runtimeRef.version;
    try {
      const g = globalThis;
      if (!(g.__JLWBOT_PLUGIN_APIS__ instanceof Map)) g.__JLWBOT_PLUGIN_APIS__ = new Map();
      g.__JLWBOT_PLUGIN_APIS__.set('VloS', api);
    } catch {
      /* ignore */
    }
    return api;
  },

  unbind() {
    runtimeRef = null;
    try {
      const g = globalThis;
      if (g.__JLWBOT_PLUGIN_APIS__?.get?.('VloS') === api) g.__JLWBOT_PLUGIN_APIS__.delete('VloS');
    } catch {
      /* ignore */
    }
  },

  /** 解析用户：openid / 别名 / QQ / 邮箱 */
  getUser(voucher) {
    const u = resolve(voucher);
    refreshPending(runtimeRef, u);
    return publicUser(u, { aliases: true });
  },

  getAccount(voucher) {
    return this.getUser(voucher);
  },

  getBinding(voucher) {
    const u = resolve(voucher);
    if (!u) return null;
    return {
      key: u.key,
      email: u.email,
      qq: u.qq,
      legacyQq: u.legacyQq,
      qqBoundAt: u.qqBoundAt,
      openid: u.openid,
      openidBoundAt: u.openidBoundAt,
      name: u.name,
      avatar: u.avatar,
      aliases: [...(u.aliases || [])],
    };
  },

  isBound(voucher) {
    return !!resolve(voucher)?.email;
  },

  resolveKey(voucher) {
    const u = resolve(voucher);
    return u ? u.key : '';
  },

  /** 插件签到账本余额（不是聚龙钱包） */
  balance(voucher) {
    const u = resolve(voucher);
    if (!u) return null;
    return { longjing: cleanInt(u.balances?.longjing), xuanyu: cleanInt(u.balances?.xuanyu) };
  },

  /** 聚龙钱包缓存（最近一次 me / balance / 签到后的值） */
  wallet(voucher) {
    const u = resolve(voucher);
    if (!u) return null;
    return { longjing: cleanMoney(u.wallet?.longjing), xuanyu: cleanMoney(u.wallet?.xuanyu) };
  },

  /**
   * VloS 余额（原「暂存余额」）：聚龙发奖失败时累计在这里，Key 恢复后下次签到一并入账。
   * 其他插件也可以给用户加减这个余额，用于小游戏 / 活动奖励等。
   */
  vlosBalance(voucher) {
    const u = resolve(voucher);
    if (!u) return null;
    refreshPending(runtimeRef, u);
    const longjing = cleanMoney(u.pendingWallet?.longjing);
    const xuanyu = cleanMoney(u.pendingWallet?.xuanyu);
    return { longjing, xuanyu, total: longjing + xuanyu };
  },

  /**
   * 增减 VloS 余额（同步，本地；负数扣减，最低扣到 0）。
   * @returns {{key,before,after,delta,vlosBalance,user}}
   */
  addVlosBalance(voucher, delta, options = {}) {
    const rt = ensureReady();
    const user = resolve(voucher);
    if (!user) throw error('NOT_FOUND', 'VloS：找不到该用户（先让用户 /add 注册聚龙账户）');
    refreshPending(rt, user);
    const d = normalizeDelta(delta);
    const before = {
      longjing: cleanMoney(user.pendingWallet?.longjing),
      xuanyu: cleanMoney(user.pendingWallet?.xuanyu),
    };
    const after = {
      longjing: cleanMoney(before.longjing + d.longjing),
      xuanyu: cleanMoney(before.xuanyu + d.xuanyu),
    };
    rt.store.setPendingWallet(user.key, after);
    logChange(rt, user, 'VloS余额', { before, after }, options.reason);
    const fresh = rt.store.get(user.key);
    return {
      key: user.key,
      before,
      after,
      delta: { longjing: after.longjing - before.longjing, xuanyu: after.xuanyu - before.xuanyu },
      vlosBalance: { ...after, total: after.longjing + after.xuanyu },
      user: publicUser(fresh, { aliases: false }),
    };
  },

  /** 直接设置 VloS 余额（同步，本地；负数按 0 处理） */
  setVlosBalance(voucher, values, options = {}) {
    const rt = ensureReady();
    const user = resolve(voucher);
    if (!user) throw error('NOT_FOUND', 'VloS：找不到该用户');
    refreshPending(rt, user);
    const v = values && typeof values === 'object' ? values : {};
    const before = {
      longjing: cleanMoney(user.pendingWallet?.longjing),
      xuanyu: cleanMoney(user.pendingWallet?.xuanyu),
    };
    const after = {
      longjing: v.longjing !== undefined ? cleanMoney(v.longjing) : before.longjing,
      xuanyu: v.xuanyu !== undefined ? cleanMoney(v.xuanyu) : before.xuanyu,
    };
    rt.store.setPendingWallet(user.key, after);
    logChange(rt, user, 'VloS余额', { before, after }, options.reason);
    const fresh = rt.store.get(user.key);
    return {
      key: user.key,
      before,
      after,
      delta: { longjing: after.longjing - before.longjing, xuanyu: after.xuanyu - before.xuanyu },
      vlosBalance: { ...after, total: after.longjing + after.xuanyu },
      user: publicUser(fresh, { aliases: false }),
    };
  },

  signInfo(voucher) {
    const u = resolve(voucher);
    if (!u) return null;
    return {
      totalDays: cleanInt(u.sign?.totalDays),
      streak: cleanInt(u.sign?.streak),
      lastDate: String(u.sign?.lastDate || ''),
      signedToday: u.sign?.lastDate === T.dateKey(),
    };
  },

  signedToday(voucher) {
    const u = resolve(voucher);
    return !!u && u.sign?.lastDate === T.dateKey();
  },

  /** 调整插件签到账本（同步，本地） */
  addBalance(voucher, delta, options = {}) {
    const rt = ensureReady();
    const user = resolve(voucher);
    if (!user) throw error('NOT_FOUND', 'VloS：找不到该用户（先让用户 /add 注册聚龙账户）');
    const d = normalizeDelta(delta);
    const r = rt.store.adjustBalances(user.key, { longjingDelta: d.longjing, xuanyuDelta: d.xuanyu });
    if (!r) throw error('NOT_FOUND', 'VloS：找不到该用户');
    logChange(rt, user, '账本', r, options.reason);
    return {
      key: user.key,
      before: r.before,
      after: r.after,
      delta: { longjing: r.after.longjing - r.before.longjing, xuanyu: r.after.xuanyu - r.before.xuanyu },
      user: publicUser(r.user, { aliases: false }),
    };
  },

  setBalance(voucher, values, options = {}) {
    const rt = ensureReady();
    const user = resolve(voucher);
    if (!user) throw error('NOT_FOUND', 'VloS：找不到该用户');
    const v = values && typeof values === 'object' ? values : {};
    const patch = {};
    if (v.longjing !== undefined) patch.longjing = cleanMoney(v.longjing);
    if (v.xuanyu !== undefined) patch.xuanyu = cleanMoney(v.xuanyu);
    const r = rt.store.adjustBalances(user.key, patch);
    if (!r) throw error('NOT_FOUND', 'VloS：找不到该用户');
    logChange(rt, user, '账本', r, options.reason);
    return { key: user.key, before: r.before, after: r.after, user: publicUser(r.user, { aliases: false }) };
  },

  /**
   * 调整聚龙钱包（异步；需要配置发奖 Key 且 Key 有 currency-add / currency-sub 权限）
   * @returns {Promise<{key,before,after,delta,wallet,user}>}
   */
  async addWallet(voucher, delta, options = {}) {
    const rt = ensureReady();
    const user = resolve(voucher);
    if (!user) throw error('NOT_FOUND', 'VloS：找不到该用户');
    if (!rt.cfg.jlAccount.key) throw error('NO_KEY', 'VloS：没有配置聚龙发奖 Key');
    const d = normalizeDelta(delta);
    const before = { longjing: cleanMoney(user.wallet?.longjing), xuanyu: cleanMoney(user.wallet?.xuanyu) };
    let wallet = { ...before };
    for (const currency of ['longjing', 'xuanyu']) {
      const amount = d[currency];
      if (!amount) continue;
      const res =
        amount > 0
          ? await rt.jl.currencyAdd(user.email, currency, Math.min(1_000_000, Math.abs(amount)))
          : await rt.jl.currencySub(user.email, currency, Math.min(1_000_000, Math.abs(amount)));
      if (res.wallet) wallet = res.wallet;
    }
    rt.store.setWallet(user.key, wallet);
    const fresh = rt.store.get(user.key);
    try {
      rt.log?.info(
        `VloS API 调整聚龙钱包 user=${user.key} email=${user.email} 龙晶 ${before.longjing}->${wallet.longjing} 玄玉 ${before.xuanyu}->${wallet.xuanyu} reason=${options.reason || '-'}`,
      );
    } catch {
      /* ignore */
    }
    return {
      key: user.key,
      before,
      after: { ...wallet },
      delta: { longjing: wallet.longjing - before.longjing, xuanyu: wallet.xuanyu - before.xuanyu },
      wallet: { ...wallet },
      user: publicUser(fresh, { aliases: false }),
    };
  },

  listUsers(options = {}) {
    const rt = ensureReady();
    const limit = Math.max(1, Math.min(500, Number(options.limit) || 100));
    const offset = Math.max(0, Number(options.offset) || 0);
    const search = String(options.search || '').trim().toLowerCase();
    let list = rt.store.all();
    if (search) {
      list = list.filter((u) =>
        [u.key, u.email, u.qq, u.legacyQq, u.name].some((x) => String(x || '').toLowerCase().includes(search)),
      );
    }
    list = list.slice().sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    return { total: list.length, users: list.slice(offset, offset + limit).map((u) => publicUser(u, { aliases: false })) };
  },

  stats() {
    return ensureReady().store.stats();
  },

  dropConfig() {
    const s = ensureReady().cfg.sign;
    return {
      longjingMin: s.longjingMin,
      longjingMax: s.longjingMax,
      xuanyuChance: s.xuanyuChance,
      xuanyuMin: s.xuanyuMin,
      xuanyuMax: s.xuanyuMax,
      oncePerDay: s.oncePerDay,
      wallet: s.wallet,
    };
  },
};

function ensureReady() {
  if (!runtimeRef) throw error('NOT_READY', 'VloS 插件尚未加载');
  return runtimeRef;
}

function resolve(voucher) {
  const rt = runtimeRef;
  if (!rt) return null;
  const v = String(voucher ?? '').trim();
  if (!v) return null;
  let user = rt.store.get(v);
  if (!user) user = rt.store.findByKeys([v]);
  if (!user && /^[1-9]\d{4,11}$/.test(v)) user = rt.store.getByQQ(v);
  if (!user && v.includes('@')) user = rt.store.getByEmail(v);
  if (!user && /^[1-9]\d{4,11}$/.test(v)) {
    user = rt.store.all().find((u) => String(u.legacyQq || '') === v) || null;
  }
  return user || null;
}

/**
 * 回表读最新 VloS余额（SQLite 下别的插件会直接 UPDATE vlos_users.vl_lj / vl_xy）。
 * 失败就退回缓存值，不影响调用方。
 */
function refreshPending(rt, user) {
  if (!rt || !user || typeof rt.store?.refreshPending !== 'function') return;
  try {
    rt.store.refreshPending(user.key);
  } catch {
    /* 读表失败就用缓存 */
  }
}

function publicUser(user, { aliases = false } = {}) {
  if (!user) return null;
  const sign = user.sign || {};
  return {
    key: user.key,
    email: user.email,
    qq: user.qq,
    legacyQq: user.legacyQq,
    qqBoundAt: cleanInt(user.qqBoundAt),
    openid: user.openid,
    openidBoundAt: cleanInt(user.openidBoundAt),
    name: user.name,
    avatar: user.avatar,
    bound: !!user.email,
    wallet: { longjing: cleanMoney(user.wallet?.longjing), xuanyu: cleanMoney(user.wallet?.xuanyu) },
    vlosBalance: {
      longjing: cleanMoney(user.pendingWallet?.longjing),
      xuanyu: cleanMoney(user.pendingWallet?.xuanyu),
      total: cleanMoney(user.pendingWallet?.longjing) + cleanMoney(user.pendingWallet?.xuanyu),
    },
    balances: { longjing: cleanInt(user.balances?.longjing), xuanyu: cleanInt(user.balances?.xuanyu) },
    sign: {
      totalDays: cleanInt(sign.totalDays),
      streak: cleanInt(sign.streak),
      lastDate: String(sign.lastDate || ''),
      signedToday: sign.lastDate === T.dateKey(),
    },
    createdAt: cleanInt(user.createdAt),
    updatedAt: cleanInt(user.updatedAt),
    ...(aliases ? { aliases: [...(user.aliases || [])] } : {}),
  };
}

function normalizeDelta(delta) {
  const d = delta && typeof delta === 'object' ? delta : { longjing: Number(delta) || 0 };
  return { longjing: signedInt(d.longjing), xuanyu: signedInt(d.xuanyu) };
}

function logChange(rt, user, label, r, reason) {
  try {
    rt.log?.info(
      `VloS API 调整${label} user=${user.key} email=${user.email} 龙晶 ${r.before.longjing}->${r.after.longjing} 玄玉 ${r.before.xuanyu}->${r.after.xuanyu} reason=${reason || '-'}`,
    );
  } catch {
    /* ignore */
  }
}

function signedInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : 0;
}

function cleanInt(v) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.trunc(n) : 0;
}

function cleanMoney(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1e9, Math.trunc(n)));
}

function error(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

module.exports = api;
