'use strict';
/**
 * 面板会话：登录成功后签发随机 sid，写入 HttpOnly Cookie
 * 会话持久化到 SQLite（sessions 表），重启进程仍保持登录；
 * 首次启动时会把旧的 data/sessions.json 导入（db.migrate 负责，这里再兜底一次）。
 */
const fs = require('fs');
const U = require('./util');
const store = require('./store');

class SessionStore {
  constructor({ config, logger }) {
    this.config = config;
    this.log = logger.child('session');
    this.file = U.p('data', 'sessions.json');
    this.sessions = new Map();
    this._load();
    this._cleanup();
  }

  _load() {
    for (const s of store.sessionLoadAll()) {
      if (!s || !s.sid || !s.expiresAt) continue;
      this.sessions.set(s.sid, s);
    }
    if (this.sessions.size) return;
    // 兜底：迁移流程没跑到时，手动导入一次旧文件
    if (!fs.existsSync(this.file)) return;
    const raw = U.readJson(this.file, {});
    let n = 0;
    for (const [sid, s] of Object.entries(raw || {})) {
      if (!s || !s.expiresAt) continue;
      this.sessions.set(sid, { ...s, sid });
      n++;
    }
    if (n) {
      this._save();
      try {
        fs.renameSync(this.file, this.file + '.imported');
      } catch {
        /* ignore */
      }
      this.log.info(`已把旧会话导入 SQLite（${n} 个）`);
    }
  }

  _save() {
    try {
      store.sessionSaveAll([...this.sessions.values()]);
    } catch (e) {
      this.log.warn('保存会话失败: ' + e.message);
    }
  }

  _ttlMs() {
    return Math.max(1, this.config.jlw().sessionDays) * 86400000;
  }

  _cleanup() {
    const now = Date.now();
    let changed = false;
    for (const [sid, s] of this.sessions) {
      if (!s.expiresAt || s.expiresAt < now) {
        this.sessions.delete(sid);
        changed = true;
      }
    }
    if (changed) this._save();
  }

  create({ user, jlwToken, provider, ip }) {
    this._cleanup();
    const sid = U.randomToken(32);
    const now = Date.now();
    const session = {
      sid,
      user: user || {},
      jlwToken: jlwToken || '',
      provider: provider || {},
      ip: ip || '',
      createdAt: now,
      expiresAt: now + this._ttlMs(),
    };
    this.sessions.set(sid, session);
    // 限制会话数量，避免无限增长
    if (this.sessions.size > 50) {
      const oldest = [...this.sessions.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
      if (oldest) this.sessions.delete(oldest.sid);
    }
    this._save();
    return session;
  }

  get(sid) {
    if (!sid) return null;
    const s = this.sessions.get(sid);
    if (!s) return null;
    if (s.expiresAt < Date.now()) {
      this.sessions.delete(sid);
      this._save();
      return null;
    }
    return s;
  }

  update(sid, patch) {
    const s = this.sessions.get(sid);
    if (!s) return null;
    Object.assign(s, patch);
    this._save();
    return s;
  }

  destroy(sid) {
    if (!sid) return false;
    const ok = this.sessions.delete(sid);
    if (ok) this._save();
    return ok;
  }

  count() {
    this._cleanup();
    return this.sessions.size;
  }
}

module.exports = SessionStore;
