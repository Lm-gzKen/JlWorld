/* 轻量 Markdown 渲染器（安全优先：先整体转义 HTML，再套用标记）
   支持：标题 / 粗体 / 斜体 / 删除线 / 行内代码 / 围栏代码 / 链接 / 图片 /
        有序无序列表 / 引用 / 分割线 / 表格 / 换行 */
(function () {
  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function safeUrl(url) {
    const u = String(url).trim();
    if (/^(https?:)?\/\//i.test(u) || u.startsWith('/') || u.startsWith('#') || /^mailto:/i.test(u)) return true;
    return false;
  }

  const IMG_RE = /\.(png|jpe?g|gif|webp|bmp|svg|avif|ico)(?:[?#]|$)/i;

  /** 链接地址如果本身就是图片（.png/.jpg…），直接显示成图片，省得用户写 ![]() */
  function linkOrImage(url) {
    if (IMG_RE.test(url)) return `<img src="${url}" alt="图片" loading="lazy">`;
    return `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`;
  }

  // 输入必须已经过 esc()
  function inline(s) {
    // 已经生成好的 HTML 先收进占位符，避免被后面的正则二次处理
    const stash = [];
    const keep = (html) => `\u0001${stash.push(html) - 1}\u0001`;

    // 行内代码
    s = s.replace(/`([^`]+)`/g, (_m, a) => keep(`<code>${a}</code>`));

    // ![alt](url) 与 [文字](url)
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g, (m, alt, url) =>
      safeUrl(url) ? keep(`<img src="${url}" alt="${alt}" loading="lazy">`) : m
    );
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g, (m, t, url) =>
      safeUrl(url) ? keep(`<a href="${url}" target="_blank" rel="noopener noreferrer">${t}</a>`) : m
    );

    // 尖括号自动链接：<https://xxx.png> —— 是图片就直接显示
    s = s.replace(/&lt;(https?:\/\/[^\s&]*(?:&amp;[^\s&]*)*)&gt;/g, (m, url) =>
      safeUrl(url) ? keep(linkOrImage(url)) : m
    );

    // 裸链接：直接粘贴的 http(s) 地址（图片地址同样自动变图片）
    // 前面的字符允许中文标点，因为「链接：https://…」是最常见的粘贴方式
    s = s.replace(/(^|[\s(（\[【>「"'：:，,、；;])(https?:\/\/[^\s<>)"'，。；、：！？【】（）]+)/g, (_m, pre, url) =>
      safeUrl(url) ? pre + keep(linkOrImage(url)) : pre + url
    );

    // 强调
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/__([^_]+)__/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*\w])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');

    return s.replace(/\u0001(\d+)\u0001/g, (_m, i) => stash[Number(i)]);
  }

  function render(src) {
    const lines = String(src == null ? '' : src).replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    let i = 0;

    const isTableSep = (l) => /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(l) && l.includes('-');
    const cells = (l) =>
      l.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map((x) => x.trim());

    while (i < lines.length) {
      const line = lines[i];

      // 围栏代码块
      const fence = /^\s*(```+|~~~+)\s*([\w+#.-]*)\s*$/.exec(line);
      if (fence) {
        const close = fence[1][0].repeat(3);
        const buf = [];
        i++;
        while (i < lines.length && !new RegExp('^\\s*' + close + '+\\s*$').test(lines[i])) buf.push(lines[i++]);
        i++;
        out.push(`<pre><code>${esc(buf.join('\n'))}</code></pre>`);
        continue;
      }

      // 标题
      const h = /^(#{1,6})\s+(.*)$/.exec(line);
      if (h) {
        const lv = h[1].length;
        out.push(`<h${lv}>${inline(esc(h[2].replace(/\s+#+\s*$/, '')))}</h${lv}>`);
        i++;
        continue;
      }

      // 分割线
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) {
        out.push('<hr>');
        i++;
        continue;
      }

      // 表格
      if (line.includes('|') && i + 1 < lines.length && isTableSep(lines[i + 1])) {
        const head = cells(line);
        i += 2;
        const body = [];
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) body.push(cells(lines[i++]));
        out.push(
          '<table><thead><tr>' +
            head.map((c) => `<th>${inline(esc(c))}</th>`).join('') +
            '</tr></thead><tbody>' +
            body
              .map((r) => '<tr>' + head.map((_c, k) => `<td>${inline(esc(r[k] || ''))}</td>`).join('') + '</tr>')
              .join('') +
            '</tbody></table>'
        );
        continue;
      }

      // 引用
      if (/^\s*>/.test(line)) {
        const buf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ''));
        out.push(`<blockquote>${render(buf.join('\n'))}</blockquote>`);
        continue;
      }

      // 列表
      if (/^\s*([-*+]|\d+[.)])\s+/.test(line)) {
        const ordered = /^\s*\d+[.)]\s+/.test(line);
        const items = [];
        while (i < lines.length && /^\s*([-*+]|\d+[.)])\s+/.test(lines[i])) {
          let text = lines[i++].replace(/^\s*([-*+]|\d+[.)])\s+/, '');
          // 续行（缩进的行）并入当前条目
          while (i < lines.length && lines[i].trim() && !/^\s*([-*+]|\d+[.)])\s+/.test(lines[i]) && !/^\s{0,3}#/.test(lines[i])) {
            text += '\n' + lines[i++].trim();
          }
          items.push(`<li>${inline(esc(text))}</li>`);
        }
        out.push(ordered ? `<ol>${items.join('')}</ol>` : `<ul>${items.join('')}</ul>`);
        continue;
      }

      // 空行
      if (!line.trim()) {
        i++;
        continue;
      }

      // 段落
      const buf = [];
      while (
        i < lines.length &&
        lines[i].trim() &&
        !/^\s*(#{1,6}\s|>|([-*+]|\d+[.)])\s|```|~~~)/.test(lines[i]) &&
        !/^\s*([-*_])(\s*\1){2,}\s*$/.test(lines[i])
      ) {
        buf.push(lines[i++]);
      }
      out.push(`<p>${inline(esc(buf.join('\n'))).replace(/\n/g, '<br>')}</p>`);
    }

    return out.join('\n');
  }

  window.renderMarkdown = render;
  window.escapeHtml = esc;
})();
