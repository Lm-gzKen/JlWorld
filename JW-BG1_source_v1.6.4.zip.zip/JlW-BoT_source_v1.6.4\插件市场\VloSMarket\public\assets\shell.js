/* 外壳：负责切换内嵌视图，自己永远不重新加载（顶栏/铃铛/海浪动画都不重建） */
(function () {
  const $ = (id) => document.getElementById(id);

  // 视图 → 地址栏路径（刷新后能回到同一个栏目）
  const PATHS = {
    '/home-view.html': '/home',
    '/index.html': '/market',
    '/developer.html': '/developer',
  };
  const BY_PATH = Object.fromEntries(Object.entries(PATHS).map(([v, p]) => [p, v]));

  const frame = $('viewFrame');
  const nav = $('shellNav');

  frame.classList.add('fade');
  const reveal = () => frame.classList.add('shown');
  frame.addEventListener('load', () => requestAnimationFrame(reveal));
  setTimeout(reveal, 1500); // 兜底

  function normalize(path) {
    let p = (path || '/').split('?')[0].split('#')[0];
    if (p === '/' || p === '/home' || p === '/home.html' || p === '/home-view.html') p = '/home';
    else if (p === '/market' || p === '/index.html') p = '/market';
    else if (p === '/developer' || p === '/developer.html') p = '/developer';
    else if (p === '/docs' || p === '/admin' || p === '/docs.html' || p === '/admin.html') p = '/home';
    return p;
  }

  function actualPath() {
    try {
      return normalize(frame.contentWindow.location.pathname);
    } catch {
      return '';
    }
  }

  function setActive(view) {
    nav.querySelectorAll('a[data-view]').forEach((a) => {
      a.classList.toggle('active', a.dataset.view === view);
    });
    App.navPill(true);
    const cur = nav.querySelector('a.active');
    document.title = (cur && cur.dataset.title ? cur.dataset.title + ' · ' : '') + 'JlW-BoT 插件市场';
  }

  function pluginHash() {
    return /^#\/p\/[0-9a-zA-Z]+$/.test(location.hash) ? location.hash : '';
  }

  function applyHash() {
    const h = pluginHash();
    if (!h) {
      // 从详情页点「插件市场」回到列表：把 iframe 里的 hash 一并清掉，否则它还停在详情
      try {
        if (frame.contentWindow.location.hash) frame.contentWindow.location.hash = '';
      } catch {}
      return;
    }
    try {
      frame.contentWindow.location.hash = h;
    } catch {}
  }

  /** 内嵌 iframe 载入插件详情（铃铛 / 栏目链接都走这里） */
  function loadPlugin(id) {
    const hash = '#/p/' + id;
    const view = '/index.html';
    setActive(view);
    try {
      history.pushState({ view, hash }, '', '/market' + hash);
    } catch {}
    if (actualPath() === '/market' && frame.getAttribute('src') === view) {
      try {
        frame.contentWindow.location.hash = hash;
      } catch {}
      return;
    }
    frame.classList.remove('shown');
    frame.setAttribute('src', view);
    frame.addEventListener('load', () => {
      try {
        frame.contentWindow.location.hash = hash;
      } catch {}
    }, { once: true });
  }

  function load(view, push) {
    if (!PATHS[view]) view = '/home-view.html';
    setActive(view);
    // 先改地址栏（会顺手清掉上一条 #/p/xxx），再决定要不要把 hash 传给 iframe
    if (push !== false) {
      try {
        history.pushState({ view }, '', PATHS[view]);
      } catch {}
    }
    const actual = actualPath();
    if (frame.getAttribute('src') !== view || (actual && actual !== PATHS[view])) {
      frame.classList.remove('shown');
      frame.setAttribute('src', view);
      frame.addEventListener('load', applyHash, { once: true });
    } else {
      applyHash();
    }
    try {
      frame.contentWindow.scrollTo(0, 0);
    } catch {}
  }

  // 内嵌视图里的站内链接（首页的两个按钮等）交回外壳切栏目
  const VIEW_LINKS = {
    '/': '/home-view.html',
    '/home': '/home-view.html',
    '/home.html': '/home-view.html',
    '/home-view.html': '/home-view.html',
    '/market': '/index.html',
    '/index.html': '/index.html',
    '/developer': '/developer.html',
    '/developer.html': '/developer.html',
  };
  App.shellView = function (href) {
    const raw = String(href || '');
    if (raw.includes('#')) return null; // hash 路由（插件详情等）留在内层自己处理
    return VIEW_LINKS[raw.split('?')[0]] || null;
  };
  App.shellLoad = load;
  App.shellOpenPlugin = loadPlugin;

  // ---------------- 登录态同步：内层登录 / 退出后顶栏要跟着变 ----------------
  function syncTopbar(user) {
    App.user = user || null;
    document.body.classList.toggle('gated', !user);
    if (user) {
      if (App._gate) {
        App._gate.remove();
        App._gate = null;
      }
      App.mountUser($('userArea'));
      App.mountBell($('bellArea'));
    } else {
      App.mountUser($('userArea'));
      App.requireLogin();
    }
  }

  // 内层 iframe（home-view / 市场 / 开发者中心）登录成功后 postMessage 过来
  window.addEventListener('message', (e) => {
    if (e.origin !== location.origin) return;
    const d = e.data || {};
    if (d.type !== 'vlos:user') return;
    const cur = App.user && App.user.email;
    const next = d.user && d.user.email;
    if (cur === next) return;
    syncTopbar(d.user);
  });

  // 切回来 / 页面获得焦点时兜底对一次：别的标签页换了账号也能同步
  let lastSync = 0;
  async function resyncFromServer() {
    if (Date.now() - lastSync < 3000) return;
    lastSync = Date.now();
    try {
      const me = await App.api('GET', '/api/me');
      const cur = App.user && App.user.email;
      const next = me.user && me.user.email;
      if (cur !== next) syncTopbar(me.user);
    } catch {}
  }
  window.addEventListener('focus', resyncFromServer);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) resyncFromServer();
  });

  App.boot((user) => {
    App.mountUser($('userArea'));
    App.mountBell($('bellArea'));

    nav.querySelectorAll('a[data-view]').forEach((a) => {
      a.onclick = (e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; // 允许新窗口打开
        e.preventDefault();
        load(a.dataset.view);
      };
    });
    document.querySelector('.brand').onclick = (e) => {
      e.preventDefault();
      load('/home-view.html');
    };

    window.addEventListener('popstate', (e) => {
      const v = (e.state && e.state.view) || BY_PATH[normalize(location.pathname)] || '/home-view.html';
      load(v, false);
    });

    const start = BY_PATH[normalize(location.pathname)] || '/home-view.html';
    load(start, false);
    // 直接打开 /market#/p/xxx 时，等 iframe 载入完再把 hash 传进去
    if (pluginHash()) frame.addEventListener('load', applyHash, { once: true });
  });
})();
