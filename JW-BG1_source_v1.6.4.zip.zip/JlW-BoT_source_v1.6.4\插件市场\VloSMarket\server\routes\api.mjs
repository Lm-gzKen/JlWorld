// 开放上传 API（v1）：用户拿自己的 API 令牌，直接上传 / 更新插件 zip。
// 认证：Authorization: Bearer <token> 或 X-API-Key: <token>；也兼容登录会话 Cookie。
// 上传：请求体就是 zip 原始二进制（不要 multipart）。
import fs from 'node:fs';
import path from 'node:path';
import { HttpError, readBody, newId, newToken, sha256, safeFileName } from '../http.mjs';
import { parsePackage } from '../package.mjs';
import { publicPlugin, releaseInfo, saveRelease } from './plugins.mjs';

const s = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

function normVersion(v) {
  const t = s(v, 32).replace(/^[vV]/, '').trim();
  if (!/^[0-9A-Za-z][0-9A-Za-z._+-]{0,31}$/.test(t)) {
    throw new HttpError(400, '版本号只能用字母、数字、点、下划线、加号、减号，且以字母或数字开头');
  }
  return t;
}

function parseTags(v) {
  return String(v == null ? '' : v)
    .split(/[,，\s]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 8)
    .join(',');
}

// 每个账户每分钟最多 20 次上传，避免脚本刷爆磁盘
const uploadHits = new Map();
function uploadLimit(email) {
  const now = Date.now();
  let rec = uploadHits.get(email);
  if (!rec || now - rec.start > 60 * 1000) {
    rec = { start: now, count: 0 };
    uploadHits.set(email, rec);
  }
  rec.count += 1;
  if (rec.count > 20) throw new HttpError(429, '上传太频繁，请稍后再试（每分钟最多 20 次）');
  if (uploadHits.size > 5000) {
    for (const [k, v] of uploadHits) if (now - v.start > 5 * 60 * 1000) uploadHits.delete(k);
  }
}

/** 从请求里取用户：优先 API 令牌，其次登录会话 */
function apiUser(c) {
  const auth = String(c.req.headers.authorization || '');
  let token = '';
  const m = /^Bearer\s+(.+)$/i.exec(auth);
  if (m) token = m[1].trim();
  if (!token) token = String(c.req.headers['x-api-key'] || '').trim();

  if (token) {
    const row = c.store.get('SELECT * FROM api_tokens WHERE token = ?', token);
    if (!row) throw new HttpError(401, 'API 令牌无效，请在「开发者中心 → api上传」里复制最新令牌');
    const user = c.store.get('SELECT * FROM users WHERE email = ?', row.email);
    if (!user) throw new HttpError(401, '这个令牌对应的账户不存在');
    c.store.run('UPDATE api_tokens SET last_used=? WHERE token=?', Date.now(), token);
    return user;
  }
  if (c.user) return c.user;
  throw new HttpError(401, '缺少 API 令牌：请加请求头 Authorization: Bearer <token>');
}

function tokenFor(store, email) {
  let row = store.get('SELECT * FROM api_tokens WHERE email = ?', email);
  if (!row) {
    // OR IGNORE 防止两个并发请求同时首次创建
    store.run(
      'INSERT OR IGNORE INTO api_tokens (email, token, created, last_used) VALUES (?,?,?,0)',
      email,
      newToken(),
      Date.now()
    );
    row = store.get('SELECT * FROM api_tokens WHERE email = ?', email);
  }
  return row;
}

/** 把上传的 zip 写到 tmp，再交给 saveRelease 落盘 */
function stageBuffer(c, buf, parsed) {
  const zipPath = path.join(c.dirs.tmp, 'api-' + newId() + '.zip');
  fs.writeFileSync(zipPath, buf);
  return {
    meta: { size: buf.length, sha256: sha256(buf), parsed, filename: 'api.zip', created: Date.now() },
    zipPath,
    metaPath: '',
  };
}

async function readZipBody(c, filename) {
  const limit = (Number(c.cfg.maxUploadMB) || 32) * 1048576;
  const buf = await readBody(c.req, limit);
  if (!buf.length) throw new HttpError(400, '上传内容为空');
  if (buf[0] !== 0x50 || buf[1] !== 0x4b) throw new HttpError(400, '请求体必须直接是 zip 文件（不要用 multipart/form-data）');
  let parsed;
  try {
    parsed = parsePackage(buf, filename || 'plugin.zip');
  } catch (e) {
    throw new HttpError(400, '解析压缩包失败：' + e.message);
  }
  return { buf, parsed };
}

export default function register(router) {
  // ---------------- 令牌（登录会话） ----------------
  router.get('/api/my/api-token', (c) => {
    const u = c.mustUser();
    const row = tokenFor(c.store, u.email);
    return { ok: true, token: row.token, created: row.created, lastUsed: row.last_used || 0 };
  });

  router.post('/api/my/api-token/refresh', (c) => {
    const u = c.mustUser();
    const token = newToken();
    c.store.run(
      `INSERT INTO api_tokens (email, token, created, last_used) VALUES (?,?,?,0)
       ON CONFLICT(email) DO UPDATE SET token=excluded.token, created=excluded.created, last_used=0`,
      u.email,
      token,
      Date.now()
    );
    return { ok: true, token, msg: '令牌已重新生成，旧令牌立即失效' };
  });

  // ---------------- v1：查看自己 / 自己的插件 ----------------
  router.get('/api/v1/me', (c) => {
    const u = apiUser(c);
    const rows = c.store.all('SELECT * FROM plugins WHERE email = ? ORDER BY updated DESC', u.email);
    return {
      ok: true,
      user: { email: u.email, name: u.nickname || String(u.email).split('@')[0] },
      plugins: rows.map((p) => ({
        id: p.id,
        name: p.name,
        version: p.version,
        offline: !!p.offline,
        releases: c.store.get('SELECT COUNT(*) AS n FROM releases WHERE plugin_id=?', p.id).n,
      })),
    };
  });

  // ---------------- v1：上传新插件 ----------------
  router.post('/api/v1/plugins', async (c) => {
    const u = apiUser(c);
    uploadLimit(u.email);

    const q = c.url.searchParams;
    const filename = safeFileName(q.get('filename') || 'plugin.zip');
    const { buf, parsed } = await readZipBody(c, filename);

    const name = s(q.get('name'), 60) || parsed.name;
    if (!name) throw new HttpError(400, '无法识别插件名称，请传 ?name=插件名');
    const author = s(q.get('author'), 40) || (u.qq ? `QQ ${u.qq}` : u.email.split('@')[0]);
    const version = normVersion(s(q.get('version'), 32) || parsed.version);
    const summary = s(q.get('summary'), 200);
    const readme = String(q.get('readme') == null ? '' : q.get('readme')).slice(0, 40000);
    const tags = parseTags(q.get('tags'));

    const id = newId();
    const now = Date.now();
    try {
      c.store.run(
        `INSERT INTO plugins (id, email, name, author, version, summary, readme, tags, created, updated)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        id,
        u.email,
        name,
        author,
        version,
        summary,
        readme,
        tags,
        now,
        now
      );
      const plugin = c.store.get('SELECT * FROM plugins WHERE id=?', id);
      const stage = stageBuffer(c, buf, parsed);
      const rel = saveRelease(c, plugin, stage, version, s(q.get('changelog'), 500));
      return {
        ok: true,
        id,
        plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', id), { owner: true }),
        release: releaseInfo(rel),
        msg: `《${name}》v${version} 已发布`,
      };
    } catch (e) {
      try {
        c.store.run('DELETE FROM releases WHERE plugin_id=?', id);
        c.store.run('DELETE FROM plugins WHERE id=?', id);
        fs.rmSync(path.join(c.cfg.dataDir, 'plugins', id), { recursive: true, force: true });
      } catch {}
      throw e;
    }
  });

  // ---------------- v1：给已有插件上传新版本 ----------------
  router.post('/api/v1/plugins/:id/releases', async (c) => {
    const u = apiUser(c);
    uploadLimit(u.email);

    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.email !== u.email) throw new HttpError(403, '只能更新自己上传的插件');

    const q = c.url.searchParams;
    const filename = safeFileName(q.get('filename') || 'plugin.zip');
    const { buf, parsed } = await readZipBody(c, filename);
    const version = normVersion(s(q.get('version'), 32) || parsed.version);
    const stage = stageBuffer(c, buf, parsed);
    try {
      const rel = saveRelease(c, p, stage, version, s(q.get('changelog'), 500));
      return {
        ok: true,
        plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', p.id), { owner: true }),
        release: releaseInfo(rel, { entries: true }),
        msg: `《${p.name}》新版本 v${version} 已发布`,
      };
    } catch (e) {
      try {
        fs.rmSync(stage.zipPath, { force: true });
      } catch {}
      throw e;
    }
  });
}
