# 明日方舟（Arknights）· JlWBoT 插件

森空岛（Skland）签到 + 个人数据卡片 + 肉鸽 / 基建（家具+基建）/ 剿灭（剿灭+保全）/ 干员（含时装）等数据查询。
纯 JS 进程内插件（`type: "js"`），**不需要插件令牌**，装好即在框架进程里跑。

- 数据来源：森空岛 `zonai.skland.com` + 鹰角账号 `as.hypergryph.com`
- 卡片出图：Windows 自带 PowerShell + GDI+（微软雅黑），无需 npm 依赖、无需浏览器
- 凭据写进 **VSQL 的 shared 库**（`arknights_users` 表），**不会出现在回复或日志里**

示例图（`preview/` 目录，演示数据）：

| 个人数据 | 家具 · 基建（合并） |
| --- | --- |
| ![个人数据](preview/profile.png) | ![家具基建](preview/detail-home.png) |

`-all` 是一张长图（760×约 1800），只回 1 条消息：

![全部数据](preview/profile-all.png)

干员 + 时装合并卡片：[preview/detail-char.png](preview/detail-char.png)

---

## 1. 安装

> **前置插件：VSQL**（框架自带的 SQLite 服务）。账号数据存在 VSQL 的 `shared` 库里，没装/没启用 VSQL 时
> 本插件会提示「缺少前置插件 VSQL」，指令不可用；在面板「插件」页启用 VSQL 后重载本插件即可。

把整个 `Arknights` 目录放到：

```text
~JlWBoT/plugins/Arknights/
├─ plugin.json
├─ index.js          # 指令路由、登录、卡片发送
├─ api.js            # 对外 API（其他 JS 插件调用）
├─ api.html          # 面板「API」按钮里的接口文档
├─ lib/
│  ├─ skland.js      # 森空岛 / 鹰角接口 + 签名
│  ├─ service.js     # 业务层：签到 / 个人数据 / 绑定（指令与 API 共用）
│  ├─ store.js       # 凭据存储（走 VSQL 的 shared 库，arknights_* 表）
│  ├─ card.js        # 卡片排版（绘制指令）
│  ├─ draw.js        # 调 PowerShell 出图 / 图片缓存
│  ├─ render.ps1     # GDI+ 渲染器（纯 ASCII 源码）
├─ settings.html     # 面板「编辑插件 → 设置」页
├─ assets/icon.png   # 插件图标（也会按 iconUrl 自动更新）
└─ data/             # 运行时：settings.json、卡片缓存（账号在 VSQL 的 shared 库）
```

然后在面板「插件」页点 **重新加载**（或重启机器人）。日志里出现
`明日方舟插件已加载` 即成功。

> 框架只在 `~JlWBoT/plugins/.seeded` 不存在时才从仓库 `plugins/` 复制示例，
> 所以新增插件请**手动复制**到 `~JlWBoT/plugins/` 后再重载。

---

## 2. 登录（仅限私聊）

> 🔒 登录相关指令（`login` / `验证码` / `导入`）**只在私聊里执行**。群里发送会被直接拦下，
> 并提示用户「私聊机器人登录」；登录成功后再回群里用签到 / 个人数据。

| 方式 | 私聊指令 | 说明 |
| --- | --- | --- |
| 短信验证码 | `/Arknights login 手机号` → **直接回复 6 位数字** | 不用再带指令；校验失败保持沉默，成功才继续 |
| 账号密码 | `/Arknights login 手机号 密码` | 群里发了也不会处理，只在私聊生效 |
| 导入 token | `/Arknights 导入 token=鹰角token` | 已有鹰角登录 token 时使用 |

> 验证码也兼容指令写法：`/Arknights 验证码 123456` 或 `/Arknights login 手机号 123456`；
> 平时直接回数字更省事。

`login` 与「登录」等价。登录后自动读取森空岛绑定的 **明日方舟 / 终末地** 角色，并在
账号写进 VSQL shared 库的 `arknights_users`（`cred / token / user_id`，不保存密码）与 `arknights_bindings`（逐个登记角色，终末地一个账号多个角色会分行）。

凭据过期时插件会自动尝试 `/api/v1/auth/refresh`；彻底失效会提示重新登录。

### 2.1 被鹰角「踢下线」时怎么办

> 据鹰角下发需求：**在登录一处后其他授权会被自动登出并自动过期**。所以第三方（本插件）的 cred 随时可能失效，
> 接口会返回 `404` / `code 10000 请求异常`。插件按登录方式区别处理：

| 登录方式 | 被踢下线后的行为 |
| --- | --- |
| 账号密码 | 用保存的鹰角 token 自动重登（换新 cred/token）→ 重试刚才的指令 |
| 导入 token | 先尝试自动重登 → 成功继续执行，失败返回提示 |
| 短信验证码 | **不自动重连**，直接返回提示（重新发一次 `/Arknights 登录 手机号` 即可） |

失败时统一提示：

```text
【404】鹰角网络拒绝了此次操作，请检查是否登录森空岛或第三方授权平台
据鹰角下发需求：在登录一处后其他授权会被自动登出并自动过期
```

> 1.10.0 之前登录的老用户没有保存鹰角 token，第一次被踢会直接收到提示；重新登录一次之后就会记录方式与 token，之后即可自动重登。

---

## 3. 指令

| 指令 | 作用 |
| --- | --- |
| `/Arknights` | 菜单（列出全部指令；下方按钮点击后只把指令填进输入框）。**`/Arknights 菜单` 和它完全等价**，回复内容共用同一份模板 |
| `/Arknights login 手机号` | 发送森空岛短信验证码（随后直接回 6 位数字） |
| `/Arknights 验证码 123456` / `/Arknights login 手机号 123456` | 也可用指令提交验证码 |
| `/Arknights login 手机号 密码` | 账号密码登录 |
| `/Arknights 导入 token=…` | 用已有鹰角 token 登录 |
| `/Arknights 签到` | 森空岛签到：明日方舟 + 终末地（多角色逐个签） |
| `/Arknights 个人数据` | 个人数据卡片：UID / 等级 / 名字 / 助理（含皮肤）/ 助战 / 月卡 / 理智 / 单点与回满时间；**常驻任务 + 招募进度** |
| `/Arknights 个人数据 -rg` | 附带肉鸽面板 |
| `/Arknights 个人数据 -jj` | 附带 基建（家具 + 基建）合并面板 |
| `/Arknights 个人数据 -jm` | 附带 剿灭（剿灭 + 保全）合并面板 |
| `/Arknights 个人数据 -gy` | 附带 干员（含时装）面板 |
| `/Arknights 个人数据 -all` | 全部面板拼成**一张长图**，只回 1 条消息 |
| `/Arknights 肉鸽` | 单独查肉鸽 |
| `/Arknights 基建` | 家具 + 基建合并一张图（总数 / 摆放 / 宿舍 / 制造 / 贸易 / 发电 / 无人机） |
| `/Arknights 剿灭` | 剿灭 + 保全合并一张图（最高击杀 / 奖励 / 最佳层数） |
| `/Arknights 干员` | 干员 + 时装合并一张图（稀有度 / 精二 / 满级 / 专三 / 动态皮肤 / 品牌） |
| `/Arknights 活动` | 活动关卡进度 |
| `/Arknights 生息` | 生息演算存档数据 |
| `/Arknights 账号` | 查看绑定角色（含当前选中） |
| `/Arknights 切换 2` | 切换当前角色（序号或 UID） |
| `/Arknights 刷新` | 重新同步森空岛绑定 |
| `/Arknights 登出` | 清除本机凭据 |

`个人数据` 后面的参数可以叠加：`-rg -jj -jm -hd -sx -gy`（`-jg` = `-jj`、`-bq` = `-jm` 仍可用），
也可以加 `-json` 返回原始 JSON（前 1800 字符，用于排查字段）。

> 任务 / 招募已并入 `个人数据`，皮肤已并入 `干员`，家具+基建统一用 `基建`，剿灭+保全统一用 `剿灭`；
> `家具` / `保全` 仍可作为别名使用。

---

## 4. 对外 API（其他插件调用）

签到 / 个人数据 / 绑定都做成了同进程接口，供其他 JS 插件直接调用。接口说明写在独立的
[api.html](api.html) 里：面板插件卡片上的「API」按钮直接打开它（沙箱 iframe），也可以直接用浏览器访问
`http://127.0.0.1:8686/api/plugins/Arknights/api-doc`。

![API 文档页](preview/api-doc.png)

```js
// 方式 A：全局注册表（推荐，不用知道路径）
const ak = globalThis.__JLWBOT_PLUGIN_APIS__?.get('Arknights');
if (ak?.isReady()) {
  if (!ak.isLoggedIn(openid)) return { reply: '请先私聊机器人登录明日方舟账号' }; // 登录确认
  const sign = await ak.sign(openid);      // { accounts: [...], errors: [...] }
  const p = await ak.profile(openid);      // { binding, data }
}

// 方式 B：直接 require
const ak = require(path.join(pluginsRoot, 'Arknights', 'api.js'));
```

| 方法 | 说明 |
| --- | --- |
| `isReady()` | 插件是否已加载 |
| `isLoggedIn(openid)` | **登录确认**：该 QQ 用户是否登录过森空岛账号，返回 `true / false`（同步、纯本地判断，不联网） |
| `sign(userKey, {games?, refresh?})` | 签到（默认方舟 + 终末地，多角色逐个签） |
| `signArknights(userKey)` / `signEndfield(userKey)` | 只签其中一个游戏 |
| `profile(userKey, {uid?, refresh?})` | 个人数据（森空岛原始 `data`） |
| `bindings(userKey, {refresh?})` / `refresh(userKey)` | 绑定列表 / 重新同步 |
| `status(userKey)` | 登录态（不返回凭据明文） |
| `storageBackend()` / `dbPath()` / `tables()` | 存储后端（`vsql`）、shared 库路径、本插件用到的表名 |
| `dependencyMissing()` | 缺哪个前置插件（正常空串，缺 VSQL 时返回 `VSQL`） |
| `users()` / `getUser(openid)` | 脱敏用户列表 / 单个用户（不含 cred / token） |

- `isLoggedIn(openid)` 的 `openid` 可以传字符串，也可以直接传消息对象
  （`message` / `message.author` / `{ union_openid, user_openid, member_openid }`），内部会逐个尝试；
  判别依据是 shared 库 `arknights_users` 里有没有 `cred + token`。插件没加载或 VSQL 缺失时也返回 `false`，不会抛错。
  别名 `loggedIn` / `hasLoggedIn` 等价。

- `userKey`：群聊用 `message.author.member_openid`（或 `union_openid`），单聊用 `message.user_openid`；
  必须是**已经在本插件登录过**的那个用户。
- 返回结构化数据，不替你发消息；错误码：`NOT_READY` / `NOT_LOGIN` / `NO_BINDING` / `NO_UID`。
- `sign()` 每项形如 `{ game, uid, name, status: 'signed'|'already'|'failed', awards: [{name,count}], daysSigned, message, code? }`（失败时带森空岛业务码）。一分钟内重复调用复用缓存，并发调用自动合并为一次。

## 5. 面板设置页（settings.html）

面板「编辑插件」弹窗第一页会内嵌 [settings.html](settings.html)，页面运行在沙箱 iframe 中，
通过 `parent.postMessage` 与框架通信。页面按**分栏**组织，一次只显示一类设置，默认停在「指令」：

- **指令**（第一个栏目）：每个功能的「指令词」与「菜单备注」都可编辑（触发词 1–16 字、不能重复/
  含空格或斜杠；备注 ≤60 字），保存后菜单、快捷按钮与指令识别都会用新词；非法/重复会自动回退默认值，
  旧的内置别名仍然可用。行尾「默认」按钮可单项还原，底部「全部恢复默认」一键还原。
  每行右侧还有**编辑**按钮：打开回复模板编辑器（左边 Markdown 源码、右边实时预览，变量从下拉里选再插入），
  下面 §5.1 详细说。第一行「菜单」的指令词固定显示 `/Arknights`（不可编辑）——它本身就是基础指令，
  `/Arknights 菜单` 只是别名。
- **授权账户**（第二个栏目）：授权用户数 / 绑定角色数 / 数据更新时间；每个用户的脱敏标识、登录状态、
  手机尾号、绑定角色（游戏 / 角色 / UID / 区服 / 等级 / 当前使用）、最近签到日期。
  **不显示 cred / token**，账号信息也不会写进 `plugin.json`。
- **插件配置**（第三个栏目）：图标 URL、是否启用卡片渲染、渲染超时 / 并发、森空岛 `platform` / `vName` / `dId`、
  QQ 素材保留张数；保存后框架重写 `config` 并重载插件。
- 账号摘要由插件在加载、登录、登出、切换、签到后写入运行中的 `manifest.config`（同一对象引用），
  面板每次拉取插件列表就能看到最新数据；另有 30 秒定时刷新。
- 栏目切换纯前端完成，刷新后回到默认的「指令」；底部保存条常驻，任何时候都能保存。
- 账号的增删（登录 / 登出）仍然只能在 QQ 私聊里操作，设置页是只读展示。
- 点「新页面」会打开框架的 `/plugin-settings.html?plugin=Arknights` 独立页：它带登录态读取插件信息、内嵌本设置页并转发保存，账号、指令、配置都是实时可编辑的；直接访问旧地址 `/api/plugins/Arknights/settings` 会自动跳到这个独立页。

![设置页 · 指令（默认栏目，右侧「编辑」= 回复模板）](preview/settings-commands.png)

![设置页 · 回复模板编辑器（左源码 / 右实时预览）](preview/settings-editor.png)

![设置页 · 授权账户](preview/settings-accounts.png)

![设置页 · 插件配置](preview/settings-config.png)

### 5.1 回复模板（可编辑每条指令的回复）

「指令」栏目每行右侧有**编辑**按钮，点开是模板编辑器：左边写 Markdown 源码，右边按**示例值**实时预览，
上方是**变量下拉列表**（分「全局 / 本指令专属 / 其它指令」三组），选中后旁边会显示这个变量是什么，
点「插入」就填进左侧光标位置。保存后写进 `plugin.json` 的 `config.replies[key]`，插件重载即生效。

- **语法**：Markdown + `{{变量}}`。未定义的变量渲染成空串；模板留空 = 用插件内置回复。
- **全局变量**：`{{prefix}}`（`/Arknights`）、`{{cmd.<指令key>}}`（当前指令词）、`{{note.<指令key>}}`（备注），
  所以你在设置页改过指令词后，模板里的命令会自动跟着变。
- **按指令的专属变量**（下拉里都带说明，选中→插入）：

| 模板 key | 可用变量 |
| --- | --- |
| `menu` | 只有全局变量（可用 `{{cmd.*}}` / `{{note.*}}` 自由拼菜单） |
| `sign` | `games`、`arknights`、`endfield`、`arknights.name/uid/status/line/awards/days`、`endfield.*`、`errors` |
| `accounts` / `refresh` | `accounts`（编号行）、`count` |
| `login` | `accounts`、`count` |
| `switch` | `game`、`name`、`uid`、`channel` |
| `logout` | 无（纯文本） |
| `profile` / `rg` / `jj` / `jm` / `gy` / `hd` / `sx` | `name`、`uid`、`title`、`channel`（`profile` 另有 `level`、`game`、`ap`、`ap_max`）——出图指令的模板是**图片下面的说明文字**，留空就只有图 |

- 只有真正写过的模板才会存进 `config.replies`（与默认一致会自动删除），`plugin.json` 不会被塞满。
- 编辑器里的预览用 `lib/templates.js` 的 `SAMPLE` 示例值渲染，真实回复用实时数据；两边共用同一个 `render()`。

## 6. 卡片渲染

- 尺寸 760px 宽，高度自适应；深色渐变 + 面板分区；右上角插件图标。
- `个人数据 -all` 把全部面板拼在**同一张长图**里（约 760×1800），只发 1 条被动回复，
  不额外占用消息次数。
- 渲染链路：Node 生成绘制指令（JSON）→ `powershell.exe -File lib/render.ps1` → PNG
  → 上传 QQ 素材库（`/v2/media-images/*`）→ `qqbot-media://` Markdown 图片
  → 附带 `<qqbot-at-user>` @ 提问者。
- 理智倒计时：`lastApAddTime + 6 分钟` 推算下一点，`completeRecoveryTime` 校验回满时间；
  时间戳自动兼容秒 / 毫秒，字段缺失时按剩余点数估算，不会出现一直 `00:00:00`。
- 素材上传失败时回退 `msg_type=7` 富媒体；再失败回退纯文字（内容不丢失）。
- 默认 `render.enabled=false` 可关掉出图，全部指令自动走文字版。
- 依赖：Windows + 自带 PowerShell 5.1 + 微软雅黑字体。沙箱/无 PowerShell 环境会
  自动回退文字，不会报错。

---

## 7. 接口与签名（维护用）

签名与森空岛客户端一致（`lib/skland.js` 的 `buildSign`）：

```text
timestamp  = 当前秒 - 2
headerJson = {"platform":"1","timestamp":"…","dId":"…","vName":"1.28.0"}   # 键序固定
raw        = path + (GET 的 query / POST 的 body) + timestamp + headerJson
sign       = md5( hmac_sha256(raw, token).hex )
```

请求头：`cred / platform / timestamp / dId / vName / sign`。

| 用途 | 方法 & 路径 |
| --- | --- |
| 绑定列表 | `GET /api/v1/game/player/binding` |
| 个人数据 | `GET /api/v1/game/player/info?uid=&userId=` |
| 签到日历 | `GET /api/v1/game/attendance?uid=&gameId=1` |
| 明日方舟签到 | `POST /api/v1/game/attendance` `{uid, gameId:1}` |
| 终末地签到 | `POST /api/v1/game/endfield/attendance` `{uid, gameId, roleId, serverId}` |
| token 刷新 | `POST /api/v1/auth/refresh` |
| code 换 cred | `POST /api/v1/user/auth/generate_cred_by_code` `{code, kind:1}` |

`dId` 默认留空；读取个人数据失败时会自动依次尝试
`""` → `de9759a5afaa634f` → 随机 32 位十六进制，规避服务端风控差异。
要固定的话改 `plugin.json` 的 `config.api.dId`。

---

## 8. 常见问题

| 现象 | 处理 |
| --- | --- |
| 提示「还没有登录森空岛」 | 先 `/Arknights 登录 手机号 密码`（私聊） |
| 短信验证码收不到 / 提示需要滑块 | 改用密码登录，或 `/Arknights 导入 token=…` |
| 提示「登录状态失效」 | 重新登录；凭据过期后自动刷新失败即需重登 |
| 没有读到绑定角色 | 先在森空岛 App 绑定明日方舟 / 终末地角色，再 `/Arknights 刷新` |
| 卡片变成文字 | 检查面板「编辑插件 → 设置」里卡片渲染是否开启；多见于无 PowerShell 的服务器 |
| 肉鸽不显示等级 | 森空岛返回里没有 `level` 字段时只能显示藏品 / 存钱罐 / 任务；可 `-json` 看原始数据 |
| 签到失败「请检查森空岛Cred是否过期」 | 重新登录后再签 |
| 签到失败「请求异常」 | 森空岛限流/风控（code 10000）。已做 1 分钟单飞 + 结果缓存 + 重复签到不刷新 token，稍后再试即可；1.4.7 起日志会带上 `code 10000 · HTTP · 接口路径 · 时钟偏差`，先看日志再判断是限流、时钟还是网络 |

---

## 9. 隐私

- 不保存手机号密码，只保存 `cred / token / userId` 与绑定信息。
- 日志只记录动作与错误，不打印凭据。
- `/Arknights 登出` 立即清除本机凭据。

---

# 工程档案（跨会话恢复用）

> **维护铁律：每完成一项任务，先把「这次改了什么 / 验证结果 / 新踩的坑 / 当前状态」写回本文件，再结束回复。**
> 会话上下文会被压缩，聊完就可能忘掉细节；只有落进本文件的才算真的保存下来 —— **不写下来 = 没做过**。
> 具体收尾步骤见 §18。

> 这一部分写给维护者 / 后续接手的会话：看完 §10–§18 就能在不问人的情况下改这个插件。
> 命令都在仓库根目录（`DSH机器人`）执行；源码目录 `plugins/Arknights`，运行时目录 `~JlWBoT/plugins/Arknights`。

## 10. 文件职责

| 文件 | 规模 | 职责 |
| --- | --- | --- |
| `index.js` | ~1200 行 | 插件入口：`onLoad / onEvent / onUnload`、指令路由、登录流程、菜单与快捷按钮、卡片下发、运行时 `ensureRuntime` |
| `lib/commands.js` | ~150 行 | 16 条指令的默认定义（key / group / trigger / note / 别名）、`sanitizeTrigger`、`sanitizeNote`、`resolveCommands`、`commandMap` |
| `lib/templates.js` | ~250 行 | 回复模板：默认模板 `DEFAULTS`、变量说明 `VAR_DOC`、预览示例 `SAMPLE`、`{{变量}}` 渲染 `render()` |
| `lib/skland.js` | ~450 行 | 森空岛客户端：`buildSign`、`withSession`、绑定 / 玩家信息 / 签到 / 刷新、`AUTH_ERROR_CODES`、刷新冷却 |
| `lib/service.js` | ~350 行 | 业务层（指令与对外 API 共用）：`session / refreshBindings / bindings / resolveBinding / playerInfo / profile / signArknights / signEndfield / signAll` |
| `lib/store.js` | ~430 行 | 账号存储：走 **VSQL**（shared 库的 `arknights_*` 四张表）、事务、从旧 `accounts.sqlite`/`accounts.json` 一次性迁移；VSQL 缺失抛 `MissingDependency` |
| `lib/card.js` | ~900 行 | 森空岛原始数据 → 绘制指令（JSON）：个人数据 / 肉鸽 / 家具基建 / 剿灭保全 / 干员时装 / 活动 / 生息 / 任务 / 招募 |
| `lib/draw.js` | ~250 行 | `Renderer`：起 `powershell.exe -File lib/render.ps1` 出 PNG、图片与图标缓存、并发控制 |
| `lib/render.ps1` | ~250 行 | GDI+ 绘制脚本（**纯 ASCII 源码**，中文与图片地址都从 UTF-8 JSON 读入） |
| `settings.html` | ~700 行 | 面板设置页：三个栏目（指令 / 授权账户 / 插件配置），`postMessage` 协议 |
| `api.js` | ~120 行 | 把公开方法挂到 `globalThis.__JLWBOT_PLUGIN_APIS__.get('Arknights')` |
| `api.html` | 独立页 | 给别人看的 API 文档（版本号、方法表、返回示例、错误码） |
| `assets/icon.png` | — | 菜单 / 卡片右上角图标（`config.iconUrl` 为空时用它） |
| `preview/*.png` | — | README 用示例图（演示数据，不是真实账号） |

## 11. 一条消息的完整链路

1. 框架把 `GROUP_AT_MESSAGE_CREATE / GROUP_MESSAGE_CREATE / C2C_MESSAGE_CREATE / AT_MESSAGE_CREATE / MESSAGE_CREATE / DIRECT_MESSAGE_CREATE` 交给 `onEvent`。
2. `route()` 判断前缀 `/` 或 `／`（机器人自己的消息直接忽略），剥掉 `/Arknights`、`/arknights`、`/ark`、`/ak`、`/方舟`、`/明日方舟`、`/森空岛` 之一。
3. 取第一个词 → `rt.commandMap`（由 `resolveCommands(rawConfig)` 生成，内置别名 + 设置页改过的指令词都能命中）。
4. 私聊限制：`login / code / import` 只在 `c2c / dm` 生效；群里发这几个词只回「私聊登录」提示。
5. 裸 6 位数字 → `handleBareCode`（仅在 `c2c / dm` 且该用户有待验证码时生效，失败静默不回复）。
6. 数据类指令 → `lib/service.js` → `lib/skland.js`（带签名请求）→ `lib/card.js` 组 spec → `lib/draw.js` 出 PNG
   → 上传 QQ 素材（`/v2/media-images/prepare → PUT → complete`）→ `msg_type=2` Markdown 卡片并 `<qqbot-at-user>`；
   上传失败退 `msg_type=7` 富媒体，再失败退纯文本。
7. 每次登录 / 登出 / 切换 / 刷新 / 签到后调 `publishAccounts()` / `publishCommands()`，把账号摘要与指令表写进
   运行中的 `manifest.config`（同一对象引用，只改内存，**不落 `plugin.json`**），面板 `GET /api/plugins` 立刻能读到。

> **回复模板**：文字类回复先走 `applyTemplate(rt, key, vars)`（`lib/templates.js`）——模板为空就返回 `''`，
> 调用方继续用内置回复；不为空则 `sendHint(ctx, md)`。出图类指令的模板是图片下面的 caption（`sendCard(ctx, img, caption)`）。
> 新增指令如果要有模板，记得在 `templates.js` 的 `DEFAULTS` / `VAR_DOC` / `SAMPLE` 三处补一份。

> 所有面向用户的文案都按 Markdown 写（`**加粗**`、`- 列表`、`## 标题`），统一由 `sendRich(ctx, md, plain)`
> 走 `msg_type=2` 发送；不支持的渠道（频道私信 `dm` 等）自动退化为 `stripMarkdown(plain)` 的纯文本。
> 登录用法这类提示用 `sendHint(ctx, md, opts)`（= `sendRich` + 自动去标记），**不要再直接 `return { reply: md }`**，
> 否则客户端会把 `**` 原样显示出来（1.4.4 修的就是这个）。
>
> 键盘按钮统一由 `fillButton(id, label, data)` 生成：`action.type = 2`、`enter: false`、`reply: false`，
> 点击只把 `data` **填进输入框**不发送。菜单用 `menuKeyboard(rt, isPrivate)`（私聊 4 行 14 键 / 群聊 13 键），
> 登录提示用 `loginKeyboard(rt)`（1 行 3 键：手机登录 / 密码登录 / token），都通过 `sendHint(..., { keyboard })` 挂到 `msg_type=2` 消息上。
>
> **群聊 / 私聊内容要分开**：登录类指令（登录 / 验证码 / 导入）只能在私聊用，所以群聊菜单不列这些条目、
> 也不挂登录按钮，只留一行「登录请私聊机器人」；群里发登录指令拿到的是纯提示（无按钮，避免填进去又被拦）。
> 判定统一用 `PRIVATE_KINDS.has(ctx.message?.kind)`。

## 12. 配置与数据

`plugin.json` 的 `config`：

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `iconUrl` | `""` | 空白则用 `assets/icon.png`；也可填 http(s) 图片地址，首次渲染下载后缓存 |
| `render.enabled` | `true` | 关掉后所有查询走纯文字，不依赖 PowerShell |
| `render.timeoutMs` | `20000` | 单张卡渲染超时 |
| `render.maxConcurrent` | `2` | 同时渲染张数上限 |
| `api.platform` / `api.vName` | `"1"` / `"1.28.0"` | 签名头里伪装客户端用的固定值 |
| `api.dId` | `""` | 留空时读取个人数据会依次尝试 `""` → `de9759a5afaa634f` → 随机 32 位 |
| `mediaKeep` | `40` | QQ 素材库中 `arknights-card-*` 的保留张数 |
| `cardTtlMs` | `300000` | 卡图短链缓存时长 |
| `commands` | 缺省 | 设置页保存的 `[{key,trigger,note}]`；缺省或留空时用 `lib/commands.js` 的内置 16 条 |
| `replies` | 缺省 | 设置页保存的回复模板 `{ key: "markdown…" }`；只存用户改过的项，缺省 = 用 `lib/templates.js` 的内置回复 |

运行时只读字段（框架返回给面板，**不要写进 plugin.json**）：`accountsView`、`accountsUpdatedAt`、`commandsInfo`、`repliesInfo`。

账号数据存在 **VSQL**（框架自带的 SQLite 服务插件，作为本插件的**前置依赖**）的默认 `shared` 库里，
表名统一带 `arknights_` 前缀，其他插件不用碰路径就能直接查：

```text
arknights_users      (key PK, name, cred, token, user_id, phone_tail, created_at, updated_at)
arknights_bindings   (user_key, game, uid, app_code, game_id, channel_name, nick_name,
                      role_id, role_name, server_id, level)  PK(user_key, game, uid)
arknights_active     (user_key, game, uid)                   PK(user_key, game)
arknights_last_sign  (user_key, target, date, at)            PK(user_key, target)
```

说明：

- **为什么交给 VSQL**：所有插件同一个 `.db`（`~JlWBoT/plugins/VSQL/data/dbs/shared.db`），A 插件建的表 B/C 直接读写，不用各自管文件、不用各自引驱动；VSQL 内部就是 `node:sqlite` + WAL，按行读写，内存占用小。
- **缺前置会怎样**：`onLoad` 打 error 日志，任何指令都回复「缺少前置插件 VSQL，请在面板启用 VSQL 后重载」；VSQL 后来被启用时，插件下一次收到消息会自动接上（无需重启本插件）。
- **迁移**：老版本的 `data/accounts.sqlite`（1.8.0）/ `data/accounts.json`（更早）会在首次成功连接 VSQL 时导入 shared 库，原文件改名 `.migrated` 保留。
- 签到的「今天」按 **04:00 游戏日**切分（`todayKey()` 用 `now - 4h`），凌晨 0–4 点仍算前一天。
- `data/settings.json`：用户设置快照 `{ commands, replies, updatedAt }`。每次 `onLoad` 都写一份；
  如果 `plugin.json` 是「全新未配置」（没有 `config.commands`），加载时自动用快照恢复指令表与回复模板 —— 换版本覆盖了 `plugin.json` 也不丢设置。

## 13. 部署 / 重载 / 打包（本机流程）

```powershell
# 1) 同步源码到运行时（务必排除 data/，那是线上授权数据）
#    逐文件复制，别用 robocopy /XD 拼接路径（历史事故：把 data 覆盖成空）
# 2) 重载插件（面板会话 Cookie：jlw_sid，值见 ~JlWBoT/data/sessions.json）
POST http://127.0.0.1:8686/api/plugins/Arknights/reload
# 3) 校验
GET  http://127.0.0.1:8686/api/plugins         → status=running / version / accountsView / commandsInfo
GET  http://127.0.0.1:8686/api/plugins/Arknights/settings
```

- 面板 `/api/*` 需要会话 Cookie `jlw_sid`；`plugins.token` 只对 `/plugin-api/v1/*` 有效。
- **更新插件**：只覆盖代码文件（`index.js`、`lib/`、`settings.html`、`api.*`、`README.md`），`plugin.json` 能不覆盖就不覆盖；
  `data/` 永远不要覆盖/删除。1.6.0 起即使 `plugin.json` 被覆盖，只要之前跑过一次（生成了 `data/settings.json`），
  启动时会自动把指令表与回复模板恢复回来。
- `autoReload` 存在但改文件不一定立刻重载，改完代码**手动 POST 一次 reload** 最稳。
- 干净发布包规则（当前产物：`插件/Arknights-【v1.4.3】.zip`）：
  - 只含 25 个文件（含 lib/templates.js、preview/settings-editor.png），**不含** `data/`、`明日方舟模块.e`、`原版乌啪.png`、`透明乌啪.jpg`；
  - `plugin.json` 重置为出厂态：`iconUrl: ""`，删掉 `config.commands`、`accountsView`、`accountsUpdatedAt`、`commandsInfo`；
  - 压缩包条目名用正斜杠，`plugin.json` 放在**根目录**（导入器要求根或单层子目录），普通 deflate、无加密、无 ZIP64；
  - 命名 `插件名-【v版本号】.zip`，放 `插件/` 目录；
  - 面板导入入口：插件页「导入插件」→ 选 zip → 「开始导入」；限制：上传 12MB、单文件解压 18MB、总解压 60MB，**同名插件不覆盖**。

## 14. 自检清单（改完必跑）

1. **空数据加载**：Node 载入 `index.js`，用桩 ctx（`plugin.dir` 指向临时目录）跑 `onLoad / onUnload`，
   应自动建 `data/`、解析出 16 条默认指令、无异常、无残留。
2. **真机状态**：`GET /api/plugins` → `Arknights.status = running`、`version` 正确、`config.commandsInfo` 16 条、
   `config.accountsView` 数量与授权用户一致。
3. **设置页**：`GET /api/plugins/Arknights/settings` 应含 `data-tab="commands" / "accounts" / "config"`；
   宿主页 `http://127.0.0.1:8686/plugin-settings.html?plugin=Arknights` 三个栏目都能点开、能读到真实账号。
4. **接口**：`GET /api/v1/game/player/binding` 正常返回 `code:0`，说明签名与 cred 未失效。
5. **回复模板**：`config.replies` 里有模板时，对应指令必须走模板（自测：桩 ctx 里塞 `replies: { menu: '# 自定义\n{{prefix}} {{cmd.sign}}' }`，
   回包 markdown 应等于渲染结果）；设置页编辑器要能实时预览、变量下拉可插入、「完成」后按钮变「编辑 · 已改」，
   保存 payload 里只有 `replies`、没有 `repliesInfo`。
6. **设置快照**：先正常加载一次（生成 `data/settings.json`），再把 `plugin.json` 换成一版没有 `config.commands` 的
   （模拟覆盖更新），重启后指令词与回复模板应自动恢复，日志出现「已从 data/settings.json 恢复用户设置」。
7. **存储 / 前置 / 迁移**：正常时 `storageBackend()` 返回 `vsql`，VSQL shared 库里能看到 `arknights_*` 四张表；
   把 VSQL 停用后重载，日志应报「缺少前置插件 VSQL」、指令回复同样提示；重新启用 VSQL 后不重启本插件，下一条消息应自动接上。
   老 `data/accounts.sqlite` / `accounts.json` 存在时首次连接应迁移并改名 `.migrated`，`getUser()` 能读到老数据。
8. **发布包**：用框架自己的 `unzipEntries` 解开 zip，检查 27 个条目、根目录 `plugin.json`、无 `data/`、
   逐文件哈希与源目录一致。

## 15. 踩过的坑（改之前先看）

| 坑 | 现象 / 处理 |
| --- | --- |
| PowerShell 5.1 编码 | `Get-Content` 默认按 ANSI 读 UTF-8 → 批量替换会把中文写成乱码。**改文件一律用 `node` + `fs.readFileSync/writeFileSync('utf8')`**（无 BOM），改完扫一遍 U+FFFD 与 `锛/鏄/鑸` 之类的乱码特征 |
| `render.ps1` 中文 | PowerShell 5.1 会把无 BOM 的 UTF-8 脚本当 ANSI 解析 → 脚本保持**纯 ASCII**，所有中文以 UTF-8 JSON 传入 |
| 沙箱 spawn | 管道 stdio 在 DSH 沙箱里 `EPERM` → 用 `stdio:'ignore'`，渲染错误写 `<out>.err` 文件回读 |
| 森空岛 404 / 10000 | 鹰角改成「登录一处、其他授权自动登出」，第三方 cred 会被踢下线，表现为 HTTP 404 或 `code 10000 请求异常`。1.10.0 起：账密授权用保存的鹰角 token 自动重登后重试；token 授权先试重登，失败给 404 提示；短信验证码登录不重连、直接给提示。日志仍会打印 `code / HTTP / 路径` 便于排查；不要把 10000 当鉴权失败去无限刷新（会触发刷新风暴） |
| 森空岛 HTTP 400 | 有些返回 400 但 body `code:0`，曾误判成功 → `sklandCall` 现在 `!r.ok` 直接抛错 |
| 签到重复点 | 1 分钟单飞（`inflightSigns`）+ 结果缓存，终末地当日已签直接短路，避免重复 POST 触发限流 |
| AP 倒计时 | `lastApAddTime` 秒/毫秒都可能；`completeRecoveryTime` 只在 1 个 tick 内可信，否则显示「已满」或按剩余点数估算 |
| 设置页 iframe | CSP `sandbox allow-scripts allow-popups`（`connect-src 'none'`）→ 页面不能联网、也不能读 iframe DOM；与框架只靠 `postMessage`（`jlw-settings-init / -save / -saved / -save-request`） |
| 独立打开设置页 | 直接开 `/api/plugins/Arknights/settings` 拿不到 init 消息 → 页面顶部判断 `window.top === window` 时自动 `location.replace('/plugin-settings.html?plugin=Arknights')` |
| zip 导入报「找不到 plugin.json」 | 条目名用了反斜杠或包了一层多余目录 → 用正斜杠、`plugin.json` 放根 |
| 一条指令回两条 | 两个实例各回一条（一旧一新）。1.5.2 起每个实例在 `globalThis` 注册自增序号，**只有最新实例回消息**，旧实例完全静默；最新实例卸载后旧实例自动接管。日志会提示「有 2 个实例在运行，只让最新的实例 #N 回消息」。若告警持续出现，去面板插件页删掉重复安装的那份 |
| 工作区限制 | 文件沙箱为 workspace-write；`~JlWBoT` 在工作区内可写，但**严禁**把 `data/` 覆盖到源码目录或反向复制 |

## 16. 版本历史

| 版本 | 变更 |
| --- | --- |
| 1.0.0 | 初版：菜单、森空岛登录、签到、个人数据卡片（GDI+ 渲染）、`-rg/-jg/-jm/-gy/-hd/-sx/-all/-json` |
| 1.1.0 | 面板设置页、对外 API（`__JLWBOT_PLUGIN_APIS__`）、独立 `api.html` |
| 1.2.0 | `-all` 合成一张长图、单条被动回复；去掉预览/状态指令；家具+基建、剿灭+保全合并 |
| 1.3.0 | 指令改名为 `基建 / 剿灭 / 干员`（保留旧别名）；任务+招募并入个人数据 |
| 1.3.1 | 修复签到「请求异常」：10001 不再当鉴权失败、刷新冷却、终末地短路、单飞与缓存 |
| 1.4.0 | 指令可编辑（触发词 / 备注），保存后菜单、按钮、识别同时生效 |
| 1.4.1 | 修复独立设置页空白：插件把账号摘要写进运行时 `manifest.config` 供页面读取 |
| 1.4.2 | 接入框架 `/plugin-settings.html?plugin=<id>` 宿主页，移除 1.4.1 的临时快照方案 |
| 1.4.3 | 设置页拆三个栏目（指令 / 授权账户 / 插件配置，默认指令）；图标默认值改为空（回落 `assets/icon.png`）；导出纯净 zip |
| 1.4.4 | 登录用法 / 私聊提示改走 Markdown（`msg_type=2`，加粗与列表正常渲染，`dm` 等渠道自动退化为纯文本）；删掉「登录信息只保存在本机插件目录」这句多余说明 |
| 1.4.5 | 登录提示底部挂 3 个按钮（手机登录 / 密码登录 / token），`enter:false` 只填指令不发送；键盘按钮抽成 `fillButton()` 与菜单共用 |
| 1.4.6 | 菜单按会话分流：群聊不再出现登录 / 验证码 / 导入条目与登录按钮（只留「请私聊」提示），私聊保持完整菜单 |
| 1.4.7 | 「请求异常（10000）」可诊断化：日志带 `code / HTTP / 接口路径 / 时钟偏差`；10000 不再触发 token 刷新（只认 10002/10003）；连续失败 20 秒冷却，避免越重试越被风控 |
| 1.5.1 | 「一条指令回两条消息」兜底：按 message.id 去重（30 秒），同内容 5 秒内不重发，去重表挂 `globalThis` |
| 1.10.1 | 签到失败行改成引用块样式：去掉「签到失败：」前缀，改为 `> 【404】…`（前面补空行，markdown 渲染成引用块） |
| 1.10.0 | 适配鹰角「一处登录、其他授权自动登出」：记录登录方式与鹰角 token；被踢（404 / 10000）时账密授权自动重登并重试、token 授权先试重登、短信登录直接提示；错误文案统一为「【404】鹰角网络拒绝了此次操作…」 |
| 1.9.0 | 账号存储改为 **VSQL 作为前置依赖**：数据写进 shared 库的 `arknights_*` 四张表，其他插件不用碰文件、直接 `vsql.db().all(...)` 就能查/改；缺 VSQL 时明确提示「缺少前置插件」并在其上线后自动接上；旧 `accounts.sqlite` / `accounts.json` 首次连接自动迁移。移除自带 SQLite/JSON 双后端 |
| 1.8.0 | 账号存储换成 **SQLite**（`data/accounts.sqlite`，Node 22.5+ 自带 `node:sqlite`）：老 JSON 自动迁移、按行读写不整表载入、其他插件可只读查库；新增 API `storageBackend / dbPath / users / getUser`；没有 `node:sqlite` 的环境自动回退 JSON |
| 1.7.1 | 新增对外 API `isLoggedIn(openid)`（登录确认，返回 boolean）：纯本地判断，只认 `cred + token`，支持传 openid 字符串或消息对象，插件未加载返回 `false` |
| 1.7.0 | `菜单` 合并进基础指令：`/Arknights` 与 `/Arknights 菜单` 共用同一份回复模板；设置页菜单行显示固定 `/Arknights`（不可编辑），别名仍然可用 |
| 1.6.0 | 回复模板编辑器改用「变量下拉 + 说明 + 插入」；用户设置（指令表 / 回复模板）额外快照到 `data/settings.json`，覆盖 `plugin.json` 更新也能恢复 |
| 1.5.2 | 只让**最新加载**的那个实例回消息：每个实例在 `globalThis` 注册序号，旧实例直接静默（不再回复旧配置的内容），最新实例卸载后旧实例自动接管 |
| 1.5.0 | 回复模板：每条指令可在设置页「编辑」里改 Markdown 回复，支持 {{变量}}（全局 cmd./note. + 各指令专属），编辑器左源码右实时预览；出图指令支持图片下方说明文字 |

## 17. 当前状态（2026-11-21）

| 项 | 值 |
| --- | --- |
| 线上版本 | `1.10.1`，`status = running`，优先级 80，超时 60s |
| 指令 | 16 条（菜单/登录/验证码/导入/登出/账号/切换/刷新/签到/个人数据/肉鸽/基建/剿灭/干员/活动/生息） |
| 授权 | 1 个已登录用户，2 个绑定角色（明日方舟 + 终末地），签到按 04:00 游戏日 |
| 对外 API | `__JLWBOT_PLUGIN_APIS__.get('Arknights')`：`isReady / isLoggedIn（登录确认）/ sign / signArknights / signEndfield / profile / bindings / refresh / status`，`VloS` 插件在用 |
| 发布包 | `插件/Arknights-【v1.10.1】.zip`（纯净，可直接面板导入） |
| 设置页 | 宿主页 `/plugin-settings.html?plugin=Arknights`；三栏目；保存会整份替换 `config` 并重载插件 |
| 文档 | README §10–§18 工程档案；§18 = 每次任务收尾必做（不写文件就等于没做） |
| 部署状态 | 运行时目录已同步 1.10.1（2026-11-23 23:25）；当时机器人未运行，下次启动自动加载，无需手动 reload |

> 新会话接手顺序：读本文件 §10–§18 → `GET /api/plugins` 看当前状态 → 需要改代码再从 `plugins/Arknights` 动手。
> 真实账号数据在 VSQL 的 shared 库 `~JlWBoT/plugins/VSQL/data/dbs/shared.db`（`arknights_*` 表），本文件不记录任何 UID、手机号、凭据。

## 18. 维护约定 · 每次任务收尾必做

**每次完成任务后都记得保存**：把这次的全部细节写回本 README，再给用户答复。
会话上下文会被压缩（越聊越短，早先的细节会丢），本文件是唯一可靠的跨会话记忆；只说不写等于没做。

收尾清单（按顺序做完再回复）：

1. **改了什么** → 写进对应章节：链路变动进 §11、配置/数据变动进 §12、部署与打包变动进 §13。
2. **验证结果** → 跑一遍 §14 自检，把结论（成功/失败、关键数字）写进 §17 状态表。
3. **新踩的坑** → 追加到 §15，写清「现象 + 根因 + 正确做法」，别只写现象。
4. **版本变化** → 改版本号时在 §16 补一行；同时改 `plugin.json`、`api.js`、`api.html` 三处版本字符串。
5. **同步运行时** → 复制到 `~JlWBoT/plugins/Arknights`（**排除 `data/`**），再 `POST /api/plugins/Arknights/reload`，
   用 `GET /api/plugins` 确认 `status = running` 与 `version`。
6. **发布包** → 需要给外人时重打 `插件/Arknights-【v<版本>】.zip`（§13 六条规则），并用框架的
   `unzipEntries` + `importPluginPackage` 复测一次导入。
7. **最后才回复**：答复里只放结论与路径，细节都留在本文件里。

> 判定标准：新开一个会话，只读本文件就能复现「现在是什么状态、为什么这么做、下一步改哪里」。
> 做不到，说明这次收尾没写完，回去补。
