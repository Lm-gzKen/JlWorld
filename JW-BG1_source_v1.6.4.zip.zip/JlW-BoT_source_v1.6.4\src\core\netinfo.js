'use strict';
/**
 * 公网 IP 探测（服务端发起，避免浏览器 CSP/跨域）
 * - 多源并发竞速，取第一个合法结果
 * - 缓存 10 分钟；失败时保留旧值并返回 error，面板可降级显示
 */
const os = require('os');
const net = require('net');

const V4_RE = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
const V6_RE = /\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{0,4}\b/;

const PROVIDERS = [
  { name: 'ipify', url: 'https://api.ipify.org?format=json', json: true, pick: (d) => d.ip },
  { name: 'ip.sb', url: 'https://api.ip.sb/ip' },
  { name: 'ipw.cn', url: 'https://4.ipw.cn' },
  { name: 'myip.ipip.net', url: 'https://myip.ipip.net' },
  { name: 'ifconfig.me', url: 'https://ifconfig.me/ip' },
  { name: 'ipinfo.io', url: 'https://ipinfo.io/ip' },
  { name: 'ip-api', url: 'http://ip-api.com/line/?fields=query' },
];

class NetInfo {
  constructor({ logger, ttlMs = 10 * 60 * 1000, timeoutMs = 4500 }) {
    this.log = logger.child('netinfo');
    this.ttlMs = ttlMs;
    this.timeoutMs = timeoutMs;
    this.cache = { ip: '', family: 0, source: '', updatedAt: 0, error: '' };
    this.inflight = null;
  }

  localAddresses() {
    const out = [];
    const ifaces = os.networkInterfaces();
    for (const [name, list] of Object.entries(ifaces)) {
      for (const item of list || []) {
        if (item.internal) continue;
        if (item.family !== 'IPv4' && item.family !== 4) continue;
        if (item.address.startsWith('169.254.')) continue;
        out.push({ name, address: item.address });
      }
    }
    return out;
  }

  _valid(ip) {
    return !!ip && net.isIP(ip) !== 0;
  }

  async _one(p) {
    const res = await fetch(p.url, {
      headers: { 'User-Agent': 'JlWBoT/1.0', Accept: 'text/plain, application/json' },
      signal: AbortSignal.timeout(this.timeoutMs),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const text = (await res.text()).trim();
    let candidate = '';
    if (p.json) {
      try {
        const data = JSON.parse(text);
        candidate = p.pick ? p.pick(data) : data.ip || data.query || '';
      } catch {
        /* fallthrough */
      }
    }
    if (!candidate) {
      const m4 = text.match(V4_RE);
      if (m4) candidate = m4[0];
      else {
        const m6 = text.match(V6_RE);
        if (m6) candidate = m6[0];
      }
    }
    candidate = String(candidate || '').trim();
    if (!this._valid(candidate)) throw new Error('返回值不是合法 IP：' + text.slice(0, 60));
    return { ip: candidate, family: net.isIP(candidate), source: p.name };
  }

  async _resolve() {
    const tasks = PROVIDERS.map((p) =>
      this._one(p).catch((e) => {
        throw e;
      }),
    );
    try {
      const r = await Promise.any(tasks);
      this.cache = { ...r, updatedAt: Date.now(), error: '' };
      this.log.info(`公网 IP：${r.ip}（来源 ${r.source}）`);
      return this.info(false);
    } catch {
      const err = '无法获取公网 IP（离线或网络受限）';
      this.cache = { ...this.cache, error: err };
      this.log.warn(err);
      return this.info(false);
    }
  }

  async get(force = false) {
    const fresh = this.cache.ip && Date.now() - this.cache.updatedAt < this.ttlMs && !force;
    if (fresh) return this.info(true);
    if (this.inflight) return this.inflight;
    this.inflight = this._resolve().finally(() => {
      this.inflight = null;
    });
    return this.inflight;
  }

  info(cached = false) {
    return {
      ok: true,
      ip: this.cache.ip,
      family: this.cache.family,
      source: this.cache.source,
      updatedAt: this.cache.updatedAt,
      error: this.cache.error,
      cached,
      hostname: os.hostname(),
      local: this.localAddresses(),
    };
  }
}

module.exports = NetInfo;
