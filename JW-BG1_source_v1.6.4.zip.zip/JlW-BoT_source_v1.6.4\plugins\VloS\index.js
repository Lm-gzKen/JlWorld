'use strict';
/**
 * VloS · 聚龙世界 QQ 机器人插件
 *
 * 账号体系：聚龙账户（/api/plugin/jl-account）
 *   - /add 邮箱        注册聚龙账户（邮箱验证码 → 密码 → 名称）
 *   - /login 邮箱 密码  登录已有聚龙账户
 *   - /bindqq QQ号     绑定 QQ（先提示不可修改，再发邮箱验证码）
 *   - /list            聚龙账户资料 / 绑定 QQ / 钱包 / 签到
 *   - /签到            随机诗词 + 龙晶 + 玄玉 + 方舟掉落
 *   - /vlos            帮助
 *
 * 插件不再发邮件、不再保存密码或验证码；密码只在注册流程的内存里短暂停留。
 */

const fs = require('node:fs');
const path = require('node:path');

const Store = require('./lib/store');
const T = require('./lib/text');
const api = require('./api.js');
const { normalizeConfig, DEFAULT_CONFIG, DEFAULT_POEMS, deepMerge } = require('./lib/defaults');
const {
  JlAccountClient,
  isTokenError,
  isEmailRegisteredError,
  isQQBoundError,
  isQQTakenError,
  isNoQQError,
  isOpenidBoundError,
  isOpenidTakenError,
  isKeyError,
  friendlyError,
} = require('./lib/jlaccount');

const PLUGIN_VERSION = '2.9.62';
const TOKEN_TTL_MS = 30 * 86400000;

/**
 * 各指令「内置默认回复」的 Markdown 模板（设置页「编辑」里预填、可一键恢复默认）。
 * - 流程类指令（注册/登录/绑定/取消…）每一步提示不同，默认模板就是 `{content}`，
 *   只在每一步提示外面套一层自定义内容；
 * - 资料/签到/菜单/帮助是固定结构，用 `{变量}` 还原真实默认排版，变量含义见设置页变量标签。
 * 这里是唯一来源：插件加载时写进 settings.html 的 vlos-command-defaults-data。
 */
const DEFAULT_COMMAND_REPLIES = {
  add: [
    '{heading}',
    '## 注册聚龙账户',
    '> 用法：{cmd_add} 邮箱',
    '> 例：{cmd_add} user@example.com',
    '系统会通过聚龙账户接口给该邮箱发送验证码；收到后按提示设置密码和显示名称。',
  ].join('\n'),
  login: [
    '{heading}',
    '## 登录聚龙账户',
    '> 用法：{cmd_login} 邮箱 密码',
    '> 请在私聊中发送，密码不要加 `/`。',
  ].join('\n'),
  bindqq: [
    '{heading}',
    '## 验证码已发送',
    '> 已发送到聚龙账户注册邮箱：**{email}**',
    '> 绑定 QQ：**{qq}**（⚠️ **绑定后无法修改 / 解绑**）',
    '> 请直接发送 6 位验证码完成绑定。',
  ].join('\n'),
  bindopenid: [
    '{heading}',
    '## OpenID 绑定成功',
    '> 聚龙账户：**{email}**',
    '> OpenID：{openid}',
    '> 填写后**不能修改**。',
  ].join('\n'),
  list: [
    '{heading}',
    '## 聚龙账户',
    '- **邮箱**：{email}',
    '- **绑定 QQ**：{qq}',
    '- **OpenID**：{openid}',
    '- **聚龙钱包**：龙晶 {wallet_longjing} · 玄玉 {wallet_xuanyu}',
    '- **签到账本**：龙晶 {ledger_longjing} · 玄玉 {ledger_xuanyu}',
    '- **签到**：累计 {days} 天 · 连续 {streak} 天 · {sign_status}',
    '',
    '{note}',
    '',
    '{footer}',
  ].join('\n'),
  sign: [
    '{heading}',
    '## 每日签到',
    '> {poem}',
    '',
    '***',
    '',
    '- **签到时间**：{time}',
    '- **龙晶**：{longjing}',
    '- **玄玉**：{xuanyu}',
    '- **累计签到**：{days} 天 · 连续 {streak} 天',
    '',
    '{pending}',
    '',
    '{note}',
    '',
    '{arknights}',
    '',
    '{footer}',
  ].join('\n'),
  menu: ['{heading}', '## 菜单', '', '{scene}', '', '{items}', '', '{footer}'].join('\n'),
  menusync: [
    '{heading}',
    '## 菜单同步',
    '- **群聊面板**：{menusync_group}',
    '- **私聊菜单**：{menusync_c2c}',
  ].join('\n'),
  groupadmin: [
    '{heading}',
    '## 群管设置',
    '> 群：**{group}**',
    '> 设置链接已私聊发送，请在私聊里查看（10 分钟内有效，提交后失效）。',
    '> 没收到私聊？请先添加机器人好友；也可以私聊发送 `/bindopenid` 绑定当前 OpenID。',
    '> **推荐使用电脑进行编辑**',
  ].join('\n'),
  help: ['{heading}', '## VloS 指令', '', '{commands}', '', '{footer}'].join('\n'),
  cancel: ['{heading}', '## 没有进行中的流程', '> 你现在没有需要取消的注册或绑定流程。'].join('\n'),
};

// 插件报错统一前缀：框架看到后只写日志、不往群聊/私聊发
const ERROR_PREFIX = '【[404 error]';
function errText(msg) {
  return `${ERROR_PREFIX} ${String(msg === undefined || msg === null ? '' : msg).trim()}】`;
}

/** VSQL（内置 SQLite 数据库服务）是 VloS 的前置插件 */
function vsqlReadyNow() {
  try {
    const g = globalThis.__JLWBOT_PLUGIN_APIS__;
    const v = g && typeof g.get === 'function' ? g.get('VSQL') : null;
    return !!(v && typeof v.isReady === 'function' && v.isReady());
  } catch {
    return false;
  }
}

/** 缺少前置时在群里 / 私聊提示一次（测试事件不打扰） */
async function notifyMissingPrereq(ctx, r) {
  if (!r.prereqMissing || r.prereqNotified) return;
  if (ctx.event?.source === 'test') return;
  const m = ctx.message;
  if (!m || (m.kind !== 'group' && m.kind !== 'c2c')) return;
  r.prereqNotified = true;
  const text =
    '> ⚠ **VloS 缺少前置插件 VSQL**（内置 SQLite 数据库服务）\n' +
    '> 当前先把数据暂存到 `data/users.json`；请安装并启用 VSQL，连上后会自动迁移并删除 users.json。';
  try {
    if (m.kind === 'group' && ctx.bot?.sendGroup) {
      await ctx.bot.sendGroup(m.group_openid, { msg_type: 2, markdown: { content: text } });
    } else if (m.kind === 'c2c' && ctx.bot?.sendC2C) {
      await ctx.bot.sendC2C(m.user_openid, { msg_type: 2, markdown: { content: text } });
    }
  } catch {
    /* ignore */
  }
}

/** 非消息类群事件：群里没有 message，只能从 ctx.raw 取字段 */
const GROUP_EVENTS = new Set([
  'GROUP_MEMBER_ADD',
  'GROUP_MEMBER_REMOVE',
  'GROUP_ADD_ROBOT',
  'GROUP_DEL_ROBOT',
  'GROUP_JOIN_REQUEST',
]);

/** @type {null | {dir:string,cfg:object,rawConfig:object|null,store:Store,jl:JlAccountClient,log:object,startedAt:number}} */
let rt = null;
const signing = new Set();
/** 注册流程：key -> {step:'code'|'password'|'name', email, code, password, name, at} */
const authFlows = new Map();
/** QQ 绑定流程：key -> {qq, at} */
const bindFlows = new Map();
/** 入群验证：`${group}:${member_openid}` -> { mode, answers, attempts, maxAttempts, passText, failText, kickText, expiresAt, at } */
const joinVerifyPending = new Map();
/** 同一成员连点同一个按钮的去重（QQ 偶发重复投递 INTERACTION_CREATE，避免一次点击算多次答错） */
const joinVerifyClicks = new Map();
const POEM_FILES = ['每日诗词.txt', 'poems.txt'];
let poemCache = { file: '', mtimeMs: 0, lines: [] };
/** /菜单同步 的冷却：key -> 时间戳 */
const menuSyncAt = new Map();
/** 并发保护：同一时刻只跑一次菜单同步 */
let menuSyncPromise = null;

/* ======================= 生命周期 ======================= */

function ensureRuntime(ctx) {
  const dir = ctx?.plugin?.dir;
  if (!dir) throw new Error('VloS：缺少插件目录');
  const rawConfig = ctx.plugin.config || {};
  if (rt && rt.dir === dir && rt.rawConfig === rawConfig) return rt;
  const cfg = normalizeConfig(rawConfig);
  const store = new Store(path.join(dir, 'data'));
  const runtime = {
    dir,
    cfg,
    rawConfig,
    store,
    jl: new JlAccountClient(cfg.jlAccount),
    log: ctx.log || console,
    bot: ctx.bot || null,
    startedAt: Date.now(),
    groupNames: new Map(),
    snapshotTimer: null,
  };
  // 用户数据保存后把只读快照写进设置页（设置页是沙箱 iframe，不能读文件 / 不能联网）
  if (typeof store.onSave === 'function') {
    store.onSave(() => scheduleUsersSnapshot(runtime));
  } else {
    const origSaveUsers = store._saveUsers.bind(store);
    store._saveUsers = () => {
      const out = origSaveUsers();
      scheduleUsersSnapshot(runtime);
      return out;
    };
  }
  rt = runtime;
  return rt;
}

/** 指令匹配：识别字符 + 指令名；识别字符为空时不要求前缀（裸词也能识别） */
function matchCommandAction(r, raw) {
  const token = String(raw || '').trim().split(/[\s\u3000]+/)[0] || '';
  if (!token) return '';
  const lower = token.toLowerCase();
  const normalizedToken = lower.replace(/^／/, '/');
  for (const [key, conf] of Object.entries(r.cfg.commands || {})) {
    if (!conf || conf.enabled === false) continue;
    const prefix = String(conf.prefix || '');
    for (const name of conf.names || []) {
      if (prefix) {
        if (normalizedToken === (prefix + name).toLowerCase()) return key;
      } else if (normalizeCmd(token) === normalizeCmd(name)) {
        return key;
      }
    }
  }
  return '';
}

function scheduleUsersSnapshot(r) {
  if (!r) return;
  clearTimeout(r.snapshotTimer);
  const t = setTimeout(() => {
    r.snapshotTimer = null;
    refreshUsersSnapshot(r);
  }, 1200);
  if (t.unref) t.unref();
  r.snapshotTimer = t;
}

async function onLoad(ctx) {
  try {
    const r = ensureRuntime(ctx);
    api.bind({ dir: r.dir, cfg: r.cfg, store: r.store, jl: r.jl, log: r.log, version: PLUGIN_VERSION });
    const poemFile = activePoemFile(r.dir);
    r.log.info(
      `VloS 插件已加载 v${PLUGIN_VERSION}：数据目录 ${path.join(r.dir, 'data')}，` +
        `聚龙账户 API ${r.cfg.jlAccount.baseUrl}${r.cfg.jlAccount.apiPath}，` +
        `发奖 Key ${r.cfg.jlAccount.key ? '已配置' : '未配置'}，` +
        `签到模式 ${r.cfg.sign.wallet ? '聚龙钱包' : '插件账本'}，` +
        `诗词库 ${poemFile ? path.basename(poemFile) : '内置 8 首'}`,
    );
    r.log.info('VloS 对外 API 已注册：__JLWBOT_PLUGIN_APIS__.get("VloS")');
    const prefixes = [...new Set(Object.values(r.cfg.commands).map((c) => c.prefix || '（无）'))].join(' / ');
    r.log.info(`VloS 指令 ${Object.keys(r.cfg.commands).length} 组，识别字符：${prefixes}`);
    r.bot = ctx.bot || r.bot;
    if (!vsqlReadyNow()) {
      r.prereqMissing = true;
      r.log.error(
        'VloS 缺少前置插件 VSQL（内置 SQLite 数据库服务）：当前暂存 users.json；安装并启用 VSQL 后会自动迁移并删除 users.json。',
      );
    }
    refreshUsersSnapshot(r);
    refreshCommandDefaultsSnapshot(r);
    await processReviewedCallbacks(r);
    refreshReviewSnapshot(r);
    notifyPendingReviewAdmins(r).catch((e) => r.log.warn('VloS 补发审核链接失败：' + (e?.message || e)));
    try {
      const pending = Object.values(loadCallbacks(r).items).filter(
        (it) =>
          (it.status === 'awaiting' && (!it.expiresAt || it.expiresAt > Date.now())) ||
          (it.reviewId && it.reviewStatus === 'awaiting'),
      );
      if (pending.length) startCallbackPolling(r);
    } catch {
      /* ignore */
    }
    if (r.cfg.sign.wallet && !r.cfg.jlAccount.key) {
      r.log.warn('VloS：签到设置为聚龙钱包模式，但没有配置发奖 Key；签到会回退到插件账本');
    }
    if (r.cfg.menu.enabled && r.cfg.menu.sync && typeof ctx.api?.call === 'function') {
      const t = setTimeout(() => {
        syncMenus(ctx, r).catch((e) => r.log.warn('VloS 菜单同步失败：' + (e?.message || e)));
      }, 2500);
      if (t.unref) t.unref();
    }
  } catch (e) {
    (ctx.log || console).error('VloS 初始化失败：' + (e?.stack || e));
  }
}

async function onUnload() {
  try {
    api.unbind();
  } catch {
    /* ignore */
  }
  if (rt?.snapshotTimer) clearTimeout(rt.snapshotTimer);
  if (callbackTimer) {
    clearInterval(callbackTimer);
    callbackTimer = null;
  }
  botJoinRetries.clear();
  rt = null;
  signing.clear();
  authFlows.clear();
  bindFlows.clear();
  joinVerifyPending.forEach(function (entry) { if (entry && entry.timer) clearTimeout(entry.timer); });
  joinVerifyPending.clear();
  joinVerifyClicks.clear();
  menuSyncAt.clear();
  poemCache = { file: '', mtimeMs: 0, lines: [] };
}

async function onEvent(ctx) {
  let r;
  try {
    r = ensureRuntime(ctx);
    if (!r.storeLogged) {
      try {
        r.storeLogged = true;
        r.log.info(
          r.store.backend === 'sqlite'
            ? 'VloS 存储后端：VSQL SQLite（shared.vlos_users）'
            : 'VloS 存储后端：users.json（VSQL 未加载，装上 VSQL 后会自动迁移）',
        );
      } catch {
        /* ignore */
      }
    }
    try {
      if (r.store.backend === 'sqlite') {
        r.prereqMissing = false;
      } else {
        r.prereqMissing = true;
        if (!r.prereqMissingLogged) {
          r.prereqMissingLogged = true;
          r.log.error('VloS 缺少前置插件 VSQL：当前使用 users.json 暂存，安装并启用 VSQL 后会自动迁移并删除 users.json。');
        }
        await notifyMissingPrereq(ctx, r);
      }
    } catch {
      /* ignore */
    }
    const accountId = String(ctx.account?.id || '');
    if (r.cfg.enabledAccountIds.length && !r.cfg.enabledAccountIds.includes(accountId)) return null;

    // 0) 非消息类群事件：进退群 / 入群申请（没有 message）
    const evtName = String(ctx.event?.name || ctx.event?.t || '');
    if (GROUP_EVENTS.has(evtName)) return await handleGroupEvent(ctx, r, evtName);
    // 0.1) 消息按钮回调（入群验证答案按钮）：按按钮 data 判定，不依赖群全量消息
    if (evtName === 'INTERACTION_CREATE') return await handleInteractionEvent(ctx, r);

    const m = ctx.message;
    if (!m || m.author?.bot) return null;
    const ids = identityKeys(m);
    if (!ids.length) return null;

    const found = r.store.findByKeys(ids);
    if (found) r.store.addAlias(found.key, ids);
    const key = found ? found.key : ids[0];
    r.store.touch(key, { scene: m.kind || '', accountId });

    const raw = String(m.cleanContent ?? m.content ?? '').trim();
    if (!raw) return null;

    const who = { key, ids, found };

    // 群管：违禁词优先处理（命中后不再进指令流程）
    if (m.kind === 'group' && (await guardGroupMessage(ctx, r, m, raw))) return null;

    // 入群验证：新人回答 / 点「开始校验」
    if (m.kind === 'group') {
      const verifyRes = await handleJoinVerifyMessage(ctx, r, m, raw);
      if (verifyRes !== false) return verifyRes;
    }

    // 1) 注册流程优先：验证码 / 密码 / 名称都可能是任意文本
    if (authFlows.has(key)) return await handleAuthInput(ctx, r, who, raw);

    // 2) QQ 绑定验证码
    if (bindFlows.has(key)) {
      if (/^\d{6}$/.test(raw)) return await handleBindCode(ctx, r, who, raw);
      if (!/^[/／]/.test(raw)) {
        return replyMd(ctx, r, [heading(ctx, who, r), '## 绑定 QQ', `> 请发送注册邮箱收到的 6 位验证码，或发送 ${cmdInline(ctx, r, 'cancel')} 取消。`].join('\n'), `请发送 6 位验证码，或发送 ${cmdLabel(r, 'cancel')} 取消。`);
      }
    }

    // 3) 指令：按「识别字符 + 指令名」匹配，前缀为空时裸词也识别
    const action = matchCommandAction(r, raw);
    if (!action) return null;
    const rest = raw.replace(/^[^\s\u3000]+\s*/, '').trim();
    const args = rest ? rest.split(/[\s\u3000]+/).filter(Boolean) : [];

    ctx.__commandKey = action;
    try {
      if (action === 'cancel') {
        const had = authFlows.delete(key) || bindFlows.delete(key);
        return replyMd(
          ctx,
          r,
          [heading(ctx, who, r), had ? '## 已取消' : '## 没有进行中的流程', had ? '> 当前注册 / 绑定流程已取消。' : '> 你现在没有需要取消的注册或绑定流程。'].join('\n'),
          had ? '已取消当前流程。' : '没有进行中的流程。',
        );
      }
      if (action === 'add') return await handleAdd(ctx, r, who, args, rest);
      if (action === 'login') return await handleLogin(ctx, r, who, args, rest);
      if (action === 'bindqq') return await handleBindQQ(ctx, r, who, args, rest);
      if (action === 'bindopenid') return await handleBindOpenid(ctx, r, who);
      if (action === 'list') return await handleList(ctx, r, who);
      if (action === 'sign') return await handleSign(ctx, r, who);
      if (action === 'menu') return await handleMenu(ctx, r, who);
      if (action === 'menusync') return await handleMenuSync(ctx, r, who);
      if (action === 'groupadmin') return await handleGroupAdmin(ctx, r, who);
      if (action === 'help') return await handleHelp(ctx, r, who);
      return null;
    } finally {
      delete ctx.__commandKey;
      delete ctx.__commandVars;
    }
  } catch (e) {
    const log = r?.log || ctx.log || console;
    log.error('VloS 处理异常：' + (e?.stack || e));
    return null;
  }
}

/* ======================= /add 注册 ======================= */

async function handleAdd(ctx, r, who, args, rest) {
  const privateOnly = requirePrivate(ctx, r, who);
  if (privateOnly) return privateOnly;

  const email = String(args[0] || T.firstWord(rest) || '').trim().toLowerCase();
  if (!email) {
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, who, r),
        '## 注册聚龙账户',
        `> 用法：${cmdInline(ctx, r, 'add')} 邮箱`,
        `> 例：${cmdInline(ctx, r, 'add')} user@example.com`,
        '系统会通过聚龙账户接口给该邮箱发送验证码；收到后按提示设置密码和显示名称。',
      ].join('\n'),
      `用法：${cmdLabel(r, 'add')} 邮箱`,
    );
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return replyMd(ctx, r, [heading(ctx, who, r), '## 邮箱格式不正确', '> 请发送正确的邮箱，例如 `user@example.com`。'].join('\n'), '邮箱格式不正确。');
  }

  const current = who.found || r.store.get(who.key);
  if (current && current.email && current.email !== email) {
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, current, r),
        '## 已绑定其他聚龙账户',
        `> 当前绑定：**${T.escapeMarkdown(current.email)}**`,
        '> 一个 QQ 用户只能绑定一个聚龙账户；如需更换请联系管理员。',
      ].join('\n'),
      `当前已绑定聚龙账户 ${current.email}，不能重复注册。`,
    );
  }

  const existing = r.store.getByEmail(email);
  if (existing && existing.key !== who.key) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 该邮箱已被使用', '> 这个聚龙账户已经绑定到另一个机器人用户，无法重复使用。'].join('\n'),
      '该邮箱已绑定其他机器人用户。',
    );
  }
  if (existing) {
    if (existing.token && existing.tokenExpiresAt > Date.now()) {
      return replyMd(
        ctx,
        r,
        [
          heading(ctx, existing, r),
          '## 已登录聚龙账户',
          `> 邮箱：**${T.escapeMarkdown(existing.email)}**`,
          existing.qq ? `> 绑定 QQ：**${T.escapeMarkdown(existing.qq)}**` : '> 绑定 QQ：未绑定（发送 `/bindqq QQ号`）',
        ].join('\n'),
        `已登录聚龙账户 ${existing.email}。`,
      );
    }
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, existing, r),
        '## 该邮箱已注册聚龙账户',
        `> **${T.escapeMarkdown(email)}** 已经注册过，请发送：`,
        `> \`/login ${T.escapeMarkdown(email)} 你的密码\``,
        '> 登录后即可绑定 QQ / 查看资料 / 签到。',
      ].join('\n'),
      `该邮箱已注册，请发送 /login ${email} 密码 登录。`,
    );
  }

  try {
    await r.jl.sendCode(email, 'register');
  } catch (e) {
    const msg = friendlyError(e, { action: 'send-code' });
    if (isEmailRegisteredError(e)) return replyMd(ctx, r, [heading(ctx, who, r), '## 该邮箱已注册聚龙账户', `> ${msg}`].join('\n'), msg);
    r.log.warn(`VloS 发送注册验证码失败 ${email}：${e.message}`);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 验证码发送失败', `> ${T.escapeMarkdown(msg)}`].join('\n'), msg);
  }

  authFlows.set(who.key, { step: 'code', email, at: Date.now() });
  r.log.info(`VloS 发起聚龙账户注册 email=${email} user=${who.key}`);
  return replyMd(
    ctx,
    r,
    [
      heading(ctx, who, r),
      '## 验证码已发送',
      `> 收件邮箱：**${T.escapeMarkdown(email)}**`,
      '> 请直接发送邮件里的 **6 位验证码**（不需要加 `/`）。',
      '> 收到验证码后，按提示依次设置密码和显示名称。',
    ].join('\n'),
    `验证码已发送到 ${email}，请直接发送 6 位验证码。`,
  );
}

async function handleAuthInput(ctx, r, who, raw) {
  const flow = authFlows.get(who.key);
  if (!flow) return null;
  if (Date.now() - flow.at > 15 * 60000) {
    authFlows.delete(who.key);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 注册流程已过期', '> 请重新发送 `/add 邮箱`。'].join('\n'), '注册流程已过期，请重新 /add 邮箱。');
  }
  if (matchCommandAction(r, raw) === 'cancel') {
    authFlows.delete(who.key);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 已取消注册', '> 你可以随时重新发送 `/add 邮箱`。'].join('\n'), '已取消注册。');
  }
  if (/^[/／]/.test(raw)) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 正在注册中', `> 当前在聚龙账户注册流程里，请按提示继续，或发送 ${cmdInline(ctx, r, 'cancel')} 取消。`].join('\n'),
      `正在注册中，请按提示继续或发送 ${cmdLabel(r, 'cancel')} 取消。`,
    );
  }

  if (flow.step === 'code') {
    if (!/^\d{6}$/.test(raw)) {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 验证码格式不对', '> 请发送邮件里的 6 位数字验证码。'].join('\n'), '请发送 6 位数字验证码。');
    }
    flow.code = raw;
    flow.step = 'password';
    flow.at = Date.now();
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, who, r),
        '## 设置聚龙账户密码',
        '> 请直接发送密码（至少 6 位，建议私聊，不要加 `/`）。',
        '> 密码只用于本次注册请求，不会保存在插件数据里。',
      ].join('\n'),
      '请发送聚龙账户密码（至少 6 位）。',
    );
  }

  if (flow.step === 'password') {
    if (ctx.message?.kind !== 'c2c') {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 请私聊发送密码', `> 密码只允许在私聊中发送，请到私聊继续，或发送 ${cmdInline(ctx, r, 'cancel')} 取消。`].join('\n'), '请私聊发送密码。');
    }
    if (raw.length < 6 || raw.length > 64) {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 密码长度不对', '> 密码至少 6 位、最多 64 位，请重新发送。'].join('\n'), '密码至少 6 位，请重新发送。');
    }
    flow.password = raw;
    flow.step = 'name';
    flow.at = Date.now();
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 设置显示名称', '> 请发送 2–20 个字符的显示名称。'].join('\n'),
      '请发送 2–20 个字符的显示名称。',
    );
  }

  if (flow.step === 'name') {
    const name = raw.trim();
    if (name.length < 2 || name.length > 20) {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 名称长度不对', '> 显示名称需要 2–20 个字符，请重新发送。'].join('\n'), '名称需要 2–20 个字符。');
    }
    const email = flow.email;
    const code = flow.code;
    const password = flow.password;
    try {
      const data = await r.jl.register({ email, code, password, name });
      const profile = data.user || {};
      const token = String(data.token || '');
      if (!token) throw new Error('注册成功但没有返回 token，请发送 /login 邮箱 密码 登录');
      const link = r.store.linkAccount({
        key: who.key,
        email: profile.email || email,
        name: profile.name || name,
        avatar: profile.avatar || '',
        token,
        tokenExpiresAt: Date.now() + TOKEN_TTL_MS,
        profile,
        aliases: who.ids,
      });
      authFlows.delete(who.key);
      if (link.conflict) {
        return replyMd(ctx, r, [heading(ctx, who, r), '## 注册成功但绑定失败', '> 该聚龙账户已绑定其他机器人用户，请联系管理员。'].join('\n'), '该聚龙账户已绑定其他机器人用户。');
      }
      r.log.info(`VloS 聚龙账户注册成功 email=${email} user=${who.key}`);
      let openidLine = '> OpenID：绑定 QQ 成功后会由机器人自动保存';
      if (link.user && link.user.qq) {
        const auto = await tryAutoBindOpenid(ctx, r, link.user);
        openidLine = auto.ok
          ? `> OpenID：已自动保存 ${codeSpan(auto.openid)}`
          : `> OpenID：自动保存失败（${T.escapeMarkdown(auto.reason)}）；请私聊 \`/bindopenid\``;
      }
      return replyMd(
        ctx,
        r,
        [
          heading(ctx, link.user || { name }, r),
          '## 注册成功',
          `> 聚龙账户：**${T.escapeMarkdown(email)}**`,
          `> 显示名称：**${T.escapeMarkdown(name)}**`,
          openidLine,
          '',
          `下一步：发送 \`/bindqq 你的QQ号\` 绑定 QQ（**绑定后无法修改**）；绑定成功后会自动保存 OpenID。`,
          '也可以先发送 `/list` 查看聚龙账户资料和钱包。',
        ].join('\n'),
        `注册成功！聚龙账户 ${email}。发送 /bindqq QQ号 绑定 QQ（绑定后无法修改），绑定后自动保存 OpenID。`,
      );
    } catch (e) {
      const msg = friendlyError(e, { action: 'register' });
      if (isEmailRegisteredError(e) || /验证码|密码/.test(String(e.message))) {
        authFlows.delete(who.key);
        r.log.warn(`VloS 聚龙账户注册失败 email=${email}：${e.message}`);
        return replyMd(
          ctx,
          r,
          [heading(ctx, who, r), '## 注册失败', `> ${T.escapeMarkdown(msg)}`, isEmailRegisteredError(e) ? `> 请发送 \`/login ${T.escapeMarkdown(email)} 你的密码\` 登录。` : '> 请重新发送 `/add 邮箱` 获取新的验证码。'].join('\n'),
          msg,
        );
      }
      // 网络错误：保留流程，让用户重发名称重试
      r.log.warn(`VloS 聚龙账户注册网络错误 email=${email}：${e.message}`);
      return replyMd(
        ctx,
        r,
        [heading(ctx, who, r), '## 注册暂时失败', `> ${T.escapeMarkdown(msg)}`, `> 请重新发送一次名称重试；或发送 ${cmdInline(ctx, r, 'cancel')} 取消后重新 \`${cmdLabel(r, 'add')}\`。`].join('\n'),
        msg,
      );
    }
  }

  return null;
}

/* ======================= /login 登录 ======================= */

async function handleLogin(ctx, r, who, args, rest) {
  const privateOnly = requirePrivate(ctx, r, who);
  if (privateOnly) return privateOnly;

  const email = String(args[0] || T.firstWord(rest) || '').trim().toLowerCase();
  const password = args.length > 1 ? args.slice(1).join(' ') : String(rest).replace(email, '').trim();
  if (!email || !password) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 登录聚龙账户', `> 用法：${cmdInline(ctx, r, 'login')} 邮箱 密码`, '> 请在私聊中发送，密码不要加 `/`。'].join('\n'),
      `用法：${cmdLabel(r, 'login')} 邮箱 密码`,
    );
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return replyMd(ctx, r, [heading(ctx, who, r), '## 邮箱格式不正确', '> 请输入正确的邮箱。'].join('\n'), '邮箱格式不正确。');
  }

  const existing = r.store.getByEmail(email);
  if (existing && existing.key !== who.key) {
    return replyMd(ctx, r, [heading(ctx, who, r), '## 该邮箱已绑定其他用户', '> 这个聚龙账户已经绑定到另一个机器人用户。'].join('\n'), '该邮箱已绑定其他机器人用户。');
  }

  try {
    const data = await r.jl.login(email, password);
    const profile = data.user || {};
    const token = String(data.token || '');
    if (!token) throw new Error('登录成功但没有返回 token');
    const link = r.store.linkAccount({
      key: who.key,
      email: profile.email || email,
      name: profile.name || '',
      avatar: profile.avatar || '',
      token,
      tokenExpiresAt: Date.now() + TOKEN_TTL_MS,
      profile,
      aliases: who.ids,
    });
    if (link.conflict) {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 登录成功但绑定失败', '> 该聚龙账户已绑定其他机器人用户，请联系管理员。'].join('\n'), '该聚龙账户已绑定其他机器人用户。');
    }
    r.log.info(`VloS 聚龙账户登录成功 email=${email} user=${who.key}`);
    const u = link.user;
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, u, r),
        '## 登录成功',
        `> 聚龙账户：**${T.escapeMarkdown(u.email)}**`,
        `> 显示名称：**${T.escapeMarkdown(u.name || '未设置')}**`,
        `> 绑定 QQ：${u.qq ? '**' + T.escapeMarkdown(u.qq) + '**' : '未绑定（发送 `/bindqq QQ号`）'}`,
        `> OpenID：${u.openid ? '已填写' : '未填写（私聊 `/bindopenid`）'}`,
        '',
        '发送 `/list` 查看资料和钱包，或 `/签到` 领取今日奖励。',
      ].join('\n'),
      `登录成功：${u.email}${u.qq ? '，已绑定 QQ ' + u.qq : '，还未绑定 QQ'}。`,
    );
  } catch (e) {
    const msg = friendlyError(e, { action: 'login' });
    r.log.warn(`VloS 聚龙账户登录失败 email=${email}：${e.message}`);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 登录失败', `> ${T.escapeMarkdown(msg)}`].join('\n'), msg);
  }
}

/* ======================= /bindqq 绑定 QQ ======================= */

async function handleBindQQ(ctx, r, who, args, rest) {
  let user = who.found || r.store.get(who.key);
  if (!user || !user.email) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 请先注册 / 登录聚龙账户', '> 发送 `/add 邮箱` 注册，或 `/login 邮箱 密码` 登录。'].join('\n'),
      '请先注册或登录聚龙账户。',
    );
  }
  if (!user.token) {
    return replyNotice(
      ctx,
      r,
      [heading(ctx, user, r), '## 尚未登录聚龙账户', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 登录。`].join('\n'),
      '尚未登录，请发送 /login 邮箱 密码。',
    );
  }

  const qq = String(args[0] || T.firstWord(rest) || '').trim();
  if (!qq) {
    return replyMd(ctx, r, [heading(ctx, user, r), '## 绑定 QQ', `> 用法：${cmdInline(ctx, r, 'bindqq')} QQ号`, '> 绑定后无法修改。'].join('\n'), `用法：${cmdLabel(r, 'bindqq')} QQ号`);
  }
  if (!/^[1-9]\d{4,11}$/.test(qq)) {
    return replyMd(ctx, r, [heading(ctx, user, r), '## QQ 号格式不正确', '> QQ 号应为 5–12 位数字，且不能以 0 开头。'].join('\n'), 'QQ 号格式不正确：5–12 位数字。');
  }

  // 先刷新一次 me，确保本地 qq 不是过期缓存
  let profile = null;
  try {
    const me = await r.jl.me(user.token);
    profile = me.user || {};
    const link = r.store.linkAccount({
      key: who.key,
      email: profile.email || user.email,
      name: profile.name || user.name,
      avatar: profile.avatar !== undefined ? profile.avatar : user.avatar,
      token: user.token,
      tokenExpiresAt: user.tokenExpiresAt,
      profile,
      aliases: who.ids,
    });
    if (link.conflict) {
      return replyMd(ctx, r, [heading(ctx, who, r), '## 该聚龙账户已绑定其他用户', '> 请联系管理员。'].join('\n'), '该聚龙账户已绑定其他机器人用户。');
    }
    user = link.user;
  } catch (e) {
    if (isTokenError(e)) {
      r.store.clearToken(user.key);
      return replyNotice(ctx, r, [heading(ctx, user, r), '## 登录已过期', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 重新登录。`].join('\n'), '登录已过期，请重新 /login。');
    }
    const msg = friendlyError(e, { action: 'me' });
    r.log.warn(`VloS 读取聚龙账户失败 ${user.email}：${e.message}`);
    return replyMd(ctx, r, [heading(ctx, user, r), '## 读取聚龙账户失败', `> ${T.escapeMarkdown(msg)}`].join('\n'), msg);
  }

  if (user.qq) {
    const same = user.qq === qq;
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, user, r),
        same ? '## 您已绑定该 QQ' : '## 您已绑定其他 QQ',
        `> 当前绑定：**${T.escapeMarkdown(user.qq)}**`,
        '> 聚龙账户的 QQ 绑定后**不能修改 / 解绑**。',
        user.openid ? `> OpenID：已填写` : '> OpenID：未填写；可私聊发送 `/bindopenid` 保存。',
      ].join('\n'),
      `您已绑定 QQ ${user.qq}，绑定后无法修改。`,
    );
  }

  // 一步完成：/bindqq QQ号 直接发验证码（不再要求第二条「确认」指令）；绑定不可逆，提示里写明
  try {
    await r.jl.qqSendCode(user.token, qq);
  } catch (e) {
    if (isTokenError(e)) {
      r.store.clearToken(user.key);
      return replyMd(ctx, r, [heading(ctx, user, r), '## 登录已过期', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 重新登录。`].join('\n'), '登录已过期，请重新 /login。');
    }
    if (isQQBoundError(e) || isQQTakenError(e)) {
      return replyMd(ctx, r, [heading(ctx, user, r), '## 无法绑定', `> ${T.escapeMarkdown(friendlyError(e, { action: 'qq-send-code' }))}`].join('\n'), friendlyError(e, { action: 'qq-send-code' }));
    }
    const msg = friendlyError(e, { action: 'qq-send-code' });
    r.log.warn(`VloS 发送 QQ 绑定验证码失败 qq=${qq}：${e.message}`);
    return replyMd(ctx, r, [heading(ctx, user, r), '## 验证码发送失败', `> ${T.escapeMarkdown(msg)}`].join('\n'), msg);
  }

  bindFlows.set(who.key, { qq, at: Date.now() });
  r.log.info(`VloS 发起 QQ 绑定 email=${user.email} qq=${qq}`);
  ctx.__commandVars = { email: user.email, qq };
  return replyMd(
    ctx,
    r,
    [
      heading(ctx, user, r),
      '## 验证码已发送',
      `> 已发送到聚龙账户注册邮箱：**${T.escapeMarkdown(user.email)}**`,
      `> 绑定 QQ：**${T.escapeMarkdown(qq)}**（⚠️ **绑定后无法修改 / 解绑**）`,
      '> 请直接发送 6 位验证码完成绑定。',
    ].join('\n'),
    `验证码已发送到 ${user.email}，请直接发送 6 位验证码完成绑定。绑定后无法修改。`,
  );
}

async function handleBindCode(ctx, r, who, code) {
  const flow = bindFlows.get(who.key);
  if (!flow) return null;
  if (Date.now() - flow.at > 15 * 60000) {
    bindFlows.delete(who.key);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 绑定流程已过期', '> 请重新发送 `/bindqq QQ号`。'].join('\n'), '绑定流程已过期，请重新 /bindqq。');
  }
  const user = who.found || r.store.get(who.key);
  if (!user || !user.token) {
    bindFlows.delete(who.key);
    return replyMd(ctx, r, [heading(ctx, who, r), '## 登录已过期', '> 请重新 `/login 邮箱 密码`。'].join('\n'), '登录已过期，请重新 /login。');
  }
  const qq = flow.qq;
  try {
    const data = await r.jl.qqBind(user.token, qq, code);
    const profile = data.user || {};
    const set = r.store.setQQ(who.key, { qq, qqBoundAt: profile.qqBoundAt || Date.now() });
    if (!set.ok) {
      bindFlows.delete(who.key);
      return replyMd(ctx, r, [heading(ctx, user, r), '## 绑定失败', `> ${T.escapeMarkdown(set.error)}`].join('\n'), set.error);
    }
    if (profile.name || profile.avatar !== undefined) {
      r.store.updateSession(who.key, {
        token: user.token,
        tokenExpiresAt: user.tokenExpiresAt,
        profile: { email: user.email, name: profile.name || user.name, avatar: profile.avatar !== undefined ? profile.avatar : user.avatar, wallet: profile.wallet },
      });
    }
    bindFlows.delete(who.key);
    const boundUser = r.store.get(who.key) || user;
    const autoOpenid = await tryAutoBindOpenid(ctx, r, boundUser);
    r.log.info(`VloS QQ 绑定成功 email=${user.email} qq=${qq}`);
    const openidLine = autoOpenid.ok
      ? `> OpenID：已自动保存 ${codeSpan(autoOpenid.openid)}`
      : autoOpenid.skipped
        ? '> OpenID：请私聊发送 `/bindopenid` 保存'
        : `> OpenID：自动保存失败（${T.escapeMarkdown(autoOpenid.reason)}）；请私聊 \`/bindopenid\` 获取字符串后手动填写。`;
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, boundUser, r),
        '## QQ 绑定成功',
        `> 聚龙账户：**${T.escapeMarkdown(user.email)}**`,
        `> 绑定 QQ：**${T.escapeMarkdown(qq)}**`,
        '> 绑定后**不能修改 / 解绑**。',
        openidLine,
      ].join('\n'),
      `QQ 绑定成功：${user.email} ↔ ${qq}。绑定后无法修改。${autoOpenid.ok ? ' OpenID 已自动保存。' : ''}`,
    );
  } catch (e) {
    if (isTokenError(e)) {
      r.store.clearToken(user.key);
      bindFlows.delete(who.key);
      return replyMd(ctx, r, [heading(ctx, user, r), '## 登录已过期', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 重新登录。`].join('\n'), '登录已过期，请重新 /login。');
    }
    if (isQQBoundError(e) || isQQTakenError(e)) {
      bindFlows.delete(who.key);
      return replyMd(ctx, r, [heading(ctx, user, r), '## 绑定失败', `> ${T.escapeMarkdown(friendlyError(e, { action: 'qq-bind' }))}`].join('\n'), friendlyError(e, { action: 'qq-bind' }));
    }
    const msg = friendlyError(e, { action: 'qq-bind' });
    const tooMany = /次数过多|重新获取|已过期/.test(String(e.message));
    if (tooMany) bindFlows.delete(who.key);
    r.log.warn(`VloS QQ 绑定校验失败 qq=${qq}：${e.message}`);
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## 验证码不正确', `> ${T.escapeMarkdown(msg)}`, tooMany ? `> 请重新发送 \`${cmdLabel(r, 'bindqq')} QQ号\` 获取新验证码。` : `> 请重新发送 6 位验证码，或发送 ${cmdInline(ctx, r, 'cancel')} 取消。`].join('\n'),
      msg,
    );
  }
}

/* ======================= /bindopenid ======================= */

/** 自动把当前会话的 OpenID 写入聚龙账户；失败返回原因，由调用方决定是否回退到手动填写 */
async function tryAutoBindOpenid(ctx, r, user) {
  if (!user || !user.email) return { ok: false, reason: '没有聚龙账户' };
  const openid = primaryOpenid(ctx.message);
  if (!isValidOpenid(openid)) return { ok: false, openid, reason: '当前会话的 OpenID 格式异常' };
  if (user.openid) return { ok: true, already: true, openid: user.openid };
  try {
    const res = await r.jl.keyCall('openid', { user: user.email, openid });
    const boundAt = Number(res.openidBoundAt) || Date.now();
    r.store.setOpenid(user.key, { openid, openidBoundAt: boundAt });
    return { ok: true, openid, boundAt };
  } catch (e) {
    return { ok: false, openid, error: e, reason: friendlyError(e, { action: 'openid' }) };
  }
}

async function handleBindOpenid(ctx, r, who) {
  // 群聊也能绑定：优先用 union_openid（群聊/私聊一致），拿不到才退回当前会话的 member/user openid
  let user = who.found || r.store.get(who.key);
  if (!user || !user.email) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 请先注册 / 登录聚龙账户', '> 发送 `/add 邮箱` 注册，或 `/login 邮箱 密码` 登录。'].join('\n'),
      '请先注册或登录聚龙账户。',
    );
  }
  if (!user.token) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## 尚未登录聚龙账户', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 登录。`].join('\n'),
      '尚未登录，请发送 /login 邮箱 密码。',
    );
  }

  try {
    const me = await r.jl.me(user.token);
    const profile = me.user || {};
    const link = r.store.linkAccount({
      key: who.key,
      email: profile.email || user.email,
      name: profile.name || user.name,
      avatar: profile.avatar !== undefined ? profile.avatar : user.avatar,
      token: user.token,
      tokenExpiresAt: user.tokenExpiresAt,
      profile,
      aliases: who.ids,
    });
    if (!link.conflict) user = link.user;
  } catch (e) {
    if (isTokenError(e)) {
      r.store.clearToken(user.key);
      return replyMd(
        ctx,
        r,
        [heading(ctx, user, r), '## 登录已过期', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 重新登录。`].join('\n'),
        '登录已过期，请重新 /login。',
      );
    }
    r.log.warn(`VloS /bindopenid 读取聚龙账户失败 ${user.email}：${e.message}`);
    // 网络抖动时继续用本地缓存尝试
  }

  if (!user.qq) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## 请先绑定 QQ', '> OpenID 的前提是聚龙账户已经绑定 QQ；请先发送 `/bindqq QQ号`。'].join('\n'),
      '请先绑定 QQ：/bindqq QQ号',
    );
  }

  const openid = primaryOpenid(ctx.message);
  if (!isValidOpenid(openid)) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## OpenID 格式异常', '> 当前会话拿不到有效的 OpenID，请稍后在私聊重试。'].join('\n'),
      'OpenID 格式异常，请稍后在私聊重试。',
    );
  }

  if (user.openid) {
    const same = user.openid === openid;
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, user, r),
        same ? '## OpenID 已绑定' : '## OpenID 已填写',
        `> 聚龙账户 OpenID：${codeSpan(user.openid)}`,
        `> 当前会话 OpenID：${codeSpan(openid)}`,
        same ? '> 两者一致，无需重复绑定。' : '> 两者不一致；OpenID 填写后不可修改，如确需更换请联系管理员。',
      ].join('\n'),
      same
        ? `OpenID 已绑定：${user.openid}（当前会话一致）。`
        : `聚龙账户已填写 OpenID：${user.openid}；当前会话是 ${openid}，填写后不可修改，如需更换请联系管理员。`,
    );
  }

  const auto = await tryAutoBindOpenid(ctx, r, user);
  if (auto.ok) {
    r.log.info(`VloS OpenID 绑定成功 email=${user.email} openid=${auto.openid}`);
    return replyMd(
      ctx,
      r,
      [
        heading(ctx, r.store.get(who.key) || user, r),
        '## OpenID 绑定成功',
        `> 聚龙账户：**${T.escapeMarkdown(user.email)}**`,
        `> OpenID：${codeSpan(auto.openid)}`,
        '> 填写后**不能修改**。',
      ].join('\n'),
      `OpenID 绑定成功：${auto.openid}（填写后不可修改）。`,
    );
  }

  if (auto.error && isNoQQError(auto.error)) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## 请先绑定 QQ', '> 这个聚龙账户还没有绑定 QQ；请先发送 `/bindqq QQ号`。'].join('\n'),
      '请先绑定 QQ：/bindqq QQ号',
    );
  }
  if (auto.error && isOpenidBoundError(auto.error)) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## OpenID 已填写', '> 聚龙账户的 OpenID 填写后不可修改。'].join('\n'),
      'OpenID 已填写，不能修改。',
    );
  }
  if (auto.error && isOpenidTakenError(auto.error)) {
    return replyMd(
      ctx,
      r,
      [heading(ctx, user, r), '## OpenID 已被使用', '> 这个 OpenID 已填写到其他聚龙账户，不能重复使用。'].join('\n'),
      '这个 OpenID 已被使用。',
    );
  }

  // 自动写入失败（Key 无效 / 没有 openid 权限 / 网络异常）→ 返回字符串，让用户手动填到账户中心
  r.log.warn(`VloS OpenID 自动写入失败 email=${user.email}：${auto.reason}`);
  return replyMd(
    ctx,
    r,
    [
      heading(ctx, user, r),
      '## 你的 OpenID',
      codeSpan(openid),
      '',
      `> 机器人暂时无法自动写入：${T.escapeMarkdown(auto.reason)}`,
      '> 请复制上面这串字符，到聚龙账户中心「个人设置 → OpenID」手动填写。',
      '> **填写后不可修改**，请确认当前 QQ / 机器人会话正确。',
    ].join('\n'),
    `你的 OpenID：${openid}\n机器人暂时无法自动写入（${auto.reason}），请到聚龙账户中心手动填写。`,
  );
}

/* ======================= /list 资料 ======================= */

async function handleList(ctx, r, who) {
  let user = who.found || r.store.get(who.key);
  if (!user || !user.email) {
    return replyNotice(
      ctx,
      r,
      [
        heading(ctx, who, r),
        '## 尚未绑定聚龙账户',
        '> 发送 `/add 邮箱` 注册聚龙账户，或 `/login 邮箱 密码` 登录已有账户。',
      ].join('\n'),
      '尚未绑定聚龙账户，请发送 /add 邮箱 或 /login 邮箱 密码。',
    );
  }

  let note = '';
  if (user.token) {
    const [meRes, balRes] = await Promise.allSettled([r.jl.me(user.token), r.jl.balance(user.token)]);
    if (meRes.status === 'fulfilled') {
      const profile = meRes.value.user || {};
      const link = r.store.linkAccount({
        key: who.key,
        email: profile.email || user.email,
        name: profile.name || user.name,
        avatar: profile.avatar !== undefined ? profile.avatar : user.avatar,
        token: user.token,
        tokenExpiresAt: user.tokenExpiresAt,
        profile,
        aliases: who.ids,
      });
      if (!link.conflict) user = link.user;
    } else if (isTokenError(meRes.reason)) {
      r.store.clearToken(user.key);
      user = r.store.get(user.key);
      note = '登录已过期，请发送 `/login 邮箱 密码` 重新登录。';
    } else {
      note = `资料刷新失败：${T.clip(friendlyError(meRes.reason), 80)}`;
    }

    if (balRes.status === 'fulfilled') {
      const wallet = balRes.value.wallet || balRes.value.user?.wallet;
      if (wallet) {
        r.store.setWallet(user.key, wallet);
        user = r.store.get(user.key);
      }
    } else if (!isTokenError(balRes.reason) && !note) {
      note = `钱包读取失败：${T.clip(friendlyError(balRes.reason), 80)}`;
    }
  } else {
    note = '尚未登录聚龙账户，资料为缓存；请发送 `/login 邮箱 密码`。';
  }

  // VloS余额 可能被其他插件直接 UPDATE vlos_users.vl_lj / vl_xy，展示前回表读最新值
  if (typeof r.store.refreshPending === 'function') r.store.refreshPending(user.key);
  user = r.store.get(user.key) || user;

  const av = avatarFor(ctx, user, r);
  const size = r.cfg.ui.avatarSize;
  const pendingBalance = {
    longjing: cleanMoney(user.pendingWallet?.longjing),
    xuanyu: cleanMoney(user.pendingWallet?.xuanyu),
  };
  const pendingTotal = pendingBalance.longjing + pendingBalance.xuanyu;
  ctx.__commandVars = {
    heading: `${av ? `![头像 #${size}px #${size}px](${av}) ` : ''}**${T.escapeMarkdown(user.name || '聚龙用户')}**`,
    avatar: av ? `![头像 #${size}px #${size}px](${av})` : '',
    name: T.escapeMarkdown(user.name || '聚龙用户'),
    email: T.escapeMarkdown(user.email),
    qq: user.qq ? T.escapeMarkdown(user.qq) : '未绑定',
    openid: user.openid || '未填写',
    wallet_longjing: T.formatNumber(user.wallet.longjing),
    wallet_xuanyu: T.formatNumber(user.wallet.xuanyu),
    ledger_longjing: T.formatNumber(user.balances.longjing),
    ledger_xuanyu: T.formatNumber(user.balances.xuanyu),
    pending: pendingTotal > 0 ? `龙晶 ${T.formatNumber(pendingBalance.longjing)} · 玄玉 ${T.formatNumber(pendingBalance.xuanyu)}（发奖 Key 恢复后下次签到入账）` : '',
    pending_longjing: T.formatNumber(pendingBalance.longjing),
    pending_xuanyu: T.formatNumber(pendingBalance.xuanyu),
    days: T.formatNumber(user.sign.totalDays),
    streak: T.formatNumber(user.sign.streak),
    sign_status: user.sign.lastDate === T.dateKey() ? '今日已签到' : '今日未签到',
    note: note ? `> ${T.escapeMarkdown(note)}` : '',
    footer: siteFooter(r),
  };
  const lines = [
    `${av ? `![头像 #${size}px #${size}px](${av}) ` : ''}**${T.escapeMarkdown(user.name || '聚龙用户')}**`,
    '## 聚龙账户',
    `- **邮箱**：${T.escapeMarkdown(user.email)}`,
    user.qq ? `- **绑定 QQ**：${T.escapeMarkdown(user.qq)}` : '- **绑定 QQ**：未绑定（发送 `/bindqq QQ号`）',
    user.openid ? `- **OpenID**：${codeSpan(user.openid)}` : '- **OpenID**：未填写（私聊发送 `/bindopenid`）',
    user.legacyQq && !user.qq ? `- **旧版本地绑定**：${T.escapeMarkdown(user.legacyQq)}（未同步到聚龙账户，请用 \`/bindqq ${T.escapeMarkdown(user.legacyQq)}\` 重新绑定）` : '',
    `- **聚龙钱包**：龙晶 ${T.formatNumber(user.wallet.longjing)} · 玄玉 ${T.formatNumber(user.wallet.xuanyu)}`,
    `- **签到账本**：龙晶 ${T.formatNumber(user.balances.longjing)} · 玄玉 ${T.formatNumber(user.balances.xuanyu)}`,
    pendingTotal > 0
      ? `- **VloS余额**：龙晶 ${T.formatNumber(pendingBalance.longjing)} · 玄玉 ${T.formatNumber(pendingBalance.xuanyu)}（发奖 Key 恢复后下次签到入账）`
      : '',
    `- **签到**：累计 ${T.formatNumber(user.sign.totalDays)} 天 · 连续 ${T.formatNumber(user.sign.streak)} 天 · ${user.sign.lastDate === T.dateKey() ? '今日已签到' : '今日未签到'}`,
  ].filter(Boolean);
  if (note) lines.push('', `> ${T.escapeMarkdown(note)}`);
  lines.push('', siteFooter(r));

  const plain = [
    `聚龙账户：${user.email}`,
    `绑定 QQ：${user.qq || '未绑定'}`,
    `OpenID：${user.openid || '未填写'}`,
    `聚龙钱包：龙晶 ${user.wallet.longjing}，玄玉 ${user.wallet.xuanyu}`,
    `签到账本：龙晶 ${user.balances.longjing}，玄玉 ${user.balances.xuanyu}`,
  ];
  if (pendingTotal > 0) plain.push(`VloS余额：龙晶 ${pendingBalance.longjing}，玄玉 ${pendingBalance.xuanyu}`);
  plain.push(`累计签到 ${user.sign.totalDays} 天，连续 ${user.sign.streak} 天`);

  return replyMd(ctx, r, lines.join('\n'), plain.join('\n'));
}

/* ======================= /签到 ======================= */

async function handleSign(ctx, r, who) {
  const { cfg } = r;
  let user = who.found || r.store.get(who.key);
  if (!user || !user.email) {
    return replyNotice(
      ctx,
      r,
      [heading(ctx, who, r), '## 尚未绑定聚龙账户', '> 签到前请先 `/add 邮箱` 注册或 `/login 邮箱 密码` 登录。'].join('\n'),
      '尚未绑定聚龙账户，请先 /add 邮箱 或 /login 邮箱 密码。',
    );
  }
  if (!user.token) {
    return replyNotice(
      ctx,
      r,
      [heading(ctx, user, r), '## 尚未登录聚龙账户', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 登录。`].join('\n'),
      '尚未登录，请发送 /login 邮箱 密码。',
    );
  }

  // VloS余额可能被其他插件直接改 vlos_users.vl_lj / vl_xy（跨表写），这里先回表读一次
  if (typeof r.store.refreshPending === 'function') r.store.refreshPending(user.key);
  user = r.store.get(user.key) || user;

  if (cfg.sign.oncePerDay && user.sign.lastDate === T.dateKey()) {
    const pendingBalance = user.pendingWallet || { longjing: 0, xuanyu: 0 };
    const pendingTotal = cleanMoney(pendingBalance.longjing) + cleanMoney(pendingBalance.xuanyu);
    const alreadyLines = [
      heading(ctx, user, r),
      '## 今日已签到',
      '> 你今天已经签到过了，明天再来吧。',
      '',
      `- **累计签到**：${T.formatNumber(user.sign.totalDays)} 天`,
      `- **连续签到**：${T.formatNumber(user.sign.streak)} 天`,
    ];
    if (pendingTotal > 0) {
      alreadyLines.push(
        '',
        `> **VloS余额**：龙晶 ${T.formatNumber(pendingBalance.longjing)} · 玄玉 ${T.formatNumber(pendingBalance.xuanyu)}`,
        '> 发奖 Key 恢复后，下次签到会与本次奖励一并入账。',
      );
    }
    alreadyLines.push('', siteFooter(r));
    return replyNotice(
      ctx,
      r,
      alreadyLines.join('\n'),
      `今日已签到。累计 ${user.sign.totalDays} 天，连续 ${user.sign.streak} 天。`,
    );
  }

  if (signing.has(user.key)) {
    return replyNotice(ctx, r, [heading(ctx, user, r), '## 正在签到', '> 上一次签到还在处理中，请稍候几秒再试。'].join('\n'), '正在签到，请稍候。');
  }
  signing.add(user.key);
  try {
    // 刷新钱包 / 校验 token
    try {
      const b = await r.jl.balance(user.token);
      const wallet = b.wallet || b.user?.wallet;
      if (wallet) {
        r.store.setWallet(user.key, wallet);
        user = r.store.get(user.key);
      }
    } catch (e) {
      if (isTokenError(e)) {
        r.store.clearToken(user.key);
        return replyNotice(ctx, r, [heading(ctx, user, r), '## 登录已过期', `> 请发送 \`/login ${T.escapeMarkdown(user.email)} 你的密码\` 重新登录。`].join('\n'), '登录已过期，请重新 /login。');
      }
      r.log.warn(`VloS 签到前读取钱包失败 ${user.email}：${e.message}`);
    }

    const poem = pickPoem(r.dir);
    const drop = rollDrops(cfg.sign);
    const walletMode = !!cfg.sign.wallet;
    const mode = walletMode ? 'wallet' : 'local';
    let note = '';
    // 再次回表：上面的钱包请求是异步的，期间别的插件可能往 VloS余额 里加过数
    if (typeof r.store.refreshPending === 'function') r.store.refreshPending(user.key);
    const carry = {
      longjing: cleanMoney(user.pendingWallet?.longjing),
      xuanyu: cleanMoney(user.pendingWallet?.xuanyu),
    };
    const credited = { longjing: 0, xuanyu: 0 };
    const failed = { longjing: 0, xuanyu: 0 };
    let wallet = { ...user.wallet };

    if (walletMode) {
      const errors = [];
      for (const currency of ['longjing', 'xuanyu']) {
        const label = currency === 'longjing' ? '龙晶' : '玄玉';
        const current = cleanMoney(drop[currency]);
        const carryAmount = carry[currency];
        const total = current + carryAmount;
        if (total <= 0) continue;
        try {
          const res = await r.jl.currencyAdd(user.email, currency, total);
          if (res.wallet) wallet = res.wallet;
          credited[currency] = total;
        } catch (e) {
          failed[currency] = current;
          errors.push(`${label}：${T.clip(friendlyError(e), 60)}`);
        }
      }
      if (credited.longjing + credited.xuanyu > 0) r.store.setWallet(user.key, wallet);
      // 只扣掉本次真正消费掉的旧 VloS余额（carry），保留这段时间里其他插件跨表加进来的部分
      const dbPending =
        (typeof r.store.refreshPending === 'function' ? r.store.refreshPending(user.key) : null) || carry;
      r.store.setPendingWallet(user.key, {
        longjing: Math.max(0, cleanMoney(dbPending.longjing) - carry.longjing) + failed.longjing,
        xuanyu: Math.max(0, cleanMoney(dbPending.xuanyu) - carry.xuanyu) + failed.xuanyu,
      });
      if (failed.longjing + failed.xuanyu > 0) {
        note = errors.length ? `原因：${errors.join('；')}` : '';
      }
    } else {
      r.store.adjustBalances(user.key, { longjingDelta: drop.longjing, xuanyuDelta: drop.xuanyu });
      if (carry.longjing + carry.xuanyu > 0) {
        note = '当前为插件账本模式；之前有 VloS余额奖励，切回钱包模式后下次签到会一并入账。';
      }
    }

    const mark = r.store.recordSign(user.key, { date: T.dateKey(), poem, ark: false, mode });
    if (!mark) {
      return replyMd(ctx, r, [heading(ctx, user, r), '## 签到失败', '> 读取账户数据失败，请稍后再试。'].join('\n'), errText('签到失败，请稍后再试。'));
    }
    let fresh = mark.user;
    const arkSection = await buildArknightsSection(r, fresh);
    if (arkSection) {
      fresh = r.store.get(user.key) || fresh;
      if (fresh.sign && fresh.sign.history && fresh.sign.history.length) {
        const arkHit = /签到成功|今日已签到/.test(arkSection);
        fresh.sign.history[fresh.sign.history.length - 1].ark = arkHit;
        // 历史在 vlos_sign_history 独立表里，必须 UPDATE 那一行；save()/saveUser() 只写用户主表
        if (typeof r.store.setLastSignArk === 'function') r.store.setLastSignArk(user.key, arkHit);
        else if (typeof r.store.saveUser === 'function') r.store.saveUser(user.key);
        else if (typeof r.store.save === 'function') r.store.save();
      }
    }

    const time = T.formatDateTime();
    // 钱包模式：credited 才是真正入账数（本次 + 已有VloS余额）；账本模式：奖励直接进插件账本。
    const ljCredited = walletMode ? credited.longjing : drop.longjing;
    const ljCarry = walletMode ? carry.longjing : 0;
    const xyCredited = walletMode ? credited.xuanyu : drop.xuanyu;
    const xyCarry = walletMode ? carry.xuanyu : 0;
    const longjingText = creditText(ljCredited, drop.longjing, ljCarry);
    const xuanyuNoDrop = xyCredited <= 0 && drop.xuanyu <= 0 && xyCarry <= 0;
    const xuanyuText = creditText(xyCredited, drop.xuanyu, xyCarry);
    const longjingLine = `- **龙晶**：${longjingText}`;
    const xuanyuLine = `- **玄玉**：${xuanyuNoDrop ? '本次未掉落' : xuanyuText}`;
    const pendingNow = fresh.pendingWallet || { longjing: 0, xuanyu: 0 };
    const pendingTotal = cleanMoney(pendingNow.longjing) + cleanMoney(pendingNow.xuanyu);

    const lines = [
      heading(ctx, fresh, r),
      '## 每日签到',
      `> ${T.escapeMarkdown(poem)}`,
      '',
      '***',
      '',
      `- **签到时间**：${time}`,
      longjingLine,
      xuanyuLine,
      `- **累计签到**：${T.formatNumber(mark.totalDays)} 天 · 连续 ${T.formatNumber(mark.streak)} 天`,
    ];
    if (pendingTotal > 0) {
      lines.push(
        '',
        `> **VloS余额**：龙晶 ${T.formatNumber(pendingNow.longjing)} · 玄玉 ${T.formatNumber(pendingNow.xuanyu)}`,
        '> 发奖 Key 恢复后，下次签到会与本次奖励一并入账。',
      );
    }
    if (note) lines.push('', `> ${T.escapeMarkdown(note)}`);
    if (arkSection) lines.push('', arkSection);
    lines.push('', siteFooter(r));

    r.log.info(
      `VloS 签到 user=${user.key} email=${fresh.email} date=${T.dateKey()} mode=${mode} ` +
        `龙晶本次+${drop.longjing} VloS余额${carry.longjing} 入账+${ljCredited} ` +
        `玄玉本次+${drop.xuanyu} VloS余额${carry.xuanyu} 入账+${xyCredited} ` +
        `钱包=${fresh.wallet.longjing}/${fresh.wallet.xuanyu} VloS余额=${fresh.pendingWallet.longjing}/${fresh.pendingWallet.xuanyu} ` +
        `账本=${fresh.balances.longjing}/${fresh.balances.xuanyu}`,
    );
    const av = avatarFor(ctx, fresh, r);
    const size = r.cfg.ui.avatarSize;
    ctx.__commandVars = {
      heading: heading(ctx, fresh, r),
      avatar: av ? `![头像 #${size}px #${size}px](${av})` : '',
      name: T.escapeMarkdown(fresh.name || '聚龙用户'),
      poem: T.escapeMarkdown(poem),
      time,
      longjing: longjingText,
      xuanyu: xuanyuNoDrop ? '本次未掉落' : xuanyuText,
      days: T.formatNumber(mark.totalDays),
      streak: T.formatNumber(mark.streak),
      pending: pendingTotal > 0 ? `> **VloS余额**：龙晶 ${T.formatNumber(pendingNow.longjing)} · 玄玉 ${T.formatNumber(pendingNow.xuanyu)}\n> 发奖 Key 恢复后，下次签到会与本次奖励一并入账。` : '',
      pending_longjing: T.formatNumber(pendingNow.longjing),
      pending_xuanyu: T.formatNumber(pendingNow.xuanyu),
      note: note ? `> ${T.escapeMarkdown(note)}` : '',
      arknights: arkSection || '',
      footer: siteFooter(r),
    };
    return replyMd(
      ctx,
      r,
      lines.join('\n'),
      [
        '签到成功！',
        `时间：${time}`,
        poem,
        `龙晶 ${longjingText}`,
        `玄玉 ${xuanyuNoDrop ? '本次未掉落' : xuanyuText}`,
        ...(pendingTotal > 0 ? [`VloS余额：龙晶 ${pendingNow.longjing}，玄玉 ${pendingNow.xuanyu}`] : []),
        `累计 ${mark.totalDays} 天，连续 ${mark.streak} 天`,
      ].join('\n'),
    );
  } finally {
    signing.delete(user.key);
  }
}

/** 纯函数：按配置掷一次签到奖励。rng 可注入，测试用。 */
function rollDrops(signCfg, rng = Math.random) {
  const longjing = T.randInt(signCfg.longjingMin, signCfg.longjingMax, rng);
  const hit = T.randInt(1, 100, rng) <= signCfg.xuanyuChance;
  const xuanyu = hit ? T.randInt(signCfg.xuanyuMin, signCfg.xuanyuMax, rng) : 0;
  return { longjing, xuanyu, xuanyuHit: hit };
}

/* ======================= 方舟签到掉落 ======================= */

function arknightsApi() {
  try {
    const g = globalThis.__JLWBOT_PLUGIN_APIS__;
    if (!g || typeof g.get !== 'function') return null;
    const apiObj = g.get('Arknights');
    if (!apiObj) return null;
    const usable = typeof apiObj.sign === 'function' || typeof apiObj.isLoggedIn === 'function';
    return usable ? apiObj : null;
  } catch {
    return null;
  }
}

async function buildArknightsSection(r, user) {
  if (!r.cfg.sign.arknights) return '';
  const apiObj = arknightsApi();
  if (!apiObj) return '***\n\n> **方舟签到**：明日方舟插件未加载，本次跳过。';
  const keys = [...new Set([user.key, ...(Array.isArray(user.aliases) ? user.aliases : [])].filter(Boolean))];
  let akKey = '';
  for (const key of keys) {
    try {
      const st = typeof apiObj.status === 'function' ? apiObj.status(key) : null;
      if (st && st.loggedIn) {
        akKey = key;
        break;
      }
    } catch {
      /* next */
    }
  }
  if (!akKey) {
    return '***\n\n> **方舟签到**：未绑定鹰角账户，发送 `/Arknights 登录 手机号 密码` 后可同步明日方舟 / 终末地签到掉落。';
  }
  let res;
  try {
    res = await withTimeout(Promise.resolve(apiObj.sign(akKey)), r.cfg.sign.arknightsTimeoutMs, '方舟签到');
  } catch (e) {
    return `***\n\n> **方舟签到**：${T.escapeMarkdown(friendlyArkError(e))}`;
  }
  const accounts = Array.isArray(res?.accounts) ? res.accounts : [];
  if (!accounts.length) {
    const firstErr = Array.isArray(res?.errors) && res.errors.length ? res.errors[0] : null;
    const msg = firstErr?.message ? `（${T.clip(firstErr.message, 80)}）` : '';
    return `***\n\n> **方舟签到**：未读取到已绑定的明日方舟 / 终末地角色${msg ? T.escapeMarkdown(msg) : ''}。`;
  }
  const body = ['**方舟签到**', ''];
  for (const a of accounts) {
    body.push(...formatArkLine(a).split('\n'), '');
  }
  while (body.length && body[body.length - 1] === '') body.pop();
  return '***\n\n' + body.map((line) => (line ? `> ${line}` : '>')).join('\n');
}

function formatArkLine(a) {
  const game = a.game === 'endfield' ? '**终末地**' : '**明日方舟**';
  const who = `${game} · ${T.escapeMarkdown(a.name || '未命名')}（UID ${T.escapeMarkdown(a.uid || '-')}）`;
  let line;
  if (a.status === 'signed') {
    const awards = Array.isArray(a.awards)
      ? a.awards.map((x) => `${T.escapeMarkdown(x.name || '道具')} ×${T.escapeMarkdown(x.count ?? '?')}`).join('、')
      : '';
    line = awards ? `签到成功 · 获得 ${awards}` : '签到成功';
  } else if (a.status === 'already') {
    line = '今日已签到';
  } else {
    line = `签到失败：${T.escapeMarkdown(T.clip(a.message || '未知错误', 80))}`;
  }
  if (Number.isFinite(Number(a.daysSigned))) line += ` · 本月已签 ${Number(a.daysSigned)} 天`;
  if (Array.isArray(a.tomorrowAwards) && a.tomorrowAwards.length) {
    const tomorrow = a.tomorrowAwards.map((x) => `${T.escapeMarkdown(x.name || '道具')} ×${T.escapeMarkdown(x.count ?? '?')}`).join('、');
    line += ` · 明日 ${tomorrow}`;
  }
  return `${who}\n${line}`;
}

function friendlyArkError(e) {
  const msg = String(e?.message || e || '未知错误');
  if (/NOT_LOGIN|没有登录|未登录|请先.*登录/i.test(msg)) {
    return '未绑定鹰角账户，发送 `/Arknights 登录 手机号 密码` 后可同步方舟签到掉落。';
  }
  if (/NOT_READY/i.test(msg)) return '明日方舟插件尚未就绪，本次跳过。';
  return `签到失败：${T.clip(msg, 100)}`;
}

/* ======================= 菜单 ======================= */

async function handleMenu(ctx, r, who) {
  const user = who.found || r.store.get(who.key);
  const c2c = ctx.message?.kind === 'c2c';
  const conf = c2c ? r.cfg.menu.c2c : r.cfg.menu.group;
  const items = r.cfg.menu.enabled && conf.enabled ? conf.items : [];
  const head = heading(ctx, user || who, r);
  const scene = c2c ? '私聊' : '群聊';
  if (!items.length) {
    ctx.__commandVars = {
      heading: head,
      title: '## 菜单',
      scene: `> ${scene}通用指令`,
      items: '> 菜单还没配置，请联系管理员在面板「菜单」里添加。',
      footer: siteFooter(r),
    };
    return replyMd(
      ctx,
      r,
      [head, '## 菜单', '> 菜单还没配置，请联系管理员在面板「菜单」里添加。', '', siteFooter(r)].join('\n'),
      '菜单还没配置，请联系管理员。',
    );
  }
  const autoSend = c2c && r.cfg.menu.autoSend;
  const itemLines = [];
  for (const it of items) {
    const tag = qqCmdTag(it.command, it.name, autoSend);
    const desc = it.desc ? `：${T.escapeMarkdown(it.desc)}` : '';
    itemLines.push(`- ${tag}${desc}`);
  }
  ctx.__commandVars = {
    heading: head,
    title: '## 菜单',
    scene: `> ${scene}通用指令`,
    items: itemLines.join('\n'),
    footer: siteFooter(r),
  };
  const lines = [head, '## 菜单', `> ${scene}通用指令`, '', ...itemLines, '', siteFooter(r)];
  return replyMd(ctx, r, lines.join('\n'), '菜单：' + items.map((x) => x.command).join(' / '));
}

/**
 * QQ Markdown 指令标签：
 * - 私聊 + autoSend：<qqbot-cmd-enter> 点击直接发送（QQ 群聊不支持）
 * - 其它：<qqbot-cmd-input> 蓝字可点击，点击把指令填入输入框，用户按发送
 * text/show 按官方要求做 urlencode。
 */
function qqCmdTag(command, name, autoSend) {
  const text = encodeURIComponent(String(command || ''));
  if (autoSend) return `<qqbot-cmd-enter text="${text}" />`;
  const show = encodeURIComponent(String(name || command || ''));
  return `<qqbot-cmd-input text="${text}" show="${show}" />`;
}

async function handleMenuSync(ctx, r, who) {
  if (ctx.message?.kind !== 'c2c') {
    return replyMd(
      ctx,
      r,
      [heading(ctx, who, r), '## 请私聊同步', `> 菜单同步会修改机器人的全局菜单，请私聊机器人发送 ${cmdInline(ctx, r, 'menusync')}。`].join('\n'),
      `请私聊发送 ${cmdLabel(r, 'menusync')}。`,
    );
  }
  const last = menuSyncAt.get(who.key) || 0;
  if (Date.now() - last < 60000) {
    return replyMd(ctx, r, [heading(ctx, who, r), '## 稍后再试', '> 菜单同步每分钟只能执行一次。'].join('\n'), '菜单同步每分钟只能执行一次。');
  }
  menuSyncAt.set(who.key, Date.now());
  const out = await syncMenus(ctx, r, { force: true });
  const lines = [heading(ctx, who, r), '## 菜单同步'];
  if (out.skipped) {
    lines.push(`> ${out.skipped}`);
  } else {
    lines.push(`- **群聊面板**：${out.group}`, `- **私聊菜单**：${out.c2c}`);
    if (!out.ok) lines.push('', '> 有项目失败，请检查机器人是否在线、是否具备指令面板权限。');
  }
  ctx.__commandVars = {
    menusync_group: out.skipped ? '' : String(out.group || ''),
    menusync_c2c: out.skipped ? '' : String(out.c2c || ''),
    menusync_skipped: out.skipped ? String(out.skipped) : '',
  };
  return replyMd(ctx, r, lines.join('\n'), '菜单同步：' + (out.skipped || `群聊 ${out.group}，私聊 ${out.c2c}`));
}

/**
 * 把面板里的菜单同步到 QQ：
 * - 群聊 → 指令面板（scope=group，target_type=all，remark 固定为「VloS 菜单」，便于覆盖）
 * - 私聊 → 全局自定义菜单（/v2/menu，仅单聊生效）
 * 只有配置变化或强制同步时才调用，避免每次重载都删建面板。
 */
async function syncMenus(ctx, r, opts = {}) {
  // 同一个进程里并发触发（重载 + /菜单同步）时只跑一次，避免重复建面板
  if (menuSyncPromise) return menuSyncPromise;
  menuSyncPromise = syncMenusOnce(ctx, r, opts).finally(() => {
    menuSyncPromise = null;
  });
  return menuSyncPromise;
}

async function syncMenusOnce(ctx, r, { force = false } = {}) {
  const menu = r.cfg.menu;
  if (!menu.enabled || !menu.sync) return { skipped: '菜单同步已关闭' };
  if (!ctx.api || typeof ctx.api.call !== 'function') return { skipped: '当前没有可用的 QQ 接口' };
  const signature = JSON.stringify({
    g: menu.group.enabled ? menu.group.items : [],
    c: menu.c2c.enabled ? menu.c2c.items : [],
  });
  const stateFile = path.join(r.dir, 'data', 'menu-sync.json');
  let state = null;
  try {
    state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  } catch {
    /* 首次同步 */
  }
  if (!force && state && state.signature === signature && state.ok) return { skipped: '菜单没有变化' };

  const out = { group: '未启用', c2c: '未启用', ok: true };

  if (menu.c2c.enabled && menu.c2c.items.length) {
    const items = menu.c2c.items.map((it) => ({ type: 'send_message', name: it.name, send_message: it.command }));
    try {
      const res = await ctx.api.call('update_menu', { body: { menu: { items } } });
      out.c2c = res?.ok ? `已同步 ${items.length} 项` : `失败：${T.clip(res?.message || '未知错误', 40)}`;
      if (!res?.ok) out.ok = false;
    } catch (e) {
      out.c2c = '失败：' + T.clip(e?.message || e, 40);
      out.ok = false;
    }
  }

  if (menu.group.enabled && menu.group.items.length) {
    try {
      const list = await ctx.api.call('list_panels', { query: { scope: 'group', limit: '50' } });
      const data = list?.data || {};
      const panels = Array.isArray(data.panels)
        ? data.panels
        : Array.isArray(data.records)
          ? data.records
          : Array.isArray(data)
            ? data
            : [];
      for (const p of panels) {
        const remark = String(p?.panel?.remark || p?.remark || '');
        if (remark !== 'VloS 菜单') continue;
        const id = p?.panel_id || p?.id;
        if (id) {
          try {
            await ctx.api.call('delete_panel', { params: { panel_id: id } });
          } catch {
            /* 忽略单个删除失败 */
          }
        }
      }
      const items = menu.group.items.map((it) => ({
        type: 'command',
        name: String(it.command || '').slice(0, 14),
        desc: String(it.desc || '').slice(0, 30),
      }));
      const res = await ctx.api.call('create_panel', {
        body: { scope: 'group', target_type: 'all', panel: { items, remark: 'VloS 菜单' } },
      });
      out.group = res?.ok ? `已同步 ${items.length} 项` : `失败：${T.clip(res?.message || '未知错误', 40)}`;
      if (!res?.ok) out.ok = false;
    } catch (e) {
      out.group = '失败：' + T.clip(e?.message || e, 40);
      out.ok = false;
    }
  }

  if (out.ok) {
    try {
      fs.writeFileSync(stateFile, JSON.stringify({ signature, ok: true, at: Date.now() }, null, 2), 'utf8');
    } catch {
      /* 状态文件写失败不影响菜单 */
    }
  }
  r.log.info(`VloS 菜单同步：群聊 ${out.group}；私聊 ${out.c2c}`);
  return out;
}

/* ======================= 群管设置（一次性网页 + 审核） ======================= */

const GROUP_ADMIN_ROLES = ['owner', 'admin', '群主', '管理员', 'group_owner', 'group_admin', 'setadmin'];

function isGroupAdmin(m) {
  return GROUP_ADMIN_ROLES.includes(String(m?.author?.role || '').toLowerCase());
}

/**
 * 取发送者在群里的角色：
 * 事件里的 author.member_role 优先；部分客户端 / 事件不带这个字段时，
 * 再调「获取群成员信息」接口补一次（该接口是内邀能力，失败只写日志，不影响主流程）。
 */
async function resolveGroupRole(ctx, r, m) {
  const direct = String(m?.author?.role || '').toLowerCase();
  if (direct) return direct;
  const group = String(m?.group_openid || '');
  const member = String(m?.author?.member_openid || '');
  if (!group || !member || typeof ctx?.api?.request !== 'function') return '';
  try {
    const res = await ctx.api.request('GET', `/v2/groups/${encodeURIComponent(group)}/members/${encodeURIComponent(member)}`);
    if (res?.ok === false) {
      r.log.warn(`VloS /群管 查询群成员角色失败 code=${res.code || ''} ${res.message || ''}`);
      return '';
    }
    const role = String(res?.data?.member_role || '').toLowerCase();
    if (role) r.log.info(`VloS /群管 通过群成员接口补到角色：${role}`);
    return role;
  } catch (e) {
    r.log.warn('VloS /群管 查询群成员角色异常：' + (e?.message || e));
    return '';
  }
}

function memberAvatar(ctx, m) {
  const a = m?.author || {};
  if (a.avatar) return String(a.avatar);
  let appId = '';
  try {
    appId = String(ctx?.bot?.info?.()?.appId || '');
  } catch {
    appId = '';
  }
  const openid = String(a.member_openid || a.id || '');
  return appId && openid ? `https://q.qlogo.cn/qqapp/${encodeURIComponent(appId)}/${encodeURIComponent(openid)}/0` : '';
}

function splitKeywords(v) {
  return [...new Set(String(v || '').split(/[\n,，、;；]+/).map((s) => s.trim()).filter(Boolean))].slice(0, 200);
}

/** 空白回调 payload -> welcome 覆盖 */
function payloadToWelcome(p, fallback) {
  const fb = fallback || {};
  return {
    memberJoin: {
      enabled: p.wJoinEnabled === '1',
      template: String(p.wJoinTpl || fb.memberJoin?.template || ''),
    },
    memberLeave: {
      enabled: p.wLeaveEnabled === '1',
      template: String(p.wLeaveTpl || fb.memberLeave?.template || ''),
    },
  };
}

/** 空白回调 payload -> guard 覆盖 */
function payloadToGuard(p) {
  return {
    enabled: p.gEnabled === '1',
    bannedWords: splitKeywords(p.bannedWords),
    action: ['recall', 'recall_mute', 'warn'].includes(p.gAction) ? p.gAction : 'recall',
    muteSeconds: Math.min(2592000, Math.max(60, Number(p.muteSeconds) || 600)),
    join: {
      enabled: p.jEnabled === '1',
      mode: ['manual', 'approve', 'decline', 'qa'].includes(p.joinMode) ? p.joinMode : 'manual',
      rejectReason: String(p.rejectReason || ''),
      qaKeywords: splitKeywords(p.joinKeywords),
      qaFallback: p.joinFallback === 'manual' ? 'manual' : 'decline',
    },
  };
}

/** 本群最近一次「已提交未审核」的记录（用于再次 /群管 时带上上次填写的内容） */
function latestPendingItem(r, group) {
  const data = loadCallbacks(r);
  return (
    Object.values(data.items)
      .filter((it) => it.group === group && it.status === 'submitted' && !(r.cfg.callbackReviews && r.cfg.callbackReviews[it.id]))
      .sort((a, b) => (Number(b.submittedAt) || 0) - (Number(a.submittedAt) || 0))[0] || null
  );
}

/** 还没提交、还没过期、带地址的页面：再发 /群管 时直接复用，不新建回调 */
function reusableAwaiting(r, group) {
  const now = Date.now();
  const data = loadCallbacks(r);
  return (
    Object.values(data.items)
      .filter(
        (it) =>
          it.group === group &&
          it.status === 'awaiting' &&
          it.url &&
          (!it.expiresAt || Number(it.expiresAt) > now + 30 * 1000),
      )
      .sort((a, b) => (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0))[0] || null
  );
}

/** 新建页面时把同群旧的未提交页面作废，避免旧地址继续可用 */
function expireAwaiting(r, group) {
  const data = loadCallbacks(r);
  let changed = false;
  for (const it of Object.values(data.items)) {
    if (it.group === group && it.status === 'awaiting') {
      it.status = 'expired';
      changed = true;
    }
  }
  if (changed) {
    saveCallbacks(r, data);
    refreshReviewSnapshot(r);
  }
}

function escHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function selectHtml(name, value, options) {
  const opts = options
    .map(([v, label]) => `<option value="${escHtml(v)}"${String(value) === String(v) ? ' selected' : ''}>${escHtml(label)}</option>`)
    .join('');
  return `<select name="${escHtml(name)}">${opts}</select>`;
}

/** 生成「空白回调」页面 HTML：群主 / 管理员填本群进退群 + 群管设置 */
function buildGroupAdminHtml({ name, group, welcome, guard, custom, cmdVars, defaults }) {
  const w = welcome || {};
  const g = guard || {};
  const join = g.join || {};
  const v = w.joinVerify || {};
  const vAnswers = Array.isArray(v.answers) ? v.answers.slice(0, 4) : [];
  const vCorrect = Math.min(Math.max(0, Number(v.correctIndex) || 0), Math.max(0, vAnswers.length - 1));
  const vRowCount = Math.max(2, vAnswers.length || 2);
  const vExpire = Math.min(10, Math.max(1, Number(v.expiresMinutes) || 5));
  const vExpireOpts = Array.from({ length: 10 }, (_, i) => [String(i + 1), `${i + 1} 分钟`]);
  const vRowsHtml = [1, 2, 3, 4]
    .map((i) => {
      const checked = i - 1 === vCorrect ? 'checked' : '';
      return `<div class="v-answer-row" data-vrow="${i}" ${i > vRowCount ? 'hidden' : ''}>
        <label class="radio"><input type="radio" name="vVerifyCorrect" value="${i}" ${checked}> <span>${i}.</span></label>
        <input type="text" name="vVerifyAnswer${i}" value="${escHtml(vAnswers[i - 1] || '')}" placeholder="答案 ${i}">
        <button type="button" class="ghost" data-vdel="${i}">删除</button>
      </div>`;
    })
    .join('');
  const groupJson = JSON.stringify(String(name || '')).replace(/</g, '\\u003c');
  const cmdJson = JSON.stringify(cmdVars || {}).replace(/</g, '\\u003c');
  const defaultsJson = JSON.stringify({
    join: defaults?.join || '',
    leave: defaults?.leave || '',
  }).replace(/</g, '\\u003c');
  const previewScript = String.raw`<script>
(function () {
  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function md(src) {
    var s = String(src || '');
    var chips = [];
    s = s.replace(/<qqbot-at-user\s+id="([^"]*)"\s*\/>/g, function () {
      chips.push('<span class="tag">@用户</span>');
      return '\u0000' + (chips.length - 1) + '\u0000';
    });
    s = s.replace(/<qqbot-at-everyone\s*\/>/g, function () {
      chips.push('<span class="tag">@全体成员</span>');
      return '\u0000' + (chips.length - 1) + '\u0000';
    });
    s = s.replace(/<qqbot-cmd-(?:input|enter)([^>]*)\/>/g, function (m, attrs) {
      var show = /show="([^"]*)"/.exec(attrs);
      var text = /text="([^"]*)"/.exec(attrs);
      var label = show ? show[1] : text ? text[1] : '指令';
      try { label = decodeURIComponent(label); } catch (e) { /* 未编码时按原文显示 */ }
      chips.push('<span class="tag">' + esc(label) + '</span>');
      return '\u0000' + (chips.length - 1) + '\u0000';
    });
    s = esc(s);
    s = s.replace(/^### (.+)$/gm, '<h3>$1</h3>').replace(/^## (.+)$/gm, '<h2>$1</h2>').replace(/^# (.+)$/gm, '<h1>$1</h1>');
    s = s.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');
    s = s.replace(/^\s*[-*] (.+)$/gm, '<li>$1</li>');
    s = s.replace(/(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g, '<ul>$1</ul>');
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    var bt = String.fromCharCode(96);
    s = s.replace(new RegExp(bt + '([^' + bt + ']+)' + bt, 'g'), '<code>$1</code>');
    s = s.replace(/!\[([^\]]*)\]\((https?:[^)\s]+)\)/g, '<img alt="$1" src="$2">');
    s = s.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>');
    s = s.replace(/^\*{3,}$/gm, '<hr>');
    s = s.replace(/\n{2,}/g, '</p><p>').replace(/\n/g, '<br>');
    s = '<p>' + s + '</p>';
    chips.forEach(function (h, i) { s = s.replace('\u0000' + i + '\u0000', h); });
    return s;
  }
  var SAMPLE = {
    group: ${groupJson},
    member: '小明', member_openid: 'MEMBER_OPENID', username: '小明',
    group_openid: 'GROUP_OPENID', time: '', apply_source: '主动申请',
    verify_message: '我是聚龙世界的道友', op_member: 'OP_MEMBER_OPENID',
    at_member: '<qqbot-at-user id="MEMBER_OPENID" />', at_user: '<qqbot-at-user id="MEMBER_OPENID" />',
    at_op: '<qqbot-at-user id="OP_MEMBER_OPENID" />', at_all: '<qqbot-at-everyone />'
  };
  Object.assign(SAMPLE, ${cmdJson});
  SAMPLE.time = new Date().toLocaleString('zh-CN', { hour12: false });
  var DEFAULTS = ${defaultsJson};
  document.querySelectorAll('[data-reset]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var which = btn.getAttribute('data-reset');
      var t = document.getElementById(which === 'leave' ? 'tplLeave' : 'tplJoin');
      if (!t) return;
      t.value = which === 'leave' ? (DEFAULTS.leave || '') : (DEFAULTS.join || '');
      t.dispatchEvent(new Event('input', { bubbles: true }));
    });
  });
  function render(inputId, previewId) {
    var t = document.getElementById(inputId), p = document.getElementById(previewId);
    if (!t || !p) return;
    var text = t.value.replace(/\{(\w+)(?::([^}]*))?\}/g, function (_, k, arg) {
      if (k === 'cmd' && arg !== undefined) {
        var parts = String(arg).split('|');
        var cmd = (parts[0] || '').trim();
        if (!cmd) return '';
        var show = (parts.length > 1 ? parts[1] : cmd).trim() || cmd;
        return '<qqbot-cmd-input text="' + encodeURIComponent(cmd) + '" show="' + encodeURIComponent(show) + '" />';
      }
      return SAMPLE[k] === undefined ? '' : SAMPLE[k];
    });
    text = text.replace(/^[ \t]*(-{3,}|_{3,})[ \t]*$/gm, '***');
    if (inputId === 'tplJoin') {
      var vOnEl = document.querySelector('[name="vVerifyEnabled"]');
      var joinOnEl = document.querySelector('[name="wJoinEnabled"]');
      if (vOnEl && joinOnEl && vOnEl.value === '1' && joinOnEl.value === '1') {
        var arkEl = document.querySelector('input[name="vVerifyMode"]:checked');
        var expireEl = document.querySelector('[name="vVerifyExpire"]');
        var vMinutes = Math.min(10, Math.max(1, Number(expireEl && expireEl.value) || 5));
        var limitLine = String.fromCharCode(10) + '> 限时 ' + vMinutes + ' 分钟';
        var block = '';
        if (arkEl && arkEl.value === 'arknights') {
          block = '## 入群验证' + limitLine + String.fromCharCode(10) + '请私聊机器人授权鹰角网络账户，授权后点击下方按钮校验' + String.fromCharCode(10) + '> 按钮：开始校验（仅本人可点）';
        } else {
          var qEl = document.querySelector('[name="vVerifyQuestion"]');
          var q = qEl ? qEl.value.trim() : '';
          var ans = Array.prototype.slice
            .call(document.querySelectorAll('[name^="vVerifyAnswer"]'))
            .map(function (x) { return String(x.value || '').trim(); })
            .filter(Boolean);
          block = '## 入群验证' + limitLine + String.fromCharCode(10) + q;
          if (ans.length) block += String.fromCharCode(10) + '> 答案按钮：' + ans.join(' / ') + '（仅新成员可点）';
        }
        if (block) {
          var NL = String.fromCharCode(10);
          text = [text, block].filter(Boolean).join(NL + NL + '***' + NL + NL);
        }
      }
    }
    p.innerHTML = md(text);
  }
  var pairs = [['tplJoin', 'pvJoin'], ['tplLeave', 'pvLeave']];
  pairs.forEach(function (pair) {
    var t = document.getElementById(pair[0]);
    if (!t) return;
    t.addEventListener('input', function () { render(pair[0], pair[1]); });
    render(pair[0], pair[1]);
  });
  ['wJoinEnabled', 'vVerifyEnabled', 'vVerifyQuestion'].forEach(function (name) {
    var el = document.querySelector('[name="' + name + '"]');
    if (!el) return;
    el.addEventListener('change', function () { render('tplJoin', 'pvJoin'); });
    el.addEventListener('input', function () { render('tplJoin', 'pvJoin'); });
  });
  document.querySelectorAll('input[name="vVerifyMode"]').forEach(function (el) {
    el.addEventListener('change', function () { render('tplJoin', 'pvJoin'); });
  });

  // 开关联动：功能关闭时，对应组件全部隐藏
  function depVal(name) {
    var el = document.querySelector('[name="' + name + '"]');
    return el ? String(el.value) : '';
  }
  function depShow(id, show) {
    var el = document.getElementById(id);
    if (el) el.hidden = !show;
  }
  function syncDeps() {
    var joinOn = depVal('wJoinEnabled') === '1';
    depShow('joinBox', joinOn);
    // 入群验证属于进退群范围，卡片始终可见；「新成员进群」关闭时只提示不生效
    depShow('vJoinOffTip', !joinOn);
    depShow('leaveBox', depVal('wLeaveEnabled') === '1');
    depShow('guardBox', depVal('gEnabled') === '1');
    depShow('joinReqBox', depVal('jEnabled') === '1');
    var vOn = depVal('vVerifyEnabled') === '1';
    depShow('vFields', vOn);
    var radio = document.querySelector('input[name="vVerifyMode"]:checked');
    var isArk = !!(radio && radio.value === 'arknights');
    depShow('vCustomBox', vOn && !isArk);
    depShow('vArkTip', vOn && isArk);
  }
  document
    .querySelectorAll('[name="wJoinEnabled"],[name="wLeaveEnabled"],[name="gEnabled"],[name="jEnabled"],[name="vVerifyEnabled"],input[name="vVerifyMode"]')
    .forEach(function (el) { el.addEventListener('change', syncDeps); });
  syncDeps();

  // 答案行：+ 添加（最多 4）、删除（至少保留 2）、单选标记正确答案
  function vRows() { return Array.prototype.slice.call(document.querySelectorAll('[data-vrow]')); }
  function vVisibleRows() { return vRows().filter(function (r) { return !r.hidden; }); }
  function syncAnswerRows() {
    var vis = vVisibleRows();
    var checked = document.querySelector('input[name="vVerifyCorrect"]:checked');
    if (!checked || checked.closest('[data-vrow]').hidden) {
      var first = vis[0] && vis[0].querySelector('input[name="vVerifyCorrect"]');
      if (first) first.checked = true;
    }
    vRows().forEach(function (row) {
      var del = row.querySelector('[data-vdel]');
      if (del) del.disabled = !row.hidden && vis.length <= 2;
    });
    var add = document.getElementById('vAddAnswer');
    if (add) add.disabled = vRows().every(function (r) { return !r.hidden; });
  }
  var addAnswerBtn = document.getElementById('vAddAnswer');
  if (addAnswerBtn) addAnswerBtn.addEventListener('click', function () {
    var row = vRows().find(function (r) { return r.hidden; });
    if (row) { row.hidden = false; syncAnswerRows(); }
  });
  document.querySelectorAll('[data-vdel]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var row = btn.closest('[data-vrow]');
      if (!row || vVisibleRows().length <= 2) return;
      row.hidden = true;
      var input = row.querySelector('input[type=text]');
      if (input) input.value = '';
      var radio = row.querySelector('input[name="vVerifyCorrect"]');
      if (radio) radio.checked = false;
      syncAnswerRows();
    });
  });
  document.querySelectorAll('input[name="vVerifyCorrect"]').forEach(function (r) { r.addEventListener('change', syncAnswerRows); });
  syncAnswerRows();
})();
</script>`;
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>群管设置 · ${escHtml(name)}</title>
<style>
body{margin:0;padding:18px;background:#f5f7fb;color:#0f172a;font:14px/1.7 -apple-system,"Microsoft YaHei",sans-serif}
h1{font-size:17px;margin:0 0 4px}.sub{color:#64748b;font-size:12px;margin:0 0 14px}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:14px;margin:0 0 12px}
.subcard{border:1px dashed #c7d2fe;border-radius:12px;padding:10px 12px;margin:12px 0;background:#f8faff}
label.radio{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:#0f172a;white-space:nowrap}
.v-answer-row{display:flex;align-items:center;gap:8px;margin:6px 0}
.v-answer-row[hidden]{display:none}
.v-answer-row input[type=text]{flex:1}
.v-answer-row button{width:auto;margin:0}
.v-answer-row .radio{min-width:52px}
h2{font-size:14px;margin:0 0 8px}.field{display:block;margin:10px 0}.field span{display:block;font-size:12px;color:#64748b;margin-bottom:5px}
input[type=text],input[type=number],textarea,select{width:100%;box-sizing:border-box;border:1px solid #e2e8f0;background:#f8fafc;color:#0f172a;border-radius:9px;padding:8px 10px;font:inherit}
textarea{min-height:90px;font-family:ui-monospace,Consolas,monospace;font-size:12.5px}
.hint{color:#64748b;font-size:12px}.row{display:flex;gap:10px}.row>*{flex:1}
.md-preview{margin:-4px 0 12px;padding:10px 12px;border:1px dashed #cbd5e1;border-radius:10px;background:#fbfdff;font-size:13px;line-height:1.8}
.md-preview h1,.md-preview h2,.md-preview h3{margin:8px 0 4px;font-size:15px}
.md-preview blockquote{margin:6px 0;padding:2px 10px;border-left:3px solid #e2e8f0;color:#475569}
.md-preview .tag{display:inline-block;padding:1px 7px;border-radius:999px;background:#eef2ff;color:#1d4ed8;font-weight:600;font-size:12px}
.md-preview img{max-width:100%;border-radius:8px}
.md-preview hr{border:0;border-top:1px solid #e2e8f0;margin:8px 0}
blockquote{margin:12px 0 0;padding:6px 12px;border-left:3px solid #e2e8f0;background:#f8fafc;color:#475569}
.ghost{background:#eef2ff;color:#1d4ed8;border:1px solid #c7d2fe;border-radius:8px;padding:3px 8px;font-size:12px;font-weight:600;margin:0;width:auto}
button{margin-top:6px;border:0;border-radius:10px;background:linear-gradient(135deg,#1d4ed8,#4f46e5);color:#fff;font-weight:700;padding:11px 16px;font-size:14px}
</style></head><body>
<h1>群管设置 · ${escHtml(name)}</h1>
<p class="sub">修改后提交：进退群（新成员进群 / 成员退群 / 入群验证）只关闭功能、和全局一致、和上次已通过的设置一致（含两者混用），都会自动通过；群管部分（违禁词、处理入群申请等）不在审核判断范围内。只有改了进退群模板 / 验证题才需要机器人管理员审核。Bot 入群欢迎不在此范围。${custom ? '当前已有本群自定义。' : '当前使用全局默认。'}</p>
<form>
<input type="hidden" name="group_openid" value="${escHtml(group)}">
<div class="card" id="verifyCard">
  <h2>入群验证</h2>
  <p class="hint" id="vJoinOffTip" hidden>当前「新成员进群」是关闭的：入群验证不会生效，成员进群也不会出验证题；打开上面的「新成员进群」后才生效。</p>
  <label class="field"><span>启用入群验证（受「新成员进群」开关控制，关闭时不生效）</span>${selectHtml('vVerifyEnabled', v.enabled ? '1' : '0', [['1', '开启'], ['0', '关闭']])}</label>
  <div id="vFields" ${v.enabled ? '' : 'hidden'}>
    <label class="field"><span>验证方式</span>
      <div class="row">
        <label class="radio"><input type="radio" name="vVerifyMode" value="custom" ${v.mode === 'arknights' ? '' : 'checked'}> 自定义问题</label>
        <label class="radio"><input type="radio" name="vVerifyMode" value="arknights" ${v.mode === 'arknights' ? 'checked' : ''}> 明日方舟校验</label>
      </div>
    </label>
    <div id="vCustomBox" ${v.mode === 'arknights' ? 'hidden' : ''}>
      <label class="field"><span>问题（发在欢迎语后面，用 *** 分隔）</span><textarea name="vVerifyQuestion">${escHtml(v.question || '')}</textarea></label>
      <div class="field"><span>答案（单选框选中的是正确答案，其他都算错；2–4 个）</span>
        <div id="vAnswerRows">${vRowsHtml}</div>
        <div class="row" style="gap:8px;align-items:center;margin-top:6px">
          <button type="button" class="ghost" id="vAddAnswer">+ 添加答案</button>
          <span class="hint">最多 4 个，至少保留 2 个</span>
        </div>
      </div>
      <label class="field"><span>最多答错次数（达到即踢出）</span><input type="number" name="vVerifyMax" min="1" max="10" value="${escHtml(v.maxAttempts || 3)}"></label>
    </div>
    <label class="field"><span>验证限时（超过后本次验证失效，需重新进群）</span>${selectHtml('vVerifyExpire', String(vExpire), vExpireOpts)}</label>
    <p class="hint" id="vArkTip" ${v.mode === 'arknights' ? '' : 'hidden'}>固定提示用户私聊授权鹰角网络账户，并挂一个「开始校验」按钮，限时内校验 <code>isLoggedIn</code>（默认 5 分钟）。</p>
  </div>
</div>
<div class="card">
  <h2>进退群</h2>
  <label class="field"><span>新成员进群</span>${selectHtml('wJoinEnabled', w.memberJoin?.enabled ? '1' : '0', [['1', '开启'], ['0', '关闭']])}</label>
  <div id="joinBox" ${w.memberJoin?.enabled ? '' : 'hidden'}>
    <label class="field"><span style="display:flex;align-items:center;justify-content:space-between;gap:10px"><span>进群 Markdown 模板（变量：{group} {member} {at_member} {at_all} {time}）</span><button type="button" class="ghost" data-reset="join">恢复默认</button></span><textarea name="wJoinTpl" id="tplJoin">${escHtml(w.memberJoin?.template || '')}</textarea></label>
    <div class="md-preview" id="pvJoin"></div>
  </div>
  <label class="field"><span>成员退群</span>${selectHtml('wLeaveEnabled', w.memberLeave?.enabled ? '1' : '0', [['1', '开启'], ['0', '关闭']])}</label>
  <div id="leaveBox" ${w.memberLeave?.enabled ? '' : 'hidden'}>
    <label class="field"><span style="display:flex;align-items:center;justify-content:space-between;gap:10px"><span>退群 Markdown 模板</span><button type="button" class="ghost" data-reset="leave">恢复默认</button></span><textarea name="wLeaveTpl" id="tplLeave">${escHtml(w.memberLeave?.template || '')}</textarea></label>
    <div class="md-preview" id="pvLeave"></div>
  </div>
</div>
<div class="card">
  <h2>群管</h2>
  <label class="field"><span>启用违禁词</span>${selectHtml('gEnabled', g.enabled ? '1' : '0', [['1', '开启'], ['0', '关闭']])}</label>
  <div id="guardBox" ${g.enabled ? '' : 'hidden'}>
    <label class="field"><span>违禁词（每行一个 / 逗号分隔）</span><textarea name="bannedWords">${escHtml((g.bannedWords || []).join('\n'))}</textarea></label>
    <div class="row">
      <label class="field"><span>命中动作</span>${selectHtml('gAction', g.action || 'recall', [['recall', '撤回'], ['recall_mute', '撤回并禁言'], ['warn', '只警告']])}</label>
      <label class="field"><span>禁言秒数</span><input type="number" name="muteSeconds" min="60" max="2592000" step="60" value="${escHtml(g.muteSeconds || 600)}"></label>
    </div>
  </div>
  <label class="field"><span>处理入群申请</span>${selectHtml('jEnabled', join.enabled ? '1' : '0', [['1', '开启'], ['0', '关闭']])}</label>
  <div id="joinReqBox" ${join.enabled ? '' : 'hidden'}>
    <label class="field"><span>审批方式</span>${selectHtml('joinMode', join.mode || 'manual', [['manual', '只记录'], ['approve', '自动通过'], ['decline', '自动拒绝'], ['qa', '按答案关键词审核']])}</label>
    <label class="field"><span>答案关键词（qa 模式，每行一个）</span><textarea name="joinKeywords">${escHtml((join.qaKeywords || []).join('\n'))}</textarea></label>
    <label class="field"><span>没命中关键词时</span>${selectHtml('joinFallback', join.qaFallback || 'decline', [['decline', '自动拒绝'], ['manual', '留给管理员']])}</label>
    <label class="field"><span>拒绝理由</span><input type="text" name="rejectReason" maxlength="100" value="${escHtml(join.rejectReason || '')}"></label>
  </div>
</div>
<p class="hint">提交后页面失效；审核判断只看进退群的 3 项（新成员进群 / 成员退群 / 入群验证）：只关闭、与全局一致、与上次已通过版本一致（含两者混用）都会自动通过并直接生效；群管部分（违禁词、处理入群申请等）不参与判断。只有改了进退群模板 / 验证题才进入机器人设置页「审核」，管理员通过后本群生效。</p>
<blockquote><strong>推荐使用电脑进行编辑</strong></blockquote>
</form>
${previewScript}
</body></html>`;
}

/** 2026-11-17 新增：用群消息 msg_id 私聊回复发送者（优先于主动 C2C） */
async function sendGroupPrivateReply(r, ctx, content, extraOpenids) {
  const m = ctx.message;
  const msgId = String(m?.id || '');
  if (!msgId || !r.bot?.sendC2C) return { ok: false, via: '' };
  const ids = [
    ...new Set(
      [m.author?.member_openid, m.author?.union_openid, ...(Array.isArray(extraOpenids) ? extraOpenids : [])]
        .map(String)
        .filter(Boolean),
    ),
  ].slice(0, 4);
  for (let i = 0; i < ids.length; i++) {
    const openid = ids[i];
    try {
      const res = await r.bot.sendC2C(openid, {
        msg_type: 0,
        content,
        msg_id: msgId,
        msg_seq: i + 1,
      });
      if (res?.ok) return { ok: true, via: 'group', openid };
      r.log.warn(`VloS 群消息私聊回复失败 openid=${openid}：${res?.message || res?.code || 'unknown'}`);
    } catch (e) {
      r.log.warn(`VloS 群消息私聊回复异常 openid=${openid}：${e?.message || e}`);
    }
  }
  return { ok: false, via: '' };
}

async function handleGroupAdmin(ctx, r, who) {
  const m = ctx.message;
  if (!m || m.kind !== 'group') {
    return replyNotice(ctx, r, [heading(ctx, who, r), '## 请在群里使用', '> `/群管` 是群主 / 管理员给本群改设置用的，请在群里发送。'].join('\n'), '请在群里使用 /群管。');
  }
  const role = await resolveGroupRole(ctx, r, m);
  r.log.info(
    `VloS /群管 权限检查 group=${m.group_openid} role=${role || '(空)'} event=${ctx.event?.name || ctx.event?.t || ''} kind=${m.kind} member=${m.author?.member_openid || ''}`,
  );
  if (!GROUP_ADMIN_ROLES.includes(role)) {
    if (role === 'member') {
      r.log.warn('VloS /群管 被拒绝：发送者是普通成员（member）');
      return replyNotice(
        ctx,
        r,
        [
          heading(ctx, who, r),
          '## 需要群主 / 管理员',
          `> 当前识别角色：**${role}**（QQ 事件下发）`,
          '> 只有群主或管理员可以修改本群设置；如果 QQ 没有下发成员角色，也会被拒绝。',
        ].join('\n'),
        '只有群主或管理员可以使用 /群管。',
      );
    }
    // 角色字段缺失且群成员接口也拿不到（内邀能力）：放行到「提交后管理员审核」，避免误伤群主/管理员
    r.log.warn(`VloS /群管 角色未知（${role || '空'}），放行到管理员审核：group=${m.group_openid} member=${m.author?.member_openid || ''}`);
  }
  if (!r.cfg.jlAccount.key) {
    return replyNotice(ctx, r, [heading(ctx, who, r), '## 未配置发奖 Key', '> 群管设置需要聚龙 Key 的 callback 权限，请先在面板配置。'].join('\n'), '未配置发奖 Key。');
  }
  const group = m.group_openid;
  const groupName = await groupNameOf(ctx, r, group);
  const pending = latestPendingItem(r, group);
  if (pending) {
    const at = pending.submittedAt ? new Date(pending.submittedAt).toLocaleString('zh-CN', { hour12: false }) : '刚刚';
    return replyNotice(
      ctx,
      r,
      [
        heading(ctx, who, r),
        '## 设置正在审核中',
        `> 本群在 **${at}** 提交的群管设置还在等待管理员审核。`,
        '> 审核通过或拒绝后才能再次提交，请耐心等待。',
      ].join('\n'),
      '本群已有一份群管设置正在审核，请等管理员通过或拒绝后再提交。',
    );
  }
  const rawOverride = r.cfg.groups?.[group] || null;
  const pendingOverride = rawOverride && rawOverride.reviewStatus === 'pending' ? rawOverride : null;
  const baseWelcome = pendingOverride
    ? deepMerge(r.cfg.welcome, pendingOverride.welcome || {})
    : effectiveWelcome(r, group);
  const baseGuard = pendingOverride
    ? deepMerge(r.cfg.guard, pendingOverride.guard || {})
    : effectiveGuard(r, group);
  // 同一个群上一次页面还没提交、也没过期：直接复用地址，不新建回调
  let id = '';
  let url = '';
  let expiresAt = 0;
  let reused = false;
  const awaiting = reusableAwaiting(r, group);
  if (awaiting) {
    id = String(awaiting.id);
    url = String(awaiting.url);
    expiresAt = Number(awaiting.expiresAt) || 0;
    reused = true;
    r.log.info(`VloS 复用未提交的群管设置页面 group=${group} id=${id}`);
  } else {
    expireAwaiting(r, group);
    let created;
    try {
      created = await r.jl.callbackCreate({
        title: `群管设置 · ${groupName}`.slice(0, 100),
        html: buildGroupAdminHtml({
          name: groupName,
          group,
          welcome: baseWelcome,
          guard: baseGuard,
          custom: !!groupOverride(r, group) || !!pendingOverride,
          cmdVars: commandSampleVars(r),
          defaults: {
            join: r.cfg.welcome.memberJoin.template,
            leave: r.cfg.welcome.memberLeave.template,
          },
        }),
        expiresMinutes: 10,
        requireLogin: false,
      });
    } catch (e) {
      return replyNotice(
        ctx,
        r,
        [heading(ctx, who, r), '## 创建设置页面失败', `> ${T.escapeMarkdown(friendlyError(e))}`, '> 请确认聚龙 Key 已授予 `callback` 权限。'].join('\n'),
        '创建设置页面失败：' + friendlyError(e),
      );
    }
    id = String(created?.id || '');
    url = String(created?.url || '');
    expiresAt = Number(created?.expiresAt) || Date.now() + 10 * 60000;
    if (!id || !url) {
      return replyNotice(ctx, r, [heading(ctx, who, r), '## 创建设置页面失败', '> 接口没有返回页面地址。'].join('\n'), '创建设置页面失败。');
    }
  }
  const notifyOpenids = [
    ...new Set(
      [m.author?.union_openid, m.author?.user_openid, who?.found?.openid, ...(who?.found?.aliases || [])]
        .map(String)
        .filter(Boolean),
    ),
  ].slice(0, 6);
  if (!reused) {
    addPendingCallback(r, {
      id,
      url,
      group,
      groupName,
      by: m.author?.username || '',
      byAvatar: memberAvatar(ctx, m),
      notifyOpenids,
      createdAt: Date.now(),
      expiresAt,
      status: 'awaiting',
    });
  }
  startCallbackPolling(r);

  // 链接只走私聊，群里不贴地址；没加好友 / 没绑定 OpenID 时提示操作步骤
  const privateText = [
    '【群管设置】',
    `群：${groupName}`,
    `提交人：${m.author?.username || '群管理'}`,
    reused ? '这是 10 分钟内还没提交的同一个页面，继续填写即可：' : '链接 10 分钟内有效，打开后填写并提交：',
    url,
  ].join('\n');
  // 优先用 2026-11-17 新增的「群消息私聊回复」；失败再走主动 C2C
  let sent = false;
  let sentVia = '';
  const groupPrivate = await sendGroupPrivateReply(r, ctx, privateText, notifyOpenids);
  if (groupPrivate.ok) {
    sent = true;
    sentVia = '群消息私聊回复';
  } else {
    sent = await sendPrivate(r, notifyOpenids, privateText);
    sentVia = sent ? '主动C2C' : '';
  }
  r.log.info(
    `VloS 群管设置链接私聊 ${sent ? '已发送（' + sentVia + '）' : '发送失败'} group=${group} id=${id}${reused ? '（复用）' : ''}`,
  );

  const lines = [
    heading(ctx, who, r),
    '## 群管设置',
    `> 群：**${T.escapeMarkdown(groupName)}**`,
    sent
      ? '> 设置链接已私聊发送，请在私聊里查看（10 分钟内有效，提交后失效）。'
      : '> 私聊发送失败（无权限）：请先添加机器人为私聊好友，再回群重新发送 `/群管`。',
    '> 没收到私聊？请先添加机器人好友；也可以私聊发送 `/bindopenid` 绑定当前 OpenID。',
    reused ? '> 已复用 10 分钟内还没提交的旧链接。' : '',
    '> **推荐使用电脑进行编辑**',
  ].filter(Boolean);
  return replyMd(ctx, r, lines.join('\n'), sent ? '群管设置链接已私聊发送。' : '私聊发送失败，请先添加机器人好友。');
}

/* ---- 一次性页面的提交轮询 ---- */

const CALLBACK_FILE = 'callbacks.json';
let callbackTimer = null;
let callbackPolling = false;

function callbacksFile(r) {
  return path.join(r.dir, 'data', CALLBACK_FILE);
}

function loadCallbacks(r) {
  try {
    const j = JSON.parse(fs.readFileSync(callbacksFile(r), 'utf8'));
    return { items: j && j.items && typeof j.items === 'object' ? j.items : {} };
  } catch {
    return { items: {} };
  }
}

function saveCallbacks(r, data) {
  try {
    fs.mkdirSync(path.join(r.dir, 'data'), { recursive: true });
    fs.writeFileSync(callbacksFile(r), JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    r.log.warn('VloS 保存空白回调状态失败：' + (e?.message || e));
  }
}

function addPendingCallback(r, item) {
  const data = loadCallbacks(r);
  data.items[item.id] = item;
  saveCallbacks(r, data);
  refreshReviewSnapshot(r);
}

/** 私聊候选 OpenID 依次尝试；群 member_openid 不一定能私聊，失败就换下一个 */
/** 生成管理员审核页：成品预览 + 通过/拒绝 + 拒绝理由；页面由聚龙 callback 托管 */
function buildReviewHtml(r, item) {
  const p = item.payload || {};
  const groupName = item.groupName || item.group || '群聊';
  const data = JSON.stringify({
    group: groupName,
    join: String(p.wJoinTpl || ''),
    leave: String(p.wLeaveTpl || ''),
  }).replace(/</g, '\\u003c');
  const modeLabel = { manual: '只记录', approve: '自动通过', decline: '自动拒绝', qa: '按答案关键词审核' }[p.joinMode] || p.joinMode || 'manual';
  const actionLabel = { recall: '撤回', recall_mute: '撤回并禁言', warn: '只警告' }[p.gAction] || p.gAction || 'recall';
  const joinOn = p.wJoinEnabled === '1';
  const leaveOn = p.wLeaveEnabled === '1';
  const vOn = p.vVerifyEnabled === '1';
  const vIsArk = p.vVerifyMode === 'arknights';
  let vSlots = [1, 2, 3, 4]
    .map((i) => String(p['vVerifyAnswer' + i] || '').trim())
    .filter(Boolean);
  if (!vSlots.length && p.vVerifyAnswers) {
    vSlots = String(p.vVerifyAnswers)
      .split(/[\n\r]+/)
      .map((s) => s.trim())
      .filter(Boolean);
  }
  const vPick = String(p['vVerifyAnswer' + (Number(p.vVerifyCorrect) || 1)] || '').trim();
  const vAnswerText = vSlots.map((a, i) => (a === vPick ? '✓ ' : '') + (i + 1) + '. ' + a).join(' · ');
  const reason = escHtml(p.rejectReason || '');
  const submitter = escHtml(item.by || '未知用户');
  const submittedAt = item.submittedAt ? escHtml(new Date(item.submittedAt).toLocaleString('zh-CN', { hour12: false })) : '—';
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>群管审核 · ${escHtml(groupName)}</title>
<style>
body{margin:0;padding:16px;background:#f5f7fb;color:#0f172a;font:14px/1.7 -apple-system,"Microsoft YaHei",sans-serif}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:14px;margin:0 0 12px}
h1{font-size:18px;margin:0 0 4px}h2{font-size:14px;margin:0 0 8px}
.sub{color:#64748b;font-size:12px;margin:0 0 12px}
.kv{display:grid;grid-template-columns:96px 1fr;gap:5px 10px;font-size:12.5px;margin:0}
.kv dt{color:#64748b}.kv dd{margin:0;word-break:break-all}
.preview{margin:8px 0 2px;padding:10px 12px;border:1px dashed #cbd5e1;border-radius:10px;background:#fbfdff;font-size:13px;line-height:1.8;overflow-wrap:anywhere}
.preview h1,.preview h2,.preview h3{margin:8px 0 4px;font-size:15px}.preview p{margin:6px 0}
.preview blockquote{margin:6px 0;padding:2px 10px;border-left:3px solid #e2e8f0;color:#475569}
.preview img{max-width:100%;border-radius:8px}.preview hr{border:0;border-top:1px solid #e2e8f0;margin:8px 0}
.preview .tag{display:inline-block;padding:1px 7px;border-radius:999px;background:#eef2ff;color:#1d4ed8;font-weight:600;font-size:12px}
.decision{display:flex;gap:10px;margin:12px 0 10px}
.choice{flex:1;padding:12px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;font:inherit;cursor:pointer;font-weight:700;color:#475569}
.choice.approve.on{border-color:#16a34a;background:#f0fdf4;color:#15803d}
.choice.reject.on{border-color:#dc2626;background:#fef2f2;color:#b91c1c}
.reason{display:block;font-size:12px;color:#64748b;margin-top:8px}
textarea{width:100%;box-sizing:border-box;min-height:64px;border:1px solid #e2e8f0;border-radius:9px;padding:8px 10px;font:inherit;margin-top:4px;resize:vertical}
.hint{color:#64748b;font-size:12px;margin:8px 0 0}
</style></head><body>
<div class="card">
  <h1>群管设置审核 · ${escHtml(groupName)}</h1>
  <p class="sub">提交人：${submitter} · ${submittedAt} · 链接 24 小时内有效</p>
  <dl class="kv">
    <dt>群 OpenID</dt><dd>${escHtml(item.group || '')}</dd>
    <dt>进群欢迎</dt><dd>${joinOn ? '开启' : '关闭'}</dd>
    <dt>退群欢迎</dt><dd>${leaveOn ? '开启' : '关闭'}</dd>
    <dt>入群验证</dt><dd>${vOn ? '开启 · ' + (vIsArk ? '明日方舟校验' : '自定义问题') + ' · 限时 ' + Math.min(10, Math.max(1, Number(p.vVerifyExpire) || 5)) + ' 分钟' : '关闭'}</dd>
    ${vOn && !vIsArk
      ? `<dt>验证问题</dt><dd>${escHtml(p.vVerifyQuestion || '（未填）')}</dd><dt>验证答案</dt><dd>${escHtml(vAnswerText || '（未填）')}</dd>`
      : ''}
    <dt>入群申请</dt><dd>${p.jEnabled === '1' ? '开启' : '关闭'} · ${escHtml(modeLabel)}</dd>
    <dt>群管</dt><dd>${p.gEnabled === '1' ? '开启' : '关闭'} · ${escHtml(actionLabel)} · 禁言 ${escHtml(p.muteSeconds || 600)} 秒</dd>
    <dt>违禁词</dt><dd>${escHtml(p.bannedWords || '（未填）')}</dd>
    <dt>入群拒绝理由</dt><dd>${reason || '（未填）'}</dd>
  </dl>
</div>
${joinOn || leaveOn
    ? `<div class="card">
  ${joinOn ? '<h2>进群模板成品</h2><div class="preview" id="pvJoin"></div>' : ''}
  ${leaveOn ? '<h2 style="margin-top:14px">退群模板成品</h2><div class="preview" id="pvLeave"></div>' : ''}
</div>`
    : '<div class="card"><p class="hint">提交时进群 / 退群欢迎都是关闭的，不显示模板。</p></div>'}
<div class="card">
  <h2>审核结果</h2>
  <div class="decision">
    <button type="button" class="choice approve on" data-decision="approve">通过</button>
    <button type="button" class="choice reject" data-decision="reject">拒绝</button>
  </div>
  <input type="hidden" name="decision" id="decision" value="approve">
  <label class="reason">拒绝理由（选择拒绝时填写，会私聊给提交人）
    <textarea name="reason" id="reason" maxlength="200" placeholder="例如：入群模板不符合群规，请修改后重新提交。"></textarea>
  </label>
  <p class="hint">选择后，点页面底部「保存并关闭」提交审核结果。</p>
</div>
<script>
(function () {
  var DATA = ${data};
  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function md(src) {
    var s = String(src || '');
    var chips = [];
    s = s.replace(/<qqbot-at-user\\s+id="([^"]*)"\\s*\\/>/g, function () { chips.push('<span class="tag">@用户</span>'); return '\\u0000' + (chips.length - 1) + '\\u0000'; });
    s = s.replace(/<qqbot-at-everyone\\s*\\/>/g, function () { chips.push('<span class="tag">@全体成员</span>'); return '\\u0000' + (chips.length - 1) + '\\u0000'; });
    s = s.replace(/<qqbot-cmd-(?:input|enter)([^>]*)\\/>/g, function (m, attrs) {
      var show = /show="([^"]*)"/.exec(attrs), text = /text="([^"]*)"/.exec(attrs);
      var label = show ? show[1] : text ? text[1] : '指令';
      try { label = decodeURIComponent(label); } catch (e) {}
      chips.push('<span class="tag">' + esc(label) + '</span>');
      return '\\u0000' + (chips.length - 1) + '\\u0000';
    });
    s = esc(s);
    s = s.replace(/^### (.+)$/gm, '<h3>$1</h3>').replace(/^## (.+)$/gm, '<h2>$1</h2>').replace(/^# (.+)$/gm, '<h1>$1</h1>');
    s = s.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');
    s = s.replace(/^\\s*[-*] (.+)$/gm, '<li>$1</li>');
    s = s.replace(/(<li>[\\s\\S]*?<\\/li>)(?!\\s*<li>)/g, '<ul>$1</ul>');
    s = s.replace(/\\*\\*([^*]+)\\*\\*/g, '<strong>$1</strong>');
    var bt = String.fromCharCode(96);
    s = s.replace(new RegExp(bt + '([^' + bt + ']+)' + bt, 'g'), '<code>$1</code>');
    s = s.replace(/!\\[([^\\]]*)\\]\\((https?:[^)\\s]+)\\)/g, '<img alt="$1" src="$2">');
    s = s.replace(/\\[([^\\]]+)\\]\\((https?:[^)\\s]+)\\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>');
    s = s.replace(/^\\*{3,}$/gm, '<hr>');
    s = s.replace(/\\n{2,}/g, '</p><p>').replace(/\\n/g, '<br>');
    s = '<p>' + s + '</p>';
    chips.forEach(function (h, i) { s = s.replace('\\u0000' + i + '\\u0000', h); });
    return s;
  }
  function vars(tpl) {
    return String(tpl || '')
      .replace(/\\{group\\}/g, DATA.group)
      .replace(/\\{member\\}/g, '小明')
      .replace(/\\{time\\}/g, new Date().toLocaleString('zh-CN', { hour12: false }))
      .replace(/\\{cmd_menu\\}/g, '菜单')
      .replace(/\\{cmd_groupadmin\\}/g, '群管')
      .replace(/\\{cmd_[a-z_]+\\}/g, '指令');
  }
  var pvJoin = document.getElementById('pvJoin');
  if (pvJoin) pvJoin.innerHTML = md(vars(DATA.join));
  var pvLeave = document.getElementById('pvLeave');
  if (pvLeave) pvLeave.innerHTML = md(vars(DATA.leave));
  var hidden = document.getElementById('decision');
  var reason = document.getElementById('reason');
  document.querySelectorAll('[data-decision]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      hidden.value = btn.getAttribute('data-decision');
      document.querySelectorAll('[data-decision]').forEach(function (b) { b.classList.toggle('on', b === btn); });
      if (hidden.value === 'reject') reason.focus();
    });
  });
})();
</script>
</body></html>`;
}

/** 管理员审核链接：创建 24h callback 页面并私聊给所有管理员 */
async function notifyReviewAdmins(r, item) {
  if (!item || item.reviewId || item.status !== 'submitted') return;
  if (r?.cfg?.adminNotify === false || r?.cfg?.groupAdmin?.adminNotify === false) {
    r.log.warn('VloS 群管审核通知已关闭（adminNotify=false），仅写入待审核列表');
    return;
  }
  const admins = [...new Set((Array.isArray(r.cfg.groupAdmin?.adminOpenids) ? r.cfg.groupAdmin.adminOpenids : []).map(String).filter(Boolean))].slice(0, 20);
  if (!admins.length) {
    r.log.warn(`VloS 群管审核：管理员 OpenID 未配置，跳过通知 group=${item.group}`);
    return;
  }
  let created;
  try {
    created = await r.jl.callbackCreate({
      title: `群管审核 · ${item.groupName || item.group || ''}`.slice(0, 100),
      html: buildReviewHtml(r, item),
      expiresMinutes: 1440,
      requireLogin: false,
    });
  } catch (e) {
    r.log.warn('VloS 群管审核链接创建失败：' + friendlyError(e));
    return;
  }
  if (!created?.id || !created?.url) {
    r.log.warn('VloS 群管审核链接创建失败：接口没有返回 url');
    return;
  }
  const data = loadCallbacks(r);
  const target = data.items[item.id];
  if (!target) return;
  target.reviewId = String(created.id);
  target.reviewUrl = String(created.url);
  target.reviewExpiresAt = Number(created.expiresAt) || Date.now() + 24 * 60 * 60 * 1000;
  target.reviewStatus = 'awaiting';
  target.reviewRequestedAt = Date.now();
  saveCallbacks(r, data);
  startCallbackPolling(r);

  const text = [
    '【群管设置审核】',
    `群：${item.groupName || item.group || ''}`,
    `提交人：${item.by || '未知用户'}`,
    '链接 24 小时内有效，打开后可查看成品并通过或拒绝：',
    String(created.url),
  ].join('\n');
  let sent = 0;
  for (const openid of admins) {
    try {
      const res = await r.bot?.sendC2C?.(openid, { msg_type: 0, content: text });
      if (res?.ok) sent++;
      else r.log.warn(`VloS 群管审核私聊失败 openid=${openid}：${res?.message || res?.code || 'unknown'}`);
    } catch (e) {
      r.log.warn(`VloS 群管审核私聊异常 openid=${openid}：${e?.message || e}`);
    }
  }
  target.reviewNotify = { sent, total: admins.length, at: Date.now() };
  saveCallbacks(r, data);
  r.log.info(`VloS 群管审核链接已发送 ${sent}/${admins.length} group=${item.group} id=${target.reviewId}`);
}

/** 把 payload 应用为群设置覆盖（与设置页「通过并保存」一致） */
function applyReviewPayload(r, item) {
  const p = item.payload || {};
  const vSlots = [1, 2, 3, 4]
    .map((i) => String(p['vVerifyAnswer' + i] || '').trim())
    .filter(Boolean)
    .slice(0, 4);
  const picked = String(p['vVerifyAnswer' + (Number(p.vVerifyCorrect) || 1)] || '').trim();
  const correctIndex = Math.max(0, vSlots.indexOf(picked));
  r.cfg.groups = r.cfg.groups || {};
  r.cfg.groups[item.group] = {
    name: item.groupName || '',
    reviewStatus: 'approved',
    updatedAt: Date.now(),
    welcome: {
      memberJoin: { enabled: p.wJoinEnabled === '1', template: p.wJoinTpl || r.cfg.welcome.memberJoin.template || '' },
      memberLeave: { enabled: p.wLeaveEnabled === '1', template: p.wLeaveTpl || r.cfg.welcome.memberLeave.template || '' },
      joinVerify: {
        enabled: p.vVerifyEnabled === '1',
        mode: p.vVerifyMode === 'arknights' ? 'arknights' : 'custom',
        question: String(p.vVerifyQuestion || '').trim().slice(0, 300),
        answers: vSlots,
        correctIndex,
        maxAttempts: Math.min(10, Math.max(1, Number(p.vVerifyMax) || 3)),
        expiresMinutes: Math.min(10, Math.max(1, Number(p.vVerifyExpire) || 5)),
        passText: r.cfg.welcome.joinVerify?.passText || DEFAULT_CONFIG.welcome.joinVerify.passText,
        failText: r.cfg.welcome.joinVerify?.failText || DEFAULT_CONFIG.welcome.joinVerify.failText,
        kickText: r.cfg.welcome.joinVerify?.kickText || DEFAULT_CONFIG.welcome.joinVerify.kickText,
      },
    },
    guard: {
      enabled: p.gEnabled === '1',
      bannedWords: String(p.bannedWords || '').split(/[\n,，、;；]+/).map((s) => s.trim()).filter(Boolean).slice(0, 200),
      action: p.gAction || 'recall',
      muteSeconds: Number(p.muteSeconds) || 600,
      join: {
        enabled: p.jEnabled === '1',
        mode: p.joinMode || 'manual',
        rejectReason: p.rejectReason || '',
        qaKeywords: String(p.joinKeywords || '').split(/[\n,，、;；]+/).map((s) => s.trim()).filter(Boolean).slice(0, 100),
        qaFallback: p.joinFallback === 'manual' ? 'manual' : 'decline',
      },
    },
  };
}

/** 文本归一：统一换行符、去首尾空白（页面 textarea 提交的是 LF，老配置里可能有 CRLF） */
function normText(v) {
  return String(v == null ? '' : v).replace(/\r\n?/g, '\n').trim();
}

/** 把提交 payload 归一成可比较的结构（字段取值与 applyReviewPayload 落盘结果一致） */
function submissionShape(r, p) {
  const payload = p || {};
  const splitList = (v) => String(v || '').split(/[\n,，、;；]+/).map((s) => s.trim()).filter(Boolean);
  const vSlots = [1, 2, 3, 4].map((i) => String(payload['vVerifyAnswer' + i] || '').trim()).filter(Boolean).slice(0, 4);
  const pick = String(payload['vVerifyAnswer' + (Number(payload.vVerifyCorrect) || 1)] || '').trim();
  return {
    welcome: {
      memberJoin: { enabled: payload.wJoinEnabled === '1', template: normText(payload.wJoinTpl || (r.cfg.welcome.memberJoin && r.cfg.welcome.memberJoin.template) || '') },
      memberLeave: { enabled: payload.wLeaveEnabled === '1', template: normText(payload.wLeaveTpl || (r.cfg.welcome.memberLeave && r.cfg.welcome.memberLeave.template) || '') },
      joinVerify: {
        enabled: payload.vVerifyEnabled === '1',
        mode: payload.vVerifyMode === 'arknights' ? 'arknights' : 'custom',
        question: normText(payload.vVerifyQuestion),
        answers: vSlots,
        correctIndex: Math.max(0, vSlots.indexOf(pick)),
        maxAttempts: Math.min(10, Math.max(1, Number(payload.vVerifyMax) || 3)),
        expiresMinutes: Math.min(10, Math.max(1, Number(payload.vVerifyExpire) || 5)),
      },
    },
    guard: {
      enabled: payload.gEnabled === '1',
      bannedWords: splitList(payload.bannedWords).sort(),
      action: payload.gAction || 'recall',
      muteSeconds: Number(payload.muteSeconds) || 600,
      join: {
        enabled: payload.jEnabled === '1',
        mode: payload.joinMode || 'manual',
        rejectReason: normText(payload.rejectReason),
        qaKeywords: splitList(payload.joinKeywords).sort(),
        qaFallback: payload.joinFallback === 'manual' ? 'manual' : 'decline',
      },
    },
  };
}

/** 本群「已通过」的自定义覆盖，归一成与 submissionShape 相同的结构；没有则返回 null */
function approvedOverrideShape(r, group) {
  const o = r.cfg.groups && r.cfg.groups[group];
  if (!o || o.reviewStatus !== 'approved' || !o.welcome) return null;
  const jv = o.welcome.joinVerify || {};
  const answers = (Array.isArray(jv.answers) ? jv.answers : []).map((a) => String(a || '').trim()).filter(Boolean);
  const gj = (o.guard && o.guard.join) || {};
  return {
    welcome: {
      memberJoin: { enabled: !!(o.welcome.memberJoin && o.welcome.memberJoin.enabled), template: normText(o.welcome.memberJoin && o.welcome.memberJoin.template) },
      memberLeave: { enabled: !!(o.welcome.memberLeave && o.welcome.memberLeave.enabled), template: normText(o.welcome.memberLeave && o.welcome.memberLeave.template) },
      joinVerify: {
        enabled: !!jv.enabled,
        mode: jv.mode === 'arknights' ? 'arknights' : 'custom',
        question: normText(jv.question),
        answers,
        correctIndex: Math.min(Math.max(0, Number(jv.correctIndex) || 0), Math.max(0, answers.length - 1)),
        maxAttempts: Math.min(10, Math.max(1, Number(jv.maxAttempts) || 3)),
        expiresMinutes: Math.min(10, Math.max(1, Number(jv.expiresMinutes) || 5)),
      },
    },
    guard: {
      enabled: !!(o.guard && o.guard.enabled),
      bannedWords: ((o.guard && o.guard.bannedWords) || []).map((x) => String(x || '').trim()).filter(Boolean).sort(),
      action: (o.guard && o.guard.action) || 'recall',
      muteSeconds: Number((o.guard && o.guard.muteSeconds) || 600),
      join: {
        enabled: !!gj.enabled,
        mode: gj.mode || 'manual',
        rejectReason: normText(gj.rejectReason),
        qaKeywords: (gj.qaKeywords || []).map((x) => String(x || '').trim()).filter(Boolean).sort(),
        qaFallback: gj.qaFallback === 'manual' ? 'manual' : 'decline',
      },
    },
  };
}

/** 深度比较（数组顺序敏感，词库 / 关键词在 shape 里已排序） */
function shapesEqual(a, b) {
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => shapesEqual(x, b[i]));
  }
  if (a && b && typeof a === 'object' && typeof b === 'object') {
    const ka = Object.keys(a);
    const kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    return ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && shapesEqual(a[k], b[k]));
  }
  return a === b;
}

/** 取入群验证的内容部分（不含 enabled），用于和全局 / 已通过版本比较 */
function verifyContent(v) {
  const o = v || {};
  const answers = (Array.isArray(o.answers) ? o.answers : []).map((a) => normText(a)).filter(Boolean);
  return {
    mode: o.mode === 'arknights' ? 'arknights' : 'custom',
    question: normText(o.question),
    answers,
    correctIndex: Math.min(Math.max(0, Number(o.correctIndex) || 0), Math.max(0, answers.length - 1)),
    maxAttempts: Math.min(10, Math.max(1, Number(o.maxAttempts) || 3)),
    expiresMinutes: Math.min(10, Math.max(1, Number(o.expiresMinutes) || 5)),
  };
}

/**
 * 这次提交是否不需要审核（只看进退群：入群欢迎 / 退群提示 / 入群验证）：
 * - 关闭某项功能；
 * - 开启的功能内容与「全局」或「本群已通过的自定义」任一一致——两者可以混着用，
 *   例如欢迎模板沿用已通过版本、入群验证内容用全局的；
 * - 群管部分（是否启用违禁词、词库、动作、禁言、处理入群申请）不在检查范围内，改了也自动通过。
 * 只有开启的进退群内容两边都对不上才需要管理员审核。
 */
function autoApprovable(r, p, group) {
  const payload = p || {};
  const sub = submissionShape(r, payload);
  const gw = r.cfg.welcome || {};
  const cur = group ? approvedOverrideShape(r, group) : null;

  const tplOk = (val, globalTpl, curTpl) => val === normText(globalTpl) || (!!cur && val === curTpl);
  const verifyOk = (v) => shapesEqual(v, verifyContent(gw.joinVerify)) || (!!cur && shapesEqual(v, verifyContent(cur.welcome.joinVerify)));

  if (sub.welcome.memberJoin.enabled && !tplOk(sub.welcome.memberJoin.template, gw.memberJoin && gw.memberJoin.template, cur && cur.welcome.memberJoin.template)) return false;
  if (sub.welcome.memberLeave.enabled && !tplOk(sub.welcome.memberLeave.template, gw.memberLeave && gw.memberLeave.template, cur && cur.welcome.memberLeave.template)) return false;
  if (sub.welcome.joinVerify.enabled && !verifyOk(verifyContent(sub.welcome.joinVerify))) return false;
  return true;
}

/** 自动通过：写本群覆盖 + 记录审核结果（提交时和待审核回溯都用这个） */
function applyAutoApproval(r, item) {
  applyReviewPayload(r, item);
  r.cfg.callbackReviews = r.cfg.callbackReviews || {};
  r.cfg.callbackReviews[item.id] = { status: 'approved', at: Date.now(), auto: true };
  item.status = 'auto_approved';
  item.reviewStatus = 'approved';
  item.reviewedAt = Date.now();
}

/** 让面板内存里的 manifest.config 立即跟上插件运行时的 groups / callbackReviews */
function syncRuntimeConfig(r) {
  try {
    if (!r?.rawConfig || typeof r.rawConfig !== 'object') return;
    r.rawConfig.groups = r.cfg.groups || {};
    r.rawConfig.callbackReviews = r.cfg.callbackReviews || {};
  } catch {
    /* ignore */
  }
}

/** 直接写回 plugin.json 的 groups / callbackReviews，插件下次重载仍然生效 */
function persistReviewConfig(r) {
  try {
    const file = path.join(r.dir, 'plugin.json');
    const manifest = JSON.parse(fs.readFileSync(file, 'utf8'));
    manifest.config = manifest.config || {};
    manifest.config.groups = r.cfg.groups || {};
    manifest.config.callbackReviews = r.cfg.callbackReviews || {};
    fs.writeFileSync(file, JSON.stringify(manifest, null, 2), 'utf8');
  } catch (e) {
    r.log.warn('VloS 审核结果写回 plugin.json 失败：' + (e?.message || e));
  }
}

/** 处理管理员在审核页的选择；返回是否成功应用 */
function applyAdminReview(r, item, payload) {
  const decision = String(payload?.decision || '').toLowerCase();
  if (decision !== 'approve' && decision !== 'reject') return false;
  if (decision === 'approve') {
    applyReviewPayload(r, item);
    r.cfg.callbackReviews = r.cfg.callbackReviews || {};
    r.cfg.callbackReviews[item.id] = { status: 'approved', at: Date.now() };
  } else {
    r.cfg.callbackReviews = r.cfg.callbackReviews || {};
    r.cfg.callbackReviews[item.id] = {
      status: 'rejected',
      at: Date.now(),
      reason: String(payload?.reason || '').trim().slice(0, 200),
    };
  }
  syncRuntimeConfig(r);
  persistReviewConfig(r);
  r.log.info(`VloS 群管审核已通过管理员页面 ${decision} group=${item.group} id=${item.id}`);
  return true;
}

async function sendPrivate(r, openids, text) {
  // 这是插件里唯一的主动消息路径（管理员审核通知/链接），可在 plugin.json 设 "adminNotify": false 关闭
  if (r?.cfg?.adminNotify === false) return false;
  const list = [...new Set((Array.isArray(openids) ? openids : []).map(String).filter(Boolean))].slice(0, 6);
  if (!r?.bot || typeof r.bot.sendC2C !== 'function' || !list.length) return false;
  for (const openid of list) {
    try {
      const res = await r.bot.sendC2C(openid, { msg_type: 0, content: text });
      if (res?.ok) return true;
    } catch {
      /* 试下一个 */
    }
  }
  return false;
}

function reviewNoticeText(r, rev) {
  if (rev.status === 'approved') {
    return rev.auto
      ? r.cfg.groupAdmin.autoApproveMessage || '您的群管设置申请已自动通过（只关闭功能或与全局一致），已在本群生效。'
      : r.cfg.groupAdmin.approveMessage;
  }
  const base = r.cfg.groupAdmin.rejectMessage;
  return rev.reason ? `${base}\n本次拒绝原因：${rev.reason}` : base;
}

/** 审核结果私聊通知；失败最多重试 3 次（下次插件重载时继续） */
async function processReviewedCallbacks(r) {
  const data = loadCallbacks(r);
  let changed = false;
  for (const [id, item] of Object.entries(data.items)) {
    const rev = r.cfg.callbackReviews?.[id];
    if (!rev) continue;
    const ok = await sendPrivate(r, item.notifyOpenids, reviewNoticeText(r, rev));
    if (ok) {
      r.log.info(`VloS 群管审核提示已私聊 id=${id} status=${rev.status}`);
      delete data.items[id];
    } else {
      item.notifyAttempts = (Number(item.notifyAttempts) || 0) + 1;
      r.log.warn(`VloS 群管审核提示私聊失败 id=${id} status=${rev.status}（第 ${item.notifyAttempts} 次）`);
      if (item.notifyAttempts >= 3) delete data.items[id];
    }
    changed = true;
  }
  if (changed) saveCallbacks(r, data);
}

function startCallbackPolling(r) {
  if (callbackTimer) clearInterval(callbackTimer);
  callbackTimer = null;
  const tick = () => pollCallbacks(r).catch((e) => r.log.warn('VloS 空白回调轮询失败：' + (e?.message || e)));
  const first = setTimeout(tick, 2500);
  if (first.unref) first.unref();
  callbackTimer = setInterval(tick, 20000);
  if (callbackTimer.unref) callbackTimer.unref();
}

async function notifyPendingReviewAdmins(r) {
  const data = loadCallbacks(r);
  for (const item of Object.values(data.items)) {
    if (item.status === 'submitted' && !item.reviewId && !item.reviewRequestedAt) {
      await notifyReviewAdmins(r, item);
    }
  }
}

async function pollCallbacks(r) {
  if (callbackPolling) return;
  callbackPolling = true;
  try {
    const data = loadCallbacks(r);
    const now = Date.now();
    let changed = false;
    let active = 0;
    let decided = false;
    const submittedNow = [];
    const autoApproved = [];
    for (const item of Object.values(data.items)) {
      // 管理员审核链接
      if (item.reviewId && item.reviewStatus === 'awaiting') {
        if (item.reviewExpiresAt && item.reviewExpiresAt < now) {
          item.reviewStatus = 'expired';
          changed = true;
        } else {
          active++;
          let rres;
          try {
            rres = await r.jl.callbackResult(item.reviewId);
          } catch {
            rres = null;
          }
          const rcb = rres?.callback;
          if (rcb && rcb.status === 'submitted') {
            item.reviewStatus = 'submitted';
            item.reviewSubmittedAt = Number(rcb.submittedAt) || Date.now();
            if (applyAdminReview(r, item, rcb.payload || {})) {
              item.status = 'reviewed';
              item.reviewedAt = Date.now();
              decided = true;
            } else {
              item.reviewStatus = 'invalid';
              r.log.warn(`VloS 群管审核结果无效 group=${item.group} id=${item.id}`);
            }
            changed = true;
          }
        }
      }

      // 之前已经提交、还挂在「待审核」里的条目：按最新规则再判一次，可自动通过的直接生效
      if (
        item.status === 'submitted' &&
        item.payload &&
        !(r.cfg.callbackReviews && r.cfg.callbackReviews[item.id]) &&
        autoApprovable(r, item.payload, item.group)
      ) {
        applyAutoApproval(r, item);
        changed = true;
        autoApproved.push(item);
        r.log.info(`VloS 群管待审核项按新规则自动通过 group=${item.group} id=${item.id}`);
        continue;
      }

      if (item.status !== 'awaiting') continue;
      if (item.expiresAt && item.expiresAt < now) {
        item.status = 'expired';
        changed = true;
        continue;
      }
      active++;
      let res;
      try {
        res = await r.jl.callbackResult(item.id);
      } catch {
        continue; // Key 没权限 / 网络异常：下一轮再试
      }
      const cb = res?.callback;
      if (cb && cb.status === 'submitted') {
        // 同群已有待审核：保留先提交的那份，后来的直接忽略（/群管 入口也会拦住）
        const existing = Object.values(data.items).find(
          (other) => other !== item && other.group === item.group && other.status === 'submitted',
        );
        if (existing) {
          item.status = 'duplicate';
          item.payload = cb.payload || {};
          item.submittedAt = Number(cb.submittedAt) || Date.now();
          changed = true;
          r.log.warn(`VloS 群管重复提交已忽略 group=${item.group} 保留 id=${existing.id} 新 id=${item.id}`);
          continue;
        }
        // 只关闭功能 / 与全局或已通过版本一致：不用管理员审核，直接写入本群覆盖
        if (autoApprovable(r, cb.payload || {}, item.group)) {
          item.payload = cb.payload || {};
          item.submittedAt = Number(cb.submittedAt) || Date.now();
          item.user = cb.user ? { name: cb.user.name || '', email: cb.user.email || '', avatar: cb.user.avatar || '' } : null;
          applyAutoApproval(r, item);
          changed = true;
          autoApproved.push(item);
          r.log.info(`VloS 群管设置自动通过（只关闭功能或与全局/已通过版本一致）group=${item.group} id=${item.id}`);
          continue;
        }
        item.status = 'submitted';
        item.payload = cb.payload || {};
        item.submittedAt = Number(cb.submittedAt) || Date.now();
        item.user = cb.user ? { name: cb.user.name || '', email: cb.user.email || '', avatar: cb.user.avatar || '' } : null;
        changed = true;
        submittedNow.push(item);
        r.log.info(`VloS 群管设置已提交，等待审核 group=${item.group} id=${item.id}`);
      }
    }
    if (changed) {
      saveCallbacks(r, data);
      refreshReviewSnapshot(r);
    }
    if (autoApproved.length) {
      // 自动通过也要落盘 + 私聊告诉提交人，面板里的 groups 才能马上看到
      syncRuntimeConfig(r);
      persistReviewConfig(r);
      await processReviewedCallbacks(r);
      refreshReviewSnapshot(r);
    }
    for (const item of submittedNow) await notifyReviewAdmins(r, item);
    if (decided) {
      await processReviewedCallbacks(r);
      refreshReviewSnapshot(r);
    }
    if (!active && callbackTimer) {
      clearInterval(callbackTimer);
      callbackTimer = null;
    }
  } finally {
    callbackPolling = false;
  }
}

function reviewSnapshot(r) {
  const data = loadCallbacks(r);
  const items = Object.values(data.items)
    .filter((it) => it.status === 'submitted' && !(r.cfg.callbackReviews && r.cfg.callbackReviews[it.id]))
    .sort((a, b) => (Number(b.submittedAt) || 0) - (Number(a.submittedAt) || 0))
    .slice(0, 50)
    .map((it) => ({
      id: it.id,
      group: it.group,
      groupName: it.groupName || '',
      by: it.by || '',
      byAvatar: it.byAvatar || '',
      createdAt: it.createdAt || 0,
      submittedAt: it.submittedAt || 0,
      user: it.user || null,
      payload: it.payload || {},
    }));
  return { at: Date.now(), items, groups: r.cfg.groups || {} };
}

function refreshReviewSnapshot(r) {
  try {
    const file = path.join(r.dir, 'settings.html');
    let html = fs.readFileSync(file, 'utf8');
    const i = html.indexOf(CALLBACKS_SNAPSHOT_START);
    const j = html.indexOf(CALLBACKS_SNAPSHOT_END);
    if (i < 0 || j < i) return false;
    const data = JSON.stringify(reviewSnapshot(r)).replace(/</g, '\\u003c');
    const block = `${CALLBACKS_SNAPSHOT_START}\n<script id="vlos-callbacks-data" type="application/json">${data}</script>\n${CALLBACKS_SNAPSHOT_END}`;
    html = html.slice(0, i) + block + html.slice(j + CALLBACKS_SNAPSHOT_END.length);
    fs.writeFileSync(file, html, 'utf8');
    return true;
  } catch (e) {
    if (r?.log?.warn) r.log.warn('VloS 审核快照写入失败：' + (e?.message || e));
    return false;
  }
}

const CALLBACKS_SNAPSHOT_START = '<!-- VLOS_CALLBACKS_START -->';
const CALLBACKS_SNAPSHOT_END = '<!-- VLOS_CALLBACKS_END -->';

/* ======================= 群管 / 进退群 ======================= */

/** 常见 QQ 接口错误的排查提示（拼在失败日志后面，方便直接定位） */
function qqApiFailHint(code, message) {
  const s = String(code || '') + ' ' + String(message || '');
  if (/11298|白名单/.test(s)) return '（当前公网 IP 不在机器人白名单，去 QQ 开放平台加 IP）';
  if (/40054005|过期|不存在/.test(s)) return '（QQ 只允许撤回 2 分钟内的消息）';
  if (/403|无权限|权限不足|管理员|not admin/i.test(s)) return '（机器人需要是群管理员，且已开通群消息权限）';
  if (/TOKEN_ERROR|appid|secret/i.test(s)) return '（机器人 AppSecret 无效，先修网关鉴权）';
  return '';
}

/** 入群验证踢人失败的排查提示（QQ 群接口） */
function kickFailHint(res) {
  const code = String(res?.code || '');
  const msg = String(res?.message || '');
  if (code === '40103012' || /群主已经关闭操作权限/.test(msg)) {
    return '群主关闭了机器人的成员管理权限，请在群设置 → 群机器人 / 群管理中给机器人开启操作权限';
  }
  if (/40103012|403|无权限|权限不足|管理员|not admin|not authorized/i.test(code + ' ' + msg)) {
    return '机器人不是群管理员或没有成员管理权限，请先给机器人管理员权限';
  }
  if (/成员不存在|not exist|not found|member.*invalid/i.test(msg)) return '成员可能已经退群';
  return '';
}

/**
 * 调 QQ 接口并把结果写进日志（成功/失败都写）。
 * 框架的 ctx.api.call 失败时是返回 { ok:false, code, message } 而不是抛异常，
 * 所以必须自己判断 ok，否则会出现「日志说已禁言、实际撤回失败」这种误导。
 */
async function callQqApi(ctx, r, key, args, label) {
  const t0 = Date.now();
  try {
    const res = await ctx.api.call(key, args);
    const ms = Date.now() - t0;
    const ok = res?.ok !== false;
    const code = res?.code || res?.error?.code || '';
    const message = res?.message || res?.error?.message || '';
    if (ok) {
      r.log.info(`VloS 接口 ${key} ${label} 成功（${ms}ms）`);
    } else {
      r.log.warn(`VloS 接口 ${key} ${label} 失败（${ms}ms）code=${code} message=${message}${qqApiFailHint(code, message)}`);
    }
    return { ok, res, code, message, ms };
  } catch (e) {
    const ms = Date.now() - t0;
    r.log.warn(`VloS 接口 ${key} ${label} 异常（${ms}ms）：${e?.message || e}`);
    return { ok: false, res: null, code: '', message: e?.message || String(e), ms, threw: true };
  }
}

/** 群消息命中违禁词：撤回 / 撤回并禁言 / 只警告。返回 true 表示已处理，不再走指令流程。 */
async function guardGroupMessage(ctx, r, m, raw) {
  const g = effectiveGuard(r, m.group_openid);
  if (!g.enabled || !g.bannedWords.length) return false;
  const text = String(raw || '').toLowerCase();
  const hit = g.bannedWords.find((w) => w && text.includes(w.toLowerCase()));
  if (!hit) return false;

  const group = m.group_openid;
  try {
    if (!ctx.api || typeof ctx.api.call !== 'function') throw new Error('没有可用的 QQ 接口');
    let recallInfo = '';
    let muteInfo = '';
    if (g.action !== 'warn') {
      const rr = await callQqApi(ctx, r, 'recall_group_message', { params: { group_openid: group, message_id: m.id } }, `撤回 message_id=${m.id}`);
      recallInfo = rr.ok ? '已撤回' : `撤回失败(code=${rr.code || '?'} ${rr.message || ''})`.trim();
    }
    if (g.action === 'recall_mute') {
      if (!m.author?.member_openid) {
        muteInfo = '跳过禁言（缺少 member_openid）';
        r.log.warn(`VloS 违禁词命中但拿不到 member_openid，无法禁言 group=${group} user=${m.author?.id || ''}`);
      } else {
        const expire = new Date(Date.now() + g.muteSeconds * 1000 + 8 * 3600 * 1000)
          .toISOString()
          .replace('Z', '+08:00');
        const mr = await callQqApi(
          ctx,
          r,
          'restrict_chat_set',
          {
            params: { group_openid: group },
            body: { members: [{ op: 'add', member_openid: m.author.member_openid, mute_expire_at: expire }] },
          },
          `禁言 ${g.muteSeconds} 秒 member=${m.author.member_openid}`,
        );
        muteInfo = mr.ok ? `已禁言 ${g.muteSeconds} 秒` : `禁言失败(code=${mr.code || '?'} ${mr.message || ''})`.trim();
      }
    }
    if (g.action === 'warn') {
      // 被动回复当前违规消息，不走主动消息
      const body = { msg_type: 2, markdown: { content: normalizeQqMarkdown('> 请勿发送违禁内容，共同维护群聊环境。') } };
      if (ctx.bot?.reply) {
        const wr = await ctx.bot.reply(m, body);
        recallInfo = wr && wr.ok === false ? `提醒发送失败(code=${wr.code || '?'})` : '已发送提醒';
      } else r.log.warn('VloS 违禁词提醒未发送：没有被动回复上下文（不发主动消息）');
    }
    r.log.info(
      `VloS 违禁词命中 group=${group} user=${m.author?.member_openid || ''} word=${hit} action=${g.action}` +
        `${recallInfo ? ' · ' + recallInfo : ''}${muteInfo ? ' · ' + muteInfo : ''}`,
    );
  } catch (e) {
    r.log.warn(`VloS 违禁词处理失败：${e?.message || e}`);
  }
  return true;
}

/**
 * 判断入群申请的答案是否通过：
 * GROUP_JOIN_REQUEST 的 verify_info 会带 verify_message，或 admin_review_qa 的 review_qa_list。
 * 命中任一关键词即通过；问题本身要在 QQ 群设置里由群主/管理员配置，机器人 API 只负责读答案和审批。
 */
function judgeJoinRequest(raw, joinCfg) {
  const info = raw?.verify_info || {};
  const answers = [];
  if (info.verify_message) answers.push(String(info.verify_message));
  if (Array.isArray(info.review_qa_list)) {
    for (const q of info.review_qa_list) if (q && q.answer) answers.push(String(q.answer));
  }
  const text = answers.join('\n').toLowerCase();
  const kws = Array.isArray(joinCfg?.qaKeywords) ? joinCfg.qaKeywords : [];
  const hit = kws.find((k) => k && text.includes(String(k).toLowerCase()));
  return { ok: !!hit, keyword: hit || '', hasAnswer: answers.length > 0, method: info.method || '' };
}

/** 欢迎语发送失败时的排查提示（按官方错误码） */
function welcomeFailHint(res) {
  const code = String(res?.code || '');
  if (code === '40034105') return '（机器人没有群主动消息权限：到 QQ 开放平台开通/申请主动消息能力）';
  if (code === '40034100') return '（主动消息触发频控：每个群每天最多 1000 条，降低频率）';
  if (code === '40034101' || code === '40054003') return '（机器人不是群成员，检查是否被移出群）';
  if (code === '40034027') return '（event_id 被服务端拒绝，已自动降级主动消息；若仍失败看主动消息权限）';
  if (code === '40054005') return '（消息被去重：同一 msg_seq 重复发送）';
  return '';
}

/** 群成员加入 / 退出、机器人进群、入群申请：这些事件没有 message，从 ctx.raw 取字段。 */
async function handleJoinVerifyMessage(ctx, r, m, raw) {
  if (!m || m.kind !== 'group') return false;
  const group = String(m.group_openid || '');
  const member = String(m.author?.member_openid || '');
  if (!group || !member) return false;
  const key = `${group}:${member}`;
  const entry = joinVerifyPending.get(key);
  if (!entry) return false;
  if (entry.expiresAt && entry.expiresAt < Date.now()) {
    // 已超时：走「提示 → 等 3 秒 → 移出」的统一流程（定时器可能还没轮到）
    await handleVerifyTimeout(ctx, r, group, member, entry);
    return null;
  }
  const text = String(raw || '').trim();

  if (entry.mode === 'arknights') {
    // 明日方舟校验只认按钮发来的指令，其他消息不拦
    if (!/^[/／]?(入群校验|开始校验|校验)$/i.test(text)) return false;
    const ak = arknightsApi();
    if (!ak || typeof ak.isLoggedIn !== 'function') {
      return replyMd(ctx, r, '## 校验暂不可用\n> 明日方舟插件未启用，请联系管理员。', '校验暂不可用。');
    }
    let ok = false;
    try {
      ok = !!(await Promise.resolve(ak.isLoggedIn(primaryOpenid(m))));
    } catch (e) {
      r.log.warn('VloS 入群校验调用明日方舟接口失败：' + (e?.message || e));
    }
    if (ok) {
      dropVerifyPending(key);
      return replyMd(ctx, r, '验证通过，博士！欢迎您的加入！(*´▽｀)ノノ', '验证通过，博士！欢迎您的加入！');
    }
    return replyMd(ctx, r, '校验未通过！', '校验未通过！请先私聊机器人授权鹰角网络账户，再点「开始校验」。');
  }

  // 自定义问题：默认用欢迎语下面的回调按钮判定（handleInteractionEvent）；
  // 按钮不可用时接受文字作答（含蓝字标签点出来的 `/入群验证 <答案>`），普通聊天不拦。
  if (!entry.allowText) return false;
  const answers = (Array.isArray(entry.answers) ? entry.answers : []).map((a) => String(a || '').trim());
  const mAnswer = text.match(/^[/／]?入群验证[\s\u3000]+([\s\S]+)$/);
  const candidate = String(mAnswer ? mAnswer[1] : text).trim().toLowerCase();
  const picked = answers.findIndex((a) => a && a.toLowerCase() === candidate);
  if (picked < 0) return false;
  return await judgeCustomAnswer(ctx, r, group, member, entry, picked, (md, plain) => replyMd(ctx, r, md, plain));
}

/**
 * 删除待验证记录并清掉超时定时器（通过 / 踢出 / 退群 / 过期都走这里）。
 */
function dropVerifyPending(key) {
  const cur = joinVerifyPending.get(key);
  if (cur && cur.timer) {
    clearTimeout(cur.timer);
    cur.timer = null;
  }
  joinVerifyPending.delete(key);
  return cur;
}

/** 限时到了：先发「验证超时」提示，等 3 秒再移出（和答错次数用完的处理一致） */
async function handleVerifyTimeout(ctx, r, group, member, entry) {
  const key = `${group}:${member}`;
  if (joinVerifyPending.get(key) !== entry) return null; // 已通过 / 已踢 / 已退群
  dropVerifyPending(key);
  r.log.info(`VloS 入群验证超时 group=${group} member=${member}，先提示再移出`);
  await sendWelcome(ctx, group, entry.timeoutText || '验证超时，您未在规定时间内完成验证，将被移出群聊。', { allowActive: true });
  await new Promise((resolve) => setTimeout(resolve, 3000));
  const res = await callQqApi(
    ctx,
    r,
    'batch_remove_members',
    { params: { group_openid: group }, body: { member_openids: [member] } },
    `入群验证超时移出 member=${member}`,
  );
  if (!res.ok) {
    const hint = kickFailHint(res);
    r.log.warn(`VloS 入群验证超时踢人失败 group=${group} member=${member} code=${res.code} ${res.message}${hint ? '（' + hint + '）' : ''}`);
    await sendWelcome(ctx, group, `> 自动移出失败：${hint || res.message || '未知原因'}`, { allowActive: true });
  }
  return null;
}

function scheduleVerifyTimeout(ctx, r, group, member, entry) {
  const wait = Math.max(1000, Number(entry.expiresAt || 0) - Date.now());
  const timer = setTimeout(() => {
    handleVerifyTimeout(ctx, r, group, member, entry).catch((e) => r.log.warn('VloS 入群验证超时处理异常：' + (e?.message || e)));
  }, wait);
  if (timer.unref) timer.unref();
  // 定时器不参与 JSON 序列化（避免调试 / 测试里 JSON.stringify(entry) 因 Timeout 循环引用报错）
  Object.defineProperty(entry, 'timer', { value: timer, writable: true, enumerable: false, configurable: true });
}

/**
 * 自定义问题判定：只有单选框选中的那条算对，点/答其他答案算错；
 * 超过 maxAttempts 调 batch_remove_members 踢出。
 * reply(markdown, plain) 由调用方决定走消息回复还是互动事件回复。
 */
async function judgeCustomAnswer(ctx, r, group, member, entry, pickedIndex, reply) {
  const key = `${group}:${member}`;
  const answers = Array.isArray(entry.answers) ? entry.answers : [];
  const idx = Math.min(Math.max(0, Number(entry.correctIndex) || 0), Math.max(0, answers.length - 1));
  if (Number(pickedIndex) === idx) {
    dropVerifyPending(key);
    return reply(entry.passText, entry.passText);
  }
  entry.attempts = Number(entry.attempts || 0) + 1;
  const max = Number(entry.maxAttempts) || 3;
  // 最多答错 N 次：第 N 次答错就移出（不是 N+1 次）
  if (entry.attempts >= max) {
    dropVerifyPending(key);
    // 先发「次数过多」提示，等 3 秒再移出：反过来的话人被踢了，提示他也看不到了
    const first = await reply(entry.kickText, entry.kickText);
    await new Promise((resolve) => setTimeout(resolve, 3000));
    const res = await callQqApi(
      ctx,
      r,
      'batch_remove_members',
      { params: { group_openid: group }, body: { member_openids: [member] } },
      `入群验证失败移出 member=${member}`,
    );
    if (!res.ok) {
      const hint = kickFailHint(res);
      r.log.warn(`VloS 入群验证踢人失败 group=${group} member=${member} code=${res.code} ${res.message}${hint ? '（' + hint + '）' : ''}`);
      // 踢人失败要让群里看到原因，不能只回「已移出」骗人；提示已经发过，这里补一条原因
      await reply(`> 自动移出失败：${hint || res.message || '未知原因'}`, `自动移出失败：${hint || res.message || '未知原因'}`);
    }
    return first;
  }
  const left = Math.max(1, max - entry.attempts);
  // 点过的那条消息里的按钮会全部变灰，答错后要重新挂一组按钮，否则没法再点
  // 重挂的按钮不带 group_id，避免「同组点过一次」再次变灰
  const retryKeyboard = buildVerifyKeyboard(answers, member, { groupButtons: false });
  return reply(`${entry.failText}${left ? `（还可尝试 ${left} 次）` : ''}`, entry.failText, retryKeyboard);
}

/**
 * 点按钮后的互动回复：INTERACTION_CREATE 只能用 event_id 被动回复，Markdown 被拒再降纯文本。
 * keyboard：答错时重新挂一组答案按钮（旧消息的按钮点过一次就灰了）。
 */
async function replyInteraction(ctx, r, markdown, plain, keyboard = null) {
  const md = normalizeQqMarkdown(String(markdown || '').trim());
  if (!md) return null;
  const evt = ctx.event || {};
  const send = async (body, label) => {
    try {
      if (ctx.bot?.replyEvent) return await ctx.bot.replyEvent(evt, body);
      if (ctx.api?.replyEvent) return await ctx.api.replyEvent(evt, body);
    } catch (e) {
      r.log.warn(`VloS ${label}异常：${e?.message || e}`);
    }
    return null;
  };
  let res = await send({ msg_type: 2, markdown: { content: md }, ...(keyboard ? { keyboard } : {}) }, keyboard ? '互动回复（带答案按钮）' : '互动回复');
  if (res && res.ok) return null;
  if (keyboard && isKeyboardReject(res)) {
    r.log.warn(`VloS 答错重发的答案按钮被拒（code=${res?.code || ''}），改无按钮重发`);
    res = await send({ msg_type: 2, markdown: { content: md } }, '互动回复（无按钮）');
    if (res && res.ok) return null;
  }
  if (res && !MARKDOWN_FALLBACK_CODES.has(String(res.code || '')) && String(res.code || '') !== 'NO_PASSIVE_REPLY') {
    r.log.warn(`VloS 互动回复失败 code=${res.code || ''} ${res.message || ''}`);
  }
  const res2 = await send({ msg_type: 0, content: String(plain || md) }, '互动纯文本回复');
  if (!res2 || !res2.ok) r.log.warn(`VloS 互动纯文本回复失败 code=${res2?.code || ''} ${res2?.message || ''}`);
  return null;
}

/**
 * 明日方舟校验按钮（jv:ark）：按钮点一次就失效，失败 / 未授权时重新挂一个「开始校验」按钮。
 */
async function judgeArknightsClick(ctx, r, group, member, entry) {
  const key = `${group}:${member}`;
  const ak = arknightsApi();
  const retryKeyboard = buildArknightsKeyboard(member, { groupButtons: false });
  if (!ak || typeof ak.isLoggedIn !== 'function') {
    r.log.warn('VloS 入群验证：明日方舟插件未启用，无法校验');
    return replyInteraction(ctx, r, '## 校验暂不可用\n> 明日方舟插件未启用，请联系管理员。', '校验暂不可用，请联系管理员。', retryKeyboard);
  }
  let ok = false;
  try {
    ok = !!(await Promise.resolve(ak.isLoggedIn(member)));
  } catch (e) {
    r.log.warn('VloS 入群校验调用明日方舟接口失败：' + (e?.message || e));
  }
  if (ok) {
    dropVerifyPending(key);
    r.log.info(`VloS 入群验证方舟校验通过 group=${group} member=${member}`);
    return replyInteraction(ctx, r, '验证通过，博士！欢迎您的加入！(*´▽｀)ノノ', '验证通过，博士！欢迎您的加入！');
  }
  // 未登录 / 接口取回失败：发消息 + 重新挂「开始校验」按钮（旧按钮点过一次就灰了）
  r.log.info(`VloS 入群验证方舟校验未通过 group=${group} member=${member}`);
  return replyInteraction(
    ctx,
    r,
    '校验未通过！\n> 请先私聊机器人授权鹰角网络账户，再点下面的「开始校验」。',
    '校验未通过！请先私聊机器人授权鹰角网络账户，再点「开始校验」。',
    retryKeyboard,
  );
}

/** 处理消息按钮回调（INTERACTION_CREATE type=11）：先回应互动，再按 jv:<序号> 判定验证答案 */
async function handleInteractionEvent(ctx, r) {
  const raw = ctx.raw || {};
  const type = Number(raw.type ?? raw.data?.type ?? 0);
  if (type && type !== 11) return null; // 只处理消息按钮
  const resolved = raw.data?.resolved || {};
  const buttonData = String(resolved.button_data || '');
  if (!/^jv:/.test(buttonData)) return null;
  const group = String(raw.group_openid || '');
  const member = String(raw.group_member_openid || raw.member_openid || '');
  const interactionId = String(raw.id || ctx.event?.id || '');
  // 3 秒内回应互动，否则客户端一直 loading
  if (interactionId) {
    const ack = await callQqApi(
      ctx,
      r,
      'interaction_ack',
      { params: { interaction_id: interactionId }, body: { code: 0 } },
      `互动回应 ${interactionId}`,
    );
    if (!ack.ok) r.log.warn(`VloS 互动回应失败 code=${ack.code} ${ack.message}`);
  }
  if (!group || !member) return null;
  // 同一个人 1.5 秒内连点同一个按钮：当成重复投递，不重复计数
  const clickKey = `${group}:${member}:${buttonData}`;
  const now = Date.now();
  if (now - Number(joinVerifyClicks.get(clickKey) || 0) < 1500) {
    r.log.info(`VloS 入群验证点击去重（1.5 秒内重复）group=${group} member=${member} data=${buttonData}`);
    return null;
  }
  joinVerifyClicks.set(clickKey, now);
  const key = `${group}:${member}`;
  const entry = joinVerifyPending.get(key);
  if (!entry) {
    r.log.info(`VloS 入群验证点击：没有待验证记录（可能已通过/过期/不是本人按钮）group=${group} member=${member}`);
    return replyInteraction(ctx, r, '这条验证已经完成或过期了，无需再点。', '这条验证已经完成或过期了。');
  }
  if (entry.expiresAt && entry.expiresAt < Date.now()) {
    await handleVerifyTimeout(ctx, r, group, member, entry);
    return null;
  }
  if (buttonData === 'jv:ark') {
    if (entry.mode !== 'arknights') {
      return replyInteraction(ctx, r, '这次入群验证不是明日方舟校验，请按提示作答。', '这次入群验证不是明日方舟校验，请按提示作答。');
    }
    return await judgeArknightsClick(ctx, r, group, member, entry);
  }
  if (entry.mode !== 'custom') {
    return replyInteraction(ctx, r, '这次入群验证不是选择题，请按提示操作。', '这次入群验证不是选择题，请按提示操作。');
  }
  const picked = Number(buttonData.slice(3));
  r.log.info(`VloS 入群验证点击 group=${group} member=${member} answer=${picked + 1}/${(entry.answers || []).length}`);
  return await judgeCustomAnswer(ctx, r, group, member, entry, picked, (md, plain, kb) => replyInteraction(ctx, r, md, plain, kb));
}

/** 群成员加入 / 退出、机器人进群、入群申请：这些事件没有 message，从 ctx.raw 取字段。 */
async function handleGroupEvent(ctx, r, name) {
  const raw = ctx.raw || {};
  const group = String(raw.group_openid || '');
  if (!group) return null;
  if (name !== 'GROUP_JOIN_REQUEST') r.log.info(`VloS 收到群事件 ${name} group=${group} member=${raw.member_openid || ''}`);
  try {
    if (name === 'GROUP_MEMBER_REMOVE') dropVerifyPending(`${group}:${String(raw.member_openid || '')}`);
    if (name === 'GROUP_MEMBER_ADD' || name === 'GROUP_MEMBER_REMOVE' || name === 'GROUP_ADD_ROBOT') {
      const w = effectiveWelcome(r, group);
      if (!w.enabled) {
        r.log.info(`VloS ${name} 跳过：欢迎总开关关闭（group=${group}）`);
        return null;
      }
      const conf = name === 'GROUP_MEMBER_ADD' ? w.memberJoin : name === 'GROUP_MEMBER_REMOVE' ? w.memberLeave : w.botJoin;
      if (!conf.enabled) {
        r.log.info(`VloS ${name} 跳过：该场景开关关闭（group=${group}）`);
        return null;
      }
      const groupName = await groupNameOf(ctx, r, group);
      const verify = w.joinVerify || {};
      // 配置不完整（问题为空 / 答案少于 2 个）时不开启验证，避免新人无论答什么都判错被踢
      const verifyReady =
        verify.mode === 'arknights' ||
        (!!String(verify.question || '').trim() &&
          Array.isArray(verify.answers) &&
          verify.answers.filter((a) => String(a || '').trim()).length >= 2);
      const verifyOn = name === 'GROUP_MEMBER_ADD' && !!verify.enabled && verifyReady;
      if (name === 'GROUP_MEMBER_ADD' && verify.enabled && !verifyReady) {
        r.log.warn(`VloS 入群验证配置不完整（问题为空或答案少于 2 个），本次跳过 group=${group}`);
      }
      const base = renderTemplate(conf.template, templateVars(raw, groupName, name, r)).trim();
      const memberOpenid = String(raw.member_openid || '');
      const verifyMinutes = Math.min(10, Math.max(1, Number(verify.expiresMinutes) || 5));
      let content = base;
      let verifyBlock = '';
      if (verifyOn) {
        // 标题下面标出限时，成员知道要在多久内完成
        const limitLine = `> 限时 ${verifyMinutes} 分钟`;
        verifyBlock =
          verify.mode === 'arknights'
            ? ['## 入群验证', limitLine, '请私聊机器人授权鹰角网络账户，授权后点击下方按钮校验'].join('\n')
            : ['## 入群验证', limitLine, String(verify.question || '').trim()].filter(Boolean).join('\n');
        if (verifyBlock) content = [base, verifyBlock].filter(Boolean).join('\n\n***\n\n');
      }
      if (!content) {
        r.log.warn(`VloS ${name} 跳过：模板渲染为空（group=${group}，检查本群/全局模板）`);
        return null;
      }
      // 验证按钮：自定义问题是每个答案一个回调按钮；明日方舟是单个「开始校验」回调按钮，都只允许这名新成员点
      const verifyKeyboard = !verifyOn
        ? null
        : verify.mode === 'arknights'
          ? buildArknightsKeyboard(memberOpenid)
          : buildVerifyKeyboard(verify.answers, memberOpenid);
      const eventId = String(ctx.event?.id || '');
      // 进群 / 退群：先用事件外层 id 作 event_id 被动回复；失败（或没有 event_id）再退群主动消息
      const allowActive = name === 'GROUP_MEMBER_ADD' || name === 'GROUP_MEMBER_REMOVE';
      const res = await sendWelcome(ctx, group, content, { eventId, allowActive, keyboard: verifyKeyboard });
      if (res && res.ok !== false) {
        r.log.info(`VloS ${name} 欢迎语已发送（${res.via}${res.keyboardDropped ? '，按钮被拒已改文字作答' : ''}）group=${group}`);
        if (verifyOn) {
          if (memberOpenid) {
            // 同一成员重新进群：先清掉旧记录和旧超时定时器
            dropVerifyPending(`${group}:${memberOpenid}`);
            const pending = {
              mode: verify.mode === 'arknights' ? 'arknights' : 'custom',
              answers: Array.isArray(verify.answers) ? verify.answers : [],
              correctIndex: Number(verify.correctIndex) || 0,
              attempts: 0,
              maxAttempts: Number(verify.maxAttempts) || 3,
              passText: verify.passText || '验证通过，欢迎加入！',
              failText: verify.failText || '答案不正确，请再试一次。',
              kickText: verify.kickText || '验证失败次数过多，已被移出群聊。',
              timeoutText: verify.timeoutText || '验证超时，您未在规定时间内完成验证，将被移出群聊。',
              expiresAt: Date.now() + verifyMinutes * 60000,
              allowText: !!res.keyboardDropped,
              at: Date.now(),
            };
            joinVerifyPending.set(`${group}:${memberOpenid}`, pending);
            scheduleVerifyTimeout(ctx, r, group, memberOpenid, pending);
            // 按钮发不出去时补蓝字兜底：自定义问题给答案标签，方舟给「开始校验」指令标签
            if (res.keyboardDropped) {
              const fallback =
                verify.mode === 'arknights'
                  ? '> 点下面的蓝色按钮也可以校验：' + qqCmdTag('/入群校验', '开始校验')
                  : verifyFallbackMarkdown(verify.answers);
              if (fallback) await sendWelcome(ctx, group, fallback, { eventId, allowActive });
            }
            r.log.info(
              `VloS ${name} 入群验证已开启 group=${group} member=${memberOpenid} mode=${verify.mode || 'custom'} ` +
                `maxAttempts=${verify.maxAttempts} expiresMinutes=${verifyMinutes} buttons=${verifyKeyboard ? 'on' : 'off'}${res.keyboardDropped ? '（按钮被拒，文字作答）' : ''}`,
            );
          }
        }
      } else {
        r.log.warn(`VloS ${name} 欢迎语发送失败：${res?.message || ''} code=${res?.code || ''}${welcomeFailHint(res)}`);
        if (name === 'GROUP_ADD_ROBOT') scheduleBotJoinRetry(ctx, r, group, conf, raw);
      }
    } else if (name === 'GROUP_JOIN_REQUEST') {
      const g = effectiveGuard(r, group);
      r.log.info(
        `VloS 收到入群申请 group=${group} user=${raw.username || raw.member_openid || ''} ` +
          `id=${raw.join_request_id || ''} method=${raw.verify_info?.method || '-'}`,
      );
      // 入群审批准只看「处理入群申请」；违禁词总开关 guard.enabled 关闭时也要生效
      if (!g.join.enabled || g.join.mode === 'manual') return null;

      // approve / decline / qa（按入群问题答案关键词审核）
      let op = g.join.mode === 'approve' ? 'approve' : g.join.mode === 'decline' ? 'decline' : '';
      if (g.join.mode === 'qa') {
        const verdict = judgeJoinRequest(raw, g.join);
        op = verdict.ok ? 'approve' : g.join.qaFallback === 'decline' ? 'decline' : '';
        r.log.info(
          `VloS 入群问题审核 group=${group} user=${raw.username || raw.member_openid || ''} ` +
            `method=${verdict.method || '-'} ${verdict.keyword ? '命中「' + verdict.keyword + '」' : '未命中关键词'} → ${op || '留给管理员'}`,
        );
      }
      if (!op) return null;
      if (op === 'approve' && raw.risk_tips) {
        r.log.warn(`VloS 入群申请带安全提示，已跳过自动通过 group=${group}`);
        return null;
      }
      if (!ctx.api || typeof ctx.api.call !== 'function') return null;
      const res = await ctx.api.call('approval_join_request', {
        params: { group_openid: group, member_openid: String(raw.member_openid || '') },
        body: {
          op,
          join_request_id: String(raw.join_request_id || ''),
          reject_reason: op === 'decline' ? g.join.rejectReason : '',
          add_to_member_blacklist: false,
        },
      });
      if (res && res.ok === false) r.log.warn(`VloS 入群申请自动处理失败：${res.message || res.code || ''}`);
      else r.log.info(`VloS 入群申请已自动${op === 'approve' ? '通过' : '拒绝'} group=${group} user=${raw.username || raw.member_openid || ''}`);
    }
  } catch (e) {
    r.log.warn(`VloS 处理 ${name} 失败：${e?.message || e}`);
  }
  return null;
}

/** 群名称缓存 10 分钟，避免每条欢迎语都请求一次接口。 */
async function groupNameOf(ctx, r, group) {
  const now = Date.now();
  const hit = r.groupNames.get(group);
  if (hit && now - hit.at < 10 * 60000) return hit.name;
  let name = '';
  try {
    const res = await ctx.api?.call('group_info', { params: { group_openid: group } });
    const d = res?.data || {};
    name = String(d.group_name || d.name || d.group?.group_name || '').trim();
  } catch {
    /* 取不到就用默认名 */
  }
  r.groupNames.set(group, { name, at: now });
  return name || '本群';
}

/** 指令 -> 腾讯蓝色指令标签（群聊用 cmd-input，点击填入输入框） */
function cmdMarkdown(r, key) {
  const c = r?.cfg?.commands?.[key];
  if (!c || c.enabled === false || !c.names.length) return '';
  const text = (c.prefix || '') + c.names[0];
  return `<qqbot-cmd-input text="${encodeURIComponent(text)}" show="${encodeURIComponent(c.names[0])}" />`;
}

const CMD_VAR_KEYS = ['sign', 'menu', 'list', 'help', 'add', 'login', 'bindqq', 'bindopenid', 'groupadmin', 'cancel'];

function commandSampleVars(r) {
  const out = {};
  for (const key of CMD_VAR_KEYS) out['cmd_' + key] = cmdMarkdown(r, key);
  return out;
}

function templateVars(raw, groupName, eventName, r) {
  const verify = raw.verify_info || {};
  const source = raw.apply_source === 'invited' ? '邀请入群' : raw.apply_source === 'self_apply' ? '主动申请' : '';
  const at = (id) => (id ? `<qqbot-at-user id="${String(id)}" />` : '');
  const memberId = eventName === 'GROUP_MEMBER_ADD' ? String(raw.member_openid || '') : '';
  return {
    group: groupName,
    group_openid: raw.group_openid || '',
    member: raw.username || raw.member_openid || '新朋友',
    member_openid: raw.member_openid || '',
    username: raw.username || '',
    user_openid: raw.user_openid || '',
    time: T.formatDateTime(),
    event: eventName,
    apply_source: source,
    verify_message: verify.verify_message || '',
    invited_by: raw.invited_by || '',
    op_member: raw.op_member_openid || '',
    // 腾讯 Markdown 内置能力：@ 用户 / @ 全体
    at_member: at(memberId),
    at_user: at(memberId),
    at_op: at(raw.op_member_openid),
    at_all: '<qqbot-at-everyone />',
    // 腾讯 Markdown 蓝色指令标签（点击填入输入框）
    ...commandSampleVars(r),
  };
}

function renderTemplate(tpl, vars) {
  return String(tpl || '').replace(/\{(\w+)(?::([^}]*))?\}/g, (_, key, arg) => {
    // 自定义蓝色指令：{cmd:/Arknights|明日方舟}（第二个参数是点击后显示的文字）
    if (key === 'cmd' && arg !== undefined) {
      const [cmdRaw, showRaw] = String(arg).split('|');
      const cmd = cmdRaw.trim();
      if (!cmd) return '';
      const show = (showRaw === undefined ? cmd : showRaw).trim() || cmd;
      return `<qqbot-cmd-input text="${encodeURIComponent(cmd)}" show="${encodeURIComponent(show)}" />`;
    }
    // Markdown 图片：{img:https://...}（自动补 QQ 需要的 #0px #0px）
    if (key === 'img' && arg !== undefined) {
      const url = String(arg).trim();
      if (!/^https?:\/\//i.test(url)) return '';
      return `![图片 #0px #0px](${url})`;
    }
    // Markdown 链接：{link:https://...|显示文字}
    if (key === 'link' && arg !== undefined) {
      const [urlRaw, textRaw] = String(arg).split('|');
      const url = urlRaw.trim();
      if (!/^https?:\/\//i.test(url)) return '';
      const text = (textRaw === undefined ? url : textRaw).trim() || url;
      return `[${text}](${url})`;
    }
    // @ 指定用户：{at:OPENID}
    if (key === 'at' && arg !== undefined) {
      const id = String(arg).trim();
      return id ? `<qqbot-at-user id="${id}" />` : '';
    }
    return vars[key] === undefined ? '' : String(vars[key]);
  });
}

/** QQ Markdown 图片需要 `![alt #宽px #高px](url)`；0px 0px = 按原图大小显示 */
function withImageSize(md) {
  return String(md || '').replace(/!\[([^\]]*)\]\((https?:\/\/[^)\s]+)\)/g, (m, alt, url) => {
    if (/#\d+px\s+#\d+px/i.test(alt)) return m;
    return `![${alt || '图片'} #0px #0px](${url})`;
  });
}

/** 腾讯要求指令标签的 text / show 做 urlencode；模板里手写的标签也统一转一次（已编码的不会重复转） */
function encodeCmdAttr(value) {
  const raw = String(value ?? '');
  let text = raw;
  try {
    text = decodeURIComponent(raw);
  } catch {
    /* 含未转义的 %，按原文处理 */
  }
  return encodeURIComponent(text);
}

function normalizeCmdTags(md) {
  return String(md || '').replace(/<qqbot-cmd-(input|enter)\b([^>]*?)\/?>/g, (m, kind, attrs) => {
    const next = String(attrs)
      .replace(/\b(text|show)="([^"]*)"/g, (_, key, value) => `${key}="${encodeCmdAttr(value)}"`)
      .trim();
    return `<qqbot-cmd-${kind}${next ? ' ' + next : ''} />`;
  });
}

/** 按腾讯 Markdown 规范收敛：分割线用 ***（腾讯文档写法），图片补尺寸，指令标签属性转码 */
function normalizeQqMarkdown(md) {
  const s = normalizeCmdTags(String(md || '').replace(/^[ \t]*(-{3,}|_{3,})[ \t]*$/gm, '***'));
  return withImageSize(s);
}

const MARKDOWN_FALLBACK_CODES = new Set(['304036', '304004', '304061', '40034124', '40034011', '40034008', '40034009']);

/** Markdown 不可用时降级纯文本：去掉 Markdown 标记，@ 标签退化成文本 */
function plainWelcome(text) {
  return String(text || '')
    .replace(/<qqbot-at-user id="([^"]+)"\s*\/>/g, '@$1')
    .replace(/<qqbot-at-everyone\s*\/>/g, '@全体成员')
    .replace(/<qqbot-cmd-input[^>]*\/>/g, '')
    .replace(/<qqbot-cmd-enter[^>]*\/>/g, '')
    .replace(/^[ \t]*#{1,6}[ \t]+/gm, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .trim();
}

async function sendGroupText(ctx, group, content, extra = {}) {
  const payload = { msg_type: 0, content: String(content || ''), ...extra };
  if (!group || !payload.content) return null;
  try {
    if (ctx.bot?.sendGroup) return await ctx.bot.sendGroup(group, payload);
    if (ctx.api?.sendGroup) return await ctx.api.sendGroup(group, payload);
    return null;
  } catch (e) {
    return { ok: false, message: e?.message || String(e) };
  }
}

/**
 * 欢迎语发送：只用事件外层 id 作 event_id 被动回复（社区实测 member_add/remove 也可用）。
 * 不降级主动消息——避免“欢迎语变成主动消息”后被限频/风控；
 * Markdown 被拒时同一 event_id 下降级纯文本，event_id 被拒则只记日志。
 * keyboard：入群验证的答案按钮；群没开通自定义按钮时自动去掉键盘重发（keyboardDropped=true，改回文字作答）。
 */
async function sendWelcome(ctx, group, content, { eventId = '', allowActive = false, keyboard = null } = {}) {
  if (!eventId && !allowActive) return { ok: false, code: 'NO_EVENT_ID', message: '缺少事件外层 id，跳过欢迎语（不发主动消息）' };
  const parsed = extractButtons(content);
  const mdContent = parsed.text;
  const kb = keyboard || buildKeyboard(parsed.buttons);
  const text = plainWelcome(mdContent);

  const attempt = async (useKeyboard) => {
    const kbExtra = useKeyboard && kb ? { keyboard: kb } : {};
    const send = (m) => (m.md ? sendGroupMarkdown(ctx, group, mdContent, { ...m.extra, ...kbExtra }) : sendGroupText(ctx, group, text, m.extra));
    const eventModes = [];
    if (eventId) {
      eventModes.push({ md: true, via: 'event_id + Markdown', extra: { event_id: eventId } });
      if (text) eventModes.push({ md: false, via: 'event_id + 纯文本', extra: { event_id: eventId } });
    }
    // 退群 / 进群事件有时拿不到可用的 event_id，失败后退回群主动消息（需要主动消息权限）
    const activeModes = [];
    if (allowActive) {
      activeModes.push({ md: true, via: '主动消息 + Markdown', extra: {} });
      if (text) activeModes.push({ md: false, via: '主动消息 + 纯文本', extra: {} });
    }

    let last = null;
    for (const m of eventModes) {
      const res = await send(m);
      last = res;
      if (res && res.ok !== false) return { res: { ...res, via: m.via, degraded: m.via.includes('纯文本') } };
      if (!MARKDOWN_FALLBACK_CODES.has(String(res?.code || ''))) break; // Markdown 被拒才试纯文本
    }
    for (const m of activeModes) {
      const res = await send(m);
      last = res;
      if (res && res.ok !== false) return { res: { ...res, via: m.via, degraded: true } };
      if (!MARKDOWN_FALLBACK_CODES.has(String(res?.code || ''))) break;
    }
    return { res: last };
  };

  const first = await attempt(true);
  if (first.res && first.res.ok !== false) return first.res;
  if (kb && isKeyboardReject(first.res)) {
    const second = await attempt(false);
    if (second.res && second.res.ok !== false) return { ...second.res, keyboardDropped: true };
    return second.res;
  }
  return first.res;
}

/** QQ 拒绝自定义按钮的典型错误（没开通内邀 / 键盘参数错）：去掉键盘再发一次 */
function isKeyboardReject(res) {
  const code = String(res?.code || '');
  const msg = String(res?.message || '');
  if (['305007', '40034106', '40034127', '40034029', '40034124'].includes(code)) return true;
  return /keyboard|键盘|按钮/i.test(msg);
}

async function sendGroupMarkdown(ctx, group, content, extra = {}) {
  if (!group || !content) return null;
  const payload = { msg_type: 2, markdown: { content: normalizeQqMarkdown(content) }, ...extra };
  try {
    if (ctx.bot?.sendGroup) return await ctx.bot.sendGroup(group, payload);
    if (ctx.api?.sendGroup) return await ctx.api.sendGroup(group, payload);
    return null;
  } catch (e) {
    return { ok: false, message: e?.message || String(e) };
  }
}

/**
 * 刚被拉进群时用 GROUP_ADD_ROBOT 的 event_id 走群消息被动回复；可能因过期 / 权限失败，
 * 这里按 15s / 45s / 90s 重试几次，不再走主动消息。
 */
const botJoinRetries = new Set();

function scheduleBotJoinRetry(ctx, r, group, conf, raw) {
  if (botJoinRetries.has(group)) return;
  botJoinRetries.add(group);
  const delays = [15000, 30000, 60000, 120000, 180000, 300000];
  const done = () => botJoinRetries.delete(group);

  const attempt = async (idx) => {
    if (!botJoinRetries.has(group)) return;
    if (rt !== r) {
      done();
      return;
    }
    try {
      const groupName = await groupNameOf(ctx, r, group);
      const content = renderTemplate(conf.template, templateVars(raw, groupName, 'GROUP_ADD_ROBOT', r)).trim();
      const eventId = String(ctx.event?.id || '');
      // 只用 GROUP_ADD_ROBOT 的 event_id 走被动消息：不占主动消息权限，也不是 msg_id
      if (content && eventId) {
        const res = await sendGroupMarkdown(ctx, group, content, { event_id: eventId });
        if (!res || res.ok !== false) {
          r.log.info(`VloS GROUP_ADD_ROBOT 介绍已补发（event_id）group=${group}`);
          done();
          return;
        }
        r.log.warn(`VloS GROUP_ADD_ROBOT 被动消息补发失败：${res.message || ''} code=${res.code || ''}`);
      } else {
        r.log.warn(`VloS GROUP_ADD_ROBOT 缺少事件 id / 模板为空，无法补发 group=${group}`);
      }
    } catch (e) {
      r.log.warn(`VloS GROUP_ADD_ROBOT 补发异常：${e?.message || e}`);
    }
    if (idx + 1 < delays.length) {
      const t = setTimeout(() => attempt(idx + 1), delays[idx + 1]);
      if (t.unref) t.unref();
    } else {
      done();
    }
  };

  const timer = setTimeout(() => attempt(0), delays[0]);
  if (timer.unref) timer.unref();
}

/* ======================= 用户快照（设置页只读数据） ======================= */

const USERS_SNAPSHOT_START = '<!-- VLOS_USERS_START -->';
const USERS_SNAPSHOT_END = '<!-- VLOS_USERS_END -->';

function usersSnapshot(r) {
  // 只列注册 / 登录过聚龙账户的用户；群里打过字但没绑账户的不算
  const all = r.store.all().filter((u) => u.email);
  return {
    at: Date.now(),
    total: all.length,
    users: all
      .slice()
      .sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0))
      .slice(0, 300)
      .map((u) => ({
        key: u.key,
        email: u.email || '',
        name: u.name || '',
        qq: u.qq || '',
        openid: u.openid || '',
        legacyQq: u.legacyQq || '',
        wallet: { longjing: cleanMoney(u.wallet?.longjing), xuanyu: cleanMoney(u.wallet?.xuanyu) },
        pending: { longjing: cleanMoney(u.pendingWallet?.longjing), xuanyu: cleanMoney(u.pendingWallet?.xuanyu) },
        balances: { longjing: cleanMoney(u.balances?.longjing), xuanyu: cleanMoney(u.balances?.xuanyu) },
        sign: {
          totalDays: Number(u.sign?.totalDays) || 0,
          streak: Number(u.sign?.streak) || 0,
          lastDate: u.sign?.lastDate || '',
        },
        createdAt: Number(u.createdAt) || 0,
        updatedAt: Number(u.updatedAt) || 0,
      })),
  };
}

/**
 * 设置页是 sandbox iframe（不能读文件、不能联网），所以把只读用户列表
 * 写进 settings.html 的占位区，页面打开时直接读这份 JSON。
 * 不含 token / 密码 / 验证码。
 */
function refreshUsersSnapshot(r) {
  try {
    const file = path.join(r.dir, 'settings.html');
    let html = fs.readFileSync(file, 'utf8');
    const i = html.indexOf(USERS_SNAPSHOT_START);
    const j = html.indexOf(USERS_SNAPSHOT_END);
    if (i < 0 || j < i) return false;
    const data = JSON.stringify(usersSnapshot(r)).replace(/</g, '\\u003c');
    const block = `${USERS_SNAPSHOT_START}\n<script id="vlos-users-data" type="application/json">${data}</script>\n${USERS_SNAPSHOT_END}`;
    html = html.slice(0, i) + block + html.slice(j + USERS_SNAPSHOT_END.length);
    fs.writeFileSync(file, html, 'utf8');
    return true;
  } catch (e) {
    if (r?.log?.warn) r.log.warn('VloS 用户快照写入失败：' + (e?.message || e));
    return false;
  }
}

/**
 * 把「各指令内置默认回复」写进 settings.html 的占位区：
 * 设置页「编辑」点开时直接预填默认 Markdown + 实时预览，并可一键「恢复默认」。
 * 默认值只在 index.js 维护一份，设置页不重复写死。
 */
const CMD_DEFAULTS_SNAPSHOT_START = '<!-- VLOS_CMD_DEFAULTS_START -->';
const CMD_DEFAULTS_SNAPSHOT_END = '<!-- VLOS_CMD_DEFAULTS_END -->';

function commandDefaultsSnapshot() {
  return { at: Date.now(), version: PLUGIN_VERSION, replies: DEFAULT_COMMAND_REPLIES };
}

function refreshCommandDefaultsSnapshot(r) {
  try {
    const file = path.join(r.dir, 'settings.html');
    let html = fs.readFileSync(file, 'utf8');
    const i = html.indexOf(CMD_DEFAULTS_SNAPSHOT_START);
    const j = html.indexOf(CMD_DEFAULTS_SNAPSHOT_END);
    if (i < 0 || j < i) return false;
    const data = JSON.stringify(commandDefaultsSnapshot()).replace(/</g, '\\u003c');
    const block = `${CMD_DEFAULTS_SNAPSHOT_START}\n<script id="vlos-command-defaults-data" type="application/json">${data}</script>\n${CMD_DEFAULTS_SNAPSHOT_END}`;
    html = html.slice(0, i) + block + html.slice(j + CMD_DEFAULTS_SNAPSHOT_END.length);
    fs.writeFileSync(file, html, 'utf8');
    return true;
  } catch (e) {
    if (r?.log?.warn) r.log.warn('VloS 指令默认回复快照写入失败：' + (e?.message || e));
    return false;
  }
}

/* ======================= 帮助 ======================= */

async function handleHelp(ctx, r, who) {
  const user = who.found || r.store.get(who.key);
  const stats = r.store.stats();
  const head = heading(ctx, user || who, r);
  const commandLines = [];
  const order = ['add', 'login', 'bindqq', 'bindopenid', 'list', 'sign', 'menu', 'menusync', 'groupadmin', 'help', 'cancel'];
  const plain = [];
  for (const key of order) {
    const c = r.cfg.commands[key];
    if (!c || c.enabled === false || !c.names.length) continue;
    const tags = c.names.map((_, i) => cmdInline(ctx, r, key, i)).filter(Boolean).join(' / ');
    commandLines.push(`- ${tags}：${T.escapeMarkdown(c.desc)}`);
    plain.push((c.prefix || '') + c.names[0]);
  }
  const footerLines = [
    '***',
    '',
    `> 插件 v${PLUGIN_VERSION} · 已绑定 ${stats.bound} 人 · 已绑 QQ ${stats.withQQ} 人 · 今日签到 ${stats.signedToday} 人`,
    `> 签到模式：[${T.escapeMarkdown(r.cfg.site.name)}](${r.cfg.site.url})`,
  ];
  ctx.__commandVars = {
    heading: head,
    title: '## VloS 指令',
    commands: commandLines.join('\n'),
    version: PLUGIN_VERSION,
    bound: String(stats.bound),
    with_qq: String(stats.withQQ),
    signed_today: String(stats.signedToday),
    footer: footerLines.join('\n'),
  };
  const lines = [head, '## VloS 指令', ...commandLines, '', ...footerLines];
  return replyMd(ctx, r, lines.join('\n'), 'VloS 指令：' + plain.join('、'));
}

/* ======================= 渲染工具 ======================= */

function requirePrivate(ctx, r, who) {
  if (ctx.message?.kind === 'c2c') return null;
  return replyMd(
    ctx,
    r,
    [heading(ctx, who, r), '## 请私聊操作', '> 注册 / 登录涉及邮箱验证码和密码，请私聊机器人发送。'].join('\n'),
    '请私聊机器人进行注册 / 登录。',
  );
}

function normalizeCmd(name) {
  return String(name || '')
    .trim()
    .replace(/^[/／]+/, '')
    .replace(/[\s\u3000]+/g, '')
    .toLowerCase();
}

/** 群自定义覆盖：只有已通过审核的群才生效，pending / rejected 一律回落全局 */
function groupOverride(r, group) {
  const o = (r?.cfg?.groups && r.cfg.groups[group]) || null;
  return o && o.reviewStatus === 'approved' ? o : null;
}

function effectiveWelcome(r, group) {
  const o = groupOverride(r, group);
  if (!o || !o.welcome) return r.cfg.welcome;
  const ow = o.welcome;
  const merged = deepMerge(r.cfg.welcome, ow);
  // 本群有设置就以本群为准：页面只控制进群/退群开关，没单独写 enabled 时按这两个开关推导，
  // 这样全局总开关关着，群里打开进群欢迎也能生效（关掉再打开同样生效）
  if (ow.enabled === undefined) {
    merged.enabled = !!r.cfg.welcome.enabled || !!(ow.memberJoin?.enabled) || !!(ow.memberLeave?.enabled);
  }
  // 本群模板留空时回落到全局模板，避免「关一次再打开」后模板被清空、发不出内容
  for (const key of ['memberJoin', 'memberLeave', 'botJoin']) {
    if (merged[key] && !String(merged[key].template || '').trim() && r.cfg.welcome[key]) {
      merged[key].template = r.cfg.welcome[key].template;
    }
  }
  return merged;
}

function effectiveGuard(r, group) {
  const o = groupOverride(r, group);
  if (!o || !o.guard) return r.cfg.guard;
  const merged = deepMerge(r.cfg.guard, o.guard);
  // 本群表单里没启用违禁词时，回落到全局违禁词配置，而不是把全局词一起关掉
  if (o.guard.enabled === false) {
    merged.enabled = r.cfg.guard.enabled;
    merged.action = r.cfg.guard.action;
    merged.muteSeconds = r.cfg.guard.muteSeconds;
    if (!Array.isArray(o.guard.bannedWords) || o.guard.bannedWords.length === 0) {
      merged.bannedWords = r.cfg.guard.bannedWords;
    }
  }
  return merged;
}

/** 生成「识别字符 + 指令名」的展示文本，例：/签到；识别字符为空时就是 签到 */
function cmdLabel(r, key, idx = 0) {
  const c = r?.cfg?.commands?.[key];
  if (!c || c.enabled === false || !c.names.length) return '';
  return (c.prefix || '') + c.names[Math.min(idx, c.names.length - 1)];
}

/** 把指令渲染成和菜单一样的蓝色可点击标签（群里填入输入框，私聊按 autoSend 直发） */
function cmdInline(ctx, r, key, idx = 0) {
  const label = cmdLabel(r, key, idx);
  if (!label) return '';
  const autoSend = ctx?.message?.kind === 'c2c' && r?.cfg?.menu?.autoSend;
  return qqCmdTag(label, label, autoSend);
}

function identityKeys(message) {
  const a = message?.author || {};
  const ids = [a.union_openid, message?.user_openid, a.user_openid, a.member_openid, a.id]
    .map((x) => String(x || '').trim())
    .filter(Boolean);
  return [...new Set(ids)];
}

/** 聚龙账户要保存的 OpenID：优先 union_openid，其次私聊 user_openid / 群 member_openid */
function primaryOpenid(message) {
  const a = message?.author || {};
  return String(a.union_openid || message?.user_openid || a.user_openid || a.member_openid || a.id || '').trim();
}

function isValidOpenid(openid) {
  return /^[\x21-\x7e]{8,128}$/.test(String(openid || ''));
}

/** OpenID 放进 Markdown 行内代码：不要转义下划线，否则会显示成 \_ */
function codeSpan(value) {
  return '`' + String(value || '').replace(/`/g, '') + '`';
}

function displayName(ctx, who) {
  const name = String(ctx.message?.author?.username || '').trim();
  if (name) return name;
  if (who?.name) return who.name;
  if (who?.email) return who.email.split('@')[0];
  return '博士';
}

function avatarFor(ctx, user, r) {
  const av = String(user?.avatar || '').trim();
  if (av) {
    if (/^https?:\/\//i.test(av)) return av;
    return r.jl.absoluteAvatar(av);
  }
  const m = ctx.message || {};
  const a = m.author || {};
  const info = (() => {
    try {
      return ctx.bot?.info?.() || null;
    } catch {
      return null;
    }
  })();
  const appId = String(info?.appId || '');
  const openid = m.kind === 'c2c' ? m.user_openid || a.user_openid || a.id : a.member_openid || a.id;
  if (!appId || !openid) return '';
  return `https://q.qlogo.cn/qqapp/${encodeURIComponent(appId)}/${encodeURIComponent(openid)}/0`;
}

function heading(ctx, user, r) {
  const av = avatarFor(ctx, user, r);
  const size = r?.cfg?.ui?.avatarSize || 48;
  const name = T.escapeMarkdown(user?.name || displayName(ctx, user));
  return `${av ? `![头像 #${size}px #${size}px](${av}) ` : ''}**${name}**`;
}

function siteFooter(r) {
  if (!r.cfg.ui.showSiteLink) return '';
  return `***\n\n[${T.escapeMarkdown(r.cfg.site.name)}](${r.cfg.site.url})`;
}

function poemCandidates(dir) {
  return POEM_FILES.map((name) => path.join(dir, 'data', name));
}

function activePoemFile(dir) {
  for (const file of poemCandidates(dir)) {
    try {
      if (fs.statSync(file).isFile()) return file;
    } catch {
      /* next */
    }
  }
  return '';
}

function pickPoem(dir) {
  for (const file of poemCandidates(dir)) {
    try {
      const st = fs.statSync(file);
      if (!st.isFile()) continue;
      if (poemCache.file === file && poemCache.mtimeMs === st.mtimeMs && poemCache.lines.length) {
        return poemCache.lines[T.randInt(0, poemCache.lines.length - 1)];
      }
      const raw = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
      const lines = raw.split(/\r?\n/).map((x) => x.trim()).filter((x) => x && !x.startsWith('#'));
      if (!lines.length) continue;
      poemCache = { file, mtimeMs: st.mtimeMs, lines };
      return lines[T.randInt(0, lines.length - 1)];
    } catch {
      /* next */
    }
  }
  poemCache = { file: '', mtimeMs: 0, lines: [] };
  return DEFAULT_POEMS[T.randInt(0, DEFAULT_POEMS.length - 1)];
}

/** 指令自定义回复：模板里可用 {content} 引用默认回复，其余变量由各 handler 放进 ctx.__commandVars */
function applyCommandReply(ctx, r, md) {
  const key = String(ctx?.__commandKey || '');
  if (!key) return md;
  const tpl = String(r?.cfg?.commands?.[key]?.reply || '').trim();
  if (!tpl) return md;
  const group = String(ctx.message?.group_openid || ctx.raw?.group_openid || '');
  const cached = group && r.groupNames ? r.groupNames.get(group) : null;
  const atId = ctx.message?.author?.member_openid || ctx.message?.author?.user_openid || ctx.message?.user_openid || '';
  // 通用变量：任何指令的自定义回复都能用 {heading} / {name} / {avatar}（不依赖具体 handler）
  const avUrl = avatarFor(ctx, null, r);
  const avSize = r?.cfg?.ui?.avatarSize || 48;
  const senderName = ctx.message?.author?.username || '';
  return renderTemplate(tpl, {
    content: md,
    user: senderName,
    name: T.escapeMarkdown(senderName || '聚龙用户'),
    heading: heading(ctx, null, r),
    avatar: avUrl ? `![头像 #${avSize}px #${avSize}px](${avUrl})` : '',
    group: (cached && cached.name) || '',
    group_openid: group,
    time: T.formatDateTime(),
    at_user: atId ? `<qqbot-at-user id="${String(atId)}" />` : '',
    at_all: '<qqbot-at-everyone />',
    ...commandSampleVars(r),
    ...(ctx.__commandVars || {}),
  }).trim() || md;
}

/** 系统提示（权限不足 / 格式错误 / 流程提示）：不套用自定义回复模板，避免被用户模板顶掉 */
function replyNotice(ctx, r, markdown, plain) {
  return replyMd(ctx, r, markdown, plain, { raw: true });
}

/**
 * 按钮语法（写在自定义回复里，独占一行）：
 *   【行,列|按钮文字|数据|类型|可点范围|点击后立即发送】
 *   - 行/列 1–5；最多 5 行、每行 5 个；
 *   - 类型（按 QQ 群聊键盘规范）：指令(2，默认) / 回调(1，需要 INTERACTION_CREATE) / 跳转(0，data 填 URL)；
 *   - 可点范围：所有人(2，默认) / 管理员(1) / 指定用户(0，需另外带 specify_user_ids，语法里只能选类型)；
 *   - 点击后立即发送：是(enter=true，仅指令按钮)；回调按钮点击后由 INTERACTION_CREATE 事件判定。
 * 例：【1,1|签到|/签到|指令|所有人|是】【1,2|官网|https://www.jlworld.net|跳转】
 * 解析后从 Markdown 里删掉，转成 QQ 的 keyboard JSON。
 */
const BUTTON_LINE = /【\s*(\d)\s*[,，]\s*(\d)\s*[|｜]\s*([^|｜】]+?)\s*[|｜]\s*([^|｜】]*?)\s*[|｜]\s*([^|｜】]+?)\s*(?:[|｜]\s*([^|｜】]+?)\s*)?(?:[|｜]\s*([^】]+?)\s*)?】/g;
const BUTTON_TYPES = { 指令: 2, 命令: 2, cmd: 2, 2: 2, 回调: 1, callback: 1, 1: 1, 跳转: 0, 链接: 0, url: 0, link: 0, 0: 0 };
const BUTTON_PERMS = { 所有人: 2, 全部: 2, all: 2, 2: 2, 管理员: 1, 管理: 1, admin: 1, 1: 1, 指定: 0, 指定用户: 0, 0: 0 };
const BUTTON_YES = { 是: true, 立即: true, true: true, yes: true, 1: true, on: true };

/**
 * 入群验证按钮发不出去时的兜底：把每个答案做成 Markdown 蓝字指令标签，
 * 点击会把 `/入群验证 <答案>`（带 @机器人）填进输入框，发送后一样能判定。
 */
function verifyFallbackMarkdown(answers) {
  const list = (Array.isArray(answers) ? answers : []).map((a) => String(a || '').trim()).filter(Boolean).slice(0, 4);
  if (!list.length) return '';
  const links = list.map((a) => qqCmdTag(`/入群验证 ${a}`, a)).join(' · ');
  return `> 点下面的蓝色答案也可以完成验证：${links}`;
}

function extractButtons(md) {
  const buttons = [];
  const text = String(md || '')
    .replace(BUTTON_LINE, (m, row, col, label, data, typeRaw, permRaw, enterRaw) => {
      const type = BUTTON_TYPES[String(typeRaw).trim().toLowerCase()];
      if (type === undefined) return m; // 类型不认识就保留原文，方便排查
      const permission = BUTTON_PERMS[String(permRaw || '所有人').trim().toLowerCase()];
      buttons.push({
        row: Math.min(5, Math.max(1, Number(row) || 1)),
        col: Math.min(5, Math.max(1, Number(col) || 1)),
        label: String(label).trim(),
        data: String(data).trim(),
        type,
        permission: permission === undefined ? 2 : permission,
        enter: !!BUTTON_YES[String(enterRaw || '').trim().toLowerCase()],
      });
      return '';
    })
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return { text, buttons };
}

function buildKeyboard(buttons) {
  if (!buttons || !buttons.length) return null;
  const rows = [];
  for (const b of buttons) {
    const i = b.row - 1;
    if (!rows[i]) rows[i] = [];
    rows[i].push(b);
  }
  const out = [];
  rows.forEach((list) => {
    if (!list || !list.length) return;
    const ordered = list.slice(0, 5).sort((a, b) => a.col - b.col);
    out.push({
      buttons: ordered.map((b, idx) => ({
        id: b.id || `${out.length + 1}-${idx + 1}`,
        render_data: { label: b.label || b.data || '按钮', visited_label: b.label || b.data || '按钮', style: 1 },
        action: {
          type: b.type,
          permission: {
            type: b.permission,
            ...(Array.isArray(b.specifyUserIds) && b.specifyUserIds.length ? { specify_user_ids: b.specifyUserIds.slice(0, 10) } : {}),
          },
          data: b.data,
          unsupport_tips: '请升级 QQ 版本',
          ...(b.enter && b.type === 2 ? { enter: true } : {}),
        },
        ...(b.type === 1 && b.groupId ? { group_id: b.groupId } : {}),
      })),
    });
  });
  if (!out.length) return null;
  return { content: { rows: out.slice(0, 5) } };
}

/**
 * 入群验证答案按钮：回调按钮（action.type=1），只允许这名新成员点（permission.type=0）；
 * 点击后 QQ 推 INTERACTION_CREATE，插件按 button_data 里的 `jv:<序号>` 判定，不依赖群全量消息。
 * opts.groupButtons=false 时不带 group_id —— 答错重挂的按钮必须还能点（group_id 会让同组按钮点一次就灰）。
 */
function buildVerifyKeyboard(answers, memberOpenid, opts = {}) {
  const list = (Array.isArray(answers) ? answers : []).map((a) => String(a || '').trim()).filter(Boolean).slice(0, 4);
  if (!list.length || !memberOpenid) return null;
  const groupId = opts.groupButtons === false ? '' : 'joinverify';
  const buttons = list.map((label, i) => ({
    id: `jv-${i}`,
    label: label.slice(0, 10),
    data: `jv:${i}`,
    type: 1,
    permission: 0,
    specifyUserIds: [String(memberOpenid)],
    groupId,
  }));
  // 4 个答案放一行，超过 5 个会拆行（答案上限 4，实际只有一行）
  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push({
      buttons: buttons.slice(i, i + 5).map((b) => ({
        id: b.id,
        render_data: { label: b.label, visited_label: b.label, style: 1 },
        action: {
          type: 1,
          permission: { type: 0, specify_user_ids: b.specifyUserIds },
          data: b.data,
          unsupport_tips: '请升级 QQ 版本',
        },
        ...(b.groupId ? { group_id: b.groupId } : {}),
      })),
    });
  }
  return { content: { rows } };
}

/**
 * 明日方舟校验按钮：同样用回调按钮（action.type=1，data=`jv:ark`），只允许这名新成员点；
 * 点后 INTERACTION_CREATE 里直接调 Arknights.isLoggedIn，不再靠指令按钮发 `/入群校验`。
 * opts.groupButtons=false 用于校验失败后重挂（旧消息的按钮点一次就灰）。
 */
function buildArknightsKeyboard(memberOpenid, opts = {}) {
  if (!memberOpenid) return null;
  const groupId = opts.groupButtons === false ? '' : 'joinverify';
  return {
    content: {
      rows: [
        {
          buttons: [
            {
              id: 'jv-ark',
              render_data: { label: '开始校验', visited_label: '开始校验', style: 1 },
              action: { type: 1, permission: { type: 0, specify_user_ids: [String(memberOpenid)] }, data: 'jv:ark', unsupport_tips: '请升级 QQ 版本' },
              ...(groupId ? { group_id: groupId } : {}),
            },
          ],
        },
      ],
    },
  };
}

async function replyMd(ctx, r, markdown, _plain, opts = {}) {
  let md = normalizeQqMarkdown(String(markdown || '').trim());
  if (!md) return null;
  const parsed = extractButtons(normalizeQqMarkdown(opts.raw ? md : applyCommandReply(ctx, r, md)));
  md = normalizeQqMarkdown(parsed.text);
  if (!md && !parsed.buttons.length) return null;
  const keyboard = buildKeyboard(parsed.buttons);
  if (ctx.event?.source === 'test') {
    return { replies: [{ type: 'markdown', markdown: { content: md }, ...(keyboard ? { keyboard } : {}) }] };
  }
  const m = ctx.message;
  if (ctx.api?.reply && m && (m.kind === 'group' || m.kind === 'c2c')) {
    const body = { msg_type: 2, markdown: { content: md } };
    if (keyboard) body.keyboard = keyboard;
    try {
      const res = await ctx.api.reply(m, body);
      if (res?.ok) {
        if (keyboard) r.log.info(`VloS 按钮消息已发送（${parsed.buttons.length} 个按钮）`);
        return null;
      }
      if (keyboard) {
        // 自定义按钮需要开放平台开通，没权限/不支持时退回纯 Markdown，至少把文字发出去
        r.log.warn(`VloS 按钮消息发送失败（code=${res?.code || ''} ${res?.message || ''}），改为纯 Markdown 重发`);
        const res2 = await ctx.api.reply(m, { msg_type: 2, markdown: { content: md } });
        if (res2?.ok) return null;
        r.log.warn(`VloS Markdown 回复失败（不降级）：${res2?.code || ''} ${res2?.message || ''}`);
        return null;
      }
      r.log.warn(`VloS Markdown 回复失败（不降级）：${res?.code || ''} ${res?.message || ''}`);
    } catch (e) {
      r.log.warn('VloS Markdown 回复异常（不降级）：' + (e?.message || e));
    }
  }
  return null;
}

function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label}超时（${Math.round(ms / 1000)} 秒）`)), Math.max(1000, ms));
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

function cleanMoney(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.floor(n);
}

/**
 * 结算文案：把「本次掉落」「上次VloS余额」「实际入账」三者说清楚，避免
 * `+127（含VloS余额 45）` 被误读成「127 之外还有 45」。
 * - 入账成功且含VloS余额：`+127（本次 82 + VloS余额 45）`
 * - 入账成功无VloS余额：  `+82`
 * - 入账失败有本次：  `+82（本次，已存入 VloS余额）`
 * - 入账失败仅旧VloS余额：`+0（VloS余额 45 待入账）`
 */
function creditText(credited, current, carry) {
  const got = cleanMoney(credited);
  const now = cleanMoney(current);
  const old = cleanMoney(carry);
  if (got > 0) {
    return old > 0
      ? `+${T.formatNumber(got)}（本次 ${T.formatNumber(now)} + VloS余额 ${T.formatNumber(old)}）`
      : `+${T.formatNumber(got)}`;
  }
  if (now > 0) return `+${T.formatNumber(now)}（本次，已存入 VloS余额）`;
  if (old > 0) return `+0（VloS余额 ${T.formatNumber(old)} 待入账）`;
  return '+0';
}

/* ======================= 导出 ======================= */

module.exports = {
  onLoad,
  onEvent,
  onUnload,
  __test: {
    rollDrops,
    creditText,
    normalizeCmd,
    identityKeys,
    formatArkLine,
    arknightsApi,
    pickPoem,
    activePoemFile,
    templateVars,
    renderTemplate,
    withImageSize,
    normalizeQqMarkdown,
    syncMenus,
    handleGroupEvent,
    guardGroupMessage,
    judgeJoinRequest,
    isGroupAdmin,
    resolveGroupRole,
    GROUP_ADMIN_ROLES,
    joinVerifyPending,
    joinVerifyClicks,
    handleJoinVerifyMessage,
    buildGroupAdminHtml,
    effectiveGuard,
    effectiveWelcome,
    reviewSnapshot,
    buildReviewHtml,
    applyReviewPayload,
    autoApprovable,
    pollCallbacks,
    reviewNoticeText,
    qqCmdTag,
    matchCommandAction,
    cmdLabel,
    usersSnapshot,
    refreshUsersSnapshot,
    commandDefaultsSnapshot,
    refreshCommandDefaultsSnapshot,
    DEFAULT_COMMAND_REPLIES,
    extractButtons,
    buildKeyboard,
    buildVerifyKeyboard,
    buildArknightsKeyboard,
    judgeArknightsClick,
    handleInteractionEvent,
    judgeCustomAnswer,
    handleVerifyTimeout,
    resetPoemCache() {
      poemCache = { file: '', mtimeMs: 0, lines: [] };
    },
    reset() {
      try {
        api.unbind();
      } catch {
        /* ignore */
      }
      if (rt?.snapshotTimer) clearTimeout(rt.snapshotTimer);
      menuSyncAt.clear();
      botJoinRetries.clear();
      rt = null;
      signing.clear();
      authFlows.clear();
      bindFlows.clear();
      joinVerifyPending.forEach(function (entry) { if (entry && entry.timer) clearTimeout(entry.timer); });
      joinVerifyPending.clear();
      joinVerifyClicks.clear();
      menuSyncAt.clear();
      poemCache = { file: '', mtimeMs: 0, lines: [] };
    },
    getRuntime: () => rt,
    getFlows: () => ({ authFlows, bindFlows }),
  },
  version: PLUGIN_VERSION,
};
