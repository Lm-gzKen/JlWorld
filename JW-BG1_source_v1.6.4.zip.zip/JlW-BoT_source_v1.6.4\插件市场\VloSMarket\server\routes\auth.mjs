// 认证路由：注册、邮箱密码登录、重置密码、登出、当前用户。
// 账户体系走聚龙世界新接口（https://www.jlworld.net/api/plugin/jl-account/）。
// 本站不保存账户密码和聚龙 token，只签发自己的会话 Cookie。
import { HttpError } from '../http.mjs';
import { attachCookie, dropCookie, COOKIE } from '../session.mjs';
import { publicUser } from '../roles.mjs';

const EMAIL_RE = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

// 发送验证码的内存冷却（聚龙接口本身也有 60 秒冷却，这里再挡一层）
const codeSentAt = new Map();
function cooldown(key, seconds) {
  const now = Date.now();
  const last = codeSentAt.get(key) || 0;
  const left = Math.ceil((last + seconds * 1000 - now) / 1000);
  if (left > 0) throw new HttpError(429, `验证码刚发送过，请 ${left} 秒后再试`);
  codeSentAt.set(key, now);
}

// 自动登录接口的 IP 限流：5 分钟最多 10 次，避免被拿来撞库
const autoLoginHits = new Map();
function autoLoginLimit(ip) {
  const now = Date.now();
  const key = String(ip || 'unknown');
  let rec = autoLoginHits.get(key);
  if (!rec || now - rec.start > 5 * 60 * 1000) {
    rec = { start: now, count: 0 };
    autoLoginHits.set(key, rec);
  }
  rec.count += 1;
  if (rec.count > 10) throw new HttpError(429, '登录尝试过于频繁，请 5 分钟后再试');
  if (autoLoginHits.size > 5000) {
    for (const [k, v] of autoLoginHits) if (now - v.start > 10 * 60 * 1000) autoLoginHits.delete(k);
  }
}

export function maskMail(mail) {
  const s = String(mail || '');
  const at = s.indexOf('@');
  if (at <= 0) return s || '（未知）';
  const name = s.slice(0, at);
  const domain = s.slice(at);
  const keep = name.length <= 2 ? name.slice(0, 1) : name.slice(0, 2);
  return `${keep}${'*'.repeat(Math.max(1, Math.min(4, name.length - keep.length)))}${domain}`;
}

function firstStr(...vals) {
  for (const v of vals) {
    const t = String(v == null ? '' : v).trim();
    if (t) return t;
  }
  return '';
}

/** 聚龙账户返回的头像字段名不完全固定，这里做一次兼容取值 */
function avatarOf(data) {
  const u = (data && data.user) || {};
  const url = firstStr(data && data.avatar, data && data.headimg, data && data.face, u.avatar, u.headimg, u.face);
  return /^https?:\/\//i.test(url) ? url.slice(0, 500) : '';
}

function upsertUser(store, mail, data) {
  const now = Date.now();
  const email = String(mail || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) throw new HttpError(400, '账户邮箱格式不正确');
  const nickname = String((data && data.name) || '').trim().slice(0, 40);
  const avatar = avatarOf(data);
  const u = (data && data.user) || {};
  const qq = firstStr(data && data.qq, data && data.QQ, u.qq, u.QQ).slice(0, 20);
  const openid = firstStr(data && data.openid, u.openid).slice(0, 80);

  const old = store.get('SELECT * FROM users WHERE email = ?', email);
  if (!old) {
    store.run(
      'INSERT INTO users (email, nickname, qq, openid, avatar, jlw_created, first_seen, last_login) VALUES (?,?,?,?,?,?,?,?)',
      email,
      nickname,
      qq,
      openid,
      avatar,
      '',
      now,
      now
    );
  } else {
    store.run(
      'UPDATE users SET nickname=?, qq=?, openid=?, avatar=?, last_login=? WHERE email=?',
      nickname || old.nickname || '',
      qq || old.qq || '',
      openid || old.openid || '',
      avatar || old.avatar || '',
      now,
      email
    );
  }
  return store.get('SELECT * FROM users WHERE email = ?', email);
}

function login(c, email, data) {
  const user = upsertUser(c.store, email, data);
  const { token, expires } = c.newSession(user.email);
  attachCookie(c.res, token, expires, !!c.cookieSecure);
  return publicUser(c.store, user);
}

export default function register(router) {
  router.get('/api/auth/methods', (c) => ({
    siteName: c.cfg.siteName,
    officialSite: c.cfg.officialSite,
    password: true,
    register: true,
    reset: true,
    accountApi: c.cfg.vlosBase,
    maxUploadMB: Number(c.cfg.maxUploadMB) || 32,
  }));

  router.get('/api/me', (c) => {
    if (!c.user) return { user: null };
    const unread = c.store.get(
      "SELECT COUNT(*) AS n FROM messages WHERE to_email=? AND is_read=0 AND kind NOT IN ('review','report','devreply','role')",
      c.user.email
    );
    return { user: publicUser(c.store, c.user), unread: unread ? unread.n : 0 };
  });

  // ---- 注册：发送邮箱验证码 ----
  router.post('/api/auth/register/send', async (c) => {
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    if (!EMAIL_RE.test(mail)) throw new HttpError(400, '邮箱格式不正确');
    cooldown('reg:' + mail + ':' + c.ip, c.cfg.codeCooldownSec);
    const r = await c.jlw.sendCode(mail, 'register');
    if (!r.ok) throw new HttpError(400, r.msg);
    return { ok: true, msg: r.data.message || '验证码已发送，10 分钟内有效', mail, cooldown: r.data.cooldown || 60 };
  });

  // ---- 注册：邮箱验证码 + 昵称 + 密码 ----
  router.post('/api/auth/register/confirm', async (c) => {
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    const code = String(b.code || '').trim();
    const password = String(b.password || '');
    const name = String(b.name || '').trim();
    if (!EMAIL_RE.test(mail)) throw new HttpError(400, '邮箱格式不正确');
    if (!/^\d{6}$/.test(code)) throw new HttpError(400, '请填写 6 位邮箱验证码');
    if (password.length < 6) throw new HttpError(400, '密码至少 6 位');
    if (name.length < 2 || name.length > 20) throw new HttpError(400, '昵称需要 2–20 个字');

    const r = await c.jlw.register(mail, code, password, name);
    if (!r.ok) throw new HttpError(400, r.msg);
    const u = (r.data && r.data.user) || {};
    const userName = u.name || name;
    return { ok: true, user: login(c, mail, { ...u, name: userName }), msg: '注册成功，已自动登录' };
  });

  // ---- 登录：邮箱 + 密码 ----
  router.post('/api/auth/login/password', async (c) => {
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!mail || !password) throw new HttpError(400, '请填写邮箱和密码');
    const r = await c.jlw.login(mail, password);
    if (!r.ok) throw new HttpError(400, r.msg);
    const u = (r.data && r.data.user) || {};
    return { ok: true, user: login(c, mail, { ...u, name: u.name || '' }), msg: '登录成功' };
  });

  // ---- 自动登录 API：一次调用完成「账号 + 密码 + 登录」，返回会话 Cookie ----
  // 给外部系统 / 脚本用；文档在「开发者中心 → 管理员 → 登录接口」里。
  router.post('/api/auth/auto-login', async (c) => {
    autoLoginLimit(c.ip);
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!mail || !password) throw new HttpError(400, '请填写邮箱和密码');

    const r = await c.jlw.login(mail, password);
    if (!r.ok) throw new HttpError(400, r.msg);
    const u = (r.data && r.data.user) || {};
    const user = login(c, mail, { ...u, name: u.name || '' });

    // 传了站内相对路径就 302 跳转（适合浏览器链接 / iframe），否则返回 JSON
    const redirect = typeof b.redirect === 'string' ? b.redirect : '';
    if (redirect.startsWith('/') && !redirect.startsWith('//')) {
      c.res.writeHead(302, { Location: redirect.slice(0, 300), 'Cache-Control': 'no-store' });
      c.res.end();
      return null;
    }
    return { ok: true, user, msg: '登录成功' };
  });

  // ---- 忘记密码：发送重置验证码 ----
  router.post('/api/auth/password/send', async (c) => {
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    if (!EMAIL_RE.test(mail)) throw new HttpError(400, '邮箱格式不正确');
    cooldown('reset:' + mail + ':' + c.ip, c.cfg.codeCooldownSec);
    const r = await c.jlw.sendCode(mail, 'reset');
    if (!r.ok) throw new HttpError(400, r.msg);
    return { ok: true, msg: r.data.message || '验证码已发送，10 分钟内有效', mail, cooldown: r.data.cooldown || 60 };
  });

  // ---- 忘记密码：验证码 + 新密码（成功后自动登录）----
  router.post('/api/auth/password/reset', async (c) => {
    const b = await c.json();
    const mail = String(b.mail || '').trim().toLowerCase();
    const code = String(b.code || '').trim();
    const password = String(b.password || '');
    if (!EMAIL_RE.test(mail)) throw new HttpError(400, '邮箱格式不正确');
    if (!/^\d{6}$/.test(code)) throw new HttpError(400, '请填写 6 位邮箱验证码');
    if (password.length < 6) throw new HttpError(400, '密码至少 6 位');

    const r = await c.jlw.resetPassword(mail, code, password);
    if (!r.ok) throw new HttpError(400, r.msg);
    const u = (r.data && r.data.user) || {};
    return { ok: true, user: login(c, mail, { ...u, name: u.name || '' }), msg: '密码已重置，已自动登录' };
  });

  router.post('/api/auth/logout', (c) => {
    const token = c.cookieToken();
    if (token) c.store.run('DELETE FROM sessions WHERE token = ?', token);
    dropCookie(c.res);
    return { ok: true };
  });

  router.get('/api/auth/cookie-name', () => ({ name: COOKIE }));
}
