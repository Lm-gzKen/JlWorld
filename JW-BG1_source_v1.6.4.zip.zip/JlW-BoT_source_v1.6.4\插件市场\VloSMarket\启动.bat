@echo off
rem ============================================================
rem  JlW-BoT Market Launcher (Windows)
rem  Just double-click this file.
rem ============================================================
chcp 936 >nul
cd /d "%~dp0"
title JlW-BoT Market

set "NODE_EXE="
for %%i in (node.exe) do set "NODE_EXE=%%~$PATH:i"

if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined NODE_EXE if exist "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe" set "NODE_EXE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not defined NODE_EXE if exist "D:\BT\BtSoft\nodejs" for /d %%v in ("D:\BT\BtSoft\nodejs\*") do if exist "%%~v\node.exe" set "NODE_EXE=%%~v\node.exe"
if not defined NODE_EXE if exist "D:\BtSoft\nodejs" for /d %%v in ("D:\BtSoft\nodejs\*") do if exist "%%~v\node.exe" set "NODE_EXE=%%~v\node.exe"

if not defined NODE_EXE (
  echo.
  echo   [ERROR] Node.js not found.
  echo   Please install Node.js 22.5 or newer from https://nodejs.org/
  echo.
  pause
  exit /b 1
)

echo.
echo   Node: %NODE_EXE%
echo.

"%NODE_EXE%" "server\launch.mjs" --open
set "CODE=%ERRORLEVEL%"

if not "%CODE%"=="0" (
  echo.
  echo   [ERROR] Server exited with code %CODE%.
  echo.
  pause
)
