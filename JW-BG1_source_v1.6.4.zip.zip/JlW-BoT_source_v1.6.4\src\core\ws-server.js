'use strict';
/**
 * 极简 WebSocket 服务端（RFC6455），用于面板实时推送
 * 不依赖任何第三方库
 */
const crypto = require('crypto');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 2 * 1024 * 1024;

class Client {
  constructor(hub, socket) {
    this.hub = hub;
    this.socket = socket;
    this.id = crypto.randomBytes(6).toString('hex');
    this.alive = true;
    this.buffer = Buffer.alloc(0);
    this.fragments = [];
    this.closed = false;
    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('close', () => this._gone());
    socket.on('error', () => this._gone());
  }

  _gone() {
    if (this.closed) return;
    this.closed = true;
    this.hub.clients.delete(this);
  }

  send(obj) {
    if (this.closed) return;
    const data = Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj), 'utf8');
    this._frame(0x1, data);
  }

  _frame(opcode, payload) {
    try {
      const len = payload.length;
      let header;
      if (len < 126) {
        header = Buffer.alloc(2);
        header[0] = 0x80 | opcode;
        header[1] = len;
      } else if (len < 65536) {
        header = Buffer.alloc(4);
        header[0] = 0x80 | opcode;
        header[1] = 126;
        header.writeUInt16BE(len, 2);
      } else {
        header = Buffer.alloc(10);
        header[0] = 0x80 | opcode;
        header[1] = 127;
        header.writeBigUInt64BE(BigInt(len), 2);
      }
      this.socket.write(Buffer.concat([header, payload]));
    } catch {
      this._gone();
    }
  }

  _onData(chunk) {
    // 手写帧解析：任何畸形帧都只能断开这个客户端，不能把整个进程带崩
    try {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      while (true) {
        const buf = this.buffer;
        if (buf.length < 2) return;
        const fin = (buf[0] & 0x80) !== 0;
        const opcode = buf[0] & 0x0f;
        const masked = (buf[1] & 0x80) !== 0;
        let len = buf[1] & 0x7f;
        let offset = 2;
        if (len === 126) {
          if (buf.length < 4) return;
          len = buf.readUInt16BE(2);
          offset = 4;
        } else if (len === 127) {
          if (buf.length < 10) return;
          const big = buf.readBigUInt64BE(2);
          if (big > BigInt(MAX_PAYLOAD)) return this.close(1009);
          len = Number(big);
          offset = 10;
        }
        if (len > MAX_PAYLOAD) return this.close(1009);
        let maskKey = null;
        if (masked) {
          if (buf.length < offset + 4) return;
          maskKey = buf.subarray(offset, offset + 4);
          offset += 4;
        }
        if (buf.length < offset + len) return;
        let payload = buf.subarray(offset, offset + len);
        if (masked) {
          const out = Buffer.allocUnsafe(len);
          for (let i = 0; i < len; i++) out[i] = payload[i] ^ maskKey[i & 3];
          payload = out;
        }
        this.buffer = buf.subarray(offset + len);
        this._onFrame(fin, opcode, payload);
      }
    } catch (e) {
      this.hub.log?.warn?.('WS 帧解析失败，断开该连接：' + (e?.message || e));
      this.close(1002);
    }
  }

  _onFrame(fin, opcode, payload) {
    switch (opcode) {
      case 0x0: // continuation
        this.fragments.push(Buffer.from(payload));
        if (fin) {
          const full = Buffer.concat(this.fragments);
          this.fragments = [];
          this._onText(full);
        }
        break;
      case 0x1: // text
        if (fin) this._onText(payload);
        else this.fragments = [Buffer.from(payload)];
        break;
      case 0x2: // binary
        if (fin) this._onText(payload);
        else this.fragments = [Buffer.from(payload)];
        break;
      case 0x8: // close
        this.close(1000);
        break;
      case 0x9: // ping
        this._frame(0xA, payload);
        break;
      case 0xA: // pong
        this.alive = true;
        break;
      default:
        break;
    }
  }

  _onText(buf) {
    let msg;
    try {
      msg = JSON.parse(buf.toString('utf8'));
    } catch {
      return;
    }
    this.hub._emitMessage({ client: this, msg });
  }

  close(code = 1000) {
    if (this.closed) return;
    try {
      const body = Buffer.alloc(2);
      body.writeUInt16BE(code, 0);
      this._frame(0x8, body);
      this.socket.end();
    } catch {
      /* ignore */
    }
    this._gone();
  }
}

class WsHub {
  constructor({ server, logger, path: wsPath = '/ws', auth }) {
    this.server = server;
    this.log = logger.child('ws');
    this.path = wsPath;
    this.auth = auth || (() => true);
    this.clients = new Set();
    this.handlers = new Set();
    this.connectHandlers = new Set();
    server.on('upgrade', (req, socket, head) => this._upgrade(req, socket, head));
    this._timer = setInterval(() => this._ping(), 30000);
    if (this._timer.unref) this._timer.unref();
  }

  onMessage(fn) {
    this.handlers.add(fn);
    return () => this.handlers.delete(fn);
  }

  onConnect(fn) {
    this.connectHandlers.add(fn);
    return () => this.connectHandlers.delete(fn);
  }

  _emitMessage(payload) {
    for (const fn of this.handlers) {
      try {
        fn(payload);
      } catch (e) {
        this.log.warn('WS 消息处理异常: ' + e.message);
      }
    }
  }

  _emitConnect(client) {
    for (const fn of this.connectHandlers) {
      try {
        fn(client);
      } catch (e) {
        this.log.warn('WS 连接处理异常: ' + e.message);
      }
    }
  }

  _upgrade(req, socket, head) {
    // 升级阶段就要挂 error 监听：握手写失败会产生 'error'，没人接就会变成未捕获异常
    socket.on('error', () => {});
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname !== this.path) {
        socket.destroy();
        return;
      }
      if (!this.auth(req, url)) {
        socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
        socket.destroy();
        return;
      }
      const key = req.headers['sec-websocket-key'];
      if (!key) {
        socket.destroy();
        return;
      }
      const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
      socket.write(
        'HTTP/1.1 101 Switching Protocols\r\n' +
          'Upgrade: websocket\r\n' +
          'Connection: Upgrade\r\n' +
          `Sec-WebSocket-Accept: ${accept}\r\n\r\n`,
      );
      const client = new Client(this, socket);
      this.clients.add(client);
      this._emitConnect(client);
      if (head && head.length) client._onData(head);
    } catch (e) {
      this.log.warn('WS 升级失败: ' + e.message);
      try {
        socket.destroy();
      } catch {
        /* ignore */
      }
    }
  }

  _ping() {
    for (const c of this.clients) {
      if (!c.alive) {
        c.close(1001);
        continue;
      }
      c.alive = false;
      c._frame(0x9, Buffer.alloc(0));
    }
  }

  broadcast(obj) {
    const data = typeof obj === 'string' ? obj : JSON.stringify(obj);
    for (const c of this.clients) c.send(data);
  }

  count() {
    return this.clients.size;
  }

  close() {
    clearInterval(this._timer);
    for (const c of this.clients) c.close(1001);
    this.clients.clear();
  }
}

module.exports = WsHub;
