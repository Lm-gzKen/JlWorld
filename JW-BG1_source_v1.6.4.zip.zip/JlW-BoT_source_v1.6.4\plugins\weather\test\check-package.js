'use strict';
/**
 * 交付包自检：按框架「导入插件」的同一套规矩检查 zip，避免打完包才发现导不进去。
 *
 *   node plugins/weather/test/check-package.js "插件\天气查询-【v1.0.0】.zip"
 *
 * 检查项（对齐 src/core/server.js 的 readZipPackage / unzipEntries）：
 *   - EOCD 存在、不是 ZIP64、没有加密条目、压缩方式只有 store/deflate
 *   - 条目名可安全规范化（没有 .. / 盘符），单文件 ≤18MB、总计 ≤60MB
 *   - plugin.json 在根目录或单层子目录，且只有一份；能 JSON.parse
 *   - plugin.json 的 id / version 与包名「名称-【v版本】.zip」对得上
 *   - 关键文件齐全；包内不带运行期数据（data/subs.json）和日志
 */
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const MAX_FILE = 18 * 1024 * 1024;
const MAX_TOTAL = 60 * 1024 * 1024;

let pass = 0;
let fail = 0;
const ok = (cond, name, extra) => {
  if (cond) {
    pass++;
    console.log('  ✓ ' + name + (extra ? '（' + extra + '）' : ''));
  } else {
    fail++;
    console.log('  ✗ ' + name + (extra ? ' —— ' + extra : ''));
  }
  return !!cond;
};

function cleanRel(name) {
  const s = String(name || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const parts = s.split('/').filter((p) => p && p !== '.');
  if (!parts.length || parts.some((p) => p === '..' || p.includes(':'))) throw new Error('路径不合法：' + s);
  return parts.join('/');
}

function readZip(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('不是有效的 zip');
  const sig = 0x06054b50;
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === sig) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('找不到 EOCD（不是 zip）');
  const count = buf.readUInt16LE(eocd + 10);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  if (count === 0xffff || cdOffset === 0xffffffff) throw new Error('ZIP64 不支持');
  let p = cdOffset;
  const out = [];
  let total = 0;
  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('中央目录损坏');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const uncompSize = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOffset = buf.readUInt32LE(p + 42);
    const rawName = buf.slice(p + 46, p + 46 + nameLen);
    const name = (flags & 0x800 ? rawName.toString('utf8') : rawName.toString('utf8')).replace(/\\/g, '/');
    p += 46 + nameLen + extraLen + commentLen;
    if (name.endsWith('/')) continue;
    if (flags & 1) throw new Error('加密条目不支持：' + name);
    if (compSize === 0xffffffff || uncompSize === 0xffffffff || localOffset === 0xffffffff) throw new Error('ZIP64 不支持：' + name);
    if (uncompSize > MAX_FILE) throw new Error('单文件超过 18MB：' + name);
    if (localOffset + 30 > buf.length || buf.readUInt32LE(localOffset) !== 0x04034b50) throw new Error('本地头损坏：' + name);
    const lnameLen = buf.readUInt16LE(localOffset + 26);
    const lextraLen = buf.readUInt16LE(localOffset + 28);
    const start = localOffset + 30 + lnameLen + lextraLen;
    if (start + compSize > buf.length) throw new Error('数据不完整：' + name);
    const raw = buf.slice(start, start + compSize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) data = zlib.inflateRawSync(raw, { maxOutputLength: MAX_FILE });
    else throw new Error('不支持的压缩方式 ' + method + '：' + name);
    total += data.length;
    if (total > MAX_TOTAL) throw new Error('解压后总大小超过 60MB');
    out.push({ rel: cleanRel(name), buf: data });
  }
  return out;
}

function main() {
  const file = process.argv[2];
  if (!file) {
    console.error('用法：node plugins/weather/test/check-package.js "插件\\天气查询-【v1.0.0】.zip"');
    process.exit(2);
  }
  const abs = path.resolve(file);
  console.log('· 检查 ' + abs);
  ok(fs.existsSync(abs), '文件存在');
  if (!fs.existsSync(abs)) return finish();

  const stat = fs.statSync(abs);
  ok(stat.size < MAX_TOTAL, '包大小合理', (stat.size / 1024).toFixed(1) + ' KB');

  let entries;
  try {
    entries = readZip(fs.readFileSync(abs));
    ok(true, 'zip 结构合法（无 ZIP64 / 无加密 / store+deflate）', entries.length + ' 个文件');
  } catch (e) {
    ok(false, 'zip 结构合法', e.message);
    return finish();
  }

  const manifests = entries.filter((f) => /(^|\/)plugin\.json$/i.test(f.rel) && f.rel.split('/').length <= 2);
  ok(manifests.length === 1, 'plugin.json 只有一份且在根目录或单层子目录', manifests.map((m) => m.rel).join(','));
  if (manifests.length !== 1) return finish();

  const mf = manifests[0];
  const root = mf.rel === 'plugin.json' ? '' : mf.rel.slice(0, -'plugin.json'.length).replace(/\/$/, '');
  ok(root === '', 'zip 根目录就是插件目录（导入后是 ~JlWBoT/plugins/<id>/）', root ? '多了一层 ' + root + '/' : '根目录');

  let manifest = null;
  try {
    manifest = JSON.parse(mf.buf.toString('utf8'));
    ok(true, 'plugin.json 是合法 JSON');
  } catch (e) {
    ok(false, 'plugin.json 是合法 JSON', e.message);
    return finish();
  }

  ok(manifest.id === 'weather', 'plugin.json id = weather', String(manifest.id));
  ok(manifest.type === 'js', 'plugin.json type = js', String(manifest.type));
  ok(/^\d+\.\d+\.\d+$/.test(String(manifest.version || '')), 'version 形如 x.y.z', String(manifest.version));

  const base = path.basename(abs);
  const m = base.match(/【v([^】]+)】/);
  ok(!!m, '文件名带版本号（名称-【v版本】.zip）', base);
  if (m) ok(m[1] === String(manifest.version), '文件名版本 = plugin.json version', `${m[1]} vs ${manifest.version}`);
  ok(base.startsWith(String(manifest.name)) || base.includes(String(manifest.name)), '文件名带插件名', base);

  const rel = (p) => (root ? root + '/' + p : p);
  const need = ['index.js', 'plugin.json', 'README.md', 'settings.html', 'api.html', 'data/cities.json', 'lib/render.ps1'];
  const rels = new Set(entries.map((e) => e.rel));
  for (const f of need) ok(rels.has(rel(f)), '包含 ' + f);
  for (const f of ['lib/cities.js', 'lib/weather.js', 'lib/store.js', 'lib/texts.js', 'lib/card.js', 'lib/media.js', 'lib/sender.js']) ok(rels.has(rel(f)), '包含 ' + f);
  for (const f of ['test/run.js', 'test/e2e.js', 'test/check-web.js', 'test/check-package.js']) ok(rels.has(rel(f)), '包含 ' + f);

  const junk = entries.filter((e) => /(^|\/)(subs\.json|.*\.log|.*\.tmp|node_modules\/)/.test(e.rel));
  ok(junk.length === 0, '不带运行期数据/日志/依赖目录', junk.map((j) => j.rel).join(','));

  const tokens = entries.filter((e) => /plugin\.json$/.test(e.rel) && /"token"\s*:/.test(e.buf.toString('utf8')));
  ok(tokens.length === 0, 'plugin.json 里没有泄漏令牌');

  const id = manifest.id;
  ok(!entries.some((e) => e.rel.startsWith('data/subs.json')), '空数据：不带用户的订阅记录');
  console.log(`\n  包内 ${entries.length} 个文件，解压后 ${(entries.reduce((s, e) => s + e.buf.length, 0) / 1024).toFixed(1)} KB，装好后目录为 ~JlWBoT/plugins/${id}/`);
  finish();
}

function finish() {
  console.log('\n' + '─'.repeat(58));
  if (fail) {
    console.log(`失败 ${fail} 项 / 通过 ${pass} 项`);
    process.exitCode = 1;
  } else {
    console.log(`全部通过 ✅（${pass} 项）`);
  }
}

main();
