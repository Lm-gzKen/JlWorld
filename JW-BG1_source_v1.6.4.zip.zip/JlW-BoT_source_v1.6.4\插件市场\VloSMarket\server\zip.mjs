// 极简 ZIP 读写（零第三方依赖）。
//   readZipDir / readZipEntry —— 只读中央目录 + 按需解压单个条目（解析名称、版本、包内文件列表）
//   makeZip                   —— 打包（旧数据迁移时把老的文件打包成 zip；上传时直接存原包，不重新打包）
// 支持 store(0) / deflate(8)，遇到 ZIP64 / 分卷包给出明确中文错误。
import zlib from 'node:zlib';

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

export function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

const SIG_EOCD = 0x06054b50;
const SIG_CEN = 0x02014b50;
const SIG_LOC = 0x04034b50;

/** Windows 自带「发送到压缩文件夹」打出来的中文名通常不带 UTF-8 标志，需要按 GBK 解码 */
function decodeName(bytes, utf8) {
  if (utf8) return bytes.toString('utf8');
  if (bytes.some((b) => b >= 0x80)) {
    try {
      return new TextDecoder('gbk').decode(bytes);
    } catch {
      /* 没有 ICU 时退回 UTF-8 */
    }
  }
  return bytes.toString('utf8');
}

export function readZipDir(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('文件太小，不是有效的 zip');
  let eocd = -1;
  const min = Math.max(0, buf.length - 65557);
  for (let i = buf.length - 22; i >= min; i--) {
    if (buf.readUInt32LE(i) === SIG_EOCD) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('不是有效的 zip 文件（找不到中央目录）');

  const disk = buf.readUInt16LE(eocd + 4);
  const cdDisk = buf.readUInt16LE(eocd + 6);
  const count = buf.readUInt16LE(eocd + 10);
  const cdSize = buf.readUInt32LE(eocd + 12);
  const cdOff = buf.readUInt32LE(eocd + 16);
  if (disk !== 0 || cdDisk !== 0) throw new Error('不支持分卷压缩包');
  if (count === 0xffff || cdOff === 0xffffffff || cdSize === 0xffffffff) {
    throw new Error('暂不支持 ZIP64 超大压缩包，请重新打包');
  }
  if (cdOff + cdSize > buf.length) throw new Error('zip 目录越界，文件可能已损坏');

  const entries = [];
  let p = cdOff;
  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== SIG_CEN) throw new Error('zip 中央目录损坏');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20);
    const usize = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const offset = buf.readUInt32LE(p + 42);
    if (flags & 0x1) throw new Error('这个 zip 有密码，请解压后重新打包成无密码的 zip');
    if (csize === 0xffffffff || usize === 0xffffffff || offset === 0xffffffff) {
      throw new Error('暂不支持 ZIP64 超大压缩包，请重新打包');
    }
    if (p + 46 + nameLen > buf.length) throw new Error('zip 中央目录损坏');
    const name = decodeName(buf.subarray(p + 46, p + 46 + nameLen), !!(flags & 0x800)).replace(/\\/g, '/');
    entries.push({
      name,
      size: usize,
      compressedSize: csize,
      method,
      offset,
      dir: name.endsWith('/'),
    });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return { entries, count };
}

export function readZipEntry(buf, entry) {
  const p = entry.offset;
  if (p + 30 > buf.length || buf.readUInt32LE(p) !== SIG_LOC) throw new Error('zip 条目损坏：' + entry.name);
  const nameLen = buf.readUInt16LE(p + 26);
  const extraLen = buf.readUInt16LE(p + 28);
  const start = p + 30 + nameLen + extraLen;
  const data = buf.subarray(start, start + entry.compressedSize);
  if (entry.method === 0) return Buffer.from(data);
  if (entry.method === 8) return zlib.inflateRawSync(data, { maxOutputLength: 8 * 1024 * 1024 });
  throw new Error(`不支持的压缩算法（${entry.method}）：${entry.name}`);
}

/** files: [{ name, data:Buffer }] → Buffer */
export function makeZip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const f of files) {
    const name = Buffer.from(String(f.name).replace(/\\/g, '/'), 'utf8');
    const data = Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data);
    const crc = crc32(data);
    const packed = zlib.deflateRawSync(data, { level: 6 });
    const store = packed.length >= data.length;
    const body = store ? data : packed;
    const method = store ? 0 : 8;

    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(SIG_LOC, 0);
    lh.writeUInt16LE(20, 4); // version needed
    lh.writeUInt16LE(0x800, 6); // 名字是 UTF-8
    lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(0, 10); // time
    lh.writeUInt16LE(0x21, 12); // date: 1980-01-01
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(body.length, 18);
    lh.writeUInt32LE(data.length, 22);
    lh.writeUInt16LE(name.length, 26);
    lh.writeUInt16LE(0, 28);
    locals.push(lh, name, body);

    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(SIG_CEN, 0);
    ch.writeUInt16LE(0x0314, 4); // made by unix
    ch.writeUInt16LE(20, 6);
    ch.writeUInt16LE(0x800, 8);
    ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(0, 12);
    ch.writeUInt16LE(0x21, 14);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(body.length, 20);
    ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(name.length, 28);
    ch.writeUInt16LE(0, 30);
    ch.writeUInt16LE(0, 32);
    ch.writeUInt16LE(0, 34);
    ch.writeUInt16LE(0, 36);
    ch.writeUInt32LE(0, 38);
    ch.writeUInt32LE(offset, 42);
    centrals.push(ch, name);

    offset += lh.length + name.length + body.length;
  }

  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(SIG_EOCD, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...locals, cd, end]);
}
