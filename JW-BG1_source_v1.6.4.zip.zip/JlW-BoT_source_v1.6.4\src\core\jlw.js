'use strict';
/**
 * 聚龙账户登录（只支持聚龙账户插件接口）
 *
 *   POST {baseUrl}{apiPath}/login  {email,password} -> {ok,token,user}
 *   POST {baseUrl}{apiPath}/me     {token}          -> {ok,user}
 *   POST {baseUrl}{apiPath}/logout {token}          -> {ok}
 *
 * 只在服务端调用，浏览器/前端不接触账户密码与 token。
 */
const http = require('http');
const https = require('https');
const VERSION = require('../../package.json').version;

class JlwError extends Error {
  constructor(message, code) {
    super(message);
    this.code = code || 'JLW_ERROR';
  }
}

const TRANSIENT_NETWORK_CODES = new Set([
  'ECONNRESET',
  'EPIPE',
  'ETIMEDOUT',
  'ECONNREFUSED',
  'EAI_AGAIN',
  'ENETUNREACH',
  'EHOSTUNREACH',
]);

function isTransientNetworkError(e) {
  if (!e || e.code !== 'NETWORK') return false;
  const networkCode = String(e.networkCode || '');
  if (TRANSIENT_NETWORK_CODES.has(networkCode)) return true;
  return /ECONNRESET|socket disconnected|连接.*重置|无法连接聚龙账户服务|连接聚龙账户服务超时/.test(
    String(e.message || ''),
  );
}

class JlwClient {
  constructor({ config, logger }) {
    this.config = config;
    this.log = logger.child('jlw');
  }

  cfg() {
    return this.config.jlw();
  }

  normalizeBase(input) {
    let s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    s = s.replace(/\/+$/, '');
    // 允许直接粘贴完整接口地址：https://站点/api/plugin/jl-account[/]
    s = s.replace(/\/api\/plugin\/jl-account$/i, '');
    return s.replace(/\/+$/, '');
  }

  /**
   * 校验站点地址。指向本机的站点在正式包里一定连不上（旧配置常见），
   * 直接给出可操作的提示，而不是把 ECONNRESET 抛给用户。
   */
  assertBase(input) {
    const base = this.normalizeBase(input);
    if (!base) throw new JlwError('还没有配置聚龙账户站点地址', 'NO_BASE');
    let host = '';
    try {
      host = new URL(base).hostname.toLowerCase().replace(/^\[|\]$/g, '');
    } catch {
      throw new JlwError('聚龙账户站点地址格式不正确：' + base, 'BAD_BASE');
    }
    if (['127.0.0.1', 'localhost', '::1', '0.0.0.0'].includes(host) && process.env.JLW_ALLOW_LOCAL_SITE !== '1') {
      throw new JlwError(`聚龙账户站点地址指向本机（${base}），请在设置里改成 https://www.jlworld.net`, 'BAD_BASE');
    }
    return base;
  }

  _apiPath() {
    const p = this.cfg().apiPath || '/api/plugin/jl-account';
    return p.startsWith('/') ? p : '/' + p;
  }

  _endpoint(path) {
    const cfg = this.cfg();
    return this.assertBase(cfg.baseUrl) + path;
  }

  _request(method, urlStr, opts = {}) {
    return this._requestWithRetry(method, urlStr, opts, 2);
  }

  _requestWithRetry(method, urlStr, opts, retries) {
    return this._requestOnce(method, urlStr, opts).catch((e) => {
      if (retries <= 0 || !isTransientNetworkError(e)) throw e;
      const delay = retries === 2 ? 300 : 800;
      return new Promise((resolve) => setTimeout(resolve, delay)).then(() =>
        this._requestWithRetry(method, urlStr, opts, retries - 1),
      );
    });
  }

  _requestOnce(method, urlStr, { body, headers } = {}) {
    const cfg = this.cfg();
    const url = new URL(urlStr);
    const mod = url.protocol === 'http:' ? http : https;
    const payload = body === undefined ? null : JSON.stringify(body);
    const h = {
      Accept: 'application/json',
      'User-Agent': `JlWBoT/${VERSION}`,
      Connection: 'close',
      ...(payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {}),
      ...(headers || {}),
    };
    return new Promise((resolve, reject) => {
      let done = false;
      const req = mod.request(
        url,
        {
          method,
          /* 不复用 keep-alive：服务端 5 秒关空闲连接，复用旧 socket 偶发 ECONNRESET */
          agent: false,
          headers: h,
          timeout: cfg.timeoutMs,
          // 站点用自签名证书时需在设置里显式开启
          rejectUnauthorized: !cfg.insecureTls,
        },
        (res) => {
          let text = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => {
            text += chunk;
            if (text.length > 1024 * 1024) {
              done = true;
              req.destroy(new JlwError('账户服务返回内容过大', 'TOO_LARGE'));
            }
          });
          res.on('end', () => {
            if (done) return;
            let json = null;
            try {
              json = JSON.parse(text);
            } catch {
              /* 非 JSON */
            }
            resolve({ status: res.statusCode, json, text });
          });
        },
      );
      req.on('timeout', () => {
        done = true;
        const err = new JlwError('连接聚龙账户服务超时', 'NETWORK');
        err.networkCode = 'ETIMEDOUT';
        req.destroy(err);
      });
      req.on('error', (e) => {
        if (done) return;
        done = true;
        if (e instanceof JlwError) reject(e);
        else {
          const err = new JlwError('无法连接聚龙账户服务：' + (e.code || e.message), 'NETWORK');
          err.networkCode = e.code || '';
          reject(err);
        }
      });
      if (payload) req.write(payload);
      req.end();
    });
  }

  _errorFrom(res, fallback) {
    const j = res.json || {};
    const msg = j.error || j.msg || j.message || (j.code ? `接口返回 code=${j.code}` : '') || fallback || `HTTP ${res.status}`;
    return new JlwError(String(msg), j.code || ('HTTP_' + res.status));
  }

  _absAvatar(u) {
    if (!u || !u.avatar) return u;
    if (/^https?:\/\//i.test(u.avatar)) return u;
    if (u.avatar.startsWith('/')) return { ...u, avatar: this.cfg().baseUrl + u.avatar };
    return u;
  }

  async login(email, password) {
    const cfg = this.cfg();
    if (!cfg.baseUrl) throw new JlwError('还没有配置聚龙账户站点地址', 'NO_BASE');
    if (!email || !password) throw new JlwError('请输入邮箱和密码', 'BAD_INPUT');

    const res = await this._request('POST', this._endpoint(this._apiPath() + '/login'), {
      body: { email, password },
    });
    if (res.status !== 200 || !res.json || res.json.ok !== true) {
      throw this._errorFrom(res, '登录失败');
    }
    const user = this._absAvatar({ ...(res.json.user || {}) });
    if (user.email) user.email = String(user.email).toLowerCase();
    this.log.info('聚龙账户登录成功', { id: user.id, name: user.name });
    return { token: res.json.token || '', user, provider: { baseUrl: cfg.baseUrl } };
  }

  /** 发送邮箱验证码：purpose = register | reset */
  async sendCode(email, purpose = 'register') {
    if (!email) throw new JlwError('请先填写邮箱', 'BAD_INPUT');
    const res = await this._request('POST', this._endpoint(this._apiPath() + '/send-code'), {
      body: { email, purpose: purpose === 'reset' ? 'reset' : 'register', website: '' },
    });
    if (res.status !== 200 || !res.json || res.json.ok !== true) throw this._errorFrom(res, '验证码发送失败');
    return {
      cooldown: Number(res.json.cooldown) || 60,
      expiresIn: Number(res.json.expiresIn) || 10,
      message: res.json.message || '验证码已发送',
    };
  }

  /** 注册并直接登录 */
  async register({ email, code, password, name }) {
    const res = await this._request('POST', this._endpoint(this._apiPath() + '/register'), {
      body: { email, code, password, name, website: '' },
    });
    if (res.status !== 200 || !res.json || res.json.ok !== true) throw this._errorFrom(res, '注册失败');
    let token = res.json.token || '';
    let user = res.json.user ? this._absAvatar({ ...res.json.user }) : null;
    if (!token) {
      // 个别版本注册接口不返回 token：用邮箱密码再登录一次
      const l = await this.login(email, password);
      token = l.token;
      user = user || l.user;
    } else if (!user) {
      user = await this.me(token);
    }
    this.log.info('聚龙账户注册成功', { id: user?.id, email });
    return { token, user, provider: { baseUrl: this.cfg().baseUrl } };
  }

  /** 用邮箱验证码重置密码，成功后直接登录 */
  async resetPassword({ email, code, password }) {
    const res = await this._request('POST', this._endpoint(this._apiPath() + '/reset-password'), {
      body: { email, code, password },
    });
    if (res.status !== 200 || !res.json || res.json.ok !== true) throw this._errorFrom(res, '重置密码失败');
    this.log.info('聚龙账户密码已重置', { email });
    return this.login(email, password);
  }

  async me(token) {
    if (!token) throw new JlwError('当前登录方式不支持刷新资料', 'NO_TOKEN');
    const res = await this._request('POST', this._endpoint(this._apiPath() + '/me'), { body: { token } });
    if (res.status !== 200 || !res.json || res.json.ok !== true) throw this._errorFrom(res, '读取资料失败');
    return this._absAvatar({ ...(res.json.user || {}) });
  }

  async logout(token) {
    if (!token) return;
    try {
      await this._request('POST', this._endpoint(this._apiPath() + '/logout'), { body: { token } });
    } catch (e) {
      this.log.debug('上游 logout 失败（忽略）: ' + e.message);
    }
  }

  /** 测试站点与接口是否可达（临时套用参数，不落盘） */
  async test(overrides = {}) {
    const cfg = { ...this.cfg(), ...overrides };
    const base = this.assertBase(cfg.baseUrl);
    const saved = this.config.data.jlw ? JSON.parse(JSON.stringify(this.config.data.jlw)) : {};
    this.config.data.jlw = { ...saved, ...cfg, baseUrl: base };
    try {
      const res = await this._request('POST', base + (cfg.apiPath || '/api/plugin/jl-account') + '/me', {
        body: { token: 'probe' },
      });
      if (res.status === 404 && !res.json) throw new JlwError('接口不存在（确认站点地址与接口路径）', 'NOT_FOUND');
      if (!res.json) throw new JlwError('返回内容不是 JSON，可能地址填错', 'BAD_RESPONSE');
      return { ok: true, message: '已连通聚龙账户接口' };
    } finally {
      this.config.data.jlw = saved;
    }
  }
}

module.exports = JlwClient;
module.exports.JlwError = JlwError;
