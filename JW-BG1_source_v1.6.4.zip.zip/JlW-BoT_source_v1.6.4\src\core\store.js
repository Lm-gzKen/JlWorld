'use strict';
/**
 * 存储门面：按 storage.engine 分发到 SQLite（db.js）或 JSON/JSONL（json-store.js）。
 * 默认 sqlite；切换引擎时用 migrateTo() 迁移历史数据。
 */
const fs = require('fs');
const path = require('path');
const U = require('./util');
const db = require('./db');
const jsonStore = require('./json-store');

let engine = 'sqlite';

function setEngine(e) {
  engine = e === 'json' ? 'json' : 'sqlite';
}

function getEngine() {
  return engine;
}

function backend() {
  return engine === 'json' ? jsonStore : db;
}

function clearJsonl(dir, prefixes) {
  try {
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith('.jsonl')) continue;
      if (prefixes.some((p) => f.startsWith(p + '-'))) {
        try {
          fs.unlinkSync(path.join(dir, f));
        } catch {
          /* ignore */
        }
      }
    }
  } catch {
    /* ignore */
  }
}

/** SQLite → JSON/JSONL（供切换引擎用） */
function exportDbToJson() {
  const logsDir = U.p('logs');
  const dataDir = U.p('data');
  U.ensureDir(logsDir);
  U.ensureDir(dataDir);
  clearJsonl(logsDir, ['jlwbot']);
  clearJsonl(dataDir, ['messages']);
  let logs = 0;
  let messages = 0;
  for (const d of db.logDates()) {
    const lines = db.logsAll(d.date).map((l) =>
      JSON.stringify({ t: l.t, time: l.time, level: l.level, scope: l.scope, msg: l.msg, meta: l.meta }),
    );
    fs.writeFileSync(path.join(logsDir, `jlwbot-${d.date}.jsonl`), lines.join('\n') + (lines.length ? '\n' : ''), 'utf8');
    logs += lines.length;
  }
  for (const d of db.messageDates()) {
    const lines = db.messagesAll(d.date).map((m) =>
      JSON.stringify({
        t: m.t,
        time: m.time,
        event: m.event,
        direction: m.direction,
        kind: m.kind,
        id: m.id,
        content: m.content,
        author: m.author,
        name: m.name,
        accountId: m.accountId,
        accountName: m.accountName,
        group_openid: m.group_openid,
        user_openid: m.user_openid,
        channel_id: m.channel_id,
        guild_id: m.guild_id,
        attachments: m.attachments,
        payload: m.payload,
      }),
    );
    fs.writeFileSync(path.join(dataDir, `messages-${d.date}.jsonl`), lines.join('\n') + (lines.length ? '\n' : ''), 'utf8');
    messages += lines.length;
  }
  const sessions = {};
  for (const s of db.sessionLoadAll()) sessions[s.sid] = s;
  U.writeJson(path.join(dataDir, 'sessions.json'), sessions);
  return { logs, messages, sessions: Object.keys(sessions).length };
}

/** JSON/JSONL → SQLite（供切换引擎用） */
function importJsonToDb() {
  db.resetAll();
  db.importFromJson(true);
  return {
    logs: db.logDates().reduce((a, b) => a + b.count, 0),
    messages: db.messageDates().reduce((a, b) => a + b.count, 0),
    sessions: db.sessionLoadAll().length,
  };
}

function migrateTo(target) {
  const from = engine;
  const to = target === 'json' ? 'json' : 'sqlite';
  if (from === to) return { ok: true, from, to, migrated: false };
  if (to === 'json') return { ok: true, from, to, migrated: true, counts: exportDbToJson() };
  return { ok: true, from, to, migrated: true, counts: importJsonToDb() };
}

module.exports = {
  setEngine,
  getEngine,
  migrateTo,
  kvGet: (...a) => backend().kvGet(...a),
  kvGetWithTime: (...a) => backend().kvGetWithTime(...a),
  kvSet: (...a) => backend().kvSet(...a),
  insertLog: (...a) => backend().insertLog(...a),
  logsByDay: (...a) => backend().logsByDay(...a),
  logDates: (...a) => backend().logDates(...a),
  logCount: (...a) => backend().logCount(...a),
  insertMessage: (...a) => backend().insertMessage(...a),
  messagesByDay: (...a) => backend().messagesByDay(...a),
  messageDates: (...a) => backend().messageDates(...a),
  sessionLoadAll: (...a) => backend().sessionLoadAll(...a),
  sessionSaveAll: (...a) => backend().sessionSaveAll(...a),
  pruneLogs: (...a) => backend().pruneLogs(...a),
  pruneMessages: (...a) => backend().pruneMessages(...a),
  checkpoint: () => backend().checkpoint(),
  close: () => {
    try {
      db.close();
    } catch {
      /* ignore */
    }
    try {
      jsonStore.close();
    } catch {
      /* ignore */
    }
  },
  dayOf: (...a) => db.dayOf(...a),
};
