// 上传包解析：从一个 .zip 里读出「插件名称 / 版本号 / 包内文件清单」。
// 解析顺序：包内清单文件 → 压缩包文件名 → 包内 .dll 文件名 → 兜底。
import path from 'node:path';
import { readZipDir, readZipEntry } from './zip.mjs';

const MAX_MANIFEST = 512 * 1024; // 清单文件最大读 512KB，避免压缩炸弹
const MAX_ENTRIES = 500; // 入库/返回的包内文件条数上限

// 常见的手写清单文件名（按优先级）。package.json 放最后，避免把源码工程的元数据当插件信息。
const MANIFESTS = [
  'plugin.json',
  'manifest.json',
  'info.json',
  'plugin.ini',
  'manifest.ini',
  '插件信息.json',
  '插件信息.txt',
  'version.txt',
  '版本.txt',
  'package.json',
];

const VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,31}$/;

/** 清单文本可能是 UTF-8，也可能是 GBK（Windows 记事本），能解哪个用哪个 */
function decodeText(buf) {
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {}
  try {
    return new TextDecoder('gbk').decode(buf);
  } catch {}
  return buf.toString('utf8');
}

function cleanName(v) {
  return String(v == null ? '' : v)
    .replace(/\.(dll|zip|exe)$/i, '')
    .replace(/\s+/g, ' ')
    .replace(/^[\s._-]+|[\s._-]+$/g, '')
    .trim()
    .slice(0, 60);
}

function cleanVersion(v) {
  const s = String(v == null ? '' : v)
    .trim()
    .replace(/^[vV]/, '')
    .trim();
  return VERSION_RE.test(s) ? s : '';
}

/** 从「名称_1.2.3」「名称-v1.2」「名称(1.2)」这类文件名里拆出名字和版本 */
export function splitNameVersion(raw) {
  const base = String(raw || '')
    .replace(/\.(zip|dll)$/i, '')
    .trim();
  const pats = [
    /^(.*?)[\s._-]+[vV]?(\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.]+)?)$/,
    /^(.*?)[\s._-]*[vV](\d+(?:\.\d+){0,3})$/,
    /^(.*?)[\s._-]*[（(](\d+(?:\.\d+){1,3})[)）]$/,
    /^(.*?[\u4e00-\u9fa5A-Za-z])(\d+(?:\.\d+){1,3})$/,
  ];
  for (const re of pats) {
    const m = re.exec(base);
    if (m && cleanName(m[1])) return { name: cleanName(m[1]), version: cleanVersion(m[2]) };
  }
  return { name: cleanName(base), version: '' };
}

function pick(obj, keys) {
  if (!obj || typeof obj !== 'object') return '';
  for (const k of keys) {
    const v = obj[k];
    if (v != null && String(v).trim()) return String(v).trim();
  }
  const lower = new Map(Object.keys(obj).map((k) => [k.toLowerCase(), k]));
  for (const k of keys) {
    const real = lower.get(k.toLowerCase());
    if (real && obj[real] != null && String(obj[real]).trim()) return String(obj[real]).trim();
  }
  return '';
}

function parseManifestText(text) {
  const t = String(text || '').replace(/^\uFEFF/, '').trim();
  if (!t) return { name: '', version: '' };
  if (t.startsWith('{') || t.startsWith('[')) {
    try {
      const j = JSON.parse(t);
      const o = Array.isArray(j) ? j[0] : j;
      return {
        name: pick(o, ['name', 'pluginName', 'plugin_name', 'title', '插件名', '名称']),
        version: pick(o, ['version', 'ver', 'pluginVersion', '版本', '插件版本']),
      };
    } catch {
      /* 不是合法 JSON，继续按 key=value 解析 */
    }
  }
  const kv = {};
  for (const line of t.split(/\r?\n/)) {
    const m = /^\s*([^=:#;[\]]{1,40})\s*[=:]\s*(.+?)\s*$/.exec(line);
    if (m) kv[m[1].trim().toLowerCase()] = m[2].trim();
  }
  const get = (...keys) => {
    for (const k of keys) if (kv[k]) return kv[k];
    return '';
  };
  return {
    name: get('name', 'pluginname', 'plugin', 'title', '插件名', '名称'),
    version: get('version', 'ver', '插件版本', '版本'),
  };
}

const depthOf = (name) => name.split('/').filter(Boolean).length;

/**
 * 解析上传的 zip。
 * @param {Buffer} buf 完整 zip 内容
 * @param {string} filename 原始文件名（只用于猜名字/版本）
 */
export function parsePackage(buf, filename) {
  const dir = readZipDir(buf);
  const files = dir.entries.filter((e) => !e.dir);
  if (!files.length) throw new Error('压缩包里没有文件');

  const totalSize = files.reduce((a, e) => a + (e.size || 0), 0);
  const entryCount = files.length;

  // ---- 1) 找清单文件（只看浅层，避免读源码深处的 package.json）----
  let meta = { name: '', version: '', source: '' };
  for (const want of MANIFESTS) {
    const hit = files.find(
      (e) => depthOf(e.name) <= 2 && path.posix.basename(e.name).toLowerCase() === want.toLowerCase()
    );
    if (!hit) continue;
    if (hit.size > MAX_MANIFEST) continue;
    let text = '';
    try {
      text = decodeText(readZipEntry(buf, hit));
    } catch {
      continue;
    }
    const got = parseManifestText(text);
    if (got.name || got.version) {
      meta = { name: cleanName(got.name), version: cleanVersion(got.version), source: path.posix.basename(hit.name) };
      break;
    }
  }

  // ---- 2) 压缩包自己的文件名 ----
  const fromZip = splitNameVersion(String(filename || '').replace(/\.zip$/i, ''));

  // ---- 3) 包内的 .dll ----
  const dlls = files
    .filter((e) => /\.dll$/i.test(e.name))
    .sort((a, b) => depthOf(a.name) - depthOf(b.name) || a.name.localeCompare(b.name));
  const dll = dlls[0] || null;
  const fromDll = dll ? splitNameVersion(path.posix.basename(dll.name)) : { name: '', version: '' };

  const name = cleanName(meta.name || fromZip.name || fromDll.name) || '未命名插件';
  const version = meta.version || fromZip.version || fromDll.version || '1.0.0';
  const sources = {
    name: meta.name ? 'manifest' : fromZip.name ? 'filename' : fromDll.name ? 'dll' : 'fallback',
    version: meta.version ? 'manifest' : fromZip.version ? 'filename' : fromDll.version ? 'dll' : 'fallback',
    manifest: meta.source,
  };

  const warnings = [];
  if (!dll) warnings.push('压缩包里没有 .dll 文件，JlW-BoT 可能加载不了这个插件');
  if (dlls.length > 1) warnings.push(`包里有 ${dlls.length} 个 .dll，已取最外层的 ${path.posix.basename(dll.name)} 作为插件本体`);
  if (entryCount > 3000) warnings.push(`包内文件较多（${entryCount} 个），下载后解压即可`);

  const entries = files
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'))
    .slice(0, MAX_ENTRIES)
    .map((e) => ({ name: e.name, size: e.size }));

  return {
    name,
    version,
    entryCount,
    totalSize,
    hasDll: !!dll,
    dllName: dll ? path.posix.basename(dll.name) : '',
    dlls: dlls.slice(0, 12).map((e) => e.name),
    entries,
    truncated: entryCount > MAX_ENTRIES,
    sources,
    warnings,
  };
}
