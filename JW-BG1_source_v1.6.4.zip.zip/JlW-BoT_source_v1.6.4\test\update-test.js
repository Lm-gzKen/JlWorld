'use strict';
/**
 * 在线更新回归：
 *   - 更新页解析（版本 / 下载地址 / 大小）
 *   - 版本比较
 *   - 从本地假页面下载 zip
 *   - 独立更新器解压、保留 ~JlWBoT、覆盖并重启
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawnSync } = require('child_process');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-update-'));
process.env.JLW_DATA_DIR = path.join(tmp, 'data');
fs.mkdirSync(process.env.JLW_DATA_DIR, { recursive: true });

const Updater = require('../src/core/updater');
const { parseUpdatePage, compareVersions } = Updater;
const ROOT = path.join(__dirname, '..');

const results = [];
function check(ok, msg) {
  results.push({ ok, msg });
  console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
}

/* ---------- 最小 ZIP 写入（store，够测试用） ---------- */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function makeZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const { name, data } of entries) {
    const nameBuf = Buffer.from(name, 'utf8');
    const body = Buffer.from(data);
    const crc = crc32(body);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(body.length, 18);
    local.writeUInt32LE(body.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, nameBuf, body);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(0x800, 8);
    cd.writeUInt16LE(0, 10);
    cd.writeUInt16LE(0, 12);
    cd.writeUInt16LE(0, 14);
    cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(body.length, 20);
    cd.writeUInt32LE(body.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt16LE(0, 30);
    cd.writeUInt16LE(0, 32);
    cd.writeUInt16LE(0, 34);
    cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(0, 38);
    cd.writeUInt32LE(offset, 42);
    centrals.push(cd, nameBuf);
    offset += 30 + nameBuf.length + body.length;
  }
  const cdBuf = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cdBuf, eocd]);
}

(async () => {
  const html = `<!doctype html><html><body>
    <div class="yz-dl is-card">
      <div class="yz-dl-body">
        <div class="yz-dl-name">JlW-BoT [v9.9.9].zip</div>
        <div class="yz-dl-meta">35 MB · 已下载 2 次</div>
      </div>
      <a class="yz-btn yz-btn-sm yz-dl-btn" href="/download/update.zip">下载</a>
    </div>
  </body></html>`;
  const parsed = parseUpdatePage(html, 'https://www.jlworld.net/QQBOT');
  check(parsed.latest === '9.9.9', '解析页面版本号 v9.9.9');
  check(parsed.url === 'https://www.jlworld.net/download/update.zip', '解析页面下载地址');
  check(parsed.sizeText === '35 MB', '解析更新包大小');
  check(compareVersions('1.3.2', '1.3.1') > 0, '版本比较 1.3.2 > 1.3.1');
  check(compareVersions('1.3.2-beta', '1.3.2') < 0, '预发布版本低于正式版');
  check(Updater.isAllowedDownload('https://www.jlworld.net/download/x', 'https://www.jlworld.net/QQBOT'), '允许聚龙域名下载');
  check(!Updater.isAllowedDownload('https://example.com/x.zip', 'https://www.jlworld.net/QQBOT'), '拒绝非聚龙域名下载');

  const newFiles = {
    'JlW-BoT/package.json': JSON.stringify({ name: 'jlwbot', version: '9.9.9' }, null, 2),
    'JlW-BoT/config.default.json': JSON.stringify({ server: { port: 8686 } }, null, 2),
    'JlW-BoT/src/index.js':
      "require('fs').writeFileSync(require('path').join(__dirname, '..', 'restarted.txt'), 'ok');\n",
    'JlW-BoT/src/keep.js': 'module.exports = 1;\n',
  };
  const zipBuf = makeZip(Object.entries(newFiles).map(([name, data]) => ({ name, data })));

  const server = http.createServer((req, res) => {
    if (req.url === '/QQBOT') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(html);
    }
    if (req.url === '/download/update.zip') {
      res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': zipBuf.length });
      return res.end(zipBuf);
    }
    res.writeHead(404);
    res.end('no');
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const pageUrl = `http://127.0.0.1:${port}/QQBOT`;

  const updater = new Updater({ pageUrl });
  const info = await updater.check(true);
  check(info.ok && info.latest === '9.9.9' && info.hasUpdate === true, '检查更新发现 9.9.9');
  const dl = await updater.download(info);
  check(fs.existsSync(dl.file) && fs.statSync(dl.file).size === zipBuf.length, '下载更新包到 ~JlWBoT/updates');

  /* ---------- 独立更新器：解压覆盖 + 保留数据 + 重启 ---------- */
  if (process.platform === 'win32') {
    const install = path.join(tmp, 'install');
    fs.mkdirSync(path.join(install, 'src'), { recursive: true });
    fs.mkdirSync(path.join(install, '~JlWBoT'), { recursive: true });
    fs.writeFileSync(path.join(install, 'src', 'index.js'), '// old\n');
    fs.writeFileSync(path.join(install, 'package.json'), JSON.stringify({ name: 'jlwbot', version: '1.0.0' }, null, 2));
    fs.writeFileSync(path.join(install, 'config.default.json'), '{}');
    fs.writeFileSync(path.join(install, '~JlWBoT', 'config.json'), '{"keep":true}');

    const updaterScript = path.join(ROOT, 'src', 'core', 'update-apply.js');
    const logFile = path.join(tmp, 'update.log');
    const argsB64 = Buffer.from(JSON.stringify(['--no-open']), 'utf8').toString('base64');
    const run = spawnSync(
      process.execPath,
      [
        updaterScript,
        '--pid',
        '0',
        '--zip',
        dl.file,
        '--root',
        install,
        '--node',
        process.execPath,
        '--version',
        '9.9.9',
        '--args-b64',
        argsB64,
        '--log',
        logFile,
      ],
      { encoding: 'utf8', timeout: 120000 },
    );
    check(run.status === 0, '独立更新器执行成功');
    check(fs.readFileSync(path.join(install, 'src', 'index.js'), 'utf8').includes('restarted.txt'), 'src/index.js 已覆盖');
    check(JSON.parse(fs.readFileSync(path.join(install, 'package.json'), 'utf8')).version === '9.9.9', 'package.json 版本已更新');
    check(fs.readFileSync(path.join(install, '~JlWBoT', 'config.json'), 'utf8').includes('keep'), '~JlWBoT 用户数据保留');
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline && !fs.existsSync(path.join(install, 'restarted.txt'))) await new Promise((r) => setTimeout(r, 100));
    check(fs.existsSync(path.join(install, 'restarted.txt')), '更新后新进程已启动');
    if (run.status !== 0) console.log(run.stdout, run.stderr);
  } else {
    console.log('  SKIP  非 Windows，跳过解压/重启测试');
  }

  server.close();
  const failed = results.filter((x) => !x.ok);
  console.log(`\n${results.length - failed.length}/${results.length} 通过`);
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
