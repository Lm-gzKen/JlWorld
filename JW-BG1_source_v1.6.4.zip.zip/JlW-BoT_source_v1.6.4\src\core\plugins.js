'use strict';
/**
 * 插件系统
 *
 * type:
 *   js      —— 进程内 JS 插件（性能最好，直接调用框架 API）
 *   http    —— 框架把事件 POST 给插件（易语言自建 HTTP 后端）
 *   pull    —— 插件长轮询拉取事件（易语言最省事的接法，只需 HTTP 客户端）
 *   process —— 框架自动拉起插件进程（易语言 EXE 后端），配合 pull/http 传输
 *   dll     —— 框架拉起「易语言 DLL 宿主」，宿主加载你的 32 位易语言 DLL
 *
 * 事件投递统一 JSON，插件回包统一 { reply | replies | actions | stop }
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const U = require('./util');

const MANIFEST = 'plugin.json';
const VALID_TYPES = new Set(['js', 'http', 'pull', 'process', 'dll']);

class PluginManager {
  constructor({ config, logger, api, endpoints }) {
    this.config = config;
    this.logger = logger;
    this.rootLogger = logger;
    this.log = logger.child('plugins');
    this.api = api;
    this.endpoints = endpoints;
    this.dir = U.p('plugins');
    this.registry = new Map();
    this.host = null;
    this.startedAt = Date.now();
    this._waiters = new Map(); // pluginId -> [{resolve, timer}]
    U.ensureDir(this.dir);
  }

  attach(host) {
    this.host = host;
  }

  _botFor(evt) {
    if (!this.host) return null;
    return this.host.botFor(evt?.accountId) || this.host.defaultBot();
  }

  get token() {
    let t = this.config.get('plugins.token');
    if (!t) {
      t = U.randomToken(24);
      this.config.set('plugins.token', t);
      this.config.save();
    }
    return t;
  }

  rotateToken() {
    const t = U.randomToken(24);
    this.config.set('plugins.token', t);
    this.config.save();
    this.log.warn('插件令牌已重置，外部插件需要更新令牌');
    return t;
  }

  checkToken(t) {
    return !!t && U.safeEqual(t, this.token);
  }

  /* ---------------- 加载 ---------------- */

  async init() {
    this._seedSamples();
    await this.reloadAll();
  }

  _seedSamples(force = false) {
    const seedDir = path.join(U.ROOT, 'plugins');
    if (!fs.existsSync(seedDir)) return;
    const marker = path.join(this.dir, '.seeded');
    if (!force && fs.existsSync(marker)) return;
    try {
      for (const name of fs.readdirSync(seedDir)) {
        const src = path.join(seedDir, name);
        if (!fs.statSync(src).isDirectory()) continue;
        const dst = path.join(this.dir, name);
        if (fs.existsSync(dst)) continue;
        fs.cpSync(src, dst, { recursive: true });
        this.log.info(`已安装示例插件：${name}`);
      }
      fs.writeFileSync(marker, new Date().toISOString() + '\n', 'utf8');
    } catch (e) {
      this.log.warn('复制示例插件失败: ' + e.message);
    }
  }

  async reloadAll() {
    for (const p of this.registry.values()) this._stopRuntime(p);
    this.registry.clear();
    let names = [];
    try {
      names = fs.readdirSync(this.dir);
    } catch {
      return;
    }
    for (const name of names) {
      const dir = path.join(this.dir, name);
      let st;
      try {
        st = fs.statSync(dir);
      } catch {
        continue;
      }
      if (!st.isDirectory()) continue;
      const manifestFile = path.join(dir, MANIFEST);
      if (!fs.existsSync(manifestFile)) continue;
      try {
        const manifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
        manifest.id = sanitizeId(manifest.id || name);
        manifest.name = manifest.name || manifest.id;
        manifest.type = VALID_TYPES.has(manifest.type) ? manifest.type : 'js';
        manifest.enabled = manifest.enabled !== false;
        manifest.priority = Number.isFinite(manifest.priority) ? manifest.priority : 100;
        manifest.events = Array.isArray(manifest.events) && manifest.events.length ? manifest.events : ['*'];
        const plugin = {
          manifest,
          dir,
          id: manifest.id,
          runtime: {
            status: manifest.enabled ? 'idle' : 'disabled',
            child: null,
            queue: [],
            waiters: [],
            lastError: null,
            startedAt: 0,
            stats: { dispatched: 0, errors: 0, timeouts: 0, lastAt: 0, avgMs: 0, totalMs: 0 },
            restarting: false,
          },
        };
        this.registry.set(manifest.id, plugin);
      } catch (e) {
        this.log.error(`插件 ${name} 的 plugin.json 解析失败: ${e.message}`);
      }
    }
    for (const p of [...this.registry.values()].sort((a, b) => a.manifest.priority - b.manifest.priority || a.id.localeCompare(b.id))) {
      if (p.manifest.enabled) await this._startRuntime(p);
    }
    this.log.info(`插件加载完成：${this.registry.size} 个`);
  }

  _startRuntime(p) {
    try {
      if (p.manifest.type === 'js') {
        this._loadJS(p);
      } else if (p.manifest.type === 'process' || p.manifest.type === 'dll') {
        this._spawn(p);
      } else {
        p.runtime.status = 'running';
        p.runtime.startedAt = Date.now();
      }
    } catch (e) {
      p.runtime.status = 'error';
      p.runtime.lastError = e.message;
      this.log.error(`插件 ${p.id} 启动失败: ${e.message}`);
    }
  }

  _stopRuntime(p) {
    p.runtime.stopping = true;
    try {
      if (p.manifest.type === 'js' && p.runtime.module?.onUnload) {
        Promise.resolve(p.runtime.module.onUnload(this._ctx(p))).catch(() => {});
      }
    } catch {
      /* ignore */
    }
    if (p.runtime.child) {
      try {
        p.runtime.child.kill();
      } catch {
        /* ignore */
      }
    }
    p.runtime.child = null;
    p.runtime.queue = [];
    for (const w of p.runtime.waiters || []) {
      clearTimeout(w.timer);
      w.resolve({ ok: true, events: [] });
    }
    p.runtime.waiters = [];
    p.runtime.status = 'disabled';
  }

  _loadJS(p) {
    const entry = path.resolve(p.dir, p.manifest.entry || 'index.js');
    if (!fs.existsSync(entry)) throw new Error(`入口不存在：${entry}`);
    this._clearRequireCache(p.dir);
    const mod = require(entry);
    p.runtime.module = mod.default || mod;
    p.runtime.status = 'running';
    p.runtime.startedAt = Date.now();
    if (typeof p.runtime.module?.onLoad === 'function') {
      Promise.resolve(p.runtime.module.onLoad(this._ctx(p))).catch((e) => {
        this.log.error(`插件 ${p.id} onLoad 异常: ${e.message}`);
      });
    }
  }

  _clearRequireCache(dir) {
    for (const key of Object.keys(require.cache)) {
      if (key.startsWith(dir)) delete require.cache[key];
    }
  }

  _spawn(p) {
    const launch = p.manifest.launch || {};
    if (!launch.command) throw new Error('process/dll 插件缺少 launch.command');
    const command = path.isAbsolute(launch.command) ? launch.command : path.resolve(p.dir, launch.command);
    const args = (launch.args || []).map(String);
    const env = {
      ...process.env,
      JLW_PLUGIN_ID: p.id,
      JLW_PLUGIN_TOKEN: this.token,
      JLW_FRAMEWORK_URL: `http://127.0.0.1:${this.config.get('server.port')}`,
      ...(launch.env || {}),
    };
    if (p.manifest.type === 'dll' && p.manifest.dll?.path) {
      env.JLW_DLL_PATH = path.resolve(p.dir, p.manifest.dll.path);
    }
    const child = spawn(command, args, {
      cwd: launch.cwd ? path.resolve(p.dir, launch.cwd) : p.dir,
      env,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    p.runtime.child = child;
    p.runtime.status = 'starting';
    p.runtime.startedAt = Date.now();
    p.runtime.lastError = null;

    const pipe = (stream, level) => {
      let buf = '';
      stream.setEncoding('utf8');
      stream.on('data', (chunk) => {
        buf += chunk;
        const lines = buf.split(/\r?\n/);
        buf = lines.pop();
        for (const line of lines) if (line.trim()) this.log[level](`[${p.id}] ${line.slice(0, 500)}`);
      });
    };
    pipe(child.stdout, 'info');
    pipe(child.stderr, 'warn');

    child.on('error', (e) => {
      p.runtime.status = 'error';
      p.runtime.lastError = e.message;
      this.log.error(`插件 ${p.id} 进程启动失败: ${e.message}`);
    });

    child.on('exit', (code, signal) => {
      p.runtime.child = null;
      p.runtime.status = p.runtime.stopping ? 'disabled' : 'stopped';
      if (p.runtime.stopping) return;
      this.log.warn(`插件 ${p.id} 进程退出 code=${code} signal=${signal}`);
      if (p.manifest.launch?.restart !== false && p.manifest.enabled) {
        p.runtime.restarting = true;
        const delay = Math.min(30000, 1500 * Math.pow(1.6, Math.min(p.runtime.restarts = (p.runtime.restarts || 0) + 1, 8)));
        setTimeout(() => {
          if (p.manifest.enabled) {
            try {
              this._spawn(p);
            } catch (e) {
              this.log.error(`插件 ${p.id} 重启失败: ${e.message}`);
            }
          }
          p.runtime.restarting = false;
        }, delay).unref?.();
      }
    });

    setTimeout(() => {
      if (p.runtime.child === child && p.runtime.status === 'starting') p.runtime.status = 'running';
    }, 500);

    if (launch.healthUrl) this._waitHealth(p, launch.healthUrl, launch.startTimeout || 15000);
  }

  async _waitHealth(p, url, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (p.runtime.child === null) return;
      try {
        const res = await fetch(url, { signal: AbortSignal.timeout(2000) });
        if (res.ok) {
          p.runtime.status = 'running';
          this.log.info(`插件 ${p.id} 健康检查通过`);
          return;
        }
      } catch {
        /* retry */
      }
      await U.sleep(600);
    }
    p.runtime.lastError = '健康检查超时';
    this.log.warn(`插件 ${p.id} 健康检查超时（${url}）`);
  }

  /* ---------------- 事件分发 ---------------- */

  list() {
    return [...this.registry.values()]
      .map((p) => ({
        id: p.id,
        name: p.manifest.name,
        version: p.manifest.version || '0.0.0',
        author: p.manifest.author || '',
        description: p.manifest.description || '',
        type: p.manifest.type,
        enabled: p.manifest.enabled,
        priority: p.manifest.priority,
        events: p.manifest.events,
        commands: p.manifest.commands || [],
        status: p.runtime.status,
        pid: p.runtime.child?.pid || null,
        lastError: p.runtime.lastError,
        queue: p.runtime.queue.length,
        stats: p.runtime.stats,
        dir: p.dir,
        hasApiDoc: fs.existsSync(path.join(p.dir, 'api.html')),
        hasSettings: fs.existsSync(path.join(p.dir, 'settings.html')),
        config: p.manifest.config || {},
      }))
      .sort((a, b) => a.priority - b.priority || a.id.localeCompare(b.id));
  }

  get(id) {
    return this.registry.get(id) || null;
  }

  _match(p, evt) {
    if (!p.manifest.enabled) return false;
    const events = p.manifest.events || ['*'];
    const name = evt.name || evt.t;
    if (!events.includes('*') && !events.includes(name)) return false;
    const cmds = p.manifest.commands || [];
    if (cmds.length) {
      const c = evt.message?.command?.name;
      if (!c || !cmds.includes(c)) return false;
    }
    return true;
  }

  async dispatch(evt) {
    if (this.config.get('plugins.enabled') === false) return;
    const targets = [...this.registry.values()].filter((p) => this._match(p, evt)).sort((a, b) => a.manifest.priority - b.manifest.priority);
    if (targets.length) {
      this.log.debug(`事件 ${evt.name} 分发给 ${targets.length} 个插件`, { eventId: evt.id, plugins: targets.map((p) => p.id) });
    }
    let stop = false;
    let replied = false;
    for (const p of targets) {
      if (stop) break;
      const t0 = Date.now();
      let result;
      try {
        result = await this._invoke(p, evt);
      } catch (e) {
        p.runtime.stats.errors++;
        p.runtime.lastError = e.message;
        this.log.warn(`插件 ${p.id} 执行异常: ${e.message}`);
        continue;
      }
      const ms = Date.now() - t0;
      this.log.debug(`插件 ${p.id} 处理 ${evt.name} 完成 ${ms}ms`, { eventId: evt.id });
      p.runtime.stats.dispatched++;
      p.runtime.stats.lastAt = Date.now();
      p.runtime.stats.totalMs += ms;
      p.runtime.stats.avgMs = Math.round(p.runtime.stats.totalMs / p.runtime.stats.dispatched);
      if (!result) continue;
      const normalized = normalizeResult(result);
      if (normalized.stop) stop = true;
      if (normalized.log) this.log.info(`[${p.id}] ${normalized.log}`);
      if (normalized.actions.length || normalized.replies.length) {
        try {
          const bot = this._botFor(evt);
          const r = bot ? await bot.applyPluginOutput(p, evt, normalized) : null;
          if (r?.replied) replied = true;
        } catch (e) {
          this.log.warn(`插件 ${p.id} 动作执行失败: ${e.message}`);
        }
      }
    }
    return { replied };
  }

  _ctx(p, evt) {
    const bot = this._botFor(evt);
    return {
      plugin: { id: p.id, dir: p.dir, config: p.manifest.config || {} },
      config: this.config,
      log: this.rootLogger.child('plugin:' + p.id),
      api: bot?.pluginApi?.(p) || null,
      bot: bot?.pluginFacade?.(p) || null,
      account: evt?.account || null,
      framework: { version: require('../../package.json').version, dataDir: U.dataRoot() },
    };
  }

  async _invoke(p, evt) {
    const timeout = Number(p.manifest.timeout) || this.config.get('plugins.defaultTimeoutMs', 8000);
    switch (p.manifest.type) {
      case 'js':
        return this._invokeJS(p, evt, timeout);
      case 'http': {
        if (!p.manifest.url) throw new Error('http 插件缺少 url');
        return this._invokeHttp(p, evt, timeout);
      }
      case 'pull':
      case 'process':
      case 'dll':
        this._enqueue(p, evt);
        return null;
      default:
        return null;
    }
  }

  async _invokeJS(p, evt, timeout) {
    const mod = p.runtime.module;
    if (!mod) throw new Error('插件未加载');
    const fn = mod.onEvent || mod.handle || mod.default;
    const ctx = { ...this._ctx(p, evt), event: evt, message: evt.message, raw: evt.raw };
    if (typeof fn === 'function') return await withTimeout(Promise.resolve(fn.call(mod, ctx)), timeout, p);
    return null;
  }

  async _invokeHttp(p, evt, timeout) {
    const bot = this._botFor(evt);
    const body = JSON.stringify({
      event: {
        name: evt.name,
        id: evt.id,
        ts: evt.ts,
        time: evt.time,
        source: evt.source,
        account: evt.account || null,
      },
      message: evt.message,
      bot: bot?.publicInfo?.() || {},
      plugin: { id: p.id, config: p.manifest.config || {} },
      api: { base: `http://127.0.0.1:${this.config.get('server.port')}`, pull: '/plugin-api/v1/pull', action: '/plugin-api/v1/action' },
      raw: evt.raw,
    });
    const headers = { 'Content-Type': 'application/json', 'X-JlW-Plugin': p.id };
    if (p.manifest.secret) {
      headers['X-JlW-Signature'] = crypto.createHmac('sha256', p.manifest.secret).update(body).digest('hex');
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(p.manifest.url, { method: 'POST', headers, body, signal: controller.signal });
      const text = await res.text();
      if (!res.ok) throw new Error(`HTTP ${res.status} ${text.slice(0, 200)}`);
      if (!text.trim()) return null;
      try {
        const data = JSON.parse(text);
        if (data && typeof data === 'object' && (data.actions || data.reply || data.replies || data.stop)) return data;
        if (data && data.async) return null;
        return data;
      } catch {
        return { reply: text };
      }
    } finally {
      clearTimeout(timer);
    }
  }

  _enqueue(p, evt) {
    const max = this.config.get('plugins.maxQueue', 200);
    if (p.runtime.queue.length >= max) p.runtime.queue.shift();
    p.runtime.seqSeed = (p.runtime.seqSeed || 0) + 1;
    const item = { seq: p.runtime.seqSeed, event: evt, at: Date.now() };
    p.runtime.queue.push(item);
    const waiters = p.runtime.waiters;
    if (waiters.length) {
      const w = waiters.shift();
      clearTimeout(w.timer);
      const batch = p.runtime.queue.splice(0, Math.min(p.runtime.queue.length, 10));
      w.resolve({ ok: true, events: batch.map((x) => this._pullView(p, x)) });
    }
  }

  _pullView(p, item) {
    const evt = item.event;
    return {
      seq: item.seq,
      event: {
        name: evt.name,
        id: evt.id,
        ts: evt.ts,
        time: evt.time,
        source: evt.source,
        account: evt.account || null,
      },
      account: evt.account || null,
      accountId: evt.accountId || null,
      message: evt.message,
      raw: evt.raw,
      plugin: { id: p.id, config: p.manifest.config || {} },
    };
  }

  /** 长轮询：易语言用 网页_访问(超时30秒) 拉取 */
  pull(id, timeoutMs = 25000) {
    const p = this.registry.get(id);
    if (!p) return Promise.resolve({ ok: false, error: 'plugin not found' });
    if (p.runtime.queue.length) {
      const batch = p.runtime.queue.splice(0, Math.min(p.runtime.queue.length, 10));
      return Promise.resolve({ ok: true, events: batch.map((x) => this._pullView(p, x)) });
    }
    return new Promise((resolve) => {
      const waiter = { resolve, timer: null };
      waiter.timer = setTimeout(() => {
        const i = p.runtime.waiters.indexOf(waiter);
        if (i >= 0) p.runtime.waiters.splice(i, 1);
        resolve({ ok: true, events: [] });
      }, Math.min(Math.max(timeoutMs, 1000), 55000));
      p.runtime.waiters.push(waiter);
    });
  }

  /* ---------------- 配置 / 测试 ---------------- */

  async remove(id) {
    const key = sanitizeId(id);
    if (!key) return { ok: false, error: '插件 ID 不合法' };
    const p = this.registry.get(key);
    const root = path.resolve(this.dir);
    const dir = path.resolve(p ? p.dir : path.join(this.dir, key));
    if (dir === root || !dir.startsWith(root + path.sep)) {
      return { ok: false, error: '插件目录不合法' };
    }
    const child = p?.runtime.child;
    if (p) this._stopRuntime(p);
    if (child && child.exitCode === null) {
      await new Promise((resolve) => {
        const timer = setTimeout(resolve, 1500);
        if (timer.unref) timer.unref();
        child.once('exit', () => {
          clearTimeout(timer);
          resolve();
        });
      });
    }
    this.registry.delete(key);
    const existed = fs.existsSync(dir);
    if (existed) {
      try {
        fs.rmSync(dir, { recursive: true, force: true, maxRetries: 4, retryDelay: 150 });
      } catch (e) {
        return { ok: false, error: '删除失败（进程可能仍占用文件）：' + e.message };
      }
    }
    this.log.info(`插件已删除：${key}${existed ? '' : '（目录原本不存在）'}`);
    return { ok: true, id: key, existed };
  }

  async reload(id) {
    if (!id) {
      await this.reloadAll();
      const failed = [...this.registry.values()]
        .filter((p) => p.runtime.status === 'error')
        .map((p) => ({ id: p.id, name: p.manifest.name, error: p.runtime.lastError || '加载失败' }));
      if (failed.length) {
        return {
          ok: false,
          error: failed.map((p) => `${p.name}（${p.id}）：${p.error}`).join('；'),
          errors: failed,
        };
      }
      return { ok: true };
    }
    const p = this.registry.get(id);
    if (!p) return { ok: false, error: '插件不存在' };
    this._stopRuntime(p);
    this.registry.delete(id);
    await this.reloadAll();
    const after = this.registry.get(id);
    if (!after) return { ok: false, error: '重载后未找到插件，请检查 plugin.json' };
    if (after.runtime.status === 'error') {
      return { ok: false, error: after.runtime.lastError || '插件加载失败' };
    }
    return { ok: true };
  }

  async setEnabled(id, enabled) {
    const p = this.registry.get(id);
    if (!p) return { ok: false, error: '插件不存在' };
    const manifest = JSON.parse(fs.readFileSync(path.join(p.dir, MANIFEST), 'utf8'));
    manifest.enabled = !!enabled;
    U.writeJson(path.join(p.dir, MANIFEST), manifest);
    p.manifest.enabled = !!enabled;
    if (!enabled) {
      this._stopRuntime(p);
      p.runtime.status = 'disabled';
    } else {
      try {
        this._startRuntime(p);
      } catch (e) {
        p.runtime.status = 'error';
        p.runtime.lastError = e.message;
      }
    }
    return { ok: true, plugin: this.list().find((x) => x.id === id) };
  }

  saveManifest(id, patch) {
    const p = this.registry.get(id);
    if (!p) return { ok: false, error: '插件不存在' };
    const file = path.join(p.dir, MANIFEST);
    const merged = U.deepMerge(p.manifest, patch);
    U.writeJson(file, merged);
    return { ok: true };
  }

  async test(id, evt) {
    const p = this.registry.get(id);
    if (!p) return { ok: false, error: '插件不存在' };
    const t0 = Date.now();
    if (p.manifest.type === 'pull' || p.manifest.type === 'process' || p.manifest.type === 'dll') {
      this._enqueue(p, evt);
      return { ok: true, queued: true, queue: p.runtime.queue.length, ms: Date.now() - t0 };
    }
    const result = await this._invoke(p, evt);
    return { ok: true, result, ms: Date.now() - t0 };
  }

  info() {
    return {
      enabled: this.config.get('plugins.enabled') !== false,
      dir: this.dir,
      token: this.token,
      count: this.registry.size,
      running: [...this.registry.values()].filter((p) => p.runtime.status === 'running').length,
    };
  }

  /** 退出前停止所有插件进程，避免留下孤儿进程 */
  dispose() {
    for (const p of this.registry.values()) {
      try {
        this._stopRuntime(p);
      } catch {
        /* ignore */
      }
    }
    this.registry.clear();
  }
}

function sanitizeId(id) {
  return String(id || '')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .slice(0, 40);
}

function withTimeout(promise, ms, p) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      p.runtime.stats.timeouts++;
      resolve(null);
    }, ms);
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        p.runtime.stats.errors++;
        reject(e);
      },
    );
  });
}

/** 插件返回值归一化 */
function normalizeResult(result) {
  const out = { replies: [], actions: [], stop: false, log: '' };
  if (result == null) return out;
  if (typeof result === 'string') {
    out.replies.push({ type: 'text', content: result });
    return out;
  }
  if (Array.isArray(result)) {
    for (const r of result) mergeOne(out, r);
    return out;
  }
  mergeOne(out, result);
  return out;
}

function mergeOne(out, r) {
  if (r == null) return;
  if (typeof r === 'string') {
    out.replies.push({ type: 'text', content: r });
    return;
  }
  if (typeof r !== 'object') return;
  if (r.stop) out.stop = true;
  if (typeof r.log === 'string' && r.log) out.log += (out.log ? '\n' : '') + r.log;
  const reply = r.reply ?? r.content;
  if (reply && typeof reply === 'string') out.replies.push({ type: 'text', content: reply });
  if (r.reply && typeof r.reply === 'object') out.replies.push(r.reply);
  if (Array.isArray(r.replies)) {
    for (const x of r.replies) out.replies.push(typeof x === 'string' ? { type: 'text', content: x } : x);
  }
  if (Array.isArray(r.actions)) {
    for (const a of r.actions) if (a && typeof a === 'object') out.actions.push(a);
  }
  if (r.action && typeof r.action === 'object') out.actions.push(r.action);
}

module.exports = PluginManager;
module.exports.normalizeResult = normalizeResult;
module.exports.sanitizeId = sanitizeId;
