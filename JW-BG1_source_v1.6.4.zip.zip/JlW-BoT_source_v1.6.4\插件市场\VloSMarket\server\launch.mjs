// 启动入口：先检查 Node 版本，再动态载入真正的服务。
// 单独拆一层是因为 ESM 的 import 会被提升——若直接在 index.mjs 里 import node:sqlite，
// 在低版本 Node 上只会抛 ERR_UNKNOWN_BUILTIN_MODULE，看不到人话提示。
const MIN = [22, 5, 0];
const cur = process.versions.node.split('.').map(Number);

if (cur[0] < MIN[0] || (cur[0] === MIN[0] && cur[1] < MIN[1])) {
  console.error('');
  console.error(`  ❌ 当前 Node.js 版本是 v${process.versions.node}，本程序需要 v${MIN[0]}.${MIN[1]} 或更高。`);
  console.error('     原因：数据库用了 Node 内置的 node:sqlite，低版本没有这个模块。');
  console.error('');
  console.error('     请到 https://nodejs.org/ 下载安装 LTS 版本后重新运行。');
  console.error('');
  process.exit(1);
}

await import('./index.mjs');
