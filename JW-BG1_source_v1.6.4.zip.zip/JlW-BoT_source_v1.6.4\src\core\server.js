'use strict';
/**
 * Web 服务：面板 + 管理 API + 插件桥 + QQ WebHook 回调（多账户）
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const U = require('./util');
const store = require('./store');
const WsHub = require('./ws-server');
const Updater = require('./updater');
const MarketProxy = require('./market-proxy');
const health = require('./health');
const { normalizeEmail, isValidEmail } = require('./config');

const WEB_DIR = path.join(__dirname, '..', 'web');
const VERSION = require('../../package.json').version;
const LOGIN_FAIL_WINDOW_MS = 60 * 1000;
const LOGIN_FAIL_MAX = 10;
const LOGIN_LOCK_MS = 5 * 60 * 1000;
const MARKET_SID_TTL_MS = 12 * 60 * 60 * 1000;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

class PanelServer {
  constructor(ctx) {
    this.ctx = ctx;
    this.config = ctx.config;
    this.logger = ctx.logger;
    this.log = ctx.logger.child('server');
    this.host = ctx.host;
    this.plugins = ctx.plugins;
    this.endpoints = ctx.endpoints;
    this.webhook = ctx.webhook;
    this.netinfo = ctx.netinfo;
    this.session = ctx.session;
    this.jlw = ctx.jlw;
    this.updater = ctx.updater || new Updater({ config: this.config, logger: this.logger });
    this.marketProxy = new MarketProxy({ logger: this.logger });
    // 面板会话 → 市场 vlos_sid（只在内存，不落盘；登录时用密码换一次）
    this.marketSids = new Map();
    // 聚龙邮箱 → 市场登录态：同一账户重复登录面板时直接复用，不再消耗市场接口的限流额度
    this.marketByMail = new Map();
    this.marketPending = new Map();
    this.marketLoginHits = new Map();
    this.onRestart = typeof ctx.onRestart === 'function' ? ctx.onRestart : null;
    this.onManualRestart = typeof ctx.onManualRestart === 'function' ? ctx.onManualRestart : null;
    this.onConfigChange = typeof ctx.onConfigChange === 'function' ? ctx.onConfigChange : null;
    this.restartSchedule = { enabled: false, minutes: 0, nextAt: 0 };
    this.updateJob = null;
    this.updateStarting = false;
    this.startedAt = Date.now();
    this.loginHits = new Map();
    this.emailHits = new Map();
    this.emailLocks = new Map();
    this.codeHits = new Map();
    this.codeCooldown = new Map();
    this.groupInfoCache = new Map();
    this.routes = [];
    this.server = http.createServer((req, res) => this._dispatch(req, res));
    this._expectedStop = false;
    this._relistenAttempts = 0;
    this._relistenTimer = null;
    this._watchdogMs = Number(ctx.watchdogMs) || 15000;
    this._watchdog = null;
    this.lastServerError = null;
    this._wireServerSafety();
    this.hub = new WsHub({
      server: this.server,
      logger: this.logger,
      path: '/ws',
      auth: (req, url) => this._authed(req, url),
    });
    this._registerRoutes();
    this._wireStreams();
  }

  get port() {
    return Number(this.config.get('server.port', 8686));
  }

  get host_() {
    return this.config.get('server.host', '127.0.0.1');
  }

  url() {
    const h = this.host_ === '0.0.0.0' ? '127.0.0.1' : this.host_;
    return `http://${h}:${this.port}`;
  }

  /* ---------------- 鉴权 ---------------- */

  _sid(req, url) {
    const raw = req.headers.cookie || '';
    for (const part of raw.split(';')) {
      const [k, ...v] = part.trim().split('=');
      if (k === 'jlw_sid') return decodeURIComponent(v.join('='));
    }
    return req.headers['x-jlw-session'] || url?.searchParams?.get('session') || '';
  }

  _sessionOf(req, url) {
    const s = this.session.get(this._sid(req, url));
    if (!s) return null;
    if (!this.config.isLoginAllowed(s.user, s.user?.email)) {
      this.session.destroy(s.sid);
      this._dropMarketSid(s.sid);
      return null;
    }
    return s;
  }

  _authed(req, url) {
    return !!this._sessionOf(req, url);
  }

  _setSessionCookie(res, sid) {
    const days = Math.max(1, this.config.jlw().sessionDays);
    res.setHeader('Set-Cookie', `jlw_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${days * 86400}`);
  }

  _clearSessionCookie(res) {
    res.setHeader('Set-Cookie', 'jlw_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
  }

  _startSession(res, r, ip) {
    const s = this.session.create({
      user: r.user,
      jlwToken: r.token,
      provider: r.provider || { baseUrl: this.config.jlw().baseUrl },
      ip,
    });
    this._setSessionCookie(res, s.sid);
    return s;
  }

  /**
   * 用聚龙账户密码换市场登录态（POST /api/auth/auto-login）。
   * 密码只在这一次请求里用一下，不写入任何配置/日志；拿到的 vlos_sid 只放内存。
   * 失败不抛错：市场页会退回它自己的登录页，不影响面板登录。
   */
  async _marketLogin(sid, mail, password) {
    if (!sid || !mail || !password) return { ok: false, error: '缺少账号或密码' };
    const key = String(mail).trim().toLowerCase();
    const job = this._marketLoginJob(sid, key, password);
    this.marketPending.set(sid, job);
    return job;
  }

  async _marketLoginJob(sid, key, password) {
    try {
      // 同一账户刚登录过：先验证缓存的市场会话是否还有效，有效就直接复用，
      // 不再调市场接口（市场自动登录接口有 10 次 / 5 分钟的 IP 限流）
      const cached = this.marketByMail.get(key);
      if (cached && Date.now() - cached.at < MARKET_SID_TTL_MS) {
        if (await this.marketProxy.checkSession(cached.cookie)) {
          this.marketSids.set(sid, { cookie: cached.cookie, at: Date.now(), mail: key });
          this._pruneMarketSids();
          this.log.info('插件市场沿用已有登录态', { mail: key });
          return { ok: true };
        }
        this.marketByMail.delete(key);
      }
      const r = await this.marketProxy.autoLogin(key, password);
      if (!r || !r.ok || !r.cookie) {
        const error = (r && r.error) || '市场接口没有返回登录态';
        this.log.warn('插件市场自动登录未成功：' + error, { mail: key, status: r && r.status });
        return { ok: false, error };
      }
      const at = Date.now();
      this.marketByMail.set(key, { cookie: r.cookie, at });
      this.marketSids.set(sid, { cookie: r.cookie, at, mail: key });
      this._pruneMarketSids();
      this.log.info('插件市场已随面板自动登录', { mail: key });
      return { ok: true };
    } catch (e) {
      this.log.warn('插件市场自动登录异常：' + e.message, { mail: key });
      return { ok: false, error: e.message };
    } finally {
      this.marketPending.delete(sid);
    }
  }

  /** 市场里主动退出登录（iframe 内点退出）：同步丢掉服务端缓存，避免又把它注入回去 */
  _marketLogout(sid) {
    const hit = sid && this.marketSids.get(sid);
    if (hit) {
      this.marketSids.delete(sid);
      if (hit.mail) this.marketByMail.delete(hit.mail);
      this.log.info('插件市场已退出登录（沿用缓存已清除）', { mail: hit.mail });
    }
    return hit || null;
  }

  /** 市场登录还没回来时等一小会儿，避免内嵌市场先闪一下登录页 */
  async _awaitMarketCookie(sid) {
    const job = sid && this.marketPending.get(sid);
    if (job) await Promise.race([job, new Promise((r) => setTimeout(r, 3000).unref?.())]);
    return this._marketCookie(sid);
  }

  _marketCookie(sid) {
    if (!sid) return '';
    const hit = this.marketSids.get(sid);
    if (!hit) return '';
    if (Date.now() - hit.at > MARKET_SID_TTL_MS) {
      this.marketSids.delete(sid);
      return '';
    }
    return hit.cookie;
  }

  _pruneMarketSids() {
    const now = Date.now();
    for (const [sid, v] of this.marketSids) {
      if (now - v.at > MARKET_SID_TTL_MS) this.marketSids.delete(sid);
    }
    for (const [mail, v] of this.marketByMail) {
      if (now - v.at > MARKET_SID_TTL_MS) this.marketByMail.delete(mail);
    }
    // 内存里最多留 200 个面板会话的市场登录态
    while (this.marketSids.size > 200) {
      const first = this.marketSids.keys().next().value;
      this.marketSids.delete(first);
    }
    while (this.marketByMail.size > 50) {
      const first = this.marketByMail.keys().next().value;
      this.marketByMail.delete(first);
    }
    for (const [sid, arr] of this.marketLoginHits) {
      const keep = arr.filter((t) => now - t < 5 * 60 * 1000);
      if (keep.length) this.marketLoginHits.set(sid, keep);
      else this.marketLoginHits.delete(sid);
    }
  }

  _dropMarketSid(sid) {
    if (sid) this.marketSids.delete(sid);
  }

  _pluginAuth(req, url) {
    const t = [
      (req.headers.authorization || '').replace(/^Bearer\s+/i, ''),
      req.headers['x-jlw-plugin-token'],
      url?.searchParams?.get('token'),
    ].filter(Boolean);
    return t.some((x) => this.plugins.checkToken(x));
  }

  /* ---------------- 路由 ---------------- */

  _route(method, pattern, handler) {
    const parts = pattern.split('/').filter(Boolean);
    this.routes.push({ method, parts, handler });
  }

  _match(method, pathname) {
    const segs = pathname.split('/').filter(Boolean);
    for (const r of this.routes) {
      if (r.method !== method && !(r.method === 'GET' && method === 'HEAD')) continue;
      if (r.parts.length !== segs.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < r.parts.length; i++) {
        const p = r.parts[i];
        if (p.startsWith(':')) params[p.slice(1)] = decodeURIComponent(segs[i]);
        else if (p !== segs[i]) {
          ok = false;
          break;
        }
      }
      if (ok) return { handler: r.handler, params };
    }
    return null;
  }

  setRestartSchedule(info) {
    this.restartSchedule = { enabled: false, minutes: 0, nextAt: 0, ...(info || {}) };
    try {
      this.hub.broadcast({ type: 'status', data: this._statusPayload() });
    } catch {
      /* ignore */
    }
    return this.restartSchedule;
  }

  _statusPayload() {
    try {
      return this._statusPayloadInner();
    } catch (e) {
      // 状态聚合失败（例如某个账户正在重启）也不能让面板 500 或进程崩溃
      try {
        this.log.error('状态聚合失败：' + e.message);
      } catch {
        /* ignore */
      }
      return {
        ok: true,
        degraded: true,
        error: e.message,
        version: VERSION,
        now: Date.now(),
        accounts: [],
        aggregate: {},
        plugins: {},
        pluginList: [],
        server: { host: this.host_, port: this.port, url: this.url(), pid: process.pid, uptime: Date.now() - this.startedAt },
        config: {},
        paths: {},
      };
    }
  }

  _statusPayloadInner() {
    const st = this.host.status();
    const cfg = this.config.publicConfig();
    return {
      ok: true,
      version: VERSION,
      now: Date.now(),
      ...st,
      plugins: this.plugins.info(),
      pluginList: this.plugins.list(),
      server: {
        host: this.host_,
        port: this.port,
        url: this.url(),
        uptime: Date.now() - this.startedAt,
        wsClients: this.hub.count(),
        dataDir: U.dataRoot(),
        node: process.version,
        platform: process.platform + ' ' + process.arch,
        pid: process.pid,
      },
      config: cfg,
      system: {
        restart: this.restartSchedule,
      },
      jlw: {
        baseUrl: this.config.jlw().baseUrl,
        apiPath: this.config.jlw().apiPath,
        configured: !!this.config.jlw().baseUrl,
        insecureTls: this.config.jlw().insecureTls,
      },
      webhook: {
        verify: this.config.get('webhook.verifySignature'),
        ackOp12: this.config.get('webhook.ackOp12'),
        accounts: st.accounts.map((a) => ({ id: a.id, name: a.name, path: a.webhookPath, stats: a.webhook })),
      },
      paths: {
        data: U.dataRoot(),
        plugins: this.plugins.dir,
        logs: U.p('logs'),
        config: this.config.file,
      },
    };
  }

  _scopePayload(session) {
    const allowed = this.config.listAllowed();
    return {
      ok: true,
      count: allowed.length,
      allowed,
      current: session?.user || null,
    };
  }

  /** JSONL 里的消息记录 → 面板事件结构（消息页按这个渲染） */
  _messageRecordToEvent(rec) {
    const out = rec.direction === 'out';
    const ts = Number(rec.t) || Date.parse(rec.time) || Date.now();
    const attachments = Math.max(0, Number(rec.attachments) || 0);
    return {
      id: (out ? 'out:' : 'hist:') + (rec.id || ts),
      name: rec.event || (out ? 'BOT_MESSAGE_CREATE' : 'MESSAGE_CREATE'),
      ts,
      time: rec.time || new Date(ts).toISOString(),
      source: out ? 'api' : 'ws',
      direction: out ? 'out' : 'in',
      accountId: rec.accountId || '',
      account: rec.accountName ? { id: rec.accountId || '', name: rec.accountName } : null,
      historical: true,
      raw: {
        id: rec.id || '',
        group_openid: rec.group_openid || '',
        user_openid: rec.user_openid || '',
        channel_id: rec.channel_id || '',
        body: rec.payload || null,
      },
      message: {
        id: rec.id || '',
        kind: rec.kind || 'group',
        content: rec.content || '',
        cleanContent: rec.content || '',
        timestamp: rec.time || new Date(ts).toISOString(),
        author: { id: rec.author || '', username: rec.name || '' },
        group_openid: rec.group_openid || '',
        user_openid: rec.user_openid || '',
        channel_id: rec.channel_id || '',
        guild_id: rec.guild_id || '',
        attachments: attachments ? new Array(attachments).fill({}) : [],
        payload: rec.payload || null,
      },
    };
  }

  _runUpdate(info) {
    const job = (this.updateJob = {
      phase: 'downloading',
      version: info.latest,
      received: 0,
      total: 0,
      percent: 0,
      startedAt: Date.now(),
    });
    (async () => {
      try {
        const dl = await this.updater.download(info, (p) => Object.assign(job, p));
        job.percent = 100;
        job.file = path.basename(dl.file);
        const r = this.updater.spawnApply(info, dl.file);
        job.phase = 'preparing';
        job.message = '正在解压并校验更新包…';
        const ready = await this._waitUpdateReady(r.readyFile, 90000);
        if (!ready.ok) throw new Error(ready.error || '更新包校验失败，旧版本继续运行');
        job.phase = 'restarting';
        job.updaterPid = r.pid;
        this.log.info('更新包已下载，准备重启安装', { version: info.latest, updater: r.pid });
        if (this.onRestart) {
          setTimeout(() => {
            try {
              this.onRestart();
            } catch (e) {
              this.log.error('自动重启失败：' + e.message);
            }
          }, 700);
          // 兜底：优雅退出卡住时强制结束，让更新器继续安装
          setTimeout(() => {
            this.log.warn('自动退出超时，强制结束进程以完成更新');
            process.exit(0);
          }, 15000).unref();
        } else {
          job.phase = 'ready';
          job.message = '更新器已启动，但当前进程无法自动退出，请手动重启';
        }
      } catch (e) {
        job.phase = 'error';
        job.error = e.message;
        job.endedAt = Date.now();
        this.log.error('在线更新失败：' + e.message);
      }
    })();
  }

  async _waitUpdateReady(file, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const j = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (j && typeof j.ok === 'boolean') return j;
      } catch {
        /* 更新器还没写好 */
      }
      await new Promise((r) => setTimeout(r, 300));
    }
    return { ok: false, error: '更新器没有响应，旧版本继续运行' };
  }

  _registerRoutes() {
    const R = (m, p, h) => this._route(m, p, h);

    R('GET', '/health', async (req, res) => {
      let crashes = [];
      try {
        crashes = health.readCrashes(U.dataRoot(), 1);
      } catch {
        /* ignore */
      }
      let accounts = 0;
      try {
        accounts = this.host.info().count;
      } catch {
        /* 账户模块异常不影响健康检查 */
      }
      this._json(res, 200, {
        ok: true,
        name: 'JlWBoT',
        version: VERSION,
        accounts,
        uptime: Date.now() - this.startedAt,
        pid: process.pid,
        node: process.version,
        listening: !!this.server.listening,
        lastServerError: this.lastServerError,
        lastCrash: crashes[0] || null,
      });
    });

    R('GET', '/api/session', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      const cfg = this.config.jlw();
      this._json(res, 200, {
        ok: true,
        loggedIn: !!s,
        user: s ? s.user : null,
        site: {
          baseUrl: cfg.baseUrl,
          apiPath: cfg.apiPath,
          insecureTls: cfg.insecureTls,
        },
        needsSetup: !cfg.baseUrl,
        accountsConfigured: this.host.info().configured > 0,
        version: VERSION,
      });
    });

    R('POST', '/api/login', async (req, res, { body }) => {
      const ip = this._ip(req);
      const email = String(body?.email || '').trim().toLowerCase();
      const password = String(body?.password || '');
      const now = Date.now();

      /* 同一邮箱 1 分钟内失败 10 次 → 冷却 5 分钟；冷却期内直接返回剩余分钟 */
      const lockUntil = Number(this.emailLocks.get(email) || 0);
      if (email && lockUntil > now) {
        const mins = Math.max(1, Math.ceil((lockUntil - now) / 60000));
        return this._json(res, 429, { ok: false, error: `该邮箱尝试次数过多，请 ${mins} 分钟后再试` });
      }
      if (email && lockUntil) this.emailLocks.delete(email);

      const ipHits = (this.loginHits.get(ip) || []).filter((t) => now - t < 60000);
      if (ipHits.length >= 10) return this._json(res, 429, { ok: false, error: '尝试过于频繁，请稍后再试' });
      ipHits.push(now);
      this.loginHits.set(ip, ipHits);

      const mailHits = (this.emailHits.get(email) || []).filter((t) => now - t < LOGIN_FAIL_WINDOW_MS);
      if (email && mailHits.length >= LOGIN_FAIL_MAX) {
        this.emailLocks.set(email, now + LOGIN_LOCK_MS);
        this.emailHits.delete(email);
        return this._json(res, 429, { ok: false, error: '该邮箱尝试次数过多，请 5 分钟后再试' });
      }
      if (!email || !password) return this._json(res, 400, { ok: false, error: '请输入邮箱和密码' });

      // 登录页允许首次填写站点地址；之后可在设置里改
      const patch = {};
      if (body?.baseUrl) patch.baseUrl = this.jlw.normalizeBase(body.baseUrl);
      if (body?.insecureTls !== undefined) patch.insecureTls = !!body.insecureTls;
      if (Object.keys(patch).length) this.config.update({ jlw: patch });

      const cfg = this.config.jlw();
      if (!cfg.baseUrl) return this._json(res, 400, { ok: false, error: '请填写聚龙账户站点地址' });

      try {
        const r = await this.jlw.login(email, password);
        if (!this.config.isLoginAllowed(r.user, email)) {
          this.log.warn('聚龙账户不在登录范围', { email, id: r.user.id, ip });
          return this._json(res, 403, {
            ok: false,
            error: '该聚龙账户不在登录范围，请联系管理员添加',
            code: 'NOT_ALLOWED',
          });
        }
        this.config.rememberAllowedUser(r.user);
        const sess = this._startSession(res, r, ip);
        // 顺带用同一聚龙账户登录插件市场（密码只用于这一次请求，不落盘）
        void this._marketLogin(sess.sid, email, password);
        this.emailHits.delete(email);
        this.emailLocks.delete(email);
        this.log.info('聚龙账户登录成功', { user: r.user.id, ip });
        this._json(res, 200, {
          ok: true,
          user: r.user,
          site: { baseUrl: cfg.baseUrl, apiPath: cfg.apiPath, insecureTls: cfg.insecureTls },
        });
      } catch (e) {
        const failedAt = Date.now();
        const hits = (this.emailHits.get(email) || []).filter((t) => failedAt - t < LOGIN_FAIL_WINDOW_MS);
        hits.push(failedAt);
        if (hits.length >= LOGIN_FAIL_MAX) {
          this.emailLocks.set(email, failedAt + LOGIN_LOCK_MS);
          this.emailHits.delete(email);
        } else {
          this.emailHits.set(email, hits);
        }
        const status = e.code === 'NETWORK' || e.code === 'TIMEOUT' ? 502 : e.code === 'NO_BASE' || e.code === 'BAD_BASE' || e.code === 'BAD_INPUT' ? 400 : 401;
        this.log.warn('登录失败：' + e.message, { ip, code: e.code });
        this._json(res, status, { ok: false, error: e.message, code: e.code });
      }
    });

    R('POST', '/api/jlw/send-code', async (req, res, { body }) => {
      const ip = this._ip(req);
      const email = String(body?.email || '').trim().toLowerCase();
      const purpose = body?.purpose === 'reset' ? 'reset' : 'register';
      if (!email) return this._json(res, 400, { ok: false, error: '请填写邮箱' });
      if (!this.config.isLoginAllowed({ email }, email)) {
        return this._json(res, 403, {
          ok: false,
          error: '该邮箱不在登录范围，请联系管理员先添加（左下角【登录范围】）',
          code: 'NOT_ALLOWED',
        });
      }

      const now = Date.now();
      const hits = (this.codeHits.get(ip) || []).filter((t) => now - t < 3600000);
      if (hits.length >= 20) return this._json(res, 429, { ok: false, error: '验证码请求过于频繁，请稍后再试' });
      hits.push(now);
      this.codeHits.set(ip, hits);

      const last = this.codeCooldown.get(email) || 0;
      const wait = Math.ceil((60000 - (now - last)) / 1000);
      if (wait > 0) return this._json(res, 429, { ok: false, error: `请 ${wait} 秒后再获取验证码`, retryAfter: wait });

      try {
        const r = await this.jlw.sendCode(email, purpose);
        this.codeCooldown.set(email, Date.now());
        this._json(res, 200, { ok: true, ...r });
      } catch (e) {
        const status = e.code === 'NETWORK' || e.code === 'TIMEOUT' ? 502 : 400;
        this.log.warn('发送验证码失败：' + e.message, { email, code: e.code });
        this._json(res, status, { ok: false, error: e.message, code: e.code });
      }
    });

    R('POST', '/api/jlw/register', async (req, res, { body }) => {
      const ip = this._ip(req);
      const now = Date.now();
      const ipHits = (this.loginHits.get(ip) || []).filter((t) => now - t < 60000);
      if (ipHits.length >= 10) return this._json(res, 429, { ok: false, error: '尝试过于频繁，请稍后再试' });
      ipHits.push(now);
      this.loginHits.set(ip, ipHits);

      const email = String(body?.email || '').trim().toLowerCase();
      const code = String(body?.code || '').trim();
      const password = String(body?.password || '');
      const name = String(body?.name || '').trim();
      if (!email || !code || !password || !name) return this._json(res, 400, { ok: false, error: '请填写邮箱、验证码、密码和名称' });
      if (!this.config.isLoginAllowed({ email }, email)) {
        return this._json(res, 403, {
          ok: false,
          error: '该邮箱不在登录范围，请联系管理员先添加（左下角【登录范围】）',
          code: 'NOT_ALLOWED',
        });
      }
      if (password.length < 6) return this._json(res, 400, { ok: false, error: '密码至少 6 位' });
      if (name.length < 2 || name.length > 20) return this._json(res, 400, { ok: false, error: '名称需要 2-20 个字' });

      try {
        const r = await this.jlw.register({ email, code, password, name });
        const sess = this._startSession(res, r, ip);
        void this._marketLogin(sess.sid, email, password);
        this.log.info('聚龙账户注册并登录成功', { email, ip });
        this._json(res, 200, { ok: true, user: r.user });
      } catch (e) {
        const status = e.code === 'NETWORK' || e.code === 'TIMEOUT' ? 502 : 400;
        this.log.warn('注册失败：' + e.message, { email, code: e.code });
        this._json(res, status, { ok: false, error: e.message, code: e.code });
      }
    });

    R('POST', '/api/jlw/reset-password', async (req, res, { body }) => {
      const ip = this._ip(req);
      const now = Date.now();
      const ipHits = (this.loginHits.get(ip) || []).filter((t) => now - t < 60000);
      if (ipHits.length >= 10) return this._json(res, 429, { ok: false, error: '尝试过于频繁，请稍后再试' });
      ipHits.push(now);
      this.loginHits.set(ip, ipHits);

      const email = String(body?.email || '').trim().toLowerCase();
      const code = String(body?.code || '').trim();
      const password = String(body?.password || '');
      if (!email || !code || !password) return this._json(res, 400, { ok: false, error: '请填写邮箱、验证码和新密码' });
      if (!this.config.isLoginAllowed({ email }, email)) {
        return this._json(res, 403, {
          ok: false,
          error: '该邮箱不在登录范围，请联系管理员先添加（左下角【登录范围】）',
          code: 'NOT_ALLOWED',
        });
      }
      if (password.length < 6) return this._json(res, 400, { ok: false, error: '密码至少 6 位' });

      try {
        const r = await this.jlw.resetPassword({ email, code, password });
        const sess = this._startSession(res, r, ip);
        void this._marketLogin(sess.sid, email, password);
        this.log.info('聚龙账户密码重置并登录成功', { email, ip });
        this._json(res, 200, { ok: true, user: r.user });
      } catch (e) {
        const status = e.code === 'NETWORK' || e.code === 'TIMEOUT' ? 502 : 400;
        this.log.warn('重置密码失败：' + e.message, { email, code: e.code });
        this._json(res, status, { ok: false, error: e.message, code: e.code });
      }
    });

    R('POST', '/api/logout', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      if (s) {
        this.session.destroy(s.sid);
        this._dropMarketSid(s.sid);
        if (s.jlwToken) this.jlw.logout(s.jlwToken);
      }
      this._clearSessionCookie(res);
      this._json(res, 200, { ok: true });
    });

    R('GET', '/api/me', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      if (!s) return this._json(res, 401, { ok: false, error: '请先登录', login: true });
      this._json(res, 200, { ok: true, user: s.user, provider: s.provider });
    });

    R('POST', '/api/me/refresh', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      if (!s) return this._json(res, 401, { ok: false, error: '请先登录', login: true });
      if (!s.jlwToken) return this._json(res, 400, { ok: false, error: '当前登录方式不支持刷新资料' });
      try {
        const user = await this.jlw.me(s.jlwToken);
        this.session.update(s.sid, { user });
        this._json(res, 200, { ok: true, user });
      } catch (e) {
        this._json(res, 502, { ok: false, error: e.message });
      }
    });

    R('GET', '/api/status', async (req, res) => {
      this._json(res, 200, this._statusPayload());
    });

    /* ---- 插件市场自动登录状态 ---- */
    R('GET', '/api/market/status', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      const hit = s && this.marketSids.get(s.sid);
      this._json(res, 200, {
        ok: true,
        signedIn: !!(hit && this._marketCookie(s.sid)),
        mail: (hit && hit.mail) || (s && s.user && s.user.email) || '',
        proxy: MarketProxy.PREFIX,
      });
    });

    // 面板会话还在、但市场登录态没了（例如框架重启过）：手动补一次市场登录。
    // 可以指定用登录范围里的哪个聚龙账户（后台多人编辑时有多个授权账户）。
    // 密码只用于这次请求，不落盘；同一会话 5 分钟内最多 5 次。
    R('POST', '/api/market/login', async (req, res, { url, body }) => {
      const s = this._sessionOf(req, url);
      if (!s) return this._json(res, 401, { ok: false, error: '请先登录', login: true });
      const sessionMail = String((s.user && s.user.email) || '').trim().toLowerCase();
      const mail = normalizeEmail(body?.mail) || sessionMail;
      const password = String(body?.password || '');
      if (!mail) return this._json(res, 400, { ok: false, error: '当前会话没有聚龙邮箱，请重新登录面板' });
      if (!this.config.isLoginAllowed({ email: mail }, mail)) {
        return this._json(res, 403, { ok: false, error: '该账户不在登录范围，先用左下角【登录范围】添加它', code: 'NOT_ALLOWED' });
      }
      if (!password) return this._json(res, 400, { ok: false, error: '请填写聚龙账户密码' });

      const now = Date.now();
      const hits = (this.marketLoginHits.get(s.sid) || []).filter((t) => now - t < 5 * 60 * 1000);
      if (hits.length >= 5) return this._json(res, 429, { ok: false, error: '尝试过于频繁，请稍后再试' });
      hits.push(now);
      this.marketLoginHits.set(s.sid, hits);
      this._pruneMarketSids();

      const r = await this._marketLogin(s.sid, mail, password);
      if (!r || !r.ok) return this._json(res, 400, { ok: false, error: (r && r.error) || '市场登录失败' });
      this._json(res, 200, { ok: true, mail, signedIn: true });
    });

    /* ---- 账户池 ---- */
    R('GET', '/api/accounts', async (req, res) => {
      this._json(res, 200, { ok: true, accounts: this.host.list(), info: this.host.info(), activeId: this.host.status().activeId });
    });

    R('POST', '/api/accounts', async (req, res, { body }) => {
      try {
        const r = await this.host.add(body || {});
        this._json(res, 200, r);
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('GET', '/api/accounts/:id', async (req, res, { params }) => {
      const rt = this.host.get(params.id);
      if (!rt) return this._json(res, 404, { ok: false, error: '账户不存在' });
      this._json(res, 200, { ok: true, account: this.host.list().find((a) => a.id === params.id) });
    });

    R('PATCH', '/api/accounts/:id', async (req, res, { params, body }) => {
      try {
        const r = await this.host.update(params.id, body || {});
        this._json(res, r.ok ? 200 : 400, r);
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('DELETE', '/api/accounts/:id', async (req, res, { params }) => {
      const r = await this.host.remove(params.id);
      this._json(res, r.ok ? 200 : 404, r);
    });

    R('POST', '/api/accounts/:id/start', async (req, res, { params }) => this._json(res, 200, await this.host.start(params.id)));
    R('POST', '/api/accounts/:id/stop', async (req, res, { params }) => this._json(res, 200, await this.host.stop(params.id)));
    R('POST', '/api/accounts/:id/restart', async (req, res, { params }) => this._json(res, 200, await this.host.restart(params.id)));
    R('POST', '/api/accounts/:id/mode', async (req, res, { params, body }) => {
      const r = await this.host.setMode(params.id, body?.mode);
      this._json(res, r.ok ? 200 : 400, r);
    });
    R('POST', '/api/accounts/:id/token/refresh', async (req, res, { params }) => {
      try {
        this._json(res, 200, await this.host.refreshToken(params.id));
      } catch (e) {
        this._json(res, 500, { ok: false, error: e.message });
      }
    });

    /* ---- 兼容旧接口：默认账户 ---- */
    const accountIdFrom = (body, url) => body?.accountId || body?.id || url?.searchParams?.get('account') || '';
    R('POST', '/api/bot/start', async (req, res, { body, url }) => {
      const r = await this.host.start(accountIdFrom(body, url));
      this._json(res, r.ok ? 200 : 400, r);
    });
    R('POST', '/api/bot/stop', async (req, res, { body, url }) => {
      const r = await this.host.stop(accountIdFrom(body, url));
      this._json(res, r.ok ? 200 : 400, r);
    });
    R('POST', '/api/bot/restart', async (req, res, { body, url }) => {
      const r = await this.host.restart(accountIdFrom(body, url));
      this._json(res, r.ok ? 200 : 400, r);
    });
    R('POST', '/api/bot/mode', async (req, res, { body, url }) => {
      const r = await this.host.setMode(accountIdFrom(body, url), body?.mode);
      this._json(res, r.ok ? 200 : 400, r);
    });
    R('POST', '/api/token/refresh', async (req, res, { body, url }) => {
      try {
        this._json(res, 200, await this.host.refreshToken(accountIdFrom(body, url)));
      } catch (e) {
        this._json(res, 500, { ok: false, error: e.message });
      }
    });

    /* ---- 配置 ---- */
    R('GET', '/api/config', async (req, res) => {
      this._json(res, 200, { ok: true, config: this.config.publicConfig() });
    });

    R('POST', '/api/config', async (req, res, { body }) => {
      const patch = body?.patch || {};
      if (patch.bot && patch.bot.clientSecret === '******') delete patch.bot.clientSecret;
      if (patch.jlw) {
        if (patch.jlw.key) delete patch.jlw.key;
        if (patch.jlw.mode) delete patch.jlw.mode;
        if (patch.jlw.baseUrl) patch.jlw.baseUrl = this.jlw.normalizeBase(patch.jlw.baseUrl);
      }
      if (patch.plugins && patch.plugins.token) delete patch.plugins.token;
      const beforePort = this.port;
      const merged = this.config.update(patch);
      if (patch.log) this.logger.configure(this.config.data);
      try {
        this.onConfigChange?.(patch);
      } catch (e) {
        this.log.warn('配置变更回调失败：' + e.message);
      }
      this.log.info('配置已更新', { keys: Object.keys(patch) });
      this._json(res, 200, { ok: true, config: merged, restartRequired: beforePort !== this.port });
    });

    /* ---- 进程内重启 ---- */
    R('POST', '/api/system/restart', async (req, res) => {
      if (!this.onManualRestart) {
        return this._json(res, 400, { ok: false, error: '当前环境不支持进程内重启，请手动重启' });
      }
      this.log.warn('面板触发了手动重启');
      this._json(res, 200, { ok: true, restarting: true });
      try {
        this.onManualRestart();
      } catch (e) {
        this.log.error('手动重启失败：' + e.message);
      }
    });

    R('POST', '/api/jlw/test', async (req, res, { body }) => {
      const o = { baseUrl: body?.baseUrl, insecureTls: body?.insecureTls };
      if (o.baseUrl) o.baseUrl = this.jlw.normalizeBase(o.baseUrl);
      try {
        const r = await this.jlw.test(o);
        this._json(res, 200, { ok: true, ...r });
      } catch (e) {
        this._json(res, e.code === 'NETWORK' || e.code === 'TIMEOUT' ? 502 : 400, { ok: false, error: e.message, code: e.code });
      }
    });

    /* ---- 登录范围 ---- */
    R('GET', '/api/auth/scope', async (req, res, { url }) => {
      const s = this._sessionOf(req, url);
      this._json(res, 200, this._scopePayload(s));
    });

    R('POST', '/api/auth/scope', async (req, res, { body, url }) => {
      const email = normalizeEmail(body?.email);
      if (!isValidEmail(email)) return this._json(res, 400, { ok: false, error: '聚龙账户邮箱格式不正确' });
      try {
        const entry = this.config.addAllowedAccount(email, { source: 'panel' });
        this.log.info('登录范围新增账户', { email: entry.email });
        this._json(res, 200, this._scopePayload(this._sessionOf(req, url)));
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('DELETE', '/api/auth/scope/:key', async (req, res, { params, url }) => {
      try {
        const removed = this.config.removeAllowedAccount(params.key);
        this.log.info('登录范围移除账户', { email: removed.email || removed.id });
        // 让所有面板 WS 重连；被移除的账户会在重连鉴权时被拒绝
        for (const c of this.hub.clients) c.close(1008);
        this._json(res, 200, this._scopePayload(this._sessionOf(req, url)));
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    /* ---- 在线更新 ---- */
    R('GET', '/api/update/check', async (req, res, { url }) => {
      const force = url.searchParams.get('force') === '1';
      const info = await this.updater.check(force);
      this._json(res, 200, info);
    });

    R('POST', '/api/update/start', async (req, res, { body }) => {
      if (this.updateStarting || (this.updateJob && ['downloading', 'preparing', 'restarting'].includes(this.updateJob.phase))) {
        return this._json(res, 200, { ok: true, already: true, job: this.updateJob });
      }
      this.updateStarting = true;
      try {
        const info = await this.updater.check(true);
        if (!info.ok) return this._json(res, 502, { ok: false, error: info.error || '检查更新失败' });
        if (!info.hasUpdate) return this._json(res, 400, { ok: false, error: '当前已是最新版本' });
        if (body?.version && String(body.version) !== info.latest) {
          return this._json(res, 409, { ok: false, error: `页面最新版本已变为 v${info.latest}，请刷新后重试` });
        }
        this._runUpdate(info);
        return this._json(res, 200, { ok: true, started: true, version: info.latest });
      } finally {
        this.updateStarting = false;
      }
    });

    R('GET', '/api/update/progress', async (req, res) => {
      this._json(res, 200, { ok: true, ...(this.updateJob || { phase: 'idle' }) });
    });

    R('POST', '/api/plugins/token/rotate', async (req, res) => {
      const token = this.plugins.rotateToken();
      this._json(res, 200, { ok: true, token });
    });

    /* ---- 事件 / 发送 / 守卫 ---- */
    R('GET', '/api/events', async (req, res, { url }) => {
      const limit = Math.min(Number(url.searchParams.get('limit')) || 100, 3000);
      const account = url.searchParams.get('account') || '';
      const date = String(url.searchParams.get('date') || '').trim();
      if (date) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return this._json(res, 400, { ok: false, error: 'date 格式应为 YYYY-MM-DD' });
        const records = store.messagesByDay(date, { account, limit });
        const events = records.map((r) => this._messageRecordToEvent(r));
        return this._json(res, 200, { ok: true, events, total: events.length, date, historical: true });
      }
      const events = this.host.events(limit, account);
      this._json(res, 200, { ok: true, events, total: events.length });
    });

    R('GET', '/api/messages/dates', async (req, res) => {
      this._json(res, 200, { ok: true, dates: store.messageDates() });
    });

    R('GET', '/api/groups/info', async (req, res, { url }) => {
      const group = String(url.searchParams.get('group') || '');
      const accountId = String(url.searchParams.get('account') || '');
      if (!group) return this._json(res, 400, { ok: false, error: '缺少 group 参数' });
      const rt = this.host.resolve(accountId);
      if (!rt) return this._json(res, 400, { ok: false, error: '没有可用账户' });
      const key = rt.id + '|' + group;
      const now = Date.now();
      const cached = this.groupInfoCache.get(key);
      if (cached && now - cached.at < 30 * 60 * 1000) {
        return this._json(res, 200, { ok: true, name: cached.name, cached: true });
      }
      try {
        const r = await rt.bot.api.get(`/v2/groups/${encodeURIComponent(group)}/info`);
        if (!r.ok) {
          return this._json(res, 200, { ok: false, error: r.message || '查询群名称失败', code: r.code });
        }
        const name = r.data?.group_name || r.data?.groupName || r.data?.name || '';
        if (name) this.groupInfoCache.set(key, { name, at: now });
        this._json(res, 200, { ok: true, name, group_openid: group });
      } catch (e) {
        this._json(res, 200, { ok: false, error: e.message });
      }
    });

    R('POST', '/api/events/inject', async (req, res, { body }) => {
      const rt = this.host.resolve(body?.accountId || body?.id);
      if (!rt) return this._json(res, 400, { ok: false, error: '没有可用账户' });
      const t = body?.t || body?.event || 'GROUP_AT_MESSAGE_CREATE';
      const d = body?.d || body?.data || {};
      const evt = {
        id: body?.id || 'mock_' + U.uid(10),
        t,
        d: {
          id: d.id || 'MOCK_MSG_' + U.uid(8),
          content: d.content ?? '/help',
          group_openid: d.group_openid || 'MOCK_GROUP_OPENID',
          author: d.author || { id: 'MOCK_USER', member_openid: 'MOCK_MEMBER', username: '测试用户', member_role: 'member' },
          timestamp: new Date().toISOString(),
          ...d,
        },
        s: 1,
        source: 'mock',
      };
      rt.bot.handleEvent(evt);
      this._json(res, 200, { ok: true, event: evt, accountId: rt.id });
    });

    R('POST', '/api/send', async (req, res, { body }) => {
      try {
        const r = await this.host.send(body || {});
        this._json(res, r.ok ? 200 : 400, r);
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('GET', '/api/endpoints', async (req, res) => {
      this._json(res, 200, {
        ok: true,
        groups: this.endpoints.groups,
        endpoints: this.endpoints,
        pluginToken: this.plugins.token,
        pluginApiBase: '/plugin-api/v1',
        intents: require('./intents').LIST,
        accounts: this.host.list().map((a) => ({ id: a.id, name: a.name, appIdMasked: a.appIdMasked })),
      });
    });

    R('POST', '/api/call', async (req, res, { body }) => {
      const rt = this.host.resolve(body?.accountId || body?.id);
      if (!rt) return this._json(res, 400, { ok: false, error: '没有可用账户' });
      let method = (body?.method || 'GET').toUpperCase();
      let p = body?.path || '';
      if (body?.key) {
        const ep = this.endpoints.find((x) => x.key === body.key);
        if (!ep) return this._json(res, 400, { ok: false, error: '未知接口 ' + body.key });
        method = ep.method;
        try {
          p = ep.path.replace(/\{(\w+)\}/g, (_, k) => {
            const v = body.params?.[k];
            if (v === undefined || v === '') throw new Error(`缺少路径参数 ${k}`);
            return encodeURIComponent(v);
          });
        } catch (e) {
          return this._json(res, 400, { ok: false, error: e.message });
        }
      }
      if (!p.startsWith('/')) return this._json(res, 400, { ok: false, error: 'path 必须以 / 开头' });
      try {
        const r = await rt.api.request(method, p, {
          query: body?.query,
          body: body?.body,
          timeout: Number(body?.timeout) || 25000,
          retry: Number(body?.retry ?? 1),
        });
        this._json(res, 200, {
          ok: r.ok,
          status: r.status,
          code: r.code,
          message: r.message,
          data: r.data,
          duration: r.duration,
          traceId: r.traceId,
          accountId: rt.id,
          request: { method, path: p },
        });
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    /* ---- 公网 IP ---- */
    R('GET', '/api/netinfo', async (req, res) => {
      this._json(res, 200, await this.netinfo.get(false));
    });
    R('POST', '/api/netinfo/refresh', async (req, res) => {
      this._json(res, 200, await this.netinfo.get(true));
    });

    /* ---- 插件 ---- */
    R('GET', '/api/plugins', async (req, res) => {
      this._json(res, 200, { ok: true, plugins: this.plugins.list(), info: this.plugins.info(), dataDir: this.plugins.dir });
    });

    R('POST', '/api/plugins/reload', async (req, res) => {
      const r = await this.plugins.reload();
      this._json(res, r.ok ? 200 : 400, { ...r, plugins: this.plugins.list() });
    });

    R('POST', '/api/plugins/create', async (req, res, { body }) => {
      const name = cleanField(body?.name, 60);
      if (!name) return this._json(res, 400, { ok: false, error: '请填写插件名称' });
      let id = require('./plugins').sanitizeId(body?.id || '');
      if (!id) id = pluginIdFromName(name, this.plugins.dir);
      if (!id) return this._json(res, 400, { ok: false, error: '无法生成插件 ID，请换一个名称' });
      const dir = path.join(this.plugins.dir, id);
      if (fs.existsSync(dir)) return this._json(res, 409, { ok: false, error: '插件已存在：' + id });
      const type = ['js', 'http', 'pull', 'process', 'dll'].includes(body?.type) ? body.type : 'pull';
      fs.mkdirSync(dir, { recursive: true });
      const manifest = {
        id,
        name,
        version: cleanField(body?.version, 24).replace(/^v/i, '') || '1.0.0',
        author: cleanField(body?.author, 64),
        description: cleanMultiline(body?.description, 500),
        enabled: true,
        type,
        priority: 100,
        events: ['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE'],
        commands: [],
        config: {},
      };
      if (type === 'http') manifest.url = 'http://127.0.0.1:9001/qqbot/event';
      if (type === 'pull' || type === 'process' || type === 'dll') manifest.timeout = 8000;
      if (type === 'process') manifest.launch = { command: 'plugin.exe', args: [], restart: true };
      if (type === 'dll') {
        manifest.launch = { command: 'dllhost.exe', args: [], restart: true };
        manifest.dll = { path: 'plugin.dll' };
      }
      U.writeJson(path.join(dir, 'plugin.json'), manifest);
      if (type === 'js') {
        const safeName = manifest.name.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
        fs.writeFileSync(
          path.join(dir, 'index.js'),
          `'use strict';\n// ${safeName}\n// 示例：只回复 /ping 与 /帮助，避免群里每条消息都回复。\nmodule.exports = {\n  async onLoad(ctx) {\n    ctx.log.info('插件已加载');\n  },\n\n  async onEvent(ctx) {\n    const { message } = ctx;\n    if (!message) return null;\n    const cmd = message.command?.name || '';\n    if (cmd === 'ping') return { reply: 'pong' };\n    if (cmd === '帮助' || cmd === 'help') {\n      return { reply: '插件已运行。编辑 index.js 开始开发。' };\n    }\n    return null;\n  },\n};\n`,
        );
      }
      await this.plugins.reload();
      this._json(res, 200, {
        ok: true,
        id,
        dir,
        plugin: this.plugins.list().find((p) => p.id === id) || manifest,
      });
    });

    R('POST', '/api/plugins/import', async (req, res, { body }) => {
      try {
        const r = await importPluginPackage(this.plugins, body || {});
        this._json(res, 200, { ok: true, ...r });
      } catch (e) {
        this._json(res, e.status || 400, { ok: false, error: e.message });
      }
    });

    R('POST', '/api/plugins/:id/update', async (req, res, { params, body }) => {
      try {
        const r = await updatePluginPackage(this.plugins, params.id, body || {});
        this.log.info('插件已更新', { id: r.id, from: r.previousVersion, to: r.version });
        this._json(res, 200, r);
      } catch (e) {
        this.log.warn('插件更新失败', { id: params.id, error: e.message });
        this._json(res, e.status || 400, { ok: false, error: e.message });
      }
    });

    R('GET', '/api/plugins/:id', async (req, res, { params }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const files = {};
      for (const f of ['plugin.json', p.manifest.entry || 'index.js', 'api.html', 'settings.html']) {
        try {
          files[f] = fs.readFileSync(path.join(p.dir, f), 'utf8');
        } catch {
          /* ignore */
        }
      }
      this._json(res, 200, { ok: true, plugin: this.plugins.list().find((x) => x.id === p.id), files, dir: p.dir });
    });

    R('GET', '/api/plugins/:id/api-doc', async (req, res, { params }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const file = path.join(p.dir, 'api.html');
      fs.readFile(file, 'utf8', (err, html) => {
        if (err) return this._json(res, 404, { ok: false, error: '该插件还没有 API 文档' });
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Content-Security-Policy':
            "sandbox allow-scripts allow-popups; default-src 'none'; img-src data: https:; style-src 'unsafe-inline' https:; font-src data: https:; script-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'",
        });
        res.end(html);
      });
    });

    R('GET', '/api/plugins/:id/settings', async (req, res, { params }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const file = path.join(p.dir, 'settings.html');
      fs.readFile(file, 'utf8', (err, html) => {
        if (err) return this._json(res, 404, { ok: false, error: '该插件还没有设置页面' });
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Content-Security-Policy':
            "sandbox allow-scripts allow-popups; default-src 'none'; img-src data: https:; style-src 'unsafe-inline' https:; font-src data: https:; script-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'",
        });
        res.end(html);
      });
    });

    R('POST', '/api/plugins/:id/config', async (req, res, { params, body }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const config = body?.config;
      if (!config || typeof config !== 'object' || Array.isArray(config)) {
        return this._json(res, 400, { ok: false, error: 'config 必须是一个对象' });
      }
      try {
        const manifest = JSON.parse(fs.readFileSync(path.join(p.dir, 'plugin.json'), 'utf8'));
        manifest.config = config;
        U.writeJson(path.join(p.dir, 'plugin.json'), manifest);
        await this.plugins.reload(params.id);
        this._json(res, 200, { ok: true, config });
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('DELETE', '/api/plugins/:id', async (req, res, { params }) => {
      const r = await this.plugins.remove(params.id);
      this._json(res, r.ok ? 200 : 400, r);
    });

    R('POST', '/api/plugins/:id/enable', async (req, res, { params, body }) => {
      const r = await this.plugins.setEnabled(params.id, body?.enabled !== false);
      this._json(res, r.ok ? 200 : 400, r);
    });

    R('POST', '/api/plugins/:id/reload', async (req, res, { params }) => {
      const r = await this.plugins.reload(params.id);
      this._json(res, r.ok ? 200 : 400, { ...r, plugins: this.plugins.list() });
    });

    R('POST', '/api/plugins/:id/test', async (req, res, { params, body }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const rt = this.host.resolve(body?.accountId);
      if (!rt) return this._json(res, 400, { ok: false, error: '没有可用账户' });
      const t = body?.t || 'GROUP_AT_MESSAGE_CREATE';
      const d = {
        id: 'TEST_' + U.uid(8),
        content: body?.content || '/帮助',
        group_openid: body?.group_openid || 'TEST_GROUP',
        author: { id: 'TEST_USER', member_openid: 'TEST_MEMBER', username: '测试用户', member_role: 'member' },
        timestamp: new Date().toISOString(),
      };
      const message = rt.bot.normalize(t, d, 'test');
      const evt = {
        id: 'test_' + U.uid(8),
        name: t,
        t,
        ts: Date.now(),
        time: U.nowIso(),
        source: 'test',
        raw: d,
        message,
        account: { id: rt.id, name: rt.account.name, appIdMasked: rt.bot.publicInfo().appIdMasked },
        accountId: rt.id,
      };
      try {
        const r = await this.plugins.test(params.id, evt);
        this._json(res, 200, { ok: true, result: r, accountId: rt.id });
      } catch (e) {
        this._json(res, 500, { ok: false, error: e.message });
      }
    });

    R('POST', '/api/plugins/:id/manifest', async (req, res, { params, body }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      try {
        const patch = typeof body?.manifest === 'string' ? JSON.parse(body.manifest) : body?.manifest || body;
        this.plugins.saveManifest(params.id, patch);
        await this.plugins.reload(params.id);
        this._json(res, 200, { ok: true, plugins: this.plugins.list() });
      } catch (e) {
        this._json(res, 400, { ok: false, error: e.message });
      }
    });

    R('POST', '/api/plugins/:id/file', async (req, res, { params, body }) => {
      const p = this.plugins.get(params.id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const name = String(body?.name || '');
      if (!name || name.includes('..') || path.isAbsolute(name)) return this._json(res, 400, { ok: false, error: '文件名不合法' });
      const file = path.join(p.dir, name);
      if (!path.resolve(file).startsWith(path.resolve(p.dir))) return this._json(res, 400, { ok: false, error: '越界路径' });
      try {
        U.writeText(file, String(body?.content ?? ''));
        if (p.manifest.type === 'js' && /\.js$/i.test(name)) await this.plugins.reload(params.id);
        this._json(res, 200, { ok: true });
      } catch (e) {
        this._json(res, 500, { ok: false, error: e.message });
      }
    });

    R('POST', '/api/plugins/install-sample', async (req, res) => {
      this.plugins._seedSamples(true);
      await this.plugins.reload();
      this._json(res, 200, { ok: true, plugins: this.plugins.list() });
    });

    /* ---- 日志 ---- */
    R('GET', '/api/logs', async (req, res, { url }) => {
      const limit = Math.min(Number(url.searchParams.get('limit')) || 200, 5000);
      const level = url.searchParams.get('level') || '';
      const q = (url.searchParams.get('q') || '').toLowerCase();
      const date = String(url.searchParams.get('date') || '').trim();
      if (date) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return this._json(res, 400, { ok: false, error: 'date 格式应为 YYYY-MM-DD' });
        const logs = store.logsByDay(date, { level, q, limit });
        return this._json(res, 200, { ok: true, logs, date, total: store.logCount(date), historical: true });
      }
      let list = this.logger.recent(Math.max(limit, 200), level || undefined);
      if (q) list = list.filter((l) => (l.msg || '').toLowerCase().includes(q) || JSON.stringify(l.meta || {}).toLowerCase().includes(q));
      this._json(res, 200, { ok: true, logs: list.slice(-limit), total: list.length });
    });

    R('GET', '/api/logs/dates', async (req, res) => {
      this._json(res, 200, { ok: true, dates: store.logDates() });
    });

    /* ---- 存储引擎切换（SQLite / JSON 文件） ---- */
    R('POST', '/api/storage/engine', async (req, res, { body }) => {
      const target = body && body.engine === 'json' ? 'json' : 'sqlite';
      const current = store.getEngine();
      if (target === current) {
        return this._json(res, 200, { ok: true, engine: current, changed: false });
      }
      try {
        const r = store.migrateTo(target);
        this.config.set('storage.engine', target);
        this.config.save();
        this.log.info(`存储方式切换：${current} → ${target}`, { counts: r.counts });
        setTimeout(() => {
          if (this.onManualRestart) this.onManualRestart();
        }, 300);
        this._json(res, 200, { ok: true, engine: target, changed: true, migrated: true, counts: r.counts, restarting: true });
      } catch (e) {
        this.log.error('切换存储方式失败：' + e.message);
        this._json(res, 500, { ok: false, error: e.message });
      }
    });

    R('GET', '/api/logs/download', async (req, res, { url }) => {
      const date = String(url.searchParams.get('date') || '').trim();
      let day = date;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) {
        const dates = store.logDates();
        day = dates.length ? dates[0].date : '';
      }
      if (!day) return this._json(res, 404, { ok: false, error: '还没有日志' });
      const list = store.logsByDay(day, { limit: 20000 });
      const text = list
        .map((l) => JSON.stringify({ t: l.t, time: l.time, level: l.level, scope: l.scope, msg: l.msg, meta: l.meta }))
        .join('\n');
      res.writeHead(200, {
        'Content-Type': 'application/x-ndjson; charset=utf-8',
        'Content-Disposition': `attachment; filename="jlwbot-${day}.jsonl"`,
      });
      res.end(text + (text ? '\n' : ''));
    });

    /* ---- 插件桥 ---- */
    const pluginAuth = (req, url, res) => {
      if (!this._pluginAuth(req, url)) {
        this._json(res, 401, { ok: false, error: '插件令牌无效' });
        return false;
      }
      return true;
    };

    R('GET', '/plugin-api/v1/info', async (req, res, { url }) => {
      if (!pluginAuth(req, url, res)) return;
      const id = url.searchParams.get('plugin');
      const accounts = this.host.list().map((a) => ({ id: a.id, name: a.name, appIdMasked: a.appIdMasked, state: a.state }));
      this._json(res, 200, {
        ok: true,
        framework: 'JlWBoT',
        version: VERSION,
        accounts,
        bot: this.host.defaultRuntime()?.bot.publicInfo() || {},
        plugin: id ? this.plugins.get(id)?.manifest : null,
        actions: ['reply', 'send_group_message', 'send_c2c_message', 'send_channel_message', 'api', 'endpoint', 'interaction_ack', 'log'],
      });
    });

    R('GET', '/plugin-api/v1/pull', async (req, res, { url }) => {
      if (!pluginAuth(req, url, res)) return;
      const id = url.searchParams.get('plugin');
      if (!id) return this._json(res, 400, { ok: false, error: '缺少 plugin 参数' });
      const timeout = Number(url.searchParams.get('timeout')) || 25000;
      const r = await this.plugins.pull(id, timeout);
      const format = url.searchParams.get('format') || '';
      if (format === 'text' || req.headers.accept === 'text/plain') {
        const text = formatPullText(id, r.events || []);
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(text);
      }
      this._json(res, 200, r);
    });

    R('POST', '/plugin-api/v1/action', async (req, res, { body, url }) => {
      if (!pluginAuth(req, url, res)) return;
      const id = body?.plugin || url.searchParams.get('plugin');
      const p = this.plugins.get(id);
      if (!p) return this._json(res, 404, { ok: false, error: '插件不存在' });
      const rt = this.host.resolve(body?.accountId || body?.account || url.searchParams.get('account'));
      if (!rt) return this._json(res, 400, { ok: false, error: '没有可用账户' });
      let actions = body?.actions;
      if (!actions) actions = [body?.action ? body : body?.action];
      if (!Array.isArray(actions)) actions = [actions];
      const results = [];
      for (const a of actions) {
        if (!a || typeof a !== 'object') continue;
        try {
          if (a.action === 'reply') {
            const msg = {
              kind: a.chat_type || a.scope || 'group',
              id: a.msg_id || a.message_id || '',
              group_openid: a.group_openid,
              user_openid: a.user_openid,
              channel_id: a.channel_id,
            };
            const r = await rt.bot.reply(msg, a.content, a);
            results.push({ ok: r.ok, action: 'reply', id: r.data?.id, code: r.code, message: r.message, accountId: rt.id });
          } else {
            results.push({ ...(await rt.bot.executeAction(p, { message: null, raw: null }, a)), accountId: rt.id });
          }
        } catch (e) {
          results.push({ ok: false, action: a.action, error: e.message });
        }
      }
      this._json(res, 200, { ok: results.every((r) => r.ok !== false), results, accountId: rt.id });
    });

    /* ---- QQ WebHook ---- */
    R('GET', '/qqbot/webhook', async (req, res) => {
      this._json(res, 200, { ok: true, message: 'JlWBoT webhook endpoint (POST only)' });
    });

    /* ---- 插件开发文档（面板内置文档页读取） ---- */
    R('GET', '/docs/:file', async (req, res, { params }) => {
      const name = path.basename(String(params.file || ''));
      if (!/\.md$/i.test(name)) return this._json(res, 404, { ok: false, error: 'Not Found' });
      const file =
        name.toLowerCase() === 'readme.md'
          ? path.join(U.ROOT, 'README.md')
          : name.toLowerCase() === 'plugin.md'
            ? path.join(U.ROOT, 'docs', '插件开发.md')
            : path.join(U.ROOT, 'docs', name);
      fs.readFile(file, 'utf8', (err, text) => {
        if (err) return this._json(res, 404, { ok: false, error: '文档不存在：' + name });
        res.writeHead(200, {
          'Content-Type': 'text/markdown; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
        });
        res.end(text);
      });
    });

    /* ---- 静态资源 ---- */
    R('GET', '/', async (req, res) => this._static(res, 'index.html'));
    R('GET', '/app.js', async (req, res) => this._static(res, 'app.js'));
    R('GET', '/style.css', async (req, res) => this._static(res, 'style.css'));
    R('GET', '/favicon.svg', async (req, res) => this._static(res, 'favicon.svg'));
  }

  _wireStreams() {
    const guard = (fn, label) => {
      try {
        fn();
      } catch (e) {
        try {
          this.log.warn(`面板推送失败 ${label}: ${e.message}`);
        } catch {
          /* ignore */
        }
      }
    };
    this.logger.subscribe((rec) => guard(() => this.hub.broadcast({ type: 'log', data: rec }), 'log'));
    this.host.on('event', (evt) => guard(() => this.hub.broadcast({ type: 'event', data: publicEvent(evt) }), 'event'));
    this.host.on('status', () => guard(() => this.hub.broadcast({ type: 'status', data: this._statusPayload() }), 'status'));
    this.host.on('notice', (n) => guard(() => this.hub.broadcast({ type: 'notice', data: n }), 'notice'));

    this.hub.onMessage(({ client, msg }) => {
      if (msg?.type === 'ping') client.send({ type: 'pong', t: Date.now() });
    });
    this.hub.onConnect((client) => {
      client.send({
        type: 'hello',
        data: {
          version: VERSION,
          status: this._statusPayload(),
          plugins: this.plugins.list(),
          logs: this.logger.recent(150),
          events: this.host.events(50).map(publicEvent),
          server: { url: this.url(), dataDir: U.dataRoot() },
        },
      });
    });
  }

  /* ---------------- HTTP ---------------- */

  async _dispatch(req, res) {
    let url;
    let pathname = '';
    try {
      url = new URL(req.url, 'http://localhost');
      pathname = url.pathname;
    } catch {
      // 畸形请求行（例如代理/扫描器发的怪东西）不能变成未捕获异常
      try {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Bad Request');
      } catch {
        /* ignore */
      }
      return;
    }
    const method = req.method || 'GET';

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');

    if (method === 'OPTIONS') {
      res.writeHead(204, corsHeaders());
      return res.end();
    }

    try {
      if (pathname.startsWith('/plugin-api/')) {
        for (const [k, v] of Object.entries(corsHeaders())) res.setHeader(k, v);
      }

      const isAdmin = pathname.startsWith('/api/');
      const isLogin =
        pathname === '/api/login' ||
        pathname === '/api/session' ||
        pathname === '/api/logout' ||
        pathname === '/api/jlw/send-code' ||
        pathname === '/api/jlw/register' ||
        pathname === '/api/jlw/reset-password';

      // 市场代理要在读 body 之前分流：上传插件是 100MB 级 zip 二进制，
      // 不能先 toString('utf8') 再转发（会损坏 zip），也不能受 24MB 读取上限限制。
      if (pathname === '/market-proxy' || pathname.startsWith('/market-proxy/')) {
        if (!this._authed(req, url)) return this._json(res, 401, { ok: false, error: '请先登录', login: true });
        const sess = this._sessionOf(req, url);
        const cookie = this._marketCookie(sess?.sid) || (await this._awaitMarketCookie(sess?.sid));
        return this.marketProxy.handle(req, res, url, '', {
          cookie,
          stream: true,
          onLogout: () => this._marketLogout(sess?.sid),
        });
      }

      let body = null;
      let raw = '';
      if (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE') {
        const buf = await readBody(req, 24 * 1024 * 1024);
        raw = buf.toString('utf8');
        const ct = req.headers['content-type'] || '';
        if (raw) {
          if (ct.includes('application/x-www-form-urlencoded')) {
            body = {};
            for (const [k, v] of new URLSearchParams(raw)) body[k] = v;
          } else if (ct.includes('application/json') || raw.trim().startsWith('{') || raw.trim().startsWith('[')) {
            try {
              body = JSON.parse(raw);
            } catch {
              body = { _raw: raw };
            }
          } else {
            body = { _raw: raw };
          }
        }
      }

      if (isAdmin && !isLogin && !this._authed(req, url)) {
        return this._json(res, 401, { ok: false, error: '请先登录', login: true });
      }

      // WebHook：按账户配置的路径路由，各自用自己的 AppSecret 验签
      const wh = this.host.webhookAccount(pathname);
      if (wh && method === 'POST') return this._handleWebhook(res, raw, req.headers, wh);

      const hit = this._match(method, pathname);
      if (!hit) {
        if (!pathname.startsWith('/api/') && method === 'GET') return this._static(res, pathname.replace(/^\//, '') || 'index.html');
        return this._json(res, 404, { ok: false, error: 'Not Found', path: pathname });
      }
      await hit.handler(req, res, { url, params: hit.params, body, raw, headers: req.headers });
    } catch (e) {
      this.log.error(`请求处理失败 ${method} ${pathname}: ${e.message}`);
      if (!res.headersSent) this._json(res, 500, { ok: false, error: e.message });
      else res.end();
    }
  }

  _handleWebhook(res, raw, headers, rt) {
    const out = this.webhook.handle({
      headers,
      rawBody: raw,
      secret: rt.account.clientSecret,
      verify: this.config.get('webhook.verifySignature', true),
      ackOp12: this.config.get('webhook.ackOp12', true),
      stats: rt.webhook,
      label: rt.account.name,
      onEvent: (evt) => rt.bot.handleEvent(evt),
    });
    this._json(res, out.status, out.body);
  }

  _ip(req) {
    const fwd = req.headers['x-forwarded-for'];
    if (this.config.get('server.trustProxy') && fwd) return String(fwd).split(',')[0].trim();
    return req.socket.remoteAddress || 'unknown';
  }

  _json(res, status, obj) {
    if (res.writableEnded) return;
    const data = JSON.stringify(obj);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Length': Buffer.byteLength(data),
    });
    res.end(data);
  }

  _static(res, name) {
    const safe = name.replace(/\\/g, '/').replace(/\.\./g, '');
    const file = path.join(WEB_DIR, safe);
    if (!file.startsWith(WEB_DIR)) return this._json(res, 403, { ok: false });
    fs.readFile(file, (err, buf) => {
      if (err) return this._json(res, 404, { ok: false, error: 'Not Found' });
      const ext = path.extname(file).toLowerCase();
      res.writeHead(200, {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control': 'no-store',
        'Content-Security-Policy': "default-src 'self'; img-src 'self' data: https:; connect-src 'self' ws: wss:; style-src 'self' 'unsafe-inline'; script-src 'self'",
      });
      res.end(buf);
    });
  }

  /* ---------------- 启停 ---------------- */

  /* ---------------- 服务自愈 ---------------- */

  _wireServerSafety() {
    // 常驻 error 监听：listen 成功后的错误（端口被抢、连接异常）不能把进程带崩
    this.server.on('error', (e) => this._onServerError(e));
    this.server.on('clientError', (err, socket) => {
      try {
        if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
        else socket.destroy();
      } catch {
        /* ignore */
      }
    });
    this.server.on('connection', (socket) => {
      socket.on('error', () => {});
    });
  }

  _onServerError(e) {
    this.lastServerError = { t: Date.now(), code: e?.code || '', message: e?.message || String(e) };
    const level = this._expectedStop ? 'info' : 'error';
    this.log[level](`HTTP 服务异常：${this.lastServerError.code} ${this.lastServerError.message}`);
    if (this._expectedStop) return;
    this._scheduleRelisten();
  }

  _scheduleRelisten() {
    if (this._expectedStop || this._relistenTimer) return;
    const delay = Math.min(30000, 1000 * Math.pow(2, Math.min(this._relistenAttempts, 5)));
    this._relistenAttempts++;
    this._relistenTimer = setTimeout(() => {
      this._relistenTimer = null;
      this._relisten();
    }, delay);
    this._relistenTimer.unref?.();
  }

  _relisten() {
    if (this._expectedStop || this.server.listening) return;
    try {
      this.server.listen(this.port, this.host_, () => {
        this._relistenAttempts = 0;
        this.log.info(`HTTP 服务已自动恢复：${this.url()}`);
        try {
          this.hub.broadcast({ type: 'notice', ok: true, message: '面板服务已自动恢复' });
        } catch {
          /* ignore */
        }
      });
    } catch (e) {
      this.log.error('HTTP 服务恢复失败：' + (e?.message || e));
      this._scheduleRelisten();
    }
  }

  /** 看门狗：监听被意外关闭时自动重新 listen，避免“整个端口掉了” */
  _startWatchdog() {
    if (this._watchdog) return;
    this._watchdog = setInterval(() => {
      if (this._expectedStop || this.server.listening) return;
      this.log.warn('检测到 HTTP 服务已停止监听，尝试恢复…');
      this._scheduleRelisten();
    }, this._watchdogMs);
    this._watchdog.unref?.();
  }

  _stopWatchdog() {
    if (this._watchdog) clearInterval(this._watchdog);
    this._watchdog = null;
    if (this._relistenTimer) clearTimeout(this._relistenTimer);
    this._relistenTimer = null;
  }

  start() {
    this._expectedStop = false;
    this._relistenAttempts = 0;
    return new Promise((resolve, reject) => {
      const onError = (e) => {
        this.server.removeListener('error', onError);
        reject(e);
      };
      this.server.once('error', onError);
      this.server.listen(this.port, this.host_, () => {
        this.server.removeListener('error', onError);
        this._startWatchdog();
        this.log.info(`Web 面板已启动：${this.url()}`);
        if (this.host_ === '0.0.0.0') this.log.warn('面板监听 0.0.0.0，局域网可访问，请确保令牌足够复杂');
        resolve(this.url());
      });
    });
  }

  stop() {
    return new Promise((resolve) => {
      this._expectedStop = true;
      this._stopWatchdog();
      this.hub.close();
      this.server.close(() => resolve());
      setTimeout(() => resolve(), 1500).unref?.();
    });
  }
}

function publicEvent(evt) {
  return {
    id: evt.id,
    name: evt.name,
    ts: evt.ts,
    time: evt.time,
    source: evt.source,
    account: evt.account || null,
    accountId: evt.accountId || null,
    raw: evt.raw,
    message: evt.message
      ? {
          id: evt.message.id,
          kind: evt.message.kind,
          content: evt.message.content,
          cleanContent: evt.message.cleanContent,
          timestamp: evt.message.timestamp,
          author: evt.message.author,
          group_openid: evt.message.group_openid,
          user_openid: evt.message.user_openid,
          channel_id: evt.message.channel_id,
          guild_id: evt.message.guild_id,
          attachments: evt.message.attachments,
          command: evt.message.command,
        }
      : null,
  };
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-JlW-Token,X-JlW-Plugin-Token,X-JlW-Plugin',
    'Access-Control-Max-Age': '600',
  };
}

/** 易语言友好的纯文本拉取格式：key=value，事件之间用 --- 分隔 */
function formatPullText(pluginId, events) {
  const esc = (v) =>
    String(v ?? '')
      .replace(/\\/g, '\\\\')
      .replace(/\r/g, '\\r')
      .replace(/\n/g, '\\n');
  const lines = ['# JlWBoT pull', 'plugin=' + pluginId, 'count=' + events.length, 'server_time=' + Date.now()];
  if (!events.length) {
    lines.push('---', 'event=NONE');
    return lines.join('\n') + '\n';
  }
  for (const item of events) {
    const m = item.message || {};
    const acc = item.account || item.event?.account || {};
    lines.push('---');
    lines.push('seq=' + item.seq);
    lines.push('event=' + esc(item.event?.name));
    lines.push('event_id=' + esc(item.event?.id));
    lines.push('time=' + esc(item.event?.time));
    lines.push('account_id=' + esc(acc.id || item.accountId));
    lines.push('account_name=' + esc(acc.name));
    lines.push('chat_type=' + esc(m.kind || 'other'));
    lines.push('group_openid=' + esc(m.group_openid));
    lines.push('user_openid=' + esc(m.user_openid));
    lines.push('channel_id=' + esc(m.channel_id));
    lines.push('guild_id=' + esc(m.guild_id));
    lines.push('msg_id=' + esc(m.id));
    lines.push('user_id=' + esc(m.author?.id));
    lines.push('user_name=' + esc(m.author?.username));
    lines.push('member_role=' + esc(m.author?.role));
    lines.push('content=' + esc(m.cleanContent ?? m.content));
    lines.push('command=' + esc(m.command?.name));
    lines.push('args=' + esc((m.command?.args || []).join(' ')));
  }
  return lines.join('\n') + '\n';
}

/* ---------------- 插件导入 ---------------- */

const IMPORT_MAX_FILE = 18 * 1024 * 1024;
const IMPORT_MAX_TOTAL = 60 * 1024 * 1024;

function decodeImportData(data) {
  if (typeof data !== 'string' || !data) throw new Error('文件内容为空');
  const buf = Buffer.from(data, 'base64');
  if (!buf.length) throw new Error('文件内容为空');
  if (buf.length > IMPORT_MAX_FILE) throw new Error('单个文件不能超过 18MB');
  return buf;
}

function cleanRelPath(value) {
  const s = String(value || '')
    .replace(/\\/g, '/')
    .replace(/^\/+/, '');
  const parts = s.split('/').filter((p) => p && p !== '.');
  if (!parts.length || parts.some((p) => p === '..' || p.includes(':'))) {
    throw new Error('插件包路径不合法：' + s);
  }
  return parts.join('/');
}

function writePluginFile(root, rel, buf) {
  const rootAbs = path.resolve(root);
  const dest = path.resolve(rootAbs, rel);
  if (dest !== rootAbs && !dest.startsWith(rootAbs + path.sep)) throw new Error('插件包路径越界');
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, buf);
}

function parsePluginManifest(buf) {
  let manifest;
  try {
    manifest = JSON.parse(buf.toString('utf8'));
  } catch {
    throw new Error('plugin.json 不是合法的 JSON');
  }
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) {
    throw new Error('plugin.json 必须是一个对象');
  }
  return manifest;
}

function decodeZipName(buf, flags) {
  if (flags & 0x800) return buf.toString('utf8');
  try {
    return new TextDecoder('gbk').decode(buf);
  } catch {
    return buf.toString('utf8');
  }
}

/** 解析 ZIP（store / deflate），返回 [{ rel, buf }]；插件包足够小，全部在内存处理。 */
function unzipEntries(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('不是有效的 zip 文件');
  const sig = 0x06054b50;
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === sig) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('不是有效的 zip 文件');
  const count = buf.readUInt16LE(eocd + 10);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  if (count === 0xffff || cdOffset === 0xffffffff) throw new Error('暂不支持 ZIP64，请用普通 zip');
  let p = cdOffset;
  const out = [];
  let total = 0;

  for (let i = 0; i < count; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 中央目录损坏');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const uncompSize = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOffset = buf.readUInt32LE(p + 42);
    const name = decodeZipName(buf.slice(p + 46, p + 46 + nameLen), flags).replace(/\\/g, '/');
    p += 46 + nameLen + extraLen + commentLen;

    if (name.endsWith('/')) continue;
    if (flags & 1) throw new Error('不支持加密的 zip：' + name);
    if (compSize === 0xffffffff || uncompSize === 0xffffffff || localOffset === 0xffffffff) {
      throw new Error('暂不支持 ZIP64，请用普通 zip');
    }
    if (uncompSize > IMPORT_MAX_FILE) throw new Error('压缩包内单个文件不能超过 18MB：' + name);
    if (localOffset + 30 > buf.length || buf.readUInt32LE(localOffset) !== 0x04034b50) {
      throw new Error('zip 本地文件头损坏：' + name);
    }
    const lnameLen = buf.readUInt16LE(localOffset + 26);
    const lextraLen = buf.readUInt16LE(localOffset + 28);
    const start = localOffset + 30 + lnameLen + lextraLen;
    if (start + compSize > buf.length) throw new Error('zip 文件数据不完整：' + name);
    const raw = buf.slice(start, start + compSize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) {
      try {
        data = zlib.inflateRawSync(raw, { maxOutputLength: IMPORT_MAX_FILE });
      } catch {
        throw new Error('zip 解压失败或文件超过 18MB：' + name);
      }
    } else {
      throw new Error('不支持的 zip 压缩方式：' + method + '（' + name + '）');
    }
    total += data.length;
    if (total > IMPORT_MAX_TOTAL) throw new Error('解压后总大小超过 60MB');
    out.push({ rel: cleanRelPath(name), buf: data });
  }
  return out;
}

function importBaseName(filename, ext) {
  const base = path.basename(String(filename || 'plugin'));
  return base.toLowerCase().endsWith(ext) ? base.slice(0, -ext.length) : base;
}

/** 读取 zip 插件包，返回 { manifest, files, sourceName } */
function readZipPackage(body) {
  const rawFiles = Array.isArray(body?.files) ? body.files : [];
  if (rawFiles.length !== 1) throw new Error('zip 一次只能选择一个文件');
  let entries = unzipEntries(decodeImportData(rawFiles[0].data)).filter(
    (f) => !f.rel.startsWith('__MACOSX/') && path.basename(f.rel) !== '.DS_Store',
  );
  const direct = entries.filter((f) => /(^|\/)plugin\.json$/i.test(f.rel) && f.rel.split('/').length <= 2);
  if (!direct.length) throw new Error('插件包里找不到 plugin.json（应位于根目录或单层子目录）');
  if (direct.length > 1) throw new Error('插件包里有多份 plugin.json，无法确定入口');
  const manifestFile = direct[0];
  const root = manifestFile.rel === 'plugin.json' ? '' : manifestFile.rel.slice(0, -'plugin.json'.length).replace(/\/$/, '');
  const sourceName = root ? path.basename(root) : '';
  entries = entries
    .filter((f) => !root || f.rel.startsWith(root + '/'))
    .map((f) => ({ rel: root ? f.rel.slice(root.length + 1) : f.rel, buf: f.buf }));
  const mf = entries.find((f) => f.rel.toLowerCase() === 'plugin.json');
  if (!mf) throw new Error('插件包里找不到 plugin.json');
  return { manifest: parsePluginManifest(mf.buf), files: entries, sourceName };
}

/**
 * 更新已有插件：保留 plugin.json 的 config、enabled 状态和 data/ 用户数据。
 * 先完整备份旧目录，失败时回滚。
 */
async function updatePluginPackage(pluginManager, id, body) {
  const key = require('./plugins').sanitizeId(id);
  if (!key) throw Object.assign(new Error('插件 ID 不合法'), { status: 400 });
  const existing = pluginManager.registry.get(key);
  if (!existing) throw Object.assign(new Error('插件不存在：' + key), { status: 404 });

  const pkg = readZipPackage(body);
  const pkgId = require('./plugins').sanitizeId(pkg.manifest.id || '');
  if (!pkgId) throw Object.assign(new Error('更新包的 plugin.json 缺少 id'), { status: 400 });
  if (pkgId !== key) {
    throw Object.assign(new Error(`更新包 ID（${pkgId}）与当前插件（${key}）不一致`), { status: 400 });
  }
  if (!['js', 'http', 'pull', 'process', 'dll'].includes(pkg.manifest.type)) {
    throw Object.assign(new Error('更新包的 type 不合法：' + pkg.manifest.type), { status: 400 });
  }

  const oldDir = existing.dir;
  const oldManifest = existing.manifest || {};
  const oldConfig = oldManifest.config && typeof oldManifest.config === 'object' ? oldManifest.config : {};
  const oldEnabled = oldManifest.enabled !== false;
  const backupRoot = U.p('backup', 'plugins');
  const backupDir = path.join(backupRoot, `${key}-${Date.now()}`);
  U.ensureDir(backupDir);
  fs.cpSync(oldDir, backupDir, { recursive: true });

  const manifest = {
    ...pkg.manifest,
    id: key,
    version: String(pkg.manifest.version || oldManifest.version || '1.0.0').replace(/^v/i, '').slice(0, 24),
    config: U.deepMerge(pkg.manifest.config || {}, oldConfig),
    enabled: oldEnabled,
  };

  try {
    const removed = await pluginManager.remove(key);
    if (!removed.ok) throw new Error(removed.error || '无法停止旧插件');
    fs.mkdirSync(oldDir, { recursive: true });
    for (const f of pkg.files) {
      if (f.rel.toLowerCase() === 'plugin.json') continue;
      // 新包的 data/ 先写入；随后用旧 data/ 覆盖，保证用户数据不丢
      writePluginFile(oldDir, f.rel, f.buf);
    }
    const oldData = path.join(backupDir, 'data');
    if (fs.existsSync(oldData)) fs.cpSync(oldData, path.join(oldDir, 'data'), { recursive: true, force: true });
    U.writeJson(path.join(oldDir, 'plugin.json'), manifest);
    await pluginManager.reloadAll();
    const loaded = pluginManager.registry.get(key);
    if (!loaded || loaded.runtime.status === 'error') {
      throw new Error((loaded && loaded.runtime.lastError) || '新版本插件加载失败');
    }
    // 只保留最近 5 个插件更新备份
    try {
      const backups = fs
        .readdirSync(backupRoot)
        .map((n) => path.join(backupRoot, n))
        .filter((p) => fs.statSync(p).isDirectory())
        .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
      for (const old of backups.slice(5)) fs.rmSync(old, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
    return {
      ok: true,
      id: key,
      version: manifest.version,
      previousVersion: oldManifest.version || '',
      plugin: pluginManager.list().find((p) => p.id === key) || manifest,
      backup: backupDir,
    };
  } catch (e) {
    // 回滚：移除半成品，恢复备份，重载旧版本
    try {
      fs.rmSync(oldDir, { recursive: true, force: true });
      fs.cpSync(backupDir, oldDir, { recursive: true });
      await pluginManager.reloadAll();
    } catch {
      /* 回滚失败时保留备份，交给用户手工恢复 */
    }
    throw Object.assign(new Error('更新失败，已回滚：' + e.message), { status: 400 });
  }
}


async function importPluginPackage(pluginManager, body) {
  const type = String(body.type || 'zip').toLowerCase();
  const rawFiles = Array.isArray(body.files) ? body.files : [];
  if (!rawFiles.length) throw new Error('没有收到文件');
  const allowed = new Set(['zip', 'folder', 'js', 'dll', 'exe', 'json']);
  if (!allowed.has(type)) throw new Error('不支持的导入类型：' + type);

  let files = [];
  for (const f of rawFiles) {
    const name = path.basename(String(f.name || 'file'));
    const rel = cleanRelPath(f.path || name);
    files.push({ rel, buf: decodeImportData(f.data) });
  }

  let manifest = null;
  let sourceName = '';

  if (type === 'zip' || type === 'folder') {
    if (type === 'zip') {
      const pkg = readZipPackage(body);
      manifest = pkg.manifest;
      files = pkg.files;
      sourceName = pkg.sourceName;
    } else {
      files = files.filter((f) => !f.rel.startsWith('__MACOSX/') && path.basename(f.rel) !== '.DS_Store');
      const direct = files.filter((f) => /(^|\/)plugin\.json$/i.test(f.rel) && f.rel.split('/').length <= 2);
      if (!direct.length) throw new Error('插件包里找不到 plugin.json（应位于根目录或单层子目录）');
      if (direct.length > 1) throw new Error('插件包里有多份 plugin.json，无法确定入口');
      const manifestFile = direct[0];
      const root = manifestFile.rel === 'plugin.json' ? '' : manifestFile.rel.slice(0, -'plugin.json'.length).replace(/\/$/, '');
      sourceName = root ? path.basename(root) : '';
      files = files
        .filter((f) => !root || f.rel.startsWith(root + '/'))
        .map((f) => ({ rel: root ? f.rel.slice(root.length + 1) : f.rel, buf: f.buf }));
      const mf = files.find((f) => f.rel.toLowerCase() === 'plugin.json');
      manifest = parsePluginManifest(mf.buf);
    }
  } else if (type === 'json') {
    manifest = parsePluginManifest(files[0].buf);
    files = [{ rel: 'plugin.json', buf: files[0].buf }];
  } else if (type === 'js') {
    sourceName = importBaseName(files[0].rel, '.js');
    manifest = {
      id: '',
      name: sourceName || 'JS 插件',
      version: '1.0.0',
      author: '',
      description: '从 JS 文件导入',
      enabled: true,
      type: 'js',
      priority: 100,
      events: ['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE'],
      commands: [],
      config: {},
      timeout: 8000,
      entry: 'index.js',
    };
    files = [{ rel: 'index.js', buf: files[0].buf }];
  } else if (type === 'dll') {
    const dllName = path.basename(files[0].rel);
    sourceName = importBaseName(dllName, '.dll');
    manifest = {
      id: '',
      name: sourceName || 'DLL 插件',
      version: '1.0.0',
      author: '',
      description: '从 DLL 文件导入，需自行准备 32 位宿主 EXE',
      enabled: true,
      type: 'dll',
      priority: 100,
      events: ['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE'],
      commands: [],
      config: {},
      timeout: 8000,
      launch: { command: 'dllhost.exe', args: [], restart: true },
      dll: { path: dllName },
    };
    files = [{ rel: dllName, buf: files[0].buf }];
  } else if (type === 'exe') {
    const exeName = path.basename(files[0].rel);
    sourceName = importBaseName(exeName, '.exe');
    manifest = {
      id: '',
      name: sourceName || '进程插件',
      version: '1.0.0',
      author: '',
      description: '从 EXE 文件导入',
      enabled: true,
      type: 'process',
      priority: 100,
      events: ['GROUP_AT_MESSAGE_CREATE', 'GROUP_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE'],
      commands: [],
      config: {},
      timeout: 8000,
      launch: { command: exeName, args: [], restart: true },
    };
    files = [{ rel: exeName, buf: files[0].buf }];
  }

  const validTypes = ['js', 'http', 'pull', 'process', 'dll'];
  if (!manifest.type) manifest.type = 'js';
  if (!validTypes.includes(manifest.type)) throw new Error('plugin.json 的 type 不合法：' + manifest.type);
  manifest.name = String(manifest.name || sourceName || manifest.id || '导入插件').trim().slice(0, 60);
  manifest.id = require('./plugins').sanitizeId(manifest.id || '') || pluginIdFromName(manifest.name, pluginManager.dir);
  manifest.version = String(manifest.version || '1.0.0').replace(/^v/i, '').slice(0, 24);
  manifest.enabled = manifest.enabled !== false;

  const dir = path.join(pluginManager.dir, manifest.id);
  if (fs.existsSync(dir)) {
    const e = new Error('插件已存在：' + manifest.id + '，请先删除或修改 plugin.json 的 id');
    e.status = 409;
    throw e;
  }

  fs.mkdirSync(dir, { recursive: true });
  try {
    for (const f of files) {
      if (f.rel.toLowerCase() === 'plugin.json') continue;
      writePluginFile(dir, f.rel, f.buf);
    }
    U.writeJson(path.join(dir, 'plugin.json'), manifest);
  } catch (e) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw e;
  }
  await pluginManager.reload();
  return {
    id: manifest.id,
    dir,
    plugin: pluginManager.list().find((p) => p.id === manifest.id) || manifest,
  };
}

function cleanField(v, max) {
  return String(v ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function cleanMultiline(v, max) {
  return String(v ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim()
    .slice(0, max);
}

/** 从插件名称生成文件系统安全的 ID；纯中文名回退到 plugin-<时间>。 */
function pluginIdFromName(name, dir) {
  let base = String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32);
  if (!base || /^\d/.test(base)) base = 'plugin-' + Date.now().toString(36);
  let id = base;
  let n = 2;
  while (fs.existsSync(path.join(dir, id))) id = base + '-' + n++;
  return id;
}

module.exports = PanelServer;
module.exports.VERSION = VERSION;
module.exports.formatPullText = formatPullText;
