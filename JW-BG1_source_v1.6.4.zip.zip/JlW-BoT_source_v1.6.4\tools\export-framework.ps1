﻿# Export a release zip. Top-level folder is always "JlW-BoT" (no version).
# 默认只打「成品包」：程序本体 + 离线 node + 启动/结束脚本 + 文档 md + README。
# 不打：test/ 回归源码、docs/images 截图、开发工具（导出/发版/演示脚本）、插件源码、插件市场、~JlWBoT 数据与日志。
# 需要完整源码包（带测试/截图/全部 tools）时加 -Full。
# Usage: powershell -ExecutionPolicy Bypass -File tools\export-framework.ps1 [-OutDir <dir>] [-Full]

param([string]$OutDir = "", [switch]$Full)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$pkg = Get-Content -Raw -Encoding UTF8 (Join-Path $root "package.json") | ConvertFrom-Json
$version = [string]$pkg.version
if (-not $OutDir) {
  # "框架导出" without relying on the script file encoding
  $outName = [string]([char]0x6846) + [char]0x67B6 + [char]0x5BFC + [char]0x51FA
  $OutDir = Join-Path $root $outName
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$zip = Join-Path $OutDir ("JlW-BoT [v" + $version + "].zip")
$stage = Join-Path ([IO.Path]::GetTempPath()) ("jlw-export-" + [guid]::NewGuid().ToString("N"))
$dst = Join-Path $stage "JlW-BoT"

# 运行必需的 tools（其余是开发工具）
$runtimeTools = @("start-panel.ps1", "stop-all.ps1", "setup-login.js")
# 成品包根目录白名单（避免把 node zip、临时文件、截图等带进去）
$startCmd = (-join @([char]0x542F, [char]0x52A8, [char]0x673A, [char]0x5668, [char]0x4EBA)) + ".cmd"
$stopCmd = (-join @([char]0x7ED3, [char]0x675F, [char]0x8FDB, [char]0x7A0B)) + ".cmd"
$rootFiles = @(
  "README.md",
  "LICENSE",
  "package.json",
  "config.default.json",
  "start.cmd",
  $startCmd,
  $stopCmd
)

try {
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  Copy-Item -LiteralPath (Join-Path $root "src") -Destination $dst -Recurse -Force
  New-Item -ItemType Directory -Force -Path (Join-Path $dst "runtime") | Out-Null
  Copy-Item -LiteralPath (Join-Path $root "runtime\node.exe") -Destination (Join-Path $dst "runtime\node.exe") -Force

  # 文档：保留 md，成品包不带截图
  Copy-Item -LiteralPath (Join-Path $root "docs") -Destination $dst -Recurse -Force
  if (-not $Full -and (Test-Path -LiteralPath (Join-Path $dst "docs\images"))) {
    Remove-Item -LiteralPath (Join-Path $dst "docs\images") -Recurse -Force
  }

  # 工具：成品只带运行必需的三个
  $toolsDst = Join-Path $dst "tools"
  New-Item -ItemType Directory -Force -Path $toolsDst | Out-Null
  $toolNames = if ($Full) {
    Get-ChildItem -LiteralPath (Join-Path $root "tools") -File | ForEach-Object { $_.Name }
  } else { $runtimeTools }
  foreach ($name in $toolNames) {
    Copy-Item -LiteralPath (Join-Path $root ("tools\" + $name)) -Destination (Join-Path $toolsDst $name) -Force
  }

  # 测试源码只在 -Full 包里
  if ($Full) {
    Copy-Item -LiteralPath (Join-Path $root "test") -Destination $dst -Recurse -Force
  }

  New-Item -ItemType Directory -Force -Path (Join-Path $dst "plugins") | Out-Null
  $pluginReadme = Join-Path $root "plugins\README.txt"
  if (Test-Path -LiteralPath $pluginReadme) {
    Copy-Item -LiteralPath $pluginReadme -Destination (Join-Path $dst "plugins\README.txt") -Force
  }

  foreach ($name in $rootFiles) {
    $src = Join-Path $root $name
    if (Test-Path -LiteralPath $src) {
      Copy-Item -LiteralPath $src -Destination (Join-Path $dst $name) -Force
    }
  }

  # README 里的文档截图在成品包里不存在：替换成占位文字，避免成品包里全是坏图
  if (-not $Full) {
    $readmePath = Join-Path $dst "README.md"
    if (Test-Path -LiteralPath $readmePath) {
      $text = [System.IO.File]::ReadAllText($readmePath, [System.Text.Encoding]::UTF8)
      $text = [regex]::Replace($text, '!\[[^\]]*\]\(docs/images/[^)]*\)', '(截图略)')
      [System.IO.File]::WriteAllText($readmePath, $text, (New-Object System.Text.UTF8Encoding($false)))
    }
  }

  # 清洗测试/临时产物
  if (Test-Path -LiteralPath (Join-Path $dst "test")) {
    Get-ChildItem -LiteralPath (Join-Path $dst "test") -Force -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -like ".tmp-*" } |
      Remove-Item -Recurse -Force
  }

  # 安全闸：绝对不能进包的东西
  if (Test-Path -LiteralPath (Join-Path $dst "~JlWBoT")) { throw "staging contains ~JlWBoT" }
  $bad = @(Get-ChildItem -LiteralPath $dst -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '\.log$' -or $_.Name -like ".tmp-*" -or $_.FullName -match '\\logs\\' -or $_.Name -match '^node-v.*\.zip$'
  })
  if ($bad.Count -gt 0) {
    $badNames = ($bad | Select-Object -First 5 | ForEach-Object { $_.Name }) -join ', '
    throw ("staging contains forbidden files: " + $badNames)
  }

  if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::CreateFromDirectory($dst, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)

  $fi = Get-Item -LiteralPath $zip
  $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
  $entries = [IO.Compression.ZipFile]::OpenRead($zip)
  $count = $entries.Entries.Count
  $entries.Dispose()

  Write-Host ""
  Write-Host ("Export: " + $fi.FullName)
  Write-Host ("Version: " + $version + $(if ($Full) { "  (full source)" } else { "  (release)" }))
  Write-Host ("Size: " + $fi.Length + " bytes (" + [math]::Round($fi.Length / 1MB, 2) + " MB)")
  Write-Host ("Files: " + $count)
  Write-Host ("SHA256: " + $hash)
  Write-Host ""
  Write-Host "Included: src/ runtime/node.exe tools(start-panel/stop-all/setup-login) docs/*.md plugins/README.txt + start/stop cmd + LICENSE"
  if ($Full) { Write-Host "           test/ docs/images/ all tools/" }
  Write-Host "Excluded: ~JlWBoT(数据/日志)  plugins源码(插件/)  插件市场/  test/源码  docs/images截图  开发工具"
  Write-Host ""
} finally {
  if (Test-Path -LiteralPath $stage) {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
  }
}
