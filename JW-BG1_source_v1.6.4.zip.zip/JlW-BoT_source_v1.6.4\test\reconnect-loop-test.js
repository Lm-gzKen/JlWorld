'use strict';
/**
 * 重连循环：一轮用尽（8 次）后进入冷却，冷却结束继续下一轮，永远不放弃。
 *   node test/reconnect-loop-test.js
 */
const assert = require('assert');
const Gateway = require('../src/core/gateway');

const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeGateway({ cooldownSec = 1 } = {}) {
  const logs = [];
  const notices = [];
  const logger = {
    child: () => ({
      info: (m) => logs.push({ level: 'info', m }),
      warn: (m) => logs.push({ level: 'warn', m }),
      error: (m) => logs.push({ level: 'error', m }),
      debug: () => {},
    }),
  };
  const config = {
    accountId: 'acc1',
    get: (k, d) => (k === 'bot.reconnectCooldownSec' ? cooldownSec : d),
  };
  const token = { get: async () => 't' };
  const api = { get: async () => ({ ok: false, message: 'mock gateway 失败' }) };
  const gw = new Gateway({ config, token, logger, api });
  gw.on('notice', (n) => notices.push(n));
  return { gw, logs, notices };
}

(async () => {
  /* ---------- 一轮用尽 → 冷却 ---------- */
  {
    const { gw, notices, logs } = makeGateway({ cooldownSec: 1 });
    for (let i = 0; i < 8; i++) gw._scheduleReconnect();
    check(gw.attempts === 8, '8 次重连后计数为 8', String(gw.attempts));
    check(gw.state === 'reconnecting', '8 次内状态为重连中', gw.state);

    gw._scheduleReconnect(); // 第 9 次触发上限
    check(gw.state === 'cooldown', '用尽后进入冷却而不是 fatal', gw.state);
    check(gw.attempts === 0, '冷却时本轮次数归零，准备下一轮', String(gw.attempts));
    check(gw.round === 1, '轮次 +1', String(gw.round));
    const waitMs = gw.cooldownUntil - Date.now();
    check(waitMs > 500 && waitMs <= 1200, '冷却时间约 1 秒（测试配置）', String(waitMs));
    check(notices.some((n) => /一直循环重试|不会放弃|未成功/.test(n.message)), '发出“不会放弃”的通知', JSON.stringify(notices));
    check(logs.some((l) => /不会放弃/.test(l.m)), '日志写明持续循环');
    check(gw.info().round === 1 && gw.info().cooldownUntil > 0, 'status 带 round/cooldownUntil');
    check(gw.reconnectTimer === null, '进入冷却时清掉上一轮遗留的重连定时器');

    // 冷却期间旧连接的 close 事件不能插队
    const attemptsBefore = gw.attempts;
    gw._scheduleReconnect();
    check(gw.attempts === attemptsBefore && gw.state === 'cooldown', '冷却期间忽略新的重连请求', `${gw.state}/${gw.attempts}`);

    /* ---------- 冷却结束 → 自动开下一轮 ---------- */
    await sleep(1300);
    check(gw.state === 'reconnecting', '冷却结束自动重新开始重连', gw.state);
    check(gw.round === 1 && gw.attempts === 1, '下一轮从第 1 次开始，轮次保留', `round=${gw.round} attempts=${gw.attempts}`);
    check(gw.cooldownUntil === 0, '冷却时间已清空');
    gw.disconnect();
    check(gw.state === 'closed', '手动断开后状态为 closed');
    check(gw.cooldownTimer === null, '手动断开清理冷却定时器');
  }

  /* ---------- 连续多轮循环 ---------- */
  {
    const { gw } = makeGateway({ cooldownSec: 1 });
    for (let round = 0; round < 2; round++) {
      for (let i = 0; i < 8; i++) gw._scheduleReconnect();
      gw._scheduleReconnect(); // 进入冷却
      check(gw.round === round + 1, `第 ${round + 1} 轮进入冷却`, `round=${gw.round}`);
      await sleep(1200);
      check(gw.state === 'reconnecting', `第 ${round + 1} 轮冷却结束继续`, gw.state);
    }
    gw.disconnect();
  }

  /* ---------- 4009 连接过期：必须丢掉 session 重新 Identify ---------- */
  {
    const { gw } = makeGateway({ cooldownSec: 5 });
    gw.sessionId = 'old-session';
    gw.seq = 123;
    gw._onClose(4009, '连接过期');
    check(gw.sessionId === '' && gw.seq === null, '4009 清空 session/seq（下次重新 Identify）');
    check(gw.state === 'reconnecting', '4009 自动重连而不是 fatal', gw.state);
    check(/4009/.test(gw.lastError || ''), '错误信息记录 4009', gw.lastError);
    gw.disconnect();
  }
  {
    const { gw } = makeGateway({ cooldownSec: 5 });
    gw.sessionId = 's';
    gw.seq = 1;
    gw._onClose(4006, '无效的 session id');
    check(gw.sessionId === '' && gw.seq === null, '4006 同样清空 session');
    gw.disconnect();
  }
  {
    const { gw } = makeGateway({ cooldownSec: 5 });
    gw._onClose(4915, '机器人已封禁');
    check(gw.state === 'fatal', '封禁仍然 fatal（不无限重连）', gw.state);
    gw.disconnect();
  }

  /* ---------- 冷却时长配置 ---------- */
  {
    const { gw } = makeGateway({ cooldownSec: 5 });
    check(gw._cooldownMs() === 5000, '冷却秒数按配置换算', String(gw._cooldownMs()));
    check(gw._cooldownMs() >= 1000, '冷却有下限');
    gw.disconnect();
  }
  {
    const { gw } = makeGateway({ cooldownSec: 0 });
    check(gw._cooldownMs() === 60000, '0/非法值回落 60 秒', String(gw._cooldownMs()));
    gw.disconnect();
  }
  {
    const { gw } = makeGateway({ cooldownSec: 99999 });
    check(gw._cooldownMs() === 3600000, '超大值截到 1 小时', String(gw._cooldownMs()));
    gw.disconnect();
  }

  /* ---------- 手动重连会清掉冷却 ---------- */
  {
    const { gw } = makeGateway({ cooldownSec: 60 });
    for (let i = 0; i < 8; i++) gw._scheduleReconnect();
    gw._scheduleReconnect();
    check(gw.state === 'cooldown', '进入冷却', gw.state);
    // 手动点重连：connect 会清冷却并重新计时（这里 API 失败会继续排重连）
    const p = gw.connect();
    await p;
    check(gw.cooldownUntil === 0, '手动重连清空冷却时间');
    gw.disconnect();
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
