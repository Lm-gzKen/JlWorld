'use strict';
// 运行状态查询插件：/状态 或 /status
module.exports = {
  async onEvent(ctx) {
    const { message } = ctx;
    if (!message) return null;
    const name = message.command?.name;
    if (!['状态', 'status', 'stat'].includes(name)) return null;

    const info = ctx.bot.info();
    const api = ctx.api;
    let me = null;
    try {
      const r = await api.me();
      if (r.ok) me = r.data;
    } catch {
      /* 忽略 */
    }
    const lines = [
      '【JlWBoT 运行状态】',
      `机器人：${info.name}（${info.appIdMasked || '未配置'}）`,
      `接入方式：${info.mode === 'webhook' ? 'WebHook' : 'WebSocket'}`,
      `框架版本：${ctx.framework.version}`,
      `数据目录：${ctx.framework.dataDir}`,
    ];
    if (me?.username) lines.push(`平台账号：${me.username}`);
    return { reply: lines.join('\n') };
  },
};
