/* 插件市场：列表 / 搜索 / 详情 / zip 下载 / 版本历史 / 留言与评分 */
(function () {
  const esc = window.escapeHtml;
  let state = { page: 1, q: '', sort: 'newest', tag: '', currentId: null };
  let searchTimer = null;
  const verOpen = new Map();

  // ---------------- 五颗心 ----------------
  const HEART =
    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.4-4.6-9.5-9A5.4 5.4 0 0 1 12 6.4 5.4 5.4 0 0 1 21.5 12C19.4 16.4 12 21 12 21z"/></svg>';
  const HEART_EMPTY =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s-7.4-4.6-9.5-9A5.4 5.4 0 0 1 12 6.4 5.4 5.4 0 0 1 21.5 12C19.4 16.4 12 21 12 21z"/></svg>';

  function heartsSmall(avg) {
    const full = Math.round(Number(avg) || 0);
    let out = '';
    for (let i = 1; i <= 5; i++) out += `<span class="heart ${i <= full ? 'on' : ''}">${i <= full ? HEART : HEART_EMPTY}</span>`;
    return `<span class="hearts">${out}</span>`;
  }

  const $ = (id) => document.getElementById(id);

  /** 只有在本站外壳 iframe 里时，才把详情 hash 同步到外壳地址栏；外部项目内嵌时不要碰外层页面 */
  function syncShellHash(hash) {
    try {
      if (App.inShell && window.parent && window.parent !== window) {
        window.parent.history.replaceState({ view: '/index.html', hash }, '', '/market' + (hash || ''));
      }
    } catch {}
  }

  // ------------------------------------------------------------ 统计
  async function loadStats() {
    try {
      const s = await App.api('GET', '/api/stats');
      $('heroStats').innerHTML = `
        <div class="s">插件 <b>${s.plugins}</b></div>
        <div class="s">累计下载 <b>${s.downloads}</b></div>
        <div class="s">累计浏览 <b>${s.views}</b></div>
        <div class="s">开发者 <b>${s.developers}</b></div>
        <div class="s">账户 <b>${s.users}</b></div>`;
    } catch {}
  }

  // ------------------------------------------------------------ 列表
  async function loadList() {
    const grid = $('grid');
    grid.innerHTML = Array.from({ length: 6 })
      .map(() => '<div class="card skeleton" style="height:168px"></div>')
      .join('');
    $('empty').hidden = true;

    const qs = new URLSearchParams({ page: state.page, sort: state.sort, size: 12 });
    if (state.q) qs.set('q', state.q);
    if (state.tag) qs.set('tag', state.tag);

    let data;
    try {
      data = await App.api('GET', '/api/plugins?' + qs.toString());
    } catch (e) {
      grid.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }

    $('count').textContent = `共 ${data.total} 个插件`;
    $('tagBar').innerHTML = data.tags
      .map((t) => `<span class="tag ${state.tag === t.name ? 'on' : ''}" data-tag="${esc(t.name)}">${esc(t.name)} · ${t.n}</span>`)
      .join('');
    $('tagBar')
      .querySelectorAll('[data-tag]')
      .forEach((el) => {
        el.style.cursor = 'pointer';
        el.onclick = () => {
          state.tag = state.tag === el.dataset.tag ? '' : el.dataset.tag;
          state.page = 1;
          loadList();
        };
      });

    if (!data.items.length) {
      grid.innerHTML = '';
      $('empty').hidden = false;
      $('pager').innerHTML = '';
      return;
    }

    grid.innerHTML = data.items
      .map(
        (p) => `
      <article class="card pcard ${p.pinned ? 'pinned' : ''}" data-id="${esc(p.id)}">
        ${p.pinned ? `<span class="pin-flag" title="管理员置顶">${App.PIN_SVG}</span>` : ''}
        <h3>${esc(p.name)} <span class="badge badge-accent">v${esc(p.version)}</span></h3>
        <div class="tiny muted-2">作者 ${esc(p.author)} · ${p.releaseCount || 1} 个版本${p.depCount ? ` · 需前置 ${p.depCount}` : ''}</div>
        <div class="desc">${esc(p.summary || '（作者没有填写简短介绍）')}</div>
        <div class="tagline">${(p.tags || []).slice(0, 4).map((t) => `<span class="tag">${esc(t)}</span>`).join('')}</div>
        <div class="foot">
          <span class="rating-mini" title="${p.rating && p.rating.count ? `均分 ${p.rating.avg}（${p.rating.count} 人评分）` : '还没有人评分'}">${HEART} ${
            p.rating && p.rating.count ? p.rating.avg.toFixed(1) : '—'
          }</span>
          <span>⬇ ${p.downloads}</span>
          <span>👁 ${p.views}</span>
          <span class="spacer"></span><span>${App.fmtRel(p.updated)}</span>
        </div>
      </article>`
      )
      .join('');
    grid.querySelectorAll('.pcard').forEach((el) => {
      el.onclick = () => (location.hash = '#/p/' + el.dataset.id);
    });
    const pager = $('pager');
    if (data.pages <= 1) {
      pager.innerHTML = '';
    } else {
      pager.innerHTML = `
        <button class="btn btn-sm" ${data.page <= 1 ? 'disabled' : ''} data-go="${data.page - 1}">上一页</button>
        <span class="muted small" style="padding:0 8px">第 ${data.page} / ${data.pages} 页</span>
        <button class="btn btn-sm" ${data.page >= data.pages ? 'disabled' : ''} data-go="${data.page + 1}">下一页</button>`;
      pager.querySelectorAll('[data-go]').forEach((b) => {
        b.onclick = () => {
          state.page = Number(b.dataset.go);
          loadList();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        };
      });
    }
  }

  // ------------------------------------------------------------ 包内文件
  function entryRows(entries, limit) {
    const list = entries.slice(0, limit);
    return list
      .map(
        (e) => `
      <tr>
        <td class="fi">${App.fileChip(App.extOf(e.name))}</td>
        <td class="fn"><span class="fname">${esc(e.name)}</span></td>
        <td class="fs">${App.fmtSize(e.size)}</td>
      </tr>`
      )
      .join('');
  }

  function entriesBlock(release, limit) {
    const entries = release.entries || [];
    const more = release.entryCount > entries.length ? release.entryCount - entries.length : 0;
    return `
      <div class="repo" style="margin-top:8px">
        <div class="repo-head">
          <b>包内文件</b>
          <span class="badge">${release.entryCount}</span>
          <span class="tiny muted-2">压缩包 ${App.fmtSize(release.size)}</span>
          <span class="spacer"></span>
          <span class="tiny muted-2">${release.dllName ? '本体 ' + esc(release.dllName) : '没有 .dll'}</span>
        </div>
        <table class="filelist"><tbody>${entryRows(entries, limit)}</tbody></table>
        ${more ? `<div class="repo-empty tiny">还有 ${more} 个文件没有显示</div>` : ''}
      </div>`;
  }

  // ------------------------------------------------------------ 详情
  async function openDetail(id) {
    state.currentId = id;
    $('viewList').hidden = true;
    $('viewDetail').hidden = false;
    const body = $('detailBody');
    body.innerHTML = '<div class="loading">正在加载插件详情…</div>';

    let d;
    try {
      d = await App.api('GET', '/api/plugins/' + encodeURIComponent(id));
    } catch (e) {
      body.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>
        <div style="margin-top:14px"><a class="btn btn-sm" href="#">返回列表</a></div>`;
      return;
    }

    const p = { ...d.plugin, releaseCount: (d.releases || []).length };
    const releases = d.releases || [];
    const latest = releases.find((r) => r.version === d.plugin.version) || releases[0] || null;

    body.innerHTML = `
      <div class="detail-head">
        ${p.offline ? '<div class="alert alert-warn" style="margin-bottom:14px">这个插件已被管理员下架：市场里不再显示，只有作者和管理员能看到这一页。</div>' : ''}
        <h1>
          ${esc(p.name)}
          <span class="badge badge-accent">v${esc(p.version)}</span>
          ${p.offline ? '<span class="badge badge-red">已下架</span>' : ''}
          ${p.pinned ? `<span class="badge badge-amber pin-badge" title="管理员置顶">${App.PIN_SVG} 置顶</span>` : ''}
          ${d.isOwner ? '<span class="badge badge-purple">我上传的</span>' : ''}
        </h1>
        <div class="row-wrap small muted" style="margin-top:4px">
          <span>作者：<b style="color:var(--text)">${esc(p.author)}</b></span>
          <span class="muted-2">·</span>
          <span>上传者：${esc(p.ownerMasked)}</span>
          <span class="muted-2">·</span>
          <span>最近更新：${App.fmtTime(p.updated)}</span>
          <span class="muted-2">·</span>
          <span>${releases.length} 个版本</span>
        </div>
        <div class="stat-row" id="statRow">${statHtml(p, d.commentCount)}</div>
        ${(p.tags || []).length ? `<div class="tagline" style="margin-top:12px">${p.tags.map((t) => `<span class="tag">${esc(t)}</span>`).join('')}</div>` : ''}
      </div>

      <div class="two-col">
        <div class="stack">
          <div class="card">
            <h3 style="font-size:17px">插件介绍</h3>
            <div class="md">${p.readme && p.readme.trim() ? window.renderMarkdown(p.readme) : '<p class="muted">作者没有填写详细介绍。</p>'}</div>
          </div>

          ${latest ? `<div class="card">
            <h3 style="font-size:17px">最新版本内容 <span class="badge badge-accent">v${esc(latest.version)}</span></h3>
            ${entriesBlock(latest, 200)}
          </div>` : ''}

          <div class="card" id="cmtCard">
            <h3 style="font-size:17px">用户留言 <span class="badge">${d.commentCount}</span></h3>
            <div style="margin:12px 0 8px">
              <textarea id="cmtInput" placeholder="说点什么…（支持换行，最多 1000 字）" maxlength="1000"></textarea>
              <div class="row" style="margin-top:9px">
                <span class="tiny muted-2" id="cmtHint"></span>
                <div class="spacer"></div>
                <button class="btn btn-primary btn-sm" id="cmtSend">发表留言</button>
              </div>
            </div>
            <div id="cmtList"><div class="loading">加载留言…</div></div>
          </div>
        </div>

        <aside class="stack">
          <div class="card side-card">
            <h4>下载</h4>
            ${
              latest
                ? `<a class="btn btn-primary btn-block" href="/api/releases/${latest.id}/download" data-dl="1">⬇ 下载最新版 v${esc(latest.version)}</a>
                   <div class="tiny muted-2 center" style="margin-top:8px">${esc(latest.filename)} · ${App.fmtSize(latest.size)}</div>
                   <div class="tiny muted-2 center" style="margin-top:3px">包含 ${latest.entryCount} 个文件${latest.dllName ? ' · 本体 ' + esc(latest.dllName) : ''}</div>`
                : '<div class="muted small">还没有可下载的版本</div>'
            }
            <div class="tiny muted-2" style="margin-top:12px">下载会记录次数，不会记录你的隐私信息。</div>
          </div>

          ${
            (d.deps || []).length
              ? `<div class="card side-card" id="depCard">
                   <h4>前置插件 <span class="badge">${d.deps.length}</span></h4>
                   <div class="dep-list">
                     ${d.deps
                       .map(
                         (x) => `<a class="dep-item" href="#/p/${esc(x.id)}">
                           <span class="dep-nm">${esc(x.name)}</span>
                           <span class="badge badge-accent">v${esc(x.version)}</span>
                           ${x.offline ? '<span class="badge badge-red">已下架</span>' : ''}
                         </a>`
                       )
                       .join('')}
                   </div>
                   <div class="tiny muted-2" style="margin-top:8px">装这个插件之前，先把上面的前置插件装好。</div>
                 </div>`
              : ''
          }

          <div class="card side-card">
            <h4>版本历史</h4>
            ${
              releases.length
                ? releases
                    .map((v) => {
                      const key = p.id + '|' + v.version;
                      const open = verOpen.has(key) ? verOpen.get(key) : v.version === p.version;
                      return `
              <div class="vgroup" data-ver="${esc(v.version)}">
                <div class="vhead" data-vtoggle="${esc(v.version)}">
                  <span class="vcaret">${open ? '▾' : '▸'}</span>
                  <b>v${esc(v.version)}</b>
                  ${v.version === p.version ? '<span class="badge badge-green">当前</span>' : ''}
                  <span class="spacer"></span>
                  <span class="tiny muted-2">${v.entryCount} 个 · ${App.fmtSize(v.size)}</span>
                </div>
                <div class="vbody" ${open ? '' : 'hidden'}>
                  <div style="padding:9px 10px 10px">
                    <div class="row-wrap" style="gap:8px">
                      <a class="btn btn-sm btn-primary nowrap" href="/api/releases/${v.id}/download" data-dl="1">下载 v${esc(v.version)}</a>
                      <span class="tiny muted-2">${esc(v.filename)}</span>
                      <span class="spacer"></span>
                      <span class="tiny muted-2">${App.fmtRel(v.created)}</span>
                    </div>
                    ${v.changelog ? `<div class="tiny muted" style="margin-top:7px;white-space:pre-wrap">${esc(v.changelog)}</div>` : ''}
                    <table class="filelist" style="margin-top:8px"><tbody>${entryRows(v.entries || [], 60)}</tbody></table>
                    ${(v.entries || []).length < v.entryCount ? `<div class="tiny muted-2" style="margin-top:6px">还有 ${v.entryCount - v.entries.length} 个文件没有显示</div>` : ''}
                  </div>
                </div>
              </div>`;
                    })
                    .join('')
                : '<div class="muted small">还没有文件</div>'
            }
            <div class="tiny muted-2" style="margin-top:8px">点版本行可展开 / 收起</div>
          </div>

          ${
            d.canManage
              ? `<div class="card side-card">
                   <h4>管理员操作</h4>
                   <div class="row-wrap" style="gap:8px">
                     <button class="btn btn-sm" data-admin-pin="${p.pinned ? '0' : '1'}">${p.pinned ? '取消置顶' : '置顶'}</button>
                     <button class="btn btn-sm" data-admin-off="${p.offline ? '0' : '1'}">${p.offline ? '重新上架' : '下架插件'}</button>
                     <button class="btn btn-sm btn-danger" data-admin-del="${esc(p.id)}" data-name="${esc(p.name)}">删除插件</button>
                   </div>
                   <div class="tiny muted-2" style="margin-top:8px">管理员可以直接下架或删除任意插件。</div>
                 </div>`
              : ''
          }

          <div class="card side-card">
            <h4>评分</h4>
            <div class="rate-big">
              ${[1, 2, 3, 4, 5]
                .map(
                  (i) =>
                    `<button class="heart-btn ${i <= Math.round(d.rating.avg) ? 'on' : ''}" data-star="${i}" ${
                      d.canRate ? '' : 'disabled'
                    } title="${d.canRate ? '给 ' + i + ' 颗心' : esc(d.rateHint || '暂时不能评分')}">${
                      i <= Math.round(d.rating.avg) ? HEART : HEART_EMPTY
                    }</button>`
                )
                .join('')}
            </div>
            <div class="small" style="margin-top:8px">
              ${
                d.rating.count
                  ? `<b style="font-size:16px">${d.rating.avg.toFixed(1)}</b> <span class="muted-2">/ 5 · ${d.rating.count} 人评分</span>`
                  : '<span class="muted-2">还没有人评分</span>'
              }
            </div>
            <div class="tiny muted-2" style="margin-top:6px">
              ${
                d.myRating
                  ? `你给了 <b style="color:var(--amber)">${d.myRating}</b> 颗心，再点一下可以改`
                  : d.canRate
                    ? '你下载过这个插件，点上面的心就能评分'
                    : esc(d.rateHint || '下载过之后才能评分')
              }
            </div>
          </div>
        </aside>
      </div>`;

    body.querySelectorAll('[data-dl]').forEach((a) => {
      a.addEventListener('click', () => setTimeout(() => refreshStats(p.id), 1600));
    });

    body.querySelectorAll('[data-vtoggle]').forEach((h) => {
      h.onclick = () => {
        const box = h.parentElement.querySelector('.vbody');
        const willOpen = box.hidden;
        box.hidden = !willOpen;
        h.querySelector('.vcaret').textContent = willOpen ? '▾' : '▸';
        verOpen.set(p.id + '|' + h.dataset.vtoggle, willOpen);
      };
    });

    body.querySelectorAll('.heart-btn').forEach((b) => {
      b.onclick = async () => {
        const stars = Number(b.dataset.star);
        b.disabled = true;
        try {
          const r = await App.api('POST', `/api/plugins/${p.id}/rating`, { stars });
          App.toast(`已评 ${r.stars} 颗心，当前均分 ${r.avg}（${r.count} 人评分）`, 'ok');
          openDetail(p.id);
          return;
        } catch (e) {
          App.toast(e.message, 'err');
        }
        b.disabled = false;
      };
    });

    // 管理员：直接在详情页置顶 / 下架 / 删除
    const adminPin = body.querySelector('[data-admin-pin]');
    if (adminPin) {
      adminPin.onclick = async () => {
        const want = adminPin.dataset.adminPin === '1';
        adminPin.disabled = true;
        try {
          await App.api('POST', '/api/admin/pin', { id: p.id, pinned: want });
          App.toast(want ? '已置顶到市场首页' : '已取消置顶', 'ok');
          openDetail(p.id);
        } catch (e) {
          App.toast(e.message, 'err');
          adminPin.disabled = false;
        }
      };
    }
    const adminOff = body.querySelector('[data-admin-off]');
    if (adminOff) {
      adminOff.onclick = async () => {
        const wantOffline = adminOff.dataset.adminOff === '1';
        adminOff.disabled = true;
        try {
          await App.api('POST', `/api/plugins/${p.id}/offline`, { offline: wantOffline });
          App.toast(wantOffline ? '插件已下架' : '插件已重新上架', 'ok');
          openDetail(p.id);
        } catch (e) {
          App.toast(e.message, 'err');
          adminOff.disabled = false;
        }
      };
    }
    const adminDel = body.querySelector('[data-admin-del]');
    if (adminDel) {
      adminDel.onclick = async () => {
        if (!confirm(`确定删除插件《${p.name}》吗？所有版本、留言都会一并删除。`)) return;
        adminDel.disabled = true;
        try {
          await App.api('DELETE', '/api/plugins/' + p.id);
          App.toast('插件已删除', 'ok');
          location.hash = '';
        } catch (e) {
          App.toast(e.message, 'err');
          adminDel.disabled = false;
        }
      };
    }

    loadComments(p.id, d);

    $('cmtSend').onclick = async () => {
      const input = $('cmtInput');
      const text = input.value.trim();
      if (!text) return App.toast('请先输入留言内容', 'err');
      const btn = $('cmtSend');
      btn.disabled = true;
      try {
        await App.api('POST', `/api/plugins/${p.id}/comments`, { body: text });
        input.value = '';
        App.toast('留言已发布，作者会收到提醒', 'ok');
        const c = await App.api('GET', `/api/plugins/${p.id}`);
        $('statRow').innerHTML = statHtml(c.plugin, c.commentCount);
        loadComments(p.id, c);
      } catch (e) {
        App.toast(e.message, 'err');
      } finally {
        btn.disabled = false;
      }
    };
  }

  function statHtml(p, commentCount) {
    return `
      <div class="s">查看次数 <b>${p.views}</b></div>
      <div class="s">下载次数 <b>${p.downloads}</b></div>
      <div class="s">版本数 <b>${p.releaseCount == null ? '—' : p.releaseCount}</b></div>
      <div class="s">留言 <b>${commentCount == null ? '—' : commentCount}</b></div>`;
  }

  async function refreshStats(id) {
    try {
      const d = await App.api('GET', '/api/plugins/' + encodeURIComponent(id));
      const row = $('statRow');
      if (row) row.innerHTML = statHtml(d.plugin, d.commentCount);
    } catch {}
  }

  // ------------------------------------------------------------ 留言
  function commentHtml(c, isReply) {
    return `
      <div class="cmt ${isReply ? 'cmt-reply' : ''}" data-cid="${c.id}">
        <div class="cmt-head">
          <span class="badge ${c.isOwner ? 'badge-purple' : ''}">${esc(c.author)}${c.isOwner ? ' · 作者' : ''}</span>
          <span>${App.fmtRel(c.created)}</span>
          <span class="spacer"></span>
          <button class="btn btn-sm btn-ghost" data-reply="${c.id}" data-author="${esc(c.author)}">回复</button>
          ${c.canDelete ? '<button class="btn btn-sm btn-ghost" data-del="1" style="color:var(--red)">删除</button>' : ''}
        </div>
        ${c.replyTo ? `<div class="cmt-replyto">回复 <b>@${esc(c.replyTo)}</b>${c.replyToIsOwner ? '（作者）' : ''}</div>` : ''}
        <div class="cmt-body">${esc(c.body)}</div>
        <div class="cmt-replybox" hidden></div>
        ${
          c.replies && c.replies.length
            ? `<div class="cmt-replies">${c.replies.map((r) => commentHtml(r, true)).join('')}</div>`
            : ''
        }
      </div>`;
  }

  async function loadComments(pluginId, pre) {
    const list = $('cmtList');
    let data = pre;
    try {
      if (!data || !data.items) data = await App.api('GET', `/api/plugins/${encodeURIComponent(pluginId)}/comments`);
    } catch (e) {
      list.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }
    const items = data.items || [];
    if (!items.length) {
      list.innerHTML = '<div class="muted small" style="padding:12px 0">还没有人留言，来做第一个吧。</div>';
      return;
    }
    list.innerHTML = items.map((c) => commentHtml(c, false)).join('');

    list.querySelectorAll('[data-del]').forEach((b) => {
      b.onclick = async () => {
        const cid = b.closest('.cmt').dataset.cid;
        if (!confirm('确定删除这条留言吗？它的回复会保留。')) return;
        try {
          await App.api('DELETE', '/api/comments/' + cid);
          App.toast('留言已删除', 'ok');
          loadComments(pluginId);
        } catch (e) {
          App.toast(e.message, 'err');
        }
      };
    });

    list.querySelectorAll('[data-reply]').forEach((b) => {
      b.onclick = () => {
        const box = b.closest('.cmt').querySelector('.cmt-replybox');
        if (!box.hidden) {
          box.hidden = true;
          box.innerHTML = '';
          return;
        }
        box.hidden = false;
        box.innerHTML = `
          <div class="row" style="gap:8px;margin-top:8px">
            <input type="text" data-rinput style="flex:1" placeholder="回复 @${esc(b.dataset.author)}…" maxlength="1000">
            <button class="btn btn-sm btn-primary" data-rsend>发送</button>
            <button class="btn btn-sm btn-ghost" data-rcancel>取消</button>
          </div>`;
        const input = box.querySelector('[data-rinput]');
        const send = async () => {
          const text = input.value.trim();
          if (!text) return App.toast('请先输入回复内容', 'err');
          box.querySelector('[data-rsend]').disabled = true;
          try {
            await App.api('POST', `/api/plugins/${encodeURIComponent(pluginId)}/comments`, {
              body: text,
              parentId: Number(b.dataset.reply),
            });
            App.toast('回复已发布，作者会收到提醒', 'ok');
            const fresh = await App.api('GET', `/api/plugins/${encodeURIComponent(pluginId)}`);
            $('statRow').innerHTML = statHtml(fresh.plugin, fresh.commentCount);
            loadComments(pluginId);
          } catch (e) {
            App.toast(e.message, 'err');
            box.querySelector('[data-rsend]').disabled = false;
          }
        };
        box.querySelector('[data-rsend]').onclick = send;
        box.querySelector('[data-rcancel]').onclick = () => {
          box.hidden = true;
          box.innerHTML = '';
        };
        input.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            send();
          }
        });
        input.focus();
      };
    });
  }

  // ------------------------------------------------------------ 路由
  function route() {
    const m = /^#\/p\/([0-9a-zA-Z]+)$/.exec(location.hash);
    syncShellHash(m ? '#/p/' + m[1] : '');
    if (m) {
      openDetail(m[1]);
      window.scrollTo({ top: 0 });
    } else {
      state.currentId = null;
      $('viewDetail').hidden = true;
      $('viewList').hidden = false;
      loadList();
      loadStats();
    }
  }

  // ------------------------------------------------------------ 启动
  App.boot(() => {
    App.mountUser($('userArea'));
    App.mountBell($('bellArea'));

    $('q').addEventListener('input', (e) => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        state.q = e.target.value.trim();
        state.page = 1;
        if (!state.currentId) loadList();
      }, 280);
    });
    $('sort').addEventListener('change', (e) => {
      state.sort = e.target.value;
      state.page = 1;
      loadList();
    });
    $('backLink').onclick = (e) => {
      e.preventDefault();
      location.hash = '';
    };
    window.addEventListener('hashchange', route);
    route();
  });
})();
