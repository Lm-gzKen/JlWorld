'use strict';
/**
 * 插件回复闸门：只拦截统一标记的报错文案，其余一律放行。
 *
 * 约定：插件报错文案必须以便于检索的前缀开头，默认：
 *   【[404 error] 具体报错内容】
 * 框架看到这个前缀就丢弃（只写日志），避免报错刷屏；正常回复、欢迎语、卡片等全部原样放行。
 *
 * 配置项 plugins.replyGuard：
 *   enabled      总开关，默认 true
 *   blockErrors  是否拦截带前缀的报错，默认 true
 *   errorPrefix  报错前缀，默认 "【[404 error]"
 */

const DEFAULT_PREFIX = '【[404 error]';

function defaultsFrom(config) {
  const g = (config && config.get && config.get('plugins.replyGuard')) || {};
  return {
    enabled: g.enabled !== false,
    blockErrors: g.blockErrors !== false,
    errorPrefix: typeof g.errorPrefix === 'string' && g.errorPrefix ? g.errorPrefix : DEFAULT_PREFIX,
  };
}

class ReplyGuard {
  constructor({ config, logger, accountId } = {}) {
    this.config = config;
    this.log = logger || null;
    this.accountId = accountId || '';
    this.opts = defaultsFrom(config);
    this.dropped = 0;
  }

  refresh() {
    this.opts = defaultsFrom(this.config);
    return this.opts;
  }

  /** 给插件用的统一报错文案（插件也可以自己拼，只要前缀一致） */
  static errorText(message) {
    const body = String(message === undefined || message === null ? '' : message).trim();
    return `${DEFAULT_PREFIX} ${body}】`;
  }

  /**
   * @returns {{ok:boolean, reason?:string}}
   */
  check({ pluginId, kind, target, text }) {
    const o = this.opts;
    if (!o.enabled || !o.blockErrors) return { ok: true };
    const body = String(text || '');
    if (!body.includes(o.errorPrefix)) return { ok: true };

    this.dropped++;
    if (this.log) {
      try {
        this.log.warn(`插件 ${pluginId || '?'} 的报错文案已拦截（只写日志）`, {
          target: `${kind || 'group'}:${target || ''}`,
          sample: body.slice(0, 160),
        });
      } catch {
        /* ignore */
      }
    }
    return { ok: false, reason: 'error-prefix' };
  }

  reset() {
    this.dropped = 0;
  }
}

module.exports = ReplyGuard;
module.exports.defaultsFrom = defaultsFrom;
module.exports.DEFAULT_PREFIX = DEFAULT_PREFIX;
module.exports.errorText = ReplyGuard.errorText;
