'use strict';
/**
 * JlWBoT 入口（多账户）
 * 用法：node src/index.js [--port 8686] [--data-dir D:\data] [--no-open] [--token xxx]
 *
 * v1.3.7 起支持进程内重启：定时重启 / 面板手动重启 / 在线更新都复用同一套
 * “dispose 旧运行时 → 重新 boot”的流程，不退出进程，控制台窗口也不会关。
 */
const path = require('path');
const { exec } = require('child_process');

const U = require('./core/util');

function parseArgs(argv) {
  const out = { open: true };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--port' || a === '-p') out.port = Number(argv[++i]);
    else if (a === '--host') out.host = argv[++i];
    else if (a === '--data-dir') out.dataDir = argv[++i];
    else if (a === '--allow-email') out.allowEmail = argv[++i];
    else if (a === '--no-open') out.open = false;
    else if (a === '--force') out.force = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else if (a === '--version' || a === '-v') out.version = true;
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));

if (args.help) {
  console.log(`JlWBoT — QQ 官方机器人框架（多账户）

用法:
  node src/index.js [选项]

选项:
  -p, --port <端口>       面板端口（默认读配置）
  --host <地址>           监听地址（默认 127.0.0.1）
  --data-dir <目录>       数据目录（默认 项目目录\\~JlWBoT）
  --allow-email <邮箱>    添加一个允许登录后台的聚龙账户（首次运行/无交互环境）
  --no-open               启动后不自动打开浏览器
  --force                 忽略单实例锁强制启动（确认旧进程已死再用）
  -v, --version           版本号`);
  process.exit(0);
}

if (args.version) {
  console.log(require('../package.json').version);
  process.exit(0);
}

if (args.dataDir) process.env.JLW_DATA_DIR = path.resolve(args.dataDir);
U.ensureDir(U.dataRoot());

// 单实例锁：同一个数据目录只允许一个进程，避免两个网关重复收消息/重复回复
const instanceLock = require('./core/instance-lock');
const lock = instanceLock.acquire(U.dataRoot(), { force: args.force });
if (!lock.ok) {
  console.error('\n[ERROR] ' + lock.error + '\n');
  process.exit(1);
}
process.on('exit', () => instanceLock.release(lock.file));
// SQLite（配置/会话/日志/消息）：退出时 checkpoint 一下，目录里只留一个 .db 文件，方便整目录拷走
const store = require('./core/store');
process.on('exit', () => {
  try {
    store.close();
  } catch {
    /* ignore */
  }
});

// 崩溃取证必须最早装：logger 还没建好也要能在 ~JlWBoT/logs/crash.log 留下记录
const health = require('./core/health');
const guard = new health.CrashGuard({ dataDir: U.dataRoot(), version: require('../package.json').version }).install();
const prevHeartbeat = health.wasUncleanShutdown(U.dataRoot());

const Config = require('./core/config');
const Logger = require('./core/logger');
const endpoints = require('./core/endpoints');
const PluginManager = require('./core/plugins');
const AccountHost = require('./core/accounts');
const Webhook = require('./core/webhook');
const NetInfo = require('./core/netinfo');
const SessionStore = require('./core/session');
const JlwClient = require('./core/jlw');
const Updater = require('./core/updater');
const { ensureFirstAllowed } = require('./core/login-scope');
const maintenance = require('./core/maintenance');
const PanelServer = require('./core/server');

/** 进程级状态：重启时只替换 runtime，不重新加载模块 */
const state = {
  runtime: null,
  restartTimer: null,
  restartAt: 0,
  restartInfo: { enabled: false, minutes: 0, nextAt: 0 },
  restarting: false,
  stopping: false,
  bootCount: 0,
  heartbeatStarted: false,
  pruneTimer: null,
};

function clearRestartTimer() {
  if (state.restartTimer) clearTimeout(state.restartTimer);
  state.restartTimer = null;
  state.restartAt = 0;
}

/** 每次 boot 后重新排定时重启（配置保存时也会调用） */
function scheduleRestart() {
  clearRestartTimer();
  const rt = state.runtime;
  if (!rt || state.stopping) return;
  const { enabled, minutes } = maintenance.readRestartConfig(rt.config);

  if (!enabled) {
    state.restartInfo = { enabled: false, minutes: 0, nextAt: 0 };
    rt.panel?.setRestartSchedule?.(state.restartInfo);
    return;
  }

  const nextAt = maintenance.nextRestartAt(minutes);
  state.restartAt = nextAt;
  state.restartInfo = { enabled: true, minutes, nextAt };
  rt.panel?.setRestartSchedule?.(state.restartInfo);
  rt.logger.info(`已启用定时重启：${maintenance.describeRestart({ enabled, minutes })}`, {
    nextAt: new Date(nextAt).toLocaleString('zh-CN'),
  });

  state.restartTimer = setTimeout(() => {
    void restartApp('定时重启');
  }, Math.max(1000, nextAt - Date.now()));
  state.restartTimer.unref?.();
}

/** 拆掉一个运行时：账户/插件/面板/日志流；不退出进程 */
async function disposeRuntime(rt, reason) {
  if (!rt) return;
  try {
    rt.logger.info(`正在停用运行时（${reason}）…`);
  } catch {
    /* ignore */
  }
  try {
    await rt.host.dispose();
  } catch {
    /* ignore */
  }
  try {
    rt.plugins.dispose();
  } catch {
    /* ignore */
  }
  try {
    await rt.panel.stop();
  } catch {
    /* ignore */
  }
  try {
    rt.logger.close();
  } catch {
    /* ignore */
  }
}

/** 进程内重启：不退出 node，控制台窗口和启动器不受影响 */
async function restartApp(reason) {
  if (state.restarting || state.stopping) return { ok: false, error: '正在重启或退出' };
  const rt = state.runtime;
  if (!rt) return { ok: false, error: '没有运行中的实例' };
  state.restarting = true;
  clearRestartTimer();
  try {
    await disposeRuntime(rt, reason);
    state.runtime = null;
    await U.sleep(200);
    await boot({ silentBanner: true });
    return { ok: true };
  } catch (e) {
    guard.record('restartFailure', e, { reason });
    console.error('重启失败：', e);
    // 重启失败就退出，让启动器按异常重启兜底
    setTimeout(() => process.exit(1), 100).unref?.();
    return { ok: false, error: e.message };
  } finally {
    state.restarting = false;
  }
}

async function shutdown(reason) {
  if (state.stopping) return;
  state.stopping = true;
  clearRestartTimer();
  const rt = state.runtime;
  if (rt) {
    try {
      rt.logger.info(`收到 ${reason}，正在退出…`);
    } catch {
      /* ignore */
    }
    await disposeRuntime(rt, '进程退出');
    state.runtime = null;
  }
  guard.markCleanExit();
  process.exit(0);
}

async function boot({ silentBanner = false } = {}) {
  const config = new Config();
  // SQLite 里的历史数据按保留策略清理：日志 log.keepDays（默认 7 天）、消息 30 天
  try {
    store.pruneLogs(config.get('log.keepDays', 7));
    store.pruneMessages(30);
  } catch {
    /* ignore */
  }
  if (!state.pruneTimer) {
    state.pruneTimer = setInterval(() => {
      try {
        store.pruneLogs(config.get('log.keepDays', 7));
        store.pruneMessages(30);
        store.checkpoint();
      } catch {
        /* ignore */
      }
    }, 6 * 3600 * 1000);
    state.pruneTimer.unref?.();
  }
  const scope = await ensureFirstAllowed(config, { allowEmail: args.allowEmail });
  if (!scope.ok) {
    if (!scope.printed) console.error(scope.message || '首次运行需要先添加允许登录的聚龙账户');
    process.exit(1);
  }
  if (args.port) config.set('server.port', args.port);
  if (args.host) config.set('server.host', args.host);
  if (args.port || args.host) config.save();

  const logger = new Logger(config.data);
  guard.attachLogger(logger);
  if (!state.heartbeatStarted) {
    guard.startHeartbeat();
    state.heartbeatStarted = true;
  }
  state.bootCount++;
  for (const notice of config.notices || []) logger.warn(notice);
  logger.info(`JlWBoT v${require('../package.json').version} 启动中`, {
    dataDir: U.dataRoot(),
    node: process.version,
    bootCount: state.bootCount,
  });

  if (state.bootCount === 1) {
    if (prevHeartbeat) {
      logger.warn('上次运行没有正常收尾（可能被强制结束、崩溃或断电）', {
        lastPid: prevHeartbeat.pid,
        lastHeartbeat: prevHeartbeat.time,
        lastUptimeSec: prevHeartbeat.uptimeSec,
        crashLog: health.crashPath(U.dataRoot()),
      });
    }
    const lastCrashes = health.readCrashes(U.dataRoot(), 1);
    if (lastCrashes.length) {
      const c = lastCrashes[0];
      logger.warn(`上次崩溃记录：${c.kind} ${c.message}`, {
        time: c.time,
        pid: c.pid,
        crashLog: health.crashPath(U.dataRoot()),
      });
    }
  }

  const plugins = new PluginManager({ config, logger, endpoints });
  const host = new AccountHost({ config, logger, plugins, endpoints });
  const webhook = new Webhook({ logger });
  const netinfo = new NetInfo({ logger });
  const session = new SessionStore({ config, logger });
  const jlw = new JlwClient({ config, logger });
  const updater = new Updater({ config, logger });

  const panel = new PanelServer({
    config,
    logger,
    host,
    plugins,
    endpoints,
    webhook,
    netinfo,
    session,
    jlw,
    updater,
    onRestart: () => shutdown('在线更新'),
    onManualRestart: () => {
      setTimeout(() => void restartApp('面板手动重启'), 200);
      return true;
    },
    onConfigChange: (patch) => {
      if (patch?.log) logger.configure(config.data);
      scheduleRestart();
    },
  });

  plugins.attach(host);

  await plugins.init();
  await host.init();
  const url = await panel.start();

  const rt = { config, logger, plugins, host, webhook, netinfo, session, jlw, updater, panel };
  state.runtime = rt;
  scheduleRestart();

  if (!silentBanner) printBanner(url, config, host);
  else logger.info(`重启完成：${url}`);

  netinfo.get(false).catch(() => {});
  if (state.bootCount === 1 && args.open && config.get('server.openBrowser', true)) openBrowser(url);

  return rt;
}

function printBanner(url, config, host) {
  const accounts = host.list();
  const jlw = config.jlw();
  const lines = [
    '',
    '  ==============================================================',
    '   JlWBoT  ·  QQ 官方机器人控制台',
    '  ==============================================================',
    '',
    `  面板地址   ${url}`,
    `  登录方式   聚龙世界账户（邮箱 + 密码）`,
    `  账户站点   ${jlw.baseUrl || '未配置 —— 打开面板后在登录页填写'}`,
    `  数据目录   ${U.dataRoot()}`,
    `  账户数量   ${accounts.length}`,
  ];
  for (const a of accounts) {
    const mask = a.appIdMasked || '未配置';
    lines.push(`    · ${a.name} (${a.id})  ${a.mode === 'webhook' ? 'WebHook' : 'WebSocket'}  ${mask}  ${a.state}`);
  }
  lines.push(`  插件数量   ${host.plugins.registry.size}`, '');
  console.log(lines.join('\n'));
}

function openBrowser(url) {
  const cmd =
    process.platform === 'win32'
      ? `start "" "${url}"`
      : process.platform === 'darwin'
        ? `open "${url}"`
        : `xdg-open "${url}"`;
  exec(cmd, () => {});
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
// uncaughtException / unhandledRejection 由 core/health.js 的 CrashGuard 统一兜住并写 crash.log

boot().catch((e) => {
  console.error('启动失败：', e);
  try {
    guard.record('startupFailure', e);
  } catch {
    /* ignore */
  }
  process.exit(1);
});
