/* 首页：Bot 图标 + 公告（管理员可直接编辑）+ 统计 */
(function () {
  const esc = window.escapeHtml;
  const $ = (id) => document.getElementById(id);
  let canEdit = false;
  let currentAnn = '';

  async function loadSettings() {
    let s;
    try {
      s = await App.api('GET', '/api/settings');
    } catch (e) {
      $('annBody').innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`;
      return;
    }
    if (s.botName && s.botName.value) $('botName').textContent = s.botName.value;

    canEdit = !!s.canEdit;
    $('annEdit').hidden = !canEdit;

    const ann = s.announcement || { value: '' };
    currentAnn = ann.value || '';
    $('annBody').innerHTML = ann.value.trim()
      ? window.renderMarkdown(ann.value)
      : `<p class="muted">${canEdit ? '还没有公告，点右上角「编辑公告」写一条吧。' : '管理员还没有发布公告。'}</p>`;
    $('annMeta').textContent = ann.updated ? App.fmtTime(ann.updated) : '';
    mountPeek(ann.value);
  }

  /** 首屏最底下那两行公告预览（半透明，往下滚就淡出） */
  function mountPeek(md) {
    const host = document.querySelector('.hero-sticky');
    if (!host) return;
    let peek = $('annPeek');
    if (!peek) {
      peek = document.createElement('div');
      peek.className = 'ann-peek';
      peek.id = 'annPeek';
      host.appendChild(peek);
    }
    const plain = String(md || '')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
      .replace(/```[\s\S]*?```/g, ' ')
      .replace(/[#>*`_~|]/g, ' ')
      .replace(/https?:\/\/\S+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!plain) {
      peek.hidden = true;
      return;
    }
    peek.hidden = false;
    peek.innerHTML = '<span class="ap-tag">📢 公告</span>' + esc(plain.slice(0, 160));
  }

  async function loadStats() {
    try {
      const s = await App.api('GET', '/api/stats');
      $('homeStats').innerHTML = `
        <div class="s">插件 <b>${s.plugins}</b></div>
        <div class="s">累计下载 <b>${s.downloads}</b></div>
        <div class="s">累计浏览 <b>${s.views}</b></div>
        <div class="s">开发者 <b>${s.developers}</b></div>
        <div class="s" title="用聚龙世界账户登录过本站的人数">账户 <b>${s.users}</b></div>`;
    } catch {}
  }

  // 管理员编辑公告（写进 settings 表，换代码文件不会丢）
  function openEditor() {
    const box = App.h(`
      <div class="gate">
        <div class="gate-box" style="max-width:760px">
          <div class="gate-head" style="text-align:left">
            <h2 style="font-size:17px">编辑首页公告</h2>
            <p>支持 Markdown：标题、粗体、列表、表格、代码块、图片直链</p>
          </div>
          <div class="gate-body">
            <textarea data-ann style="min-height:300px;font-family:var(--mono);font-size:13.4px"></textarea>
            <div class="alert alert-err" data-err hidden style="margin-top:10px"></div>
            <div class="row" style="margin-top:14px">
              <button class="btn btn-primary" data-save>保存公告</button>
              <button class="btn" data-cancel>取消</button>
              <span class="spacer"></span>
              <span class="tiny muted-2">保存后首页立即生效</span>
            </div>
          </div>
        </div>
      </div>`);
    box.querySelector('[data-ann]').value = currentAnn || '';
    document.body.appendChild(box);

    const errBox = box.querySelector('[data-err]');
    box.querySelector('[data-cancel]').onclick = () => box.remove();
    box.querySelector('[data-save]').onclick = async () => {
      const btn = box.querySelector('[data-save]');
      errBox.hidden = true;
      btn.disabled = true;
      try {
        await App.api('POST', '/api/admin/settings', { announcement: box.querySelector('[data-ann]').value });
        box.remove();
        App.toast('公告已更新', 'ok');
        loadSettings();
      } catch (e) {
        errBox.hidden = false;
        errBox.textContent = e.message;
        btn.disabled = false;
      }
    };
  }

  // 首屏：图标一开始超大居中，往下滚一段（死区）之后才平滑缩回 172px
  function heroScroll() {
    const hero = $('heroHome');
    const img = $('botIcon');
    if (!hero || !img) return;
    const reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    let raf = 0;
    const apply = () => {
      raf = 0;
      const vh = window.innerHeight;
      const drive = Math.max(1, hero.offsetHeight - vh);
      const y = window.scrollY || 0;
      const dead = drive * 0.18;
      const k = Math.min(1, Math.max(0, (y - dead) / Math.max(1, drive - dead)));
      const e = k * k * (3 - 2 * k);
      const w = img.offsetWidth || 1;
      const end = Math.min(1, 172 / w);
      if (!reduce) {
        img.style.transform = 'scale(' + (1 - (1 - end) * e).toFixed(4) + ')';
        const inner = document.getElementById('heroInner');
        if (inner) inner.style.transform = 'translateY(' + (-20 * e).toFixed(2) + 'vh)';
      }
      const peek = document.getElementById('annPeek');
      if (peek) peek.style.opacity = String(Math.max(0, 0.34 * (1 - e * 1.4)).toFixed(3));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(apply);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    apply();
  }

  App.boot(async () => {
    App.mountUser($('userArea'));
    App.mountBell($('bellArea'));

    $('annEdit').onclick = openEditor;
    loadSettings();
    loadStats();
    heroScroll();
  });
})();
