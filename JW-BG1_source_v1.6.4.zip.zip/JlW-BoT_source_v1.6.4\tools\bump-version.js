#!/usr/bin/env node
'use strict';
/**
 * 发版前统一改版本号：node tools/bump-version.js 1.4.7
 *
 * 只改「当前版本」这类明确锚点，不动变更记录里的历史版本、也不改测试数字；
 * 跑完会打印还需要手工确认的清单（变更记录、测试数、历史导出列表）。
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const ver = String(process.argv[2] || '').trim();

if (!/^\d+\.\d+\.\d+$/.test(ver)) {
  console.error('用法: node tools/bump-version.js <主>.<次>.<修订>   例如 1.4.7');
  process.exit(1);
}

const changed = [];
const missing = [];

function patch(rel, patterns) {
  const file = path.join(root, rel);
  let text = fs.readFileSync(file, 'utf8');
  const before = text;
  for (const { label, re, repl } of patterns) {
    if (!re.test(text)) {
      missing.push(`${label}（${rel}）`);
      continue;
    }
    text = text.replace(re, repl);
  }
  if (text !== before) {
    fs.writeFileSync(file, text, 'utf8');
    changed.push(rel);
  }
}

const v = (m) => String(m).replace(/\d+\.\d+\.\d+/, ver);

patch('package.json', [{ label: 'package.json version', re: /"version": "\d+\.\d+\.\d+"/, repl: (m) => `"version": "${ver}"` }]);

patch('src/web/index.html', [
  { label: '侧边栏版本号', re: /<small id="brand-version">v\d+\.\d+\.\d+<\/small>/, repl: (m) => `<small id="brand-version">v${ver}</small>` },
]);

patch('src/web/docs.html', [
  { label: '文档页适用版本', re: /<span>适用 v\d+\.\d+\.\d+\+<\/span>/, repl: (m) => `<span>适用 v${ver}+</span>` },
]);

patch('docs/插件开发.md', [
  { label: '插件文档适用版本', re: /> 适用版本：JlWBoT v\d+\.\d+\.\d+\+/, repl: (m) => `> 适用版本：JlWBoT v${ver}+` },
]);

patch('docs/部署与脱机运行.md', [
  { label: '部署文档升级版本', re: /升级到 v\d+\.\d+\.\d+/, repl: v },
]);

patch('README.md', [
  { label: 'README 顶部当前版本', re: /> 当前版本：\*\*v\d+\.\d+\.\d+\*\*/, repl: (m) => `> 当前版本：**v${ver}**` },
  { label: 'README 交接卡版本', re: /\| 版本 \| `\d+\.\d+\.\d+`（`package\.json`） \|/, repl: (m) => `| 版本 | \`${ver}\`（\`package.json\`） |` },
  { label: 'README Get-FileHash', re: /Get-FileHash "框架导出\\JlW-BoT \[v\d+\.\d+\.\d+\]\.zip"/, repl: (m) => `Get-FileHash "框架导出\\JlW-BoT [v${ver}].zip"` },
  { label: 'README 源码版本', re: /\| 源码版本 \| \*\*v\d+\.\d+\.\d+\*\* \|/, repl: (m) => `| 源码版本 | **v${ver}** |` },
  { label: 'README 导出包', re: /\| 导出包 \| `框架导出\\JlW-BoT \[v\d+\.\d+\.\d+\]\.zip`/, repl: (m) => `| 导出包 | \`框架导出\\JlW-BoT [v${ver}].zip\`` },
  { label: 'README 页面版本提示', re: /本地已是 v\d+\.\d+\.\d+/, repl: (m) => `本地已是 v${ver}` },
  { label: 'README 首次升级说明', re: /必须手动换成 v\d+\.\d+\.\d+/, repl: (m) => `必须手动换成 v${ver}` },
  { label: 'README 低于本机版本', re: /低于本机 v\d+\.\d+\.\d+/, repl: (m) => `低于本机 v${ver}` },
]);

console.log(`\n目标版本：v${ver}`);
console.log(changed.length ? `已更新：${changed.join('、')}` : '没有文件需要更新');
if (missing.length) {
  console.log('\n[注意] 下面这些锚点没匹配到，请手动确认：');
  for (const m of missing) console.log('  - ' + m);
}
console.log('\n还要手工做：');
console.log('  1. README「## 17. 变更记录」加 v' + ver + ' 条目（写清改了什么）');
console.log('  2. README 测试数字：0.3 快照、12.1 合计、12.2 命令、变更记录');
console.log('  3. README 目录清单里的 `框架导出/` 历史列表补 [v' + ver + ']');
console.log('  4. node test/run-all.js 全量回归');
console.log('  5. powershell -ExecutionPolicy Bypass -File tools\\export-framework.ps1');
console.log('');
