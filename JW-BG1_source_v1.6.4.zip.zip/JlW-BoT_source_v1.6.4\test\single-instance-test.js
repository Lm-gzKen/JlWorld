'use strict';
/**
 * 单实例锁 + 旧共享状态兼容
 *   node test/single-instance-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitHealth(base, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(base + '/health', { signal: AbortSignal.timeout(1200) });
      if (r.ok) return await r.json();
    } catch {
      /* retry */
    }
    await sleep(200);
  }
  return null;
}

function spawnApp(dir, extraArgs = [], port) {
  const args = [path.join(ROOT, 'src', 'index.js'), '--no-open', ...extraArgs];
  if (port) args.push('--port', String(port));
  return spawn(process.execPath, args, {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
}

function collect(child) {
  const buf = { text: '' };
  child.stdout.on('data', (d) => (buf.text += String(d)));
  child.stderr.on('data', (d) => (buf.text += String(d)));
  return buf;
}

(async () => {
  /* ---------------- 旧共享对象兼容（Arknights .keys 报错） ---------------- */
  {
    delete globalThis.__ARKNIGHTS_SHARED__;
    globalThis.__ARKNIGHTS_SHARED__ = { seen: new Map(), sends: new Map() };
    let mod = null;
    let threw = null;
    try {
      mod = require('../plugins/Arknights/index.js');
    } catch (e) {
      threw = e;
    }
    check(!threw, '旧版共享对象不会让插件加载失败', threw?.message);
    check(typeof mod?._internal?.newestLiveSeq === 'function', '导出 newestLiveSeq 供测试');
    let seq = null;
    try {
      seq = mod?._internal?.newestLiveSeq();
    } catch (e) {
      threw = e;
    }
    check(seq === 0, '缺 live 时 newestLiveSeq 返回 0 而不是 .keys 报错', String(seq));
    check(globalThis.__ARKNIGHTS_SHARED__.live instanceof Map, '自动补齐 live Map');
    delete globalThis.__ARKNIGHTS_SHARED__;
  }

  /* ---------------- 单实例锁 ---------------- */
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-lock-'));
  const port = 24500 + Math.floor(Math.random() * 200);
  const base = `http://127.0.0.1:${port}`;
  fs.writeFileSync(
    path.join(dir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: 'http://127.0.0.1:1' },
        auth: { allowed: ['t@t.t'], initialized: true },
        accounts: [],
        plugins: { enabled: false },
        log: { level: 'info', console: false },
      },
      null,
      2,
    ),
  );

  let a = null;
  let b = null;
  try {
    a = spawnApp(dir);
    collect(a);
    const h = await waitHealth(base);
    check(!!h, '第一个实例启动成功', JSON.stringify(h));
    const lock = JSON.parse(fs.readFileSync(path.join(dir, 'run.pid'), 'utf8'));
    check(lock.pid === h.pid, 'run.pid 记录当前 PID', `${lock.pid} vs ${h?.pid}`);

    // 第二个实例：同一数据目录应被拒绝
    b = spawnApp(dir);
    const buf = collect(b);
    const exited = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(false), 12000);
      b.on('exit', () => {
        clearTimeout(timer);
        resolve(true);
      });
    });
    check(exited, '第二个实例被单实例锁拦下并退出');
    check(b.exitCode !== 0, '被拦下的实例退出码非 0', String(b.exitCode));
    check(/已有另一个 JlWBoT 实例在运行/.test(buf.text), '提示里说明已有实例与处理办法', buf.text.slice(-200));
    b = null;

    // 结束第一个实例：Windows 强杀不会触发 exit 钩子，锁可能残留，但新实例必须能接管
    a.kill();
    await new Promise((r) => a.on('exit', r));
    a = null;
    await sleep(500);

    const c = spawnApp(dir);
    const cbuf = collect(c);
    const h2 = await waitHealth(base);
    check(!!h2, '旧实例退出后新实例可以启动', cbuf.text.slice(-200));
    const lock2 = JSON.parse(fs.readFileSync(path.join(dir, 'run.pid'), 'utf8'));
    check(lock2.pid === h2?.pid, '残留的运行锁被新实例接管', `${lock2.pid} vs ${h2?.pid}`);

    // --force：锁被占用也能强开（换端口）
    const port2 = port + 1;
    const forced = spawnApp(dir, ['--force'], port2);
    const fbuf = collect(forced);
    const h3 = await waitHealth(`http://127.0.0.1:${port2}`, 15000);
    check(!!h3, '--force 可以忽略锁启动', fbuf.text.slice(-200));
    check(h3 && h3.pid !== c.pid, '--force 实例是另一个 PID');
    forced.kill();
    await new Promise((r) => forced.on('exit', r));
    c.kill();
    await new Promise((r) => c.on('exit', r));
  } finally {
    for (const child of [a, b]) {
      try {
        child?.kill();
      } catch {
        /* ignore */
      }
    }
    try {
      fs.rmSync(dir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
