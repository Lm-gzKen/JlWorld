'use strict';
/**
 * 星火插件 · 单元自测（不联网、不需要跑框架）
 *
 *   node test/xinghuo-test.js
 *
 * 覆盖：配置归一化 / 用户库合并 / 兑换码生命周期 / 任务执行 /
 *       快照注入 / VloS 余额读取与发奖（假 API）/ 指令解析。
 */

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const PLUGIN = path.join(ROOT, 'plugins', 'xinghuo');
const Store = require(path.join(PLUGIN, 'lib', 'store'));
const U = require(path.join(PLUGIN, 'lib', 'util'));
const { normalizeConfig, DEFAULT_ANNOUNCEMENT } = require(path.join(PLUGIN, 'lib', 'defaults'));
const snapshot = require(path.join(PLUGIN, 'lib', 'snapshot'));
const vlosApi = require(path.join(PLUGIN, 'lib', 'vlos'));
const plugin = require(path.join(PLUGIN, 'index.js'));

let passed = 0;
function ok(cond, label) {
  assert.ok(cond, label);
  console.log('  ✓ ' + label);
  passed++;
}
function eq(a, b, label) {
  assert.strictEqual(a, b, label + `（实际 ${JSON.stringify(a)} / 期望 ${JSON.stringify(b)}）`);
  console.log('  ✓ ' + label);
  passed++;
}
function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'xh-test-'));
}
function makeRuntime(dir, cfg) {
  const store = new Store(path.join(dir, 'data'), {});
  return {
    dir,
    cfg: normalizeConfig(cfg || {}),
    store,
    log: { info() {}, warn() {}, error() {}, debug() {} },
    frameworkConfig: null,
    bot: null,
    accountId: 'a1',
    accounts: [{ id: 'a1', name: '测试' }],
    version: '1.0.0',
    disposed: false,
    redeeming: new Set(),
    cooldowns: new Map(),
    snapshotAt: 0,
    warned: new Set(),
  };
}
function readSnapshot(dir) {
  const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
  const m = /<script id="xh-data" type="application\/json">([\s\S]*?)<\/script>/.exec(html);
  assert.ok(m, 'settings.html 里应该有 xh-data 快照');
  return JSON.parse(m[1]);
}
function fakeVlos(overrides = {}) {
  const calls = [];
  const users = {
    'U1@TEST.LOCAL': {
      key: 'u1',
      email: 'u1@test.local',
      qq: '10001',
      name: '阿一',
      wallet: { longjing: 10, xuanyu: 1 },
      vlosBalance: { longjing: 2, xuanyu: 0 },
      balances: { longjing: 0, xuanyu: 0 },
    },
  };
  const api = {
    pluginId: 'VloS',
    version: '2.9.56',
    isReady: () => true,
    stats: () => ({
      users: 3,
      bound: 2,
      signedToday: 1,
      pendingLongjing: 100,
      pendingXuanyu: 7,
      walletLongjing: 1000,
      walletXuanyu: 50,
      longjing: 5,
      xuanyu: 1,
    }),
    getUser: (voucher) => users[String(voucher || '').toUpperCase()] || null,
    listUsers: () => ({ total: 1, users: Object.values(users) }),
    addWallet: async (voucher, delta) => {
      calls.push({ fn: 'addWallet', voucher, delta });
      return { wallet: { longjing: 110, xuanyu: 52 } };
    },
    addVlosBalance: (voucher, delta) => {
      calls.push({ fn: 'addVlosBalance', voucher, delta });
      const u = users['U1@TEST.LOCAL'];
      const before = { ...u.vlosBalance };
      u.vlosBalance.longjing += Number(delta.longjing) || 0;
      u.vlosBalance.xuanyu += Number(delta.xuanyu) || 0;
      const after = { ...u.vlosBalance };
      return {
        key: 'u1',
        before,
        after,
        delta: { longjing: after.longjing - before.longjing, xuanyu: after.xuanyu - before.xuanyu },
        vlosBalance: after,
        user: { wallet: { longjing: 10, xuanyu: 1 } },
      };
    },
    vlosBalance: () => ({ ...users['U1@TEST.LOCAL'].vlosBalance }),
    ...overrides,
  };
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map([['VloS', api]]);
  return { api, calls };
}

function testConfig() {
  console.log('\n配置归一化');
  const cfg = normalizeConfig({
    announce: { delayMs: 10, markdown: '', adminOpenids: 'a,b' },
    redeem: { creditTarget: 'nope', cooldownSec: -3 },
    command: { names: 'XH, 星火' },
    custom: { keep: true },
    tasks: [{ id: 't1', type: 'x' }, { bad: 1 }],
  });
  eq(cfg.announce.delayMs, 300, '公告间隔下限 300ms');
  eq(cfg.announce.markdown, '', 'markdown 允许为空（页面回退默认草稿）');
  eq(cfg.announce.adminOpenids.join(','), 'a,b', '管理员 openid 字符串转数组');
  eq(cfg.redeem.creditTarget, undefined, '已移除到账位置配置');
  eq(cfg.redeem.cooldownSec, 0, '冷却时间下限 0');
  eq(cfg.vlos, undefined, '已移除金库配置');
  eq(cfg.jlAccount, undefined, '已移除备用发奖 Key 配置');
  eq(cfg.profile.delayMs, 800, '资料刷新间隔默认 800ms');
  eq(cfg.command.names.join(','), 'xh,星火', '指令名小写化');
  eq(cfg.custom.keep, true, '保留未知顶层字段');
  eq(cfg.tasks.length, 1, '过滤掉没有 id 的任务');
  ok(DEFAULT_ANNOUNCEMENT.includes('星火公告'), '默认公告有标题');
}

function testStore() {
  console.log('\n用户库');
  const dir = tmpDir();
  const s = new Store(path.join(dir, 'data'), {});

  const a = s.upsertFriend({ openid: 'A'.repeat(32), accountId: 'a1', name: '好友甲', source: 'event' });
  ok(a.created, '新好友');
  const again = s.upsertFriend({ openid: 'A'.repeat(32), accountId: 'a1', name: '好友甲2', source: 'event' });
  ok(!again.created, '重复事件不重复新增');
  eq(s.data.friends['A'.repeat(32)].name, '好友甲2', '昵称更新');
  eq(s.counts().friendsActive, 1, '有效好友 1');

  const g = s.upsertGroup({ group_openid: 'G'.repeat(32), accountId: 'a1', source: 'event' });
  ok(g.created, '新群');
  s.markGroupLeft('G'.repeat(32), 'a1');
  eq(s.data.groups['G'.repeat(32)].status, 'left', '退群标记');

  const imp = s.mergeRows(
    'friend',
    [
      { o: 'B'.repeat(32), u: 'U'.repeat(32), t: 1795408123 },
      { o: 'B'.repeat(32) },
      { o: 'bad id!' },
    ],
    { source: 'export.zip' },
  );
  eq(imp.added, 1, '导入新增 1（同文件去重）');
  eq(imp.skipped, 1, '非法行跳过');
  eq(s.data.friends['B'.repeat(32)].addTime, 1795408123 * 1000, 'add_time 秒转毫秒');
  eq(s.data.friends['B'.repeat(32)].sources.import, true, '导入来源');

  s.markFriendRemoved('B'.repeat(32), 'a1');
  eq(s.data.friends['B'.repeat(32)].status, 'removed', '删好友标记');
  s.mergeRows('friend', [{ o: 'B'.repeat(32) }], { source: 'old.zip' });
  eq(s.data.friends['B'.repeat(32)].status, 'removed', '导入旧包不复活已删除好友');

  // 群发失败 → 无效；再次收到事件 → 恢复有效
  s.markFriendInvalid('A'.repeat(32), '40034 频控');
  eq(s.data.friends['A'.repeat(32)].status, 'invalid', '发送失败标记为无效');
  eq(s.counts().friendsInvalid, 1, '无效好友计数');
  ok(!s.activeFriends().some((u) => u.openid === 'A'.repeat(32)), '无效好友不进入群发目标');
  s.upsertFriend({ openid: 'A'.repeat(32), name: '好友甲2', source: 'event' });
  eq(s.data.friends['A'.repeat(32)].status, 'active', '再次收到事件恢复有效');
  eq(s.data.friends['A'.repeat(32)].invalidReason, '', '恢复有效时清空无效原因');

  // 群头像兜底（官方 group_info 不保证返回群头像）
  const iconGroup = s.upsertGroup({ group_openid: 'R'.repeat(32), name: '测试群头像' });
  ok(/^data:image\/svg\+xml/.test(iconGroup.group.avatar), '群头像用群名首字兜底');
  ok(iconGroup.group.avatar.length <= 512, '群头像兜底长度不超过头像字段上限');

  // 群导入
  const impG = s.mergeRows('group', [{ o: 'Q'.repeat(32), t: 1767369600 }], { source: 'group.zip' });
  eq(impG.added, 1, '群导入新增');
  eq(s.data.groups['Q'.repeat(32)].joinTime, 1767369600 * 1000, 'join_time 秒转毫秒');

  // 数据文件落盘
  s.flush();
  const raw = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'xinghuo.json'), 'utf8'));
  ok(raw.friends['A'.repeat(32)], '数据写入 xinghuo.json');
  fs.rmSync(dir, { recursive: true, force: true });
}

function testCodes() {
  console.log('\n兑换码');
  const dir = tmpDir();
  const s = new Store(path.join(dir, 'data'), {});

  const r1 = s.createCodes(
    [
      { code: 'xh-demo-0001', longjing: 100, xuanyu: 5, message: '恭喜' },
      { code: 'XHDEMO0001', longjing: 999 },
      { code: 'short', longjing: 1 },
      { code: 'XHEXPIRED001', longjing: 1, expireDays: 1 },
    ],
    { createdBy: 'admin' },
  );
  eq(r1.created.length, 2, '生成 2 张（重复 / 太短跳过）');
  eq(s.getCode('xh-demo-0001').longjing, 100, '码统一成大写可查询');
  eq(s.getCode('XHDEMO0001').status, 'active', '新码可用');

  const b1 = s.beginRedeem('XHDEMO0001');
  ok(b1.ok, '开始兑换');
  eq(s.getCode('XHDEMO0001').status, 'redeeming', '兑换中锁定');
  ok(!s.beginRedeem('XHDEMO0001').ok, '重复开始被拒绝');
  s.finishRedeem('XHDEMO0001', { openid: 'A'.repeat(32), email: 'a@b.c', at: Date.now(), longjing: 100, xuanyu: 5, via: 'vlos' });
  eq(s.getCode('XHDEMO0001').status, 'exhausted', '用完后失效');
  eq(s.getCode('XHDEMO0001').uses, 1, '使用次数 +1');

  // 多次可用
  s.createCodes([{ code: 'XHMULTI0001', longjing: 1, maxUses: 2 }], {});
  s.beginRedeem('XHMULTI0001');
  s.finishRedeem('XHMULTI0001', { openid: 'A', at: Date.now() });
  eq(s.getCode('XHMULTI0001').status, 'active', '未用完仍是可用');
  s.beginRedeem('XHMULTI0001');
  s.finishRedeem('XHMULTI0001', { openid: 'B', at: Date.now() });
  eq(s.getCode('XHMULTI0001').status, 'exhausted', '第二次后失效');

  // 固定码 + 可兑换次数 0 = 无限
  const fixed = s.createCodes([{ code: 'XHFIXED0001', longjing: 3, maxUses: 0 }], {});
  eq(fixed.created.length, 1, '固定码只生成一个');
  for (const openid of ['F1', 'F2', 'F3']) {
    eq(s.beginRedeem('XHFIXED0001').ok, true, '无限码可开始兑换');
    s.finishRedeem('XHFIXED0001', { openid, at: Date.now() });
  }
  eq(s.getCode('XHFIXED0001').uses, 3, '无限码累计次数');
  eq(s.getCode('XHFIXED0001').status, 'active', '0 次上限表示无限，仍可用');
  const dup = s.createCodes([{ code: 'XHFIXED0001', longjing: 1 }], {});
  eq(dup.created.length, 0, '固定码不可重复生成');
  eq(dup.skipped[0].reason, '已存在', '重复码给出原因');
  s.createCodes([{ code: 'XHOPEN0001', longjing: 1, maxUses: 5, oncePerUser: false }], {});
  eq(s.getCode('XHOPEN0001').oncePerUser, false, '每人限一次可关闭');

  // 过期
  const expired = s.getCode('XHEXPIRED001');
  expired.expiresAt = Date.now() - 1000;
  ok(s.isExpired(expired), '过期判断');
  eq(s.beginRedeem('XHEXPIRED001').reason, 'expired', '过期码不能兑换');

  // 停用 / 启用 / 删除
  s.codeAction('XHDEMO0001', 'disable');
  eq(s.getCode('XHDEMO0001').status, 'disabled', '停用');
  eq(s.beginRedeem('XHDEMO0001').reason, 'disabled', '停用码不能兑换');
  s.codeAction('XHDEMO0001', 'enable');
  eq(s.getCode('XHDEMO0001').status, 'exhausted', '启用不会把已用完的码变可用');
  s.codeAction('XHEXPIRED001', 'delete');
  eq(s.getCode('XHEXPIRED001'), null, '删除');

  // 部分到账 -> 异常
  s.createCodes([{ code: 'XHPARTIAL001', longjing: 10, xuanyu: 2 }], {});
  s.beginRedeem('XHPARTIAL001');
  s.abortRedeem('XHPARTIAL001', { error: '第二笔失败', granted: { longjing: 10, xuanyu: 0 } });
  eq(s.getCode('XHPARTIAL001').status, 'failed', '部分到账标记异常');
  ok(/第二笔失败/.test(s.getCode('XHPARTIAL001').lastError), '记录失败原因');
  // 未到账 -> 恢复可用
  s.createCodes([{ code: 'XHRETRY0001', longjing: 10 }], {});
  s.beginRedeem('XHRETRY0001');
  s.abortRedeem('XHRETRY0001', { error: '网络错误', granted: { longjing: 0, xuanyu: 0 } });
  eq(s.getCode('XHRETRY0001').status, 'active', '未到账恢复可用');

  const totals = s.codeTotals();
  ok(totals.total >= 3 && totals.exhausted >= 2, '汇总统计');
  fs.rmSync(dir, { recursive: true, force: true });
}

function testTasksAndSnapshot() {
  console.log('\n任务 / 快照');
  const dir = tmpDir();
  fs.copyFileSync(path.join(PLUGIN, 'settings.html'), path.join(dir, 'settings.html'));
  const r = makeRuntime(dir, {});
  r.store.upsertFriend({ openid: 'A'.repeat(32), accountId: 'a1', name: '甲', source: 'event' });

  // 导入任务
  return (async () => {
    const imp = await plugin.__internal.runTask(r, {
      id: 't-imp',
      type: 'import-users',
      payload: { source: 'export.zip', items: [{ kind: 'friend', rows: [{ o: 'C'.repeat(32), t: 1795408123 }] }, { kind: 'group', rows: [{ o: 'D'.repeat(32) }] }] },
    });
    eq(imp.friends.added, 1, '任务：导入好友');
    eq(imp.groups.added, 1, '任务：导入群');

    const made = await plugin.__internal.runTask(r, {
      id: 't-code',
      type: 'create-codes',
      payload: { codes: [{ code: 'XHTASK000001', longjing: 20, xuanyu: 1, message: '任务码' }] },
    });
    eq(made.created.length, 1, '任务：生成兑换码');

    const disabled = await plugin.__internal.runTask(r, { id: 't-dis', type: 'code-action', payload: { code: 'XHTASK000001', action: 'disable' } });
    eq(disabled.status, 'disabled', '任务：停用兑换码');

    const ann = await plugin.__internal.runTask(r, { id: 't-ann', type: 'announce', payload: { markdown: '## 测试', delayMs: 300 } });
    eq(ann.total, 2, '任务：创建公告，目标为 2 位有效好友');
    const job = r.store.runnableAnnouncement();
    ok(job && job.id === ann.id && job.status === 'queued', '公告任务排队');

    const cancelled = await plugin.__internal.runTask(r, { id: 't-cancel', type: 'announce-cancel', payload: { id: ann.id } });
    eq(cancelled.status, 'cancelled', '任务：取消公告');

    // 快照
    ok(snapshot.refresh(r), '写快照');
    const data = readSnapshot(dir);
    eq(data.stats.friends, 2, '快照：好友数 2');
    eq(data.stats.groups, 1, '快照：群数 1');
    ok(data.codes.some((c) => c.code === 'XHTASK000001' && c.status === 'disabled'), '快照：兑换码状态');
    ok(data.announcements.some((a) => a.id === ann.id && a.status === 'cancelled'), '快照：公告记录');
    eq(data.limits.listLimit, 800, '快照：展示上限');
    const html = fs.readFileSync(path.join(dir, 'settings.html'), 'utf8');
    eq((html.match(/XH_DATA_START/g) || []).length, 1, '快照占位区只保留一处');

    // 处理过的任务幂等
    r.store.markTask('t-imp', { type: 'import-users', ok: true, result: imp });
    ok(r.store.taskDone('t-imp'), '任务标记完成');
    eq(r.store.recentTasks(10).length, 1, 'recentTasks 只包含已记录任务');

    fs.rmSync(dir, { recursive: true, force: true });
  })();
}

function testVlos() {
  console.log('\nVloS 对接');
  const { calls } = fakeVlos();
  const bal = vlosApi.readBalance();
  ok(bal.ready, '读到余额');
  eq(bal.pool.vlosLongjing, 100, 'VloS 余额合计（龙晶）');
  eq(bal.pool.vlosXuanyu, 7, 'VloS 余额合计（玄玉）');
  eq(bal.treasury, undefined, '不再有金库账户字段');

  const user = vlosApi.resolveUser(['nope', 'u1@test.local']);
  ok(user && user.key === 'u1', '按邮箱找到用户');
  const p = vlosApi.publicUser(user);
  eq(p.vlosBalance.longjing, 2, '用户 VloS 余额副本');
  eq(p.wallet, undefined, '不再暴露聚龙钱包');

  return (async () => {
    const res = await vlosApi.credit('u1@test.local', { longjing: 10, xuanyu: 2 }, '测试');
    ok(res.ok && res.via === 'vlos', 'VloS 余额到账');
    eq(res.granted.longjing, 10, '龙晶到账');
    eq(res.granted.xuanyu, 2, '玄玉到账');
    eq(calls.length, 1, '只调用 addVlosBalance（1 次）');
    eq(calls[0].fn, 'addVlosBalance', '调用 addVlosBalance');

    fakeVlos({
      addVlosBalance: () => {
        throw new Error('VloS 内部错误');
      },
    });
    const res2 = await vlosApi.credit('u1@test.local', { longjing: 1 }, '测试');
    ok(!res2.ok && res2.granted.longjing === 0, 'VloS 报错时失败不虚报');

    fakeVlos({ addVlosBalance: () => ({ ok: true }) });
    const resNoDelta = await vlosApi.credit('u1@test.local', { longjing: 5 }, '测试');
    ok(!resNoDelta.ok, 'VloS 没返回到账数量时失败，不虚报成功');

    delete globalThis.__JLWBOT_PLUGIN_APIS__;
    const res3 = await vlosApi.credit('u1@test.local', { longjing: 1 }, '测试');
    ok(!res3.ok, 'VloS 未加载时失败');
  })();
}

function testTemplatesAndProfiles() {
  console.log('\n公告模板 / 头像名称补全');
  const dir = tmpDir();
  const s = new Store(path.join(dir, 'data'), {});
  const A = 'A'.repeat(32);
  const B = 'B'.repeat(32);

  // 无资料的好友 -> 待补全
  s.upsertFriend({ openid: A, accountId: 'a1', source: 'import' });
  // 有名称+头像 -> 不需要补
  s.upsertFriend({ openid: B, accountId: 'a1', name: '有资料', avatar: 'https://example.com/a.png', source: 'event' });
  eq(s.data.friends[A].profileAt, 0, '无资料好友进入待补全队列');
  ok(s.data.friends[B].profileAt > 0, '有名称+头像的好友不需要补全');
  const st1 = s.profileStats();
  eq(st1.pendingFriends, 1, '待补全好友 1');
  eq(st1.missingFriends, 1, '缺资料好友 1');

  const next = s.nextPendingProfile();
  eq(next.kind, 'friend', '优先补好友');
  eq(next.id, A, '取最早待补的好友');
  s.markProfileAttempt('friend', A);
  eq(s.nextPendingProfile(), null, '尝试中的条目不重复取');
  s.revertProfileAttempt('friend', A);
  eq(s.nextPendingProfile().id, A, '失败回退后重新入队');
  s.applyProfile('friend', A, { name: '补全名', avatar: 'https://example.com/b.png', unionOpenid: 'UNION1' });
  eq(s.data.friends[A].name, '补全名', '补全名称');
  eq(s.data.friends[A].avatar, 'https://example.com/b.png', '补全头像');
  eq(s.nextPendingProfile(), null, '补全后不再入队');
  eq(s.profileStats().missingFriends, 0, '补全后缺资料为 0');

  // 群补全（优先群）
  const G = 'C'.repeat(32);
  s.upsertGroup({ group_openid: G, accountId: 'a1', source: 'import' });
  s.resetProfiles('group');
  const ng = s.nextPendingProfile('group');
  eq(ng.kind, 'group', 'prefer=group 时优先群');
  eq(ng.id, G, '群待补 id');
  s.applyProfile('group', G, { name: '测试群', avatar: 'https://example.com/g.png', unionGroupOpenid: 'UG1' });
  eq(s.data.groups[G].avatar, 'https://example.com/g.png', '群头像');

  // 手动重新刷新
  const reset = s.resetProfiles('friend', [A]);
  eq(reset, 1, '只重置指定好友');
  ok(s.data.friends[A].profileAt === 0, '重置后待补');
  eq(s.resetProfiles('all'), 3, '重置全部（2 好友 + 1 群）');
  eq(s.nextPendingProfile('friend', { scope: 'group' }).kind, 'group', '只补群聊时不取好友');
  eq(s.nextPendingProfile('group', { scope: 'friend' }).kind, 'friend', '只补好友时不取群聊');
  eq(s.nextPendingProfile('friend', { scope: 'group', ids: new Set([G]) }).id, G, '选中群只处理选中的群');

  // 公告模板
  const t1 = s.saveTemplate({ id: 'tpl-1', title: '', markdown: '## 标题来自内容\n正文' });
  eq(t1.title, '标题来自内容', '无标题时从 Markdown 标题推导');
  eq(s.listTemplates().length, 1, '模板列表');
  s.markTemplateSent('tpl-1', 'job-1');
  eq(s.getTemplate('tpl-1').status, 'sent', '标记已发送');
  s.saveTemplate({ id: 'tpl-1', title: '修改后', markdown: '## 修改后' });
  eq(s.getTemplate('tpl-1').status, 'draft', '编辑后回到草稿');
  eq(s.getTemplate('tpl-1').title, '修改后', '更新标题');
  ok(s.deleteTemplate('tpl-1'), '删除模板');
  eq(s.getTemplate('tpl-1'), null, '删除后不存在');

  fs.rmSync(dir, { recursive: true, force: true });
}

async function testStorage() {
  console.log('\n存储驱动（VSQL）');
  const cfg = normalizeConfig({});
  eq(cfg.storage.sqlitePath, 'data/xinghuo.db', '保留旧 SQLite 路径用于迁移');
  eq(cfg.storage.driver, undefined, '不再有存储驱动选择');

  const VSQL = require(path.join(ROOT, 'plugins', 'VSQL'));
  const factory = require(path.join(PLUGIN, 'lib', 'store-factory'));
  const sqlite = require(path.join(PLUGIN, 'lib', 'sqlite-store'));
  const dir = tmpDir();
  const log = { info() {}, warn() {}, error() {} };
  const vsqlDir = path.join(dir, 'vsql');
  const dbs = path.join(vsqlDir, 'dbs');
  fs.mkdirSync(dbs, { recursive: true });
  const vsqlConfig = {
    dataDir: dbs,
    defaultNamespace: 'shared',
    maxOpen: 16,
    autoCreate: true,
    allowAttach: false,
    busyTimeoutMs: 5000,
    injectSettings: false,
    http: { enabled: false, host: '127.0.0.1', port: 0, token: '', maxRows: 1000 },
    admin: { enabled: false, openids: [], allowWrite: false, maxRows: 30 },
  };
  globalThis.__JLWBOT_PLUGIN_APIS__ = new Map();
  const vsqlCtx = {
    plugin: { id: 'VSQL', dir: vsqlDir, config: vsqlConfig },
    log,
    config: { get: () => null },
  };
  await VSQL.onLoad(vsqlCtx);
  const vsql = globalThis.__JLWBOT_PLUGIN_APIS__.get('VSQL');
  ok(vsql && vsql.isReady(), 'VSQL 插件已就绪');

  // 旧 JSON 数据 → 首次打开自动迁移到 VSQL shared
  const json = new Store(path.join(dir, 'data'), {});
  json.upsertFriend({ openid: 'A'.repeat(32), accountId: 'a1', name: '旧数据' });
  json.createCodes([{ code: 'XHTEST0001', longjing: 5 }], {});
  json.saveNow();

  const s = factory.openStore({ dir, log, storage: {} });
  eq(s.storageInfo.driver, 'vsql', 'openStore 使用 VSQL');
  eq(s.storageInfo.namespace, 'shared', '默认 shared 命名空间');
  eq(s.storageInfo.rows.friends, 1, '首次打开自动迁移好友');
  ok(s.migrated && s.migrated.friends === 1, '返回迁移统计');
  ok(vsql.db().hasTable('xinghuo_friends'), '共享库里应有 xinghuo_friends');
  ok(s.storageInfo.tables.includes('xinghuo_friends'), '状态里列出 xinghuo_ 表');

  s.upsertFriend({ openid: 'B'.repeat(32), name: '新数据' });
  s.createCodes([{ code: 'XHTEST0002', longjing: 1 }, { code: 'XHINFINITE01', longjing: 1, maxUses: 0, oncePerUser: false }], {});
  s.markFriendInvalid('A'.repeat(32), '40034 发送失败');
  factory.closeStore(s);

  const rawCount = vsql.db().value('SELECT COUNT(*) FROM xinghuo_friends');
  eq(rawCount, 2, '其他插件可直接读 shared 库的同名表');

  const re = factory.openStore({ dir, log, storage: {} });
  eq(re.data.codes.XHTEST0002.longjing, 1, '重开后兑换码仍在');
  eq(re.data.codes.XHINFINITE01.maxUses, 0, 'VSQL 保留 0=无限');
  eq(re.data.codes.XHINFINITE01.oncePerUser, false, 'VSQL 保留每人可重复');
  eq(re.data.codes.XHINFINITE01.status, 'active', '无限码初始可用');
  ok(re.beginRedeem('XHINFINITE01').ok, '无限码可开始兑换');
  re.finishRedeem('XHINFINITE01', { openid: 'F1', at: Date.now() });
  eq(re.data.codes.XHINFINITE01.status, 'active', '无限码兑换一次后仍可用');
  ok(re.beginRedeem('XHINFINITE01').ok, '无限码可再次兑换');
  eq(Object.keys(re.data.friends).length, 2, '重开后好友仍在');
  eq(re.data.friends['A'.repeat(32)].status, 'invalid', 'VSQL 持久化无效状态');
  eq(re.data.friends['A'.repeat(32)].invalidReason, '40034 发送失败', 'VSQL 持久化无效原因');
  ok(re.storageInfo.size > 0, '状态包含文件大小');
  ok(re.storageInfo.rows.codes >= 2, '状态包含行数');
  factory.closeStore(re);

  // 旧版自带 SQLite → loadLegacy 能读出并迁移
  const legacyDir = tmpDir();
  const oldDb = path.join(legacyDir, 'data', 'xinghuo.db');
  const oldStore = new sqlite.SqliteStore({ dir: legacyDir, file: oldDb, jsonFile: path.join(legacyDir, 'data', 'none.json') });
  oldStore.upsertFriend({ openid: 'C'.repeat(32), name: '旧库好友' });
  oldStore.flush();
  oldStore.close();
  const legacy = factory.loadLegacy(legacyDir, {}, log);
  ok(legacy && legacy.data.friends['C'.repeat(32)], '可读取旧版自带 SQLite 数据');
  fs.rmSync(legacyDir, { recursive: true, force: true });

  // VSQL 没加载时回退 JSON，并给出原因
  await VSQL.onUnload(vsqlCtx);
  const fallback = factory.openStore({ dir, log, storage: {} });
  eq(fallback.storageInfo.driver, 'json', 'VSQL 未加载时回退 JSON');
  assert.match(fallback.storageInfo.error, /VSQL/, '回退原因包含 VSQL');
  factory.closeStore(fallback);

  fs.rmSync(dir, { recursive: true, force: true });
}

function testButtons() {
  console.log('\n消息按钮');
  const B = require(path.join(PLUGIN, 'lib', 'buttons'));
  const kb = B.buildKeyboard([
    { row: 1, col: 2, label: '官网', data: 'https://example.com', type: 0, permission: 2 },
    { row: 1, col: 1, label: '帮助', data: '/xh 帮助', type: 2, permission: 2, enter: true },
    { row: 2, col: 1, label: '管理员', data: '/xh 余额', type: 2, permission: 1 },
  ]);
  eq(kb.content.rows.length, 2, '按钮按行分组');
  eq(kb.content.rows[0].buttons[0].render_data.label, '帮助', '同列按列号排序');
  eq(kb.content.rows[0].buttons[0].action.enter, true, '指令按钮可立即发送');
  eq(kb.content.rows[0].buttons[1].action.type, 0, '链接按钮类型 0');
  eq(kb.content.rows[1].buttons[0].action.permission.type, 1, '管理员可点');
  eq(B.buildKeyboard([]), null, '没有按钮不挂 keyboard');
  const normalized = B.normalizeButtons([{ row: 9, col: 9, label: '超长按钮文字超过十个字', data: '/xh', type: 2 }, { label: '', data: '' }]);
  eq(normalized.length, 1, '空按钮被过滤');
  eq(normalized[0].row, 5, '行号夹到 5');
  ok(Array.from(normalized[0].label).length <= 10, '按钮文字最多 10 字');
  ok(B.isKeyboardReject({ code: '11253', message: 'keyboard not allowed' }), '识别按钮被拒');
  ok(!B.isKeyboardReject({ code: '40054', message: 'openid invalid' }), '普通失败不当作按钮被拒');
}

function testCommands() {
  console.log('\n指令解析');
  const cfg = normalizeConfig({ command: { prefix: '/', names: ['xh', '星火'] } });
  eq(plugin.__internal.parseCommand(cfg, '/xh XHDEMO0001').name, 'xh', '/xh 解析');
  eq(plugin.__internal.parseCommand(cfg, '／星火 兑换码').name, '星火', '中文指令 + 全角斜杠');
  ok(plugin.__internal.matchCommand(cfg, '/xh 兑换码'), '命中指令');
  ok(!plugin.__internal.matchCommand(cfg, '/帮助'), '不命中其它指令');
  const ids = plugin.__internal.messageIdentity({
    user_openid: 'u-openid',
    author: { id: 'member', member_openid: 'member', union_openid: 'union', user_openid: 'u-openid' },
  });
  eq(ids.join(','), 'u-openid,member,union', '身份候选去重');
}

(async () => {
  console.log('\n星火插件单元自测\n');
  testConfig();
  testStore();
  testCodes();
  await testTasksAndSnapshot();
  await testVlos();
  testTemplatesAndProfiles();
  await testStorage();
  testButtons();
  testCommands();
  console.log(`\n全部通过（${passed} 项）\n`);
})().catch((e) => {
  console.error('\n测试失败：', e && e.stack ? e.stack : e);
  process.exit(1);
});
