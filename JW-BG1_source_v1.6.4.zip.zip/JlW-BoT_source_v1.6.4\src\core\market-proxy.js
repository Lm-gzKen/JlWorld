'use strict';
/**
 * VloSBoT 插件市场反向代理。
 *
 * 市场站点带 X-Frame-Options: SAMEORIGIN，不能直接 iframe；
 * 面板同源代理 /market-proxy/* -> https://vlos.jlworld.net/*，
 * 去掉防嵌套头，并把页面/JS/CSS 里的根路径改写到 /market-proxy。
 * 只代理固定上游，避免变成开放代理。
 */
const http = require('http');
const https = require('https');

const PREFIX = '/market-proxy';
const DEFAULT_TARGET = 'https://vlos.jlworld.net';
const HOP_HEADERS = new Set([
  'connection',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'te',
  'trailer',
  'transfer-encoding',
  'upgrade',
  'content-encoding',
  'x-frame-options',
  'content-security-policy',
  'content-security-policy-report-only',
  'cross-origin-opener-policy',
  'cross-origin-embedder-policy',
  'cross-origin-resource-policy',
]);

/**
 * 注入到市场外壳页的「栏目点击」补丁。
 * 市场自己靠 shell.js 的 load() 切 #viewFrame，但它的 PATHS 是站内绝对路径，
 * 经代理改写后容易和 data-view 对不上（浏览器缓存旧 shell.js 时更明显），
 * 点「开发者中心」就会被 load() 退回首页。这里在捕获阶段接管点击：
 *  - 顶栏 a[data-view]：直接按 data-view 切 iframe；
 *  - 内层视图里的站内链接（例如首页的「上传插件」href="/market-proxy/developer"）：
 *    映射成对应视图，在外壳里切，而不是让内层 iframe 自己跳成一张独立页面。
 * Ctrl/⌘/Shift/中键点击仍走默认新标签打开。
 */
const NAV_PATCH =
  '<script>(function(){' +
  'var MAP={"/market-proxy/home":"/market-proxy/home-view.html","/market-proxy/home-view.html":"/market-proxy/home-view.html",' +
  '"/market-proxy/market":"/market-proxy/index.html","/market-proxy/index.html":"/market-proxy/index.html",' +
  '"/market-proxy/developer":"/market-proxy/developer.html","/market-proxy/developer.html":"/market-proxy/developer.html"};' +
  'function viewOf(href){if(!href||href.charAt(0)!=="/"||href.indexOf("#")>=0)return "";var p=String(href).split("?")[0];return MAP[p]||"";}' +
  "function go(view,href){var f=document.getElementById('viewFrame');if(!f||!view)return false;" +
  "if(f.getAttribute('src')!==view)f.setAttribute('src',view);" +
  "try{history.pushState({view:view},'',href||view);}catch(e){}" +
  "var ls=document.querySelectorAll('#shellNav a[data-view]');" +
  'for(var i=0;i<ls.length;i++){ls[i].classList.toggle("active",ls[i].getAttribute("data-view")===view);}' +
  "var act=document.querySelector('#shellNav a[data-view].active');" +
  "document.title=(act&&act.getAttribute('data-title')?act.getAttribute('data-title')+' · ':'')+'JlW-BoT 插件市场';return true;}" +
  'function onNav(e){var a=e.target&&e.target.closest?e.target.closest("a[data-view]"):null;' +
  'if(!a||e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey)return;' +
  'var v=a.getAttribute("data-view");if(!v||!document.getElementById("viewFrame"))return;' +
  'e.preventDefault();e.stopPropagation();go(v,a.getAttribute("href")||v);}' +
  'function bindInner(){var f=document.getElementById("viewFrame");if(!f)return;' +
  'var d;try{d=f.contentDocument;}catch(e){return;}if(!d||d.__jlwNavBound)return;d.__jlwNavBound=true;' +
  'd.addEventListener("click",function(e){var a=e.target&&e.target.closest?e.target.closest("a[href]"):null;' +
  'if(!a||e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||a.target==="_blank")return;' +
  'var v=viewOf(a.getAttribute("href")||"");if(!v)return;e.preventDefault();e.stopPropagation();go(v,a.getAttribute("href"));},true);}' +
  'document.addEventListener("click",onNav,true);' +
  'var fr=document.getElementById("viewFrame");if(fr){fr.addEventListener("load",bindInner);bindInner();}' +
  '})();</script>';

function filterCookie(raw) {
  return String(raw || '')
    .split(';')
    .map((s) => s.trim())
    .filter((s) => s && !/^jlw_sid=/i.test(s))
    .join('; ');
}

function rewriteCookie(value) {
  let s = String(value || '').replace(/;\s*Domain=[^;]*/gi, '');
  // 面板一般是 http://127.0.0.1:8686，带 Secure 的 Cookie 浏览器会直接丢掉
  s = s.replace(/;\s*Secure\b/gi, '');
  if (/;\s*Path=/i.test(s)) s = s.replace(/;\s*Path=[^;]*/gi, '; Path=/market-proxy/');
  else s += '; Path=/market-proxy/';
  return s;
}

class MarketProxy {
  constructor({ logger, target } = {}) {
    this.log = logger ? logger.child('market') : null;
    this.target = new URL(target || process.env.JLW_MARKET_URL || DEFAULT_TARGET);
  }

  _target(url) {
    // 根路径要映射到市场根（/），不能映射到 /index.html：
    // 市场的 /index.html 是「插件列表」页，/ 和 /home 才是首页。
    let p = url.pathname === PREFIX ? '/' : url.pathname.slice(PREFIX.length) || '/';
    p = '/' + p.replace(/^\/+/, '');
    return new URL(this.target.origin + p + (url.search || ''));
  }

  _rewriteUrl(value) {
    const s = String(value || '');
    if (!s) return s;
    if (s.startsWith(this.target.origin)) return PREFIX + s.slice(this.target.origin.length);
    if (s.startsWith('//' + this.target.host)) return PREFIX + s.slice(('//' + this.target.host).length);
    if (s.startsWith('/') && !s.startsWith('//') && !s.startsWith(PREFIX + '/')) return PREFIX + (s === '/' ? '/' : s);
    return s;
  }

  _rewriteJs(text) {
    let s = String(text || '');
    s = s.replace(/https?:\/\/vlos\.jlworld\.net/gi, PREFIX);
    // 市场登录成功后会把顶层窗口跳到 /home，面板内嵌时这会把整个控制台顶掉。
    // 在代理层改成就地刷新 iframe，保持内嵌。
    s = s.replace(/(?:window\.)?top\.location\.href\s*=\s*(['"])\/home\1/g, 'location.reload()');
    s = s.replace(/(?:window\.)?top\.location\.replace\(\s*(['"])\/home\1\s*\)/g, 'location.reload()');
    // 市场一检测到自己被 iframe 内嵌，就会加 .embedded 把顶栏/页脚隐藏（那是给它自家外壳用的）。
    // 面板里内嵌的是整个市场，这样会只剩内容区、看不到栏目；改成「父窗口是不是市场自己的外壳」再判断。
    if (s.includes('return window.self !== window.top;')) {
      s = s.replace(
        'return window.self !== window.top;',
        'return __jlwMarketInOwnShell();',
      );
      s =
        'function __jlwMarketInOwnShell(){try{if(window.self===window.top)return false;' +
        'var p=window.parent;return !!(p&&p!==window&&p.App&&typeof p.App.shellView==="function"&&typeof p.App.shellLoad==="function");}catch(e){return false;}}\n' +
        s;
    }
    s = s.replace(
      /(["'`])\/(home-view\.html|index\.html|developer\.html|home\.html|api|assets|uploads|download|home|market|developer|docs|admin|viewFrame)(?=[/'"`?#]|$)/g,
      `$1${PREFIX}/$2`,
    );
    return s;
  }

  _rewriteCss(text) {
    let s = String(text || '');
    s = s.replace(/https?:\/\/vlos\.jlworld\.net/gi, PREFIX);
    s = s.replace(/url\(\s*(["']?)\/(?!\/)/gi, `url($1${PREFIX}/`);
    s = s.replace(/@import\s+(["'])\/(?!\/)/gi, `@import $1${PREFIX}/`);
    return s;
  }

  _rewriteHtml(text) {
    let s = String(text || '');
    s = s.replace(/https?:\/\/vlos\.jlworld\.net/gi, PREFIX);
    s = s.replace(/(\b(?:href|src|action|data-view|poster|data-src)=["'])\/(?!\/)/gi, `$1${PREFIX}/`);
    s = s.replace(/url\(\s*(["']?)\/(?!\/)/gi, `url($1${PREFIX}/`);
    s = s.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (m) => this._rewriteJs(m));
    s = s.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, (m) => this._rewriteCss(m));
    // 外壳页额外注入「栏目点击」补丁：不依赖市场自己的 shell.js 路由（旧缓存/路径改写差异
    // 都会导致点「开发者中心」被 load() 退回首页），直接按 data-view 切 viewFrame。
    if (/id=["']viewFrame["']/i.test(s)) {
      if (/<\/body>/i.test(s)) s = s.replace(/<\/body>/i, NAV_PATCH + '</body>');
      else s += NAV_PATCH;
    }
    return s;
  }

  _rewriteLocation(value) {
    return this._rewriteUrl(value);
  }

  /**
   * 用面板登录的聚龙账户换取市场会话 Cookie。
   * 只在面板登录请求里调用一次，密码不落盘，只保留 vlos_sid。
   */
  autoLogin(mail, password, { timeout = 8000 } = {}) {
    return new Promise((resolve) => {
      let payload;
      try {
        payload = JSON.stringify({ mail, password });
      } catch {
        return resolve({ ok: false, error: '请求体序列化失败' });
      }
      const target = new URL('/api/auth/auto-login', this.target.origin);
      const mod = target.protocol === 'https:' ? https : http;
      const up = mod.request(
        target,
        {
          method: 'POST',
          headers: {
            host: target.host,
            'content-type': 'application/json',
            'content-length': Buffer.byteLength(payload),
            accept: 'application/json',
            'user-agent': 'JlWBoT-MarketSSO',
          },
          timeout,
        },
        (res) => {
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            const raw = Buffer.concat(chunks).toString('utf8');
            let data = {};
            try {
              data = JSON.parse(raw);
            } catch {
              /* ignore */
            }
            const setCookie = res.headers['set-cookie'] || [];
            const list = Array.isArray(setCookie) ? setCookie : [setCookie];
            const sid = list.map((c) => String(c).split(';')[0]).find((c) => /^vlos_sid=/.test(c));
            if (res.statusCode >= 200 && res.statusCode < 300 && data?.ok && sid) {
              return resolve({ ok: true, cookie: sid, user: data.user || null });
            }
            resolve({ ok: false, status: res.statusCode, error: data?.msg || data?.error || 'HTTP ' + res.statusCode });
          });
          res.on('error', (e) => resolve({ ok: false, error: e.message }));
        },
      );
      up.on('timeout', () => up.destroy(new Error('timeout')));
      up.on('error', (e) => resolve({ ok: false, error: e.message }));
      up.write(payload);
      up.end();
    });
  }

  /**
   * 检查一个市场会话 Cookie 还有没有效（GET /api/me，未登录时返回 {user:null}）。
   * 用于复用缓存前先验一下，避免把过期 Cookie 注入给内嵌市场。
   */
  checkSession(cookie, { timeout = 6000 } = {}) {
    return new Promise((resolve) => {
      if (!cookie) return resolve(false);
      const target = new URL('/api/me', this.target.origin);
      const mod = target.protocol === 'https:' ? https : http;
      const up = mod.request(
        target,
        {
          method: 'GET',
          headers: {
            host: target.host,
            cookie: String(cookie),
            accept: 'application/json',
            'user-agent': 'JlWBoT-MarketSSO',
          },
          timeout,
        },
        (res) => {
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            if (res.statusCode !== 200) return resolve(false);
            try {
              const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
              return resolve(!!(data && data.user));
            } catch {
              resolve(false);
            }
          });
          res.on('error', () => resolve(false));
        },
      );
      up.on('timeout', () => up.destroy(new Error('timeout')));
      up.on('error', () => resolve(false));
      up.end();
    });
  }

  async handle(req, res, url, rawBody = '', opts = {}) {
    const target = this._target(url);
    const method = req.method || 'GET';
    const headers = {
      host: target.host,
      'user-agent': req.headers['user-agent'] || 'JlWBoT-MarketProxy',
      accept: req.headers.accept || '*/*',
      'accept-language': req.headers['accept-language'] || 'zh-CN',
      'accept-encoding': 'identity',
      origin: this.target.origin,
      referer: this.target.origin + '/',
    };
    let cookie = filterCookie(req.headers.cookie);
    // 面板会话已经自动登录过市场：用服务端拿到的 vlos_sid 覆盖浏览器里的旧值
    if (opts.cookie) {
      cookie = cookie
        .split(';')
        .map((s) => s.trim())
        .filter((s) => s && !/^vlos_sid=/i.test(s))
        .join('; ');
      cookie = cookie ? cookie + '; ' + opts.cookie : opts.cookie;
    }
    if (cookie) headers.cookie = cookie;
    // 不转发条件请求头：市场的 ETag 只对「它自己的原文」有效，
    // 我们转发时改写了 HTML/JS（路径、内嵌判定、登录跳转等），
    // 一旦命中 304 浏览器就会继续用改写过之前的旧脚本（例如 shell.js 里没有 developer.html 路由）。
    for (const k of ['content-type', 'authorization', 'x-requested-with', 'range']) {
      if (req.headers[k]) headers[k] = req.headers[k];
    }
    const body = rawBody && rawBody.length ? (Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody), 'utf8')) : null;
    if (body) headers['content-length'] = body.length;
    // 上传插件是 zip 二进制（最大 200MB）：直接流式转发，不能先转成字符串（会损坏文件）
    const stream = !!opts.stream && !body && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method);
    if (stream && req.headers['content-length']) headers['content-length'] = req.headers['content-length'];

    return new Promise((resolve) => {
      const mod = target.protocol === 'https:' ? https : http;
      const up = mod.request(
        target,
        { method, headers, timeout: stream ? 300000 : 30000 },
        (upRes) => {
          try {
            const out = {};
            for (const [k, v] of Object.entries(upRes.headers)) {
              if (HOP_HEADERS.has(k.toLowerCase())) continue;
              if (k.toLowerCase() === 'set-cookie') {
                out[k] = Array.isArray(v) ? v.map(rewriteCookie) : [rewriteCookie(v)];
              } else if (k.toLowerCase() === 'location') {
                out[k] = this._rewriteLocation(v);
              } else {
                out[k] = v;
              }
            }
            const ct = String(upRes.headers['content-type'] || '').toLowerCase();
            // 市场里点了「退出登录」：上游会下发清空 vlos_sid 的 Cookie，
            // 通知调用方把服务端缓存一起丢掉，否则下次又把它注入回去。
            const cleared = (out['set-cookie'] || []).some((c) => /^vlos_sid=\s*;/.test(String(c).trim()));
            if (cleared && typeof opts.onLogout === 'function') {
              try {
                opts.onLogout();
              } catch {
                /* ignore */
              }
            }
            const isText = /text\/html|text\/css|javascript|application\/json|text\/plain|text\/xml/.test(ct);
            // 改写过的文本一律不缓存：内容由代理生成，上游 ETag/Last-Modified 对不上，
            // 让浏览器每次重新取，避免面板升级后还跑旧的 shell.js / common.js。
            if (isText) {
              for (const k of ['etag', 'last-modified', 'expires', 'cache-control', 'age', 'vary', 'content-md5']) delete out[k];
              out['cache-control'] = 'no-store';
            }
            if (!isText || upRes.statusCode === 304) {
              res.writeHead(upRes.statusCode || 502, out);
              upRes.pipe(res);
              upRes.on('end', () => resolve());
              return;
            }
            const chunks = [];
            let size = 0;
            upRes.on('data', (c) => {
              size += c.length;
              if (size > 15 * 1024 * 1024) {
                upRes.destroy();
                return;
              }
              chunks.push(c);
            });
            upRes.on('error', () => {
              if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8' });
              res.end(JSON.stringify({ ok: false, error: '市场页面读取失败' }));
              resolve();
            });
            upRes.on('end', () => {
              let text = Buffer.concat(chunks).toString('utf8');
              if (/text\/html/.test(ct)) text = this._rewriteHtml(text);
              else if (/text\/css/.test(ct)) text = this._rewriteCss(text);
              else if (/javascript/.test(ct)) text = this._rewriteJs(text);
              else text = text.replace(/https?:\/\/vlos\.jlworld\.net/gi, PREFIX);
              out['content-type'] = upRes.headers['content-type'] || 'text/plain; charset=utf-8';
              out['content-length'] = Buffer.byteLength(text);
              res.writeHead(upRes.statusCode || 502, out);
              res.end(text);
              resolve();
            });
          } catch (e) {
            if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ ok: false, error: e.message }));
            resolve();
          }
        },
      );
      up.on('timeout', () => up.destroy(new Error('市场站点连接超时')));
      up.on('error', (e) => {
        if (this.log) this.log.warn('市场代理失败：' + e.message);
        if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ ok: false, error: '无法连接插件市场：' + e.message }));
        resolve();
      });
      if (stream) {
        req.on('aborted', () => up.destroy(new Error('客户端中断上传')));
        req.pipe(up);
      } else {
        if (body) up.write(body);
        up.end();
      }
    });
  }
}

module.exports = MarketProxy;
module.exports.PREFIX = PREFIX;
