// SQLite 存储层（Node 内置 node:sqlite，零第三方依赖）。
//
// 数据模型（v2，2026-11 重构）：
//   plugins  一个插件一行（name/author/version=最新版本/summary/readme/tags/统计）
//   releases 一个版本一行，一个版本 = 一个 .zip 包（插件只收 zip）
//   users / sessions / comments / messages / ratings / download_logs / view_logs / settings
//
// 旧库（v1：dll/source/module 分文件上传 + 审核状态机）启动时自动迁移：
//   把每个已上架插件的每个版本的老文件打成一个 zip，写入 releases，再删掉审核相关的表。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { makeZip } from './zip.mjs';

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS users (
  email        TEXT PRIMARY KEY,
  nickname     TEXT DEFAULT '',
  qq           TEXT DEFAULT '',
  openid       TEXT DEFAULT '',
  jlw_created  TEXT DEFAULT '',
  first_seen   INTEGER NOT NULL,
  last_login   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token    TEXT PRIMARY KEY,
  email    TEXT NOT NULL,
  created  INTEGER NOT NULL,
  expires  INTEGER NOT NULL,
  ip       TEXT DEFAULT '',
  ua       TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS plugins (
  id        TEXT PRIMARY KEY,
  email     TEXT NOT NULL,
  name      TEXT NOT NULL,
  author    TEXT NOT NULL,
  version   TEXT NOT NULL,
  summary   TEXT DEFAULT '',
  readme    TEXT DEFAULT '',
  tags      TEXT DEFAULT '',
  views     INTEGER DEFAULT 0,
  downloads INTEGER DEFAULT 0,
  offline   INTEGER DEFAULT 0,
  pinned    INTEGER DEFAULT 0,
  created   INTEGER NOT NULL,
  updated   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  email    TEXT PRIMARY KEY,
  added_by TEXT DEFAULT '',
  created  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS api_tokens (
  email     TEXT PRIMARY KEY,
  token     TEXT NOT NULL UNIQUE,
  created   INTEGER NOT NULL,
  last_used INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS releases (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  plugin_id   TEXT NOT NULL,
  version     TEXT NOT NULL,
  filename    TEXT NOT NULL,
  rel_path    TEXT NOT NULL,
  size        INTEGER NOT NULL,
  sha256      TEXT NOT NULL,
  entry_count INTEGER DEFAULT 0,
  dll_name    TEXT DEFAULT '',
  entries     TEXT DEFAULT '',   -- JSON [{name,size}]，包内文件清单（最多 500 条）
  changelog   TEXT DEFAULT '',
  created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS comments (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  plugin_id TEXT NOT NULL,
  email     TEXT NOT NULL,
  body      TEXT NOT NULL,
  created   INTEGER NOT NULL,
  deleted   INTEGER DEFAULT 0,
  parent_id INTEGER DEFAULT 0,
  reply_to  INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  to_email   TEXT NOT NULL,
  plugin_id  TEXT NOT NULL,
  comment_id INTEGER DEFAULT 0,
  kind       TEXT NOT NULL DEFAULT 'comment',
  body       TEXT NOT NULL,
  created    INTEGER NOT NULL,
  is_read    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS download_logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  plugin_id  TEXT NOT NULL,
  release_id INTEGER DEFAULT 0,
  version    TEXT DEFAULT '',
  email      TEXT DEFAULT '',
  ip         TEXT DEFAULT '',
  created    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS view_logs (
  plugin_id TEXT NOT NULL,
  viewer    TEXT NOT NULL,
  created   INTEGER NOT NULL,
  PRIMARY KEY (plugin_id, viewer)
);

CREATE TABLE IF NOT EXISTS ratings (
  plugin_id TEXT NOT NULL,
  email     TEXT NOT NULL,
  stars     INTEGER NOT NULL,
  created   INTEGER NOT NULL,
  updated   INTEGER NOT NULL,
  PRIMARY KEY (plugin_id, email)
);

CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated    INTEGER NOT NULL,
  updated_by TEXT DEFAULT ''
);

-- 前置插件：plugin_id 依赖 dep_id（可多个）。删除插件时两个方向都要清理。
CREATE TABLE IF NOT EXISTS plugin_deps (
  plugin_id TEXT NOT NULL,
  dep_id    TEXT NOT NULL,
  created   INTEGER NOT NULL,
  PRIMARY KEY (plugin_id, dep_id)
);

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

const INDEXES = `
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);
CREATE INDEX IF NOT EXISTS idx_plugins_email ON plugins(email);
CREATE INDEX IF NOT EXISTS idx_plugins_updated ON plugins(updated DESC);
CREATE INDEX IF NOT EXISTS idx_releases_plugin ON releases(plugin_id, created DESC);
CREATE INDEX IF NOT EXISTS idx_releases_version ON releases(plugin_id, version);
CREATE INDEX IF NOT EXISTS idx_comments_plugin ON comments(plugin_id, created DESC);
CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments(parent_id);
CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_email, is_read, created DESC);
CREATE INDEX IF NOT EXISTS idx_dl_plugin ON download_logs(plugin_id, created DESC);
CREATE INDEX IF NOT EXISTS idx_deps_plugin ON plugin_deps(plugin_id);
CREATE INDEX IF NOT EXISTS idx_deps_dep ON plugin_deps(dep_id);
`;

const SCHEMA_VERSION = '2';

function tableExists(db, name) {
  return !!db.prepare("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?").get(name);
}

function columnsOf(db, table) {
  try {
    return db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  } catch {
    return [];
  }
}

function safePart(s, max = 80) {
  return String(s || '')
    .replace(/[\\/:*?"<>|\x00-\x1f\x7f]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

/** 迁移前把整个库备份一份（先 checkpoint，把 WAL 里的内容并回主文件） */
function backupDb(db, dataDir, dbFile) {
  try {
    db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
    const dir = path.join(dataDir, 'data', 'backup');
    fs.mkdirSync(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const file = path.join(dir, `market.db.v1-${stamp}.bak`);
    fs.copyFileSync(dbFile, file);
    console.log(`[db] 旧库已备份：${path.relative(dataDir, file)}`);
  } catch (err) {
    console.log(`[db] 旧库备份失败（继续迁移）：${err.message}`);
  }
}

/** 老库补列：新版本加的字段在这里补齐（每次启动都跑，已有则跳过） */
function ensureColumns(db) {
  const add = (table, column, ddl) => {
    const cols = columnsOf(db, table);
    if (!cols.length || cols.includes(column)) return;
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
    console.log(`[db] 已为 ${table} 补充字段 ${column}`);
  };
  add('plugins', 'offline', 'offline INTEGER DEFAULT 0');
  add('plugins', 'pinned', 'pinned INTEGER DEFAULT 0');
  add('users', 'nickname', "nickname TEXT DEFAULT ''");
  add('users', 'avatar', "avatar TEXT DEFAULT ''");
}

/**
 * v1 → v2：把老的「按 kind 分文件」的上传内容，每个版本打成一个 zip。
 * 所有状态的插件都迁移（草稿 / 待审 / 已驳回也保留文件，迁移后标记为已下架，避免突然出现在市场）。
 * 旧表一律保留，不删数据，方便回退。
 */
function migrateV1(db, dataDir, dbFile) {
  const now = Date.now();
  const legacy = columnsOf(db, 'plugins').includes('status');
  if (!legacy) {
    db.prepare("INSERT INTO meta (key, value) VALUES ('schema', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(SCHEMA_VERSION);
    return;
  }

  backupDb(db, dataDir, dbFile);

  let plugins = [];
  try {
    plugins = db.prepare('SELECT * FROM plugins ORDER BY created ASC').all();
  } catch {
    plugins = [];
  }
  let madeZip = 0;
  let migrated = 0;

  db.exec('BEGIN');
  try {
    for (const p of plugins) {
      if (!tableExists(db, 'files')) break;
      const rows = db
        .prepare(
          "SELECT * FROM files WHERE plugin_id=? AND active=1 AND kind IN ('dll','source','module') ORDER BY version, uploaded"
        )
        .all(p.id);
      if (!rows.length) continue;

      const byVersion = new Map();
      for (const f of rows) {
        if (!byVersion.has(f.version)) byVersion.set(f.version, []);
        byVersion.get(f.version).push(f);
      }

      let latest = null;
      for (const [version, list] of byVersion) {
        const zipFiles = [];
        const used = new Set();
        for (const f of list) {
          let data;
          try {
            data = fs.readFileSync(path.join(dataDir, f.rel_path));
          } catch {
            continue;
          }
          let inner = `${f.kind}/${safePart(f.filename, 120) || 'file'}`;
          let n = 2;
          while (used.has(inner)) inner = `${f.kind}/${n++}_${safePart(f.filename, 120) || 'file'}`;
          used.add(inner);
          zipFiles.push({ name: inner, data });
        }
        if (!zipFiles.length) continue;

        const zipName = `${safePart(p.name, 60) || 'plugin'}_v${safePart(version, 24)}.zip`;
        const relDir = path.posix.join('plugins', p.id, version);
        const relPath = path.posix.join(relDir, zipName);
        fs.mkdirSync(path.join(dataDir, relDir), { recursive: true });
        const buf = makeZip(zipFiles);
        fs.writeFileSync(path.join(dataDir, relPath), buf);

        const uploadedAt = Math.max(...list.map((f) => f.uploaded || now));
        db.prepare(
          `INSERT INTO releases (plugin_id, version, filename, rel_path, size, sha256, entry_count, dll_name, entries, changelog, created)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`
        ).run(
          p.id,
          version,
          zipName,
          relPath,
          buf.length,
          sha256(buf),
          zipFiles.length,
          (list.find((f) => f.kind === 'dll') || {}).filename || '',
          JSON.stringify(zipFiles.map((f) => ({ name: f.name, size: f.data.length }))),
          '从旧版插件市场迁移',
          uploadedAt
        );
        madeZip += 1;
        if (!latest || uploadedAt > latest.uploaded) latest = { version, uploaded: uploadedAt };
      }

      if (latest) {
        db.prepare('UPDATE plugins SET version=? WHERE id=?').run(latest.version, p.id);
        // 没上架过的插件迁移后先隐藏，管理员确认后再上架
        if (!['approved', 'review'].includes(p.status)) {
          db.prepare('UPDATE plugins SET offline=1 WHERE id=?').run(p.id);
        }
        migrated += 1;
      }
    }

    // 老的下载日志结构和现在不同：改个名留着，建一张新表给新代码用，不删旧数据
    if (tableExists(db, 'download_logs') && !columnsOf(db, 'download_logs').includes('release_id')) {
      db.exec('ALTER TABLE download_logs RENAME TO download_logs_v1');
      db.exec(`CREATE TABLE download_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plugin_id TEXT NOT NULL,
        release_id INTEGER DEFAULT 0,
        version TEXT DEFAULT '',
        email TEXT DEFAULT '',
        ip TEXT DEFAULT '',
        created INTEGER NOT NULL
      )`);
    }

    db.prepare("INSERT INTO meta (key, value) VALUES ('schema', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(SCHEMA_VERSION);
    db.exec('COMMIT');
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {}
    throw err;
  }

  console.log(`[db] 旧数据迁移完成：${migrated} 个插件 / ${madeZip} 个版本已打包成 zip（旧表全部保留）`);
}

/**
 * 修复：有些插件在旧版迁移时被跳过 / 旧库被新代码删过 files 表，结果 plugins 里有记录但 0 个版本。
 * 只要磁盘上还留着 plugins/<id>/<版本>/dll|source|module 文件，就重新打回 zip 并补 releases。
 * 每次启动都会检查，只处理「0 个版本」的插件，不覆盖任何已有版本。
 */
function repairReleases(db, dataDir) {
  if (!tableExists(db, 'plugins') || !tableExists(db, 'releases')) return;

  const plugins = db
    .prepare('SELECT * FROM plugins WHERE NOT EXISTS (SELECT 1 FROM releases r WHERE r.plugin_id = plugins.id)')
    .all();
  if (!plugins.length) return;

  let fixedPlugins = 0;
  let fixedReleases = 0;
  const now = Date.now();

  db.exec('BEGIN');
  try {
    for (const p of plugins) {
      const dir = path.join(dataDir, 'plugins', p.id);
      if (!fs.existsSync(dir)) continue;

      // 老 files 表还在的话优先用它（文件名、kind、上传时间都更准）
      const byVersion = new Map();
      if (tableExists(db, 'files')) {
        const rows = db
          .prepare("SELECT * FROM files WHERE plugin_id=? AND kind IN ('dll','source','module') ORDER BY version, uploaded")
          .all(p.id);
        for (const f of rows) {
          if (!byVersion.has(f.version)) byVersion.set(f.version, []);
          byVersion.get(f.version).push({ abs: path.join(dataDir, f.rel_path), inner: `${f.kind}/${safePart(f.filename, 120) || 'file'}`, at: f.uploaded || now, dll: f.kind === 'dll' ? f.filename : '' });
        }
      }

      // files 表没了 / 没记录，就直接扫磁盘
      if (!byVersion.size) {
        for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
          if (!ent.isDirectory()) continue;
          const versionDir = path.join(dir, ent.name);
          const found = [];
          const walk = (d) => {
            for (const e of fs.readdirSync(d, { withFileTypes: true })) {
              const abs = path.join(d, e.name);
              if (e.isDirectory()) walk(abs);
              else if (e.isFile() && !/\.zip$/i.test(e.name)) {
                found.push({
                  abs,
                  inner: path.relative(versionDir, abs).split(path.sep).join('/'),
                  at: (() => {
                    try {
                      return fs.statSync(abs).mtimeMs;
                    } catch {
                      return now;
                    }
                  })(),
                  dll: /\.dll$/i.test(e.name) ? e.name : '',
                });
              }
            }
          };
          walk(versionDir);
          if (found.length) byVersion.set(ent.name, found);
        }
      }

      let latest = null;
      for (const [version, list] of byVersion) {
        const zipFiles = [];
        const used = new Set();
        for (const f of list) {
          let data;
          try {
            data = fs.readFileSync(f.abs);
          } catch {
            continue;
          }
          let inner = f.inner;
          let n = 2;
          while (used.has(inner)) inner = `${n++}_${f.inner}`;
          used.add(inner);
          zipFiles.push({ name: inner, data, at: f.at, dll: f.dll });
        }
        if (!zipFiles.length) continue;

        const zipName = `${safePart(p.name, 60) || 'plugin'}_v${safePart(version, 24)}.zip`;
        const relDir = path.posix.join('plugins', p.id, version);
        const relPath = path.posix.join(relDir, zipName);
        const absPath = path.join(dataDir, relPath);
        fs.mkdirSync(path.dirname(absPath), { recursive: true });
        const buf = makeZip(zipFiles.map((f) => ({ name: f.name, data: f.data })));
        fs.writeFileSync(absPath, buf);

        const uploadedAt = Math.max(...zipFiles.map((f) => f.at || now));
        db.prepare(
          `INSERT INTO releases (plugin_id, version, filename, rel_path, size, sha256, entry_count, dll_name, entries, changelog, created)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`
        ).run(
          p.id,
          version,
          zipName,
          relPath,
          buf.length,
          sha256(buf),
          zipFiles.length,
          (zipFiles.find((f) => f.dll) || {}).dll || '',
          JSON.stringify(zipFiles.map((f) => ({ name: f.name, size: f.data.length }))),
          '从旧版插件市场恢复（升级时保留的原文件）',
          uploadedAt
        );
        fixedReleases += 1;
        if (!latest || uploadedAt > latest.at) latest = { version, at: uploadedAt };
      }

      if (latest) {
        db.prepare('UPDATE plugins SET version=? WHERE id=?').run(latest.version, p.id);
        // 老状态不是「已上架」的，恢复后先隐藏
        const cols = columnsOf(db, 'plugins');
        if (cols.includes('status')) {
          const row = db.prepare('SELECT status FROM plugins WHERE id=?').get(p.id);
          if (row && !['approved', 'review', 'online'].includes(row.status)) {
            db.prepare('UPDATE plugins SET offline=1 WHERE id=?').run(p.id);
          }
        }
        fixedPlugins += 1;
      }
    }
    db.exec('COMMIT');
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {}
    console.log('[db] 修复旧插件失败（不影响启动）：' + err.message);
    return;
  }

  if (fixedPlugins) {
    console.log(`[db] 已从磁盘恢复 ${fixedPlugins} 个插件 / ${fixedReleases} 个版本（原文件没有删除）`);
  }
}

export function openDb(dbFile, opts = {}) {
  const dataDir = opts.dataDir || path.dirname(path.dirname(dbFile));
  fs.mkdirSync(path.dirname(dbFile), { recursive: true });
  const db = new DatabaseSync(dbFile);
  db.exec(SCHEMA);
  ensureColumns(db);

  const meta = tableExists(db, 'meta') ? db.prepare("SELECT value FROM meta WHERE key='schema'").get() : null;
  if (!meta || meta.value !== SCHEMA_VERSION) migrateV1(db, dataDir, dbFile);

  // 每次启动都补一次：0 个版本但磁盘上还有老文件的插件，自动恢复成 zip
  repairReleases(db, dataDir);

  db.exec(INDEXES);
  return db;
}

/** node:sqlite 只接受 null / number / string / bigint / Buffer，这里统一收口。 */
function norm(params) {
  return params.map((p) => {
    if (p === undefined || p === null) return null;
    if (typeof p === 'boolean') return p ? 1 : 0;
    if (typeof p === 'number' && !Number.isFinite(p)) return null;
    if (p instanceof Date) return p.getTime();
    return p;
  });
}

export function makeStore(db) {
  const cache = new Map();
  const stmt = (sql) => {
    let s = cache.get(sql);
    if (!s) {
      s = db.prepare(sql);
      cache.set(sql, s);
    }
    return s;
  };

  return {
    raw: db,
    all: (sql, ...p) => stmt(sql).all(...norm(p)),
    get: (sql, ...p) => stmt(sql).get(...norm(p)) ?? null,
    run: (sql, ...p) => stmt(sql).run(...norm(p)),
    tx(fn) {
      db.exec('BEGIN');
      try {
        const r = fn();
        db.exec('COMMIT');
        return r;
      } catch (e) {
        try {
          db.exec('ROLLBACK');
        } catch {}
        throw e;
      }
    },
    close: () => db.close(),
  };
}
