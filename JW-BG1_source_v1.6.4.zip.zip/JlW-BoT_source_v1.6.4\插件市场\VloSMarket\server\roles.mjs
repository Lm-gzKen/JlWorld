// 管理员体系：
//   超级管理员  固定 3407556894@qq.com（写死，不能删除 / 不能降级）
//   管理员      超级管理员在「开发者中心 → 管理员」里手动添加的聚龙账户（按邮箱）
// 管理员可以：下架 / 重新上架 / 删除任意插件。
// 只有超级管理员可以新增 / 移除管理员。

export const SUPER_ADMIN_EMAIL = '3407556894@qq.com';

const norm = (email) => String(email || '').trim().toLowerCase();

export function isSuperAdmin(u) {
  return !!u && norm(u.email) === SUPER_ADMIN_EMAIL;
}

/** store 用来查 admins 表；判断某个登录用户是不是管理员 */
export function isAdmin(store, u) {
  if (!u) return false;
  if (isSuperAdmin(u)) return true;
  return !!store.get('SELECT 1 AS x FROM admins WHERE email = ?', norm(u.email));
}

export function publicUser(store, u) {
  if (!u) return null;
  const admin = isAdmin(store, u);
  const superAdmin = isSuperAdmin(u);
  return {
    email: u.email,
    name: u.nickname || String(u.email || '').split('@')[0],
    avatar: u.avatar || '',
    qq: u.qq || '',
    openid: u.openid || '',
    joined: u.first_seen,
    lastLogin: u.last_login,
    isAdmin: admin,
    isSuper: superAdmin,
    roleLabel: superAdmin ? '超级管理员' : admin ? '管理员' : '用户',
  };
}
