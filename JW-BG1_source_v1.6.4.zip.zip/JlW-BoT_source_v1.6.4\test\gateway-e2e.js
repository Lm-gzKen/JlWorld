'use strict';
/**
 * 网关端到端测试（多账户）：假 QQ 服务器 + 真实框架进程
 * 覆盖：两个账户各自 token/网关、事件按账户回复、面板发消息路由、易语言拉取与动作、断线 resume
 * 运行：node test/gateway-e2e.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');
const seedTestPlugins = require('./seed-plugins');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 10000, interval = 150, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

async function main() {
  console.log('\nJlWBoT 多账户网关端到端测试\n');
  const mock = await new MockQQ({ port: 0, accounts: { app_a: 'sec_a', app_b: 'sec_b' } }).start();
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const panelPort = 21000 + Math.floor(Math.random() * 500);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-gw-'));
  seedTestPlugins(dataDir, ROOT);
  const common = {
    mode: 'ws',
    sandbox: false,
    tokenUrl: mock.base + '/app/getAppAccessToken',
    tokenUrlAlt: mock.base + '/app/getAppAccessToken',
    apiBase: mock.base,
    apiBaseSandbox: mock.base,
    gatewayUrl: mock.wsUrl,
    intents: ['GUILDS', 'GROUP_AND_C2C_EVENT'],
    shardId: 0,
    shardCount: 1,
    enabled: true,
  };
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port: panelPort, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        accounts: [
          { ...common, id: 'a1', name: '一号', appId: 'app_a', clientSecret: 'sec_a', prefix: '/' },
          { ...common, id: 'a2', name: '二号', appId: 'app_b', clientSecret: 'sec_b', prefix: '/' },
        ],
        plugins: { enabled: true, defaultTimeoutMs: 4000 },
        log: { level: 'info', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  const childLog = [];
  child.stdout.on('data', (d) => childLog.push(String(d)));
  child.stderr.on('data', (d) => childLog.push(String(d)));

  const base = `http://127.0.0.1:${panelPort}`;
  const auth = { 'Content-Type': 'application/json' };
  let passed = 0;

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 15000, 200, '面板启动');
    console.log('  ✓ 面板启动');
    passed++;

    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    assert.equal(login.status, 200, '聚龙账户登录失败');
    const setCookie = (login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '';
    auth.Cookie = setCookie.split(';')[0];
    console.log('  ✓ 聚龙世界账户登录');
    passed++;

    const online = await waitFor(
      async () => {
        const s = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
        return s.accounts?.length === 2 && s.accounts.every((a) => a.state === 'online') ? s : null;
      },
      20000,
      200,
      '双账户上线',
    );
    assert.equal(online.accounts[0].name, '一号');
    assert.equal(online.accounts[1].name, '二号');
    console.log('  ✓ 两个账户同时 online');
    passed++;

    const withAvatar = await waitFor(
      async () => {
        const s = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
        return s.accounts?.length === 2 && s.accounts.every((a) => String(a.self?.avatar || '').startsWith('https://')) ? s : null;
      },
      8000,
      200,
      '机器人头像',
    );
    assert.ok(withAvatar, '机器人头像未从 /users/@me 获取或未归一化为 https');
    console.log('  ✓ 机器人头像取自 /users/@me 并归一化为 https');
    passed++;

    assert.ok(mock.identifies.app_a, 'app_a 未 identify');
    assert.ok(mock.identifies.app_b, 'app_b 未 identify');
    assert.equal(mock.identifies.app_a.token, 'QQBot mock_token_app_a');
    assert.equal(mock.identifies.app_b.token, 'QQBot mock_token_app_b');
    assert.ok((mock.identifies.app_a.intents & (1 << 25)) !== 0);
    console.log('  ✓ 每个账户使用各自 access_token 与 intents 完成鉴权');
    passed++;

    // 账户 A 的群消息，只能由 A 回复
    mock.pushGroupMessage({ appId: 'app_a', content: '/ping', group: 'G_A', user: 'U_A' });
    const sentA = await waitFor(() => mock.sent.find((s) => s.appId === 'app_a'), 8000, 150, 'A 回复');
    assert.ok(String(sentA.body.content).startsWith('pong'));
    await sleep(300);
    assert.ok(!mock.sent.some((s) => s.appId === 'app_b' && String(s.body.content).includes('pong')), 'B 不应收到 A 的事件');
    console.log('  ✓ 账户 A 的事件由 A 的账户凭证回复（账户隔离）');
    passed++;

    // 账户 B 的群消息
    mock.pushGroupMessage({ appId: 'app_b', content: '/ping', group: 'G_B', user: 'U_B' });
    const sentB = await waitFor(() => mock.sent.find((s) => s.appId === 'app_b'), 8000, 150, 'B 回复');
    assert.ok(String(sentB.body.content).startsWith('pong'));
    console.log('  ✓ 账户 B 独立收发');
    passed++;

    // 面板按账户发消息
    const sendRes = await fetch(base + '/api/send', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ accountId: 'a2', type: 'group', target: 'G_PANEL', content: '面板消息-二号' }),
    }).then((r) => r.json());
    assert.equal(sendRes.ok, true);
    assert.equal(sendRes.accountId, 'a2');
    await waitFor(() => mock.sent.some((s) => s.appId === 'app_b' && s.body.content === '面板消息-二号'), 5000, 150, '面板消息路由');
    console.log('  ✓ 面板发消息按 accountId 路由到 B');
    passed++;

    // 面板按 event_id 被动回复（GROUP_ADD_ROBOT 这类事件）
    const evtSend = await fetch(base + '/api/send', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ accountId: 'a1', type: 'group', target: 'G_EVT', content: '欢迎入群', event_id: 'EVENT_X1' }),
    }).then((r) => r.json());
    assert.equal(evtSend.ok, true);
    const evtSent = await waitFor(() => mock.sent.find((s) => s.body.event_id === 'EVENT_X1'), 5000, 150, 'event_id 回复');
    assert.ok(!('msg_id' in evtSent.body), 'event_id 回复不带 msg_id');
    assert.ok(!('msg_seq' in evtSent.body), 'event_id 回复不带 msg_seq');
    console.log('  ✓ 面板按 event_id 被动回复，不带 msg_id / msg_seq');
    passed++;

    // msg_id 与 event_id 混用：拒绝且不发请求
    const sentBefore = mock.sent.length;
    const mixed = await fetch(base + '/api/send', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ accountId: 'a1', type: 'group', target: 'G_MIX', content: 'x', msg_id: 'M1', event_id: 'E1' }),
    }).then((r) => r.json());
    assert.equal(mixed.ok, false);
    assert.match(String(mixed.error || mixed.message || ''), /不能同时传/);
    assert.equal(mock.sent.length, sentBefore, '混用引用不应发出请求');
    console.log('  ✓ msg_id 与 event_id 混用被拒绝');
    passed++;

    // 接口调试按账户调用
    const call = await fetch(base + '/api/call', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ accountId: 'a1', key: 'group_info', params: { group_openid: 'G_A' }, query: {}, body: {} }),
    }).then((r) => r.json());
    assert.equal(call.ok, true);
    assert.equal(call.accountId, 'a1');
    assert.equal(call.data.group_name, '测试群');
    console.log('  ✓ 接口注册表按账户调用');
    passed++;

    const groupInfo = await fetch(base + '/api/groups/info?account=a1&group=G_A', { headers: auth }).then((r) => r.json());
    assert.equal(groupInfo.ok, true);
    assert.equal(groupInfo.name, '测试群');
    console.log('  ✓ 消息页群名称接口');
    passed++;

    // 易语言拉取（text）+ 表单动作：事件带账户，动作回 accountId
    mock.pushGroupMessage({ appId: 'app_a', content: '/天气 上海', group: 'G_EL', user: 'U_EL' });
    const ptoken = (await fetch(base + '/api/plugins', { headers: auth }).then((r) => r.json())).info.token;
    const pullText = await waitFor(async () => {
      const t = await fetch(`${base}/plugin-api/v1/pull?plugin=el-sample&timeout=2000&format=text&token=${ptoken}`).then((r) => r.text());
      return t.includes('天气 上海') ? t : null;
    }, 8000, 200, '文本拉取');
    assert.ok(pullText.includes('account_id=a1'), '拉取文本缺少 account_id');
    assert.ok(pullText.includes('account_name=一号'), '拉取文本缺少 account_name');
    const msgId = pullText.match(/msg_id=(\S+)/)[1];
    const form = new URLSearchParams({
      plugin: 'el-sample',
      accountId: 'a1',
      action: 'reply',
      chat_type: 'group',
      group_openid: 'G_EL',
      msg_id: msgId,
      content: '【易语言】上海今天多云',
    }).toString();
    const actRes = await fetch(base + '/plugin-api/v1/action', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + ptoken, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form,
    }).then((r) => r.json());
    assert.equal(actRes.ok, true);
    assert.equal(actRes.accountId, 'a1');
    await waitFor(() => mock.sent.some((s) => s.body.content === '【易语言】上海今天多云'), 5000, 150, '易语言动作');
    const sentEl = mock.sent.find((s) => s.body.content === '【易语言】上海今天多云');
    assert.equal(sentEl.body.msg_id, msgId, '动作回复未带 msg_id');
    // 同一 msg_id 可能已被内置指令插件回复过，msg_seq 必须是递增的正整数
    const elIndex = mock.sent.indexOf(sentEl);
    const priorSameMsg = mock.sent.slice(0, elIndex).filter((s) => s.body.msg_id === msgId).length;
    assert.equal(sentEl.body.msg_seq, priorSameMsg + 1, '动作回复未自动分配递增 msg_seq');
    console.log('  ✓ 易语言拉取带账户信息，动作按 accountId 回复');
    passed++;

    // 只断开 A，B 不受影响，A 自动 resume（普通关闭 1000 不清 session）
    const clientA = mock.wsClients.get('app_a');
    assert.ok(clientA, '找不到 A 的连接');
    clientA.close(1000);
    await waitFor(() => mock.resumed === true, 12000, 200, 'A resume');
    const sentBeforeResume = mock.sent.length;
    mock.pushGroupMessage({ appId: 'app_a', content: '/ping', group: 'G_A2', user: 'U_A2' });
    await waitFor(() => mock.sent.length > sentBeforeResume, 8000, 150, 'A 重连后回复');
    assert.ok(mock.wsClients.get('app_b'), 'B 的连接不应断开');
    console.log('  ✓ 单账户断线重连不影响其他账户');
    passed++;

    // 4009 连接过期：必须丢掉旧 session 重新 Identify，不能一直 Resume 失败
    const identBefore = mock.identifyCounts['app_a'] || 0;
    const expired = mock.wsClients.get('app_a');
    assert.ok(expired, '4009 前找不到 A 的连接');
    expired.close(4009);
    await waitFor(() => (mock.identifyCounts['app_a'] || 0) > identBefore, 15000, 200, '4009 后重新 Identify');
    const stAfter4009 = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
    assert.equal(stAfter4009.accounts.find((x) => x.id === 'a1')?.state, 'online', '4009 后应重新上线');
    console.log('  ✓ 4009 连接过期后重新 Identify 上线');
    passed++;

    // 无权限 Intent：网关 4014 -> 框架自动回退到上次可用集合并重连
    const safeIntents = ['GUILDS', 'GUILD_MEMBERS', 'GUILD_MESSAGE_REACTIONS', 'DIRECT_MESSAGE', 'GROUP_AND_C2C_EVENT', 'PUBLIC_GUILD_MESSAGES', 'INTERACTION'];
    await fetch(base + '/api/accounts/a1', {
      method: 'PATCH',
      headers: auth,
      body: JSON.stringify({ intents: [...safeIntents, 'GUILD_MESSAGES'] }),
    });
    const recovered = await waitFor(async () => {
      const s = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
      const a = s.accounts?.find((x) => x.id === 'a1');
      return a && a.state === 'online' && !a.intents.includes('GUILD_MESSAGES') ? a : null;
    }, 20000, 250, 'Intent 自动回退');
    assert.ok(recovered.intents.includes('GROUP_AND_C2C_EVENT'));
    console.log('  ✓ 无权限 Intent 自动回退并重连');
    passed++;

    // 账户 CRUD
    const created = await fetch(base + '/api/accounts', {
      method: 'POST',
      headers: auth,
      body: JSON.stringify({ name: '三号', appId: 'app_c', clientSecret: 'sec_c', mode: 'webhook', enabled: false }),
    }).then((r) => r.json());
    assert.equal(created.ok, true);
    assert.ok(/^acc/.test(created.account.id), '账户 ID 生成异常：' + created.account.id);
    assert.ok(created.account.webhookPath.includes(created.account.id));
    const st3 = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
    assert.equal(st3.accounts.length, 3);
    const del = await fetch(base + '/api/accounts/' + created.account.id, { method: 'DELETE', headers: auth }).then((r) => r.json());
    assert.equal(del.ok, true);
    const st2 = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
    assert.equal(st2.accounts.length, 2);
    console.log('  ✓ 账户增删与状态聚合');
    passed++;

    // 公网 IP 接口（离线环境返回空 IP + error，但不能 500）
    const net = await fetch(base + '/api/netinfo', { headers: auth }).then((r) => r.json());
    assert.equal(net.ok, true);
    assert.equal(typeof net.ip, 'string');
    console.log(`  ✓ 公网 IP 接口可用（${net.ip || '离线降级'}）`);
    passed++;

    const st = await fetch(base + '/api/status', { headers: auth }).then((r) => r.json());
    assert.ok(st.aggregate.today >= 2);
    assert.equal(st.aggregate.online, 2);
    console.log('  ✓ 聚合统计正确');
    passed++;

    console.log(`\n全部通过（${passed} 项）\n`);
  } catch (e) {
    console.error('\n测试失败：', e.message);
    console.error('--- 子进程日志 ---');
    console.error(childLog.join('').slice(-5000));
    process.exitCode = 1;
  } finally {
    child.kill();
    await sleep(300);
    await mock.stop();
    await jlwMock.stop();
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
