'use strict';
/**
 * 我的世界查询 — JlWBoT 进程内 JS 插件
 *
 * 指令（大小写不敏感，命令名 >MC / mc 均可）：
 *   /MC 服务器地址        查询服务器状态，随机底图生成状态图（图片 + Markdown 摘要）
 *   /MC 服务器地址 -json  以 Markdown ```json 代码块返回原始 JSON
 *   /MC api               网站入口 + 图片接口调用帮助（Markdown）
 *   /MC                   指令菜单
 *
 * 数据来源：聚龙世界 MCStatus 接口
 *   POST /api/plugin/mcstatus/query   服务器状态
 *   POST /api/plugin/mcstatus/image   状态图（frame 指定底图，留空由服务端随机）
 *   POST /api/plugin/mcstatus/frames  底图模板列表
 *
/**
 * 约定：
 *   - key 只放在 plugin.json 的 config 里，不打印、不外泄到回复内容。
 *   - 状态图先上传到 QQ 素材库（/v2/media-images），用 qqbot-media:// 引用，
 *     这样一条 Markdown 被动回复里可以同时 @用户 + 引用 + 图片，不依赖外链可访问性。
 *   - 素材上传失败才回退富媒体图片（msg_type=7，无 @），再失败回退纯文字。
 *   - Markdown 发送失败（频道或未开通）自动回退纯文本。
 */

const crypto = require('crypto');

const DEFAULTS = {
  apiBase: 'https://www.jlworld.net',
  key: '',
  frameTtlMs: 300000,
  httpTimeoutMs: 12000,
  siteUrl: 'https://www.jlworld.net',
  siteImage: '',
  iconUrl: '',
  iconSize: 40,
  mediaKeep: 60,
  commands: [
    { type: 'status', label: '查询服务器', command: '/MC ', note: '图片查询，随机底图生成状态图' },
    { type: 'json', label: 'JSON 数据', command: '/MC -json ', note: '以 JSON 代码块返回原始数据' },
    { type: 'api', label: '接口帮助', command: '/MC api', note: '网站入口与图片接口调用帮助' },
    { type: 'menu', label: '指令菜单', command: '/MC', note: '打开本菜单' },
  ],
};

/**
 * 各指令的默认回复模板（Markdown，可用 {{变量}}）。
 * 设置页里编辑的 reply 会覆盖这里；这里也是设置页预览的初始内容。
 */
const DEFAULT_TEMPLATES = {
  status: ['{{user}}', '{{image}}'].join('\n'),
  json: ['```json', '{{json}}', '```'].join('\n'),
  api: [
    '{{siteImage}}',
    '## MC 状态图片接口 · [聚龙世界]({{site}})',
    '',
    '`POST {{imageEndpoint}}`',
    '',
    '```json',
    '{',
    '  "key": "mcst_你的密钥",',
    '  "host": "play.example.com",',
    '  "port": 25565,',
    '  "frame": "inventory"',
    '}',
    '```',
    '',
    '**请求参数**',
    '',
    '- `key`：接口密钥（服务端调用，不要放在公开网页前端）',
    '- `host`：服务器地址，必填',
    '- `port`：端口，默认 `25565`',
    '- `frame`：底图模板 id，留空则随机',
    '- `imageUrl`：自定义底图地址（PNG / JPEG，≤2MB）',
    '',
    '**返回字段**',
    '',
    '- `image`：PNG 的 `data:image/png;base64,...`',
    '- `imageUrl`：相对站点根的 PNG 地址，可直接 GET',
    '- `width` / `height`：图片尺寸（默认 760×270）',
    '- `frame`：实际使用的模板',
    '- `ping` / `queriedAt`：延迟 / 查询完成时间',
    '',
    '模板列表：`POST {{framesEndpoint}}`',
    '',
    '官网：{{site}}',
  ].join('\n'),
  menu: [
    '{{icon}}',
    '## 我的世界服务器查询',
    '',
    '**指令**',
    '',
    '{{commands}}',
    '',
    '点击下方蓝字按钮，指令会自动填入输入框，补上服务器地址后发送即可。',
    '',
    '> 支持 Java / 基岩版；端口默认 25565，基岩服请带端口（如 `:19132`）。',
  ].join('\n'),
};

/** 底图模板缓存：避免每查一次都请求 frames */
const frameCache = { at: 0, base: '', list: [] };
/** 菜单图标素材缓存：accountId|iconUrl → qqbot-media:// 引用 */
const iconMediaCache = new Map();

module.exports = {
  async onLoad(ctx) {
    ctx.log.info('我的世界查询已加载（命令：/MC）');
  },

  async onEvent(ctx) {
    try {
      const message = ctx.message;
      if (!message) return null;
      if (message.author?.bot) return null; // 不响应机器人，避免互相触发

      // 只处理以 /（半角或全角）开头的指令；不带 / 的普通聊天一律不响应
      const rawText = String(message.cleanContent ?? message.content ?? '').trim();
      if (!/^[/／]/.test(rawText)) return null;

      const command = message.command;
      if (command && command.matched === false) return null; // 尊重面板配置的前缀

      const rawName = command?.name || firstWord(rawText);
      if (normalize(rawName) !== 'mc') return null;

      const cfg = configOf(ctx);
      const args = resolveArgs(command, message);
      const { flags, words } = splitArgs(args);

      if (!words.length) return menu(ctx, cfg);
      const head = String(words[0]).toLowerCase();
      if (head === 'api' || head === 'help' || head === '接口') return apiHelp(ctx, cfg);
      if (head === 'json') return queryJson(ctx, cfg, words[1] || '');

      const target = words.join(' ');
      if (flags.has('json')) return queryJson(ctx, cfg, target);
      return queryStatus(ctx, cfg, target);
    } catch (e) {
      // 异常只写框架日志，不在群聊/私聊回错误信息，避免刷屏
      ctx.log.error('我的世界查询异常：' + (e?.stack || e));
      return null;
    }
  },

  async onUnload(ctx) {
    ctx.log.info('我的世界查询已卸载');
  },
};

/* ================= 命令实现 ================= */

/** /MC —— 指令菜单：Markdown（模板可编辑）+ 蓝色指令按钮 */
async function menu(ctx, cfg) {
  const icon = await iconMarkdown(ctx, cfg);
  const commands = commandList(cfg)
    .map((c) => `- \`${c.command}\`${c.note ? '：' + c.note : ''}`)
    .join('\n');
  const md = cleanTemplate(renderTemplate(templateFor(cfg, 'menu'), { icon, commands, title: '我的世界服务器查询' }));
  return sendRich(ctx, md, md, { keyboard: buildMenuKeyboard(cfg) });
}

/**
 * 菜单图标：把 config.iconUrl 的图片上传到 QQ 素材库，用 qqbot-media:// 引用（外链在客户端会裂图）。
 * 未配置 iconUrl 或上传失败时不显示图标。
 */
async function iconMarkdown(ctx, cfg) {
  const url = String(cfg.iconUrl || '').trim();
  if (!url) return '';
  const size = Math.max(16, Math.min(120, Number(cfg.iconSize) || DEFAULTS.iconSize));
  const mediaUrl = await ensureIconMedia(ctx, url);
  if (!mediaUrl) return '';
  return `![我的世界 #${size}px #${size}px](${mediaUrl})`;
}

async function ensureIconMedia(ctx, remoteUrl) {
  const key = `${ctx.account?.id || ''}|${remoteUrl}`;
  const cached = iconMediaCache.get(key);
  // 素材 90 天滑动有效；缓存 30 天后重新上传，避免旧引用失效
  if (cached && Date.now() - cached.at < 30 * 86400000) return cached.url;
  try {
    const res = await fetch(remoteUrl, { signal: AbortSignal.timeout(Number(ctx.plugin?.config?.httpTimeoutMs) || 10000) });
    if (!res.ok) {
      ctx.log.warn(`菜单图标下载失败：HTTP ${res.status}`);
      return '';
    }
    const buffer = Buffer.from(await res.arrayBuffer());
    const media = await uploadImageMedia(ctx, buffer, 'mc-menu-icon');
    if (media?.url) {
      iconMediaCache.set(key, { url: media.url, at: Date.now() });
      return media.url;
    }
  } catch (e) {
    ctx.log.warn('菜单图标上传失败：' + (e?.message || e));
  }
  return '';
}

/**
 * 菜单按钮：QQ Markdown 消息底部挂载的自定义按钮。
 * action.type=2（指令按钮）+ enter=false → 点击后把 data 插入输入框，不自动发送。
 * 每条指令一个按钮（最多 8 条），最后一行固定「点我查询」。
 */
function buildMenuKeyboard(cfg) {
  const list = commandList(cfg).slice(0, 8);
  const rows = [];
  for (let i = 0; i < list.length; i += 2) {
    rows.push({
      buttons: list
        .slice(i, i + 2)
        .map((c, j) => menuButton(i + j + 1, c.label || c.command, c.command)),
    });
  }
  rows.push({ buttons: [menuButton(list.length + 1, '点我查询', '/MC ')] });
  return { content: { rows } };
}

function menuButton(id, label, data) {
  return {
    id: String(id),
    render_data: { label, visited_label: label, style: 1 }, // style 1 = 蓝色线框
    action: {
      type: 2,
      permission: { type: 2 }, // 所有人可点
      data,
      enter: false, // false：只填入输入框，用户补完地址再发送
      reply: false,
      unsupport_tips: '请升级 QQ 客户端后使用按钮',
    },
  };
}

/** /MC api —— 网站 + 图片接口帮助（模板可编辑） */
async function apiHelp(ctx, cfg) {
  const site = cfg.siteUrl || DEFAULTS.siteUrl;
  const vars = {
    site,
    apiBase: cfg.apiBase || DEFAULTS.apiBase,
    imageEndpoint: joinUrl(cfg.apiBase, '/api/plugin/mcstatus/image'),
    queryEndpoint: joinUrl(cfg.apiBase, '/api/plugin/mcstatus/query'),
    framesEndpoint: joinUrl(cfg.apiBase, '/api/plugin/mcstatus/frames'),
    siteImage: cfg.siteImage ? `![聚龙世界](${cfg.siteImage})` : '',
  };
  const md = cleanTemplate(renderTemplate(templateFor(cfg, 'api'), vars));
  return sendRich(ctx, md, md);
}

/** /MC 地址 -json —— 模板可编辑，默认 JSON 代码块 */
async function queryJson(ctx, cfg, target) {
  const address = parseAddress(target);
  if (!address) {
    const md = '```json\n' + pretty({ ok: false, error: '缺少服务器地址' }) + '\n```';
    return sendRich(ctx, md, md);
  }

  const r = await mcPost(cfg, '/api/plugin/mcstatus/query', {
    key: cfg.key,
    host: address.host,
    port: address.port,
    edition: 'auto',
  });

  const payload = r.ok ? compact(r.data) : { ok: false, host: address.host, port: address.port, error: r.error };
  let json = pretty(payload);
  if (json.length > 1800) json = pretty(compact(payload, { maxString: 80, maxItems: 10 }));

  const vars = {
    json,
    ok: r.ok ? 'true' : 'false',
    error: r.ok ? '' : r.error,
    host: address.host,
    port: address.port,
    address: `${address.host}:${address.port}`,
    online: r.ok ? (r.data?.online ? '在线' : '离线') : '未知',
    players: r.ok ? r.data?.onlinePlayers ?? '' : '',
    maxPlayers: r.ok ? r.data?.maxPlayers ?? '' : '',
    version: r.ok ? r.data?.version || '' : '',
  };
  const md = cleanTemplate(renderTemplate(templateFor(cfg, 'json'), vars));

  // 失败（超时/网络/地址不存在）时挂「重新查询」按钮，点击直接重发原指令
  const opts = r.ok ? {} : { keyboard: retryKeyboard(`/MC ${target} -json`) };
  return sendRich(ctx, md, md, opts);
}

/**
 * /MC 地址 —— 一条被动回复：@用户 + 引用原消息 + 状态图
 * 图片走 Markdown 图片（平台会下载转存），因此能同时带上 @ 和引用；
 * 群聊/单聊都只在被动回复里发，不占用主动消息额度。
 */
async function queryStatus(ctx, cfg, target) {
  const address = parseAddress(target);
  if (!address) {
    return { reply: '请提供服务器地址，例如：/MC mc.hypixel.net' };
  }
  const command = `/MC ${target}`;

  const [status, frames] = await Promise.all([
    mcPost(cfg, '/api/plugin/mcstatus/query', {
      key: cfg.key,
      host: address.host,
      port: address.port,
      edition: 'auto',
    }),
    loadFrames(cfg).catch(() => []),
  ]);

  if (!status.ok) {
    return retryMessage(ctx, command, '查询失败', `${status.error}\n地址：${address.host}:${address.port}`);
  }

  const frame = pickFrame(frames);
  const picture = await mcPost(cfg, '/api/plugin/mcstatus/image', {
    key: cfg.key,
    host: address.host,
    port: address.port,
    frame: frame ? frame.id : '',
  });

  if (!picture.ok) {
    return retryMessage(ctx, command, '状态图生成失败', `${picture.error}\n地址：${address.host}:${address.port}`);
  }

  // 模板渲染：{{image}} 存在时才上传素材（外链在客户端会裂图）
  const template = templateFor(cfg, 'status');
  const needsImage = /\{\{\s*image\s*\}\}/.test(template);
  const width = Math.max(1, Number(picture.data.width) || 760);
  const height = Math.max(1, Number(picture.data.height) || 270);
  let imageMarkdown = '';
  if (needsImage) {
    const media = await uploadStatusMedia(ctx, picture.data);
    if (media) imageMarkdown = `![服务器状态图 #${width}px #${height}px](${media.url})`;
  }

  // 模板要图但素材上传失败：不发空消息，直接提示 + 重试按钮（仍是 Markdown）
  if (needsImage && !imageMarkdown) {
    return retryMessage(ctx, command, '状态图发送失败', `地址：${address.host}:${address.port}`);
  }

  const member = ctx.message?.kind === 'group' ? ctx.message?.author?.member_openid || '' : '';
  const vars = statusVars(status.data || {}, picture.data, imageMarkdown, member ? `<qqbot-at-user id="${member}" />` : '', cfg);
  const md = cleanTemplate(renderTemplate(template, vars));
  if (!md) return retryMessage(ctx, command, '状态图发送失败', `地址：${address.host}:${address.port}`);

  // 只用 Markdown：@用户 + 引用 + 图/文字，一条被动回复
  if (await sendMarkdown(ctx, md)) {
    scheduleCleanup(ctx);
    return null;
  }
  return retryMessage(ctx, command, '状态图发送失败', `地址：${address.host}:${address.port}`);
}

/* ================= 模板 ================= */

/** {{变量}} 替换；未知变量原样保留，方便用户发现拼错 */
function renderTemplate(template, vars) {
  return String(template || '').replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (all, key) => {
    return Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key] ?? '') : all;
  });
}

/** 去掉首尾空行（模板里 {{icon}} 为空时会留空行） */
function cleanTemplate(markdown) {
  return String(markdown || '')
    .replace(/^[ \t]*\n+/, '')
    .replace(/\n+[ \t]*$/, '');
}

/** 取某类指令的回复模板：用户编辑的 reply 优先，否则内置默认 */
function templateFor(cfg, type) {
  const item = commandList(cfg).find((c) => c.type === type);
  const custom = item && typeof item.reply === 'string' ? item.reply.trim() : '';
  return custom || DEFAULT_TEMPLATES[type] || '';
}

/** 状态查询可用变量 */
function statusVars(data, picture, imageMarkdown, userMarkdown, cfg) {
  const online = data.online === true;
  return {
    user: userMarkdown,
    image: imageMarkdown,
    imageUrl: picture?.imageUrl ? joinUrl(cfg.apiBase, picture.imageUrl) : '',
    host: data.host || '',
    port: data.port ?? '',
    address: data.address || `${data.host || ''}:${data.port || ''}`,
    edition: data.edition === 'bedrock' ? '基岩版' : data.edition === 'java' ? 'Java 版' : '未知',
    version: data.version || '',
    protocol: data.protocol ?? '',
    online: online ? '在线' : '离线',
    onlineBool: online ? 'true' : 'false',
    players: data.onlinePlayers ?? '',
    maxPlayers: data.maxPlayers ?? '',
    motd: oneLine(String(data.motdText || '').replace(/§./g, '')).slice(0, 120),
    ping: data.ping ?? data.latencyMs ?? '',
    frame: picture?.frame?.name || picture?.frame?.id || '',
    queried: formatTime(data.queriedAt),
  };
}

/** 上传状态图到素材库，返回 { url, id } 或 null */
async function uploadStatusMedia(ctx, picture) {
  const base64 = dataUriBase64(picture?.image);
  if (!base64) return null;
  return uploadImageMedia(ctx, Buffer.from(base64, 'base64'), 'mc-status');
}

/** 只发一条 Markdown 被动回复（用于模板渲染结果） */
async function sendMarkdown(ctx, markdown) {
  const api = ctx.api;
  const message = ctx.message;
  if (!api?.reply || !message) return false;
  if (message.kind !== 'group' && message.kind !== 'c2c') return false;
  const r = await api.reply(message, { msg_type: 2, markdown: { content: markdown } });
  if (r?.ok) return true;
  ctx.log.warn(`Markdown 发送失败（${r?.code ?? r?.message ?? '未知'}）`);
  return false;
}

/* ================= 发送 ================= */

/** 只用 Markdown 发送（可带按钮）；失败只记日志，不降级成纯文本/富媒体 */
async function sendRich(ctx, markdown, plain, opts = {}) {
  const message = ctx.message;
  const api = ctx.api;
  if (!api?.reply || !message || (message.kind !== 'group' && message.kind !== 'c2c')) {
    ctx.log.warn('当前会话不支持 Markdown 消息，跳过发送');
    return null;
  }
  const payload = { msg_type: 2, markdown: { content: markdown } };
  if (opts.keyboard) payload.keyboard = opts.keyboard;
  const r = await api.reply(message, payload);
  if (r?.ok) return null;
  ctx.log.warn(`Markdown 发送失败（${r?.code ?? r?.message ?? '未知'}）`);
  return null;
}

/** 上传图片到 QQ 素材库（prepare → PUT → complete），返回 { url: 'qqbot-media://...', id } */
async function uploadImageMedia(ctx, buffer, baseName = 'mc-image') {
  const api = ctx.api;
  if (!api?.request || !buffer?.length) return null;
  const kind = detectImage(buffer);
  if (!kind) {
    ctx.log.warn('素材上传跳过：不是 PNG/JPEG/GIF/WebP');
    return null;
  }
  const md5 = crypto.createHash('md5').update(buffer).digest('hex');
  const sha1 = crypto.createHash('sha1').update(buffer).digest('hex');
  const fileName = `${baseName}-${Date.now()}.${kind.ext}`;

  try {
    const prep = await api.request('POST', '/v2/media-images/prepare', {
      body: { file_name: fileName, file_size: buffer.length, content_type: kind.type, md5, sha1 },
    });
    if (!prep?.ok || !prep.data?.upload_id || !prep.data?.presigned_url) {
      ctx.log.warn(`素材 prepare 失败：${prep?.code ?? prep?.message ?? '未知'}`);
      return null;
    }

    const put = await fetch(prep.data.presigned_url, {
      method: 'PUT',
      headers: { 'Content-Type': kind.type },
      body: buffer,
    });
    if (!put.ok) {
      ctx.log.warn(`素材 PUT 失败：HTTP ${put.status}`);
      return null;
    }

    const done = await api.request('POST', '/v2/media-images/complete', {
      body: { upload_id: prep.data.upload_id, md5 },
    });
    if (!done?.ok || !done.data?.url) {
      ctx.log.warn(`素材 complete 失败：${done?.code ?? done?.message ?? '未知'}`);
      return null;
    }
    return { url: done.data.url, id: done.data.image_id };
  } catch (e) {
    ctx.log.warn('素材上传异常：' + (e?.message || e));
    return null;
  }
}

function detectImage(buffer) {
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
    return { ext: 'png', type: 'image/png' };
  }
  if (buffer[0] === 0xff && buffer[1] === 0xd8) return { ext: 'jpg', type: 'image/jpeg' };
  if (buffer.slice(0, 3).toString('ascii') === 'GIF') return { ext: 'gif', type: 'image/gif' };
  if (buffer.slice(8, 12).toString('ascii') === 'WEBP') return { ext: 'webp', type: 'image/webp' };
  return null;
}

/** 素材库上限 100 张：发完后异步清理，只保留最近 N 张 */
function scheduleCleanup(ctx) {
  const timer = setTimeout(() => cleanupMedia(ctx).catch(() => {}), 1500);
  if (timer.unref) timer.unref();
}

async function cleanupMedia(ctx) {
  const api = ctx.api;
  if (!api?.request) return;
  const keep = Math.max(10, Number(ctx.plugin?.config?.mediaKeep) || DEFAULTS.mediaKeep);
  const list = await api.request('GET', '/v2/media-images');
  const images = list?.ok ? list.data?.images || [] : [];
  // 只清理状态图（mc-status-*），菜单图标（mc-menu-icon-*）保留
  const statusImages = images.filter((img) => String(img?.file_name || '').startsWith('mc-status-'));
  if (statusImages.length <= keep) return;
  for (const img of statusImages.slice(keep)) {
    if (!img?.image_id) continue;
    try {
      await api.request('DELETE', `/v2/media-images/${encodeURIComponent(img.image_id)}/delete`);
    } catch {
      /* 清理失败不影响回复 */
    }
  }
}

/** 「重新查询」按钮：enter=true，点击后直接发送原指令 */
function retryKeyboard(command) {
  return {
    content: {
      rows: [
        {
          buttons: [
            {
              id: 'retry',
              render_data: { label: '重新查询', visited_label: '重新查询', style: 1 },
              action: {
                type: 2,
                permission: { type: 2 },
                data: command,
                enter: true,
                reply: false,
                unsupport_tips: '请升级 QQ 客户端后使用按钮',
              },
            },
          ],
        },
      ],
    },
  };
}

/** 失败提示 + 重新查询按钮（仍走 Markdown） */
function retryMessage(ctx, command, title, detail) {
  const markdown = `**${title}**\n\n${detail}`;
  return sendRich(ctx, markdown, markdown, { keyboard: retryKeyboard(command) });
}

/* ================= 指令表 ================= */

/** 用户可编辑的指令表（config.commands），为空时用内置默认；旧配置缺 type 时按顺序补，保证模板可用 */
function commandList(cfg) {
  const list = Array.isArray(cfg.commands) ? cfg.commands : [];
  const fallbackTypes = ['status', 'json', 'api', 'menu'];
  const cleaned = list
    .map((c, i) => ({
      type: String(c?.type || '').trim() || fallbackTypes[i] || 'status',
      label: String(c?.label || '').trim(),
      command: String(c?.command || '').trim(),
      note: String(c?.note || '').trim(),
      reply: typeof c?.reply === 'string' ? c.reply : '',
    }))
    .filter((c) => c.command);
  return cleaned.length ? cleaned : DEFAULTS.commands;
}

/* ================= 接口 ================= */

async function mcPost(cfg, path, body) {
  const base = String(cfg.apiBase || DEFAULTS.apiBase).replace(/\/+$/, '');
  const timeout = Number(cfg.httpTimeoutMs) || DEFAULTS.httpTimeoutMs;
  try {
    const res = await fetch(base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeout),
    });
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }
    if (!res.ok) {
      return { ok: false, status: res.status, error: friendly(data?.error || data?.message || `HTTP ${res.status}`) };
    }
    if (data && data.ok === false) return { ok: false, status: res.status, data, error: friendly(data.error) };
    return { ok: true, data };
  } catch (e) {
    if (e?.name === 'TimeoutError') return { ok: false, error: '接口超时，请稍后重试' };
    return { ok: false, error: `网络错误：${e?.message || e}` };
  }
}

/** 底图模板：5 分钟缓存 */
async function loadFrames(cfg) {
  const ttl = Number(cfg.frameTtlMs) || DEFAULTS.frameTtlMs;
  const base = String(cfg.apiBase || DEFAULTS.apiBase);
  if (frameCache.list.length && frameCache.base === base && Date.now() - frameCache.at < ttl) {
    return frameCache.list;
  }
  const r = await mcPost(cfg, '/api/plugin/mcstatus/frames', { key: cfg.key });
  if (!r.ok) throw new Error(r.error);
  const list = Array.isArray(r.data?.frames) ? r.data.frames : Array.isArray(r.data) ? r.data : [];
  frameCache.at = Date.now();
  frameCache.base = base;
  frameCache.list = list.filter((f) => f && f.id);
  return frameCache.list;
}

function pickFrame(list) {
  if (!Array.isArray(list) || !list.length) return null;
  return list[Math.floor(Math.random() * list.length)];
}

/* ================= 工具 ================= */

function configOf(ctx) {
  return { ...DEFAULTS, ...(ctx.plugin?.config || {}) };
}

function resolveArgs(command, message) {
  if (Array.isArray(command?.args) && command.args.length) return command.args.map(String);
  return String(message.cleanContent || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(1);
}

function splitArgs(args) {
  const flags = new Set();
  const words = [];
  for (const raw of args || []) {
    const token = String(raw);
    const low = token.toLowerCase();
    if (low === '-json' || low === '--json' || low === '—json' || low === '－json') {
      flags.add('json');
      continue;
    }
    words.push(token);
  }
  return { flags, words };
}

function parseAddress(input) {
  let text = String(input || '').trim();
  if (!text) return null;
  text = text.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim();
  if (!text || /\s/.test(text)) return null;
  let host = text;
  let port = 0;
  const m = text.match(/^\[([^\]]+)\](?::(\d{1,5}))?$/);
  if (m) {
    host = m[1];
    port = Number(m[2] || 0);
  } else {
    const m2 = text.match(/^([^:]+):(\d{1,5})$/);
    if (m2) {
      host = m2[1];
      port = Number(m2[2]);
    }
  }
  if (!host || !/^[A-Za-z0-9._-]+$/.test(host)) return null;
  if (port && (port < 1 || port > 65535)) port = 0;
  return { host, port: port || 25565 };
}

/** JSON 压缩：超长字符串与列表截断，保证是合法 JSON 且能发出去 */
function compact(value, opts = {}) {
  const maxString = opts.maxString || 240;
  const maxItems = opts.maxItems || 40;
  const visit = (v) => {
    if (typeof v === 'string') {
      if (v.length <= maxString) return v;
      return v.slice(0, maxString) + `…(共${v.length}字符)`;
    }
    if (Array.isArray(v)) return v.slice(0, maxItems).map(visit);
    if (v && typeof v === 'object') {
      const out = {};
      for (const [k, val] of Object.entries(v)) {
        if (k === 'iconUrl' && typeof val === 'string' && val.startsWith('data:')) {
          out[k] = val.slice(0, 30) + `…(共${val.length}字符，已省略)`;
        } else {
          out[k] = visit(val);
        }
      }
      return out;
    }
    return v;
  };
  return visit(value);
}

function pretty(value) {
  return JSON.stringify(value, null, 2);
}

function dataUriBase64(uri) {
  const text = String(uri || '');
  const m = text.match(/^data:[^;,]+;base64,(.+)$/i);
  if (!m) return '';
  return m[1];
}

function joinUrl(base, path) {
  if (!path) return base || '';
  if (/^https?:\/\//i.test(path)) return path;
  return String(base || '').replace(/\/+$/, '') + '/' + String(path).replace(/^\/+/, '');
}

function friendly(error) {
  const msg = String(error || '').trim();
  if (!msg) return '接口返回失败';
  if (/key|密钥/i.test(msg) && /(无效|错误|不存在|invalid)/i.test(msg)) return '接口密钥无效或已失效';
  if (/关闭|停用|disabled/i.test(msg)) return '查询接口已关闭';
  if (/每分钟|频率|次数|rate|过多/i.test(msg)) return '查询太频繁，请稍后再试';
  if (/内网|本机|局域网|private|local/i.test(msg)) return '服务端拒绝内网 / 本机地址';
  if (/模板|frame/i.test(msg)) return '图片模板不存在';
  if (/不存在|无法解析|解析失败|找不到|not found|unknown host/i.test(msg)) return '服务器地址不存在或无法解析';
  return msg;
}

function normalize(name) {
  return String(name || '')
    .trim()
    .replace(/^[/／]+/, '')
    .toLowerCase();
}

function oneLine(text) {
  return String(text || '').replace(/\s+/g, ' ').trim();
}

function formatTime(ms) {
  const n = Number(ms);
  const d = Number.isFinite(n) && n > 0 ? new Date(n) : new Date();
  const pad = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function firstWord(text) {
  return String(text || '').trim().split(/\s+/)[0] || '';
}
