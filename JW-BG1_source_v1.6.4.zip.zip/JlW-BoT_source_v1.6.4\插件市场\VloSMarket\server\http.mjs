// 极简 HTTP 工具：请求体读取、响应发送、静态文件、Cookie。零第三方依赖。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
};

// 在 <head> 紧后面注入：在首次绘制前决定风格。
// 默认白天；用户手动切过（localStorage 里有 vlosTheme）就按他存的来，下次进来也保持。
const THEME_BOOT =
  '<script>document.documentElement.dataset.theme="light";try{var t=localStorage.getItem("vlosTheme");if(t)document.documentElement.dataset.theme=t}catch(e){}</script>';

export function readBody(req, limitBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let overflow = false;
    req.on('data', (c) => {
      // 超限后不再缓存（内存保持平稳），让剩下的字节直接丢掉，这样还能正常回 413
      if (overflow) return;
      size += c.length;
      if (size > limitBytes) {
        overflow = true;
        chunks.length = 0;
        reject(new HttpError(413, `上传内容超过上限 ${Math.round(limitBytes / 1048576)} MB`));
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!overflow) resolve(Buffer.concat(chunks));
    });
    req.on('error', (e) => reject(new HttpError(400, `读取请求失败：${e.message}`)));
  });
}

export async function readJson(req, limitBytes = 256 * 1024) {
  const buf = await readBody(req, limitBytes);
  if (!buf.length) return {};
  const text = buf.toString('utf8').trim();
  if (!text) return {};
  try {
    const v = JSON.parse(text);
    if (v === null || typeof v !== 'object' || Array.isArray(v)) throw new Error('顶层必须是对象');
    return v;
  } catch (e) {
    throw new HttpError(400, `请求体不是合法 JSON：${e.message}`);
  }
}

export function sendJson(res, status, obj, extraHeaders) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(
    status,
    Object.assign(
      {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': body.length,
        'Cache-Control': 'no-store',
      },
      extraHeaders || {}
    )
  );
  res.end(body);
}

export function sendText(res, status, text, contentType = 'text/plain; charset=utf-8') {
  const body = Buffer.from(text, 'utf8');
  res.writeHead(status, { 'Content-Type': contentType, 'Content-Length': body.length, 'Cache-Control': 'no-store' });
  res.end(body);
}

export function sendFileDownload(res, absPath, downloadName, size) {
  const stat = fs.statSync(absPath);
  const headers = {
    'Content-Type': 'application/octet-stream',
    'Content-Length': stat.size,
    'Cache-Control': 'no-store',
  };
  if (downloadName) {
    headers['Content-Disposition'] =
      `attachment; filename="${downloadName.replace(/[^\x20-\x7e]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(downloadName)}`;
  }
  res.writeHead(200, headers);
  const stream = fs.createReadStream(absPath);
  stream.on('error', () => res.destroy());
  stream.pipe(res);
  return size === undefined ? stat.size : size;
}

export function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie;
  if (!raw) return out;
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  }
  return out;
}

export function setCookie(res, name, value, opts = {}) {
  const bits = [`${name}=${encodeURIComponent(value)}`];
  bits.push(`Path=${opts.path || '/'}`);
  if (opts.maxAge !== undefined) bits.push(`Max-Age=${opts.maxAge}`);
  if (opts.httpOnly !== false) bits.push('HttpOnly');
  bits.push(`SameSite=${opts.sameSite || 'Lax'}`);
  if (opts.secure) bits.push('Secure');
  const prev = res.getHeader('Set-Cookie');
  const list = prev ? (Array.isArray(prev) ? prev.concat(bits.join('; ')) : [prev, bits.join('; ')]) : [bits.join('; ')];
  res.setHeader('Set-Cookie', list);
}

export function clearCookie(res, name) {
  setCookie(res, name, '', { maxAge: 0 });
}

/** 静态文件服务：只允许 rootDir 内的文件，防目录穿越。 */
export function serveStatic(res, rootDir, urlPath) {
  const hasVersion = /[?&]v=/.test(urlPath); // 带版本参数的资源 = 内容指纹固定，可以长期强缓存
  let rel = decodeURIComponent(urlPath.split('?')[0]);
  if (rel.endsWith('/')) rel += 'index.html';
  const abs = path.resolve(rootDir, '.' + path.posix.normalize(rel));
  const rootAbs = path.resolve(rootDir);
  if (abs !== rootAbs && !abs.startsWith(rootAbs + path.sep)) {
    sendText(res, 403, '禁止访问');
    return true;
  }
  let stat;
  try {
    stat = fs.statSync(abs);
  } catch {
    return false;
  }
  if (stat.isDirectory()) return serveStatic(res, rootDir, rel.replace(/\/?$/, '/') + 'index.html');

  const ext = path.extname(abs).toLowerCase();

  // HTML 改写：
  //  1) 在首次绘制前把上次选的风格（夜晚/白天）写到 <html> 上，避免切到白天时先闪深色；
  //  2) 给 /assets 下的 css、js 加上内容指纹（?v=大小-时间）。
  //     以前改版后浏览器可能还用着旧的 app.css，新旧 JS/CSS 一混搭界面就散架了；
  //     加了指纹之后，文件一变 URL 就变，永远不可能混用。
  let htmlBody = null;
  let size = stat.size;
  if (ext === '.html' || ext === '.htm') {
    try {
      const src = fs.readFileSync(abs, 'utf8');
      let out = /<head[^>]*>/i.test(src) ? src.replace(/<head[^>]*>/i, (m) => m + THEME_BOOT) : THEME_BOOT + src;
      out = out.replace(/(["'])(\/assets\/[^"'?]+\.(?:css|js))\1/g, (m, q, ref) => {
        const v = assetStamp(rootDir, ref);
        return v ? q + ref + '?v=' + v + q : m;
      });
      htmlBody = out;
      size = Buffer.byteLength(htmlBody);
    } catch {
      htmlBody = null;
    }
  }

  // ETag 的算法很讲究：
  //  HTML 是「读进来 + 注入 + 改写过」的，字节数不一定随内容变化
  //  （比如 admin.js?v=20191-1791791849239 换成 22079-1791797068508，
  //   长度一样，注入后总字节数就一样，而 HTML 文件本身没被改过）。
  //  如果 ETag 只看「字节数 + HTML 文件时间」，就会和上一版撞车 → 回 304 →
  //  浏览器一直咬着旧 HTML（连带旧的 ?v= 资源地址）不放。所以这里用内容哈希。
  const etag =
    htmlBody !== null
      ? `W/"h${crypto.createHash('sha1').update(htmlBody).digest('hex').slice(0, 16)}"`
      : `W/"${size}-${Math.round(stat.mtimeMs)}-t2"`;
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': size,
    // HTML 与未带版本号的资源：每次协商缓存，改了立刻生效
    // 带版本号的资源：内容不会变，直接强缓存一年，隧道下也不再反复往返
    'Cache-Control': hasVersion ? 'public, max-age=31536000, immutable' : 'no-cache',
    ETag: etag,
  };
  if (!hasVersion && res.req && res.req.headers['if-none-match'] === etag) {
    res.writeHead(304, { ETag: etag, 'Cache-Control': 'no-cache' });
    res.end();
    return true;
  }
  res.writeHead(200, headers);
  if (htmlBody === null) fs.createReadStream(abs).pipe(res);
  else res.end(htmlBody);
  return true;
}

/** 取某个静态资源的内容指纹（大小 + 修改时间），用于 HTML 里的 ?v= 版本号 */
function assetStamp(rootDir, ref) {
  try {
    const s = fs.statSync(path.resolve(rootDir, '.' + path.posix.normalize(ref)));
    if (!s.isFile()) return '';
    return `${s.size}-${Math.round(s.mtimeMs)}`;
  } catch {
    return '';
  }
}

export function clientIp(req, trustProxy) {
  if (trustProxy) {
    const xff = req.headers['x-forwarded-for'];
    if (xff) return String(xff).split(',')[0].trim();
  }
  return (req.socket && req.socket.remoteAddress) || '';
}

export const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
export const newToken = () => crypto.randomBytes(32).toString('base64url');
export const newId = () => crypto.randomBytes(9).toString('hex');

/** 文件名净化：去掉路径分隔符与控制字符，保留中文与前导点（.gitignore 这类点文件）。 */
export function safeFileName(name) {
  let base = String(name || '')
    .replace(/[\\/]/g, '_')
    .replace(/[\x00-\x1f\x7f]/g, '')
    .trim();
  base = base.replace(/^\.{2,}/, '.'); // "..." / "..x" 收敛成单点，避免目录穿越
  if (!base || /^\.+$/.test(base)) base = 'file';
  return base.slice(0, 120);
}
