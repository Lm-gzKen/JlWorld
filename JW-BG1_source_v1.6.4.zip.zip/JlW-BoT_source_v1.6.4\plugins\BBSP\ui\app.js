'use strict';
/**
 * BBSP 积木工作台（面板内置设置页版）
 *
 * 运行环境：面板设置页的沙箱 iframe —— 不能联网、不能写磁盘、没有 localStorage。
 * 因此所有数据都走面板给的配置通道：
 *   - 打开：parent.postMessage({type:'jlw-settings-init', config})    → 读项目/DLL/上次导出
 *   - 保存：parent.postMessage({type:'jlw-settings-save', config})    → 面板写 plugin.json 并重载插件
 *   - 插件 onLoad 再把配置里的 DLL base64 落盘、执行 pending 导出/安装
 *
 * 代码分成两块：
 *   1) 纯前端编辑器：组件库、画布拖拽、参数编辑（与后端无关）
 *   2) 配置桥：load/save/导入 DLL/导出（全部通过 postMessage）
 */
(() => {
  const B = window.BBSP.blocks;
  const P = window.BBSP.project;
  const C = window.BBSP.codegen;
  const CFG = window.BBSP.config;
  const PE = window.BBSP.pe;

  /* ================= 小工具 ================= */

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }
  function clone(v) {
    return v == null ? null : JSON.parse(JSON.stringify(v));
  }
  function uid() {
    return 'n' + Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 6);
  }
  function nowIso() {
    return new Date().toISOString();
  }
  function fmtTime(d) {
    return new Date(d).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }

  let toastTimer = null;
  function toast(message, type = '') {
    const box = $('#toast');
    box.textContent = message;
    box.className = 'toast' + (type ? ' ' + type : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => box.classList.add('hidden'), type === 'err' ? 6000 : 2800);
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      /* 沙箱里可能没有剪贴板权限 */
    }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return !!ok;
    } catch {
      return false;
    }
  }

  /**
   * 沙箱设置页没有 allow-modals：window.confirm / prompt 会被浏览器忽略。
   * 统一用页面内弹窗，返回 Promise。
   */
  function askConfirm(title, message, okLabel = '确定') {
    return new Promise((resolve) => {
      openModal(
        title,
        (m) => {
          m.body.appendChild(el('p', 'help', message));
          m.button('取消', '', () => {
            closeModal();
            resolve(false);
          });
          m.button(okLabel, 'primary', () => {
            closeModal();
            resolve(true);
          });
        },
        { size: 'sm' },
      );
    });
  }

  function askText(title, label, value = '', placeholder = '') {
    return new Promise((resolve) => {
      openModal(
        title,
        (m) => {
          const field = el('div', 'field');
          field.appendChild(el('label', '', label));
          const input = el('input', 'input');
          input.value = value;
          input.placeholder = placeholder;
          field.appendChild(input);
          m.body.appendChild(field);
          const ok = () => {
            closeModal();
            resolve(input.value.trim());
          };
          input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') ok();
          });
          setTimeout(() => {
            input.focus();
            input.select();
          }, 60);
          m.button('取消', '', () => {
            closeModal();
            resolve('');
          });
          m.button('确定', 'primary', ok);
        },
        { size: 'sm' },
      );
    });
  }

  function toBase64(bytes) {
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CH, bytes.length)));
    }
    return btoa(s);
  }

  function hashHex(bytes) {
    // 轻量哈希，只用来生成稳定的 DLL id（不用 crypto，沙箱里也不依赖安全上下文）
    let h1 = 0x811c9dc5;
    let h2 = 0x01000193;
    for (let i = 0; i < bytes.length; i++) {
      h1 ^= bytes[i];
      h1 = Math.imul(h1, 0x01000193) >>> 0;
      h2 = (Math.imul(h2 ^ bytes[i], 0x85ebca6b) + i) >>> 0;
    }
    return (h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0')).slice(0, 12);
  }

  /* ================= 状态 ================= */

  const state = {
    config: CFG.normalizeConfig(null).config,
    project: null,
    connected: false,
    dirty: false,
    saving: null,
    pendingSave: null,
    savedAt: '',
    lastAction: null,
    activeCat: 'all',
    search: '',
    zoom: 1,
    panX: 24,
    panY: 18,
    nodes: new Map(),
    focusScriptId: '',
    preview: null,
    localOnly: false,
    payloadSize: 0,
    payloadDirty: true,
    popupWin: null,
    popupReady: false,
    popupPending: null,
    history: [],
    future: [],
    historyTimer: null,
    restoring: false,
    context: { embedded: true, direct: false, compact: false, width: 0, height: 0, mode: 'editor' },
  };

  /**
   * 环境识别：
   *   - 是否嵌在面板 iframe 里：window.parent !== window（可靠；沙箱跨域也能判断）
   *   - 「面板弹窗」还是「设置页新窗口」：两者都是同一个沙箱 iframe，父页 URL 跨域不可读，
   *     只能按视口大小推断（<1000×620 视为内嵌小窗，提示去「新页面」全屏）。
   *   - 直接打开 /settings 或本地文件：没有父页，只读预览。
   */
  function detectContext() {
    const embedded = window.parent !== window;
    const width = window.innerWidth || 0;
    const height = window.innerHeight || 0;
    let hasOpener = false;
    try {
      hasOpener = !!(window.opener && !window.opener.closed);
    } catch {
      hasOpener = !!window.opener;
    }
    return {
      embedded,
      direct: !embedded,
      width,
      height,
      compact: embedded && (width < 1000 || height < 620),
      // 内嵌（面板弹窗 / 设置页新窗口）→ 启动页；被启动页 window.open 出来的顶层窗口 → 编辑器（保存走 opener 中转）；
      // 直接打开顶层页面 → 只读编辑器。
      mode: embedded ? 'launcher' : hasOpener ? 'popup' : 'editor',
    };
  }

  const defs = () => B.DEFS;
  const categories = () => B.CATEGORIES;
  const catColor = (id) => {
    const c = categories().find((x) => x.id === id);
    return c ? c.color : '#4a9eff';
  };
  const catName = (id) => {
    const c = categories().find((x) => x.id === id);
    return c ? c.name : id;
  };
  const projects = () => state.config.projects || [];
  const dllList = () => state.config.dlls || [];
  const components = () => (state.project && state.project.components) || [];
  const dllLib = () => CFG.dllLibrary(state.config);

  const RET_OPTIONS = [
    { value: 'text_ansi', label: '文本（ANSI/易语言 文本型）' },
    { value: 'text_utf8', label: '文本（UTF-8）' },
    { value: 'int', label: '整数（32 位）' },
    { value: 'long', label: '长整数（64 位）' },
    { value: 'double', label: '小数（double）' },
    { value: 'float', label: '小数（float）' },
    { value: 'bool', label: '逻辑（0/1）' },
    { value: 'ptr', label: '指针' },
    { value: 'void', label: '无返回值' },
  ];

  function defOf(node) {
    if (node.type === 'def_component') {
      return { category: 'component', shape: 'hat', label: '定义组件', body: true, fields: [], template: ['定义组件'] };
    }
    return defs()[node.type] || null;
  }

  /* ================= 节点模型 ================= */

  function makeNodeFromSpec(spec) {
    if (!spec || !spec.type) return null;
    const def = defs()[spec.type];
    if (!def) return null;
    const node = { id: uid(), type: spec.type, fields: {}, slots: [] };
    for (const f of def.fields || []) node.fields[f.name] = f.default !== undefined ? f.default : '';
    for (const s of def.slots || []) node.slots.push(s.default ? makeNodeFromSpec(s.default) : null);
    if (def.body) node.body = [];
    if (def.elseBody) node.elseBody = [];
    if (spec.fields) Object.assign(node.fields, spec.fields);
    if (Array.isArray(spec.slots) && def.slots) node.slots = spec.slots.map((s) => makeNodeFromSpec(s));
    if (spec.value !== undefined && def.fields && def.fields[0]) node.fields[def.fields[0].name] = spec.value;
    return node;
  }

  function findDllExport(ref) {
    const s = String(ref || '');
    const at = s.indexOf('::');
    if (at < 0) return null;
    const dll = dllList().find((d) => d.id === s.slice(0, at));
    if (!dll) return null;
    return (dll.exports || []).find((e) => (e.clean || e.name) === s.slice(at + 2)) || null;
  }

  function makeNode(type, preset = {}) {
    const def = defs()[type];
    if (!def) throw new Error('未知积木：' + type);
    const node = { id: uid(), type, fields: {}, slots: [] };
    for (const f of def.fields || []) node.fields[f.name] = f.default !== undefined ? f.default : '';
    if (preset.fields) Object.assign(node.fields, preset.fields);
    if (def.body) node.body = [];
    if (def.elseBody) node.elseBody = [];
    let slotDefs = def.slots || [];
    if (def.dynamic === 'component') {
      const comp = components().find((c) => c.id === node.fields.comp);
      slotDefs = comp ? comp.params.map((p) => ({ name: p.name })) : [];
    } else if (def.dynamic === 'dll') {
      const ex = findDllExport(node.fields.dllref);
      slotDefs = ex ? ex.params.map((t, i) => ({ name: 'arg' + i })) : [];
    }
    for (let i = 0; i < slotDefs.length; i++) {
      const sd = slotDefs[i];
      node.slots.push(sd && sd.default ? makeNodeFromSpec(sd.default) : null);
    }
    return node;
  }

  function syncDynamicSlots(node) {
    const def = defs()[node.type];
    if (!def) return;
    let count = 0;
    if (def.dynamic === 'component') {
      const comp = components().find((c) => c.id === node.fields.comp);
      count = comp ? comp.params.length : 0;
    } else if (def.dynamic === 'dll') {
      const ex = findDllExport(node.fields.dllref);
      count = ex ? ex.params.length : 0;
    } else {
      return;
    }
    while (node.slots.length < count) node.slots.push(null);
    if (node.slots.length > count) node.slots.length = count;
  }

  function locate(nodeId) {
    if (!state.project) return null;
    const walk = (list, chain, stackId) => {
      for (let i = 0; i < list.length; i++) {
        const node = list[i];
        if (node.id === nodeId) return { list, index: i, chain, stackId };
        if (Array.isArray(node.body)) {
          const hit = walk(node.body, chain ? chain + '|' + node.id + '|body' : node.id + '|body', stackId);
          if (hit) return hit;
        }
        if (Array.isArray(node.elseBody)) {
          const hit = walk(node.elseBody, chain ? chain + '|' + node.id + '|elseBody' : node.id + '|elseBody', stackId);
          if (hit) return hit;
        }
      }
      return null;
    };
    for (const script of state.project.scripts) {
      const hit = walk(script.blocks, '', script.id);
      if (hit) return hit;
    }
    return null;
  }

  function listFor(stackId, chain) {
    if (!state.project) return null;
    const script = state.project.scripts.find((s) => s.id === stackId);
    if (!script) return null;
    if (!chain) return script.blocks;
    const parts = chain.split('|');
    let list = script.blocks;
    for (let i = 0; i < parts.length; i += 2) {
      const node = list.find((n) => n.id === parts[i]);
      if (!node) return null;
      list = node[parts[i + 1]];
      if (!Array.isArray(list)) return null;
    }
    return list;
  }

  function containerForBlock(blockEl) {
    if (!blockEl) return null;
    const stackEl = blockEl.closest('.stack');
    if (!stackEl) return null;
    const chainParts = [];
    let container = blockEl.parentElement;
    let guard = 0;
    while (container && guard++ < 32) {
      if (container.classList.contains('stack-body')) break;
      if (container.classList.contains('c-body') || container.classList.contains('c-else')) {
        const owner = container.parentElement && container.parentElement.closest ? container.parentElement.closest('.block') : null;
        if (!owner) break;
        chainParts.unshift(owner.dataset.id, container.classList.contains('c-else') ? 'elseBody' : 'body');
        container = owner.parentElement;
        continue;
      }
      container = container.parentElement;
    }
    return { stackId: stackEl.dataset.stack, chain: chainParts.join('|') };
  }

  function countBlocks() {
    let n = 0;
    const walk = (list) => {
      for (const node of list || []) {
        n++;
        if (node.body) walk(node.body);
        if (node.elseBody) walk(node.elseBody);
        for (const s of node.slots || []) if (s) walk([s]);
      }
    };
    for (const s of (state.project && state.project.scripts) || []) walk(s.blocks);
    return n;
  }

  /* ================= 渲染：调色板 ================= */

  function renderCategories() {
    const cats = $('#cats');
    cats.innerHTML = '';
    const all = [{ id: 'all', name: '全部', color: 'var(--accent)' }].concat(categories());
    for (const c of all) {
      const btn = el('button', 'cat', c.name);
      btn.style.setProperty('--c', c.color);
      btn.classList.toggle('on', state.activeCat === c.id);
      btn.addEventListener('click', () => {
        state.activeCat = c.id;
        renderCategories();
        renderPalette();
      });
      cats.appendChild(btn);
    }
  }

  function paletteItems() {
    const out = [];
    for (const [type, def] of Object.entries(defs())) {
      if (type === 'comp_call' || type === 'dll_call') continue;
      out.push({ key: type, type, label: def.label, category: def.category, shape: def.shape });
    }
    out.push({ key: 'new-component', type: '__new_component', label: '＋ 新建组件', category: 'component', shape: 'stmt', tag: '点击/拖出' });
    for (const comp of components()) {
      out.push({
        key: 'comp:' + comp.id,
        type: 'comp_call',
        label: comp.name,
        category: 'component',
        shape: 'expr',
        tag: comp.params.length ? comp.params.length + ' 参' : '无参',
        preset: { fields: { comp: comp.id } },
      });
    }
    for (const dll of dllList()) {
      for (const ex of dll.exports || []) {
        if (ex.enabled === false) continue;
        out.push({
          key: 'dll:' + dll.id + ':' + (ex.clean || ex.name),
          type: 'dll_call',
          label: (dll.alias || dll.name) + ' · ' + (ex.clean || ex.name),
          category: 'dll',
          shape: 'expr',
          tag: (ex.ret || 'int').replace('text_', '文本/'),
          preset: { fields: { dllref: dll.id + '::' + (ex.clean || ex.name) } },
        });
      }
    }
    return out;
  }

  function renderPalette() {
    const listEl = $('#palette-list');
    listEl.innerHTML = '';
    const q = state.search.trim().toLowerCase();
    const items = paletteItems().filter((it) => {
      if (state.activeCat !== 'all' && it.category !== state.activeCat) return false;
      if (!q) return true;
      return (it.label + ' ' + it.type).toLowerCase().includes(q);
    });
    const groups = new Map();
    for (const it of items) {
      if (!groups.has(it.category)) groups.set(it.category, []);
      groups.get(it.category).push(it);
    }
    if (!items.length) listEl.appendChild(el('div', 'palette-empty', state.search ? '没有匹配的积木' : '这个分类还没有组件'));
    for (const [cat, arr] of groups) {
      const group = el('div', 'palette-group');
      group.style.setProperty('--c', catColor(cat));
      const head = el('h4');
      head.appendChild(el('span', 'dot'));
      head.appendChild(document.createTextNode(catName(cat)));
      group.appendChild(head);
      for (const it of arr) {
        const chip = el('div', 'chip' + (it.shape === 'expr' ? ' expr' : ''));
        chip.style.setProperty('--c', catColor(it.category));
        chip.draggable = true;
        chip.appendChild(el('span', 'dot'));
        chip.appendChild(el('span', 'label', it.label));
        if (it.tag) chip.appendChild(el('span', 'tag', it.tag));
        chip.title = it.shape === 'expr' ? '表达式积木：点到已渲染的虚线插槽里，或拖到插槽上' : '语句积木：点一下加到脚本末尾，或拖到画布/积木里';
        chip.addEventListener('dragstart', (e) => {
          e.dataTransfer.effectAllowed = 'copy';
          e.dataTransfer.setData('application/x-bbsp', JSON.stringify({ type: it.type, preset: it.preset || {} }));
          e.dataTransfer.setData('text/plain', it.label);
        });
        chip.addEventListener('click', () => insertFromPalette(it));
        group.appendChild(chip);
      }
      listEl.appendChild(group);
    }
    $('#palette-count').textContent = items.length + ' 个';
  }

  /* ================= 渲染：画布 ================= */

  function render() {
    const stacksEl = $('#stacks');
    stacksEl.innerHTML = '';
    state.nodes.clear();
    const project = state.project;
    $('#welcome').classList.toggle('hidden', !!project);
    if (!project) {
      updateHud();
      updateProjectUi();
      return;
    }
    let hasBlocks = false;
    for (const script of project.scripts) {
      hasBlocks = hasBlocks || (script.blocks || []).length > 0;
      const stackEl = el('div', 'stack');
      stackEl.dataset.stack = script.id;
      stackEl.style.left = (script.x || 0) + 'px';
      stackEl.style.top = (script.y || 0) + 'px';
      stackEl.appendChild(renderStackBody(script));
      stacksEl.appendChild(stackEl);
    }
    $('#canvas-empty').classList.toggle('hidden', hasBlocks);
    updateHud();
    updateProjectUi();
  }

  function renderStackBody(script) {
    const wrap = el('div', 'stack-body');
    wrap.dataset.stack = script.id;
    appendList(wrap, script.blocks, { stackId: script.id, chain: '' });
    return wrap;
  }

  function appendList(container, list, ctx) {
    for (let i = 0; i < (list || []).length; i++) {
      container.appendChild(makeGap(ctx, i));
      container.appendChild(renderBlock(list[i], ctx));
    }
    const tail = makeGap(ctx, (list || []).length);
    tail.classList.add('tail');
    if (!list || !list.length) {
      tail.classList.add('stack-empty');
      tail.textContent = '拖入积木';
    }
    container.appendChild(tail);
  }

  function makeGap(ctx, index) {
    const gap = el('div', 'gap');
    gap.dataset.drop = 'stack';
    gap.dataset.stack = ctx.stackId;
    gap.dataset.chain = ctx.chain;
    gap.dataset.index = String(index);
    return gap;
  }

  function renderBlock(node, ctx) {
    state.nodes.set(node.id, node);
    const def = defOf(node);
    if (!def) return el('div', 'block', '未知积木：' + node.type);
    const block = el('div', 'block');
    block.dataset.id = node.id;
    block.dataset.type = node.type;
    block.style.setProperty('--c', catColor(def.category));
    if (def.shape === 'hat') block.classList.add('hat');
    if (node.type === 'def_component') block.classList.add('def');
    const comp = node.type === 'def_component' ? components().find((c) => c.id === node.fields.comp) : null;

    const line = el('div', 'block-line');
    if (node.type === 'def_component') {
      line.appendChild(el('span', 'label-text', '定义组件「' + (comp ? comp.name : '?') + '」'));
      if (comp) line.appendChild(el('span', 'badge', comp.params.length ? '参数 ' + comp.params.map((p) => p.name).join('、') : '无参数'));
    } else {
      for (const part of def.template || []) {
        if (typeof part === 'string') line.appendChild(el('span', 'label-text', part));
        else if (part.f) {
          const f = (def.fields || []).find((x) => x.name === part.f);
          if (f) line.appendChild(renderField(node, f, ctx));
        } else if (part.s !== undefined) line.appendChild(renderSlot(node, part.s, ctx));
      }
      if (def.dynamic) {
        line.appendChild(el('span', 'label-text', '('));
        const slots = node.slots || [];
        if (!slots.length) line.appendChild(el('span', 'muted', '无参数'));
        slots.forEach((s, i) => {
          if (i) line.appendChild(el('span', 'label-text', ', '));
          line.appendChild(renderSlot(node, i, ctx));
        });
        line.appendChild(el('span', 'label-text', ')'));
      }
    }
    if (def.hint) {
      const dot = el('span', 'hint-dot', '?');
      dot.title = def.hint;
      line.appendChild(dot);
    }
    block.appendChild(line);

    const compParams = node.type === 'def_component' && comp ? comp.params.map((p) => p.name) : ctx.compParams;
    if (def.body) {
      const bodyChain = ctx.chain ? ctx.chain + '|' + node.id + '|body' : node.id + '|body';
      const body = el('div', 'c-body');
      body.dataset.drop = 'body';
      body.dataset.stack = ctx.stackId;
      body.dataset.chain = bodyChain;
      appendList(body, node.body || [], { stackId: ctx.stackId, chain: bodyChain, compParams });
      block.appendChild(body);
    }
    if (def.elseBody) {
      block.appendChild(el('div', 'c-else-label', '否则'));
      const elseChain = ctx.chain ? ctx.chain + '|' + node.id + '|elseBody' : node.id + '|elseBody';
      const els = el('div', 'c-else');
      els.dataset.drop = 'body';
      els.dataset.stack = ctx.stackId;
      els.dataset.chain = elseChain;
      appendList(els, node.elseBody || [], { stackId: ctx.stackId, chain: elseChain, compParams });
      block.appendChild(els);
    }

    const del = el('button', 'del', '×');
    del.title = '删除这块积木';
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      removeNode(node.id);
    });
    if (def.shape !== 'expr') block.appendChild(del);
    return block;
  }

  function renderField(node, f, ctx = {}) {
    const wrap = el('span', 'fld');
    const value = node.fields[f.name];

    if (f.kind === 'select') {
      const sel = document.createElement('select');
      for (const op of f.options || []) {
        const o = document.createElement('option');
        o.value = op.value;
        o.textContent = op.label;
        sel.appendChild(o);
      }
      sel.value = value;
      sel.title = f.label || '';
      sel.addEventListener('change', () => {
        node.fields[f.name] = sel.value;
        onChangeStructural();
      });
      wrap.appendChild(sel);
      return wrap;
    }

    if (f.kind === 'var') {
      const sel = document.createElement('select');
      const locals = (ctx && ctx.compParams) || [];
      const globals = ((state.project && state.project.vars) || []).map((v) => v.name);
      const names = locals.concat(globals.filter((n) => !locals.includes(n)));
      if (value && !names.includes(value)) names.unshift(value);
      for (const name of names) {
        const o = document.createElement('option');
        o.value = name;
        o.textContent = (locals.includes(name) ? '局部 · ' : '全局 · ') + name;
        sel.appendChild(o);
      }
      if (!names.length) {
        const o = document.createElement('option');
        o.value = '';
        o.textContent = '（先建变量）';
        sel.appendChild(o);
      }
      sel.value = value || names[0] || '';
      sel.title = (locals.length ? '组件参数是局部变量；项目「变量」是全局变量' : f.label || '变量') + (locals.includes(sel.value) ? '（局部）' : '');
      sel.addEventListener('change', () => {
        node.fields[f.name] = sel.value;
        onChangeStructural();
      });
      wrap.appendChild(sel);
      return wrap;
    }

    if (f.kind === 'component') {
      const sel = document.createElement('select');
      const none = document.createElement('option');
      none.value = '';
      none.textContent = '（选组件）';
      sel.appendChild(none);
      for (const c of components()) {
        const o = document.createElement('option');
        o.value = c.id;
        o.textContent = c.name;
        sel.appendChild(o);
      }
      sel.value = value || '';
      sel.addEventListener('change', () => {
        node.fields[f.name] = sel.value;
        syncDynamicSlots(node);
        onChangeStructural();
      });
      wrap.appendChild(sel);
      return wrap;
    }

    if (f.kind === 'dllref') {
      const sel = document.createElement('select');
      const none = document.createElement('option');
      none.value = '';
      none.textContent = '（选 DLL 函数）';
      sel.appendChild(none);
      for (const dll of dllList()) {
        const group = document.createElement('optgroup');
        group.label = dll.alias || dll.name;
        let any = false;
        for (const ex of dll.exports || []) {
          if (ex.enabled === false) continue;
          const o = document.createElement('option');
          o.value = dll.id + '::' + (ex.clean || ex.name);
          o.textContent = (ex.clean || ex.name) + ' → ' + (ex.ret || 'int');
          group.appendChild(o);
          any = true;
        }
        if (any) sel.appendChild(group);
      }
      sel.value = value || '';
      sel.addEventListener('change', () => {
        node.fields[f.name] = sel.value;
        syncDynamicSlots(node);
        onChangeStructural();
      });
      wrap.appendChild(sel);
      return wrap;
    }

    if (f.kind === 'code') {
      const btn = el('button', 'fld code', String(value || '').slice(0, 24) || '（空）');
      btn.type = 'button';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openCodeEditor(node, f);
      });
      return btn;
    }

    const input = document.createElement('input');
    input.type = f.kind === 'number' ? 'number' : 'text';
    input.value = value === undefined || value === null ? '' : String(value);
    input.placeholder = f.placeholder || f.label || '';
    input.title = f.label || '';
    input.size = Math.max(4, Math.min(22, String(input.value).length + 2));
    input.addEventListener('input', () => {
      node.fields[f.name] = f.kind === 'number' ? Number(input.value) : input.value;
      input.size = Math.max(4, Math.min(22, String(input.value).length + 2));
      markDirty();
      schedulePreview();
    });
    input.addEventListener('pointerdown', (e) => e.stopPropagation());
    wrap.appendChild(input);
    return wrap;
  }

  function renderSlot(node, index, ctx = {}) {
    const slot = el('span', 'slot');
    slot.dataset.slotIndex = String(index);
    const child = node.slots[index];
    if (child) {
      const holder = el('span', 'slot-holder');
      holder.appendChild(renderBlock(child, { stackId: ctx.stackId || '', chain: ctx.chain || '', compParams: ctx.compParams }));
      const del = el('button', 'del slot-del', '×');
      del.title = '清空插槽';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        node.slots[index] = null;
        onChangeStructural();
      });
      holder.appendChild(del);
      slot.appendChild(holder);
    } else {
      const ph = el('span', 'slot-empty', '拖入…');
      ph.dataset.drop = 'slot';
      slot.appendChild(ph);
    }
    return slot;
  }

  function updateHud() {
    $('#zoom-label').textContent = Math.round(state.zoom * 100) + '%';
    $('#block-count').textContent = state.project ? countBlocks() + ' 块' : '0 块';
    $('#stacks').style.transform = `translate(${state.panX}px, ${state.panY}px) scale(${state.zoom})`;
    if (state.payloadDirty) {
      state.payloadSize = JSON.stringify(buildPayload()).length;
      state.payloadDirty = false;
    }
    $('#cfg-size').textContent = '配置 ' + Math.max(1, Math.round(state.payloadSize / 1024)) + 'KB';
  }

  function updateProjectUi() {
    const p = state.project;
    const nameEl = $('#proj-name');
    const subEl = $('#proj-sub');
    const conn = $('#conn');
    const ctx = state.context;
    if (conn) {
      if (ctx.mode === 'popup') {
        conn.textContent = state.popupReady ? '弹窗 · 已连接面板' : '弹窗 · 等待面板…';
        conn.className = 'badge ' + (state.popupReady ? 'ok' : 'warn');
        conn.title = '保存经启动页中转；请保持面板里的 BBSP 设置页打开';
      } else if (state.connected) {
        conn.textContent = ctx.embedded ? (ctx.compact ? '内嵌小窗 · 建议全屏' : '面板设置页') : '面板已连接';
        conn.className = 'badge ' + (ctx.compact ? 'warn' : 'ok');
        conn.title = (ctx.embedded ? '在面板 iframe 里' : '没有面板父页（直接打开）') + ' · ' + ctx.width + '×' + ctx.height;
      } else {
        conn.textContent = state.localOnly ? (ctx.embedded ? '内嵌未连接 · 只读预览' : '直接打开 · 只读预览') : '等待面板…';
        conn.className = 'badge ' + (state.localOnly ? 'err' : '');
        conn.title = (ctx.embedded ? '在面板 iframe 里' : '没有面板父页（直接打开）') + ' · ' + ctx.width + '×' + ctx.height;
      }
    }
    const hint = $('#ctx-hint');
    if (hint) hint.classList.toggle('hidden', !(state.connected && ctx.compact));
    const saveBtn = $('#btn-save');
    if (saveBtn) saveBtn.classList.toggle('dirty', state.dirty);
    if (state.connected && ctx.mode === 'launcher') {
      nameEl.textContent = 'BBSP 积木编程';
      subEl.textContent = '新建或打开项目，会在新标签页全屏编辑';
      return;
    }
    if (!p) {
      nameEl.textContent = '未打开项目';
      subEl.textContent = state.connected ? '点「项目」新建一个 .bbsp 项目' : '请从面板打开设置页';
      return;
    }
    nameEl.textContent = p.name;
    if (state.context.mode === 'popup') document.title = 'BBSP · ' + p.name;
    const parts = [p.pluginId, '积木 ' + countBlocks()];
    if (state.dirty) parts.push('未保存');
    else if (state.savedAt) parts.push('已保存 ' + state.savedAt);
    else parts.push('已同步');
    subEl.textContent = parts.join(' · ');
  }

  /* ================= 编辑操作 ================= */

  async function removeNode(nodeId) {
    const loc = locate(nodeId);
    if (!loc) return;
    const node = loc.list[loc.index];
    if ((node.type === 'def_component' || node.type === 'on_message' || node.type === 'on_load') && loc.chain === '') {
      const script = state.project.scripts.find((s) => s.blocks === loc.list);
      if (script) {
        if (node.type === 'def_component') {
          const comp = components().find((c) => c.id === node.fields.comp);
          const name = comp ? comp.name : '?';
          const ok = await askConfirm('删除组件', '删除组件「' + name + '」？画布上调用它的积木会失效。', '删除');
          if (!ok) return;
          state.project.components = components().filter((c) => c.id !== node.fields.comp);
          state.project.scripts = state.project.scripts.filter((s) => s !== script);
          onChangeStructural();
          toast('已删除组件「' + name + '」', 'ok');
          return;
        }
        const ok = await askConfirm('删除脚本', '删除整个脚本「' + script.title + '」？', '删除');
        if (!ok) return;
        state.project.scripts = state.project.scripts.filter((s) => s !== script);
        onChangeStructural();
        return;
      }
    }
    loc.list.splice(loc.index, 1);
    onChangeStructural();
  }

  function onChangeStructural() {
    markDirty();
    render();
    renderPalette();
    schedulePreview();
  }

  function markDirty() {
    if (!state.project) return;
    state.dirty = true;
    state.payloadDirty = true;
    scheduleHistory();
    updateProjectUi();
  }

  /* ---------------- 撤销 / 重做 ---------------- */

  function projectSnapshot() {
    return state.project ? JSON.stringify(state.project) : '';
  }

  function resetHistory() {
    state.history = state.project ? [projectSnapshot()] : [];
    state.future = [];
    clearTimeout(state.historyTimer);
    updateHistoryButtons();
  }

  function scheduleHistory() {
    if (state.restoring) return;
    clearTimeout(state.historyTimer);
    state.historyTimer = setTimeout(commitHistory, 350);
  }

  function commitHistory() {
    if (!state.project || state.restoring) return;
    const json = projectSnapshot();
    if (!json) return;
    if (state.history.length && state.history[state.history.length - 1] === json) return;
    state.history.push(json);
    if (state.history.length > 80) state.history.shift();
    state.future.length = 0;
    updateHistoryButtons();
  }

  function updateHistoryButtons() {
    const u = $('#btn-undo');
    const r = $('#btn-redo');
    if (u) u.disabled = state.history.length < 2;
    if (r) r.disabled = !state.future.length;
  }

  function restoreSnapshot(json) {
    if (!state.project) return;
    let data;
    try {
      data = JSON.parse(json);
    } catch {
      return;
    }
    const target = projects().find((p) => p.id === state.project.id) || state.project;
    state.restoring = true;
    for (const k of Object.keys(target)) delete target[k];
    Object.assign(target, data);
    state.project = target;
    if (!state.config.activeProjectId) state.config.activeProjectId = target.id;
    markDirty();
    render();
    renderCategories();
    renderPalette();
    refreshPreview();
    updateHistoryButtons();
    state.restoring = false;
  }

  function undo() {
    commitHistory();
    if (state.history.length < 2) {
      toast('没有可撤销的操作');
      return;
    }
    state.future.push(state.history.pop());
    restoreSnapshot(state.history[state.history.length - 1]);
    updateHistoryButtons();
  }

  function redo() {
    if (!state.future.length) {
      toast('没有可重做的操作');
      return;
    }
    const json = state.future.pop();
    state.history.push(json);
    restoreSnapshot(json);
    updateHistoryButtons();
  }

  function schedulePreview() {
    clearTimeout(state.previewTimer);
    state.previewTimer = setTimeout(refreshPreview, 350);
  }

  function buildPreview(project) {
    try {
      const gen = C.generate(project || state.project, dllLib());
      return gen;
    } catch (e) {
      return { code: '', manifest: {}, warnings: [e.message], stats: {} };
    }
  }

  function refreshPreview() {
    if (!state.project) return;
    state.preview = buildPreview(state.project);
    if (!$('#drawer').classList.contains('hidden')) renderDrawer(state.preview);
    updateHud();
  }

  /* ================= 配置桥：保存 ================= */

  function buildPayload() {
    return {
      version: 1,
      settings: { dllTimeoutMs: Number(state.config.settings.dllTimeoutMs) || 15000 },
      projects: projects(),
      activeProjectId: state.project ? state.project.id : '',
      dlls: dllList(),
      pending: state.config.pending || null,
    };
  }

  function saveConfig(opts = {}) {
    if (state.context.mode === 'popup') return popupSaveConfig(opts);
    if (!state.connected) {
      toast('当前是只读预览（没有连接到面板），不能保存。请从面板「插件 → BBSP → 编辑 → 设置」打开。', 'err');
      return Promise.reject(new Error('未连接面板'));
    }
    if (state.pendingSave) {
      // 已在保存：等它完成后视情况再存一次
      const wait = state.pendingSave.promise.catch(() => {});
      return wait.then(() => saveConfig(opts));
    }
    const payload = buildPayload();
    const hadPending = payload.pending ? { action: payload.pending.action, id: payload.pending.package ? payload.pending.package.id : (payload.pending.project && payload.pending.project.pluginId) || '', at: payload.pending.at } : null;
    const entry = { payload, hadPending, canResolve: true };
    entry.promise = new Promise((resolve, reject) => {
      entry.resolve = resolve;
      entry.reject = reject;
      entry.timer = setTimeout(() => {
        if (state.pendingSave === entry) state.pendingSave = null;
        reject(new Error('保存超时：面板没有回应（检查是否在面板里打开、是否已登录）'));
      }, 30000);
    });
    state.pendingSave = entry;
    updateProjectUi();
    try {
      parent.postMessage({ type: 'jlw-settings-save', config: payload }, '*');
    } catch (e) {
      clearTimeout(entry.timer);
      state.pendingSave = null;
      return Promise.reject(e);
    }
    return entry.promise.then(
      () => {
        if (!opts.silent) toast('已保存到插件配置', 'ok');
        return true;
      },
      (e) => {
        if (!opts.silent) toast('保存失败：' + e.message, 'err');
        throw e;
      },
    );
  }

  function markSaved(hadPending) {
    // DLL 二进制已经由插件落盘，内存里不再保留 base64
    for (const d of dllList()) {
      if (d.base64) delete d.base64;
    }
    if (hadPending) {
      state.lastAction = { ...hadPending, at: Date.now(), saved: true };
      state.config.pending = null;
    }
    state.dirty = false;
    state.payloadDirty = true;
    state.savedAt = fmtTime(Date.now());
    updateProjectUi();
    updateHud();
  }

  function onSettingsSaved(msg) {
    const entry = state.pendingSave;
    if (!entry) return;
    clearTimeout(entry.timer);
    state.pendingSave = null;
    if (!msg || msg.ok === false) {
      entry.reject(new Error((msg && msg.error) || '面板保存失败'));
      updateProjectUi();
      return;
    }
    markSaved(entry.hadPending);
    entry.resolve(true);
  }

  /* ---------------- 弹窗模式：保存经 opener 中转 ---------------- */

  function popupSaveConfig(opts = {}) {
    if (!state.popupReady) {
      toast('没有连接到面板（弹窗模式），不能保存。请从面板里的 BBSP 设置页重新打开。', 'err');
      return Promise.reject(new Error('弹窗未连接面板'));
    }
    if (state.popupPending) {
      const wait = state.popupPending.promise.catch(() => {});
      return wait.then(() => popupSaveConfig(opts));
    }
    const payload = buildPayload();
    const hadPending = payload.pending
      ? { action: payload.pending.action, id: payload.pending.package ? payload.pending.package.id : (payload.pending.project && payload.pending.project.pluginId) || '', at: payload.pending.at }
      : null;
    const id = 'ps' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const entry = { id, hadPending, timer: null };
    entry.promise = new Promise((resolve, reject) => {
      entry.resolve = resolve;
      entry.reject = reject;
      entry.timer = setTimeout(() => {
        if (state.popupPending === entry) state.popupPending = null;
        reject(new Error('面板窗口没有响应：请保持面板里的 BBSP 设置页打开（保存通道）'));
      }, 20000);
    });
    state.popupPending = entry;
    try {
      window.opener.postMessage({ type: 'bbsp-popup-save', id, config: payload }, '*');
    } catch (e) {
      clearTimeout(entry.timer);
      state.popupPending = null;
      return Promise.reject(e);
    }
    return entry.promise.then(
      () => {
        if (!opts.silent) toast('已保存到插件配置', 'ok');
        return true;
      },
      (e) => {
        if (!opts.silent) toast('保存失败：' + e.message, 'err');
        throw e;
      },
    );
  }

  function popupHello() {
    if (!window.opener) return;
    try {
      window.opener.postMessage({ type: 'bbsp-popup-hello', v: 1 }, '*');
    } catch {
      /* ignore */
    }
  }

  function onPopupConfigMessage(msg) {
    if (!msg || !msg.config) return;
    state.popupReady = true;
    state.connected = true;
    state.localOnly = false;
    onSettingsInit({ config: msg.config });
    $('#banner').classList.add('hidden');
  }

  function onPopupSavedMessage(msg) {
    const entry = state.popupPending;
    if (!entry || !msg || msg.id !== entry.id) return;
    clearTimeout(entry.timer);
    state.popupPending = null;
    if (msg.ok === false) {
      entry.reject(new Error(msg.error || '面板保存失败'));
      return;
    }
    markSaved(entry.hadPending);
    entry.resolve(true);
  }

  async function onClickSave() {
    if (!state.project) return toast('先新建或载入一个项目', 'err');
    try {
      await saveConfig({});
    } catch {
      /* toast 已在 saveConfig 里 */
    }
  }

  function onSettingsInit(msg) {
    const raw = msg && msg.config && typeof msg.config === 'object' ? msg.config : null;
    state.connected = !!raw || state.connected;
    if (raw) {
      const norm = CFG.normalizeConfig(raw);
      state.config = norm.config;
      state.lastAction = norm.config.lastExport ? { action: norm.config.lastExport.action === 'install' ? 'install' : norm.config.lastExport.action === 'project' ? 'write-project' : 'export', id: norm.config.lastExport.id, at: norm.config.lastExport.at, error: norm.config.lastExport.error } : null;
      if (norm.warnings.length) toast('配置提示：' + norm.warnings[0], 'err');
    }
    const id = state.config.activeProjectId;
    state.project = projects().find((p) => p.id === id) || projects()[0] || null;
    if (state.project) state.config.activeProjectId = state.project.id;
    state.dirty = false;
    state.payloadDirty = true;
    state.focusScriptId = '';
    state.savedAt = state.connected ? fmtTime(Date.now()) : '';
    $('#banner').classList.add('hidden');
    resetHistory();
    applyMode();
  }

  function applyMode() {
    const launcher = state.connected && state.context.mode === 'launcher';
    document.body.classList.toggle('launcher-mode', launcher);
    $('#launcher').classList.toggle('hidden', !launcher);
    if (launcher) {
      renderLauncher();
      updateProjectUi();
      return;
    }
    render();
    renderCategories();
    renderPalette();
    refreshPreview();
  }

  /* ================= 启动页（面板内嵌时） ================= */

  function renderLauncher() {
    const sel = $('#open-select');
    if (!sel) return;
    const list = projects();
    sel.innerHTML = '';
    for (const p of list) {
      const o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.name + (p.pluginId ? ' · ' + p.pluginId : '');
      sel.appendChild(o);
    }
    const active = state.config.activeProjectId;
    if (active && list.some((p) => p.id === active)) sel.value = active;
    sel.disabled = !list.length;
    $('#launcher-open').disabled = !list.length;
    $('#launcher-hint').textContent = list.length
      ? '共 ' + list.length + ' 个项目。打开后在新标签页全屏编辑；列表在面板里重新打开设置页时刷新。'
      : '还没有项目，先在上面新建一个。';
    $('#launcher-stats').textContent =
      '项目 ' + list.length + ' 个 · DLL ' + dllList().length + ' 个' + (state.connected ? '' : ' · 未连接面板');
    updateProjectUi();
  }

  async function launcherCreate() {
    if (!state.connected) return toast('没有连接面板，无法保存项目', 'err');
    const nameInput = $('#new-name');
    const name = nameInput.value.trim();
    if (!name) {
      nameInput.focus();
      toast('先填项目名称', 'err');
      return;
    }
    const project = P.emptyProject({ name, pluginId: $('#new-id').value.trim() || '' });
    projects().unshift(project);
    state.project = project;
    state.config.activeProjectId = project.id;
    state.dirty = true;
    state.payloadDirty = true;
    try {
      await saveConfig({ silent: true });
    } catch (e) {
      toast('保存失败：' + e.message, 'err');
      return;
    }
    state.dirty = false;
    state.savedAt = fmtTime(Date.now());
    nameInput.value = '';
    $('#new-id').value = '';
    renderLauncher();
    openEditorTab(project.name);
  }

  async function launcherOpen() {
    if (!state.connected) return toast('没有连接面板，无法保存', 'err');
    const id = $('#open-select').value;
    const project = projects().find((p) => p.id === id);
    if (!project) return toast('先选择一个项目', 'err');
    state.project = project;
    state.config.activeProjectId = project.id;
    state.dirty = true;
    state.payloadDirty = true;
    try {
      await saveConfig({ silent: true });
    } catch (e) {
      toast('保存失败：' + e.message, 'err');
      return;
    }
    state.dirty = false;
    state.savedAt = fmtTime(Date.now());
    openEditorTab(project.name);
  }

  function openEditorTab(name) {
    let url;
    try {
      // 同一个设置页地址，去掉查询只留 mode=popup；沙箱 iframe 的 location.origin 是 "null"，用 href 作 base
      url = new URL(location.href);
      url.search = '';
      url.searchParams.set('mode', 'popup');
      url.searchParams.set('t', String(Date.now()));
    } catch (e) {
      toast('找不到面板地址：' + e.message, 'err');
      enterEditorMode();
      return;
    }
    let win = null;
    try {
      win = window.open(url.toString(), '_blank');
    } catch (e) {
      win = null;
    }
    if (win) {
      state.popupWin = win;
      state.popupReady = false;
      toast('已在新标签页打开全屏工作台' + (name ? '：' + name : ''), 'ok');
      // 被弹窗拦截时 WindowProxy 会立刻变成 closed；兜底在当前 iframe 里打开编辑器
      setTimeout(() => {
        if (win.closed) {
          toast('新标签页被浏览器拦截，已在当前页打开工作台', 'err');
          enterEditorMode();
        }
      }, 900);
      setTimeout(() => {
        if (state.popupWin === win && !state.popupReady && !win.closed) {
          toast('新标签页还没连上（可能登录失效或被拦截）；可以关掉它，用当前页编辑', 'err');
        }
      }, 4000);
      return;
    }
    toast('浏览器拦截了新窗口，已在当前页打开工作台', 'err');
    enterEditorMode();
  }

  function enterEditorMode() {
    state.context.mode = 'editor';
    document.body.classList.remove('launcher-mode');
    $('#launcher').classList.add('hidden');
    render();
    renderCategories();
    renderPalette();
    refreshPreview();
    updateProjectUi();
  }

  /* ================= 拖拽 ================= */

  function canvasPoint(clientX, clientY) {
    const rect = $('#canvas').getBoundingClientRect();
    return { x: (clientX - rect.left - state.panX) / state.zoom, y: (clientY - rect.top - state.panY) / state.zoom };
  }

  function targetUnder(clientX, clientY) {
    const hit = document.elementFromPoint(clientX, clientY);
    return hit ? hit.closest('[data-drop]') : null;
  }

  function clearDropHighlight() {
    $$('.drop-active').forEach((n) => n.classList.remove('drop-active'));
  }

  /** 某个 block 的 body/elseBody 容器 → {stackId, chain} */
  function bodyChainFor(ownerEl, kind) {
    const ownerNode = state.nodes.get(ownerEl.dataset.id);
    if (!ownerNode) return null;
    const info = containerForBlock(ownerEl);
    if (!info) return null;
    const chain = info.chain ? info.chain + '|' + ownerNode.id + '|' + kind : ownerNode.id + '|' + kind;
    return { stackId: info.stackId, chain };
  }

  /** 落点 → 应该插入到哪个语句列表的哪个位置（{list, index}）；不合法返回 null */
  function dropTargetAt(clientX, clientY) {
    const hit = document.elementFromPoint(clientX, clientY);
    if (!hit) return null;
    // 1) 落在积木之间的空隙：按空隙的下标插
    const gap = hit.closest('.gap');
    if (gap && gap.dataset.drop === 'stack') {
      const list = listFor(gap.dataset.stack, gap.dataset.chain || '');
      if (list) return { list, index: Math.min(Number(gap.dataset.index), list.length) };
    }
    const blockEl = hit.closest('.block');
    const bodyEl = hit.closest('.c-body, .c-else');
    // 2) 落在某个 body/else 的空白处：追加到这个 body 末尾
    if (bodyEl) {
      const inner = blockEl && bodyEl.contains(blockEl) && blockEl !== bodyEl.parentElement ? blockEl : null;
      if (inner) {
        const loc = locate(inner.dataset.id);
        if (loc) return { list: loc.list, index: loc.index + 1 };
      }
      const list = listFor(bodyEl.dataset.stack, bodyEl.dataset.chain || '');
      if (list) return { list, index: list.length };
    }
    // 3) 落在积木本体上：有 body 的放进它的 body 开头，否则插到它后面
    if (blockEl) {
      const node = state.nodes.get(blockEl.dataset.id);
      const d = node && defOf(node);
      if (node && d && d.body) {
        const info = bodyChainFor(blockEl, 'body');
        const list = info && listFor(info.stackId, info.chain);
        if (list) return { list, index: 0 };
      }
      const loc = locate(blockEl.dataset.id);
      if (loc) return { list: loc.list, index: loc.index + 1 };
    }
    return null;
  }

  /* ---------------- 左侧点一下就能加积木 ---------------- */

  function focusedScript() {
    const scripts = (state.project && state.project.scripts) || [];
    if (!scripts.length) return null;
    const hit = scripts.find((s) => s.id === state.focusScriptId);
    if (hit) return hit;
    const withEvent = scripts.find((s) => (s.blocks || []).some((b) => b.type === 'on_message' || b.type === 'on_load'));
    return withEvent || scripts[0];
  }

  /** 语句积木点一下加到哪里：优先当前点过的脚本里的事件/组件体 */
  function defaultStmtTarget() {
    if (!state.project) return null;
    let script = focusedScript();
    if (!script) {
      script = { id: 's' + uid(), title: '主脚本', x: 120, y: 100, blocks: [] };
      state.project.scripts = state.project.scripts || [];
      state.project.scripts.push(script);
    }
    const hats = (script.blocks || []).filter((b) => b.type === 'on_message' || b.type === 'on_load' || b.type === 'def_component');
    state.focusScriptId = script.id;
    if (!hats.length) {
      const node = makeNode('on_message', {});
      script.blocks = script.blocks || [];
      script.blocks.push(node);
      return node.body;
    }
    const hat = hats.find((b) => b.type === 'on_message') || hats[0];
    if (!Array.isArray(hat.body)) hat.body = [];
    return hat.body;
  }

  function firstEmptySlot(list) {
    for (const node of list || []) {
      const slots = node.slots || [];
      for (let i = 0; i < slots.length; i++) if (!slots[i]) return { node, index: i };
      for (const body of [node.body, node.elseBody]) {
        const hit = firstEmptySlot(body);
        if (hit) return hit;
      }
    }
    return null;
  }

  function insertFromPalette(item) {
    if (!state.project) {
      toast('先新建或载入一个项目', 'err');
      return;
    }
    if (item.type === '__new_component') {
      createComponentFlow({});
      return;
    }
    const def = defs()[item.type];
    if (!def) return;
    const node = makeNode(item.type, item.preset || {});
    if (def.shape === 'hat') {
      newEventStack(node);
      return;
    }
    if (def.shape === 'expr') {
      const script = focusedScript();
      const slot =
        firstEmptySlot(script && script.blocks) ||
        (state.project.scripts || []).reduce((acc, s) => acc || firstEmptySlot(s.blocks), null);
      if (!slot) {
        toast('表达式积木：要放进积木的虚线插槽（例如「回复」后面的框）；先放一个带插槽的积木', 'err');
        return;
      }
      slot.node.slots[slot.index] = node;
      onChangeStructural();
      toast('已放进插槽', 'ok');
      return;
    }
    const body = defaultStmtTarget();
    if (!body) {
      toast('先放一个「当收到消息」或「插件启动」事件块', 'err');
      return;
    }
    body.push(node);
    onChangeStructural();
    toast('已添加「' + (def.label || '') + '」', 'ok');
  }

  function newEventStack(node) {
    const rect = $('#canvas').getBoundingClientRect();
    const p = canvasPoint(rect.left + rect.width / 2 - 120, rect.top + 120);
    const def = defOf(node);
    state.project.scripts = state.project.scripts || [];
    state.project.scripts.push({
      id: 's' + uid(),
      title: (def && def.label) || '脚本',
      x: Math.max(20, Math.round(p.x)),
      y: Math.max(20, Math.round(p.y)),
      blocks: [node],
    });
    onChangeStructural();
    toast('已新建事件脚本', 'ok');
  }

  function handlePaletteDrop(payload, clientX, clientY) {
    if (!state.project) {
      toast('先新建或载入一个项目', 'err');
      return;
    }
    if (payload.type === '__new_component') {
      const p = canvasPoint(clientX, clientY);
      createComponentFlow({ x: Math.round(p.x), y: Math.round(p.y) });
      return;
    }
    const def = defs()[payload.type];
    if (!def) return;
    const node = makeNode(payload.type, payload.preset || {});
    const target = targetUnder(clientX, clientY);
    if (def.shape === 'expr') {
      const slotEl = target && target.dataset.drop === 'slot' ? target : null;
      if (!slotEl) {
        toast('这是表达式积木：要拖到虚线插槽里（例如「回复」后面的框、条件的框）', 'err');
        return;
      }
      const owner = slotEl.closest('.block');
      const index = Number(slotEl.closest('.slot').dataset.slotIndex);
      const ownerNode = owner ? state.nodes.get(owner.dataset.id) : null;
      if (!ownerNode) return;
      ownerNode.slots[index] = node;
      onChangeStructural();
      return;
    }
    if (def.shape === 'hat') {
      if (target || dropTargetAt(clientX, clientY)) {
        toast('事件积木（帽块）只能放在空白画布上，不能塞进别的积木里', 'err');
        return;
      }
      const p = canvasPoint(clientX, clientY);
      state.project.scripts.push({
        id: 's' + uid(),
        title: (def.label || '脚本') + (payload.preset && payload.preset.fields && payload.preset.fields.command ? '：' + payload.preset.fields.command : ''),
        x: Math.round(p.x),
        y: Math.round(p.y),
        blocks: [node],
      });
      onChangeStructural();
      return;
    }
    const dropAt = dropTargetAt(clientX, clientY);
    if (dropAt) {
      dropAt.list.splice(dropAt.index, 0, node);
      onChangeStructural();
      return;
    }
    toast('语句积木要放进事件块或组件体里（顶层只能放事件积木）', 'err');
  }

  function beginDragFromBlock(blockEl, startEvent) {
    if (!state.project) return null;
    const node = state.nodes.get(blockEl.dataset.id);
    if (!node) return null;
    const def = defOf(node);
    const rect = blockEl.getBoundingClientRect();
    const offsetX = startEvent.clientX - rect.left;
    const offsetY = startEvent.clientY - rect.top;
    const stackEl = blockEl.closest('.stack');
    const script = stackEl ? state.project.scripts.find((s) => s.id === stackEl.dataset.stack) : null;
    const isRoot = script && script.blocks.includes(node);
    const isExpr = def && def.shape === 'expr';

    const drag = { node, def, isRoot, isExpr, script, offsetX, offsetY, ghost: null, target: null, origin: null, moved: false };

    if (isRoot) {
      const startX = parseFloat(stackEl.style.left) || 0;
      const startY = parseFloat(stackEl.style.top) || 0;
      drag.move = (e) => {
        drag.moved = true;
        script.x = Math.round(startX + (e.clientX - startEvent.clientX) / state.zoom);
        script.y = Math.round(startY + (e.clientY - startEvent.clientY) / state.zoom);
        stackEl.style.left = script.x + 'px';
        stackEl.style.top = script.y + 'px';
      };
      drag.finish = () => {
        if (Math.abs(script.x - startX) + Math.abs(script.y - startY) > 2) markDirty();
      };
      return drag;
    }

    if (isExpr) {
      const slotEl = blockEl.closest('.slot');
      const ownerEl = blockEl.closest('.block');
      const ownerNode = ownerEl ? state.nodes.get(ownerEl.dataset.id) : null;
      const slotIndex = slotEl ? Number(slotEl.dataset.slotIndex) : -1;
      if (!ownerNode || slotIndex < 0) return null;
      drag.origin = { node: ownerNode, index: slotIndex };
      drag.move = (e) => {
        if (!drag.moved) {
          drag.moved = true;
          ownerNode.slots[slotIndex] = null;
          const ghost = el('div', 'drag-ghost');
          ghost.appendChild(blockEl.cloneNode(true));
          document.body.appendChild(ghost);
          drag.ghost = ghost;
          render();
        }
        drag.ghost.style.left = e.clientX - drag.offsetX + 'px';
        drag.ghost.style.top = e.clientY - drag.offsetY + 'px';
        clearDropHighlight();
        const t = targetUnder(e.clientX, e.clientY);
        if (t && t.dataset.drop === 'slot') {
          t.classList.add('drop-active');
          drag.target = t;
        } else drag.target = null;
      };
      drag.finish = () => {
        if (!drag.moved) return;
        let placed = false;
        if (drag.target) {
          const ownerEl2 = drag.target.closest('.block');
          const owner = ownerEl2 ? state.nodes.get(ownerEl2.dataset.id) : null;
          const idx = Number(drag.target.closest('.slot').dataset.slotIndex);
          if (owner) {
            owner.slots[idx] = node;
            placed = true;
          }
        }
        if (!placed) {
          if (drag.origin) drag.origin.node.slots[drag.origin.index] = node;
          toast('没放对位置，已放回原插槽');
        }
        cleanupGhost(drag);
        onChangeStructural();
      };
      return drag;
    }

    const parent = blockEl.parentElement;
    const siblings = $$(':scope > .block', parent);
    const indexInDom = siblings.indexOf(blockEl);
    const loc = locate(node.id);
    if (!loc) return null;
    const moved = loc.list.splice(loc.index);
    const ghost = el('div', 'drag-ghost');
    for (const elm of siblings.slice(indexInDom)) ghost.appendChild(elm.cloneNode(true));
    drag.originList = loc.list;
    drag.originIndex = loc.index;
    drag.movedNodes = moved;

    const ghostFor = (e) => {
      if (!drag.moved) {
        drag.moved = true;
        document.body.appendChild(ghost);
        drag.ghost = ghost;
        render();
      }
      drag.ghost.style.left = e.clientX - drag.offsetX + 'px';
      drag.ghost.style.top = e.clientY - drag.offsetY + 'px';
    };

    drag.move = (e) => {
      ghostFor(e);
      clearDropHighlight();
      const t = targetUnder(e.clientX, e.clientY);
      if (t) t.classList.add('drop-active');
      drag.target = dropTargetAt(e.clientX, e.clientY);
    };
    drag.finish = (e) => {
      if (!drag.moved) return;
      let placed = false;
      const at = drag.target || (e ? dropTargetAt(e.clientX, e.clientY) : null);
      const isSelf = at && drag.movedNodes.some((n) => at.list === n.body || at.list === n.elseBody);
      if (at && !isSelf) {
        at.list.splice(Math.min(at.index, at.list.length), 0, ...drag.movedNodes);
        placed = true;
      }
      if (!placed) {
        drag.originList.splice(drag.originIndex, 0, ...drag.movedNodes);
        toast('没放对位置，已放回原处');
      }
      cleanupGhost(drag);
      onChangeStructural();
    };
    return drag;
  }

  function cleanupGhost(drag) {
    clearDropHighlight();
    if (drag.ghost && drag.ghost.parentElement) drag.ghost.parentElement.removeChild(drag.ghost);
    drag.ghost = null;
  }

  function bindCanvasDrag() {
    const canvas = $('#canvas');
    let pending = null;

    const capture = (pointerId) => {
      try {
        canvas.setPointerCapture(pointerId);
      } catch {
        /* 某些浏览器/合成事件下会抛 NotFoundError，靠 window 兜底结束拖拽 */
      }
    };

    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      // 画布上的按钮/输入框/欢迎卡片：不要启动平移捕获，否则 click 会被 canvas 吞掉
      if (e.target.closest('input,select,textarea,button,a,label,.fld,#welcome')) return;
      // 上一次拖拽如果有残留 ghost（指针在窗口外松开），先清掉，避免越积越多
      $$('.drag-ghost').forEach((n) => n.remove());
      const stackEl = e.target.closest('.stack');
      if (stackEl) state.focusScriptId = stackEl.dataset.stack;
      const line = e.target.closest('.block-line');
      if (line) {
        const drag = beginDragFromBlock(line.closest('.block'), e);
        if (drag) {
          pending = { drag, x: e.clientX, y: e.clientY, pointerId: e.pointerId };
          e.preventDefault();
          capture(e.pointerId);
          return;
        }
      }
      pending = { pan: true, x: e.clientX, y: e.clientY, panX: state.panX, panY: state.panY, pointerId: e.pointerId };
      canvas.classList.add('panning');
      capture(e.pointerId);
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!pending) return;
      if (pending.pan) {
        state.panX = pending.panX + (e.clientX - pending.x);
        state.panY = pending.panY + (e.clientY - pending.y);
        updateHud();
        return;
      }
      const drag = pending.drag;
      if (!drag.moved && Math.abs(e.clientX - pending.x) + Math.abs(e.clientY - pending.y) < 5) return;
      drag.move(e);
    });

    const end = (e) => {
      if (!pending) return;
      if (pending.pan) {
        canvas.classList.remove('panning');
      } else if (pending.drag) {
        // 指针移出窗口/丢失捕获时也要收尾，否则被拖的积木会凭空消失
        if (pending.drag.moved) pending.drag.finish(e);
        else cleanupGhost(pending.drag);
      }
      pending = null;
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    // 兜底：拖拽过程中指针离开画布（或捕获失效）时，window 上的 pointerup 也能结束拖拽
    window.addEventListener('pointerup', (e) => {
      if (pending && !pending.pan) end(e);
    });
    window.addEventListener('pointercancel', (e) => {
      if (pending && !pending.pan) end(e);
    });
    // 切走窗口/失焦时 pointerup 可能永远不来：把积木放回原处，避免丢块
    window.addEventListener('blur', () => {
      if (!pending || pending.pan || !pending.drag || !pending.drag.moved) return;
      const d = pending.drag;
      if (d.originList) d.originList.splice(d.originIndex, 0, ...d.movedNodes);
      else if (d.origin) d.origin.node.slots[d.origin.index] = d.node;
      cleanupGhost(d);
      pending = null;
      onChangeStructural();
      toast('拖拽被中断，积木已放回原处');
    });

    canvas.addEventListener('wheel', (e) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        zoomAt(e.clientX, e.clientY, e.deltaY > 0 ? -0.1 : 0.1);
      } else {
        state.panX -= e.deltaX;
        state.panY -= e.deltaY;
        updateHud();
        e.preventDefault();
      }
    }, { passive: false });

    canvas.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      clearDropHighlight();
      const t = targetUnder(e.clientX, e.clientY);
      if (t) t.classList.add('drop-active');
    });
    canvas.addEventListener('dragleave', clearDropHighlight);
    canvas.addEventListener('drop', (e) => {
      e.preventDefault();
      clearDropHighlight();
      let payload = null;
      try {
        payload = JSON.parse(e.dataTransfer.getData('application/x-bbsp') || 'null');
      } catch {
        payload = null;
      }
      if (payload && payload.type) handlePaletteDrop(payload, e.clientX, e.clientY);
    });
  }

  function zoomAt(clientX, clientY, delta) {
    const rect = $('#canvas').getBoundingClientRect();
    const px = clientX - rect.left;
    const py = clientY - rect.top;
    const beforeX = (px - state.panX) / state.zoom;
    const beforeY = (py - state.panY) / state.zoom;
    state.zoom = Math.round(Math.min(2, Math.max(0.35, state.zoom + delta)) * 100) / 100;
    state.panX = px - beforeX * state.zoom;
    state.panY = py - beforeY * state.zoom;
    updateHud();
  }

  /* ================= 弹窗 ================= */

  function closeModal() {
    const root = $('#modal-root');
    if (root.lastElementChild) root.removeChild(root.lastElementChild);
  }

  function openModal(title, builder, opts = {}) {
    const root = $('#modal-root');
    const mask = el('div', 'modal-mask');
    const modal = el('div', 'modal' + (opts.size ? ' ' + opts.size : ''));
    const head = el('div', 'modal-head');
    head.appendChild(el('div', 'modal-title', title));
    const closeBtn = el('button', 'btn sm ghost', '关闭');
    closeBtn.addEventListener('click', closeModal);
    head.appendChild(closeBtn);
    const body = el('div', 'modal-body');
    const foot = el('div', 'modal-foot');
    modal.appendChild(head);
    modal.appendChild(body);
    modal.appendChild(foot);
    mask.appendChild(modal);
    mask.addEventListener('click', (e) => {
      if (e.target === mask) closeModal();
    });
    root.appendChild(mask);
    const api = {
      body,
      foot,
      close: closeModal,
      button(label, cls, fn) {
        const b = el('button', 'btn ' + (cls || ''), label);
        b.addEventListener('click', () => fn(b));
        foot.appendChild(b);
        return b;
      },
    };
    builder(api);
    return api;
  }

  /* ================= 项目 ================= */

  async function saveNowOrThrow() {
    if (!state.connected) return false;
    if (!state.dirty && !state.config.pending) return true;
    await saveConfig({ silent: true });
    return true;
  }

  function setActiveProject(id) {
    const p = projects().find((x) => x.id === id) || null;
    state.project = p;
    state.config.activeProjectId = p ? p.id : '';
    state.focusScriptId = '';
    resetHistory();
    render();
    renderCategories();
    renderPalette();
    refreshPreview();
  }

  async function createProject(opts = {}) {
    try {
      if (state.connected && state.dirty) await saveConfig({ silent: true });
    } catch (e) {
      toast('先保存当前项目失败：' + e.message, 'err');
      return null;
    }
    const project = P.emptyProject({ name: opts.name || '未命名项目', pluginId: opts.pluginId || '', description: opts.description || '' });
    projects().unshift(project);
    setActiveProject(project.id);
    markDirty();
    if (state.connected) {
      try {
        await saveConfig({ silent: true });
        toast('已新建项目「' + project.name + '」并保存', 'ok');
      } catch (e) {
        toast('项目已在内存里新建，但保存失败：' + e.message, 'err');
      }
    }
    return project;
  }

  async function deleteProject(id) {
    const p = projects().find((x) => x.id === id);
    if (!p) return;
    const ok = await askConfirm('删除项目', '删除项目「' + p.name + '」？不可恢复。', '删除');
    if (!ok) return;
    state.config.projects = projects().filter((x) => x.id !== id);
    if (state.project && state.project.id === id) {
      if (projects()[0]) setActiveProject(projects()[0].id);
      else {
        state.project = null;
        state.config.activeProjectId = '';
        render();
        renderPalette();
      }
    }
    markDirty();
    if (state.connected) {
      try {
        await saveConfig({ silent: true });
      } catch (e) {
        toast('删除已在内存生效，但保存失败：' + e.message, 'err');
      }
    }
  }

  function openProjectsModal() {
    openModal('项目', (m) => {
      const list = el('div', 'list');
      const wrap = el('div', 'field');
      wrap.appendChild(el('label', '', '我的项目（保存在插件配置里）'));
      wrap.appendChild(list);
      m.body.appendChild(wrap);

      const renderList = () => {
        list.innerHTML = '';
        if (!projects().length) {
          list.appendChild(el('div', 'empty-state', '还没有项目，先在下面新建一个。'));
          return;
        }
        for (const p of projects()) {
          const item = el('div', 'list-item');
          const grow = el('div', 'grow');
          grow.appendChild(el('div', 'title', p.name + (state.project && state.project.id === p.id ? '  ✓' : '')));
          const stats = P.stats(p);
          grow.appendChild(el('div', 'sub', [p.pluginId, '积木 ' + stats.blocks, '组件 ' + stats.components, '更新 ' + new Date(p.updatedAt || Date.now()).toLocaleString('zh-CN')].join(' · ')));
          item.appendChild(grow);
          const open = el('button', 'btn sm primary', '打开');
          open.addEventListener('click', async () => {
            try {
              if (state.connected && state.dirty) await saveConfig({ silent: true });
            } catch {
              /* ignore */
            }
            setActiveProject(p.id);
            closeModal();
          });
          item.appendChild(open);
          const dup = el('button', 'btn sm', '复制');
          dup.addEventListener('click', async () => {
            const copy = clone(p);
            copy.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
            copy.name = p.name + ' 副本';
            copy.pluginId = (p.pluginId || 'plugin') + '-copy';
            copy.updatedAt = nowIso();
            projects().push(copy);
            markDirty();
            try {
              await saveConfig({ silent: true });
              renderList();
            } catch (e) {
              toast('保存失败：' + e.message, 'err');
            }
          });
          item.appendChild(dup);
          const exp = el('button', 'btn sm', '导出文件');
          exp.addEventListener('click', async () => {
            state.config.pending = { action: 'write-project', at: Date.now(), project: clone(p) };
            try {
              await saveConfig({ silent: true });
              toast('已提交导出：BBSP 会把 .bbsp 写到 data/exports/projects/', 'ok');
            } catch (e) {
              state.config.pending = null;
              toast('导出失败：' + e.message, 'err');
            }
          });
          item.appendChild(exp);
          const del = el('button', 'btn sm danger', '删除');
          del.addEventListener('click', () => deleteProject(p.id).then(renderList));
          item.appendChild(del);
          list.appendChild(item);
        }
      };
      renderList();

      const newBox = el('div', 'field');
      newBox.appendChild(el('label', '', '新建项目'));
      const row = el('div', 'row');
      const nameField = el('div', 'field');
      nameField.appendChild(el('label', '', '项目名称'));
      const nameInput = el('input', 'input');
      nameInput.placeholder = '例如：天气查询';
      nameField.appendChild(nameInput);
      const idField = el('div', 'field');
      idField.appendChild(el('label', '', '插件 ID（导出后就是框架插件 ID）'));
      const idInput = el('input', 'input');
      idInput.placeholder = '留空自动生成';
      idField.appendChild(idInput);
      row.appendChild(nameField);
      row.appendChild(idField);
      newBox.appendChild(row);
      const descField = el('div', 'field');
      descField.appendChild(el('label', '', '介绍（可空）'));
      const descInput = el('input', 'input');
      descField.appendChild(descInput);
      newBox.appendChild(descField);
      m.body.appendChild(newBox);

      const fileField = el('div', 'field');
      fileField.appendChild(el('label', '', '导入 .bbsp 项目文件'));
      const file = el('input', 'input');
      file.type = 'file';
      file.accept = '.bbsp,application/json';
      file.style.padding = '4px';
      file.addEventListener('change', async () => {
        const f = file.files && file.files[0];
        if (!f) return;
        try {
          const raw = JSON.parse(await f.text());
          if (raw && raw.format && raw.format !== P.FORMAT) throw new Error('不是 BBSP 项目文件（format=' + raw.format + '）');
          const { project } = P.normalize(raw, { dllLib: dllLib() });
          if (projects().some((x) => x.id === project.id)) project.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
          project.updatedAt = nowIso();
          projects().unshift(project);
          setActiveProject(project.id);
          markDirty();
          await saveConfig({ silent: true });
          closeModal();
          toast('已导入项目「' + project.name + '」', 'ok');
        } catch (e) {
          toast('导入失败：' + e.message, 'err');
        }
      });
      fileField.appendChild(file);
      m.body.appendChild(fileField);

      m.button('新建项目', 'primary', async () => {
        const name = nameInput.value.trim();
        if (!name) {
          nameInput.focus();
          toast('先填项目名称', 'err');
          return;
        }
        const p = await createProject({ name, pluginId: idInput.value.trim(), description: descInput.value.trim() });
        if (p) {
          closeModal();
          toast('已新建项目「' + p.name + '」', 'ok');
        }
      });
    }, { size: 'lg' });
  }

  /* ================= 变量 ================= */

  function openVarsModal() {
    if (!state.project) return toast('先打开一个项目', 'err');
    openModal('变量', (m) => {
      m.body.appendChild(
        el('p', 'help', '这里是全局变量：所有事件块和组件共用一份，值存在插件内部的 STATE 里（重启框架后回到初始值，除非在「插件启动」里重新设置）。'),
      );
      m.body.appendChild(el('p', 'help', '组件里想用「只在那次调用里有效」的变量，就在组件上填参数 —— 那些是局部变量，和这里的全局变量互不影响。'));
      const list = el('div', 'list');
      const rows = () => {
        list.innerHTML = '';
        const vars = state.project.vars || [];
        if (!vars.length) list.appendChild(el('div', 'empty-state', '还没有变量，点下面「添加变量」。'));
        vars.forEach((v, i) => {
          const item = el('div', 'list-item');
          const nameInput = el('input', 'input');
          nameInput.value = v.name;
          nameInput.style.maxWidth = '170px';
          nameInput.addEventListener('change', () => {
            if (!nameInput.value.trim()) return;
            v.name = nameInput.value.trim();
            markDirty();
          });
          const valueInput = el('input', 'input');
          valueInput.value = v.value === undefined ? '' : String(v.value);
          valueInput.style.maxWidth = '150px';
          valueInput.addEventListener('change', () => {
            const n = Number(valueInput.value);
            v.value = valueInput.value !== '' && Number.isFinite(n) && String(n) === valueInput.value.trim() ? n : valueInput.value;
            markDirty();
          });
          const del = el('button', 'btn sm danger', '删除');
          del.addEventListener('click', () => {
            state.project.vars.splice(i, 1);
            markDirty();
            rows();
          });
          item.appendChild(el('span', 'muted', '变量'));
          item.appendChild(nameInput);
          item.appendChild(el('span', 'muted', '初始值'));
          item.appendChild(valueInput);
          item.appendChild(del);
          list.appendChild(item);
        });
      };
      rows();
      m.body.appendChild(list);
      m.button('添加变量', '', () => {
        state.project.vars = state.project.vars || [];
        state.project.vars.push({ name: 'var' + (state.project.vars.length + 1), value: '' });
        markDirty();
        rows();
      });
      m.button('保存变量', 'primary', async () => {
        try {
          await saveConfig({ silent: true });
          closeModal();
          render();
          renderPalette();
          toast('变量已保存', 'ok');
        } catch (e) {
          toast('保存失败：' + e.message, 'err');
        }
      });
    }, { size: 'sm' });
  }

  /* ================= 组件 ================= */

  function promptNewComponent() {
    return new Promise((resolve) => {
      openModal('新建组件', (m) => {
        m.body.appendChild(el('p', 'help', '组件 = 自己造的积木：建好后左侧「组件」分类里会出现它，可以拖进任何事件里调用。'));
        m.body.appendChild(
          el('p', 'help', '「参数」在组件内部是局部变量（每次调用各有一份）；项目「变量」面板里建的是全局变量（所有事件、组件共用）。'),
        );

        const nameField = el('div', 'field');
        nameField.appendChild(el('label', '', '组件名称'));
        const nameInput = el('input', 'input');
        nameInput.value = '组件' + (components().length + 1);
        nameField.appendChild(nameInput);
        m.body.appendChild(nameField);

        const paramField = el('div', 'field');
        paramField.appendChild(el('label', '', '局部参数（逗号分隔，可留空）'));
        const paramInput = el('input', 'input');
        paramInput.placeholder = '例如：名字, 次数';
        paramField.appendChild(paramInput);
        m.body.appendChild(paramField);

        const retField = el('div', 'field');
        retField.appendChild(el('label', '', '返回类型'));
        const retSel = document.createElement('select');
        retSel.className = 'select';
        for (const t of [
          { v: 'text_ansi', l: '文本' },
          { v: 'int', l: '整数' },
          { v: 'double', l: '小数' },
          { v: 'bool', l: '逻辑' },
          { v: 'void', l: '无返回' },
        ]) {
          const o = document.createElement('option');
          o.value = t.v;
          o.textContent = t.l;
          retSel.appendChild(o);
        }
        retSel.value = 'text_ansi';
        retField.appendChild(retSel);
        m.body.appendChild(retField);

        const submit = () => {
          const name = nameInput.value.trim();
          if (!name) {
            toast('先填组件名称', 'err');
            nameInput.focus();
            return;
          }
          if (components().some((c) => c.name === name)) {
            toast('已经有同名组件了', 'err');
            nameInput.focus();
            return;
          }
          const params = paramInput.value
            .split(/[,，\s]+/)
            .map((s) => s.trim())
            .filter(Boolean)
            .map((n) => ({ name: n, type: 'any' }));
          closeModal();
          resolve({ name, params, returns: retSel.value });
        };
        nameInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') submit();
        });
        m.button('取消', '', () => {
          closeModal();
          resolve(null);
        });
        m.button('创建', 'primary', submit);
        setTimeout(() => {
          nameInput.focus();
          nameInput.select();
        }, 60);
      }, { size: 'sm' });
    });
  }

  async function createComponentFlow(opts = {}) {
    if (!state.project) {
      toast('先新建或打开一个项目', 'err');
      return;
    }
    const form = await promptNewComponent();
    if (!form) return;
    const id = 'c' + Date.now().toString(36).slice(-6);
    state.project.components = components().concat([{ id, name: form.name, params: form.params, returns: form.returns }]);
    const index = (state.project.scripts || []).length;
    const x = Number.isFinite(opts.x) ? opts.x : 140 + (index % 5) * 44;
    const y = Number.isFinite(opts.y) ? opts.y : 120 + (index % 5) * 44;
    const script = {
      id: 's' + uid(),
      title: '组件：' + form.name,
      x: Math.max(20, Math.round(x)),
      y: Math.max(20, Math.round(y)),
      blocks: [{ id: uid(), type: 'def_component', fields: { comp: id }, slots: [], body: [] }],
    };
    state.project.scripts = state.project.scripts || [];
    state.project.scripts.push(script);
    state.focusScriptId = script.id;
    onChangeStructural();
    toast('已新建组件「' + form.name + '」：画布上已放好「定义组件」块，往它里面加积木就是组件逻辑', 'ok');
  }

  function openComponentsModal() {
    if (!state.project) return toast('先打开一个项目', 'err');
    openModal('我的组件', (m) => {
      m.body.appendChild(el('p', 'help', '组件就是自己造积木：建好后左侧「组件」分类里会出现它，可以拖到任何事件里调用。'));
      const list = el('div', 'list');
      const renderRows = () => {
        list.innerHTML = '';
        const comps = components();
        if (!comps.length) list.appendChild(el('div', 'empty-state', '还没有组件。'));
        comps.forEach((c) => {
          const item = el('div', 'list-item');
          const nameInput = el('input', 'input');
          nameInput.value = c.name;
          nameInput.style.maxWidth = '140px';
          nameInput.addEventListener('change', () => {
            c.name = nameInput.value.trim() || c.name;
            markDirty();
          });
          const paramsInput = el('input', 'input');
          paramsInput.placeholder = '参数，逗号分隔';
          paramsInput.value = (c.params || []).map((p) => p.name).join(',');
          paramsInput.style.maxWidth = '200px';
          paramsInput.addEventListener('change', () => {
            c.params = paramsInput.value
              .split(/[,，]/)
              .map((s) => s.trim())
              .filter(Boolean)
              .map((name) => ({ name, type: 'any' }));
            markDirty();
          });
          const retSelect = document.createElement('select');
          retSelect.className = 'select';
          retSelect.style.maxWidth = '110px';
          for (const t of [
            { v: 'text_ansi', l: '文本' },
            { v: 'int', l: '整数' },
            { v: 'double', l: '小数' },
            { v: 'bool', l: '逻辑' },
            { v: 'void', l: '无返回' },
          ]) {
            const o = document.createElement('option');
            o.value = t.v;
            o.textContent = t.l;
            retSelect.appendChild(o);
          }
          retSelect.value = c.returns || 'text_ansi';
          retSelect.addEventListener('change', () => {
            c.returns = retSelect.value;
            markDirty();
          });
          const del = el('button', 'btn sm danger', '删除');
          del.addEventListener('click', () => {
            state.project.components = components().filter((x) => x !== c);
            state.project.scripts = state.project.scripts.filter((s) => !s.blocks.some((b) => b.type === 'def_component' && b.fields.comp === c.id));
            markDirty();
            renderRows();
          });
          item.appendChild(nameInput);
          item.appendChild(paramsInput);
          item.appendChild(retSelect);
          item.appendChild(del);
          list.appendChild(item);
        });
      };
      renderRows();
      m.body.appendChild(list);
      m.button('新建组件', '', () => {
        const id = 'c' + Date.now().toString(36).slice(-5);
        state.project.components = components().concat([{ id, name: '组件' + (components().length + 1), params: [], returns: 'text_ansi' }]);
        state.project.scripts.push({
          id: 's' + id,
          title: '组件：新组件',
          x: 480 + components().length * 30,
          y: 100 + components().length * 20,
          blocks: [{ id: uid(), type: 'def_component', fields: { comp: id }, slots: [], body: [] }],
        });
        markDirty();
        renderRows();
      });
      m.button('保存组件', 'primary', async () => {
        try {
          await saveConfig({ silent: true });
          closeModal();
          render();
          renderPalette();
          toast('组件已保存', 'ok');
        } catch (e) {
          toast('保存失败：' + e.message, 'err');
        }
      });
    }, { size: 'lg' });
  }

  /* ================= DLL ================= */

  function openDllModal() {
    openModal('第三方 DLL', (m) => {
      m.body.appendChild(
        el('p', 'help', '导入 DLL 会自动读出导出函数；给每个函数填好「函数名 / 返回类型 / 参数 / 调用约定」，保存后它们就像组件一样出现在左侧「DLL」分类里。'),
      );
      m.body.appendChild(el('p', 'help', 'DLL 二进制会随保存上传到插件（base64），插件落盘到 data/dlls/ 后自动从配置里删掉；不需要本机端口，远端面板也能导入。'));

      const fileField = el('div', 'field');
      fileField.appendChild(el('label', '', '导入 DLL（.dll，支持易语言 32 位 DLL 与其它 32/64 位 DLL，≤9MB）'));
      const file = el('input', 'input');
      file.type = 'file';
      file.accept = '.dll';
      file.style.padding = '4px';
      file.addEventListener('change', async () => {
        const f = file.files && file.files[0];
        if (!f) return;
        file.value = '';
        try {
          if (f.size > 9 * 1024 * 1024) throw new Error('DLL 超过 9MB，配置里放不下');
          const bytes = new Uint8Array(await f.arrayBuffer());
          const parsed = PE.parseExports(bytes);
          if (parsed.kind === 'exe') throw new Error('这是 EXE，不是 DLL');
          const base = String(f.name || 'dll').replace(/\.dll$/i, '').replace(/[^\w\u4e00-\u9fa5-]+/g, '_').slice(0, 30) || 'dll';
          const entry = {
            id: 'dll_' + base + '_' + hashHex(bytes).slice(0, 6),
            name: f.name,
            alias: base,
            arch: parsed.arch,
            kind: parsed.kind,
            size: bytes.length,
            importedAt: nowIso(),
            note: parsed.arch === 'x86' ? '32 位（x86 宿主，易语言 DLL 一般是这种）' : '64 位（x64 宿主）',
            exports: parsed.exports.map((e) => ({
              name: e.name,
              clean: e.clean,
              ordinal: e.ordinal,
              ret: 'int',
              params: [],
              conv: parsed.arch === 'x86' ? 'stdcall' : 'cdecl',
              enabled: true,
            })),
            base64: toBase64(bytes),
          };
          state.config.dlls = dllList().filter((d) => d.id !== entry.id).concat(entry);
          markDirty();
          renderPalette();
          closeModal();
          toast('正在保存 DLL（' + parsed.exports.length + ' 个函数）…');
          await saveConfig({ silent: true });
          toast('DLL 已导入：函数已加入左侧「DLL」分类', 'ok');
          openDllModal();
        } catch (e) {
          toast('导入失败：' + e.message, 'err');
        }
      });
      fileField.appendChild(file);
      m.body.appendChild(fileField);

      const list = el('div', 'list');
      m.body.appendChild(list);

      const renderDlls = () => {
        list.innerHTML = '';
        if (!dllList().length) {
          list.appendChild(el('div', 'empty-state', '还没有导入 DLL。导入后这里会出现函数表。'));
          return;
        }
        for (const dll of dllList()) {
          const card = el('div', 'list-item');
          card.style.flexDirection = 'column';
          card.style.alignItems = 'stretch';
          const head = el('div', 'pill-row');
          const aliasInput = el('input', 'input');
          aliasInput.value = dll.alias || dll.name;
          aliasInput.style.maxWidth = '160px';
          aliasInput.title = '组件别名（左侧分类里显示）';
          aliasInput.addEventListener('change', () => {
            dll.alias = aliasInput.value.trim() || dll.alias;
            markDirty();
          });
          head.appendChild(aliasInput);
          head.appendChild(el('span', 'badge ' + (dll.arch === 'x86' ? 'x86' : 'x64'), dll.arch === 'x86' ? '32 位' : '64 位'));
          head.appendChild(el('span', 'badge', (dll.exports || []).filter((e) => e.enabled !== false).length + ' 个函数'));
          head.appendChild(el('span', 'muted', dll.name));
          const spacer = el('span', '');
          spacer.style.flex = '1';
          head.appendChild(spacer);
          const saveBtn = el('button', 'btn sm primary', '保存这个 DLL');
          saveBtn.addEventListener('click', async () => {
            try {
              await saveConfig({ silent: true });
              closeModal();
              renderPalette();
              toast('DLL 已保存', 'ok');
            } catch (e) {
              toast('保存失败：' + e.message, 'err');
            }
          });
          head.appendChild(saveBtn);
          const del = el('button', 'btn sm danger', '删除');
          del.addEventListener('click', async () => {
            const ok = await askConfirm('删除 DLL', '删除 DLL「' + (dll.alias || dll.name) + '」？函数积木也会一起消失。', '删除');
            if (!ok) return;
            state.config.dlls = dllList().filter((d) => d.id !== dll.id);
            markDirty();
            try {
              await saveConfig({ silent: true });
              renderPalette();
              closeModal();
              openDllModal();
              toast('已删除 DLL', 'ok');
            } catch (e) {
              toast('保存失败：' + e.message, 'err');
            }
          });
          head.appendChild(del);
          card.appendChild(head);

          const table = document.createElement('table');
          table.className = 'tbl';
          table.innerHTML = '<thead><tr><th style="width:24px">启用</th><th>函数名（可改）</th><th style="width:150px">返回类型</th><th style="width:170px">参数（逗号分隔）</th><th style="width:90px">调用约定</th></tr></thead>';
          const tbody = document.createElement('tbody');
          for (const ex of dll.exports || []) {
            const tr = document.createElement('tr');
            const tdOn = document.createElement('td');
            const chk = document.createElement('input');
            chk.type = 'checkbox';
            chk.checked = ex.enabled !== false;
            chk.addEventListener('change', () => {
              ex.enabled = chk.checked;
              markDirty();
            });
            tdOn.appendChild(chk);
            tr.appendChild(tdOn);

            const tdName = document.createElement('td');
            tdName.className = 'fn';
            const nameWrap = el('div', 'pill-row');
            const nameInput = el('input');
            nameInput.value = ex.clean || ex.name;
            nameInput.title = '调用时用的函数名（BBSP 会自动兼容 _Fn@N 修饰名）';
            nameInput.style.width = '190px';
            nameInput.addEventListener('change', () => {
              ex.clean = nameInput.value.trim() || ex.name;
              markDirty();
            });
            nameWrap.appendChild(nameInput);
            if (ex.ordinal) nameWrap.appendChild(el('span', 'muted', '#' + ex.ordinal));
            if (ex.name && ex.clean && ex.name !== ex.clean) nameWrap.appendChild(el('span', 'muted', '原名 ' + ex.name));
            tdName.appendChild(nameWrap);
            tr.appendChild(tdName);

            const tdRet = document.createElement('td');
            const retSel = document.createElement('select');
            for (const t of RET_OPTIONS) {
              const o = document.createElement('option');
              o.value = t.value;
              o.textContent = t.label;
              retSel.appendChild(o);
            }
            retSel.value = ex.ret || 'int';
            retSel.addEventListener('change', () => {
              ex.ret = retSel.value;
              markDirty();
            });
            tdRet.appendChild(retSel);
            tr.appendChild(tdRet);

            const tdParams = document.createElement('td');
            const paramInput = el('input');
            paramInput.value = (ex.params || []).join(',');
            paramInput.placeholder = 'int,text_ansi';
            paramInput.style.width = '100%';
            paramInput.addEventListener('change', () => {
              ex.params = paramInput.value.split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean);
              markDirty();
            });
            tdParams.appendChild(paramInput);
            tr.appendChild(tdParams);

            const tdConv = document.createElement('td');
            const convSel = document.createElement('select');
            for (const c of ['stdcall', 'cdecl']) {
              const o = document.createElement('option');
              o.value = c;
              o.textContent = c;
              convSel.appendChild(o);
            }
            convSel.value = ex.conv || (dll.arch === 'x86' ? 'stdcall' : 'cdecl');
            convSel.addEventListener('change', () => {
              ex.conv = convSel.value;
              markDirty();
            });
            tdConv.appendChild(convSel);
            tr.appendChild(tdConv);
            tbody.appendChild(tr);
          }
          table.appendChild(tbody);
          card.appendChild(table);

          const tools = el('div', 'pill-row');
          tools.style.marginTop = '7px';
          const addFn = el('button', 'btn sm', '＋ 手动添加函数');
          addFn.title = '导出表读不到、或想给函数起别名时用';
          addFn.addEventListener('click', () => {
            dll.exports = dll.exports || [];
            dll.exports.push({
              name: 'NewFunction',
              clean: 'NewFunction',
              ordinal: 0,
              ret: 'int',
              params: [],
              conv: dll.arch === 'x86' ? 'stdcall' : 'cdecl',
              enabled: true,
              manual: true,
            });
            markDirty();
            renderDlls();
          });
          tools.appendChild(addFn);
          tools.appendChild(el('span', 'muted', 'DLL 调用的实际执行在 BBSP 插件里；装好后在 QQ 触发一次看面板日志验证。'));
          card.appendChild(tools);
          list.appendChild(card);
        }
      };
      renderDlls();

      if (state.lastAction && state.lastAction.id) {
        const last = el('div', 'help');
        last.textContent = '上次' + (state.lastAction.action === 'install' ? '安装' : state.lastAction.action === 'write-project' ? '导出项目' : '导出') + '：' + state.lastAction.id + (state.lastAction.at ? ' · ' + new Date(state.lastAction.at).toLocaleString('zh-CN') : '') + (state.lastAction.error ? '（失败：' + state.lastAction.error + '）' : '');
        m.body.appendChild(last);
      }
    }, { size: 'lg' });
  }

  /* ================= 源码 / 导出 ================= */

  function renderDrawer(preview) {
    $('#drawer-code').textContent = (preview && preview.code) || '（还没有可生成的代码）';
    const warns = (preview && preview.warnings) || [];
    const warn = $('#drawer-warn');
    warn.classList.toggle('hidden', !warns.length);
    warn.textContent = warns.length ? '提示：\n· ' + warns.join('\n· ') : '';
    const man = (preview && preview.manifest) || {};
    $('#drawer-title').textContent = '生成的 JS 插件 · ' + (man.id || '?') + ' · ' + ((man.events || []).length) + ' 个事件';
  }

  function openCodeDrawer() {
    if (!state.project) return toast('先打开一个项目', 'err');
    state.preview = buildPreview(state.project);
    renderDrawer(state.preview);
    $('#drawer').classList.remove('hidden');
  }

  async function requestExport(action, overwrite) {
    if (!state.project) return toast('先打开一个项目', 'err');
    const gen = buildPreview(state.project);
    if (gen.warnings && gen.warnings.length) {
      const fine = await askConfirm('生成提示', '生成时有提示：\n· ' + gen.warnings.join('\n· ') + '\n\n仍要继续吗？', '继续');
      if (!fine) return;
    }
    state.config.pending = {
      action,
      at: Date.now(),
      overwrite: !!overwrite,
      package: {
        id: gen.manifest.id,
        code: gen.code,
        manifest: gen.manifest,
        readme: gen.readme,
        overwrite: !!overwrite,
      },
    };
    try {
      await saveConfig({ silent: true });
      const id = gen.manifest.id;
      const note = action === 'install'
        ? '已提交安装：BBSP 会把插件写到 ~JlWBoT/plugins/' + id + '/，然后去面板点「重新加载」'
        : '已提交导出：文件写到 data/exports/' + id + '/（index.js + plugin.json + README.md）';
      showExportResult(action, id, note, gen);
    } catch (e) {
      state.config.pending = null;
      toast('导出失败：' + e.message, 'err');
    }
  }

  function showExportResult(action, id, note, gen) {
    openModal(action === 'install' ? '安装到框架' : '导出到服务器', (m) => {
      m.body.appendChild(el('p', 'help', note));
      const paths = el('pre', 'code');
      paths.textContent = action === 'install'
        ? ['数据目录：~JlWBoT/plugins/' + id + '/', '导出副本：DATA/exports/' + id + '/', '', '下一步：面板 → 插件 → 顶部「重新加载」，新插件才出现在列表里。'].join('\n')
        : ['导出目录：DATA/exports/' + id + '/', '文件：index.js、plugin.json、README.md', '', '想直接进框架：用「导出 JS 插件」里的「一键安装到框架」。'].join('\n');
      m.body.appendChild(paths);
      const actions = el('div', 'pill-row');
      actions.style.marginTop = '8px';
      const copy = el('button', 'btn sm', '复制 index.js 源码');
      copy.addEventListener('click', async () => {
        const ok = await copyText(gen.code);
        toast(ok ? '源码已复制' : '复制失败，请到「源码」抽屉里手动选择复制', ok ? 'ok' : 'err');
      });
      actions.appendChild(copy);
      const view = el('button', 'btn sm', '查看完整源码');
      view.addEventListener('click', () => {
        closeModal();
        openCodeDrawer();
      });
      actions.appendChild(view);
      m.body.appendChild(actions);
      m.button('知道了', 'primary', closeModal);
    }, { size: '' });
  }

  function openExportModal() {
    if (!state.project) return toast('先打开一个项目', 'err');
    openModal('导出为 JS 插件', (m) => {
      m.body.appendChild(
        el('p', 'help', '导出格式 = 本框架的「JS 插件」：index.js + plugin.json + README.md。文件由 BBSP 插件写到服务器磁盘（面板在内网/外网都行），不需要下载。'),
      );
      const row = el('div', 'row');
      const mk = (label, value, placeholder) => {
        const f = el('div', 'field');
        f.appendChild(el('label', '', label));
        const i = el('input', 'input');
        i.value = value || '';
        i.placeholder = placeholder || '';
        f.appendChild(i);
        row.appendChild(f);
        return i;
      };
      const idInput = mk('插件 ID', state.project.pluginId, '英文/数字/下划线');
      const nameInput = mk('插件名称', state.project.name);
      const verInput = mk('版本', state.project.version || '1.0.0');
      m.body.appendChild(row);

      const summary = el('div', 'field');
      summary.appendChild(el('label', '', '生成摘要'));
      const info = el('pre', 'code');
      info.style.maxHeight = '190px';
      summary.appendChild(info);
      m.body.appendChild(summary);

      const out = el('div', 'warnbox hidden');
      m.body.appendChild(out);

      const applyFields = () => {
        state.project.pluginId = CFG.sanitizeId(idInput.value.trim() || state.project.pluginId, 'bbsp-plugin');
        state.project.name = nameInput.value.trim() || state.project.name;
        state.project.version = verInput.value.trim() || '1.0.0';
        markDirty();
      };
      const refresh = () => {
        applyFields();
        const gen = buildPreview(state.project);
        const man = gen.manifest || {};
        info.textContent = [
          '插件 ID     ' + man.id,
          '事件        ' + (man.events || []).join(', '),
          '命令        ' + ((man.commands || []).length ? man.commands.join(', ') : '（所有消息）'),
          '超时        ' + man.timeout + 'ms',
          '积木        ' + ((gen.stats && gen.stats.blocks) || 0) + ' 块 · 组件 ' + ((gen.stats && gen.stats.components) || 0) + ' 个 · DLL 调用 ' + ((gen.stats && gen.stats.dllCalls) || 0) + ' 处',
          '',
          ((gen.warnings || []).length ? '⚠ ' + gen.warnings.join('\n⚠ ') : '没有需要处理的提示'),
        ].join('\n');
        out.classList.toggle('hidden', !(gen.warnings || []).length);
        out.textContent = (gen.warnings || []).join('\n');
      };
      [idInput, nameInput, verInput].forEach((i) => i.addEventListener('change', refresh));
      refresh();

      const overwrite = document.createElement('input');
      overwrite.type = 'checkbox';
      const owWrap = el('label', 'pill-row');
      owWrap.style.marginTop = '6px';
      owWrap.appendChild(overwrite);
      owWrap.appendChild(el('span', '', '覆盖安装（框架里已有同名插件时先备份旧目录）'));
      m.body.appendChild(owWrap);

      m.button('导出文件到服务器', '', async () => {
        refresh();
        m.close();
        await requestExport('export', false);
      });
      m.button('复制源码', '', async () => {
        refresh();
        const gen = buildPreview(state.project);
        const ok = await copyText(gen.code);
        toast(ok ? '源码已复制' : '复制失败，请打开「源码」抽屉手动复制', ok ? 'ok' : 'err');
      });
      m.button('一键安装到框架', 'primary', async () => {
        refresh();
        m.close();
        await requestExport('install', !!overwrite.checked);
      });
    }, { size: '' });
  }

  function openCodeEditor(node, field) {
    openModal('编辑代码：' + (field.label || ''), (m) => {
      const ta = el('textarea', 'textarea');
      ta.style.minHeight = '200px';
      ta.value = String(node.fields[field.name] || '');
      m.body.appendChild(ta);
      m.body.appendChild(el('p', 'help', '「执行 JS」会原样插入生成的插件里（可以写 await）；「原样代码」是一个 JS 表达式。'));
      m.button('确定', 'primary', () => {
        node.fields[field.name] = ta.value;
        closeModal();
        onChangeStructural();
      });
    }, { size: 'sm' });
  }

  /* ================= 顶栏 / 初始化 ================= */

  function bindToolbar() {
    $('#btn-projects').addEventListener('click', openProjectsModal);
    $('#btn-vars').addEventListener('click', openVarsModal);
    $('#btn-comps').addEventListener('click', openComponentsModal);
    $('#btn-dlls').addEventListener('click', openDllModal);
    $('#btn-code').addEventListener('click', openCodeDrawer);
    $('#btn-save').addEventListener('click', onClickSave);
    $('#btn-undo').addEventListener('click', undo);
    $('#btn-redo').addEventListener('click', redo);
    $('#btn-export').addEventListener('click', openExportModal);
    $('#launcher-create').addEventListener('click', launcherCreate);
    $('#launcher-open').addEventListener('click', launcherOpen);
    $('#new-name').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') launcherCreate();
    });
    $('#open-select').addEventListener('dblclick', launcherOpen);
    $('#welcome-new').addEventListener('click', () => createProject({ name: '我的积木插件' }).then((p) => p && toast('已新建项目「' + p.name + '」', 'ok')));
    $('#welcome-import').addEventListener('click', openProjectsModal);
    $('#search').addEventListener('input', (e) => {
      state.search = e.target.value;
      renderPalette();
    });
    $('#zoom-in').addEventListener('click', () => zoomAt($('#canvas').getBoundingClientRect().left + 200, 300, 0.1));
    $('#zoom-out').addEventListener('click', () => zoomAt($('#canvas').getBoundingClientRect().left + 200, 300, -0.1));
    $('#zoom-reset').addEventListener('click', () => {
      state.zoom = 1;
      state.panX = 24;
      state.panY = 18;
      updateHud();
    });
    $('#drawer-close').addEventListener('click', () => $('#drawer').classList.add('hidden'));
    $('#drawer-copy').addEventListener('click', async () => {
      const ok = await copyText(($('#drawer-code').textContent || '').trim());
      toast(ok ? '源码已复制' : '复制失败，请手动全选复制', ok ? 'ok' : 'err');
    });

    document.addEventListener('keydown', (e) => {
      const meta = e.ctrlKey || e.metaKey;
      const key = String(e.key || '').toLowerCase();
      if (meta && key === 's') {
        e.preventDefault();
        onClickSave();
        return;
      }
      if (meta && key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
      }
      if (meta && (key === 'y' || (key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
        return;
      }
      if (e.key === 'Escape' && $('#modal-root').lastElementChild) closeModal();
    });

    window.addEventListener('beforeunload', (e) => {
      if (!state.dirty) return;
      e.preventDefault();
      e.returnValue = '';
    });
  }

  async function handlePopupRequest(e, msg) {
    if (!state.popupWin || e.source !== state.popupWin) return;
    if (msg.type === 'bbsp-popup-hello') {
      try {
        e.source.postMessage({ type: 'bbsp-popup-config', config: buildPayload() }, '*');
      } catch {
        /* ignore */
      }
      return;
    }
    let ok = true;
    let error = '';
    try {
      // 采纳弹窗的配置，再走面板保存通道
      const norm = CFG.normalizeConfig(msg.config);
      state.config = norm.config;
      state.project = projects().find((p) => p.id === state.config.activeProjectId) || projects()[0] || null;
      if (state.project) state.config.activeProjectId = state.project.id;
      state.dirty = true;
      state.payloadDirty = true;
      await saveConfig({ silent: true });
      renderLauncher();
    } catch (err) {
      ok = false;
      error = err.message;
    }
    try {
      e.source.postMessage({ type: 'bbsp-popup-saved', id: msg.id, ok, error }, '*');
    } catch {
      /* ignore */
    }
  }

  function onMessage(e) {
    const msg = e.data || {};
    if (!msg || typeof msg !== 'object') return;
    if (state.context.mode === 'popup') {
      if (msg.type === 'bbsp-popup-config') {
        onPopupConfigMessage(msg);
        return;
      }
      if (msg.type === 'bbsp-popup-saved') {
        onPopupSavedMessage(msg);
        return;
      }
    }
    if (state.context.mode === 'launcher' && (msg.type === 'bbsp-popup-hello' || msg.type === 'bbsp-popup-save')) {
      handlePopupRequest(e, msg);
      return;
    }
    if (msg.type === 'jlw-settings-init') {
      state.connected = true;
      onSettingsInit(msg);
      return;
    }
    if (msg.type === 'jlw-settings-saved') {
      onSettingsSaved(msg);
      return;
    }
    if (msg.type === 'jlw-settings-save-request') {
      // 面板底部「保存设置」按钮
      saveConfig({ silent: false }).catch(() => {});
      return;
    }
    if (msg.type === 'jlw-settings-pong') return;
  }

  function bootLocal() {
    // 直接打开 /api/plugins/BBSP/settings 时没有面板父页：可以编辑预览，但不能保存
    state.localOnly = true;
    state.connected = false;
    state.context.mode = 'editor';
    document.body.classList.remove('launcher-mode');
    $('#launcher').classList.add('hidden');
    $('#banner').classList.remove('hidden');
    $('#banner').className = 'banner err';
    $('#banner').textContent = '未连接面板（直接打开了设置页）：可以编辑预览，但保存不可用。请从面板「插件 → BBSP → 编辑 → 设置」或卡片设置页的「新页面」进入。';
    render();
    renderCategories();
    renderPalette();
    refreshPreview();
  }

  function init() {
    state.context = detectContext();
    window.addEventListener('resize', () => {
      state.context = detectContext();
      updateProjectUi();
    });
    window.addEventListener('message', onMessage);
    bindToolbar();
    bindCanvasDrag();
    if (state.context.mode === 'launcher') {
      document.body.classList.add('launcher-mode');
      $('#launcher').classList.remove('hidden');
      renderLauncher();
      updateProjectUi();
    } else if (state.context.mode === 'popup') {
      document.body.classList.remove('launcher-mode');
      $('#launcher').classList.add('hidden');
      $('#banner').classList.remove('hidden');
      $('#banner').className = 'banner';
      $('#banner').textContent = '正在从面板读取项目…（保存通道：面板里的 BBSP 设置页）';
      popupHello();
      // 面板设置页（保存通道）被关掉时给出明确提示，而不是等保存超时
      setInterval(() => {
        let closed = true;
        try {
          closed = !window.opener || window.opener.closed;
        } catch {
          closed = !window.opener;
        }
        if (closed && state.popupReady) {
          state.popupReady = false;
          state.connected = false;
          state.localOnly = true;
          $('#banner').classList.remove('hidden');
          $('#banner').className = 'banner err';
          $('#banner').textContent = '保存通道已断：面板里的 BBSP 设置页被关闭了。可以继续编辑/复制源码，但保存要回到面板重新打开设置页。';
          updateProjectUi();
        }
      }, 3000);
      setTimeout(() => {
        if (!state.popupReady) {
          state.localOnly = true;
          $('#banner').className = 'banner err';
          $('#banner').textContent = '没有收到面板数据（启动页可能已关闭或登录失效）。当前页面只读；请回到面板里的 BBSP 设置页重新打开。';
          renderCategories();
          renderPalette();
          render();
          updateProjectUi();
        }
      }, 2500);
    } else {
      renderCategories();
      renderPalette();
      render();
    }
    // 父页会在 iframe load 后立刻发 init；1.2 秒还没等到就当直接打开处理
    setTimeout(() => {
      if (state.context.mode !== 'popup' && !state.connected && !state.localOnly) bootLocal();
    }, 1200);
  }

  window.addEventListener('DOMContentLoaded', init);
})();
