'use strict';
/**
 * 插件回复闸门：只拦截统一前缀的报错，其余放行
 *   node test/reply-guard-test.js
 */
const Bot = require('../src/core/bot');
const ReplyGuard = require('../src/core/reply-guard');

const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}

function guardWith(cfg) {
  const logs = [];
  const logger = { warn: (m, meta) => logs.push({ m, meta }), info() {}, error() {}, debug() {} };
  const config = { get: (k, d) => (k === 'plugins.replyGuard' ? cfg : d) };
  return { g: new ReplyGuard({ config, logger, accountId: 'a1' }), logs };
}

(async () => {
  /* ---------------- 前缀规则 ---------------- */
  {
    const { g, logs } = guardWith({ enabled: true });
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '【[404 error] 出错了：Cannot read keys】' }).ok === false, '统一前缀的报错被拦截');
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '欢迎新成员加入！' }).ok === true, '欢迎语放行');
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '欢迎新成员加入！' }).ok === true, '相同内容重复也放行（不再去重）');
    const rapid = [];
    for (let i = 0; i < 5; i++) rapid.push(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '第 ' + i + ' 条正常回复' }).ok);
    check(rapid.every(Boolean), '连续多条正常回复全部放行（不再限频）');
    check(logs.some((l) => /报错文案已拦截/.test(l.m)), '拦截会写日志');
    check(ReplyGuard.errorText('出错了：x').startsWith('【[404 error]'), 'errorText 生成统一前缀', ReplyGuard.errorText('x'));
  }
  {
    const { g } = guardWith({ enabled: false });
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '【[404 error] x】' }).ok === true, '关闭闸门后不拦');
  }
  {
    const { g } = guardWith({ enabled: true, blockErrors: false });
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '【[404 error] x】' }).ok === true, 'blockErrors=false 时不拦');
  }
  {
    const { g } = guardWith({ enabled: true, errorPrefix: '【[ERR]' });
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '【[ERR] boom】' }).ok === false, '自定义前缀生效');
    check(g.check({ pluginId: 'p', kind: 'group', target: 'G', text: '【[404 error] x】' }).ok === true, '旧前缀不再拦截');
  }

  /* ---------------- Bot 集成 ---------------- */
  {
    const logs = [];
    const bot = Object.create(Bot.prototype);
    bot.account = { id: 'a1', name: '测试', appId: '123456' };
    bot.log = { warn: (m, meta) => logs.push({ m, meta }), info() {}, error() {}, debug() {} };
    bot.replyGuard = new ReplyGuard({ config: { get: () => ({ enabled: true }) }, logger: bot.log, accountId: 'a1' });
    bot._outgoingText = (c) => (c && c.markdown ? c.markdown.content : String(c?.content || ''));
    let sent = 0;
    bot.reply = async () => {
      sent++;
      return { ok: true, data: { id: 'M' } };
    };
    bot.replyEvent = async () => {
      sent++;
      return { ok: true };
    };
    const evt = { message: null, raw: { group_openid: 'G' } };
    const res = await bot.applyPluginOutput({ id: 'p1' }, evt, {
      replies: [
        { type: 'text', content: '欢迎 A 加入' },
        { type: 'text', content: '欢迎 A 加入' },
        { type: 'text', content: '【[404 error] 出错了：Cannot read keys】' },
        { type: 'text', content: '欢迎 B 加入' },
      ],
      actions: [],
    });
    check(sent === 3, '3 条正常回复都发出，报错被拦', 'sent=' + sent);
    check(res.results.some((r) => r.code === 'REPLY_GUARD'), '被拦的回复标记 REPLY_GUARD', JSON.stringify(res.results));
    check(logs.some((l) => /报错文案已拦截/.test(l.m)), 'Bot 集成层写拦截日志');
  }
  {
    const bot = Object.create(Bot.prototype);
    bot.account = { id: 'a1', name: '测试', appId: '1' };
    bot.log = { warn() {}, info() {}, error() {}, debug() {} };
    bot.replyGuard = new ReplyGuard({ config: { get: () => ({ enabled: true }) }, logger: bot.log, accountId: 'a1' });
    bot._outgoingText = (c) => (c && c.markdown ? c.markdown.content : String(c?.content || ''));
    let sent = 0;
    bot.sendGroup = async () => {
      sent++;
      return { ok: true };
    };
    const api = bot.pluginApi({ id: 'p2' });
    const r1 = await api.sendGroup('G', { content: '正常主动消息 1' });
    const r2 = await api.sendGroup('G', { content: '正常主动消息 2' });
    const err = await api.sendGroup('G', { content: ReplyGuard.errorText('出错了：x') });
    check(r1.ok === true && r2.ok === true, '插件 API 的正常发送不受限', JSON.stringify([r1.ok, r2.ok]));
    check(err.ok === false && err.code === 'REPLY_GUARD', '插件 API 的报错文案被拦截');
    check(sent === 2, '只发出 2 条正常消息', 'sent=' + sent);
  }
  {
    const bot = Object.create(Bot.prototype);
    bot.account = { id: 'a1', name: '测试', appId: '1' };
    bot.log = { warn() {}, info() {}, error() {}, debug() {} };
    bot.replyGuard = new ReplyGuard({ config: { get: () => ({ enabled: true }) }, logger: bot.log, accountId: 'a1' });
    bot._outgoingText = (c) => (c && c.markdown ? c.markdown.content : String(c?.content || ''));
    let sent = 0;
    bot.sendGroup = async () => {
      sent++;
      return { ok: true };
    };
    const r = await bot.executeAction({ id: 'p3' }, { message: null, raw: { group_openid: 'G' } }, {
      action: 'send_group_message',
      content: ReplyGuard.errorText('TypeError: boom'),
    });
    check(r.ok === false && r.code === 'REPLY_GUARD', '动作 send_group_message 拦截报错', JSON.stringify(r));
    check(sent === 0, '动作没有真的发出');
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
