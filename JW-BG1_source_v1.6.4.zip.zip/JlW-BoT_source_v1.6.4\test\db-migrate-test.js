'use strict';
/**
 * SQLite 迁移：旧 config.json / sessions.json / logs / messages 导入一次，
 * 旧文件移到 ~JlWBoT/backup/legacy-json-*，第二次启动不重复导入。
 * 运行：node test/db-migrate-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const out = [];
const check = (ok, msg) => {
  out.push({ ok, msg });
  console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
};

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-dbmig-'));
const day = '2026-11-20';
fs.mkdirSync(path.join(dir, 'logs'), { recursive: true });
fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify({ server: { port: 9999 }, marker: 'from-json' }), 'utf8');
fs.writeFileSync(
  path.join(dir, 'data', 'sessions.json'),
  JSON.stringify({ s1: { sid: 's1', user: { email: 'a@b.c' }, createdAt: Date.now(), expiresAt: Date.now() + 86400000 } }),
  'utf8',
);
fs.writeFileSync(
  path.join(dir, 'logs', `jlwbot-${day}.jsonl`),
  [
    { t: Date.parse(`${day}T10:00:00+08:00`), level: 'info', msg: '日志二' },
    { t: Date.parse(`${day}T10:01:00+08:00`), level: 'error', msg: '日志三' },
  ]
    .map((x) => JSON.stringify(x))
    .join('\n'),
  'utf8',
);
fs.writeFileSync(
  path.join(dir, 'logs', `jlwbot-${day}-1795.jsonl`),
  JSON.stringify({ t: Date.parse(`${day}T09:59:00+08:00`), level: 'debug', msg: '日志一' }),
  'utf8',
);
fs.writeFileSync(
  path.join(dir, 'data', `messages-${day}.jsonl`),
  [
    { t: Date.parse(`${day}T11:00:00+08:00`), event: 'GROUP_MESSAGE_CREATE', accountId: 'a1', accountName: '一号', kind: 'group', id: 'm1', content: '历史消息', group_openid: 'g1', payload: { msg_type: 2, markdown: { content: '**历史消息**' } } },
  ]
    .map((x) => JSON.stringify(x))
    .join('\n'),
  'utf8',
);

const script = `
const db = require(${JSON.stringify(path.join(ROOT, 'src', 'core', 'db'))});
db.getDb();
db.insertLog({ t: Date.parse('2020-01-01T00:00:00Z'), level: 'info', msg: '很老的日志' });
const oldBefore = db.logsByDay('2020-01-01', { limit: 5 }).length;
db.pruneLogs(7);
const oldAfter = db.logsByDay('2020-01-01', { limit: 5 }).length;
console.log(JSON.stringify({
  cfg: db.kvGet('config'),
  sessions: db.sessionLoadAll().length,
  dates: db.logDates(),
  logs: db.logsByDay('${day}', { limit: 10 }).map((l) => l.msg),
  msgs: db.messagesByDay('${day}', { limit: 10 }).map((m) => ({ content: m.content, payload: m.payload })),
  oldBefore,
  oldAfter,
}));
db.close();
`;

function runOnce() {
  const r = spawnSync(process.execPath, ['-e', script], {
    env: { ...process.env, JLW_DATA_DIR: dir },
    encoding: 'utf8',
  });
  if (r.status !== 0) throw new Error(r.stderr || 'child failed');
  const line = r.stdout.trim().split('\n').pop();
  return JSON.parse(line);
}

try {
  const a = runOnce();
  check(a.cfg && a.cfg.marker === 'from-json', '旧 config.json 已导入 SQLite');
  check(a.sessions === 1, '旧 sessions.json 已导入 SQLite');
  check((a.logs || []).length === 3 && a.logs[0] === '日志一' && a.logs[2] === '日志三', '旧日志合并分片并按时间排序');
  check((a.msgs || []).length === 1 && a.msgs[0]?.content === '历史消息', '旧消息已导入 SQLite');
  check(a.msgs?.[0]?.payload?.markdown?.content === '**历史消息**', '旧消息的 payload 一并导入 SQLite');
  check((a.dates || []).some((d) => d.date === day && d.count === 3), '日志日期统计正确');

  const moved = fs.existsSync(path.join(dir, 'backup'));
  const legacyLeft = fs.existsSync(path.join(dir, 'logs', `jlwbot-${day}.jsonl`));
  check(moved && !legacyLeft, '旧 JSONL 已移到 backup/legacy-json-*');

  const b = runOnce();
  check((b.logs || []).length === 3 && b.sessions === 1, '第二次启动不重复导入');
  check(b.oldBefore === 1 && b.oldAfter === 0, '按保留天数清理过期日志');
} finally {
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
}

const failed = out.filter((x) => !x.ok);
console.log(`\n${out.length - failed.length}/${out.length} 通过`);
process.exit(failed.length ? 1 : 0);
