'use strict';
/**
 * 在线更新：从聚龙世界 QQBOT 下载页读取最新版本。
 *
 * 页面结构（2026-11）：
 *   <div class="yz-dl-name">JlW-BoT [v1.3.2].zip</div>
 *   <a class="yz-btn yz-btn-sm yz-dl-btn" href="/download/xxxx">下载</a>
 *
 * 也兼容页面加入以下 meta 的以后版本：
 *   <meta name="jlwbot-version" content="1.3.2">
 *   <meta name="jlwbot-download" content="/download/xxxx">
 *   <meta name="jlwbot-sha256" content="...">
 *   <meta name="jlwbot-notes" content="更新说明">
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { spawn } = require('child_process');
const U = require('./util');

const VERSION = require('../../package.json').version;
const DEFAULT_PAGE = 'https://www.jlworld.net/QQBOT';
const MAX_PAGE_BYTES = 2 * 1024 * 1024;
const MAX_ZIP_BYTES = 320 * 1024 * 1024;
const CACHE_MS = 10 * 60 * 1000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function decodeEntities(s) {
  return String(s || '')
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'");
}

function stripTags(s) {
  return decodeEntities(String(s || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
}

function parseVersion(input) {
  const m = String(input || '').match(/v?(\d+)\.(\d+)\.(\d+)(?:-([0-9a-z.-]+))?/i);
  if (!m) return null;
  return {
    text: `${Number(m[1])}.${Number(m[2])}.${Number(m[3])}${m[4] ? '-' + m[4] : ''}`,
    parts: [Number(m[1]), Number(m[2]), Number(m[3])],
    pre: m[4] || '',
  };
}

function compareVersions(a, b) {
  const x = parseVersion(a);
  const y = parseVersion(b);
  if (!x && !y) return 0;
  if (!x) return -1;
  if (!y) return 1;
  for (let i = 0; i < 3; i++) {
    if (x.parts[i] !== y.parts[i]) return x.parts[i] > y.parts[i] ? 1 : -1;
  }
  if (x.pre && !y.pre) return -1;
  if (!x.pre && y.pre) return 1;
  if (x.pre === y.pre) return 0;
  return x.pre.localeCompare(y.pre, 'en', { numeric: true }) > 0 ? 1 : -1;
}

function isLoopback(host) {
  const h = String(host || '').toLowerCase().replace(/^\[|\]$/g, '');
  return h === '127.0.0.1' || h === 'localhost' || h === '::1' || h === '0.0.0.0';
}

function isAllowedDownload(urlStr, pageUrl) {
  let u;
  let p;
  try {
    u = new URL(urlStr);
    p = new URL(pageUrl);
  } catch {
    return false;
  }
  if (!/^https?:$/.test(u.protocol)) return false;
  if (u.protocol === 'http:' && p.protocol === 'https:') return false;
  const host = u.hostname.toLowerCase();
  if (host === p.hostname.toLowerCase()) return true;
  if (/(^|\.)jlworld\.net$/i.test(host)) return true;
  if (isLoopback(host) && isLoopback(p.hostname)) return true;
  return false;
}

function metaMap(html) {
  const out = {};
  for (const m of String(html).matchAll(/<meta\b[^>]*>/gi)) {
    const tag = m[0];
    const name = tag.match(/\bname\s*=\s*["']([^"']+)["']/i);
    const content = tag.match(/\bcontent\s*=\s*["']([^"']*)["']/i);
    if (name && content) out[name[1].toLowerCase()] = decodeEntities(content[1]).trim();
  }
  return out;
}

/** 解析更新页，返回 { latest, url, fileName, sizeText, notes, sha256 } */
function parseUpdatePage(html, pageUrl = DEFAULT_PAGE) {
  const text = String(html || '');
  const metas = metaMap(text);
  const cards = [];

  const nameRe = /class=["'][^"']*\byz-dl-name\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/gi;
  for (const m of text.matchAll(nameRe)) {
    const fileName = stripTags(m[1]);
    if (!/JlW-?BoT/i.test(fileName)) continue;
    const windowText = text.slice(m.index, m.index + 5000);
    let href = '';
    const a1 = windowText.match(/<a\b[^>]*\bclass=["'][^"']*\byz-dl-btn\b[^"']*["'][^>]*\bhref=["']([^"']+)["']/i);
    const a2 = windowText.match(/<a\b[^>]*\bhref=["']([^"']+)["'][^>]*\bclass=["'][^"']*\byz-dl-btn\b[^"']*["']/i);
    if (a1) href = a1[1];
    else if (a2) href = a2[1];
    if (!href) continue;
    const meta = windowText.match(/class=["'][^"']*\byz-dl-meta\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
    const sizeRaw = meta ? stripTags(meta[1]) : '';
    const sizeMatch = sizeRaw.match(/([\d.]+\s*(?:KB|MB|GB|B))/i);
    const version = parseVersion(fileName) || parseVersion(stripTags(m[1]));
    cards.push({
      fileName,
      href: decodeEntities(href),
      sizeText: sizeMatch ? sizeMatch[1] : sizeRaw,
      version: version ? version.text : '',
    });
  }

  // 未来页面可以直接给 meta，不依赖下载卡片
  if (!cards.length && metas['jlwbot-download']) {
    const version = parseVersion(metas['jlwbot-version'] || '') || parseVersion(metas['jlwbot-download'] || '');
    cards.push({
      fileName: metas['jlwbot-filename'] || (version ? `JlW-BoT [v${version.text}].zip` : 'JlW-BoT.zip'),
      href: metas['jlwbot-download'],
      sizeText: metas['jlwbot-size'] || '',
      version: version ? version.text : '',
    });
  }

  const usable = cards.filter((c) => c.version);
  if (!usable.length) throw new Error('更新页里没有找到 JlW-BoT 版本号');
  usable.sort((a, b) => compareVersions(b.version, a.version));
  const best = usable[0];
  const url = new URL(best.href, pageUrl).toString();
  return {
    latest: best.version,
    url,
    fileName: best.fileName,
    sizeText: metas['jlwbot-size'] || best.sizeText || '',
    notes: metas['jlwbot-notes'] || '',
    sha256: String(metas['jlwbot-sha256'] || '').toLowerCase(),
  };
}

function requestStream(urlStr, { timeout = 20000, headers = {}, redirects = 5 } = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (fn, v) => {
      if (settled) return;
      settled = true;
      fn(v);
    };
    let u;
    try {
      u = new URL(urlStr);
    } catch {
      return done(reject, new Error('不正确的更新地址：' + urlStr));
    }
    if (!/^https?:$/.test(u.protocol)) return done(reject, new Error('更新地址必须是 http/https'));
    const mod = u.protocol === 'http:' ? http : https;
    const req = mod.request(
      u,
      {
        method: 'GET',
        timeout,
        headers: {
          'User-Agent': `JlWBoT/${VERSION} (+${DEFAULT_PAGE})`,
          Accept: '*/*',
          ...headers,
        },
      },
      (res) => {
        const code = res.statusCode || 0;
        if ([301, 302, 303, 307, 308].includes(code) && res.headers.location) {
          res.resume();
          if (!redirects) return done(reject, new Error('更新地址重定向次数过多'));
          const next = new URL(res.headers.location, u).toString();
          return requestStream(next, { timeout, headers, redirects: redirects - 1 }).then(
            (r) => done(resolve, r),
            (e) => done(reject, e),
          );
        }
        done(resolve, { res, url: u.toString() });
      },
    );
    req.on('timeout', () => req.destroy(new Error('连接更新页超时')));
    req.on('error', (e) => done(reject, e));
    req.end();
  });
}

async function fetchText(url, { timeout = 20000 } = {}) {
  const { res } = await requestStream(url, { timeout, headers: { Accept: 'text/html,application/json;q=0.9,*/*;q=0.8' } });
  if (res.statusCode !== 200) {
    res.resume();
    throw new Error('更新页返回 HTTP ' + res.statusCode);
  }
  let size = 0;
  const chunks = [];
  for await (const chunk of res) {
    size += chunk.length;
    if (size > MAX_PAGE_BYTES) {
      res.destroy();
      throw new Error('更新页内容过大');
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

class Updater {
  constructor({ config, logger, pageUrl } = {}) {
    this.config = config;
    this.logger = logger;
    this.log = logger ? logger.child('update') : null;
    this.pageUrl = String(pageUrl || process.env.JLW_UPDATE_PAGE || config?.get('update.pageUrl', DEFAULT_PAGE) || DEFAULT_PAGE).trim();
    this.cache = null;
    this.cacheAt = 0;
  }

  enabled() {
    return this.config ? this.config.get('update.enabled', true) !== false : true;
  }

  async check(force = false) {
    if (!this.enabled()) {
      return { ok: true, enabled: false, current: VERSION, latest: VERSION, hasUpdate: false, pageUrl: this.pageUrl };
    }
    if (!force && this.cache && Date.now() - this.cacheAt < CACHE_MS) return this.cache;
    try {
      let html;
      try {
        html = await fetchText(this.pageUrl);
      } catch {
        await sleep(700);
        html = await fetchText(this.pageUrl);
      }
      const info = parseUpdatePage(html, this.pageUrl);
      const out = {
        ok: true,
        enabled: true,
        current: VERSION,
        latest: info.latest,
        hasUpdate: compareVersions(info.latest, VERSION) > 0,
        url: info.url,
        fileName: info.fileName,
        sizeText: info.sizeText,
        notes: info.notes,
        sha256: info.sha256,
        pageUrl: this.pageUrl,
        checkedAt: Date.now(),
      };
      this.cache = out;
      this.cacheAt = Date.now();
      if (this.log) this.log.info(`检查更新：当前 v${VERSION}，页面最新 v${info.latest}`, { hasUpdate: out.hasUpdate });
      return out;
    } catch (e) {
      if (this.log) this.log.warn('检查更新失败：' + e.message);
      return {
        ok: false,
        enabled: true,
        current: VERSION,
        latest: '',
        hasUpdate: false,
        pageUrl: this.pageUrl,
        error: e.message,
        checkedAt: Date.now(),
      };
    }
  }

  _filename(info) {
    let name = path.basename(String(info.fileName || '').replace(/\\/g, '/'));
    if (!/\.zip$/i.test(name)) name = `JlW-BoT [v${info.latest}].zip`;
    name = name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/^\.+/, '');
    return name || `JlW-BoT [v${info.latest}].zip`;
  }

  async download(info, onProgress = () => {}) {
    if (!info || !info.url) throw new Error('没有可下载的更新地址');
    if (!isAllowedDownload(info.url, this.pageUrl)) throw new Error('更新地址不在聚龙世界域名下，已拒绝下载');
    const dir = U.p('updates');
    fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, this._filename(info));
    const part = dest + '.part';
    try {
      fs.rmSync(part, { force: true });
    } catch {
      /* ignore */
    }

    const { res, url } = await requestStream(info.url, {
      timeout: 120000,
      headers: { Accept: 'application/zip,application/octet-stream,*/*' },
    });
    if (res.statusCode !== 200) {
      res.resume();
      throw new Error('下载更新包失败：HTTP ' + res.statusCode);
    }
    const total = Number(res.headers['content-length']) || 0;
    if (total > MAX_ZIP_BYTES) {
      res.destroy();
      throw new Error('更新包超过 320MB，已拒绝');
    }
    let received = 0;
    let lastEmit = 0;
    const hash = crypto.createHash('sha256');
    const out = fs.createWriteStream(part);
    const done = new Promise((resolve, reject) => {
      res.on('data', (chunk) => {
        received += chunk.length;
        if (received > MAX_ZIP_BYTES) {
          res.destroy(new Error('更新包超过 320MB，已拒绝'));
          return;
        }
        hash.update(chunk);
        const now = Date.now();
        if (now - lastEmit > 250) {
          lastEmit = now;
          onProgress({ received, total, percent: total ? Math.min(99, Math.round((received / total) * 100)) : 0 });
        }
      });
      res.on('error', reject);
      out.on('error', reject);
      out.on('finish', resolve);
      res.pipe(out);
    });
    try {
      await done;
    } catch (e) {
      try {
        out.destroy();
      } catch {
        /* ignore */
      }
      try {
        fs.rmSync(part, { force: true });
      } catch {
        /* ignore */
      }
      throw new Error('下载更新包失败：' + e.message);
    }
    const sha256 = hash.digest('hex');
    if (info.sha256 && sha256 !== info.sha256) {
      fs.rmSync(part, { force: true });
      throw new Error('更新包 SHA256 校验失败');
    }
    const fd = fs.openSync(part, 'r');
    const magic = Buffer.alloc(4);
    try {
      fs.readSync(fd, magic, 0, 4, 0);
    } finally {
      fs.closeSync(fd);
    }
    if (magic[0] !== 0x50 || magic[1] !== 0x4b) {
      fs.rmSync(part, { force: true });
      throw new Error('下载到的不是 zip 更新包');
    }
    fs.renameSync(part, dest);
    onProgress({ received, total: total || received, percent: 100 });
    if (this.log) this.log.info(`更新包下载完成：${path.basename(dest)}`, { bytes: received, url });
    return { file: dest, bytes: received, sha256 };
  }

  /** 启动独立更新器；它等当前进程退出后解压覆盖，再启动新版本 */
  spawnApply(info, zipFile) {
    const dir = U.p('updates');
    fs.mkdirSync(dir, { recursive: true });
    const script = path.join(dir, 'apply-update.js');
    fs.copyFileSync(path.join(__dirname, 'update-apply.js'), script);

    let nodeExe = process.execPath;
    if (process.platform === 'win32') {
      const copy = path.join(dir, 'update-node.exe');
      try {
        fs.rmSync(copy, { force: true });
      } catch {
        /* ignore */
      }
      fs.copyFileSync(process.execPath, copy);
      nodeExe = copy;
    }

    const args = process.argv.slice(2).filter((a) => a !== '--no-open');
    // --data-dir 传相对路径时改成绝对路径，重启后工作目录仍是项目根
    for (let i = 0; i < args.length; i++) {
      if ((args[i] === '--data-dir' || args[i] === '-d') && args[i + 1] && !path.isAbsolute(args[i + 1])) {
        args[i + 1] = path.resolve(process.cwd(), args[i + 1]);
      }
    }
    args.push('--no-open');
    const argsB64 = Buffer.from(JSON.stringify(args), 'utf8').toString('base64');
    const readyFile = path.join(dir, 'apply-ready.json');
    try {
      fs.rmSync(readyFile, { force: true });
    } catch {
      /* ignore */
    }
    const child = spawn(
      nodeExe,
      [
        script,
        '--pid',
        String(process.pid),
        '--zip',
        zipFile,
        '--root',
        U.ROOT,
        '--node',
        nodeExe,
        '--version',
        info.latest,
        '--args-b64',
        argsB64,
        '--log',
        path.join(dir, 'update.log'),
        '--ready',
        readyFile,
      ],
      { cwd: U.ROOT, detached: true, stdio: 'ignore', windowsHide: true },
    );
    if (!child.pid) throw new Error('无法启动更新器');
    child.unref();
    if (this.log) this.log.info('更新器已启动，等待当前进程退出后安装', { pid: child.pid, version: info.latest });
    return { pid: child.pid, script, readyFile };
  }
}

module.exports = Updater;
module.exports.VERSION = VERSION;
module.exports.DEFAULT_PAGE = DEFAULT_PAGE;
module.exports.parseUpdatePage = parseUpdatePage;
module.exports.compareVersions = compareVersions;
module.exports.parseVersion = parseVersion;
module.exports.isAllowedDownload = isAllowedDownload;
