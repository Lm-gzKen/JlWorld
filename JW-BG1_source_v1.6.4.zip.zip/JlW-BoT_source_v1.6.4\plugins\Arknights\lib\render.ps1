param(
  [Parameter(Mandatory = $true)][string]$In,
  [Parameter(Mandatory = $true)][string]$Out
)
# ---------------------------------------------------------------------------
# JlWBoT Arknights card renderer.
# ASCII-only source on purpose: text content arrives through a UTF-8 JSON file,
# so this script never depends on the .ps1 file encoding (works on PS 5.1).
#   powershell -NoProfile -ExecutionPolicy Bypass -File render.ps1 -In spec.json -Out card.png
# Item types: rect / text / image / line
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$errFile = $Out + '.err'
trap {
  $msg = 'render error'
  try { $msg = [string]$_.Exception.Message + ' @ line ' + [string]$_.InvocationInfo.ScriptLineNumber } catch { }
  try { [System.IO.File]::WriteAllText($errFile, $msg, [System.Text.Encoding]::UTF8) } catch { }
  Write-Host ('render-error: ' + $msg)
  exit 1
}
if (Test-Path -LiteralPath $errFile) { Remove-Item -LiteralPath $errFile -Force }

function ConvertTo-Color([string]$spec, [int]$alphaDefault = 255) {
  if ([string]::IsNullOrWhiteSpace($spec)) { return [System.Drawing.Color]::Transparent }
  $s = $spec.Trim().TrimStart('#')
  try {
    if ($s.Length -eq 8) {
      $a = [Convert]::ToInt32($s.Substring(0, 2), 16)
      $r = [Convert]::ToInt32($s.Substring(2, 2), 16)
      $g = [Convert]::ToInt32($s.Substring(4, 2), 16)
      $b = [Convert]::ToInt32($s.Substring(6, 2), 16)
      return [System.Drawing.Color]::FromArgb($a, $r, $g, $b)
    }
    if ($s.Length -eq 6) {
      $r = [Convert]::ToInt32($s.Substring(0, 2), 16)
      $g = [Convert]::ToInt32($s.Substring(2, 2), 16)
      $b = [Convert]::ToInt32($s.Substring(4, 2), 16)
      return [System.Drawing.Color]::FromArgb($alphaDefault, $r, $g, $b)
    }
  } catch {
  }
  return [System.Drawing.Color]::Black
}

function New-RoundRect([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  if ($r -le 0 -or $w -le 0 -or $h -le 0) {
    $p.AddRectangle((New-Object System.Drawing.RectangleF($x, $y, [Math]::Max($w, 0), [Math]::Max($h, 0))))
    return $p
  }
  $maxR = [Math]::Min($w, $h) / 2
  if ($r -gt $maxR) { $r = $maxR }
  $d = $r * 2
  $p.AddArc($x, $y, $d, $d, 180, 90)
  $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $p.CloseFigure()
  return $p
}

function Get-ImageFrom([string]$src) {
  if ([string]::IsNullOrWhiteSpace($src)) { return $null }
  try {
    if (Test-Path -LiteralPath $src) { return [System.Drawing.Image]::FromFile($src) }
  } catch {
    Write-Host ('image-fail: ' + $src)
  }
  return $null
}

function Get-Num($obj, [double]$fallback) {
  if ($null -eq $obj) { return $fallback }
  try { return [double]$obj } catch { return $fallback }
}

$json = [System.IO.File]::ReadAllText($In, [System.Text.Encoding]::UTF8)
$spec = $json | ConvertFrom-Json

$w = [int](Get-Num $spec.width 760)
$h = [int](Get-Num $spec.height 480)
if ($w -lt 1) { $w = 760 }
if ($h -lt 1) { $h = 480 }

$bmp = New-Object System.Drawing.Bitmap($w, $h, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
$g.Clear([System.Drawing.Color]::Transparent)

if ($null -ne $spec.background) {
  $bg = $spec.background
  $rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
  if ([string]$bg.type -eq 'linear') {
    $c1 = ConvertTo-Color ([string]$bg.from)
    $c2 = ConvertTo-Color ([string]$bg.to)
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $c1, $c2, [single](Get-Num $bg.angle 45))
    $brush.WrapMode = [System.Drawing.Drawing2D.WrapMode]::TileFlipXY
    $g.FillRectangle($brush, $rect)
    $brush.Dispose()
  } elseif ([string]$bg.type -eq 'solid') {
    $brush = New-Object System.Drawing.SolidBrush((ConvertTo-Color ([string]$bg.color)))
    $g.FillRectangle($brush, $rect)
    $brush.Dispose()
  }
}

$imgCache = @{}

foreach ($item in @($spec.items)) {
  if ($null -eq $item) { continue }
  $t = [string]$item.type

  if ($t -eq 'rect') {
    $x = [single](Get-Num $item.x 0)
    $y = [single](Get-Num $item.y 0)
    $rw = [single](Get-Num $item.w 0)
    $rh = [single](Get-Num $item.h 0)
    $r = [single](Get-Num $item.radius 0)
    $path = New-RoundRect $x $y $rw $rh $r
    $brush = New-Object System.Drawing.SolidBrush((ConvertTo-Color ([string]$item.color)))
    $g.FillPath($brush, $path)
    $brush.Dispose()
    if ($null -ne $item.stroke -and [string]$item.stroke -ne '') {
      $pen = New-Object System.Drawing.Pen((ConvertTo-Color ([string]$item.stroke)), [single](Get-Num $item.strokeWidth 1))
      $g.DrawPath($pen, $path)
      $pen.Dispose()
    }
    $path.Dispose()
  }
  elseif ($t -eq 'text') {
    $text = [string]$item.text
    if ([string]::IsNullOrEmpty($text)) { continue }
    $size = [single](Get-Num $item.size 14)
    $style = [System.Drawing.FontStyle]::Regular
    if ($item.bold -eq $true) { $style = [System.Drawing.FontStyle]::Bold }
    $familyName = 'Microsoft YaHei'
    if (-not [string]::IsNullOrWhiteSpace([string]$item.font)) { $familyName = [string]$item.font }
    $font = New-Object System.Drawing.Font($familyName, $size, $style, [System.Drawing.GraphicsUnit]::Pixel)
    $fmt = [System.Drawing.StringFormat]::GenericTypographic
    $x = [single](Get-Num $item.x 0)
    $y = [single](Get-Num $item.y 0)
    $align = [string]$item.align
    if ($align -eq 'right' -or $align -eq 'center') {
      $measured = $g.MeasureString($text, $font, (New-Object System.Drawing.PointF(0, 0)), $fmt)
      if ($align -eq 'right') { $x = $x - [single]$measured.Width }
      else { $x = $x - [single]$measured.Width / 2 }
    }
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $origin = New-Object System.Drawing.PointF($x, $y)
    $path.AddString($text, $font.FontFamily, [int]$style, $font.Size, $origin, $fmt)
    $brush = New-Object System.Drawing.SolidBrush((ConvertTo-Color ([string]$item.color)))
    $g.FillPath($brush, $path)
    $brush.Dispose()
    $path.Dispose()
    $font.Dispose()
  }
  elseif ($t -eq 'image') {
    $src = [string]$item.src
    if ([string]::IsNullOrWhiteSpace($src)) { $src = [string]$item.url }
    if ([string]::IsNullOrWhiteSpace($src)) { continue }
    if (-not $imgCache.ContainsKey($src)) { $imgCache[$src] = Get-ImageFrom $src }
    $img = $imgCache[$src]
    if ($null -eq $img) { continue }
    $x = [single](Get-Num $item.x 0)
    $y = [single](Get-Num $item.y 0)
    $iw = [single](Get-Num $item.w 0)
    $ih = [single](Get-Num $item.h 0)
    if ($iw -le 0) { $iw = [single]$img.Width }
    if ($ih -le 0) { $ih = [single]$img.Height }
    $radius = [single](Get-Num $item.radius 0)
    $state = $g.Save()
    if ($radius -gt 0) {
      $clip = New-RoundRect $x $y $iw $ih $radius
      $g.SetClip($clip)
    }
    $sw = [single]$img.Width
    $sh = [single]$img.Height
    $scale = [Math]::Max($iw / $sw, $ih / $sh)
    $cw = $iw / $scale
    $ch = $ih / $scale
    $sx = ($sw - $cw) / 2
    $sy = ($sh - $ch) / 2
    $dst = New-Object System.Drawing.RectangleF($x, $y, $iw, $ih)
    $srcRect = New-Object System.Drawing.RectangleF($sx, $sy, $cw, $ch)
    $g.DrawImage($img, $dst, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
    $g.Restore($state)
  }
  elseif ($t -eq 'line') {
    $pen = New-Object System.Drawing.Pen((ConvertTo-Color ([string]$item.color)), [single](Get-Num $item.width 1))
    $g.DrawLine($pen, [single](Get-Num $item.x1 0), [single](Get-Num $item.y1 0), [single](Get-Num $item.x2 0), [single](Get-Num $item.y2 0))
    $pen.Dispose()
  }
}

$g.Dispose()

$dir = [System.IO.Path]::GetDirectoryName($Out)
if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
}
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Host ('rendered: ' + $Out)
