'use strict';
/**
 * 存储方式切换：SQLite ↔ JSON/JSONL（迁移 + 自动重启）
 * 运行：node test/storage-engine-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = [];
const check = (ok, msg) => {
  out.push({ ok, msg });
  console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
};

(async () => {
  const jlw = await new MockJlw({ port: 0 }).start();
  const port = 22200 + Math.floor(Math.random() * 40);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-engine-'));
  fs.writeFileSync(
    path.join(dir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        plugins: { enabled: false },
        storage: { engine: 'sqlite', messages: true },
        log: { level: 'info', console: false },
      },
      null,
      2,
    ),
  );
  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  let cookie = '';
  const call = (p, opts = {}) =>
    fetch(base + p, {
      method: opts.method || 'GET',
      headers: { ...(cookie ? { Cookie: cookie } : {}), ...(opts.body ? { 'Content-Type': 'application/json' } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
  const waitHealth = async (ms = 15000) => {
    const deadline = Date.now() + ms;
    while (Date.now() < deadline) {
      try {
        const h = await fetch(base + '/health').then((r) => r.json());
        if (h.ok && h.version) return h;
      } catch {}
      await sleep(250);
    }
    throw new Error('wait health timeout');
  };

  try {
    await waitHealth();
    const login = await call('/api/login', { method: 'POST', body: { email: 'user@test.local', password: 'secret123' } });
    cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];
    const cfg1 = await call('/api/status').then((r) => r.json());
    check((cfg1.config?.storage?.engine || 'sqlite') === 'sqlite', '初始引擎是 SQLite');
    check(fs.existsSync(path.join(dir, 'jlwbot.db')), 'SQLite 文件已创建');

    const sw1 = await call('/api/storage/engine', { method: 'POST', body: { engine: 'json' } }).then((r) => r.json());
    check(sw1.ok === true && sw1.engine === 'json', '切换到 JSON 成功');
    await sleep(3500);
    await waitHealth();
    const fileCfg = JSON.parse(fs.readFileSync(path.join(dir, 'config.json'), 'utf8'));
    check((fileCfg.storage?.engine || '') === 'json', 'config.json 记录新引擎');
    const today = (() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    })();
    const logFile = path.join(dir, 'logs', `jlwbot-${today}.jsonl`);
    check(fs.existsSync(logFile), 'JSON 引擎生成 logs/jlwbot-*.jsonl');
    const logs1 = await call('/api/logs?date=' + today).then((r) => r.json());
    check(logs1.ok === true && (logs1.logs || []).length > 0, 'JSON 引擎下日志可按日期查询');

    const sw2 = await call('/api/storage/engine', { method: 'POST', body: { engine: 'sqlite' } }).then((r) => r.json());
    check(sw2.ok === true && sw2.engine === 'sqlite', '切回 SQLite 成功');
    await sleep(3500);
    await waitHealth();
    const cfg2 = await call('/api/status').then((r) => r.json());
    check((cfg2.config?.storage?.engine || '') === 'sqlite', '重启后引擎为 SQLite');
    const logs2 = await call('/api/logs?date=' + today).then((r) => r.json());
    check(logs2.ok === true && (logs2.logs || []).length > 0, 'SQLite 引擎下日志仍可按日期查询');

    // JSON 引擎写消息时 payload 要能原样读回（消息详情预览依赖它）
    const probe = `
      (async () => {
        const store = require(${JSON.stringify(path.join(ROOT, 'src', 'core', 'store'))});
        store.setEngine('json');
        const t = Date.now();
        store.insertMessage({ t, time: new Date(t).toISOString(), event: 'BOT_MESSAGE_CREATE', direction: 'out', kind: 'group', id: 'json-payload', content: '**优雅**', payload: { msg_type: 2, markdown: { content: '**优雅**' } } });
        store.close();
        await new Promise((r) => setTimeout(r, 300));
        const store2 = require(${JSON.stringify(path.join(ROOT, 'src', 'core', 'store'))});
        store2.setEngine('json');
        const got = store2.messagesByDay('${today}', { limit: 50 }).find((m) => m.id === 'json-payload');
        console.log(JSON.stringify(got && got.payload ? got.payload : null));
        store2.close();
      })();
    `;
    const probeRun = require('child_process').spawnSync(process.execPath, ['-e', probe], {
      env: { ...process.env, JLW_DATA_DIR: dir },
      encoding: 'utf8',
    });
    let jsonPayload = null;
    try {
      jsonPayload = JSON.parse(probeRun.stdout.trim().split('\n').pop());
    } catch {}
    check(jsonPayload?.markdown?.content === '**优雅**', 'JSON 引擎消息 payload 可读回');
  } finally {
    child.kill();
    await sleep(300);
    await jlw.stop();
    try {
      fs.rmSync(dir, { recursive: true, force: true });
    } catch {}
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
