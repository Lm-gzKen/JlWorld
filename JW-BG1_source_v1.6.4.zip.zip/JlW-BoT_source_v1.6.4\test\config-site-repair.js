'use strict';
/**
 * 账户站点自愈回归：
 *   1. 全新数据目录 -> 官方站点
 *   2. 旧配置 baseUrl="" -> 自动恢复官方站点
 *   3. 旧配置 baseUrl=127.0.0.1:3101 -> 自动恢复官方站点
 *   4. JLW_ALLOW_LOCAL_SITE=1 时保留本地 mock 地址
 *   5. 运行中手动填本机地址登录 -> 400 + 可操作提示（不再是 ECONNRESET）
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const OFFICIAL = 'https://www.jlworld.net';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitHealth(base, child) {
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error('子进程提前退出：' + child.exitCode);
    try {
      const r = await fetch(base + '/health');
      if (r.ok) return;
    } catch {
      /* retry */
    }
    await sleep(200);
  }
  throw new Error('服务未在 20 秒内启动');
}

async function runCase(name, port, config, env, opts = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-site-'));
  if (config) fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify(config, null, 2));
  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open', '--port', String(port), '--data-dir', dir], {
    cwd: ROOT,
    env: { ...process.env, ...env, JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  try {
    await waitHealth(base, child);
    const sess = await fetch(base + '/api/session').then((r) => r.json());
    const saved = JSON.parse(fs.readFileSync(path.join(dir, 'config.json'), 'utf8'));
    return { sess, saved, dir, base, child };
  } finally {
    if (!opts.keep) {
      child.kill();
      await sleep(150);
      try {
        fs.rmSync(dir, { recursive: true, force: true });
      } catch {
        /* ignore */
      }
    }
  }
}

(async () => {
  const results = [];
  const check = (ok, msg) => {
    results.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };

  let r = await runCase('fresh', 18741, null, {});
  check(r.sess.site.baseUrl === OFFICIAL, '全新数据目录使用官方站点');
  check(r.sess.needsSetup === false, '全新数据目录 needsSetup=false');

  r = await runCase('empty', 18742, { jlw: { baseUrl: '' } }, {});
  check(r.sess.site.baseUrl === OFFICIAL, '空 baseUrl 自动恢复官方站点');
  check(r.saved.jlw.baseUrl === OFFICIAL, '空 baseUrl 已写回 config.json');

  r = await runCase('loopback', 18743, { jlw: { baseUrl: 'http://127.0.0.1:3101' } }, {});
  check(r.sess.site.baseUrl === OFFICIAL, '本机 baseUrl 自动恢复官方站点');
  check(r.saved.jlw.baseUrl === OFFICIAL, '本机 baseUrl 已写回 config.json');

  r = await runCase('mock', 18744, { jlw: { baseUrl: 'http://127.0.0.1:3101' } }, { JLW_ALLOW_LOCAL_SITE: '1' });
  check(r.sess.site.baseUrl === 'http://127.0.0.1:3101', 'JLW_ALLOW_LOCAL_SITE=1 保留本地地址');

  // 运行中手动把站点改成 loopback 再登录：应 400 且提示改成官方站点
  r = await runCase('runtime', 18745, null, {}, { keep: true });
  const res = await fetch(r.base + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'a@b.c', password: 'x', baseUrl: 'http://127.0.0.1:3101' }),
  });
  const body = await res.json();
  check(res.status === 400 && /指向本机/.test(body.error || ''), '运行中填本机地址返回 400 与可操作提示');
  r.child.kill();
  await sleep(150);
  try {
    fs.rmSync(r.dir, { recursive: true, force: true });
  } catch {
    /* ignore */
  }

  const failed = results.filter((x) => !x.ok);
  console.log(`\n${results.length - failed.length}/${results.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
