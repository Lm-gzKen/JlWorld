'use strict';
/**
 * 定时重启 / 手动重启 的进程内重启端到端
 *   node test/restart-e2e.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = [];
function check(ok, name, extra) {
  out.push({ ok: !!ok, name });
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}${!ok && extra ? ' \x1b[90m' + extra + '\x1b[0m' : ''}`);
}

async function waitHealth(base, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(base + '/health', { signal: AbortSignal.timeout(1500) });
      if (r.ok) return await r.json();
    } catch {
      /* retry */
    }
    await sleep(200);
  }
  return null;
}

(async () => {
  const port = 22300 + Math.floor(Math.random() * 300);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-restart-e2e-'));
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const base = `http://127.0.0.1:${port}`;

  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        auth: { allowed: ['user@test.local'], initialized: true },
        accounts: [],
        plugins: { enabled: false },
        system: { restart: { enabled: true, minutes: 60 } },
        log: { level: 'debug', console: false },
      },
      null,
      2,
    ),
  );

  let child = null;
  try {
    child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
      cwd: ROOT,
      env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    let stderr = '';
    child.stderr.on('data', (d) => (stderr += String(d)));

    const h1 = await waitHealth(base);
    check(!!h1, '服务启动', stderr.slice(-300));
    if (!h1) throw new Error('服务未启动：' + stderr.slice(-500));
    const pid1 = h1.pid;

    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    const cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];
    check(login.status === 200 && cookie.includes('jlw_sid='), '登录面板', String(login.status));

    const st = await fetch(base + '/api/status', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(st.system?.restart?.enabled === true, '/api/status 显示定时重启已启用', JSON.stringify(st.system));
    check(st.system.restart.minutes === 60, '/api/status 显示 60 分钟', JSON.stringify(st.system));
    check(st.system.restart.nextAt > Date.now(), '/api/status 给出下次重启时间', JSON.stringify(st.system));

    // 改配置 → 计划跟着变
    const saved = await fetch(base + '/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ patch: { system: { restart: { enabled: true, minutes: 5 } } } }),
    }).then((r) => r.json());
    check(saved.ok === true, '保存定时重启配置', JSON.stringify(saved));
    const st2 = await fetch(base + '/api/status', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(st2.system?.restart?.minutes === 5, '配置保存后计划立即更新', JSON.stringify(st2.system));

    // 手动重启：进程内重开，pid 不变、uptime 归零
    const before = await fetch(base + '/health').then((r) => r.json());
    const rs = await fetch(base + '/api/system/restart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: '{}',
    }).then((r) => r.json());
    check(rs.ok === true && rs.restarting === true, '手动重启接口返回重启中', JSON.stringify(rs));

    let after = null;
    for (let i = 0; i < 80; i++) {
      await sleep(250);
      const h = await waitHealth(base, 3000);
      if (h && h.pid === before.pid && h.uptime < before.uptime) {
        after = h;
        break;
      }
    }
    check(!!after, '重启后服务恢复', JSON.stringify(after));
    check(after?.pid === before.pid, '进程内重启 PID 不变', `${before.pid} → ${after?.pid}`);
    check((after?.uptime ?? 1e9) < before.uptime, '重启后 uptime 归零', `${before.uptime} → ${after?.uptime}`);

    const st3 = await fetch(base + '/api/status', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(st3.system?.restart?.enabled === true && st3.system.restart.minutes === 5, '重启后定时计划仍在', JSON.stringify(st3.system));

    // 日志（SQLite）里能看到重启过程：走面板接口读当天日志
    await sleep(300);
    const today = (() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    })();
    const logRes = await fetch(base + '/api/logs?date=' + today + '&limit=5000', { headers: { Cookie: cookie } }).then((r) => r.json());
    const text = (logRes.logs || []).map((l) => l.msg).join('\n');
    check(/正在停用运行时/.test(text), '日志记录停用旧运行时');
    check(/JlWBoT v.*启动中/.test(text), '日志记录重新启动');
    check(/面板手动重启/.test(text), '日志记录重启原因');
    check((logRes.logs || []).length > 0, '日志接口可读（SQLite）');
  } finally {
    if (child) {
      child.kill();
      await sleep(300);
    }
    await jlwMock.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  if (failed.length) {
    console.log('失败项：');
    for (const f of failed) console.log('  - ' + f.name);
  }
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
