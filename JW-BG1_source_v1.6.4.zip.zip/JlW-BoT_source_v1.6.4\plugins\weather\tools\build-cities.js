'use strict';
/**
 * 生成 data/cities.json —— 中国行政区（省 / 市 / 区县）→ 中国天气网 AREAID
 *
 * 数据源：http://j.i8tq.com/weather2020/search/city.js（中国天气网用的三级城市表，3221 条）
 * 为什么要离线付一份：中国天气网的「按名字查代码」接口（toy1.weather.com.cn/search）
 * 已经返回空 `()`，open-meteo / GeoNames 也查不到中文「天河区」这种区县名，
 * 所以把三级表打进插件，用名字直接查到区县级 AREAID，再拿 itboy / d1 的区县天气。
 *
 * 用法（只有要更新城市表时才跑）：
 *   node plugins/weather/tools/build-cities.js            # 在线下载后生成
 *   node plugins/weather/tools/build-cities.js tmp/city.js # 用本地已下载的文件
 */

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const SOURCE = 'http://j.i8tq.com/weather2020/search/city.js';
const OUT = path.join(__dirname, '..', 'data', 'cities.json');

function download(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 30000 }, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error('HTTP ' + res.statusCode));
      }
      let b = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (b += c));
      res.on('end', () => resolve(b));
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

function parseCityJs(text) {
  const i = text.indexOf('{');
  if (i < 0) throw new Error('city.js 里找不到 JSON 起点');
  const json = text.slice(i).replace(/;\s*$/, '');
  return JSON.parse(json);
}

/**
 * 压缩结构，减少一半体积：
 * {v, source, updated, provinces: [[省名, [[市名, 市代码, [[区名, 区代码], ...]], ...]], ...]}
 */
function compact(data) {
  const provinces = [];
  for (const pName of Object.keys(data)) {
    const cities = [];
    for (const cName of Object.keys(data[pName] || {})) {
      const leaves = data[pName][cName] || {};
      let cityCode = '';
      const districts = [];
      for (const dName of Object.keys(leaves)) {
        const leaf = leaves[dName] || {};
        const code = String(leaf.AREAID || '').trim();
        if (!/^\d{9}$/.test(code)) continue;
        // 市本级节点（名字与市同名）单独存成 cityCode，其它是区县
        if (!cityCode && (dName === cName || /^101\d{4}01$|^101\d{4}00$/.test(code))) cityCode = code;
        else districts.push([dName, code]);
      }
      if (!cityCode && districts.length) cityCode = districts[0][1];
      if (!cityCode && !districts.length) continue;
      cities.push([cName, cityCode, districts]);
    }
    provinces.push([pName, cities]);
  }
  return { v: 1, source: SOURCE, updated: new Date().toISOString().slice(0, 10), provinces };
}

(async () => {
  const local = process.argv[2];
  const raw = local ? fs.readFileSync(path.resolve(local), 'utf8') : await download(SOURCE);
  const data = parseCityJs(raw);
  const packed = compact(data);
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  const body = JSON.stringify(packed);
  fs.writeFileSync(OUT, body + '\n', 'utf8');
  let cities = 0;
  let districts = 0;
  for (const [, list] of packed.provinces) {
    cities += list.length;
    for (const [, , ds] of list) districts += ds.length;
  }
  console.log(`已生成 ${OUT}`);
  console.log(`省 ${packed.provinces.length} · 市 ${cities} · 区县 ${districts} · ${(body.length / 1024).toFixed(1)} KB`);
})().catch((e) => {
  console.error('生成失败：' + (e?.message || e));
  process.exit(1);
});
