'use strict';
/**
 * 明日方舟插件 · 对外 API（供其他 JS 插件在同进程内调用）
 *
 * 两种拿法：
 *   1) 全局注册表（推荐，无需知道路径）：
 *        const ak = globalThis.__JLWBOT_PLUGIN_APIS__?.get('Arknights');
 *   2) 直接 require 插件目录（同进程共享模块缓存）：
 *        const ak = require(path.join(pluginsRoot, 'Arknights', 'api.js'));
 *
 * 所有方法都是纯数据返回，不会替你发 QQ 消息；未登录时抛错（code='NOT_LOGIN'）。
 * 需要用户先在自己的会话里发过 /Arknights 登录，凭据按 QQ 用户隔离。
 */

const Service = require('./lib/service');

let runtimeRef = null;

/** 从各种入参里收集可能的 openid（字符串 / 消息对象 / author 对象都行） */
function openidCandidates(input) {
  if (!input) return [];
  if (typeof input === 'string') return [input.trim()].filter(Boolean);
  const raw = [input.union_openid, input.user_openid, input.member_openid, input.openid, input.id];
  const author = input.author || input.message?.author;
  if (author) raw.push(author.union_openid, author.user_openid, author.member_openid, author.id);
  const out = [];
  for (const v of raw) {
    const s = typeof v === 'string' ? v.trim() : '';
    if (s && !out.includes(s)) out.push(s);
  }
  return out;
}

/** 对外只暴露脱敏字段（不含 cred / token） */
function publicUser(user) {
  if (!user) return null;
  const active = user.active || {};
  return {
    key: user.key,
    name: user.name || '',
    phoneTail: user.phoneTail || '',
    loggedIn: !!(user.cred && user.token),
    createdAt: user.createdAt || 0,
    updatedAt: user.updatedAt || 0,
    active,
    lastSign: user.lastSign || {},
    bindings: (user.bindings || []).map((b) => ({
      game: b.game,
      uid: b.uid,
      name: b.roleName || b.nickName || '',
      channel: b.channelName || '',
      level: b.level || '',
      current: (active[b.game] || '') === b.uid,
    })),
  };
}

function ensureReady() {  if (!runtimeRef) {
    const err = new Error('明日方舟插件尚未加载（runtime 未初始化）');
    err.code = 'NOT_READY';
    throw err;
  }
  return runtimeRef;
}

const api = {
  pluginId: 'Arknights',
  version: '1.10.1',

  /** 插件是否已加载并可用 */
  isReady() {
    return !!runtimeRef;
  },

  /**
   * 登录确认：这个 QQ 用户是否已经登录过森空岛（明日方舟）账号。
   * 纯本地判断（只看本机 `data/accounts.json` 里有没有 cred + token），不联网、不会刷新凭据。
   *
   * @param {string|object} openid openid 字符串，或带 union_openid / user_openid / member_openid 的对象（消息对象也行）
   * @returns {boolean} 已登录 true，未登录 false（插件没加载也返回 false）
   *
   * @example
   *   const ak = globalThis.__JLWBOT_PLUGIN_APIS__.get('Arknights');
   *   if (!ak.isLoggedIn(message.author.user_openid)) return { reply: '请先私聊登录明日方舟账号' };
   */
  isLoggedIn(openid) {
    if (!runtimeRef || !runtimeRef.store) return false;
    for (const id of openidCandidates(openid)) {
      const user = runtimeRef.store.get(id);
      if (user && user.cred && user.token) return true;
    }
    return false;
  },

  /** 当前存储后端：'vsql'（VSQL 的 shared 库）；VSQL 缺失时为 'none' */
  storageBackend() {
    return runtimeRef?.store?.backend || 'none';
  },

  /** 缺少的前置插件名（正常为空串） */
  dependencyMissing() {
    return runtimeRef?.depMissing || '';
  },

  /** 本插件在 shared 库里用的表名 */
  tables() {
    return runtimeRef?.store?.tables || {};
  },

  /**
   * 账号数据库文件绝对路径（SQLite）。其他插件可以直接只读打开：
   *   const { DatabaseSync } = require('node:sqlite');
   *   const db = new DatabaseSync(ak.dbPath(), { readOnly: true });
   *   db.prepare('SELECT key, phone_tail FROM users').all();
   * JSON 后端返回 accounts.json 路径。
   */
  dbPath() {
    return runtimeRef?.store?.dbFile || runtimeRef?.store?.file || '';
  },

  /**
   * 所有已授权用户（脱敏，不含 cred / token）
   * @returns {Array<object>}
   */
  users() {
    if (!runtimeRef?.store) return [];
    return (runtimeRef.store.all() || []).map(publicUser);
  },

  /**
   * 按 openid 取单个用户（脱敏）；没登录过返回 null
   * @returns {object|null}
   */
  getUser(openid) {
    if (!runtimeRef?.store) return null;
    for (const id of openidCandidates(openid)) {
      const user = runtimeRef.store.get(id);
      if (user) return publicUser(user);
    }
    return null;
  },

  /** 由 index.js 的 onLoad 调用 */
  bind(runtime) {
    runtimeRef = runtime;
    try {
      const g = globalThis;
      if (!(g.__JLWBOT_PLUGIN_APIS__ instanceof Map)) g.__JLWBOT_PLUGIN_APIS__ = new Map();
      g.__JLWBOT_PLUGIN_APIS__.set('Arknights', api);
    } catch {
      /* ignore */
    }
    return api;
  },

  /** 由 index.js 的 onUnload 调用 */
  unbind() {
    runtimeRef = null;
    try {
      globalThis.__JLWBOT_PLUGIN_APIS__?.delete('Arknights');
    } catch {
      /* ignore */
    }
  },

  /**
   * 森空岛签到（明日方舟 + 终末地）。一分钟内重复调用复用缓存结果，并发调用自动合并为一次。
   * @param {string} userKey QQ OpenID（与指令事件里的 user_openid / member_openid / union_openid 一致）
   * @param {{games?: Array<'arknights'|'endfield'>, refresh?: boolean}} [options]
   * @returns {Promise<{accounts: Array<object>, errors: Array<object>}>}
   *
   * account = {
   *   game, uid, name, channel,
   *   status: 'signed' | 'already' | 'failed',   // failed 时附带 code（森空岛业务码）
   *   awards: [{ name, count }],
   *   tomorrowAwards?: [{ name, count }],
   *   daysSigned: number | null,
   *   message: string
   * }
   */
  async sign(userKey, options = {}) {
    return Service.signAll(ensureReady(), userKey, options);
  },

  /** 只签明日方舟 */
  async signArknights(userKey, options = {}) {
    return Service.signAll(ensureReady(), userKey, { ...options, games: ['arknights'] });
  },

  /** 只签终末地 */
  async signEndfield(userKey, options = {}) {
    return Service.signAll(ensureReady(), userKey, { ...options, games: ['endfield'] });
  },

  /**
   * 个人数据（森空岛 player/info 原始 data）
   * @param {string} userKey
   * @param {{uid?: string, refresh?: boolean}} [options]
   * @returns {Promise<{binding: object, data: object}>}
   */
  async profile(userKey, options = {}) {
    return Service.profile(ensureReady(), userKey, options);
  },

  /**
   * 绑定角色列表
   * @param {string} userKey
   * @param {{refresh?: boolean}} [options]
   * @returns {Promise<Array<object>>}
   */
  async bindings(userKey, options = {}) {
    return Service.bindings(ensureReady(), userKey, options);
  },

  /** 重新同步森空岛绑定 */
  async refresh(userKey) {
    return Service.refreshBindings(ensureReady(), userKey);
  },

  /** 当前登录态（不返回 cred / token 明文） */
  status(userKey) {
    const rt = ensureReady();
    const user = rt.store ? rt.store.get(userKey) : null;
    if (!user) return { loggedIn: false, bindings: 0, active: {} };
    return {
      loggedIn: !!(user.cred && user.token),
      phoneTail: user.phoneTail || '',
      bindings: (user.bindings || []).length,
      active: user.active || {},
    };
  },
};

module.exports = api;

// 别名：isLoggedIn / loggedIn / hasLoggedIn 都可调用同一实现
api.loggedIn = api.isLoggedIn;
api.hasLoggedIn = api.isLoggedIn;
