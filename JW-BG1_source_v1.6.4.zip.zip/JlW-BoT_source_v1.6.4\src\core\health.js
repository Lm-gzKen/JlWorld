'use strict';
/**
 * 进程健康守护：崩溃取证 + 心跳。
 *
 * 解决的问题：机器人偶尔“直接没了”——不回复、没日志、面板端口也打不开。
 * 这类情况以前在磁盘上留不下任何痕迹，只能靠猜。这里做三件事：
 *   1. 兜住 uncaughtException / unhandledRejection，把堆栈写进 ~JlWBoT/logs/crash.log，进程继续跑；
 *   2. 每 15 秒写一次 ~JlWBoT/logs/heartbeat.json，下次启动即可判断“上次是不是异常退出”；
 *   3. 连续异常过多时主动退出（退出码 1），交给启动器自动重启，避免半死不活。
 *
 * 只用 Node 内置模块；写日志全部同步 + try/catch，保证崩溃路径上不会再抛。
 */
const fs = require('fs');
const path = require('path');
const U = require('./util');

const CRASH_FILE = 'crash.log';
const HEARTBEAT_FILE = 'heartbeat.json';
const HEARTBEAT_MS = 15000;

function logsDir(dataDir) {
  return path.join(dataDir || U.dataRoot(), 'logs');
}

function crashPath(dataDir) {
  return path.join(logsDir(dataDir), CRASH_FILE);
}

function heartbeatPath(dataDir) {
  return path.join(logsDir(dataDir), HEARTBEAT_FILE);
}

function ensureDir(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    /* ignore */
  }
}

/** 同步追加一行；任何失败都吞掉，绝不在崩溃路径上再抛 */
function appendLine(file, text) {
  try {
    ensureDir(path.dirname(file));
    fs.appendFileSync(file, text.endsWith('\n') ? text : text + '\n');
    return true;
  } catch {
    return false;
  }
}

function describe(err) {
  if (!err) return { message: '', stack: '' };
  if (typeof err === 'string') return { message: err, stack: '' };
  return {
    message: String(err.message || err),
    stack: String(err.stack || '').split('\n').slice(0, 24).join('\n'),
  };
}

function formatRecord(kind, err, extra) {
  const d = describe(err);
  return {
    t: Date.now(),
    time: U.nowIso(),
    kind,
    message: d.message,
    stack: d.stack,
    pid: process.pid,
    uptimeSec: Math.round(process.uptime()),
    rssMB: Math.round(process.memoryUsage().rss / 1048576),
    version: extra?.version || '',
    exitCode: extra?.exitCode,
  };
}

/** 读最近几条崩溃记录（新的在后） */
function readCrashes(dataDir, limit = 5) {
  try {
    const text = fs.readFileSync(crashPath(dataDir), 'utf8');
    const lines = text.trim().split('\n').slice(-Math.max(1, limit));
    return lines
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

function readHeartbeat(dataDir) {
  try {
    return JSON.parse(fs.readFileSync(heartbeatPath(dataDir), 'utf8'));
  } catch {
    return null;
  }
}

/** 上次心跳是否“没有正常收尾”（进程被杀 / 崩溃 / 断电） */
function wasUncleanShutdown(dataDir, currentPid = process.pid) {
  const hb = readHeartbeat(dataDir);
  if (!hb || !hb.pid) return null;
  if (hb.stoppedAt) return null;
  if (Number(hb.pid) === Number(currentPid)) return null;
  return hb;
}

class CrashGuard {
  constructor({ dataDir, version, logger, maxExceptions = 30, windowMs = 60000, heartbeatMs = HEARTBEAT_MS } = {}) {
    this.dataDir = dataDir || U.dataRoot();
    this.version = version || '';
    this.logger = logger || null;
    this.maxExceptions = maxExceptions;
    this.windowMs = windowMs;
    this.heartbeatMs = heartbeatMs;
    this.installed = false;
    this.exits = 0;
    this.firstAt = 0;
    this.heartbeatTimer = null;
    this.handlers = null;
  }

  record(kind, err, extra) {
    const rec = formatRecord(kind, err, { version: this.version, ...(extra || {}) });
    appendLine(crashPath(this.dataDir), JSON.stringify(rec));
    return rec;
  }

  /** 只写文件、不依赖 logger 的兜底安装（logger 还没建好时也能用） */
  install() {
    if (this.installed) return this;
    this.installed = true;
    const self = this;

    const onUncaught = (err, origin) => {
      self.exits++;
      if (!self.firstAt) self.firstAt = Date.now();
      const rec = self.record('uncaughtException', err, { origin });
      self._log('error', `未捕获异常（进程继续运行）：${rec.message}`, { origin, stack: rec.stack });
      if (self.exits >= self.maxExceptions && Date.now() - self.firstAt < self.windowMs) {
        if (!self.warnedBurst) {
          self.warnedBurst = true;
          self.record('exceptionBurst', new Error(`短时间内未捕获异常 ${self.exits} 次（进程继续运行）`));
          self._log('error', `短时间内异常 ${self.exits} 次：已写入 crash.log，进程继续运行（不主动退出，避免连面板一起没）`);
        }
      }
    };

    const onRejection = (reason) => {
      const rec = self.record('unhandledRejection', reason);
      self._log('error', `未处理的 Promise 拒绝（进程继续运行）：${rec.message}`, { stack: rec.stack });
    };

    const onWarning = (w) => {
      self._log('warn', `进程告警：${w?.name || ''} ${w?.message || w}`);
    };

    const onExit = (code) => {
      self.record('exit', null, { exitCode: code });
      try {
        const hb = readHeartbeat(self.dataDir) || {};
        fs.writeFileSync(
          heartbeatPath(self.dataDir),
          JSON.stringify({ ...hb, pid: process.pid, stoppedAt: Date.now(), exitCode: code, clean: code === 0 }, null, 2),
        );
      } catch {
        /* ignore */
      }
    };

    // stdout/stderr 被关掉/管道断开时不要因为 EPIPE 变成未捕获异常
    const onStdoutError = () => {};
    const onStderrError = () => {};

    process.on('uncaughtException', onUncaught);
    process.on('unhandledRejection', onRejection);
    process.on('warning', onWarning);
    process.on('exit', onExit);
    process.stdout?.on?.('error', onStdoutError);
    process.stderr?.on?.('error', onStderrError);

    this.handlers = { onUncaught, onRejection, onWarning, onExit, onStdoutError, onStderrError };
    return this;
  }

  uninstall() {
    if (!this.installed || !this.handlers) return;
    const h = this.handlers;
    process.removeListener('uncaughtException', h.onUncaught);
    process.removeListener('unhandledRejection', h.onRejection);
    process.removeListener('warning', h.onWarning);
    process.removeListener('exit', h.onExit);
    process.stdout?.removeListener?.('error', h.onStdoutError);
    process.stderr?.removeListener?.('error', h.onStderrError);
    this.stopHeartbeat();
    this.installed = false;
    this.handlers = null;
  }

  attachLogger(logger) {
    this.logger = logger;
    return this;
  }

  _log(level, msg, meta) {
    try {
      if (this.logger && typeof this.logger[level] === 'function') this.logger[level](msg, meta);
      else if (level === 'error') process.stderr.write(msg + '\n');
    } catch {
      /* ignore */
    }
  }

  /** 启动心跳；写失败只记一次，避免刷屏 */
  startHeartbeat() {
    if (this.heartbeatTimer) return this;
    const write = () => {
      const rec = {
        pid: process.pid,
        version: this.version,
        t: Date.now(),
        time: U.nowIso(),
        uptimeSec: Math.round(process.uptime()),
        rssMB: Math.round(process.memoryUsage().rss / 1048576),
      };
      try {
        ensureDir(logsDir(this.dataDir));
        fs.writeFileSync(heartbeatPath(this.dataDir), JSON.stringify(rec, null, 2));
        this._hbFailed = false;
      } catch (e) {
        if (!this._hbFailed) {
          this._hbFailed = true;
          this._log('warn', '心跳写入失败：' + (e?.message || e));
        }
      }
    };
    write();
    this.heartbeatTimer = setInterval(write, this.heartbeatMs);
    if (this.heartbeatTimer.unref) this.heartbeatTimer.unref();
    return this;
  }

  stopHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
  }

  /** 正常退出：写 clean 标记，避免下次误报“异常退出” */
  markCleanExit() {
    try {
      const hb = readHeartbeat(this.dataDir) || { pid: process.pid };
      fs.writeFileSync(
        heartbeatPath(this.dataDir),
        JSON.stringify({ ...hb, pid: process.pid, stoppedAt: Date.now(), exitCode: 0, clean: true }, null, 2),
      );
    } catch {
      /* ignore */
    }
  }
}

module.exports = {
  CrashGuard,
  installCrashGuard: (opts) => new CrashGuard(opts).install(),
  readCrashes,
  readHeartbeat,
  wasUncleanShutdown,
  crashPath,
  heartbeatPath,
  CRASH_FILE,
  HEARTBEAT_FILE,
  HEARTBEAT_MS,
};
