'use strict';
/**
 * WebHook 事件接收（多账户）
 * - 每个账户用自己的 AppSecret 做 Ed25519 验签
 * - op=13 回调地址验证：返回 { plain_token, signature }
 * - op=0 事件：立刻回 op=12 ACK，再异步交给对应账户处理
 */
const crypto = require('crypto');

const PKCS8_ED25519_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

function seedOf(secret) {
  let seed = Buffer.from(String(secret || ''), 'utf8');
  if (!seed.length) return null;
  while (seed.length < 32) seed = Buffer.concat([seed, seed]);
  return seed.subarray(0, 32);
}

function keyPair(secret) {
  const seed = seedOf(secret);
  if (!seed) return null;
  const privateKey = crypto.createPrivateKey({
    key: Buffer.concat([PKCS8_ED25519_PREFIX, seed]),
    format: 'der',
    type: 'pkcs8',
  });
  const publicKey = crypto.createPublicKey(privateKey);
  return { privateKey, publicKey };
}

function sign(secret, message) {
  const kp = keyPair(secret);
  if (!kp) throw new Error('缺少 AppSecret');
  return crypto.sign(null, Buffer.from(message), kp.privateKey).toString('hex');
}

function verify(secret, message, signatureHex) {
  const kp = keyPair(secret);
  if (!kp) return false;
  try {
    return crypto.verify(null, Buffer.from(message), kp.publicKey, Buffer.from(String(signatureHex), 'hex'));
  } catch {
    return false;
  }
}

/** 校验回调请求签名：timestamp + rawBody */
function verifyRequest({ headers, rawBody, secret, maxSkewMs = 15 * 60 * 1000 }) {
  const sig = headers['x-signature-ed25519'];
  const timestamp = headers['x-signature-timestamp'];
  if (!sig || !timestamp) return { ok: false, reason: '缺少签名头' };
  if (maxSkewMs) {
    const t = Number(timestamp) * 1000;
    if (Number.isFinite(t) && Math.abs(Date.now() - t) > maxSkewMs) return { ok: false, reason: '时间戳超出允许范围' };
  }
  const ok = verify(secret, timestamp + rawBody, sig);
  return ok ? { ok: true } : { ok: false, reason: '签名不匹配' };
}

/** 生成回调地址验证响应 */
function validationResponse(secret, d) {
  const plainToken = d?.plain_token || '';
  const eventTs = d?.event_ts || '';
  return { plain_token: plainToken, signature: sign(secret, eventTs + plainToken) };
}

class Webhook {
  constructor({ logger }) {
    this.log = logger.child('webhook');
  }

  /**
   * @param {object} opts { headers, rawBody, secret, verify, ackOp12, stats, onEvent, label }
   * @returns {{status:number, body:object}}
   */
  handle({ headers, rawBody, secret, verify: needVerify = true, ackOp12 = true, stats, onEvent, label = '' }) {
    const st = stats || (this._fallbackStats = this._fallbackStats || { received: 0, verified: 0, rejected: 0, lastAt: 0, lastError: null });
    st.received++;
    st.lastAt = Date.now();
    const who = label ? `[${label}] ` : '';
    let payload;
    try {
      payload = JSON.parse(rawBody || '{}');
    } catch {
      st.rejected++;
      return { status: 400, body: { message: 'invalid json' } };
    }

    // 回调地址验证：平台示例请求不带签名头，应答本身用 Ed25519 签名完成验证
    if (payload.op === 13) {
      try {
        const body = validationResponse(secret, payload.d);
        this.log.info(who + '回调地址验证通过');
        return { status: 200, body };
      } catch (e) {
        return { status: 500, body: { message: e.message } };
      }
    }

    if (needVerify) {
      if (!secret) {
        st.rejected++;
        return { status: 500, body: { message: 'AppSecret 未配置，无法验签' } };
      }
      const hasSignature = !!(headers['x-signature-ed25519'] && headers['x-signature-timestamp']);
      if (!hasSignature) {
        st.rejected++;
        st.lastError = '缺少签名头';
        this.log.warn(who + 'WebHook 缺少签名头');
        return { status: 401, body: { message: 'missing signature' } };
      }
      const v = verifyRequest({ headers, rawBody, secret });
      if (!v.ok) {
        st.rejected++;
        st.lastError = v.reason;
        this.log.warn(who + 'WebHook 验签失败：' + v.reason);
        return { status: 401, body: { message: 'invalid signature' } };
      }
    }
    st.verified++;

    if (payload.op === 0 && payload.t) {
      // 先 ACK，再异步处理，避免 QQ 端超时重推
      setImmediate(() => {
        try {
          onEvent({ t: payload.t, d: payload.d, id: payload.id, s: payload.s, source: 'webhook' });
        } catch (e) {
          this.log.error(who + '处理 WebHook 事件失败: ' + e.message);
        }
      });
      return { status: 200, body: ackOp12 ? { op: 12 } : { code: 0 } };
    }

    return { status: 200, body: { op: 12 } };
  }

  info(stats) {
    return { ...(stats || {}), verify: true };
  }
}

module.exports = Webhook;
module.exports.sign = sign;
module.exports.verify = verify;
module.exports.verifyRequest = verifyRequest;
module.exports.validationResponse = validationResponse;
module.exports.seedOf = seedOf;
