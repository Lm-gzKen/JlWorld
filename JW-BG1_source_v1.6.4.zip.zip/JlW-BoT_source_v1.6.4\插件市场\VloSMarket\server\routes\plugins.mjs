// 插件路由：市场列表 / 详情 / zip 解析暂存 / 发布 / 新版本 / 下载 / 我的插件。
// 插件只收 .zip：上传包先暂存到 tmp/ 并解析出名称+版本，用户确认后一次落库。
import fs from 'node:fs';
import path from 'node:path';
import { HttpError, readBody, safeFileName, sha256, newId } from '../http.mjs';
import { maskMail } from './auth.mjs';
import { isAdmin } from '../roles.mjs';
import { parsePackage } from '../package.mjs';
import { ratingsFor, ratingStats, hasDownloaded } from './community.mjs';

const VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,31}$/;

function s(v, max) {
  return String(v == null ? '' : v).trim().slice(0, max);
}

function normVersion(v) {
  const t = s(v, 32).replace(/^[vV]/, '').trim();
  if (!VERSION_RE.test(t)) {
    throw new HttpError(400, '版本号只能用字母、数字、点、下划线、加号、减号，且以字母或数字开头');
  }
  return t;
}

function parseTags(v) {
  return String(v == null ? '' : v)
    .split(/[,，\s]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 8)
    .join(',');
}

// ---------------------------------------------------------------- 前置插件
const MAX_DEPS = 20;

/** 从 from 顺着前置关系往上走，能不能走到 target（用来挡循环依赖） */
function reaches(store, from, target, seen) {
  if (from === target) return true;
  if (seen.has(from)) return false;
  seen.add(from);
  const rows = store.all('SELECT dep_id FROM plugin_deps WHERE plugin_id=?', from);
  return rows.some((r) => reaches(store, r.dep_id, target, seen));
}

/** 把前端传来的前置插件 id 列表规范化：去重、校验存在、不能依赖自己、不能成环 */
function normDeps(store, pluginId, raw) {
  if (!Array.isArray(raw)) return [];
  const ids = [];
  for (const v of raw) {
    const id = s(v, 40);
    if (!id || ids.includes(id)) continue;
    if (pluginId && id === pluginId) throw new HttpError(400, '插件不能把自己设为前置插件');
    if (!store.get('SELECT 1 AS x FROM plugins WHERE id=?', id)) throw new HttpError(400, '选择的前置插件不存在');
    ids.push(id);
  }
  if (ids.length > MAX_DEPS) throw new HttpError(400, `前置插件最多选 ${MAX_DEPS} 个`);
  if (pluginId) {
    for (const id of ids) {
      if (reaches(store, id, pluginId, new Set())) throw new HttpError(400, '前置插件形成了循环依赖，请调整');
    }
  }
  return ids;
}

export function saveDeps(store, pluginId, ids) {
  store.run('DELETE FROM plugin_deps WHERE plugin_id=?', pluginId);
  const now = Date.now();
  for (const id of ids) {
    store.run('INSERT OR IGNORE INTO plugin_deps (plugin_id, dep_id, created) VALUES (?,?,?)', pluginId, id, now);
  }
}

export function depsFor(store, pluginId) {
  return store
    .all(
      `SELECT p.id, p.name, p.version, p.author, p.offline
       FROM plugin_deps d JOIN plugins p ON p.id = d.dep_id
       WHERE d.plugin_id=? ORDER BY p.name COLLATE NOCASE ASC`,
      pluginId
    )
    .map((r) => ({ id: r.id, name: r.name, version: r.version, author: r.author, offline: !!r.offline }));
}

export function publicPlugin(p, opts = {}) {
  return {
    id: p.id,
    name: p.name,
    author: p.author,
    version: p.version,
    summary: p.summary,
    readme: opts.withReadme ? p.readme : undefined,
    tags: p.tags ? p.tags.split(',').filter(Boolean) : [],
    views: p.views,
    downloads: p.downloads,
    offline: !!p.offline,
    pinned: !!p.pinned,
    created: p.created,
    updated: p.updated,
    releaseCount: p.release_count != null ? p.release_count : undefined,
    depCount: p.dep_count != null ? p.dep_count : undefined,
    owner: opts.owner ? p.email : undefined,
    ownerMasked: maskMail(p.email),
  };
}

function parseEntries(r) {
  try {
    const list = JSON.parse(r.entries || '[]');
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function releaseInfo(r, opts = {}) {
  return {
    id: r.id,
    version: r.version,
    filename: r.filename,
    size: r.size,
    sha256: r.sha256,
    entryCount: r.entry_count,
    dllName: r.dll_name || '',
    changelog: r.changelog || '',
    created: r.created,
    entries: opts.entries ? parseEntries(r) : undefined,
  };
}

// ---------------------------------------------------------------- 上传暂存
let lastClean = 0;

function cleanStage(dirs, minutes) {
  const now = Date.now();
  if (now - lastClean < 10 * 60 * 1000) return; // 10 分钟内只扫一次
  lastClean = now;
  const maxAge = Math.max(10, Number(minutes) || 120) * 60 * 1000;
  let names = [];
  try {
    names = fs.readdirSync(dirs.tmp);
  } catch {
    return;
  }
  for (const name of names) {
    const file = path.join(dirs.tmp, name);
    try {
      if (now - fs.statSync(file).mtimeMs > maxAge) fs.unlinkSync(file);
    } catch {}
  }
}

function takeStage(c, token) {
  const u = c.mustUser();
  const t = String(token || '');
  if (!/^[a-f0-9]{16,32}$/.test(t)) throw new HttpError(400, '上传凭证不正确，请重新选择压缩包');
  const metaPath = path.join(c.dirs.tmp, t + '.json');
  const zipPath = path.join(c.dirs.tmp, t + '.zip');
  if (!fs.existsSync(metaPath) || !fs.existsSync(zipPath)) {
    throw new HttpError(400, '上传已过期，请重新选择压缩包');
  }
  let meta;
  try {
    meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
  } catch {
    throw new HttpError(400, '上传信息损坏，请重新选择压缩包');
  }
  if (meta.email !== u.email) throw new HttpError(403, '这个上传包不属于当前账户');
  if (Date.now() - meta.created > Math.max(10, Number(c.cfg.zipStageMin) || 120) * 60000) {
    try {
      fs.unlinkSync(metaPath);
      fs.unlinkSync(zipPath);
    } catch {}
    throw new HttpError(400, '上传包已过期，请重新选择');
  }
  return { meta, zipPath, metaPath };
}

/** 把暂存的 zip 落到 plugins/<id>/<version>/，写 release 行，并把插件版本推进到这一版 */
export function saveRelease(c, plugin, stage, version, changelog) {
  if (c.store.get('SELECT 1 AS x FROM releases WHERE plugin_id=? AND version=?', plugin.id, version)) {
    throw new HttpError(400, `版本 ${version} 已经发布过了，请换一个版本号`);
  }
  const now = Date.now();

  const zipName = safeFileName(`${plugin.name}_v${version}.zip`);
  const relDir = path.posix.join('plugins', plugin.id, version);
  const relPath = path.posix.join(relDir, zipName);
  const absDir = path.join(c.cfg.dataDir, relDir);
  const absPath = path.join(c.cfg.dataDir, relPath);
  fs.mkdirSync(absDir, { recursive: true });
  try {
    fs.renameSync(stage.zipPath, absPath);
  } catch {
    fs.copyFileSync(stage.zipPath, absPath);
    try {
      fs.unlinkSync(stage.zipPath);
    } catch {}
  }

  const parsed = stage.meta.parsed || {};
  try {
    c.store.run(
      `INSERT INTO releases (plugin_id, version, filename, rel_path, size, sha256, entry_count, dll_name, entries, changelog, created)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      plugin.id,
      version,
      zipName,
      relPath,
      stage.meta.size,
      stage.meta.sha256,
      parsed.entryCount || 0,
      parsed.dllName || '',
      JSON.stringify(parsed.entries || []),
      s(changelog, 500),
      now
    );
    c.store.run('UPDATE plugins SET version=?, updated=? WHERE id=?', version, now, plugin.id);
  } catch (e) {
    // 落库失败：把包挪回暂存区，用户可以直接重试而不必重新上传
    try {
      fs.renameSync(absPath, stage.zipPath);
    } catch {}
    try {
      fs.rmSync(absDir, { recursive: true, force: true });
    } catch {}
    throw e;
  }
  try {
    fs.unlinkSync(stage.metaPath);
  } catch {}

  const row = c.store.get('SELECT * FROM releases WHERE plugin_id=? AND version=?', plugin.id, version);
  return row;
}

export default function register(router) {
  // ---------------- 市场列表 ----------------
  router.get('/api/plugins', (c) => {
    const q = s(c.query.get('q'), 60);
    const tag = s(c.query.get('tag'), 20);
    const sort = s(c.query.get('sort'), 16) || 'newest';
    const page = Math.max(1, Number(c.query.get('page')) || 1);
    const size = Math.min(48, Math.max(1, Number(c.query.get('size')) || 12));

    const where = ['offline = 0'];
    const args = [];
    if (q) {
      where.push('(name LIKE ? OR author LIKE ? OR summary LIKE ? OR tags LIKE ?)');
      const like = `%${q}%`;
      args.push(like, like, like, like);
    }
    if (tag) {
      where.push('tags LIKE ?');
      args.push(`%${tag}%`);
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const sortSql =
      {
        newest: 'created DESC',
        updated: 'updated DESC',
        downloads: 'downloads DESC, views DESC',
        views: 'views DESC, downloads DESC',
        name: 'name COLLATE NOCASE ASC',
        rating:
          '(SELECT COALESCE(AVG(stars),0) FROM ratings WHERE plugin_id = plugins.id) DESC, ' +
          '(SELECT COUNT(*) FROM ratings WHERE plugin_id = plugins.id) DESC',
      }[sort] || 'created DESC';

    const total = c.store.get(`SELECT COUNT(*) AS n FROM plugins ${whereSql}`, ...args).n;
    const rows = c.store.all(
      `SELECT *,
         (SELECT COUNT(*) FROM releases r WHERE r.plugin_id = plugins.id) AS release_count,
         (SELECT COUNT(*) FROM plugin_deps d WHERE d.plugin_id = plugins.id) AS dep_count
       FROM plugins ${whereSql} ORDER BY pinned DESC, ${sortSql} LIMIT ? OFFSET ?`,
      ...args,
      size,
      (page - 1) * size
    );

    const tagRows = c.store.all("SELECT tags FROM plugins WHERE offline=0 AND tags <> ''");
    const tagCount = new Map();
    for (const r of tagRows) {
      for (const t of r.tags.split(',').filter(Boolean)) tagCount.set(t, (tagCount.get(t) || 0) + 1);
    }
    const tags = [...tagCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24).map(([name, n]) => ({ name, n }));

    const ratings = ratingsFor(c.store, rows.map((r) => r.id));

    return {
      items: rows.map((r) => ({ ...publicPlugin(r), rating: ratings.get(r.id) || { avg: 0, count: 0 } })),
      total,
      page,
      size,
      pages: Math.max(1, Math.ceil(total / size)),
      tags,
    };
  });

  // ---------------- 站点统计 ----------------
  router.get('/api/stats', (c) => {
    const g = (sql, ...a) => c.store.get(sql, ...a);
    return {
      plugins: g('SELECT COUNT(*) AS n FROM plugins WHERE offline=0').n,
      downloads: g('SELECT COALESCE(SUM(downloads),0) AS n FROM plugins').n,
      views: g('SELECT COALESCE(SUM(views),0) AS n FROM plugins').n,
      developers: g('SELECT COUNT(DISTINCT email) AS n FROM plugins').n,
      users: g('SELECT COUNT(*) AS n FROM users').n,
    };
  });

  // ---------------- 前置插件候选列表（上传 / 编辑时选前置用）----------------
  router.get('/api/plugin-options', (c) => {
    c.mustUser();
    const rows = c.store.all(
      `SELECT id, name, version, author, offline FROM plugins
       ORDER BY pinned DESC, name COLLATE NOCASE ASC LIMIT 500`
    );
    return {
      items: rows.map((r) => ({ id: r.id, name: r.name, version: r.version, author: r.author, offline: !!r.offline })),
    };
  });

  // ---------------- 包解析暂存：返回自动识别出的名称 / 版本 / 包内文件 ----------------
  router.post('/api/inspect', async (c) => {
    const u = c.mustUser();
    cleanStage(c.dirs, c.cfg.zipStageMin);

    const filename = safeFileName(c.query.get('name') || 'plugin.zip');
    if (!/\.zip$/i.test(filename)) throw new HttpError(400, '插件只支持 .zip 压缩包');
    const limit = (Number(c.cfg.maxUploadMB) || 32) * 1048576;
    const buf = await readBody(c.req, limit);
    if (!buf.length) throw new HttpError(400, '上传内容为空');
    if (buf[0] !== 0x50 || buf[1] !== 0x4b) throw new HttpError(400, '这个文件不是 zip 压缩包');

    let parsed;
    try {
      parsed = parsePackage(buf, filename);
    } catch (e) {
      throw new HttpError(400, '解析压缩包失败：' + e.message);
    }

    const token = newId();
    fs.writeFileSync(path.join(c.dirs.tmp, token + '.zip'), buf);
    fs.writeFileSync(
      path.join(c.dirs.tmp, token + '.json'),
      JSON.stringify({
        email: u.email,
        filename,
        size: buf.length,
        sha256: sha256(buf),
        parsed,
        created: Date.now(),
      })
    );
    return { ok: true, token, filename, size: buf.length, parsed };
  });

  // ---------------- 发布新插件（zip 已在暂存区）----------------
  router.post('/api/plugins', async (c) => {
    const u = c.mustUser();
    const b = await c.json();
    const stage = takeStage(c, b.token);

    const name = s(b.name, 60) || (stage.meta.parsed && stage.meta.parsed.name) || '';
    if (!name) throw new HttpError(400, '请填写插件名称');
    const author = s(b.author, 40) || (u.qq ? `QQ ${u.qq}` : u.email.split('@')[0]);
    const version = normVersion(s(b.version, 32) || (stage.meta.parsed && stage.meta.parsed.version) || '');
    const summary = s(b.summary, 200);
    const readme = String(b.readme == null ? '' : b.readme).slice(0, 40000);
    const tags = parseTags(b.tags);

    const id = newId();
    const now = Date.now();
    try {
      c.store.run(
        `INSERT INTO plugins (id, email, name, author, version, summary, readme, tags, created, updated)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        id,
        u.email,
        name,
        author,
        version,
        summary,
        readme,
        tags,
        now,
        now
      );
      const plugin = c.store.get('SELECT * FROM plugins WHERE id=?', id);
      saveDeps(c.store, id, normDeps(c.store, id, b.deps));
      const rel = saveRelease(c, plugin, stage, version, b.changelog);
      return {
        ok: true,
        id,
        plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', id), { owner: true }),
        release: releaseInfo(rel),
      };
    } catch (e) {
      try {
        c.store.run('DELETE FROM plugin_deps WHERE plugin_id=?', id);
        c.store.run('DELETE FROM releases WHERE plugin_id=?', id);
        c.store.run('DELETE FROM plugins WHERE id=?', id);
        fs.rmSync(path.join(c.cfg.dataDir, 'plugins', id), { recursive: true, force: true });
      } catch {}
      throw e;
    }
  });

  // ---------------- 发布新版本 ----------------
  router.post('/api/plugins/:id/releases', async (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.email !== u.email) throw new HttpError(403, '只能给自己上传的插件发布新版本');

    const b = await c.json();
    const stage = takeStage(c, b.token);
    const version = normVersion(s(b.version, 32) || (stage.meta.parsed && stage.meta.parsed.version) || '');
    const rel = saveRelease(c, p, stage, version, b.changelog);
    return {
      ok: true,
      release: releaseInfo(rel, { entries: true }),
      plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', p.id), { owner: true }),
    };
  });

  // ---------------- 修改资料（版本号由发布决定，不在这里改）----------------
  router.patch('/api/plugins/:id', async (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.email !== u.email) throw new HttpError(403, '只能修改自己上传的插件');
    const b = await c.json();
    const name = s(b.name, 60) || p.name;
    const author = s(b.author, 40) || p.author;
    const summary = b.summary === undefined ? p.summary : s(b.summary, 200);
    const readme = b.readme === undefined ? p.readme : String(b.readme || '').slice(0, 40000);
    const tags = b.tags === undefined ? p.tags : parseTags(b.tags);
    c.store.run(
      'UPDATE plugins SET name=?, author=?, summary=?, readme=?, tags=?, updated=? WHERE id=?',
      name,
      author,
      summary,
      readme,
      tags,
      Date.now(),
      p.id
    );
    if (b.deps !== undefined) saveDeps(c.store, p.id, normDeps(c.store, p.id, b.deps));
    return {
      ok: true,
      plugin: { ...publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', p.id), { owner: true }), deps: depsFor(c.store, p.id) },
    };
  });

  // ---------------- 删除插件 ----------------
  router.delete('/api/plugins/:id', (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.email !== u.email && !isAdmin(c.store, u)) throw new HttpError(403, '只能删除自己上传的插件');
    try {
      fs.rmSync(path.join(c.cfg.dataDir, 'plugins', p.id), { recursive: true, force: true });
    } catch {}
    c.store.tx(() => {
      c.store.run('DELETE FROM releases WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM comments WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM messages WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM ratings WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM view_logs WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM download_logs WHERE plugin_id=?', p.id);
      c.store.run('DELETE FROM plugin_deps WHERE plugin_id=? OR dep_id=?', p.id, p.id);
      c.store.run('DELETE FROM plugins WHERE id=?', p.id);
    });
    return { ok: true };
  });

  // ---------------- 下架 / 重新上架（作者或管理员）----------------
  router.post('/api/plugins/:id/offline', async (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    const admin = isAdmin(c.store, u);
    if (p.email !== u.email && !admin) throw new HttpError(403, '无权操作这个插件');

    const b = await c.json().catch(() => ({}));
    const want = b && b.offline !== undefined ? !!b.offline : !p.offline;
    if (want === !!p.offline) {
      return { ok: true, offline: want, plugin: publicPlugin(p, { owner: true }) };
    }
    const now = Date.now();
    c.store.run('UPDATE plugins SET offline=?, updated=? WHERE id=?', want ? 1 : 0, now, p.id);
    // 管理员操作时通知作者（自己操作自己插件不通知）
    if (admin && p.email !== u.email) {
      c.store.run(
        'INSERT INTO messages (to_email, plugin_id, comment_id, kind, body, created) VALUES (?,?,0,?,?,?)',
        p.email,
        p.id,
        'system',
        `你的插件《${p.name}》已被管理员${want ? '下架' : '重新上架'}。`,
        now
      );
    }
    return {
      ok: true,
      offline: want,
      plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', p.id), { owner: true }),
    };
  });

  // ---------------- 我的插件 ----------------
  router.get('/api/my/plugins', (c) => {
    const u = c.mustUser();
    const rows = c.store.all('SELECT * FROM plugins WHERE email = ? ORDER BY updated DESC', u.email);
    const items = rows.map((p) => {
      const releases = c.store.all('SELECT * FROM releases WHERE plugin_id=? ORDER BY created DESC', p.id).map((r) =>
        releaseInfo(r, { entries: true })
      );
      const comments = c.store.get('SELECT COUNT(*) AS n FROM comments WHERE plugin_id=? AND deleted=0', p.id).n;
      const unread = c.store.get(
        "SELECT COUNT(*) AS n FROM messages WHERE to_email=? AND plugin_id=? AND is_read=0 AND kind NOT IN ('review','report','devreply','role')",
        u.email,
        p.id
      ).n;
      return {
        ...publicPlugin(p, { owner: true, withReadme: true }),
        releases,
        releaseCount: releases.length,
        commentCount: comments,
        unread,
        deps: depsFor(c.store, p.id),
      };
    });
    const unreadAll = c.store.get(
      "SELECT COUNT(*) AS n FROM messages WHERE to_email=? AND is_read=0 AND kind NOT IN ('review','report','devreply','role')",
      u.email
    ).n;
    return { items, unread: unreadAll };
  });

  // ---------------- 详情（含查看计数）----------------
  router.get('/api/plugins/:id', (c) => {
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    const isOwner = !!c.user && c.user.email === p.email;
    const admin = isAdmin(c.store, c.user);
    if (p.offline && !isOwner && !admin) throw new HttpError(403, '该插件已被管理员下架');

    // 查看计数：同一访客在 viewDedupeSec 内只记一次
    const viewer = c.user ? c.user.email : c.ip || 'anon';
    const now = Date.now();
    const seen = c.store.get('SELECT created FROM view_logs WHERE plugin_id=? AND viewer=?', p.id, viewer);
    if (!seen) {
      c.store.run('INSERT INTO view_logs (plugin_id, viewer, created) VALUES (?,?,?)', p.id, viewer, now);
      c.store.run('UPDATE plugins SET views = views + 1 WHERE id = ?', p.id);
      p.views += 1;
    } else if (now - seen.created > (Number(c.cfg.viewDedupeSec) || 3600) * 1000) {
      c.store.run('UPDATE view_logs SET created=? WHERE plugin_id=? AND viewer=?', now, p.id, viewer);
      c.store.run('UPDATE plugins SET views = views + 1 WHERE id = ?', p.id);
      p.views += 1;
    }

    const releases = c.store
      .all('SELECT * FROM releases WHERE plugin_id = ? ORDER BY created DESC', p.id)
      .map((r) => releaseInfo(r, { entries: true }));
    const commentCount = c.store.get('SELECT COUNT(*) AS n FROM comments WHERE plugin_id=? AND deleted=0', p.id).n;

    let myRating = 0;
    let canRate = false;
    let rateHint = '';
    if (c.user) {
      const mine = c.store.get('SELECT stars FROM ratings WHERE plugin_id=? AND email=?', p.id, c.user.email);
      myRating = mine ? mine.stars : 0;
      const isOwnerSelf = c.user.email === p.email;
      const downloaded = hasDownloaded(c.store, p.id, c.user.email);
      canRate = !isOwnerSelf && downloaded;
      rateHint = isOwnerSelf ? '不能给自己的插件评分' : downloaded ? '' : '下载过之后才能评分';
    }

    return {
      plugin: publicPlugin(p, { withReadme: true, owner: isOwner }),
      releases,
      releaseCount: releases.length,
      commentCount,
      deps: depsFor(c.store, p.id),
      isOwner,
      canManage: admin,
      rating: ratingStats(c.store, p.id),
      myRating,
      canRate,
      rateHint,
    };
  });

  // ---------------- 下载入口 ----------------
  const latestRelease = (store, p) =>
    store.get('SELECT * FROM releases WHERE plugin_id=? AND version=? ORDER BY created DESC LIMIT 1', p.id, p.version) ||
    store.get('SELECT * FROM releases WHERE plugin_id=? ORDER BY created DESC LIMIT 1', p.id);

  router.get('/api/plugins/:id/download', (c) => {
    const u = c.mustUser();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', c.params.id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.offline && p.email !== u.email && !isAdmin(c.store, u)) throw new HttpError(403, '该插件已被管理员下架');
    const r = latestRelease(c.store, p);
    if (!r) throw new HttpError(404, '这个插件还没有可下载的版本');
    c.res.writeHead(302, { Location: `/api/releases/${r.id}/download`, 'Cache-Control': 'no-store' });
    c.res.end();
    return null;
  });

  router.get('/api/releases/:id/download', (c) => {
    const u = c.mustUser();
    const r = c.store.get('SELECT * FROM releases WHERE id = ?', Number(c.params.id));
    if (!r) throw new HttpError(404, '版本不存在');
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', r.plugin_id);
    if (!p) throw new HttpError(404, '插件不存在');
    if (p.offline && p.email !== u.email && !isAdmin(c.store, u)) throw new HttpError(403, '该插件已被管理员下架');
    const abs = path.join(c.cfg.dataDir, r.rel_path);
    if (!fs.existsSync(abs)) throw new HttpError(410, '文件已丢失，请联系作者重新上传');

    c.store.tx(() => {
      c.store.run('UPDATE plugins SET downloads = downloads + 1 WHERE id = ?', p.id);
      c.store.run(
        'INSERT INTO download_logs (plugin_id, release_id, version, email, ip, created) VALUES (?,?,?,?,?,?)',
        p.id,
        r.id,
        r.version,
        u.email,
        c.ip || '',
        Date.now()
      );
    });
    c.helpers.sendFileDownload(c.res, abs, r.filename);
    return null;
  });
}
