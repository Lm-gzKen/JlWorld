@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem first-run: ask for the first allowed login account (no-op after configured)
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0tools\setup-login.js"
) else (
  node "%~dp0tools\setup-login.js"
)
if errorlevel 1 (
  echo.
  echo [ERROR] Login scope setup failed. Check the message above.
  pause
  exit /b 1
)
rem kill old -> start -> wait -> print URL -> open panel (add -NoOpen to skip browser)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\start-panel.ps1" %*
if errorlevel 1 pause
