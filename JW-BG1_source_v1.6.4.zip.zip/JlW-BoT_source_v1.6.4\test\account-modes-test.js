'use strict';
/**
 * 账户连接开关：启用 / 自动连接 / 异常重连
 * 覆盖：
 *  1) 配置默认值与 PATCH 持久化；
 *  2) 启动时只自动连接「启用 + 自动连接」的账户，其余跳过并写日志；
 *  3) 关闭异常重连后掉线不再自动重连，重新打开立即补连；
 *  4) 进程内重启（=定时重启）后，自动连接开启的账户会重新上线。
 * 运行：node test/account-modes-test.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 20000, interval = 200, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

(async () => {
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };

  /* ---------- 1. 配置层 ---------- */
  const Config = require('../src/core/config');
  const cfgs = [['A', { id: 'a', enabled: true }], ['B', { id: 'b', autoConnect: false }], ['C', { id: 'c', autoReconnect: false }]];
  for (const [label, acc] of cfgs) {
    const norm = Config.prototype._normalizeAccounts.call(
      { defaults: { bot: {} } },
      { bot: {} },
      [{ ...acc, name: label, appId: 'x', clientSecret: 'y', intents: [] }],
    )[0];
    if (label === 'A') check(norm.autoConnect === true && norm.autoReconnect === true, '默认开启自动连接 / 异常重连');
    if (label === 'B') check(norm.autoConnect === false && norm.autoReconnect === true, 'autoConnect=false 被保留');
    if (label === 'C') check(norm.autoReconnect === false && norm.autoConnect === true, 'autoReconnect=false 被保留');
  }
  // 新建账户（不传开关）默认三项全开
  const cfgDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-cfg-'));
  const prevDataDir = process.env.JLW_DATA_DIR;
  process.env.JLW_DATA_DIR = cfgDir;
  try {
    const created = new Config().addAccount({ name: '新号', appId: 'app_x', clientSecret: 'sec_x', intents: [] });
    check(
      created.enabled === true && created.autoConnect === true && created.autoReconnect === true,
      '新建账户默认启用、自动连接、异常重连全开',
    );
  } finally {
    if (prevDataDir === undefined) delete process.env.JLW_DATA_DIR;
    else process.env.JLW_DATA_DIR = prevDataDir;
    try {
      fs.rmSync(cfgDir, { recursive: true, force: true });
    } catch {}
  }

  /* ---------- 2. 网关层：关闭异常重连 ---------- */
  const Gateway = require('../src/core/gateway');
  const silent = { info() {}, warn() {}, error() {}, debug() {} };
  const mkGw = () =>
    new Gateway({
      config: { accountId: 't', get: (k, d) => d },
      token: {},
      logger: { child: () => silent },
      api: {},
    });
  const gw = mkGw();
  gw.autoReconnect = false;
  gw._onClose(1006, '网络断开');
  check(gw.state === 'closed', '异常重连关闭时掉线进入 closed');
  check(!gw.reconnectTimer, '异常重连关闭时不排重连定时器');
  const gw2 = mkGw();
  gw2._onClose(1006, '网络断开');
  check(gw2.state === 'reconnecting' && !!gw2.reconnectTimer, '异常重连开启时掉线自动重连');
  clearTimeout(gw2.reconnectTimer);

  /* ---------- 3. 端到端 ---------- */
  const mock = await new MockQQ({ port: 0, accounts: { app_a: 'sec_a', app_b: 'sec_b' } }).start();
  const jlw = await new MockJlw({ port: 0 }).start();
  const port = 21800 + Math.floor(Math.random() * 300);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-modes-'));
  const common = {
    mode: 'ws',
    sandbox: false,
    tokenUrl: mock.base + '/app/getAppAccessToken',
    tokenUrlAlt: mock.base + '/app/getAppAccessToken',
    apiBase: mock.base,
    apiBaseSandbox: mock.base,
    gatewayUrl: mock.wsUrl,
    intents: ['GUILDS'],
    shardId: 0,
    shardCount: 1,
    prefix: '/',
  };
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        accounts: [
          { ...common, id: 'a1', name: '自动号', appId: 'app_a', clientSecret: 'sec_a', enabled: true },
          { ...common, id: 'b1', name: '手动号', appId: 'app_b', clientSecret: 'sec_b', enabled: true, autoConnect: false },
          { ...common, id: 'c1', name: '停用号', appId: 'app_b', clientSecret: 'sec_b', enabled: false },
        ],
        plugins: { enabled: false },
        log: { level: 'info', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  let cookie = '';
  const call = async (p, opts = {}) => {
    const res = await fetch(base + p, {
      method: opts.method || 'GET',
      headers: { ...(cookie ? { Cookie: cookie } : {}), ...(opts.body ? { 'Content-Type': 'application/json' } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* ignore */
    }
    return { status: res.status, data };
  };
  const status = async () => (await call('/api/status')).data;
  const accOf = (s, id) => (s.accounts || []).find((a) => a.id === id) || {};

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 25000, 250, '面板启动');
    const loginRes = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    const rawCookie = (loginRes.headers.getSetCookie ? loginRes.headers.getSetCookie()[0] : loginRes.headers.get('set-cookie')) || '';
    cookie = rawCookie.split(';')[0];
    check(loginRes.status === 200 && cookie.includes('jlw_sid='), '面板登录成功');

    const s1 = await waitFor(async () => {
      const s = await status();
      return accOf(s, 'a1').state === 'online' ? s : null;
    }, 25000, 250, '自动号上线');
    check(accOf(s1, 'a1').autoConnect === true && accOf(s1, 'a1').autoReconnect === true, '/api/status 暴露自动连接/异常重连');
    check(accOf(s1, 'b1').state !== 'online' && !accOf(s1, 'b1').startedAt, '未开启自动连接的账户启动时不连接');
    check(accOf(s1, 'c1').state !== 'online' && !accOf(s1, 'c1').startedAt, '停用账户启动时不连接');
    check(accOf(s1, 'c1').enabled === false, '停用状态可见');

    // 关闭异常重连：模拟网关断开（4009），应停在 closed 且不自动重连
    const off = await call('/api/accounts/a1', { method: 'PATCH', body: { autoReconnect: false } });
    check(off.status === 200 && off.data.account.autoReconnect === false, '关闭异常重连后状态立即保存');
    const before = accOf(await status(), 'a1').gateway?.reconnects || 0;
    for (const c of mock.clients) {
      try {
        c.close(4009);
      } catch {
        /* ignore */
      }
    }
    await waitFor(async () => accOf(await status(), 'a1').state === 'closed', 10000, 200, '掉线后 closed');
    check(true, '异常重连关闭后掉线停在已断开');
    await sleep(5000);
    const s2 = await status();
    check(accOf(s2, 'a1').state === 'closed', '5 秒后仍不会自动重连');
    check((accOf(s2, 'a1').gateway?.reconnects || 0) === before, '异常重连关闭期间没有产生重连尝试');

    // 重新打开异常重连：应立即补连成功
    await call('/api/accounts/a1', { method: 'PATCH', body: { autoReconnect: true } });
    await waitFor(async () => accOf(await status(), 'a1').state === 'online', 30000, 250, '重新打开异常重连后上线');
    check(true, '重新打开异常重连后立刻补连上线');

    // 进程内重启（定时重启走同一条路）：自动号应重新上线，手动号仍不连
    const rs = await call('/api/system/restart', { method: 'POST', body: {} });
    check(rs.status === 200 && rs.data.restarting === true, '触发进程内重启');
    await sleep(1500);
    const s3 = await waitFor(async () => {
      const s = await status();
      return accOf(s, 'a1').state === 'online' ? s : null;
    }, 30000, 300, '重启后自动号重新上线');
    check(true, '重启后自动连接的账户重新上线');
    check(accOf(s3, 'b1').state !== 'online' && !accOf(s3, 'b1').startedAt, '重启后未开启自动连接的账户仍不连接');
  } finally {
    child.kill();
    await sleep(300);
    await jlw.stop();
    await mock.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
