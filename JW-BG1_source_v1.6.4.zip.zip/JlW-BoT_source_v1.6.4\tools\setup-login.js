#!/usr/bin/env node
'use strict';
/**
 * 首次运行登录范围设置（供 启动机器人.cmd 在启动前调用）。
 * 已配置时静默退出；未配置时在控制台要求输入第一个聚龙账户邮箱。
 * 也可：node tools/setup-login.js --allow-email you@example.com
 */
const Config = require('../src/core/config');
const { ensureFirstAllowed } = require('../src/core/login-scope');

const argv = process.argv.slice(2);
let allowEmail = '';
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === '--allow-email' && argv[i + 1]) allowEmail = argv[++i];
}

(async () => {
  const config = new Config();
  const r = await ensureFirstAllowed(config, { allowEmail });
  if (!r.ok && !r.printed) console.error(r.message || '登录范围设置失败：' + (r.error || '未知错误'));
  process.exit(r.ok ? 0 : 1);
})().catch((e) => {
  console.error('登录范围设置失败：' + (e.stack || e.message));
  process.exit(1);
});
