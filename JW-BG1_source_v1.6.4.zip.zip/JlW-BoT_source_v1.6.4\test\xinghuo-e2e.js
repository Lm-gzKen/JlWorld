'use strict';
/**
 * 星火插件 · 端到端测试（假 QQ + 假聚龙账户 + 假 VloS 插件 + 真实框架进程）
 *
 *   node test/xinghuo-e2e.js
 *
 * 覆盖：
 *   1. 插件加载、设置页快照注入；
 *   2. C2C / FRIEND_ADD / GROUP_ADD_ROBOT 事件自动收 openid；
 *   3. 设置页 config.tasks：zip 导入（这里直接传行）、生成兑换码、发公告；
 *   4. /xh 兑换码 → 假 VloS addVlosBalance 到账、码失效、重复兑换被拒；
 *   5. 同一份 config 再保存一次 → 任务不重复执行（幂等）；
 *   6. 公告通过框架 /plugin-api/v1/action 主动私聊全部好友；
 *   7. 发送失败好友标记无效；SQLite / JSON 双驱动与切库导出。
 */

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const MockQQ = require('./mock-qq');
const MockJlw = require('./mock-jlw');

const ROOT = path.resolve(__dirname, '..');
const PLUGIN_SRC = process.env.XH_PLUGIN_SRC ? path.resolve(process.env.XH_PLUGIN_SRC) : path.join(ROOT, 'plugins', 'xinghuo');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 12000, interval = 150, label = 'condition') {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
      last = v;
    } catch (e) {
      last = e.message;
    }
    await sleep(interval);
  }
  throw new Error(`等待超时：${label}（最后结果：${JSON.stringify(last)}）`);
}

function writeFakeVlos(dir) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(
    path.join(dir, 'plugin.json'),
    JSON.stringify(
      {
        id: 'VloS',
        name: 'VloS 测试桩',
        version: '2.9.56',
        author: 'test',
        description: '假 VloS 对外 API',
        enabled: true,
        type: 'js',
        priority: 60,
        events: ['*'],
        commands: [],
        timeout: 5000,
        entry: 'index.js',
        config: {},
      },
      null,
      2,
    ),
    'utf8',
  );
  const src = `
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const FILE = path.join(__dirname, 'credits.json');

const baseUsers = {
  U_C2C_OPENID: { key: 'u1', email: 'u1@test.local', qq: '10001', name: '小星', wallet: { longjing: 10, xuanyu: 1 }, vlosBalance: { longjing: 2, xuanyu: 0 }, balances: { longjing: 0, xuanyu: 0 } },
  U_FRIEND_OPENID: { key: 'u2', email: 'u2@test.local', qq: '10002', name: '好友二', wallet: { longjing: 20, xuanyu: 2 }, vlosBalance: { longjing: 0, xuanyu: 0 }, balances: { longjing: 0, xuanyu: 0 } },
  U_IMPORT_OPENID: { key: 'u3', email: 'u3@test.local', qq: '10003', name: '导入三', wallet: { longjing: 30, xuanyu: 3 }, vlosBalance: { longjing: 1, xuanyu: 0 }, balances: { longjing: 0, xuanyu: 0 } },
};
const users = {};
for (const u of Object.values(baseUsers)) {
  users[u.key.toUpperCase()] = u;
  users[u.email.toUpperCase()] = u;
  users[u.qq] = u;
}
for (const [k, u] of Object.entries(baseUsers)) users[k] = u;

function load() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return { credits: [], wallets: {} }; }
}
function save(state) { fs.writeFileSync(FILE, JSON.stringify(state, null, 2), 'utf8'); }
function walletOf(u, state) { return state.wallets[u.key] || { ...u.wallet }; }
function pub(u, state) {
  return { ...u, wallet: walletOf(u, state), vlosBalance: { ...u.vlosBalance }, balances: { ...u.balances } };
}
function find(v) {
  const s = String(v == null ? '' : v).trim();
  return users[s.toUpperCase()] || users[s] || null;
}

module.exports = {
  onLoad(ctx) {
    let state = load();
    const api = {
      pluginId: 'VloS',
      version: '2.9.56',
      isReady: () => true,
      getUser: (v) => { const u = find(v); return u ? pub(u, state) : null; },
      wallet: (v) => { const u = find(v); return u ? walletOf(u, state) : null; },
      vlosBalance: (v) => { const u = find(v); return u ? { ...u.vlosBalance } : null; },
      balance: (v) => { const u = find(v); return u ? { ...u.balances } : null; },
      stats: () => ({
        users: 3, bound: 3, signedToday: 0,
        pendingLongjing: 3, pendingXuanyu: 0,
        walletLongjing: 60, walletXuanyu: 6,
        longjing: 0, xuanyu: 0,
      }),
      listUsers: () => ({ total: 3, users: Object.values(baseUsers).map((u) => pub(u, state)) }),
      async addWallet(v, delta, options) {
        const u = find(v);
        if (!u) { const e = new Error('VloS：找不到该用户'); e.code = 'NOT_FOUND'; throw e; }
        const w = walletOf(u, state);
        const after = { longjing: (w.longjing || 0) + (delta.longjing || 0), xuanyu: (w.xuanyu || 0) + (delta.xuanyu || 0) };
        state.wallets[u.key] = after;
        state.credits.push({ at: Date.now(), key: u.key, email: u.email, delta: { ...delta }, after: { ...after }, reason: options && options.reason });
        save(state);
        return { key: u.key, before: w, after: { ...after }, wallet: { ...after }, delta: { ...delta } };
      },
      addVlosBalance(v, delta, options) {
        const u = find(v);
        if (!u) { const e = new Error('VloS：找不到该用户'); e.code = 'NOT_FOUND'; throw e; }
        u.vlosBalance.longjing += delta.longjing || 0;
        u.vlosBalance.xuanyu += delta.xuanyu || 0;
        const p = pub(u, state);
        state.credits.push({ at: Date.now(), key: u.key, email: u.email, delta: { ...delta }, vlos: true, reason: options && options.reason });
        save(state);
        return { key: u.key, delta: { ...delta }, before: { longjing: 0, xuanyu: 0 }, after: { ...u.vlosBalance }, user: p };
      },
    };
    const g = globalThis;
    if (!(g.__JLWBOT_PLUGIN_APIS__ instanceof Map)) g.__JLWBOT_PLUGIN_APIS__ = new Map();
    g.__JLWBOT_PLUGIN_APIS__.set('VloS', api);
    ctx.log.info('假 VloS API 已注册');
  },
  onUnload() {
    try { globalThis.__JLWBOT_PLUGIN_APIS__?.delete('VloS'); } catch {}
  },
};
`;
  fs.writeFileSync(path.join(dir, 'index.js'), src, 'utf8');
}

function readStore(dataDir) {
  const vsqlDb = path.join(dataDir, 'plugins', 'VSQL', 'data', 'dbs', 'shared.db');
  if (fs.existsSync(vsqlDb)) {
    return require('../plugins/xinghuo/lib/sqlite-store').readData(vsqlDb, { prefix: 'xinghuo_' });
  }
  const base = path.join(dataDir, 'plugins', 'xinghuo', 'data');
  return JSON.parse(fs.readFileSync(path.join(base, 'xinghuo.json'), 'utf8'));
}
function readSnapshot(dataDir) {
  const html = fs.readFileSync(path.join(dataDir, 'plugins', 'xinghuo', 'settings.html'), 'utf8');
  const m = /<script id="xh-data" type="application\/json">([\s\S]*?)<\/script>/.exec(html);
  assert.ok(m, 'settings.html 里应有 xh-data 快照');
  return JSON.parse(m[1]);
}
function readManifest(dataDir) {
  return JSON.parse(fs.readFileSync(path.join(dataDir, 'plugins', 'xinghuo', 'plugin.json'), 'utf8'));
}

async function main() {
  const storageDriver = 'vsql';
  console.log('\n星火插件端到端测试（存储：VSQL shared）\n');

  const mock = await new MockQQ({ port: 0, accounts: { app_xh: 'sec_xh' } }).start();
  const jlwMock = await new MockJlw({ port: 0 }).start();
  const panelPort = 24000 + Math.floor(Math.random() * 500);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-xinghuo-'));
  const pluginDir = path.join(dataDir, 'plugins', 'xinghuo');

  fs.mkdirSync(path.join(dataDir, 'plugins'), { recursive: true });
  fs.writeFileSync(path.join(dataDir, 'plugins', '.seeded'), 'test\n', 'utf8');
  fs.cpSync(PLUGIN_SRC, pluginDir, { recursive: true });
  fs.rmSync(path.join(pluginDir, 'data'), { recursive: true, force: true });
  const vsqlDir = path.join(dataDir, 'plugins', 'VSQL');
  fs.cpSync(path.join(ROOT, 'plugins', 'VSQL'), vsqlDir, { recursive: true });
  fs.rmSync(path.join(vsqlDir, 'data'), { recursive: true, force: true });
  const vsqlManifestFile = path.join(vsqlDir, 'plugin.json');
  const vsqlManifest = JSON.parse(fs.readFileSync(vsqlManifestFile, 'utf8'));
  vsqlManifest.config = {
    ...(vsqlManifest.config || {}),
    http: { ...((vsqlManifest.config || {}).http || {}), enabled: false },
    injectSettings: false,
    admin: { ...((vsqlManifest.config || {}).admin || {}), enabled: false },
  };
  fs.writeFileSync(vsqlManifestFile, JSON.stringify(vsqlManifest, null, 2), 'utf8');
  const manifestFile = path.join(pluginDir, 'plugin.json');
  const seededManifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
  fs.writeFileSync(manifestFile, JSON.stringify(seededManifest, null, 2), 'utf8');
  writeFakeVlos(path.join(dataDir, 'plugins', 'VloS'));

  const common = {
    mode: 'ws',
    sandbox: false,
    tokenUrl: mock.base + '/app/getAppAccessToken',
    tokenUrlAlt: mock.base + '/app/getAppAccessToken',
    apiBase: mock.base,
    apiBaseSandbox: mock.base,
    gatewayUrl: mock.wsUrl,
    intents: ['GUILDS', 'GROUP_AND_C2C_EVENT'],
    shardId: 0,
    shardCount: 1,
    enabled: true,
  };
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port: panelPort, openBrowser: false },
        jlw: { baseUrl: jlwMock.base, insecureTls: false },
        accounts: [{ ...common, id: 'a1', name: '星火测试', appId: 'app_xh', clientSecret: 'sec_xh', prefix: '/' }],
        plugins: { enabled: true, defaultTimeoutMs: 15000 },
        log: { level: 'info', console: false },
        storage: { messages: false, events: 100 },
      },
      null,
      2,
    ),
    'utf8',
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  const childLog = [];
  child.stdout.on('data', (d) => childLog.push(String(d)));
  child.stderr.on('data', (d) => childLog.push(String(d)));

  const base = `http://127.0.0.1:${panelPort}`;
  const headers = { 'Content-Type': 'application/json' };
  let passed = 0;
  const ok = (cond, label) => {
    assert.ok(cond, label);
    console.log('  ✓ ' + label);
    passed++;
  };

  try {
    await waitFor(async () => (await fetch(base + '/health')).ok, 20000, 200, '框架启动');
    ok(true, '框架启动');

    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    assert.equal(login.status, 200, '面板登录失败');
    const setCookie = (login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '';
    headers.Cookie = setCookie.split(';')[0];
    ok(!!headers.Cookie, '面板登录');

    const plugins = await waitFor(async () => {
      const r = await fetch(base + '/api/plugins', { headers });
      const d = await r.json();
      const xh = (d.plugins || []).find((p) => p.id === 'xinghuo');
      const vl = (d.plugins || []).find((p) => p.id === 'VloS');
      return xh && xh.status === 'running' && vl && vl.status === 'running' ? { xh, vl } : null;
    }, 20000, 200, '星火 / VloS 加载');
    ok(plugins.xh.hasSettings, '星火 settings.html 存在');
    ok(true, '星火与 VloS 测试桩均已 running');

    await waitFor(() => mock.identifies.app_xh, 20000, 200, '机器人上线');
    ok(true, '机器人网关已 identify');

    // 1) C2C 帮助
    mock.push('C2C_MESSAGE_CREATE', {
      id: 'MSG_HELP_1',
      content: '/xh 帮助',
      author: { user_openid: 'U_C2C_OPENID', username: '小星', bot: false },
      timestamp: new Date().toISOString(),
    }, { appId: 'app_xh', seq: 101 });
    const help = await waitFor(() => mock.sent.find((s) => s.body && s.body.msg_id === 'MSG_HELP_1'), 10000, 100, '帮助回复');
    assert.ok(help.body.markdown && /兑换码/.test(help.body.markdown.content), '帮助回复应包含兑换码说明');
    ok(help.path === '/v2/users/U_C2C_OPENID/messages', 'C2C 帮助以 Markdown 被动回复');

    // 2) 加好友 / 进群事件
    mock.push('FRIEND_ADD', { openid: 'U_FRIEND_OPENID', timestamp: Math.floor(Date.now() / 1000) }, { appId: 'app_xh', seq: 102 });
    mock.push('GROUP_ADD_ROBOT', { group_openid: 'G_GROUP_1_OPENID', op_member_openid: 'U_OP', timestamp: Math.floor(Date.now() / 1000) }, { appId: 'app_xh', seq: 103 });
    await waitFor(() => {
      try {
        const s = readStore(dataDir);
        return s.friends.U_FRIEND_OPENID && s.groups.G_GROUP_1_OPENID ? s : null;
      } catch { return null; }
    }, 10000, 150, '事件写入用户库');
    ok(true, 'C2C / FRIEND_ADD / GROUP_ADD_ROBOT 自动写入 openid 库');

    // 3) 设置页快照
    const settingsRes = await fetch(base + '/api/plugins/xinghuo/settings', { headers });
    assert.equal(settingsRes.status, 200, '设置页 HTTP 状态');
    const settingsHtml = await settingsRes.text();
    assert.ok(settingsHtml.includes('星火 · 管理台'), '设置页 HTML');
    const snap0 = await waitFor(() => {
      const s = readSnapshot(dataDir);
      return s.stats.friends === 2 && s.stats.groups === 1 ? s : null;
    }, 8000, 200, '设置页快照更新');
    assert.equal(snap0.stats.friends, 2, '快照好友数（U_C2C_OPENID + U_FRIEND_OPENID）');
    assert.equal(snap0.stats.groups, 1, '快照群数');
    assert.equal(snap0.storage && snap0.storage.driver, storageDriver, '快照存储驱动为 ' + storageDriver);
    ok(true, '设置页快照已注入（好友 / 群计数正确）');

    // 账户显示名：/users/@me 的机器人昵称，不再是 accxxx
    const accountNamed = await waitFor(() => {
      const snap = readSnapshot(dataDir);
      const acc = (snap.accounts || []).find((a) => a.id === 'a1');
      return acc && /MockBot/.test(acc.name || '') ? acc : null;
    }, 10000, 250, '机器人昵称');
    assert.match(accountNamed.name, /MockBot-app_xh/, '账户名来自机器人昵称');
    ok(true, '账户列使用机器人昵称（/users/@me）');

    // 4) 任务：导入 + 发码 + 公告
    const manifest = readManifest(dataDir);
    const cfg = manifest.config || {};
    cfg.tasks = [
      {
        id: 'T-IMPORT-1',
        type: 'import-users',
        createdAt: Date.now(),
        payload: {
          source: 'export.zip',
          accountId: 'a1',
          items: [
            { kind: 'friend', rows: [{ o: 'U_IMPORT_OPENID', t: Math.floor(Date.now() / 1000) }] },
            { kind: 'group', rows: [{ o: 'G_IMPORT_OPENID', t: Math.floor(Date.now() / 1000) }] },
          ],
        },
      },
      {
        id: 'T-CODES-1',
        type: 'create-codes',
        createdAt: Date.now(),
        payload: { codes: [{ code: 'XHETESTCODE1', longjing: 100, xuanyu: 5, message: '星火测试附言' }] },
      },
      {
        id: 'T-ANNOUNCE-1',
        type: 'announce',
        createdAt: Date.now(),
        payload: { markdown: '## 星火测试公告\n> 这是一条端到端测试消息', delayMs: 300 },
      },
    ];
    const saveRes = await fetch(base + '/api/plugins/xinghuo/config', {
      method: 'POST',
      headers,
      body: JSON.stringify({ config: cfg }),
    });
    const saveBody = await saveRes.json();
    assert.equal(saveRes.status, 200, '保存 config 失败：' + JSON.stringify(saveBody));

    await waitFor(() => {
      const s = readStore(dataDir);
      return s.friends.U_IMPORT_OPENID && s.groups.G_IMPORT_OPENID && s.codes.XHETESTCODE1 ? s : null;
    }, 12000, 150, '任务写入');
    ok(true, 'import-users / create-codes 任务执行');

    // 3.1) 头像 / 名称补全：事件 + 导入都会后台补
    const profiled = await waitFor(() => {
      const s = readStore(dataDir);
      const fs = [
        s.friends.U_C2C_OPENID,
        s.friends.U_FRIEND_OPENID,
        s.friends.U_IMPORT_OPENID,
        s.groups.G_GROUP_1_OPENID,
        s.groups.G_IMPORT_OPENID,
      ];
      return fs.every((x) => x && x.name && /^https:\/\//.test(x.avatar || '')) ? s : null;
    }, 25000, 300, '头像/名称补全');
    assert.match(profiled.friends.U_FRIEND_OPENID.name, /模拟用户/, '好友名称来自 get_user_info');
    assert.equal(profiled.friends.U_IMPORT_OPENID.accountId, 'a1', '导入归属账户写入');
    assert.match(profiled.groups.G_GROUP_1_OPENID.name, /测试群/, '群名称来自 group_info');
    assert.match(profiled.groups.G_GROUP_1_OPENID.avatar, /^https:\/\//, '群头像 http 已转 https');
    ok(true, '事件 + 导入的好友/群都补上了头像与名称（http 头像转 https）');

    // 3.2) 一键刷新：重置好友资料并后台重新拉取
    const cfgRefresh = readManifest(dataDir).config || {};
    cfgRefresh.tasks = (cfgRefresh.tasks || []).concat([
      { id: 'T-REFRESH-FRIENDS', type: 'refresh-profiles', createdAt: Date.now(), payload: { scope: 'friend' } },
    ]);
    const refreshRes = await fetch(base + '/api/plugins/xinghuo/config', {
      method: 'POST',
      headers,
      body: JSON.stringify({ config: cfgRefresh }),
    });
    assert.equal(refreshRes.status, 200, '提交刷新资料任务');
    await waitFor(() => {
      const s = readStore(dataDir);
      const rec = s.processedTasks['T-REFRESH-FRIENDS'];
      const st = s.friends;
      return rec && rec.ok && st.U_FRIEND_OPENID.name && st.U_IMPORT_OPENID.name && st.U_C2C_OPENID.name ? s : null;
    }, 15000, 200, '刷新好友资料');
    ok(true, '一键刷新好友资料任务执行（重置后重新补全）');

    await waitFor(() => {
      const s = readStore(dataDir);
      const job = s.announcements.find((j) => j.id && j.status === 'done');
      return job && job.sent + job.failed >= 3 ? job : null;
    }, 15000, 200, '公告发完');
    const sentAnnounce = mock.sent.filter((s) => s.path.startsWith('/v2/users/') && s.body && s.body.msg_type === 2 && !s.body.msg_id);
    const targets = sentAnnounce.map((s) => s.path.split('/')[3]).sort();
    assert.deepEqual(targets, ['U_C2C_OPENID', 'U_FRIEND_OPENID', 'U_IMPORT_OPENID'], '公告应发给全部 3 位好友');
    assert.ok(sentAnnounce.every((s) => /星火测试公告/.test(s.body.markdown.content)), '公告 Markdown 内容');
    ok(true, '公告通过 /plugin-api/v1/action 主动私聊全部好友（3/3）');

    // 5) 兑换码
    mock.push('C2C_MESSAGE_CREATE', {
      id: 'MSG_REDEEM_1',
      content: '/xh XH-ETEST-CODE1',
      author: { user_openid: 'U_C2C_OPENID', username: '小星', bot: false },
      timestamp: new Date().toISOString(),
    }, { appId: 'app_xh', seq: 104 });
    const redeem = await waitFor(() => mock.sent.find((s) => s.body && s.body.msg_id === 'MSG_REDEEM_1'), 10000, 100, '兑换回复');
    assert.ok(/兑换成功/.test(redeem.body.markdown.content), '兑换成功回复：' + redeem.body.markdown.content.slice(0, 120));
    assert.ok(/星火测试附言/.test(redeem.body.markdown.content), '回复带码内附言');
    const credits = JSON.parse(fs.readFileSync(path.join(dataDir, 'plugins', 'VloS', 'credits.json'), 'utf8')).credits;
    assert.equal(credits.length, 1, '只调用一次 addVlosBalance');
    assert.equal(credits.reduce((s, c) => s + (c.delta.longjing || 0), 0), 100, '龙晶到账 100');
    assert.equal(credits.reduce((s, c) => s + (c.delta.xuanyu || 0), 0), 5, '玄玉到账 5');
    const afterRedeem = readStore(dataDir);
    assert.equal(afterRedeem.codes.XHETESTCODE1.status, 'exhausted', '兑换后码失效');
    assert.equal(afterRedeem.codes.XHETESTCODE1.uses, 1, '兑换次数 1');
    assert.equal(afterRedeem.codes.XHETESTCODE1.redeemedBy[0].email, 'u1@test.local', '记录兑换邮箱');
    ok(true, '兑换码：到账 VloS 余额 + 码失效 + 记录兑换者');

    // 6) 重复兑换
    mock.push('C2C_MESSAGE_CREATE', {
      id: 'MSG_REDEEM_2',
      content: '/xh XHETESTCODE1',
      author: { user_openid: 'U_C2C_OPENID', username: '小星', bot: false },
      timestamp: new Date().toISOString(),
    }, { appId: 'app_xh', seq: 105 });
    const again = await waitFor(() => mock.sent.find((s) => s.body && s.body.msg_id === 'MSG_REDEEM_2'), 10000, 100, '重复兑换回复');
    assert.ok(/已被使用|用完/.test(again.body.markdown.content), '重复兑换应被拒绝：' + again.body.markdown.content.slice(0, 100));
    const credits2 = JSON.parse(fs.readFileSync(path.join(dataDir, 'plugins', 'VloS', 'credits.json'), 'utf8')).credits;
    assert.equal(credits2.length, 1, '重复兑换不重复到账');
    ok(true, '重复兑换被拒绝，不重复发奖');

    // 7) 幂等：同一份 config 再保存一次
    await sleep(600);
    const before = readStore(dataDir);
    const beforeCodes = Object.keys(before.codes).length;
    const beforeJobs = before.announcements.length;
    const save2 = await fetch(base + '/api/plugins/xinghuo/config', {
      method: 'POST',
      headers,
      body: JSON.stringify({ config: cfg }),
    });
    assert.equal(save2.status, 200, '二次保存 config');
    await sleep(1200);
    const after = readStore(dataDir);
    assert.equal(Object.keys(after.codes).length, beforeCodes, '幂等：不重复生成兑换码');
    assert.equal(after.announcements.length, beforeJobs, '幂等：不重复创建公告');
    const credits3 = JSON.parse(fs.readFileSync(path.join(dataDir, 'plugins', 'VloS', 'credits.json'), 'utf8')).credits;
    assert.equal(credits3.length, 1, '幂等：不重复发奖');
    ok(true, '同一份 config 重复保存不会重复执行任务（processedTasks 去重）');

    // 7.1) 公告模板：保存 + 只发给选中的好友
    const cfg2 = readManifest(dataDir).config || {};
    cfg2.tasks = (cfg2.tasks || []).concat([
      {
        id: 'T-TPL-SAVE',
        type: 'save-announcement',
        createdAt: Date.now(),
        payload: {
          id: 'tpl-e2e-1',
          title: 'E2E 模板公告',
          markdown: '## E2E 模板\n> 只发给选中的好友',
          buttons: [
            { row: 1, col: 1, label: '帮助', data: '/xh 帮助', type: 2, permission: 2, enter: false },
            { row: 1, col: 2, label: '官网', data: 'https://example.com', type: 0, permission: 2, enter: false },
          ],
        },
      },
      {
        id: 'T-TPL-SEND',
        type: 'send-announcement',
        createdAt: Date.now(),
        payload: { templateId: 'tpl-e2e-1', openids: ['U_C2C_OPENID', 'U_IMPORT_OPENID'], delayMs: 300 },
      },
    ]);
    const saveTpl = await fetch(base + '/api/plugins/xinghuo/config', {
      method: 'POST',
      headers,
      body: JSON.stringify({ config: cfg2 }),
    });
    assert.equal(saveTpl.status, 200, '保存公告模板 config');
    const tplJob = await waitFor(() => {
      const s = readStore(dataDir);
      const tpl = s.templates.find((t) => t.id === 'tpl-e2e-1');
      const job = s.announcements.find((j) => j.templateId === 'tpl-e2e-1' && j.status === 'done');
      return tpl && tpl.status === 'sent' && job && job.sent === 2 ? { tpl, job } : null;
    }, 15000, 200, '模板公告发送');
    assert.equal(tplJob.tpl.title, 'E2E 模板公告', '模板标题');
    const tplSent = mock.sent.filter(
      (s) => s.path.startsWith('/v2/users/') && s.body && s.body.msg_type === 2 && !s.body.msg_id &&
        /E2E 模板/.test(s.body.markdown.content),
    );
    assert.deepEqual(tplSent.map((s) => s.path.split('/')[3]).sort(), ['U_C2C_OPENID', 'U_IMPORT_OPENID'], '只发给选中的 2 位好友');
    const kbMsg = tplSent.find((s) => s.body && s.body.keyboard);
    assert.ok(kbMsg, '模板发送应带 keyboard');
    const kbRows = kbMsg.body.keyboard.content.rows;
    assert.equal(kbRows.length, 1, '按钮 1 行');
    assert.equal(kbRows[0].buttons.length, 2, '一行 2 个按钮');
    assert.equal(kbRows[0].buttons[0].render_data.label, '帮助', '按钮文字');
    assert.equal(kbRows[0].buttons[0].action.data, '/xh 帮助', '指令按钮数据');
    assert.equal(kbRows[0].buttons[1].action.type, 0, '链接按钮类型');
    ok(true, '公告模板保存 + 按选中好友发送（2/2，带消息按钮）');

    // 7.2) 接收失败 → 好友标记无效
    mock.failOpenids.add('U_FRIEND_OPENID');
    const cfgFail = readManifest(dataDir).config || {};
    cfgFail.tasks = (cfgFail.tasks || []).concat([{
      id: 'T-FAIL-SEND',
      type: 'send-announcement',
      createdAt: Date.now(),
      payload: { templateId: 'tpl-e2e-1', openids: ['U_FRIEND_OPENID'], delayMs: 300 },
    }]);
    const failRes = await fetch(base + '/api/plugins/xinghuo/config', {
      method: 'POST',
      headers,
      body: JSON.stringify({ config: cfgFail }),
    });
    assert.equal(failRes.status, 200, '提交失败发送任务');
    const failedJob = await waitFor(() => {
      const s = readStore(dataDir);
      const job = s.announcements.find((j) => j.templateId === 'tpl-e2e-1' && j.failed === 1 && j.status === 'done');
      return job ? s : null;
    }, 15000, 200, '失败发送完成');
    assert.equal(failedJob.friends.U_FRIEND_OPENID.status, 'invalid', '发送失败好友标记无效');
    assert.match(failedJob.friends.U_FRIEND_OPENID.invalidReason, /40054/, '无效原因记录 code');
    ok(true, '公告发送失败 → 好友自动标记「无效」');
    mock.failOpenids.delete('U_FRIEND_OPENID');

    // 7.3) 无效好友再发消息 → 自动恢复有效
    mock.push('C2C_MESSAGE_CREATE', {
      id: 'MSG_REACTIVATE',
      content: '/xh 帮助',
      author: { user_openid: 'U_FRIEND_OPENID', username: '回流好友', bot: false },
      timestamp: new Date().toISOString(),
    }, { appId: 'app_xh', seq: 120 });
    const reactivated = await waitFor(() => {
      const s = readStore(dataDir);
      return s.friends.U_FRIEND_OPENID && s.friends.U_FRIEND_OPENID.status === 'active' ? s : null;
    }, 10000, 200, '无效好友恢复');
    assert.equal(reactivated.friends.U_FRIEND_OPENID.invalidReason, '', '恢复时清空无效原因');
    ok(true, '无效好友再发消息 → 自动恢复「有效」');

    // 8) 快照刷新
    const snap1 = readSnapshot(dataDir);
    assert.ok(snap1.codes.some((c) => c.code === 'XHETESTCODE1' && c.status === 'exhausted'), '快照包含已兑换码');
    assert.ok(snap1.announcements.some((a) => a.sent >= 3), '快照包含公告发送统计');
    assert.ok(snap1.balance.ready, '快照包含 VloS 余额');
    assert.equal(snap1.balance.pool.vlosLongjing, 3, '快照 VloS 余额合计');
    ok(true, '设置页快照包含兑换码 / 公告 / VloS 余额');

    // 9) VSQL：shared 库 + xinghuo_ 前缀表，其他插件可直接读
    const vsqlDbFile = path.join(dataDir, 'plugins', 'VSQL', 'data', 'dbs', 'shared.db');
    assert.ok(fs.existsSync(vsqlDbFile), '应有 VSQL shared 库文件');
    const D = require('node:sqlite').DatabaseSync;
    const rawDb = new D(vsqlDbFile, { readOnly: true });
    const tables = rawDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'xinghuo_%' ORDER BY name").all().map((r) => r.name);
    const friendCount = rawDb.prepare('SELECT COUNT(*) AS n FROM xinghuo_friends').get().n;
    rawDb.close();
    assert.ok(tables.includes('xinghuo_friends') && tables.includes('xinghuo_codes'), 'VSQL 共享库应有 xinghuo_ 表：' + tables.join(','));
    assert.ok(friendCount >= 3, '其他插件可直接读 xinghuo_friends');
    assert.equal(snap1.storage.driver, 'vsql', '快照存储驱动 VSQL');
    assert.equal(snap1.storage.namespace, 'shared', '快照命名空间 shared');
    ok(true, 'VSQL shared 库：表带 xinghuo_ 前缀，其他插件可直接读');

    console.log(`\n全部通过（${passed} 项）\n`);
  } catch (e) {
    console.error('\n测试失败：', e.message);
    try {
      console.error('\n--- 框架日志尾部 ---\n' + childLog.join('').split('\n').slice(-40).join('\n'));
      const errLog = path.join(dataDir, 'logs');
      if (fs.existsSync(errLog)) {
        for (const f of fs.readdirSync(errLog).filter((x) => x.endsWith('.jsonl')).slice(-1)) {
          const lines = fs.readFileSync(path.join(errLog, f), 'utf8').trim().split('\n').slice(-30).join('\n');
          console.error('\n--- 日志文件尾部 ---\n' + lines);
        }
      }
    } catch {
      /* ignore */
    }
    process.exitCode = 1;
  } finally {
    child.kill();
    await sleep(300);
    await mock.stop();
    await jlwMock.stop();
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
