'use strict';
/**
 * BBSP 插件自测（不联网、不碰线上数据）
 *
 *   node test/bbsp-test.js
 *
 * 覆盖：
 *   - 插件清单 / 单文件 settings.html（重新构建对比，防止忘记生成）
 *   - PE 导出表解析（Node Buffer + 浏览器 Uint8Array，32/64 位）
 *   - 积木目录、.bbsp 规范化、代码生成（vm 语法校验）
 *   - 配置规范化（项目/DLL/pending/lastExport）
 *   - 运行时：DLL base64 落盘、pending 导出/安装/写项目、config 回写、invokeDll、/bbsp 回复
 *   - 生成的 JS 插件在 BBSP API 上真跑通（调用系统 DLL 并回复）
 *
 * Windows 自带 DLL 用于验证：
 *   System32\version.dll（64 位）、SysWOW64\version.dll（32 位）
 *   System32\kernel32.dll / SysWOW64\kernel32.dll（DLL 宿主调用）
 */

const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.join(__dirname, '..');
const PLUGIN_DIR = path.join(ROOT, 'plugins', 'BBSP');
const TMP = path.join(__dirname, '.tmp-bbsp-test');

const B = require(path.join(PLUGIN_DIR, 'lib', 'blocks.js'));
const P = require(path.join(PLUGIN_DIR, 'lib', 'project.js'));
const C = require(path.join(PLUGIN_DIR, 'lib', 'codegen.js'));
const PE = require(path.join(PLUGIN_DIR, 'lib', 'pe.js'));
const CFG = require(path.join(PLUGIN_DIR, 'lib', 'config.js'));
const { build: buildSettings } = require(path.join(PLUGIN_DIR, 'tools', 'build-settings.js'));

const SYS_VERSION = 'C:\\Windows\\System32\\version.dll';
const SYS_VERSION_WOW = 'C:\\Windows\\SysWOW64\\version.dll';
const SYS_KERNEL32 = 'C:\\Windows\\System32\\kernel32.dll';
const SYS_KERNEL32_WOW = 'C:\\Windows\\SysWOW64\\kernel32.dll';

let passed = 0;
let failed = 0;
const failures = [];
const checks = [];

function check(name, fn) {
  checks.push({ name, fn });
}
function ok(cond, message) {
  if (!cond) throw new Error(message || '断言失败');
}
function eq(actual, expected, message) {
  assert.strictEqual(actual, expected, message);
}
function has(p) {
  try {
    return fs.existsSync(p);
  } catch {
    return false;
  }
}
function makeLog() {
  const logs = [];
  const push = (level) => (msg) => logs.push(level + ':' + msg);
  return { logs, info: push('info'), warn: push('warn'), error: push('error'), debug: push('debug') };
}

/* ======================= 清单 / 设置页 ======================= */

check('plugin.json：id / type / 命令 / 新配置结构', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(PLUGIN_DIR, 'plugin.json'), 'utf8'));
  eq(manifest.id, 'BBSP');
  eq(manifest.type, 'js');
  eq(manifest.entry, 'index.js');
  ok(manifest.version >= '1.2.0', '内置设置页版应是 1.2.x：' + manifest.version);
  ok(manifest.commands.includes('bbsp'), '要有 /bbsp 命令');
  const c = manifest.config;
  ok(c && c.version === 1, 'config.version');
  ok(c.settings && c.settings.dllTimeoutMs >= 1000, 'config.settings.dllTimeoutMs');
  ok(Array.isArray(c.projects) && Array.isArray(c.dlls), 'config 要有 projects/dlls 数组');
  ok('pending' in c && 'lastExport' in c, 'config 要有 pending/lastExport');
  ok(!c.workbench, '不该再保留 workbench 端口配置');
  ok(fs.existsSync(path.join(PLUGIN_DIR, 'settings.html')), '要有 settings.html');
  ok(fs.existsSync(path.join(PLUGIN_DIR, 'api.html')), '要有 api.html');
});

check('settings.html：单文件、内联、与源码同步', () => {
  const onDisk = fs.readFileSync(path.join(PLUGIN_DIR, 'settings.html'), 'utf8');
  const { html } = buildSettings();
  ok(onDisk === html, 'settings.html 和 ui/ + lib/ 不一致：请运行 node plugins/BBSP/tools/build-settings.js');
  ok(/<script>[\s\S]*<\/script>/.test(onDisk), '要有内联脚本');
  ok(onDisk.includes('window.BBSP ='), '要打包出 window.BBSP');
  ok(!/<script[^>]+src=/i.test(onDisk), '不能外链脚本（面板 CSP 会拦）');
  ok(!/<link[^>]+href=/i.test(onDisk), '不能外链样式');
  ok(!/fetch\(\s*['"]http/i.test(onDisk), '设置页不能自己发网络请求');
  const scripts = [...onDisk.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
  eq(scripts.length, 1);
  new vm.Script(scripts[0]); // 语法检查
  for (const key of ['jlw-settings-init', 'jlw-settings-save', 'jlw-settings-save-request', 'application/x-bbsp']) {
    ok(onDisk.includes(key), '设置页应处理 ' + key);
  }
});

/* ======================= PE ======================= */

check('PE 解析：64 位 / 32 位 / Uint8Array', () => {
  ok(has(SYS_VERSION), '缺少系统 DLL：' + SYS_VERSION);
  const a = PE.parseExports(fs.readFileSync(SYS_VERSION));
  eq(a.arch, 'x64');
  eq(a.kind, 'dll');
  ok(a.exports.length > 5);
  ok(a.exports.some((e) => e.name.includes('GetFileVersionInfoSizeA')));

  const b = PE.parseExports(new Uint8Array(fs.readFileSync(SYS_VERSION)));
  eq(b.exports.length, a.exports.length, 'Buffer 与 Uint8Array 结果应一致');

  if (has(SYS_VERSION_WOW)) {
    const c = PE.parseExports(fs.readFileSync(SYS_VERSION_WOW));
    eq(c.arch, 'x86');
    ok(c.exports.length > 5);
  }
  eq(PE.cleanName('_Foo@12'), 'Foo');
  ok(PE.candidateNames('_Add@8', ['int', 'int'], 'x86').includes('Add'));
});

check('PE 解析：非 PE 文件抛错', () => {
  let threw = false;
  try {
    PE.parseExports(Buffer.from('not a dll at all'));
  } catch (e) {
    threw = /MZ|PE|太小/i.test(e.message);
  }
  ok(threw);
});

/* ======================= 积木 / 项目 / 代码生成 ======================= */

check('积木目录：定义完整、默认节点可创建', () => {
  const cats = new Set(B.CATEGORIES.map((c) => c.id));
  for (const [type, def] of Object.entries(B.DEFS)) {
    ok(cats.has(def.category), type + ' 分类不存在');
    ok(def.label && Array.isArray(def.template) && def.template.length, type + ' 定义不完整');
    ok(['hat', 'stmt', 'expr'].includes(def.shape), type + ' shape');
    const node = B.defaultNode(type);
    eq(node.type, type);
    for (const f of def.fields || []) ok(node.fields[f.name] !== undefined, type + ' 缺默认字段 ' + f.name);
    eq(node.slots.length, (def.slots || []).length);
  }
  ok(Object.keys(B.DEFS).length >= 25);
});

check('.bbsp：空项目 / 规范化 / 坏节点丢弃', () => {
  const p = P.emptyProject({ name: '测试项目', pluginId: 'test-bbsp' });
  eq(p.format, 'bbsp-project');
  ok(p.scripts.length >= 2);
  ok(p.components.length === 1);
  const { project, warnings } = P.normalize({
    format: 'bbsp-project',
    name: '脏项目',
    scripts: [{ id: 's1', blocks: [{ type: 'on_message', fields: { command: '测试' }, body: [{ type: '不存在' }, { type: 'reply', slots: [{ type: 'lit_text', fields: { value: 'ok' } }] }] }] }],
  });
  ok(warnings.some((w) => w.includes('未知积木')));
  eq(project.scripts[0].blocks[0].body.length, 1);
  eq(project.scripts[0].blocks[0].fields.scope, 'all');
});

check('代码生成：语法可解析 + 事件/命令推导', () => {
  const p = P.emptyProject({ name: '生成测试', pluginId: 'gen-test' });
  const hat = p.scripts[0].blocks[0];
  hat.fields.command = '天气';
  hat.body = [
    B.defaultNode('if', {
      slots: [{ type: 'raw_expr', fields: { code: 'message.command.args.length > 0' } }],
      body: [B.defaultNode('reply', { slots: [{ type: 'msg_arg', fields: { index: 0 } }] })],
      elseBody: [B.defaultNode('reply', { slots: [{ type: 'lit_text', value: '没参数' }] })],
    }),
    B.defaultNode('repeat', { slots: [{ type: 'lit_num', value: 2 }], body: [B.defaultNode('log', { slots: [{ type: 'concat', slots: [{ type: 'lit_text', value: '第' }, { type: 'now_time' }] }] })] }),
    B.defaultNode('set_var', { fields: { var: 'count' }, slots: [{ type: 'math', fields: { op: '+' }, slots: [{ type: 'var_expr', fields: { var: 'count' } }, { type: 'lit_num', value: 1 }] }] }),
  ];
  const gen = C.generate(p, { items: [] });
  ok(gen.code.includes('async function onEvent'));
  ok(gen.code.includes('__out.push'));
  eq(gen.manifest.id, 'gen-test');
  ok(gen.manifest.commands.includes('天气'));
  ok(gen.manifest.events.includes('GROUP_MESSAGE_CREATE'));
  new vm.Script(gen.code);
  ok(gen.code.includes('__comp_c_hello'));
});

check('代码生成：DLL 积木生成转发调用', () => {
  const dll = { id: 'dll_demo_abc123', alias: '演示DLL', arch: 'x86', exports: [{ name: 'Add', clean: 'Add', ret: 'int', params: ['int', 'int'], conv: 'stdcall', enabled: true }] };
  const lib = { items: [dll] };
  const p = P.emptyProject({ name: 'DLL 生成', pluginId: 'dll-gen' });
  p.scripts[0].blocks[0].body = [
    B.defaultNode('reply', { slots: [{ type: 'dll_call', fields: { dllref: dll.id + '::Add' }, slots: [{ type: 'lit_num', value: 2 }, { type: 'lit_num', value: 40 }] }] }),
  ];
  const norm = P.normalize(p, { dllLib: lib }).project;
  const gen = C.generate(norm, lib);
  ok(gen.code.includes('__bbspDll'));
  ok(gen.code.includes('"int", "stdcall"'));
  ok(gen.code.includes('__JLWBOT_PLUGIN_APIS__'));
  new vm.Script(gen.code);
});

/* ======================= 配置 ======================= */

check('配置：默认值 / 脏数据修复 / pending 校验', () => {
  const d = CFG.normalizeConfig(null).config;
  eq(d.version, 1);
  eq(d.projects.length, 0);
  eq(d.settings.dllTimeoutMs, 15000);

  const r = CFG.normalizeConfig({
    version: 9,
    settings: { dllTimeoutMs: 999 },
    projects: [{ name: 'A' }, { name: 'B' }, null],
    activeProjectId: 'nope',
    dlls: [
      { id: '', exports: [] },
      { id: 'dll_ok', name: 'x.dll', arch: 'x86', exports: [{ name: 'Fn', ret: '文本型', params: 'int,文本型' }] },
      { id: 'dll_big', base64: 'A'.repeat(CFG.MAX_BASE64 + 10), exports: [] },
    ],
    pending: { action: 'export', package: { id: 'x', manifest: { id: 'x' }, code: 'x' } },
    lastExport: { at: 1, action: 'install', id: 'p', dirs: ['d:/x'], error: '' },
  });
  const cfg = r.config;
  eq(cfg.settings.dllTimeoutMs, 15000, '非法超时应回落默认');
  eq(cfg.projects.length, 2, '空项目应被丢掉');
  eq(cfg.activeProjectId, cfg.projects[0].id, 'activeProjectId 应指向第一个项目');
  eq(cfg.dlls.length, 1, '空 id / 超大 base64 的 DLL 应被丢弃');
  eq(cfg.dlls[0].exports[0].ret, 'text_ansi');
  eq(cfg.dlls[0].exports[0].params.length, 2);
  ok(r.warnings.length >= 2, '应有修复提示');
  ok(cfg.pending && cfg.pending.package.id === 'x', 'pending 应保留');
  eq(cfg.lastExport.id, 'p');

  const bad = CFG.normalizeConfig({ pending: { action: 'export', package: { code: '' } } }).config;
  eq(bad.pending, null, '空代码的 pending 应被丢掉');
});

/* ======================= 运行时 ======================= */

function copyPluginToTmp(name) {
  const dir = path.join(TMP, name);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.cpSync(PLUGIN_DIR, dir, { recursive: true });
  fs.rmSync(path.join(dir, 'data'), { recursive: true, force: true });
  fs.rmSync(path.join(dir, 'fw'), { recursive: true, force: true });
  fs.mkdirSync(path.join(dir, 'fw'), { recursive: true });
  return dir;
}

function writePluginConfig(dir, config) {
  const file = path.join(dir, 'plugin.json');
  const manifest = JSON.parse(fs.readFileSync(file, 'utf8'));
  manifest.config = config;
  fs.writeFileSync(file, JSON.stringify(manifest, null, 2));
  return file;
}

function loadPlugin(dir) {
  const entry = path.join(dir, 'index.js');
  for (const key of Object.keys(require.cache)) if (key.startsWith(dir)) delete require.cache[key];
  return require(entry);
}

function base64(file) {
  return fs.readFileSync(file).toString('base64');
}

function dllEntryFrom(file, id, alias) {
  const parsed = PE.parseExports(fs.readFileSync(file));
  return {
    id,
    name: path.basename(file),
    alias,
    arch: parsed.arch,
    size: fs.statSync(file).size,
    exports: parsed.exports.map((e) => ({
      name: e.name,
      clean: e.clean,
      ordinal: e.ordinal,
      ret: 'int',
      params: e.clean === 'GetFileVersionInfoSizeA' ? ['text_ansi', 'ptr'] : [],
      conv: parsed.arch === 'x86' ? 'stdcall' : 'cdecl',
      enabled: e.clean === 'GetFileVersionInfoSizeA',
    })),
    base64: base64(file),
  };
}

function projectWithDllCall(dllId, command) {
  const p = P.emptyProject({ name: 'DLL 项目', pluginId: 'bbsp-it' });
  const hat = p.scripts[0].blocks[0];
  hat.fields.command = command;
  hat.body = [
    B.defaultNode('reply', {
      slots: [
        {
          type: 'dll_call',
          fields: { dllref: dllId + '::GetFileVersionInfoSizeA' },
          slots: [{ type: 'lit_text', value: 'C:\\Windows\\notepad.exe' }, { type: 'lit_num', value: 0 }],
        },
      ],
    }),
  ];
  return p;
}

check('运行时：DLL base64 落盘 + pending 安装 + config 回写', async () => {
  fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(TMP, { recursive: true });
  const dir = copyPluginToTmp('runtime');
  const fw = path.join(dir, 'fw');
  const dll = dllEntryFrom(SYS_VERSION, 'dll_version_test', '版本库');
  const project = projectWithDllCall(dll.id, '你好');
  const config = {
    version: 1,
    settings: { dllTimeoutMs: 15000 },
    projects: [project],
    activeProjectId: project.id,
    dlls: [dll],
    pending: {
      action: 'install',
      at: Date.now(),
      package: {
        id: 'bbsp-it',
        code: "module.exports={onEvent:async()=>({reply:'x'})};",
        manifest: { id: 'bbsp-it', name: '测试插件', version: '1.0.0', type: 'js', events: ['GROUP_MESSAGE_CREATE'], commands: [] },
        readme: '# x',
      },
    },
  };
  const manifestFile = writePluginConfig(dir, config);
  const plugin = loadPlugin(dir);
  const log = makeLog();
  await plugin.onLoad({ plugin: { id: 'BBSP', dir, config }, log, framework: { version: '1.6.1', dataDir: fw } });

  const after = JSON.parse(fs.readFileSync(manifestFile, 'utf8')).config;
  ok(!after.dlls[0].base64, 'config 里的 base64 应被删掉');
  ok(after.dlls[0].materializedAt, '要记录落盘时间');
  ok(fs.existsSync(path.join(dir, 'data', 'dlls', 'dll_version_test.dll')), 'DLL 应写到 data/dlls/');
  eq(after.pending, null, 'pending 应被清空');
  ok(after.lastExport && after.lastExport.id === 'bbsp-it', 'lastExport 应记录');
  ok(after.lastExport.dirs.some((d) => d.includes('exports')), 'lastExport 应包含导出目录');
  ok(fs.existsSync(path.join(dir, 'data', 'exports', 'bbsp-it', 'index.js')), '应导出 index.js');
  ok(fs.existsSync(path.join(fw, 'plugins', 'bbsp-it', 'index.js')), '应安装进框架插件目录');
  ok(fs.existsSync(path.join(fw, 'plugins', 'bbsp-it', 'plugin.json')), '安装要有 plugin.json');

  const api = globalThis.__JLWBOT_PLUGIN_APIS__.get('BBSP');
  ok(api && api.isReady(), '应注册 BBSP API');
  const size = await api.invokeDll('版本库', 'GetFileVersionInfoSizeA', ['C:\\Windows\\notepad.exe', 0], { ret: 'int', conv: 'cdecl' });
  ok(Number(size) > 0, 'invokeDll 应返回版本信息大小：' + size);

  const evt = await plugin.onEvent({ message: { kind: 'c2c', command: { name: 'bbsp' } }, log });
  ok(evt && evt.reply.includes('BBSP') && evt.reply.includes('设置页'), '/bbsp 应返回面板路径提示');

  // 生成的插件用同一个 BBSP 实例跑通
  const lib = CFG.dllLibrary(after);
  const gen = C.generate(after.projects[0], lib);
  new vm.Script(gen.code);
  const genFile = path.join(dir, 'generated.js');
  fs.writeFileSync(genFile, gen.code);
  const generated = require(genFile);
  const out = await generated.onEvent({
    message: { id: 'M1', kind: 'group', content: '/你好', command: { name: '你好', args: [], matched: true }, author: {} },
    event: { name: 'GROUP_MESSAGE_CREATE' },
    log: { info() {}, warn() {}, error() {}, debug() {} },
    bot: { sendGroup: async () => ({ ok: true }), sendC2C: async () => ({ ok: true }) },
    api: { call: async () => ({}) },
  });
  ok(out && out.replies && Number(out.replies[0].content) > 0, '生成的插件应回复 DLL 结果：' + JSON.stringify(out));

  // 幂等：再加载一次不应该再报 base64 / pending
  await plugin.onUnload();
  const plugin2 = loadPlugin(dir);
  await plugin2.onLoad({ plugin: { id: 'BBSP', dir, config: after }, log, framework: { version: '1.6.1', dataDir: fw } });
  await plugin2.onUnload();
  eq(globalThis.__JLWBOT_PLUGIN_APIS__.get('BBSP'), undefined, '卸载后应注销 API');
});

check('运行时：pending 导出 / 写项目文件 / 删除 DLL 清理文件', async () => {
  const dir = copyPluginToTmp('runtime2');
  const fw = path.join(dir, 'fw');
  const dll = dllEntryFrom(SYS_VERSION, 'dll_version_test', '版本库');
  const project = projectWithDllCall(dll.id, '你好');
  const config = {
    version: 1,
    settings: { dllTimeoutMs: 15000 },
    projects: [project],
    activeProjectId: project.id,
    dlls: [dll],
    pending: { action: 'write-project', at: Date.now(), project: clone(project) },
  };
  const manifestFile = writePluginConfig(dir, config);
  const plugin = loadPlugin(dir);
  await plugin.onLoad({ plugin: { id: 'BBSP', dir, config }, log: makeLog(), framework: { version: '1.6.1', dataDir: fw } });
  const after = JSON.parse(fs.readFileSync(manifestFile, 'utf8')).config;
  ok(after.lastExport.dirs.some((d) => d.endsWith('.bbsp')), '应写出 .bbsp：' + JSON.stringify(after.lastExport));
  ok(has(path.join(dir, 'data', 'dlls', 'dll_version_test.dll')), 'DLL 落盘');

  // 移除 DLL 后再加载：文件应被清掉
  after.dlls = [];
  writePluginConfig(dir, after);
  await plugin.onUnload();
  const plugin3 = loadPlugin(dir);
  await plugin3.onLoad({ plugin: { id: 'BBSP', dir, config: after }, log: makeLog(), framework: { version: '1.6.1', dataDir: fw } });
  ok(!has(path.join(dir, 'data', 'dlls', 'dll_version_test.dll')), '配置删掉的 DLL 文件应清理');
  await plugin3.onUnload();
});

check('运行时：plugin.json 被重置后从 data/state.json 恢复', async () => {
  const dir = copyPluginToTmp('runtime3');
  const fw = path.join(dir, 'fw');
  const dll = dllEntryFrom(SYS_VERSION, 'dll_version_test', '版本库');
  const project = projectWithDllCall(dll.id, '你好');
  const config = { version: 1, settings: { dllTimeoutMs: 15000 }, projects: [project], activeProjectId: project.id, dlls: [dll], pending: null };
  const manifestFile = writePluginConfig(dir, config);
  const plugin = loadPlugin(dir);
  await plugin.onLoad({ plugin: { id: 'BBSP', dir, config }, log: makeLog(), framework: { version: '1.6.1', dataDir: fw } });
  const stateFile = path.join(dir, 'data', 'state.json');
  ok(fs.existsSync(stateFile), '应写 data/state.json');
  const side = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  eq(side.projects.length, 1);
  eq(side.dlls.length, 1);
  ok(!side.dlls[0].base64, 'state.json 不应保存 base64');
  await plugin.onUnload();

  // 模拟手工覆盖插件文件：plugin.json 的 config 变回默认空值
  const empty = { version: 1, settings: { dllTimeoutMs: 15000 }, projects: [], activeProjectId: '', dlls: [], pending: null };
  writePluginConfig(dir, empty);
  const plugin2 = loadPlugin(dir);
  await plugin2.onLoad({ plugin: { id: 'BBSP', dir, config: empty }, log: makeLog(), framework: { version: '1.6.1', dataDir: fw } });
  const after = JSON.parse(fs.readFileSync(manifestFile, 'utf8')).config;
  eq(after.projects.length, 1, '项目应从 state.json 恢复');
  eq(after.dlls.length, 1, 'DLL 应从 state.json 恢复');
  ok(after.activeProjectId, 'activeProjectId 应恢复');
  await plugin2.onUnload();
});

check('DLL 宿主：32/64 位真实调用', async () => {
  const { DllBridge } = require(path.join(PLUGIN_DIR, 'lib', 'dll-bridge.js'));
  const bridge = new DllBridge({ dir: PLUGIN_DIR, log: makeLog(), timeoutMs: 15000 });
  try {
    const r64 = await bridge.call({ dll: SYS_KERNEL32, fn: 'GetCurrentProcessId', conv: 'stdcall', ret: 'int', args: [], arch: 'x64' });
    ok(r64.ok && Number(r64.value) > 0, 'x64 调用失败：' + r64.error);
    if (has(SYS_KERNEL32_WOW)) {
      const r32 = await bridge.call({ dll: SYS_KERNEL32_WOW, fn: 'GetTickCount', conv: 'stdcall', ret: 'int', args: [], arch: 'x86' });
      ok(r32.ok && Number(r32.value) > 0, 'x86 调用失败：' + r32.error);
    }
    const miss = await bridge.call({ dll: SYS_KERNEL32, fn: 'NoSuchFunction_xyz', conv: 'stdcall', ret: 'int', args: [], arch: 'x64' });
    eq(miss.ok, false);
    ok(/找不到导出函数/.test(miss.error));
  } finally {
    bridge.dispose();
  }
});

function clone(v) {
  return v == null ? null : JSON.parse(JSON.stringify(v));
}

/* ======================= 运行 ======================= */

(async () => {
  delete globalThis.__JLWBOT_PLUGIN_APIS__;
  for (const c of checks) {
    try {
      await c.fn();
      passed++;
      console.log(`  ✓ ${c.name}`);
    } catch (e) {
      failed++;
      failures.push({ name: c.name, error: e });
      console.log(`  ✗ ${c.name}`);
      console.log(`      ${e && e.message ? e.message : e}`);
    }
  }
  try {
    if (globalThis.__JLWBOT_PLUGIN_APIS__) delete globalThis.__JLWBOT_PLUGIN_APIS__;
  } catch {
    /* ignore */
  }
  fs.rmSync(TMP, { recursive: true, force: true, maxRetries: 3 });
  console.log(`\nBBSP 自测：${passed} 通过 / ${failed} 失败（共 ${checks.length} 项）`);
  if (failures.length) {
    console.log('\n失败详情：');
    for (const f of failures) {
      console.log(`\n[${f.name}]`);
      console.log(f.error && f.error.stack ? f.error.stack : String(f.error));
    }
    process.exit(1);
  }
})();
