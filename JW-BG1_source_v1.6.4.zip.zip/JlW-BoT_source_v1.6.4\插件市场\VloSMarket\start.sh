#!/usr/bin/env bash
# JlW-BoT Market 启动脚本（Linux / macOS）
# 用法：./start.sh        （自动打开浏览器）
#       ./start.sh --no-open
set -e
cd "$(dirname "$0")"

if command -v node >/dev/null 2>&1; then
  NODE=node
elif [ -x /usr/local/bin/node ]; then
  NODE=/usr/local/bin/node
elif [ -x /usr/bin/node ]; then
  NODE=/usr/bin/node
else
  echo
  echo "  ❌ 没有找到 Node.js。请先安装 Node.js 22.5 或更高版本："
  echo "     https://nodejs.org/   或   curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt install -y nodejs"
  echo
  exit 1
fi

ARGS=""
if [ "$1" != "--no-open" ]; then
  ARGS="--open"
fi

exec "$NODE" server/launch.mjs $ARGS
