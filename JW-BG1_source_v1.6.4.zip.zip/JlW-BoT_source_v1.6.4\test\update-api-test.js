'use strict';
/** 面板更新接口：登录鉴权 + 更新页解析 + 进度查询 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');
const MockJlw = require('./mock-jlw');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const html = `<!doctype html><html><body>
  <div class="yz-dl-name">JlW-BoT [v9.9.9].zip</div>
  <div class="yz-dl-meta">12 MB · 已下载 0 次</div>
  <a class="yz-btn yz-btn-sm yz-dl-btn" href="/download/update.zip">下载</a>
</body></html>`;

(async () => {
  const page = http.createServer((req, res) => {
    if (req.url === '/QQBOT') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(html);
    }
    res.writeHead(404);
    res.end('no');
  });
  await new Promise((r) => page.listen(0, '127.0.0.1', r));
  const pageUrl = `http://127.0.0.1:${page.address().port}/QQBOT`;

  const jlw = await new MockJlw({ port: 0 }).start();
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jlw-update-api-'));
  const port = 18891 + Math.floor(Math.random() * 60);
  fs.writeFileSync(
    path.join(dataDir, 'config.json'),
    JSON.stringify(
      {
        server: { host: '127.0.0.1', port, openBrowser: false },
        jlw: { baseUrl: jlw.base, insecureTls: false },
        update: { enabled: true, pageUrl },
        log: { level: 'warn', console: false },
      },
      null,
      2,
    ),
  );

  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'index.js'), '--no-open'], {
    cwd: ROOT,
    env: { ...process.env, JLW_DATA_DIR: dataDir, JLW_ALLOW_LOCAL_SITE: '1', JLW_ALLOW_ALL_LOGIN: '1' },
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsHide: true,
  });
  const base = `http://127.0.0.1:${port}`;
  const out = [];
  const check = (ok, msg) => {
    out.push({ ok, msg });
    console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
  };

  try {
    const deadline = Date.now() + 20000;
    let ready = false;
    while (Date.now() < deadline) {
      try {
        const r = await fetch(base + '/health');
        if (r.ok) {
          ready = true;
          break;
        }
      } catch {
        /* retry */
      }
      await sleep(200);
    }
    if (!ready) throw new Error('服务未启动');

    const login = await fetch(base + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'user@test.local', password: 'secret123' }),
    });
    const cookie = ((login.headers.getSetCookie ? login.headers.getSetCookie()[0] : login.headers.get('set-cookie')) || '').split(';')[0];

    const unauth = await fetch(base + '/api/update/check');
    check(unauth.status === 401, '未登录不能检查更新');

    const info = await fetch(base + '/api/update/check?force=1', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(info.ok === true && info.latest === '9.9.9', '面板解析到最新版 9.9.9');
    check(info.hasUpdate === true, '面板发现新版本');
    check(info.sizeText === '12 MB', '面板返回更新包大小');

    const prog = await fetch(base + '/api/update/progress', { headers: { Cookie: cookie } }).then((r) => r.json());
    check(prog.phase === 'idle', '未开始更新时进度为 idle');
  } finally {
    child.kill();
    await sleep(200);
    await jlw.stop();
    await new Promise((r) => page.close(r));
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }

  const failed = out.filter((x) => !x.ok);
  console.log(`\n${out.length - failed.length}/${out.length} 通过`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => {
  console.error(e.stack || e);
  process.exit(1);
});
