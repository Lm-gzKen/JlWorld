// 管理接口：插件下架/上架/删除 + 管理员账户管理。
// 权限：
//   - 所有管理员：看后台列表、下架/上架/删除任意插件
//   - 只有超级管理员（3407556894@qq.com）：新增 / 移除管理员
import { HttpError } from '../http.mjs';
import { isAdmin, isSuperAdmin, SUPER_ADMIN_EMAIL } from '../roles.mjs';
import { publicPlugin, depsFor } from './plugins.mjs';
import { maskMail } from './auth.mjs';

const EMAIL_RE = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

const s = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

export default function register(router) {
  // ---------------- 全部插件（含已下架，带上传者与版本明细）----------------
  router.get('/api/admin/plugins', (c) => {
    c.mustAdmin();
    const rows = c.store.all(
      `SELECT *,
         (SELECT COUNT(*) FROM releases r WHERE r.plugin_id = plugins.id) AS release_count,
         (SELECT COALESCE(SUM(r.size),0) FROM releases r WHERE r.plugin_id = plugins.id) AS total_size,
         (SELECT COUNT(*) FROM comments cm WHERE cm.plugin_id = plugins.id AND cm.deleted=0) AS comment_count,
         (SELECT COUNT(*) FROM ratings g WHERE g.plugin_id = plugins.id) AS rating_count,
         (SELECT COALESCE(AVG(g.stars),0) FROM ratings g WHERE g.plugin_id = plugins.id) AS rating_avg
       FROM plugins ORDER BY pinned DESC, updated DESC`
    );
    const items = rows.map((p) => {
      const owner = c.store.get(
        'SELECT email, qq, openid, first_seen, last_login FROM users WHERE email=?',
        p.email
      ) || { email: p.email, qq: '', openid: '', first_seen: 0, last_login: 0 };
      const releases = c.store.all(
        'SELECT version, filename, size, entry_count, created FROM releases WHERE plugin_id=? ORDER BY created DESC',
        p.id
      );
      return {
        ...publicPlugin(p, { owner: true }),
        offline: !!p.offline,
        owner: {
          email: owner.email,
          qq: owner.qq || '',
          openid: owner.openid || '',
          joined: owner.first_seen || 0,
          lastLogin: owner.last_login || 0,
        },
        ownerMasked: maskMail(p.email),
        totalSize: p.total_size || 0,
        commentCount: p.comment_count || 0,
        rating: {
          avg: p.rating_count ? Math.round(Number(p.rating_avg) * 10) / 10 : 0,
          count: p.rating_count || 0,
        },
        releases: releases.map((r) => ({
          version: r.version,
          filename: r.filename,
          size: r.size,
          entryCount: r.entry_count,
          created: r.created,
        })),
        deps: depsFor(c.store, p.id),
      };
    });
    return {
      items,
      total: items.length,
      offlineCount: items.filter((p) => p.offline).length,
    };
  });

  // ---------------- 置顶 / 取消置顶 ----------------
  router.post('/api/admin/pin', async (c) => {
    c.mustAdmin();
    const b = await c.json();
    const p = c.store.get('SELECT * FROM plugins WHERE id = ?', s(b.id, 40));
    if (!p) throw new HttpError(404, '插件不存在');
    const want = b.pinned === undefined ? !p.pinned : !!b.pinned;
    c.store.run('UPDATE plugins SET pinned=? WHERE id=?', want ? 1 : 0, p.id);
    return {
      ok: true,
      pinned: want,
      plugin: publicPlugin(c.store.get('SELECT * FROM plugins WHERE id=?', p.id), { owner: true }),
    };
  });

  // ---------------- 登录用户列表 ----------------
  router.get('/api/admin/users', (c) => {
    c.mustAdmin();
    const rows = c.store.all(
      `SELECT u.*,
         (SELECT COUNT(*) FROM plugins p WHERE p.email = u.email) AS plugin_count,
         (SELECT COUNT(*) FROM plugins p WHERE p.email = u.email AND p.offline = 0) AS online_count,
         (SELECT COALESCE(SUM(p.downloads),0) FROM plugins p WHERE p.email = u.email) AS download_sum
       FROM users u ORDER BY u.last_login DESC`
    );
    const items = rows.map((u) => {
      const admin = isAdmin(c.store, u);
      const sup = isSuperAdmin(u);
      return {
        email: u.email,
        name: u.nickname || String(u.email || '').split('@')[0],
        qq: u.qq || '',
        openid: u.openid || '',
        joined: u.first_seen || 0,
        lastLogin: u.last_login || 0,
        plugins: u.plugin_count || 0,
        online: u.online_count || 0,
        downloads: u.download_sum || 0,
        isAdmin: admin,
        isSuper: sup,
        roleLabel: sup ? '超级管理员' : admin ? '管理员' : '用户',
      };
    });
    return { items, total: items.length, admins: items.filter((u) => u.isAdmin).length };
  });

  // ---------------- 管理员列表 ----------------
  router.get('/api/admin/admins', (c) => {
    const me = c.mustAdmin();
    const rows = c.store.all('SELECT * FROM admins ORDER BY created ASC');
    return {
      superEmail: SUPER_ADMIN_EMAIL,
      canManage: isSuperAdmin(me),
      items: [
        { email: SUPER_ADMIN_EMAIL, isSuper: true, addedBy: '', created: 0 },
        ...rows.map((r) => ({
          email: r.email,
          isSuper: false,
          addedBy: r.added_by || '',
          created: r.created,
        })),
      ],
    };
  });

  // ---------------- 新增管理员（仅超级管理员）----------------
  router.post('/api/admin/admins', async (c) => {
    const me = c.mustSuper();
    const b = await c.json();
    const email = s(b.email, 120).toLowerCase();
    if (!EMAIL_RE.test(email)) throw new HttpError(400, '请填写正确的邮箱（聚龙账户）');
    if (email === SUPER_ADMIN_EMAIL) throw new HttpError(400, '超级管理员已经固定，无需重复添加');
    if (c.store.get('SELECT 1 AS x FROM admins WHERE email=?', email)) {
      throw new HttpError(400, '这个账户已经是管理员了');
    }

    const now = Date.now();
    c.store.run('INSERT INTO admins (email, added_by, created) VALUES (?,?,?)', email, me.email, now);
    // 站内信通知本人（他下次登录会在铃铛里看到）
    c.store.run(
      'INSERT INTO messages (to_email, plugin_id, comment_id, kind, body, created) VALUES (?,?,0,?,?,?)',
      email,
      '',
      'system',
      `你已被 ${me.email} 设为 JlW-BoT 插件市场管理员，可以管理插件。`,
      now
    );
    return { ok: true, email, msg: '已添加管理员' };
  });

  // ---------------- 移除管理员（仅超级管理员）----------------
  router.delete('/api/admin/admins/:email', (c) => {
    const me = c.mustSuper();
    const email = decodeURIComponent(String(c.params.email || '')).trim().toLowerCase();
    if (email === SUPER_ADMIN_EMAIL) throw new HttpError(400, '超级管理员是固定的，不能移除');
    const row = c.store.get('SELECT 1 AS x FROM admins WHERE email=?', email);
    if (!row) throw new HttpError(404, '这个账户不是管理员');
    c.store.run('DELETE FROM admins WHERE email=?', email);
    c.store.run(
      'INSERT INTO messages (to_email, plugin_id, comment_id, kind, body, created) VALUES (?,?,0,?,?,?)',
      email,
      '',
      'system',
      `你已被 ${me.email} 取消 JlW-BoT 插件市场管理员权限。`,
      Date.now()
    );
    return { ok: true, email, msg: '已移除管理员' };
  });
}
