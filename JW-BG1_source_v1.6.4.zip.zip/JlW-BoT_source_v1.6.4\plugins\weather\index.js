'use strict';
/**
 * 天气查询 · JlWBoT 插件 v1.1.0
 *
 * 指令（群 / 私聊都能用；回复统一是图片，用富媒体发送）：
 *   群聊   /天气 城市            → 该城市天气卡
 *   私聊   /天气 城市            → 该城市天气卡
 *          /天气 订阅 城市       → 订阅每日推送（时间沿用已设的，否则用 defaultTime）
 *          /天气 时间 0800       → 设置推送时间（并开启）
 *          /天气 取消订阅        → 关闭推送
 *          /天气                 → 看自己的订阅状态（没订阅就是用法说明）
 *
 * 数据存储：VSQL（shared 库，表 weather_subs / weather_tasks）；VSQL 缺席时回退 JSON。
 * 文案与卡片外观：config.texts / config.card，设置页可改（模板支持 {city} {temp} … 占位符）。
 *
 * 结构：
 *   lib/cities.js       地名 → 中国天气网 AREAID（离线三级行政区表）
 *   lib/geocode.js      Photon / open-meteo 经纬度（兜底 + 补逐小时降水）
 *   lib/weather.js      d1 / itboy / open-meteo / wttr 取数 + 成品串（宜不宜、降雨措辞）
 *   lib/texts.js        文案模板 / 卡片外观默认值 + 占位符渲染
 *   lib/card.js         天气卡 → 绘制指令
 *   lib/render-image.js PowerShell + GDI+ 出 PNG
 *   lib/render.ps1      GDI+ 绘制脚本（源自 Arknights 插件，见文件头注释）
 *   lib/media.js        事件上下文里的图片上传 + 被动回复
 *   lib/sender.js       定时推送（本地 /plugin-api 两步：上传 + 发送，失败退文本）
 *   lib/store.js        VSQL 主存储（JSON 回退）
 *   lib/subscribe.js    时间解析 + 到点判定（纯函数）
 *   lib/util.js         原子写 / http / varJson / 温度解析
 */

const path = require('node:path');

const C = require('./lib/cities');
const geocode = require('./lib/geocode');
const S = require('./lib/subscribe');
const weather = require('./lib/weather');
const T = require('./lib/texts');
const cards = require('./lib/card');
const { Renderer } = require('./lib/render-image');
const media = require('./lib/media');
const sender = require('./lib/sender');
const { openStore } = require('./lib/store');
const U = require('./lib/util');

const PLUGIN_ID = 'weather';
const PLUGIN_VERSION = '1.3.2';

/** 调度固定「每分钟整点检查一次」，不再做成可配置（需求：按当前分钟判断，有就推） */
const TICK_MS = 60000;
/** 同一分钟的推送并发数：只是取数/出图/发送的并发度，**不是人数上限**（人数无上限） */
const PUSH_CONCURRENCY = 4;

const DEFAULT_CONFIG = {
  fetchTimeoutMs: 6000,
  sendTimeoutMs: 30000,
  cacheTtlMs: 600000,
  defaultTime: '0800',
  geocodeOnSubscribe: true,
};

let rt = null;

/* ---------------------------- 配置 ---------------------------- */

function num(v, def, min, max) {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.min(max, Math.max(min, n));
}

function normalizeConfig(raw) {
  const c = raw && typeof raw === 'object' ? raw : {};
  const render = c.render && typeof c.render === 'object' ? c.render : {};
  return {
    fetchTimeoutMs: num(c.fetchTimeoutMs, DEFAULT_CONFIG.fetchTimeoutMs, 3000, 20000),
    sendTimeoutMs: num(c.sendTimeoutMs, DEFAULT_CONFIG.sendTimeoutMs, 5000, 90000),
    cacheTtlMs: num(c.cacheTtlMs, DEFAULT_CONFIG.cacheTtlMs, 0, 6 * 3600 * 1000),
    defaultTime: S.parseTime(c.defaultTime) || DEFAULT_CONFIG.defaultTime,
    geocodeOnSubscribe: c.geocodeOnSubscribe !== false,
    render: {
      enabled: render.enabled !== false,
      timeoutMs: num(render.timeoutMs, 20000, 4000, 60000),
      maxConcurrent: num(render.maxConcurrent, 2, 1, 4),
    },
    texts: T.normalizeTexts(c.texts),
    card: T.normalizeCard(c.card),
    tasks: Array.isArray(c.tasks) ? c.tasks.slice(0, 200) : [],
  };
}

/* ---------------------------- 运行时 ---------------------------- */

function ensureRuntime(ctx) {
  const dir = ctx?.plugin?.dir || path.resolve(__dirname);
  if (rt && rt.dir === dir) {
    if (ctx?.plugin?.config) {
      rt.cfg = normalizeConfig(ctx.plugin.config);
      if (rt.renderer) {
        rt.renderer.cfg = rt.cfg.render;
        rt.renderer.enabled = rt.cfg.render.enabled;
        rt.renderer.timeoutMs = rt.cfg.render.timeoutMs;
        rt.renderer.maxConcurrent = rt.cfg.render.maxConcurrent;
      }
    }
    if (ctx?.config) rt.config = ctx.config;
    return rt;
  }
  if (rt && (rt.timer || rt.bootTimer)) {
    if (rt.timer) clearInterval(rt.timer);
    if (rt.bootTimer) clearTimeout(rt.bootTimer);
  }
  const cfg = normalizeConfig(ctx?.plugin?.config);
  const log = ctx?.log || console;
  rt = {
    dir,
    cfg,
    config: ctx?.config || null,
    log,
    pluginId: ctx?.plugin?.id || PLUGIN_ID,
    store: openStore({ dir, log }),
    renderer: new Renderer({ dir, cfg: cfg.render, log }),
    timer: null,
    bootTimer: null,
    ticking: false,
    startedAt: Date.now(),
    lastError: '',
    pushed: 0,
    failed: 0,
    lastPushAt: 0,
    lastTickAt: 0,
    lastMinute: '',
    lastDueCount: 0,
    version: PLUGIN_VERSION,
  };
  return rt;
}

function setError(r, msg) {
  r.lastError = String(msg || '').slice(0, 300);
  r.log?.warn?.('天气：' + r.lastError);
}

function maskOpenid(id) {
  const s = String(id || '');
  if (s.length <= 10) return s;
  return `${s.slice(0, 6)}…${s.slice(-4)}`;
}

/* ---------------------------- 出图 ---------------------------- */

async function renderPng(r, spec) {
  try {
    const out = await r.renderer.render(spec);
    return out.buffer;
  } catch (e) {
    setError(r, '出图失败：' + (e?.message || e));
    return null;
  }
}

/** 把 spec 变成插件返回值：优先图片，出图/上传失败退纯文本 */
async function replySpec(r, ctx, spec) {
  const fallback = cards.specToText(spec);
  const png = await renderPng(r, spec);
  if (png) {
    const up = await media.replyImage(ctx, png);
    if (up.ok) return { replies: up.replies };
    r.log?.warn?.('天气：图片回复失败，改发文本（' + up.error + '）');
  }
  return { reply: fallback };
}

function weatherSpec(r, w, sub, at = new Date(), { kind = 'push' } = {}) {
  const cfg = r.cfg;
  const vars = T.weatherVars(w, sub, at);
  const lines = T.toLines(cfg.texts.weather, vars);
  const titleTpl = kind === 'query' ? cfg.texts.queryTitle : cfg.texts.weatherTitle;
  const title = T.renderTemplate(titleTpl || cfg.texts.weatherTitle, vars);
  const footer = T.renderTemplate(cfg.card.footer, vars);
  return cards.buildSpec({ title, lines, footer, card: cfg.card });
}

/** 订阅/状态/帮助/报错这类「信息卡」；footer 传 '' 表示这张卡不要页脚 */
function infoSpec(r, kind, vars = {}, opts = {}) {
  const cfg = r.cfg;
  const title = T.renderTemplate(cfg.texts[`${kind}Title`] || '', vars);
  const lines = T.toLines(cfg.texts[kind] || '', vars);
  const footerTpl = opts.footer !== undefined ? opts.footer : cfg.card.footer;
  const footer = footerTpl ? T.renderTemplate(footerTpl, vars) : '';
  return cards.buildSpec({ title, lines, footer, card: cfg.card });
}

async function infoReply(r, ctx, kind, vars, opts) {
  return replySpec(r, ctx, infoSpec(r, kind, vars, opts));
}

/* ---------------------------- 取数 ---------------------------- */

async function fetchWeather(r, sub) {
  const plainName = [sub.city, sub.district].filter(Boolean).join('') || sub.display || sub.city || '';
  return weather
    .getWeather(
      { code: sub.code, lat: sub.lat, lon: sub.lon, name: plainName },
      { timeoutMs: r.cfg.fetchTimeoutMs, cacheTtlMs: r.cfg.cacheTtlMs },
    )
    .catch((e) => {
      setError(r, '取数失败：' + (e?.message || e));
      return null;
    });
}

/** 城市名 → 地理字段（离线表优先，查不到再地理编码） */
async function locate(r, cityText) {
  const res = C.resolve(cityText);
  if (res.ok) {
    const out = {
      code: res.code,
      display: res.display,
      province: res.province,
      city: res.city,
      district: res.district,
      lat: null,
      lon: null,
      via: 'table',
    };
    if (r.cfg.geocodeOnSubscribe) {
      const q = [res.province, res.city, res.district].filter(Boolean).join(' ');
      const geo = await geocode.geocode(q, { timeoutMs: Math.min(3500, r.cfg.fetchTimeoutMs) }).catch(() => null);
      if (geo && geo.ok && looksLike(geo, res)) {
        out.lat = geo.lat;
        out.lon = geo.lon;
      }
    }
    return { ok: true, ...out };
  }
  if (res.reason === 'ambiguous' || res.reason === 'need-city' || res.reason === 'empty') return res;

  const geo = await geocode.geocode(cityText, { timeoutMs: r.cfg.fetchTimeoutMs }).catch(() => null);
  if (geo && geo.ok) {
    return {
      ok: true,
      code: '',
      display: geo.display || cityText,
      province: geo.state || '',
      city: geo.city || '',
      district: geo.name || '',
      lat: geo.lat,
      lon: geo.lon,
      via: 'geocode',
    };
  }
  return res;
}

function looksLike(geo, res) {
  const hay = [geo.display, geo.name, geo.city, geo.state].filter(Boolean).join('·');
  const keys = [res.district, res.city].filter(Boolean);
  if (!keys.length) return true;
  return keys.some((k) => hay.includes(String(k).replace(/(省|市|区|县|旗|盟|自治州)$/g, '')));
}

/* ---------------------------- 指令解析 ---------------------------- */

function normalizeText(text) {
  return String(text || '')
    .replace(/^[\s\u3000]*[/／!！.。]+/, '')
    .replace(/[\u3000]/g, ' ')
    .trim();
}

const CMD_RE = /^(?:天气查询|天气)(?=[\s]|$)/;

/**
 * @returns {null|{kind:'auto'|'query'|'subscribe'|'time'|'cancel'|'status'|'help', city?:string, time?:string}}
 */
function parseIntent(text) {
  const raw = normalizeText(text);
  if (!raw || !CMD_RE.test(raw)) return null;
  const rest = raw.replace(CMD_RE, '').trim();
  const tokens = rest ? rest.split(/\s+/).filter(Boolean) : [];
  const head = tokens[0] || '';
  if (!head) return { kind: 'auto' };
  if (/^(订阅|订阅推送)$/.test(head)) return { kind: 'subscribe', city: tokens.slice(1).join(' ').trim() };
  if (/^(取消订阅|取消|退订)$/.test(head)) return { kind: 'cancel' };
  if (/^(时间|推送时间|定时)$/.test(head)) return { kind: 'time', time: tokens.slice(1).join('').trim() };
  if (/^(帮助|help|说明|菜单)$/i.test(head)) return { kind: 'help' };
  if (/^(状态|我的)$/.test(head)) return { kind: 'status' };
  return { kind: 'query', city: rest };
}

/* ---------------------------- 业务处理 ---------------------------- */

function sceneOf(message) {
  if (!message) return '';
  if (message.kind === 'group') return 'group';
  if (message.kind === 'c2c') return 'c2c';
  return '';
}

function identityOf(message, ctx) {
  const scene = sceneOf(message);
  const openid = String(message?.user_openid || message?.author?.user_openid || message?.author?.id || '').trim();
  const accountId = String(ctx?.account?.id || '').trim();
  return { scene, openid, accountId };
}

async function handleLocateFail(r, ctx, found, cityText) {
  if (found.reason === 'ambiguous') {
    const options = (found.alternatives || []).map((a) => `/天气 ${a.text}`).join('\n');
    return infoReply(r, ctx, 'ambiguous', { query: cityText, options });
  }
  if (found.reason === 'need-city') {
    const options = (found.suggestions || []).slice(0, 6).map((s) => `/天气 ${s.text}`).join('\n');
    return infoReply(r, ctx, 'ambiguous', { query: cityText, options });
  }
  return infoReply(r, ctx, 'cityNotFound', { query: cityText });
}

/** 查天气（群 / 私聊都允许） */
async function handleQuery(r, ctx, { scene, openid, cityText }) {
  let sub = null;
  if (cityText) {
    const found = await locate(r, cityText);
    if (!found.ok) return handleLocateFail(r, ctx, found, cityText);
    sub = {
      openid,
      display: found.display,
      province: found.province,
      city: found.city,
      district: found.district,
      code: found.code,
      lat: found.lat,
      lon: found.lon,
      time: r.cfg.defaultTime,
      enabled: false,
    };
  } else if (scene === 'c2c') {
    sub = r.store.get(openid);
    if (!sub || (!sub.code && sub.lat == null)) return infoReply(r, ctx, 'cityMissing', {});
  } else {
    return infoReply(r, ctx, 'cityMissing', {});
  }

  const w = await fetchWeather(r, sub);
  if (!w || !w.ok) {
    return infoReply(r, ctx, 'error', { message: '暂时查不到天气（数据源都没响应），过几分钟再发一次 /天气 城市' });
  }
  return replySpec(r, ctx, weatherSpec(r, w, sub, new Date(), { kind: 'query' }));
}

/** 订阅（私聊） */
async function handleSubscribe(r, ctx, { scene, openid, accountId, cityText }) {
  if (scene !== 'c2c') return infoReply(r, ctx, 'groupOnly', {});
  if (!cityText) return infoReply(r, ctx, 'cityMissing', {});

  const found = await locate(r, cityText);
  if (!found.ok) return handleLocateFail(r, ctx, found, cityText);

  const now = new Date();
  const existing = r.store.get(openid);
  const time = (existing && existing.time) || r.cfg.defaultTime;
  const sub = r.store.upsert({
    ...(existing || {}),
    openid,
    accountId: accountId || existing?.accountId || '',
    code: found.code,
    display: found.display,
    province: found.province,
    city: found.city,
    district: found.district,
    lat: found.lat,
    lon: found.lon,
    time,
    enabled: true,
    created: existing?.created || Date.now(),
    // 不再预写 lastDate：到点判定只比较「当前分钟」，预写会把今天真正到点那次挡掉
    failCount: 0,
    lastError: '',
  });
  if (!sub) return infoReply(r, ctx, 'error', { message: '订阅没存进去（存储不可用），把这条发给管理员看看日志' });
  r.log?.info?.(`天气：${maskOpenid(openid)} 订阅 ${sub.display}（${sub.code || 'geo'}）每天 ${S.formatTime(time)}`);
  refreshSnapshot(r);
  return infoReply(r, ctx, 'subscribed', { ...T.infoVars(sub), firstAt: S.firstPushText(time, now) });
}

/** 设置时间（私聊） */
async function handleTime(r, ctx, { scene, openid, accountId, timeText }) {
  if (scene !== 'c2c') return infoReply(r, ctx, 'groupOnly', {});
  const time = S.parseTime(timeText);
  if (!time) return infoReply(r, ctx, 'badTime', { input: timeText || '', example: S.formatTime(r.cfg.defaultTime) });
  const existing = r.store.get(openid);
  if (!existing || (!existing.code && existing.lat == null)) return infoReply(r, ctx, 'cityMissing', {});

  const now = new Date();
  const sub = r.store.upsert({
    ...existing,
    openid,
    accountId: accountId || existing.accountId || '',
    time,
    enabled: true,
    // 同上：不要预写 lastDate（否则今天到点会被判成「今天已推」）
  });
  if (!sub) return infoReply(r, ctx, 'error', { message: '时间没存进去（存储不可用），把这条发给管理员看看日志' });
  r.log?.info?.(`天气：${maskOpenid(openid)} 推送时间 ${S.formatTime(time)}（${sub.display}）`);
  refreshSnapshot(r);
  return infoReply(r, ctx, 'timeSet', { ...T.infoVars(sub), firstAt: S.firstPushText(time, now) });
}

/** 取消订阅（私聊） */
async function handleCancel(r, ctx, { scene, openid }) {
  if (scene !== 'c2c') return infoReply(r, ctx, 'groupOnly', {});
  const existing = r.store.get(openid);
  if (!existing) return infoReply(r, ctx, 'cancelled', {});
  r.store.patch(openid, { enabled: false });
  r.log?.info?.(`天气：${maskOpenid(openid)} 取消订阅`);
  refreshSnapshot(r);
  return infoReply(r, ctx, 'cancelled', {});
}

/** 状态（私聊） */
async function handleStatus(r, ctx, { scene, openid }) {
  if (scene !== 'c2c') return infoReply(r, ctx, 'groupOnly', {});
  const sub = r.store.get(openid);
  if (!sub) return infoReply(r, ctx, 'menu', {});
  return infoReply(r, ctx, 'status', T.infoVars(sub));
}

/* ---------------------------- 定时推送 ---------------------------- */

/** 推送失败时给一句人话提示（没开主动消息权限是最常见的） */
function pushFailHint(code, message) {
  const s = `${code || ''} ${message || ''}`;
  if (/TOKEN_ERROR|invalid appid/i.test(s)) return '（框架的 AppID / AppSecret 不对，先在面板把机器人连上）';
  if (/40034105|304023|主动消息/.test(s)) return '（机器人没有「主动消息」权限：到 QQ 开放平台开通后再试）';
  if (/40034024/.test(s)) return '（超出了 QQ 的回复时间窗，主动消息不受这个限制，检查是否走了被动回复）';
  if (/11321|user_id|user_openid/i.test(s)) return '（这个 openid 无效，用户可能已经删掉机器人）';
  if (/REPLY_GUARD|限流/.test(s)) return '（被框架的回复闸门限流）';
  if (/NETWORK|TIMEOUT/.test(s)) return '（连不上本地面板接口，检查 server.port / 插件令牌）';
  return '';
}

/**
 * 推一个人。
 * 约定（v1.2.0）：**发出去就算处理完**——成功或失败都会写 lastDate=今天，
 * 「因特殊原因没发成功的不补推」，下一轮只看新的当前分钟。
 */
async function pushOne(r, sub, { now = new Date() } = {}) {
  const w = await fetchWeather(r, sub);
  const spec = w && w.ok ? weatherSpec(r, w, sub, now, {}) : infoSpec(r, 'error', { message: '自动推送时天气接口不通，这一条先跳过' });
  const png = await renderPng(r, spec);
  const sent = await sender.pushImage({
    config: r.config,
    pluginId: r.pluginId,
    accountId: sub.accountId,
    openid: sub.openid,
    buffer: png,
    textFallback: cards.specToText(spec),
    timeoutMs: r.cfg.sendTimeoutMs,
  });

  const base = {
    lastDate: U.dateKey(now),
    lastTime: S.hhmmOf(now),
    pushCount: (sub.pushCount || 0) + (sent.ok ? 1 : 0),
    failCount: sent.ok ? 0 : (sub.failCount || 0) + 1,
    lastError: sent.ok ? '' : `${sent.code || ''} ${sent.message || ''}`.trim().slice(0, 200) || '发送失败',
  };

  if (sent.ok) {
    r.pushed++;
    r.lastPushAt = Date.now();
    r.store.patch(sub.openid, base);
    r.log?.info?.(`天气：已推送 ${maskOpenid(sub.openid)}（${sub.display}，${S.formatTime(sub.time)}）${sent.via === 'image' ? '' : ' [文本兜底]'}`);
    return true;
  }

  r.failed++;
  r.store.patch(sub.openid, base);
  setError(r, `推送给 ${maskOpenid(sub.openid)} 失败：${sent.code || ''} ${sent.message || ''}${pushFailHint(sent.code, sent.message)}（按设置不补推，等明天这个点）`);
  return false;
}

/**
 * 每分钟跑一次：把「推送时间 == 当前分钟」的订阅**全部**推完（人数无上限）。
 * 只受并发度限制（PUSH_CONCURRENCY），不受人数限制；
 * 一旦跨分钟，剩下的作废（不补推）。
 */
async function tick(r = rt) {
  if (!r) return;
  if (r.ticking) return;
  r.ticking = true;
  try {
    const now = new Date();
    const minute = S.minuteKey(now);
    r.lastTickAt = Date.now();
    r.lastMinute = minute;
    const due = r.store.list().filter((s) => S.dueNow(s, now).due);
    r.lastDueCount = due.length;
    if (!due.length) return;

    let cursor = 0;
    const worker = async () => {
      for (;;) {
        const sub = due[cursor++];
        if (!sub) return;
        // 跨分钟了：剩下的作废（不补推），下一轮按新的分钟判断
        if (S.minuteKey(new Date()) !== minute) return;
        await pushOne(r, sub, { now: new Date() });
      }
    };
    await Promise.all(Array.from({ length: Math.min(PUSH_CONCURRENCY, due.length) }, worker));
  } catch (e) {
    setError(r, '定时任务异常：' + (e?.stack || e));
  } finally {
    r.ticking = false;
    // 每分钟把运行状态写回设置页快照：调度是否在跑、上次检查、本分钟待推人数
    try {
      refreshSnapshot(r);
    } catch {
      /* ignore */
    }
  }
}

/**
 * 对齐到整分：先等到下一个整分，再每 60 秒跑一次。
 * （不用 setInterval(tick, 60s) 是因为插件加载时刻是随机的，会和整分错开。）
 */
function startScheduler(r) {
  if (r.timer) clearInterval(r.timer);
  if (r.bootTimer) clearTimeout(r.bootTimer);
  const arm = () => {
    r.timer = setInterval(() => {
      tick(r).catch((e) => setError(r, '定时任务异常：' + (e?.message || e)));
    }, TICK_MS);
    if (r.timer.unref) r.timer.unref();
  };
  // 插件刚加载时先按「当前这一分钟」检查一次（否则 17:10:30 加载会漏掉 17:10 的订阅）
  tick(r).catch((e) => setError(r, '首轮检查异常：' + (e?.message || e)));
  r.bootTimer = setTimeout(() => {
    if (rt !== r) return;
    r.log?.info?.(`天气：进入整分调度，当前 ${S.minuteKey()}，之后每分钟检查一次`);
    arm();
    // 定时器就绪后再写一次快照，否则设置页会一直显示「调度未运行」
    try {
      refreshSnapshot(r);
    } catch {
      /* ignore */
    }
    tick(r).catch((e) => setError(r, '首轮检查异常：' + (e?.message || e)));
  }, S.msToNextMinute());
  if (r.bootTimer.unref) r.bootTimer.unref();
  r.log?.info?.(`天气：调度已就绪，${Math.round(S.msToNextMinute() / 1000)} 秒后对齐整分，之后每分钟检查「当前分钟有没有订阅」`);
}

/* ---------------------------- 设置页快照 / 任务 ---------------------------- */

const SNAP_START = '<!-- WX_DATA_START -->';
const SNAP_END = '<!-- WX_DATA_END -->';

function buildSnapshot(r) {
  const list = r.store.list();
  const counts = r.store.counts();
  const tasks = {};
  for (const rec of r.store.recentTasks(10)) {
    const id = rec.id || rec.at;
    tasks[id] = {
      at: Number(rec.at) || 0,
      action: rec.action || '',
      openid: maskOpenid(rec.openid),
      ok: rec.ok === true || rec.ok === 1,
      message: rec.message || '',
    };
  }
  return {
    at: Date.now(),
    version: r.version,
    uptimeSec: Math.round((Date.now() - r.startedAt) / 1000),
    runtime: {
      running: !!r.timer || !!r.bootTimer,
      ticking: !!r.ticking,
      pushed: r.pushed,
      failed: r.failed,
      lastPushAt: r.lastPushAt,
      lastError: r.lastError,
      render: r.renderer.stats(),
      schedule: {
        everySeconds: TICK_MS / 1000,
        minute: S.minuteKey(),
        lastTickAt: r.lastTickAt || 0,
        lastMinute: r.lastMinute || '',
        dueNow: r.lastDueCount || 0,
        nextTickAt: r.lastTickAt ? r.lastTickAt + TICK_MS : 0,
        concurrency: PUSH_CONCURRENCY,
        noLimit: true,
      },
    },
    storage: r.store.info(),
    counts,
    cities: C.stats(),
    defaults: { texts: T.DEFAULT_TEXTS, card: T.DEFAULT_CARD },
    config: {
      defaultTime: r.cfg.defaultTime,
      cacheTtlMs: r.cfg.cacheTtlMs,
      render: r.cfg.render,
      texts: r.cfg.texts,
      card: r.cfg.card,
    },
    subs: list.map((s) => ({
      openid: maskOpenid(s.openid),
      openidRaw: s.openid,
      accountId: s.accountId,
      display: s.display,
      code: s.code,
      time: s.time,
      enabled: s.enabled,
      lastDate: s.lastDate,
      lastTime: s.lastTime,
      pushCount: s.pushCount,
      failCount: s.failCount,
      lastError: s.lastError,
    })),
    tasks,
  };
}

function refreshSnapshot(r) {
  try {
    const fs = require('node:fs');
    const file = path.join(r.dir, 'settings.html');
    const html = fs.readFileSync(file, 'utf8');
    const i = html.indexOf(SNAP_START);
    const j = html.indexOf(SNAP_END);
    if (i < 0 || j < i) {
      r.log?.warn?.('天气：settings.html 缺少 WX_DATA 占位区，设置页将没有实时数据');
      return false;
    }
    const json = JSON.stringify(buildSnapshot(r)).replace(/</g, '\\u003c');
    const block = `${SNAP_START}\n<script id="wx-data" type="application/json">${json}</script>\n${SNAP_END}`;
    const next = html.slice(0, i) + block + html.slice(j + SNAP_END.length);
    if (next !== html) U.atomicWrite(file, next);
    return true;
  } catch (e) {
    r.log?.warn?.('天气：写设置页快照失败：' + (e?.message || e));
    return false;
  }
}

async function processTasks(r) {
  const tasks = r.cfg.tasks || [];
  if (!tasks.length) return 0;
  let ran = 0;
  for (const t of tasks) {
    if (!t || !t.id) continue;
    if (r.store.taskDone(t.id)) continue;
    const openid = String(t.openid || '').trim();
    let result = { ok: false, message: '未知动作' };
    try {
      switch (String(t.action || '')) {
        case 'del': {
          result = r.store.remove(openid) ? { ok: true, message: '已删除订阅' } : { ok: false, message: '没有这条订阅' };
          break;
        }
        case 'enable':
        case 'disable': {
          const sub = r.store.get(openid);
          if (!sub) result = { ok: false, message: '没有这条订阅' };
          else {
            r.store.patch(openid, { enabled: t.action === 'enable' });
            result = { ok: true, message: t.action === 'enable' ? '已开启' : '已暂停' };
          }
          break;
        }
        case 'test': {
          const sub = r.store.get(openid);
          if (!sub) result = { ok: false, message: '没有这条订阅' };
          else {
            const w = await weather.getWeather(
              { code: sub.code, lat: sub.lat, lon: sub.lon, name: [sub.city, sub.district].filter(Boolean).join('') },
              { timeoutMs: r.cfg.fetchTimeoutMs, cacheTtlMs: 0, force: true },
            );
            const spec = w && w.ok ? weatherSpec(r, w, sub, new Date(), {}) : infoSpec(r, 'error', { message: '测试时天气接口不通' });
            const png = await renderPng(r, spec);
            const sent = await sender.pushImage({
              config: r.config,
              pluginId: r.pluginId,
              accountId: sub.accountId,
              openid: sub.openid,
              buffer: png,
              textFallback: cards.specToText(spec),
              timeoutMs: r.cfg.sendTimeoutMs,
            });
            result = { ok: !!sent.ok, message: sent.ok ? '已发送一条测试推送' : `发送失败：${sent.code || ''} ${sent.message || ''}`.trim() };
          }
          break;
        }
        default:
          result = { ok: false, message: '未知动作 ' + String(t.action || '') };
      }
    } catch (e) {
      result = { ok: false, message: e?.message || String(e) };
    }
    r.store.recordTask({ id: t.id, action: String(t.action || ''), openid, at: Date.now(), ...result });
    ran++;
    r.log?.[result.ok ? 'info' : 'warn']?.(`天气：设置页任务 ${t.action} ${maskOpenid(openid)} → ${result.message}`);
  }
  if (ran) refreshSnapshot(r);
  return ran;
}

/* ---------------------------- 插件入口 ---------------------------- */

async function onLoad(ctx) {
  try {
    const r = ensureRuntime(ctx);
    r.log = ctx?.log || r.log;
    r.config = ctx?.config || r.config;
    const counts = r.store.counts();
    const cityStats = C.stats();
    const st = r.store.info();
    r.log.info(
      `天气 v${r.version} 已加载：订阅 ${counts.total}（开启 ${counts.enabled}）· 存储 ${String(st.driver).toUpperCase()}` +
        `${st.error ? '（' + st.error + '）' : ''} · 城市表 ${cityStats.provinces}/${cityStats.cities}/${cityStats.districts} · 出图 ${r.renderer.available() ? '可用' : '不可用（退回文本）'}`,
    );
    await processTasks(r);
    // 先把调度挂上，再写快照：否则首份快照里 running=false，设置页会显示「调度未运行」
    startScheduler(r);
    refreshSnapshot(r);
  } catch (e) {
    (ctx?.log || console).error('天气：初始化失败 ' + (e?.stack || e));
  }
}

async function onUnload() {
  const r = rt;
  rt = null;
  if (!r) return;
  if (r.timer) clearInterval(r.timer);
  if (r.bootTimer) clearTimeout(r.bootTimer);
  try {
    r.store.close?.();
  } catch {
    /* ignore */
  }
  r.log?.info?.('天气：已卸载（调度停止）');
}

async function onEvent(ctx, evt) {
  const log = ctx?.log || console;
  try {
    const r = ensureRuntime(ctx);
    r.log = ctx?.log || r.log;
    r.config = ctx?.config || r.config;
    const name = evt?.name || ctx?.event?.name || '';
    if (!/^(C2C_MESSAGE_CREATE|GROUP_AT_MESSAGE_CREATE|GROUP_MESSAGE_CREATE)$/.test(name)) return null;
    const msg = ctx?.message || evt?.message;
    if (!msg) return null;
    const { scene, openid, accountId } = identityOf(msg, ctx);
    if (!scene) return null;
    if (scene === 'c2c' && openid) sender.rememberBot(accountId, ctx?.bot);

    const intent = parseIntent(msg.cleanContent || msg.content || '');
    if (!intent) return null;

    switch (intent.kind) {
      case 'auto': {
        // 私聊：已订阅看状态，没订阅给菜单；群里只给「只能查天气」的群菜单（群里不放订阅页脚）
        if (scene === 'c2c') {
          const sub = r.store.get(openid);
          return sub ? handleStatus(r, ctx, { scene, openid }) : infoReply(r, ctx, 'menu', {});
        }
        return infoReply(r, ctx, 'menuGroup', {}, { footer: '' });
      }
      case 'help':
        return infoReply(r, ctx, scene === 'group' ? 'menuGroup' : 'help', {}, scene === 'group' ? { footer: '' } : undefined);
      case 'query':
        return await handleQuery(r, ctx, { scene, openid, cityText: intent.city });
      case 'subscribe':
        return await handleSubscribe(r, ctx, { scene, openid, accountId, cityText: intent.city });
      case 'time':
        return await handleTime(r, ctx, { scene, openid, accountId, timeText: intent.time });
      case 'cancel':
        return await handleCancel(r, ctx, { scene, openid });
      case 'status':
        return await handleStatus(r, ctx, { scene, openid });
      default:
        return null;
    }
  } catch (e) {
    log?.error?.('天气：处理消息失败 ' + (e?.stack || e));
    try {
      const r = ensureRuntime(ctx);
      const spec = infoSpec(r, 'error', { message: String(e?.message || e).slice(0, 120) });
      return await replySpec(r, ctx, spec);
    } catch {
      return null;
    }
  }
}

module.exports = {
  onLoad,
  onEvent,
  onUnload,
  parseIntent,
  normalizeConfig,
  weatherSpec,
  infoSpec,
  buildSnapshot,
  tick,
  PLUGIN_ID,
  PLUGIN_VERSION,
};
