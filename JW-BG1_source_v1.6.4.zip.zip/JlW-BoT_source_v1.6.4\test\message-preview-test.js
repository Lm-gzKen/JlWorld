'use strict';
/** 临时校验：消息预览渲染（文本/markdown/图片/ark_data 群公告/XSS） */
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'web', 'app.js'), 'utf8');
const start = src.indexOf('/* ================= 消息预览');
const end = src.indexOf('function openEventDrawer(', start);
if (start < 0 || end < 0) throw new Error('找不到消息预览块');
const block = src.slice(start, end);

const esc = (s) =>
  String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
const fn = new Function(
  'esc',
  'accountName',
  'fmtDateTime',
  'isOutgoing',
  block + '\nreturn { renderMessagePreview, renderMarkdown, cardFromPayload, stripCtl };',
);
const api = fn(esc, () => '测试账户', () => '2026-11-24 12:00:00', (e) => e.direction === 'out');

const checks = [];
const check = (ok, msg) => {
  checks.push(ok);
  console.log((ok ? '  PASS  ' : '  FAIL  ') + msg);
};

// 1. 纯文本 + 链接 + 转义
let h = api.renderMessagePreview({ ts: 1, message: { content: '你好 https://example.com/a?b=1 <img onerror=alert(1)>' } });
check(h.includes('你好') && h.includes('href="https://example.com/a?b=1"'), '纯文本自动识别链接');
check(h.includes('&lt;img onerror'), 'HTML 被转义（不会执行）');

// 2. markdown
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '# 标题\n**加粗**\n- 列表一\n- 列表二\n[链接](https://example.com/x)' },
});
check(h.includes('<h3 class="bubble-h">标题</h3>'), 'markdown 标题渲染');
check(h.includes('<b>加粗</b>') && h.includes('<li>列表一</li>'), 'markdown 加粗/列表渲染');
check(h.includes('href="https://example.com/x"'), 'markdown 链接渲染');

// 2.1 图片/行内标签不能被 URL 自动识别二次包裹（旧消息里常见），加粗仍要生效
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '![图片说明 #0px #0px](https://example.com/a.png) <qqbot-at-user id="U1" /> 欢迎 **加入**' },
});
check(
  h.includes('<img class="bubble-img" src="https://example.com/a.png"') &&
    !h.includes('href="<a') &&
    h.includes('<b>加入</b>') &&
    h.includes('@用户') &&
    !h.includes('qqbot-'),
  '图片 URL 不被二次包链接，自定义标签不显示且加粗生效',
);

// 3. 图片附件
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '', attachments: [{ content_type: 'image/png', url: 'https://example.com/a.png', size: 2048 }] },
});
check(h.includes('class="bubble-img"') && h.includes('https://example.com/a.png'), '图片附件渲染成图片');

// 3.1 腾讯自定义标签：中文解码、@ 用户、单独成行的命令蓝字隐藏、*** 变分隔线
h = api.renderMessagePreview({
  ts: 1,
  message: {
    content:
      '<qqbot-at-user id="81910C31F04A9A12F7D93CDD0D074650" /> 欢迎加入 春风精灵！\n***\n<qqbot-cmd-input text="%2F%E8%8F%9C%E5%8D%95" show="%E8%8F%9C%E5%8D%95" />\n2026-11-24 17:14:16\n[BoT BUG提交](https://www.jlworld.net)',
  },
});
check(
  h.includes('@用户') &&
    h.includes('欢迎加入 春风精灵！') &&
    !h.includes('qqbot-') &&
    !h.includes('%E8') &&
    !h.includes('菜单') &&
    h.includes('bubble-hr') &&
    h.includes('https://www.jlworld.net'),
  '腾讯自定义标签解码/隐藏，*** 渲染为分隔线',
);

// 3.2 行内命令标签显示解码后的中文标签，不显示原始 <qqbot-cmd-input>
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '- <qqbot-cmd-input text="%2F%E7%BE%A4%E7%AE%A1" show="%E7%BE%A4%E7%AE%A1" />：进退群提示' },
});
check(h.includes('群管：进退群提示') && !h.includes('qqbot-cmd-input') && !h.includes('%E7'), '行内命令标签解码成中文');

// 4. ark_data 群公告（带控制字符）
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '' },
  raw: {
    ark_data: {
      ark_name: '',
      ark_type: 'unknown',
      prompt: '\u0002[群公告]\u0002官网：https://www.jlworld.net/\u0002提供可视化网站搭建',
    },
  },
});
check(h.includes('群公告'), 'ark_data 的 [群公告] 前缀识别为标题');
check(h.includes('https://www.jlworld.net/') && h.includes('href='), '群公告正文里的链接可点');
check(!h.includes('\u0002') && !h.includes('\u0001'), '控制字符已清理');

// 5. 结构化 ark（kv 卡片）
h = api.renderMessagePreview({
  ts: 1,
  message: { content: '' },
  raw: { ark: { kv: [{ key: '#TITLE#', value: '标题卡' }, { key: '#DESC#', value: '描述' }, { key: '#IMG#', value: 'https://example.com/c.png' }] } },
});
check(h.includes('msg-card-title') && h.includes('标题卡') && h.includes('https://example.com/c.png'), 'ark kv 卡片渲染');

// 6. 卡片/富媒体占位
h = api.renderMessagePreview({ ts: 1, direction: 'out', message: { content: '[卡片消息]' } });
check(h.includes('卡片消息') && h.includes('原始事件'), '卡片占位提示');

// 7. javascript: 链接不放行
h = api.renderMessagePreview({ ts: 1, message: { content: '[点我](javascript:alert(1))' } });
check(!h.includes('href="javascript:'), 'javascript: 链接被拦截');

// 8. 机器人发出：markdown body
h = api.renderMessagePreview({ ts: 1, direction: 'out', message: { content: '标题', payload: { msg_type: 2, markdown: { content: '## 小标题\n**粗体**' } } } });
check(h.includes('<h4 class="bubble-h">小标题</h4>') && h.includes('<b>粗体</b>'), '发出消息的 markdown body 渲染');

// 9. 机器人发出：card body
h = api.renderMessagePreview({ ts: 1, direction: 'out', message: { content: '[卡片消息]', payload: { msg_type: 8, card: { title: '卡片标题', desc: '卡片描述' } } } });
check(h.includes('msg-card-title') && h.includes('卡片标题'), '发出消息的卡片 body 渲染');

// 10. 机器人发出：media body
h = api.renderMessagePreview({ ts: 1, direction: 'out', message: { content: '[富媒体消息]', payload: { msg_type: 7, media: { file_info: 'abc-file-info' } } } });
check(h.includes('富媒体消息') && h.includes('abc-file-info'), '发出消息的富媒体 body 渲染');

const bad = checks.filter((x) => !x).length;
console.log(`\n${checks.length - bad}/${checks.length} 通过`);
process.exit(bad ? 1 : 0);
